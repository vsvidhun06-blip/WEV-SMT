---
name: wev-smt-pass-status
description: wev-smt status — Pass 3 Stage 2 RESOLVED (0 mismatches, WEAKEST captured); Day 9 scalability, Day 10 .litmus parser, Day 11 real-corpus (0/2998 hierarchy-soundness), Day 12 fence+RMW encoding (190/190 atlas, scalability-fences <3x), Day 13 POPL Docker artifact (one-command reproduce, 1.34GB, 14m44s), Day 14 edge-case robustness (11/11 handled, validate package + resource ceilings, 45/45 tests, 7-step Docker 15m14s), Day 15 paper §4 worked example (LB-real vs LB-fake-xor-cycle contrast, 48/48 tests)
metadata:
  node_type: memory
  type: project
  originSessionId: 1cfb6e58-a223-418c-9de0-da05407f9037
---

`wev-smt` (the SMT minimum-witness layer for the POPL submission) is well past the
mismatch-reduction phase. Current state as of **2026-05-23**:

**Validation: 0 mismatches, 133/133 matched.** `AtlasReconstruct` (`consistency-validation.csv`,
`mismatches.txt`) reconstructs the weak-memory atlas with no remaining disagreements
against the textbook outcomes. WEAKEST is fully captured.

**Lineage (compressed):**
- Passes 2a/2b-min/2c reduced 16→5 mismatches (RA `irreflexive(hb;eco?)`; relaxed
  well-formedness dropping cross-location `W→W`/`W→R` from global `pos`; PSO `sw`).
- Pass 3 Stage 1 (2026-05-21, `754de74`): data model only — `wev.smt.DependencyInfo`
  sidecar (data/addr/ctrl, `isSemantic` flag), inert `dep_*` encoder vars,
  `dependencyDefinitions()` hook. `com.weakest.model.*` left untouched (read-only rule).
- Pass 3 Stage 2 "Option B" (Day 8, 2026-05-22, commit **`b405f7c`**): the genuine POPL
  contribution. `AxiomaticConsistency.jfCoherence` = `acyclic(sdep ∪ jf)` wired into
  `consistencyWEAKEST` ONLY (verified polarity: `jf_w_r ⇒ layer(w)<layer(r)`, dep
  producer→consumer); **WF relaxation** dropping the global rf-forward edge
  (`rf(w,r) ⇒ pos(w)<pos(r)`) from BOTH `EventStructureEncoder.encodeWellFormedness` and
  `MinimalWitnessExtractor.gatedWellFormedness` (per-location read-after-write re-imposed
  by `coherencePerLocation` over colayer vars); test relocation; and corpus expectation
  correction `LB-fake-dep`/`OOTA-cycle` `(F,F,F,F,F)→(F,F,F,A,A)`. Result: 5→0 mismatches,
  113→133 matched. The earlier "well-formedness-locked, can't fix" diagnosis was about a
  WEAKEST-axiom-only patch; the fix needed the WF relaxation + corpus correction, which
  Option B delivered.

**Day 9 (2026-05-23, commit `a68ef62`): scalability sweep.** `wev.smt.bench.ParametricPrograms`
(LBChain/LBFakeChain/SBNThread/IRIWFan, n=2..16) + `wev.smt.cli.ScalabilitySweep` →
`wev-smt/eval/*.csv`. Headline: procedure scales **polynomially, not exponentially**
(SC/TSO/WEAKEST near-linear; PSO/RA polynomial; no ≥2.5×/step beyond n=4). 16 tests green.

**Day 10 (2026-05-23, commit `3882f41`): `.litmus` parser.** `wev.smt.parse.LitmusParser`
(parse / parseDirectory) for X86/PPC/ARM/RISCV/C dialects → wired `EventStructure` +
`DependencyInfo`; rf wired from the `exists` clause, identity-xor → `isSemantic=false`.
`wev.smt.cli.CorpusValidation` validates a `.litmus` dir against per-model herd7
expectations. Robustness: unknown arch / unsupported instr / malformed (line-tagged) /
empty all skip-with-warning, never crash the run. **29 tests green** (13 new in
`LitmusParserTest`). Coverage doc = `wev-smt/docs/litmus-parser-coverage.md` (paper §6.1).
**Checkpoint after Day 10: do NOT run CorpusValidation against a real herd7 corpus until
that suite is downloaded** (separate day's work).

**Day 11 (2026-05-24, commit `8e21f97`): real-corpus validation.** Swept `herd/herdtools7`
(4324 files) + `hernanponcedeleon/Dat3M` (8000 of 24722 sampled) through CorpusValidation
(per-file SolverContext+ShutdownManager, 30s/file, 64-event size guard, incremental
crash-safe CSV). **2998 files fully parsed+validated across all 5 models; headline =
hierarchy-soundness 0/2998 violations** (SC⊆TSO⊆PSO + {SC,TSO,PSO}⟹WEAKEST; even the
non-theorem RA⟹WEAKEST held — no `FFFAF` in corpus). Metric REFRAMED (approved): primary
= hierarchy-soundness, secondary = parse-coverage (24.3%), tertiary external match-rate
DEFERRED (raw .litmus carry no per-model truth; only x86_64 kinds.txt is clean and it's
AT&T-syntax, unparsed). Parser boundaries found (all coverage, NOT soundness): AArch64 MTE
`STG`/`LDG` (859), RISC-V `ori` (1686 — STOP trigger fired, narrow lexicon gap), branch
labels `L0:`/`LC00:`, AT&T x86 `movl`, full C/LKMM. Parser fix: skip pre-init header
metadata (quoted desc + `KEY=value` diy lines) — lifted herd7 parse rate. PPC/Intel-x86
best-covered (70–83%); ARM 24.5%, RISCV 0.3%. Solve ~11ms mean, p99<40ms. **LitmusCorpus
classics() grew 28→32**: added `3.2W` (FFAAA), `6.SB` (F··A), `3.LBdep-fake` (FFFAA),
`3.LBdep-real` (FFFAF — jf-coherence thin-air contribution now confirmed at 3-thread
width). AtlasReconstruct: **150/150 cells matched, 0 mismatch**; mvn test 29/29 green.
Deliverables: `eval/corpus-summary.md`, `docs/corpus-validation-findings.md` (paper §6.2),
`eval/corpus-validation-{herd7,dat3m}.csv` committed; `eval/corpus/` gitignored. Future
work (priority): strip `label:` tokens, RISC-V `ori`/`andi`/`xori`, encode fences, AT&T x86.

**Day 12 (2026-05-26, commit `adb65a7`): fence + RMW encoding.** Promoted fences/RMW from
parser-recognised-but-unencoded to first-class. NEW (additive, `com.weakest.model`):
`FenceEvent` (enum `FenceKind` FULL/ACQ/REL/ACQ_REL; passes `EventType.WRITE` sentinel,
keyed by `instanceof`) and `RMWEvent extends WriteEvent` (`readValue`+`fullFence`; atomic
read+write at ONE event id, so per-loc coherence already subsumes atomicity — explicit
`rmwAtomicity` axiom is the textbook guard). Encoder: `isReader`/`readValueOf` generalise
rf/jf/WF to RMW readers (+ self-exclusion); ppo made fence-transparent via
`nextAccessHops`/`restoresOrder` (ACQ_REL = R→∪→W is not a product → pairwise `fenceOrders`).
Parser emits FenceEvent/RMWEvent per arch (X86 MFENCE→FULL/XCHG·XADD·CMPXCHG→RMW; ARM
DMB ISH/ISHLD/ISHST + SWP/LDADD/CAS; PPC SYNC/LWSYNC/ISYNC + LWARX/STWCX; RISC-V FENCE
rw,rw/r,r/w,w + AMO*; C `atomic_thread_fence(mo)` + fetch/exchange/CAS). `LitmusCorpus`
classics **32→40** (+8: SB+mfences/2+2W+sync/IRIW+sync/RMW-as-fence/SB+rmw = FFFAA,
MP+lwsync/LB+ctrlfence = FFFFA [LB+ctrlfence is a NEW RA|WEAKEST separator],
CAS-pair = FFFFF). **AtlasReconstruct: 190/190 matched, 0 mismatch** (was 150/150).
`scalability-fences.csv` via 2 new `ParametricPrograms` families (`SBChainMfence(n)` 4n
events, `RMWChain(n)` n+1 events O(n²) atomicity); `ScalabilitySweep` parametrized by suite
arg (day-9 default untouched) + pom `exec:exec@scalability-fences`. **Fence/RMW overhead
<3× on n≤4 (worst 2.56× SBChainMfence/RA n=4)** — stop-trigger clear. 34/34 tests (29+5).
Two bugs fixed mid-pass: `relaxedPoConstraints` must skip fence-incident edges (else
fence re-imposes dropped W→W in the global witness → spurious FFFFF on 2+2W+sync);
`addFr`/`addFrLoc` need RMW self-loop guard (`wp.getId()==r.getId()`). Doc refreshed
(`litmus-parser-coverage.md` fence caveat removed, per-arch fence/RMW table added);
atlas-day12-final.txt + corpus-summary.md §Day-12 committed; root atlas CSVs + eval/logs/
gitignored. Why fences invisible to RA/WEAKEST: a seq-cst fence creates neither sync nor a
thin-air cycle, so SB+mfences stays ALLOWED there even as SC/TSO/PSO forbid.

**Day 13 (2026-05-27, commit `ccd6c90`): POPL artifact-evaluation Docker bundle.** Pure
packaging — NO `com.weakest.*`/`ConsistencyChecker` edits, 34/34 unchanged. New
`wev-smt/artifact/`: `Dockerfile` (eclipse-temurin:21-jdk-noble; **binary Maven 3.9.9 +
pip matplotlib/pandas**, NOT apt — apt-maven drags a 2nd JRE and apt-matplotlib drags
scipy/sympy/tk; lean swap → **1.34 GB**, under the 1.5 GB target, build `--provenance=false`),
`reproduce.sh` (6 steps: tests→atlas→sweep→fences→optional-corpus→plots; diffs only
DETERMINISTIC columns — verdict/match — since timing/mem/minwitness-size & the separation
atlas are machine/budget-dependent; `LC_ALL=C`), `plots/` (4 py: scalability-curves
log-log, atlas-heatmap Okabe-Ito, separation-matrix; Agg headless, PDF+PNG),
`expected-outputs/` (4 committed snapshots), `README.md`, `lib/` (**vendored** visualiser
model jar `visualising-weakest-executions-1.0-SNAPSHOT.jar` 218 KB + dependency-reduced
pom, `install:install-file`'d in image — the dep is NOT on Maven Central; `*.jar` un-ignored
+ marked `binary`). pom.xml +`exec:exec@atlas`/`@corpus-validation` (scalability ones
pre-existed). `docs/artifact-guide.md` (reviewer guide, anon contact). Root `.gitattributes`
forces `eol=lf` on reproduce.sh/Dockerfile/*.py/expected-outputs (Windows-clone autocrlf
would CRLF-break the in-container LF diffs). **Container run validated: all checks PASS in
14m44s** (<30 min target, <45 min stop-trigger): tests 34/34, atlas 190/190/0, both sweep
projections match, fence overhead 2.69× (<3×), 6 plots. Corpus step gated on `/corpus`
volume mount (optional, Reusable-badge; re-derives hierarchy-soundness=0 via awk). Build
context = wev-smt/ (`docker build -f artifact/Dockerfile .`) since the spec's `COPY
../wev-smt` can't escape context. Two corpus dirs (eval/corpus 203 MB) `.dockerignore`d.

**Day 14 (2026-05-28, commit `41db4b2`): edge-case robustness + graceful degradation (paper
§6.4).** Pure additive, NO `com.weakest.*`/`ConsistencyChecker` edits. NEW `wev.smt.validate`:
`InputValidator.validate(EventStructure, DependencyInfo)` → `ValidationReport` (errors:
po-acyclic, every-read-has-write/rf-candidate, consistent-init, po/rf/co/dep ref present
events; warning: po-total-per-thread since thread-0 init writes are intentionally
incomparable); errors throw `InvalidEventStructureException`. Wired in TWO places:
`LitmusParser` just before emitting `LitmusCase` (+11 lines), and the
`MinimalWitnessExtractor` ctor before building activation literals. By construction NEVER
fires on well-formed litmus/parametric input (corpus/atlas/sweeps validate clean — that is
why verdicts are unchanged). Resource ceilings in `MinimalWitnessExtractor` (closes runaway
cost): `wev.smt.maxEvents=256` (`MAX_EVENTS_PROPERTY`) + `wev.smt.maxVars=100000`, read
per-call, pre-flight before any solve; breach → `Optional.empty()` + INFO log ("sound under
pressure", same no-witness path callers handle). NEW `wev.smt.cli.RobustnessSweep` (478 ln,
mirrors EdgeCaseTest A–K) + pom `exec:exec@robustness` → `eval/robustness-report.txt`
(deterministic `<id> | <outcome>` col + non-det time/mem col, the latter NOT diffed); 90s
per-case cap, exits non-zero iff a case throws. `EdgeCaseTest` (11 new tests A–K) → **tests
34→45 green**. `docs/limits.md` (§6.4: validation table + 256-event rationale — LBChain(64)=192
admitted/stress-solver vs LBChain(128)=384 refused/stress-guard). **NO REGRESSION:** atlas
190/190/0; `scalability-{consistency,fences}.csv` verdict cols (1-5) **byte-identical** to
adb65a7. The ONLY re-run deltas are in budget-dependent columns reproduce.sh already drops:
`minwitness_size` flips `-2`↔`1` (-2 = probe skipped past minWitDeadline, timing), separation
`status` flips `TIMEOUT`↔`SOLVED`/`NO_SEPARATION` (which cells finish in budget). Docker:
`reproduce.sh` gained **Step 7 robustness** (between plots & summary; asserts exit 0 + 11
recorded + outcome projection == `expected-outputs/robustness-report-expected.txt`), Step 1
**34→45**; README/artifact-guide/Dockerfile bumped 34→45 + robustness/claim-C5. Image rebuilt
`wev-smt-artifact:day14` **1.34 GB**, **7-step run 15m14s, ALL PASS** (case G 20-loc/4-thread
~15.6s, well under 90s cap). 3 per-run regen outputs gitignored
(`eval/{atlas-separations,consistency-validation,robustness-report.*}` + `eval/*-stdout.txt`).
BUILD GOTCHA: `mvn -pl wev-smt` FAILS (root pom has no `<modules>`); run mvn from INSIDE
`wev-smt/` (standalone sibling project, see [[wev-project-structure]]).

**Day 15 (2026-05-28, commit `b0bfae5` on branch `feat/xor-litmus-example`, NOT pushed):
paper §4 worked example.** First project-authored .litmus triplet at NEW
`wev-smt/eval/examples/paper/` (everything else is external corpora at `eval/corpus/`):
`LB-real.litmus` (store `r+1`, isSemantic=true, WEAKEST FORBIDS), `LB-fake-xor-cycle.litmus`
(store `r^r^1` folds via XOR identity to constant 1, isSemantic=false, WEAKEST ALLOWS via
jfCoherence with sdep empty), `LB-fake-xor.litmus` (store `r^r` folds to 0 — kept with
header caveat: wired candidate degenerates to r=r=0 not the LB cycle, so WEAKEST=SAT is
trivially-SAT NOT jfCoherence-driven; documents SYNTACTIC classification only).
**Paper §4 key contrast = LB-real vs LB-fake-xor-cycle: identical structure, identical
written values, identical wired r=r=1 candidate — only isSemantic flips, only WEAKEST
verdict flips (FORBIDDEN↔ALLOWED).** `PaperExampleTest` asserts per-file isSemantic count,
program-write values, wired-rf candidate, WEAKEST verdict → **45→48 tests green**. Parser
quirk discovered + documented in commit msg + file comment: `C_WRITE_ONCE` regex `[^)]+`
value capture truncates at the inner `)`, so the literature-canonical `(r^r)|1` spelling
does NOT parse (orphans `|1)` as UNSUPPORTED_INSTRUCTION); the paren-free equivalent
`r^r^1` parses cleanly and evalConst genuinely produces 1. Additive only — no edits to
`com.weakest.*`, `ConsistencyChecker`, parser source, or the dependsReally heuristic.

Key invariants enforced by tests: `LBChain(n)/WEAKEST=FORBIDDEN` (real dep cycle) vs
`LBFakeChain(n)/WEAKEST=ALLOWED` (fake dep) at equal encoding cost; parsed
`LB/WEAKEST=ALLOWED`, `SB/SC=FORBIDDEN`, `MP/TSO=FORBIDDEN`. Constraints throughout: no
edits to `com.weakest.*` or `ConsistencyChecker.java`.

**Paper-risk mitigation deliverables (2026-05-31, on top of 41db4b2; observation-only, no
semantic-core edits):** three reviewer-risk write-ups in `wev-smt/` root.
- **risk #3 (`ablation_results.md`)** — sdep ablation via NEW `wev.smt.ablation`
  (`SdepConfig`/`AblationRun`, runtime `WEV_SDEP_MODE`): none/all-deps-semantic/current.
  Shipped detector is the only config that ALLOWS every fake-dep LB and FORBIDS every
  real-dep LB; verdict-neutral on the 200-file corpus slice (coherence-decided, not sdep).
- **risk #4 (`parser_failures.md`)** — parser-failure categorization; NEW
  `wev.smt.ablation.ParserFailureLog` captures untruncated ParseException kind+offending
  instr (CSV `note` clips at 120 chars).
- **risk #6 (`herd7_baseline.md`)** — herd7 agreement baseline. **herd7 7.58 installed
  no-sudo in WSL2 Ubuntu** (opam 2.2.1 binary→`~/.local/bin`; `unzip`/`libgmp-dev`/`pkgconf`
  via `apt-get download`+`dpkg-deb -x` into `~/.local`; `gmp.pc` repointed w/ `-Wl,-rpath`;
  `pkg-config` wrapper re-exports stripped LD_LIBRARY_PATH; opam switch 4.14.2). Compared on
  the 697 herd7-OK files, strong fragment only. **SC (sc.cat): non-ARM 106/123 agree (86%)
  — X86 42/50, PPC 51/59, C 9/9, RISCV 4/5. x86-TSO: 34/46 (74%).** ARM excluded (herd7
  errors 210/570 under sc.cat; rest are VMSA/MTE/exotic WEV-SMT flattens — parser scope, not
  model comparison). **Every comparable disagreement = WEV-SMT MORE permissive (never
  over-forbids).** Two root causes, both architecture-independent (manifest across x86/ppc/
  riscv front-ends, so NOT per-arch parse bugs): (A) **same-thread store→store order is not
  enforced** (2+2W/S family); (B) **x86 MFENCE treated as inert** under TSO.
  (CoWW/CoWR `co4`/`co10` were initially lumped here as the shakiest concern but are RESOLVED
  separately below — a co-wiring artifact, not under-enforcement.) **WEAKEST has no
  herd7 counterpart → the paper's actual contribution is NOT cross-validated.** Artifacts:
  `eval/herd7-results.csv`, `eval/herd7-wev-verdicts.csv`, `eval/herd7-filelist.txt`,
  WSL `~/run_herd7.sh`. WSL gotcha: variable refs/`/abs/paths` get eaten passing through
  `wsl -- bash -lc '…'`; use literal paths inline or run a script FILE.

**Theorem 4.3 (hierarchy preservation) by-construction proof attempt (2026-05-31,
`theorem_4_3_attempt.md`; analysis-only, NEW additive probe `wev.smt.proof.HierarchyProbe`,
no encoding edits).** Constraint sets read from `AxiomaticConsistency`: SC=acyclic(po∪rf∪co∪fr)∧CPL∧RMW;
TSO=acyclic(ppo_T∪rfe∪co∪fr)∧CPL∧RMW (ppo_T drops same-thread W→R); PSO=acyclic(ppo_P∪rfe∪co∪fr)∧CPL∧RMW∧**irreflexive(hb;eco?)**
(ppo_P also drops W→W); RA=**irreflexive(hb;eco?)**∧CPL∧RMW; WEAKEST=⟨inert guard⟩∧CPL∧**jfCoherence=acyclic(sdep∪jf)**∧RMW.
CPL(coherencePerLocation)+RMW(rmwAtomicity) textually identical across all 5. **RESULT: NOT a total
lattice — only the SC-rooted edges hold.** SC⊒TSO **PROVED** (R_TSO⊆R_SC subset); SC⊒RA **PROVED**
(hb;eco?⊆(po∪rf∪co∪fr)⁺); bonus SC⊒PSO & SC⊒WEAKEST also PROVED (SC's monolithic acyclicity entails
every model's relation), so **SC is a true top**. **TSO⊒PSO = COUNTEREXAMPLE** (verified): custom
`WR-relacq-cex` [T1: Wx=1;Ra;W_rel b=1 | T2: R_acq b;Wx2; co(x): init→Wx2→Wx] gives (F,**A**,**F**,F,A)
— TSO allows (W→R Wx→Ra dropped, Wx co-maximal so no R_TSO out-edge), PSO forbids via hb;eco
(Wx→po→Ra→po→Wb→sw→Rb→po→Wx2, eco=co(Wx2,Wx)); PSO base⊆R_TSO so forbidding is solely the hb;eco term.
Plus `2+2W` reverse (PSO=A,TSO=F) ⇒ **TSO/PSO incomparable**. **RA⊒WEAKEST = COUNTEREXAMPLE** (verified):
`LBdep-real`/`LBdep-addr`/`3.LBdep-real` give (F,F,F,**A**,**F**) — RA allows (relaxed reads, no sw, no
hb;eco cycle), WEAKEST forbids via jfCoherence (semantic-dep LB cycle); plus `CO-MP`/`MP-relacq` reverse
(RA=F,WEAKEST=A) ⇒ **RA/WEAKEST incomparable**. HierarchyProbe classics scan: SC⊒TSO/SC⊒RA 0/40 violations,
RA⇒WEAKEST 3 violations. **Why empirical 0/2998 missed it: corpus lacks the two witnessing shapes
(W→R+release/acquire+coherence-reversed co; semantic-dependency LB).** §4.7 rewrite = empirical with proved
SC-rooted subset + two known counterexample shapes. Confirms the project's own "RA⟹WEAKEST is a non-theorem"
note and extends it: TSO⟹PSO is ALSO a non-theorem; both intermediate weakening edges add orthogonal axioms
(PSO's RC11 hb;eco, WEAKEST's jfCoherence) not present in the model above them. Connects to herd7_baseline:
the TSO⊒PSO break is the same encoding-TSO under-approximation (W→R/store-buffer-FIFO not enforced).

**co4/co10 same-location coherence disagreement RESOLVED (2026-05-31,
`co4_co10_diagnosis.md`; read-only probe `wev.smt.proof.ParseDump`, no parser/core edits).**
The load-bearing §6 risk (WEV ALLOWS PPC `co4`/`co10` where herd7 FORBIDS under SC) is
**NEITHER (i) parser-addressing NOR (ii) coherence-axiom under-enforcement — it is a benign
coherence-order WIRING artifact.** (i) ruled out: both stores resolve to loc=x (PPC
`stw rN,0(r5)` with r5=x aliases correctly). Root cause: the loader fixes `co` in the writes'
SOURCE order, not from the `~exists`/`exists` queried final value — co10 wires
x=[init,W1,W2] (co AGREES with po W1→W2) = a coherent execution → correctly SAT/ALLOWED.
herd7 asks "is the bad state reachable?"; WEV asks "is THIS wired exec consistent?" — different
questions. (ii) ruled out DECISIVELY: `LitmusCorpus.buildCoWW` (same 2 stores, REVERSED co
W2-before-W1 against po) is FORBIDDEN under all 5 models incl WEAKEST/SC — `coherencePerLocation`
is sound (per-loc layer makes po-loc and reversed co contradictory). Minimal C reproducer
`eval/examples/diag/CoWW-min.litmus` (`exists(x=1)`, two po-ordered stores) reproduces ALLOWED
in SUPPORTED syntax but for the wiring reason. **Not a soundness bug; does not block
submission.** §6 footnote = loader wires co in source order vs from exists target; this is why
the Co* family systematically disagrees (their forbidden outcome lives in co, which the loader
derives syntactically, unlike MP/SB/LB whose outcome is wired via rf from the exists clause).

**§7 related-work verification pass (2026-06-01, `section7_drafts_v2.md`; verify-only, no
semantic-core edits).** Verified all 11 §7 paragraphs against the actual source PDFs in `D:\`
(pdfminer; `pdftoppm` unavailable). PDF↔paper map: `3290381`=Raad (POPL'19 Art.68),
`3290382`=IMM/Podkopaev (Art.69), `3290383`=Weakestmo/Chakraborty-Vafeiadis (Art.70),
`3062341.3062352`=RC11, `3009837.3009850`=Promising, `2618128.2618134`=Boehm-Demsky,
`2627752`=Herding Cats, `cav2019`=Dat3M, `3314221.3314609`=GenMC, `3498711`=TruSt,
`c_concurrency_challenges`=Batty. Corrections applied: RC11 (drop "same location" — §2.1 says
unsoundness is between DIFFERENT locations under mixed SC/non-SC), Dat3M (2-orders-of-magnitude
speed-up is vs unoptimised-Dartagnan+Herd, "comparable to CBMC", "better than Nidhugg"), IMM
(RISC-V IS a proven target per Fig.1; `ar=rfe∪bob∪ppo∪detour∪psc` so softened), Herding Cats
("31 anomalies" restored). Verbatim-confirmed: GenMC Remark 1, Batty Theorem 2, Boehm-Demsky
dependence quote, IMM footnote 2, RC11 §2.3 `acyclic(sb∪rf)`. **TWO STRUCTURAL GAPS:
Weakestmo and Raad have NO paragraph in `section7_drafts.md`** despite Weakestmo being the
nearest neighbour (shares event-structure+`jf` machinery, source of the "WEAKEST" model name) —
drafted both fresh, flagged Weakestmo absence as CRITICAL §7 risk. SMT-based-reasoning paragraph:
added short standalone anchored on Dat3M.

**Batty §7 "forbids both" claim EMPIRICALLY CONFIRMED (2026-06-01).** Ran the two §4 control
examples `eval/examples/paper/LB+ctrldata+ctrl-{double,single}.litmus` through the frozen checker
(`wev.smt.proof.ParseDump`): **both FORBIDDEN under WEAKEST** (also SC/TSO/PSO; RA=allow,
consistent with RA/WEAKEST incomparability above). The two parsed candidates are extensionally
identical (Theorem 2's setup). `AblationRun` none-vs-current localises the cause: `current` →
both FORBIDDEN sem=2; `none` (ctrl stripped from sdep) → both ALLOWED sem=0, so the forbidding is
driven precisely by the conservative read→write ctrl-edge inclusion in `sdep_impl`, exactly as §7
states. Caveat: parser FLATTENS double- and single-branch sources to ONE identical event structure
(can't represent both-branches-write distinctly) — benign for the claim, itself an instance of
Theorem 2. §7 risk downgraded MAJOR→RESOLVED. No encoding/parser edits.

Plans/analysis: `wev-smt/docs/pass-3-plan.md`, `wev-smt/docs/encoding-rootcause-analysis.md`.
See [[wev-project-structure]], [[javasmt-z3-native-setup]].
