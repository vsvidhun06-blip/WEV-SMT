# FSEN 2027 #41: fourth archive (taint-linear theory and code-base screen)

Built on 2026-11-12 for the revised manuscript "Read-Restricted Dependency Summaries Do Not
Compose Exactly". The paper calls this "the fourth archive". It does not replace the base
artifact, the add-on or the supplement; it adds two things.

1. **Isabelle session `WEV_SMT_TL`** (paper Thm. 5(e), Table 4).
2. **The code-base screen** (paper §4 "Concurrency code bases", App. D "Code-base screen").
   It is an unmodified copy of the real-code investigation directory
   `realcode-20261110T235600` (2026-11-10 to 2026-11-11).

The work was done with AI assistance (Anthropic's Claude, through Claude Code), as the
paper's "Use of Generative AI" section states.

## Layout

| path | content |
|---|---|
| `isabelle/base/` | Sessions `WEV_SMT` and `WEV_SMT_PwT`. Byte-identical to `isabelle/` of `tacas2027-4549-artifact-corrected-v1.zip` (sha256 `45e434df…`). |
| `isabelle/addon/` | Session `WEV_SMT_Rev`. Theories and ROOT are byte-identical to `formal/` of `fsen27-41-addon.zip` (sha256 `dfd70eec…`). `CHECK-RESULT.txt` was written by the 2026-11-12 build. |
| `isabelle/tl/` | Session `WEV_SMT_TL`. `PwT_TaintLinear.thy` and `TL_Check.thy` are byte-identical to `realcode/theory/tl/`. `TL_Ancestry.thy` and this ROOT were added on 2026-11-12. `CHECK-RESULT.txt` and `ANCESTRY-RESULT.txt` were written by the build. |
| `isabelle/build-WEV_SMT_TL.log`, `isabelle/build-meta.txt` | Log of the 2026-11-12 clean build of all four sessions (exit 0). |
| `realcode/` | Unmodified copy of the real-code investigation, minus Python bytecode caches (`__pycache__`). |
| `external/p1a-linux-src-rows.csv` | Rows of the Linux 7.3 source-level screen. The verifier reads it; it was outside the investigation directory. |
| `external/baseline-wev-smt-fsen27.tex` | Manuscript source (sha256 `b555e516…`) that the verifier checks was left untouched. |
| `verify/realcode-verify-report-20261112.txt` | Verifier output, run on 2026-11-12 in the original location: 43 of 43 pass. |
| `tools/verify_realcode_relocated.py` | Runs the unmodified verifier against this copy by replacing its three absolute paths in memory. |
| `tools/check_manifest.py` | Checks `MANIFEST.sha256`. |

## Checks

- **Manifest.** `python -I tools/check_manifest.py` exits 0.
- **Isabelle** (Isabelle2024):

  ```
  isabelle build -c -d isabelle/base -d isabelle/addon -d isabelle/tl \
      WEV_SMT WEV_SMT_PwT WEV_SMT_Rev WEV_SMT_TL
  ```

  It should exit 0, and the build should rewrite the result files as follows:
  - `isabelle/tl/CHECK-RESULT.txt` begins `oracles over 31 theorems: none`.
  - `isabelle/tl/ANCESTRY-RESULT.txt` says `ancestry: OK`, and its control line lists
    `WEV_SMT.WEV_SMT_Defs`.
  - `isabelle/addon/CHECK-RESULT.txt` says `ancestry: OK` and `oracles over 73 theorems: none`.
- **Code-base screen.** `python -I tools/verify_realcode_relocated.py` ends with
  `SUMMARY: 43 claims, 43 PASS, 0 FAIL`. It needs Python 3 and the standard library only.

## Not included

- **The upstream corpora and the compiled bitcode.** `realcode/REAL-CODE-SEARCH.md` pins them
  by commit or tarball hash, and `realcode/tools/fetch_corpora.sh` fetches them. Re-running the
  screen needs clang 20.1.2 (zig 0.15.2), Python with z3-solver, and several hours. It was not
  re-run for this archive.
- **No independent re-execution.** The verifier re-checks the reports' numbers against the
  archived outputs; it does not re-execute the screen.

## Caveats

- Files under `realcode/` contain absolute paths of the machine where they were produced.
- The primary record of the screen is `realcode/REAL-CODE-SEARCH.md`, together with
  `SCIENTIFIC-VERDICT.md`, `COMPILER-RESULTS.md`, `SEMANTIC-VALIDATION.md` and
  `protocol/`. Items not covered by the frozen protocol or an amendment are labelled
  EXPLORATORY there.
- The arguments that the 52 composed cancellations change no verdict are proof sketches.
  They are not model-checking results.
