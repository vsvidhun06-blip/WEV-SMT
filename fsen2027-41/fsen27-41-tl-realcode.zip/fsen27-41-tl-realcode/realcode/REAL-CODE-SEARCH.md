# Real-code search for composition-dependent verdict differences (FSEN 2027 #41)

Pass: `realcode-20261110T235600` (2026-11-10T23:56Z to 2026-11-11). Protocol: `protocol/PROTOCOL.md`, frozen
2026-11-11T00:09:01Z, sha256 `bd907b34…` (re-checked at the end of the pass: unchanged). Amendments 1 to 9 are in
`protocol/AMENDMENTS.md`. Every item not covered by the protocol or an amendment is labelled EXPLORATORY.

## Answer

No authentic upstream program in the screened corpora contains a composed cancellation that changes a weak-memory
verdict. Stage A finds 52 unique FAKE-COMPOSED sites (composed cancellations that the closure keeps) in 8 distinct
source corpora (10 builds). None passes Stage D. Every one of them is a **control** (50) or **address** (2) sink. In
the paper's own fragment, data dependencies into a marked store, there are **0 composed cancellations among 501
real-code sites** (SLI view; 497 REAL, 3 FAKE-LOCAL, 1 LARGE).

The cancellations do exist at the edge level. clang 20.1.2 removes every examined Stage-C-passing site at -O1 and
above (`COMPILER-RESULTS.md`). They never matter for a verdict, for three structural reasons:
1. the source access is seq_cst, so the dependency is redundant;
2. a REAL dependency of the same load dominates the fake one;
3. the site exists only in a stale test-harness duplicate.

The remaining 44 sites are thread-local or single-threaded test code.

## 1. What was searched

Bitcode: clang 20.1.2 (zig 0.15.2), `-O0 -Xclang -disable-O0-optnone -fno-sanitize=all -g`, x86_64-linux-gnu.
Two program views per module (`irscreen_v9.py: load_module`):
- **SL**: per-function SROA, no inlining.
- **SLI**: functions of at most 400 instructions (except `main`) are force-inlined first, then SROA. SLI is the
  view in which cancellations created by inlining a helper become visible.

| corpus | ref (commit / tarball sha256) | modules compiled | screened by v9 (SL+SLI jobs) | status |
|---|---|---:|---|---|
| ck | 0.7.2 `981e1429` | 152/155 | 152 + 152, all exit 0 | complete |
| libvsync | v4.3.0 `b8f1dd52` | 182/235 | 182 + 182, all exit 0 | complete |
| liburcu | v0.15.7 `bbc6bc94` (builtins config) | 77/99 | 77 + 77, all exit 0 | complete |
| liburcu-vol | same source, `URCU_DEREFERENCE_USE_VOLATILE` | 77/99 | 77 + 77, all exit 0 | complete (duplicate source) |
| mimalloc | v3.6.1 `56dc5eb8` | 16/17 | 16 + 14 (2 SLI MEMOUT) | complete except 2 SLI jobs |
| dat3m benchmarks | 4.4.1 `d8de5e8e` | 137/152 | 137 + 137, all exit 0 | complete |
| genmc tests | v0.20.0 `fab5bba7` | 655/1,062 | 655 + 655, all exit 0 | complete |
| linux-7.3 radix-tree harness (K1) | tarball `87363c24…` | 21/21 | 21 + 18 (1 MEMOUT, 2 TIMEOUT) | complete except 3 SLI jobs |
| linux-7.3 radix-tree harness (K2) | same source, 2nd config | 21/21 | 21 + 18 (1 MEMOUT, 2 TIMEOUT) | duplicate source |
| linux-7.3 vma harness (K1) | same tarball | 2/2 | 2 + 2 | complete |
| nidhugg tests | v0.3.1 `942056f9` | 8,257/8,261 | **not screened** (memory) | NOT SCREENED BY v9 |
| linux-7.3 vma harness (K2) | same tarball | 2/2 | **not screened** (memory) | NOT SCREENED BY v9 |
| linux-7.3 tools/lib/bpf ringbuf | same tarball | 0/1 (`libelf.h` not found) | — | setup failure |
| DPDK | v26.07 `93ecf13a` | 0/46 (v6 flags); v9 rebuild not run | — | NOT SCREENED |
| LLVM InstCombine/other .ll tests | llvmorg-22.1.0 | v6 screen only (superseded) | — | NOT SCREENED BY v9 |
| GCC testsuite | 15.2.0 | 2,659/5,095 | not screened by v9 | NOT SCREENED BY v9 |

Under Amendment 9, unscreened corpora are reported but never counted. Their v6 screens, where they exist, used a
superseded tool (v6 had loop and control-gate defects, fixed in v7/v9) and are not used.

Also run:
- **P1a**, a source-level screen of all of linux-7.3 (`tools/srcscreen.py`, sha `e649c3ec…`, controls 15/15 PASS).
  It covered 65,835 files and 15,556 marked-store sinks. Of 573 load→store pairs (96 multi-operator), **all are
  REAL**. Limitation: the screen parses unpreprocessed C. Of the 8,386 files containing both marked loads and
  marked stores, 6,707 have at least one tree-sitter parse error (macro-heavy code). They are still screened through
  error recovery, but functions inside error regions can be missed (`logs/p1a-linux.log`, STATS line).
- **P5**, author-written transcriptions of the kernel-documentation examples (`inputs/p5/P5-kernel-docs.c`, cited
  line by line; NOT upstream code). These are the only documented composed case:
  - `x-(uintptr_t)x` (Documentation/RCU/rcu_dereference.rst:68-72) is FAKE-COMPOSED;
  - `r1*0` and `q%1` are FAKE-LOCAL;
  - the rest are REAL.

  v7 and v9 give identical classes (`outputs/p5-kerneldocs-v9-*`).

## 2. Screening method (Stage A)

`tools/irscreen_v9.py` (sha `b50a95c4…`; Amendment 7):
- **Composed test (mode C analogue):** self-composition in QF_BV at the exact IR widths, over the backward slice
  from the sink operand to the marked load L. Calls, non-L loads, floating point and inline asm are opaque but
  shared uninterpreted functions. Control-gated phis are exact `ite`; def-use cycles are UFs over their external
  inputs.
- **Closure test (mode B analogue):** the same oracle per instruction, followed by reachability.
- **Classes:** REAL; FAKE-LOCAL (one instruction cuts every path); FAKE-COMPOSED (constant, but the closure keeps
  it); UNKNOWN (Z3 5 s); LARGE (slice over 300).
- **Controls:** pass identically across v3/v5/v6/v7/v9; there are loop and gate controls for v7/v9.

The screen is sound for FAKE and conservative for REAL. It under-approximates what clang cancels: two REAL-classed
libvsync sites and one REAL-classed liburcu site are also folded by clang (`COMPILER-RESULTS.md`).

### Stage A counts (sites, deduplicated by innermost L and S location; `search/stageA/STAGEA-V9-BYKIND-20261111T120555Z.txt`)

Totals over the 8 distinct source corpora (duplicate builds liburcu-vol and radix-K2 excluded):

| view | sink kind | sites | REAL | FAKE-LOCAL | FAKE-COMPOSED | UNKNOWN | LARGE |
|---|---|---:|---:|---:|---:|---:|---:|
| SL | D (data → marked store; the paper's fragment) | 392 | 390 | 2 | **0** | 0 | 0 |
| SL | P (plain store, exploratory) | 263 | 263 | 0 | 0 | 0 | 0 |
| SL | A (address) | 341 | 341 | 0 | 0 | 0 | 0 |
| SL | K (control) | 1,534 | 1,534 | 0 | 0 | 0 | 0 |
| SLI | D | 501 | 497 | 3 | **0** | 0 | 1 |
| SLI | P | 416 | 393 | 2 | 0 | 0 | 21 |
| SLI | A | 930 | 815 | 6 | 2 | 0 | 107 |
| SLI | K | 5,559 | 5,398 | 1 | 50 | 6 | 104 |

Per corpus (SLI view, all kinds; `search/stageA/STAGEA-V9-TABLE-20261111T120043Z.tsv`):

| corpus | sites | FAKE-COMPOSED | FAKE-LOCAL | LARGE+UNKNOWN |
|---|---:|---:|---:|---:|
| ck | 853 | 4 | 10 | 0 |
| libvsync | 3,038 | 45 | 0 | 18 |
| liburcu | 571 | 1 | 0 | 3 |
| mimalloc | 35 | 0 | 0 | 0 |
| dat3m | 625 | 0 | 0 | 0 |
| genmc | 1,177 | 0 | 2 | 0 |
| radix-tree (K1) | 1,076 | 1 | 0 | 218 |
| vma (K1) | 31 | 1 | 0 | 0 |

These counts are not prevalence estimates. The corpora are a purposive sample of concurrency libraries, verifier
test suites and kernel test harnesses, and sites of shared headers are counted once per corpus.

**Undecided share.** LARGE/UNKNOWN is significant in the radix-tree harness (218/1,076 SLI sites) and in libvsync
(18). They are undecided, not REAL. For the paper's D fragment only 1 SLI site is undecided.

## 3. Stages B to E (all unique FAKE sites; `CANDIDATE-INVENTORY.csv`, 64 rows)

There are 12 FAKE-LOCAL sites (ck hclh validate test, GenMC litmus `LB+fr-fr-data+data`). Stage C excludes them by
class, because the closure already removes them.

FAKE-COMPOSED (52 unique sites):

| stage | in | pass | excluded (reason) |
|---|---:|---:|---|
| B concurrency relevance | 52 | 8 (10 under Arm-architectural ctrl) | 40 libvsync vatomic unit tests (stack object, single-threaded `main`); 2 ck address sinks (stack `cpu_set_t`); 2 ck control sinks (compiler-sense: guard only the stack write; they pass B under architectural ctrl) |
| C composition relevance | 8 (10) | 7 (9) | 1 radix-tree `radix_tree_replace_slot` (vacuous: `node = NULL` puts L on a dead path, so this is not a value cancellation) |
| D outcome relevance | 7 (9) | **0** | 5 libvsync library sites (bitmap.h:164/303, ebr.h:248, atomicptr_stamped.h:86/87): seq_cst source, dependency redundant; (2 ck control sinks: seq_cst RMW source); 1 liburcu rculfhash.c:635@2128: fake branch dominated by REAL branches on the same load; 1 kernel vma harness dup.h:1532: stale harness duplicate, the kernel has no cancellation |
| E independent validation | 0 | — | not reached; compiler differentials were run anyway as edge evidence (C) |

Stage C requires the memory caveat (PROTOCOL §3.1) to be cleared for slices flagged memory-opaque. Three
Stage-C sites carry the flag: K05 rculfhash and K06/K07 stamped. All three were cleared mechanically: each sink
stays constant when every opaque node is unshared between the two copies (`tools/opaque_probe_v1.py`,
`outputs/opaque-probe-20261111T122327Z/`). The other four Stage-C sites are not flagged.

The Stage-D redundancy rule ("L ordering ≥ acquire ⇒ the dependency is redundant") was written in `CHECKPOINT.md`
(S4c, 00:55Z) before any triage, not in the frozen protocol. Its justification is per model:
- AArch64: `[A];po ⊆ bob`, and seq_cst loads and RMWs compile to LDAR / LDADDAL / LDAXR.
- x86-TSO: no load→store reordering.
- RC11: `acyclic(po ∪ rf)` holds regardless of dependencies.

The three sites that pass Stage C with a relaxed or volatile source are the most informative. The 12-item analysis
is in `SEMANTIC-VALIDATION.md`.
- **liburcu `rculfhash.c` (relaxed load of `resize_target`).** `max(new_size, 1)` is followed by `if (!x)` in an
  inlined helper, a range restriction. It fails Stage D because the REAL branches at :2155 and :2157 on the same
  value dominate the fake branch. clang removes the fake branch at -O1 and above and keeps the dominating ones.
- **linux-7.3 VMA test harness.** The harness copy of `mlock_future_ok` (dup.h:1527) still takes `vm_flags_t`,
  while the kernel's (mm/mmap.c:231) now takes `bool is_vma_locked`. A 0/1 value masked with `VM_LOCKED` (bit 13)
  is always 0. This is a latent harness inconsistency with no observable effect, because the harness's `capable()`
  stub returns true. It is not a weak-memory finding. Nothing was reported upstream.
- **radix-tree.** Vacuous; see the table.

## 4. Theory link (prespecified checks, Amendment 8)

The taint-linear census (`search/tlcensus-join-20261111T114530Z/CENSUS-REPORT.md`) joins 124,756 screen pairs row
for row (86,856 excluding duplicate builds) with a forward taint classification. That classification is the LLVM
analogue of the mechanised criterion `tl_exact` in `theory/tl/PwT_TaintLinear.thy`.

The prespecified consistency check passes in all 10 builds:
- 0 pairs in the fragment are classed FAKE;
- every FAKE-COMPOSED pair is TU (outside the fragment).

See `THEOREM-OPPORTUNITIES.md`.

## 5. Prespecified vs exploratory

- **Prespecified:** corpora P1–P5 and Stages A–E (PROTOCOL.md); the counting units (Am. 2); resource guards
  (Am. 3); tool fixes v5/v6/v7/v9 (Am. 1, 4, 6, 7, each before re-screening); the census criterion and checks
  (Am. 8); census scope under memory limits (Am. 9 + addendum, fixed before results).
- **Exploratory:**
  - the P sink class;
  - the libvsync and liburcu compiler differentials (the v2 libvsync plan was written before its runs; see its
    PLAN.md);
  - the genuine-level re-runs of the recovery family and compiler sources;
  - the per-corpus in-fragment shares and TU-origin distributions;
  - `tl_plus`;
  - the side observations (vma harness duplicate, ck hclh include order).

## 6. Negative and superseded results (all kept)

- Screens and tools:
  - v1/v2 screens and v4/v8 tools are broken; they are kept and never used.
  - The v3/v5/v6/v7 Stage-A screens are superseded by v9.
- Compiler runs:
  - compiler differential v1 (`outputs/compdiff-libvsync-20261111T013718Z`) is confounded by zig cc's
    `-O1/-O2/-O3 → -DNDEBUG -O2` mapping (CONFOUNDED-READ-FIRST.md);
  - the first family genuine-level attempt (`outputs/family-true-levels-20261111T115312Z`) had unmatched flags
    (NOT-USED.txt).
- Census:
  - census runs killed for memory before Amendment 9 (logged in `logs/run_tl_A.log`; empty directories kept);
  - `tl_plus` gains at most 23 rows per corpus (NEGATIVE).
- Dat3M was not built: 0.26 GB RAM was available, and no candidate reached Stage E.
- Unscreened corpora are listed in §1.
