# Theorem opportunities (alternative path: stronger theory)

## 1. Mechanised in this pass: the taint-linear exactness theorem (T1)

**Files.**
- `theory/tl/PwT_TaintLinear.thy` (sha256 `8e1c0100fed2d814…`), session `WEV_SMT_TL`.
- Its parent `WEV_SMT_Rev` is built from **copies** of the base and add-on theories
  (`theory/{base-isabelle-copy,addon-formal-copy}`, hashes in `COPIES.sha256`). The originals are untouched.

**Build.** Clean `isabelle build -c`, BUILD_EXIT=0. `TL_Check` reports 31 facts and **no oracles**
(`theory/tl/CHECK-RESULT.txt`; logs in `theory/logs/`; failed earlier attempts are kept as `*.attemptN.thy.txt`).

**Setting.** This is the paper's straight-line BV32 programs (`prog` = list of `(reg, expr)`), with
`prog_dep P x y` (semantic dependency: y's final value varies with x's initial value) and `vdep P y` (the closure
of exact per-instruction summaries: `non_constant e r` at every step).

**Definition (three-class forward taint from a source x).** A step `z := e` reading tainted registers gets class:
- **TI** if it reads exactly one tainted register r, r is TI, and e is injective in r (`inj_in e r`; side inputs
  arbitrary);
- **TN** if it reads exactly one tainted register r, r is TI, and e is *uniformly* non-constant in r
  (`unc e r`: for every state there are two values of r giving different results);
- **TU** otherwise (≥ 2 tainted reads, a TN input, or a step that is non-constant only for some side values).

**Theorems.**

| name | statement |
|---|---|
| `taint_sound` | TI or TN at y ⇒ `prog_dep P x y`; untainted ⇒ ¬`prog_dep P x y` |
| `tl_exact` | if y does not end TU, then `prog_dep P x y ⟺ x ∈ vdep P y` (the closure is exact) |
| `tl_frag_exact` | if no register ever becomes TU, the closure is exact for every target |
| `sri_exact_via_tl` | the paper's `vdep_exact_sri` (every step reads ≤ 1 register and is injective in it) re-derived as a corollary |
| `tl_needs_linear` | correlation is necessary: `cancel2` (every step injective in each input, two tainted reads) ends TU, and the closure is inexact there |
| `tl_needs_full` | range restriction is necessary: `x & 1` is uniformly non-constant but not injective, so `maskP` (`x&1`, then `&2`) ends TU and the closure is inexact |
| `tl_needs_uniform` | side-input annihilation is necessary (new witness): `annP = [u := 0; y := x * u]`, where `x*u` is non-constant in x but not uniformly, so `x ∈ vdep` but ¬`prog_dep` |

Sufficient-condition lemmas for automation: `inj_in_add_side`, `inj_in_sub_side(')`, `inj_in_xor_side`,
`inj_in_un`, `inj_in_imp_unc`, `unc_and_num` (`c ≠ 0`), `unc_mul_num` (`c ≠ 0`), `unc_eq_side`.

**What is stronger than the paper.**
- The paper proves exactness only for SRI programs, where every step reads at most one register *at all* and is
  injective in it.
- `tl_exact` constrains only the steps that read the *tainted* value. They may read any number of untainted side
  inputs, and the last non-injective step may be any uniformly non-constant operation: a mask with a non-zero
  constant, a multiplication by a non-zero constant, an equality test against a side input.
- The three necessity theorems show that each hypothesis of the criterion (single tainted read, injectivity before
  the last step, uniformity) is needed. Each failure mode is exactly one of the three cancellation mechanisms seen
  in the constructed family and in real code: correlation (`x-(uintptr_t)x` in the kernel RCU docs), range
  restriction (all 7 Stage-C real sites), and side-input annihilation.
- In real code the mechanisms are not equally common. In the census, **0 of the 282 FAKE-COMPOSED pairs** have a
  correlation (reconvergence) origin anywhere in their slice. Their origins are range restriction (TN input),
  side-input non-uniformity, or phis/cycles behind which the manual analysis again finds range restriction
  (`max`, CAS-loop `max_get`). The correlation pattern that the paper's examples and the kernel documentation
  emphasise does not occur among the real composed cancellations found.

**What it is not.**
- It is a sufficient condition, not a characterisation.
- It is straight-line (no phis or loops) and BV32 only.
- It is a modest generalisation. A reviewer may call it the natural extension of SRI. Its value is that it is
  mechanised, has matching necessity witnesses, and is tested on real code (§2).

## 2. Empirical test of the theorem on real code (prespecified, Amendment 8)

`search/tlcensus-join-20261111T114530Z/CENSUS-REPORT.md` applies a multi-width LLVM analogue of the criterion. The
analogue is NOT mechanised; Z3 decides `inj`/`unc` per instruction with free side operands. It covers every pair
enumerated by the v9 screen: 124,756 joined pairs, 86,856 excluding duplicate builds.

**Prespecified consistency check: PASS in all 10 builds.**
- 0 pairs in the fragment (TI/TN) are classed FAKE-LOCAL or FAKE-COMPOSED by the independently implemented
  self-composition screen.
- Every FAKE-COMPOSED pair is TU.

This is a falsifiable prediction of `tl_exact`, checked against a different oracle on real code.

**In-fragment share, exploratory.** It varies widely. The SLI raw in-fragment shares are genmc 51.0%, dat3m 43.8%,
mimalloc 22.5%, libvsync 21.2%, ck 12.5%, liburcu 3.5%, and 0.0% for both kernel harnesses.
- Pairs leave the fragment mostly for structural reasons (loops, control merges, memory, calls): 85.7% of pooled
  SLI pairs. Loops and control merges alone (closest origin `cycle` or `phi`) account for 97.7% of these structural
  exits, i.e. 62,793 of the 74,950 pooled SLI pairs (83.8%).
- Semantic reasons (correlation, range restriction, annihilation) account for 4.8% of pooled SLI pairs. Per corpus
  the share runs from 0.4% (liburcu) to 20.7% (ck), with one outlier of 65.4% in the 191-pair vma harness.

**Consequence.** The straight-line theorem certifies exactness for a corpus-dependent minority of real pairs. Its
reach is limited by control flow, not by the cancellation mechanisms it excludes.

## 3. Opportunities not mechanised (ranked by value for the paper)

**O1. Verdict-irrelevance of composed cancellations (from the real-code triage). Recommended if any further
theory is added.** The 7 real sites that pass Stages A–C are all verdict-irrelevant for one of two structural
reasons. Both can be stated and proved in an event-graph model with `po`, `rf` and dependency relations.
- **(a) Ordered source.** If L is an acquire (or stronger) read and the model satisfies `[Acq];po ⊆ ord` (Arm
  `bob`, x86-TSO, LKMM acquire), then for any two dependency summaries D ⊆ D' from L, the consistency verdicts
  under `acyclic(ord ∪ D ∪ rf)` and `acyclic(ord ∪ D' ∪ rf)` coincide. Closure vs composition is then irrelevant.
  Proof sketch: every D'-edge from L is already in `ord`.
- **(b) Dominated control dependency.** If every path from L to a fake branch b_F passes a branch b_R whose
  condition truly depends on L, then `ctrl` computed with or without b_F relates L to the same events. Every event
  po-after b_F is po-after b_R. Verdicts coincide.

Together with "data sinks only" (N2), these give a formal scoping statement: closure vs composition can change a
verdict only for a relaxed source whose cancelled dependency is not dominated by a real dependency of the same
load. That matches the negative empirical result. Effort: moderate. The existing Isabelle development has an event
bridge (`PwT_EventBridge.thy`) but no `ctrl`/`po` dominance model, so (b) needs new definitions; (a) is close to a
one-line set inclusion once the model is fixed.

**O2. A control-flow extension of `tl_exact`.** Exits through loops and phis dominate: 83.8% of pooled SLI pairs
(62,793 of 74,950).
A gated-SSA version, with phis as `ite` over gate conditions as the v9 screen already encodes them, would extend
the certified fragment. This is substantial: it needs gated SSA semantics in Isabelle. High value for coverage, low
value for the significance question.

**O3. `tl_plus` (a TN value followed by an injective step stays TN).** It is sound by inspection, since injective
maps preserve non-constancy. The census shows it gains at most 23 rows per corpus (pooled SLI: 63 of 74,950).
NEGATIVE: not worth mechanising.

**O4. A multi-width/LLVM version of the theorem (to mechanise the census's analogue).** It is mostly
book-keeping; low novelty.

## 4. Assessment for outcome category B

T1 is a genuine, mechanised strengthening of the paper's exactness result. It has matching necessity witnesses
and a prespecified real-code test that passes. It improves the theory side of the paper. It is incremental, not a
new characterisation, and it does not by itself answer the practical-significance objection. Category B is met
modestly. O1 is the theory step that would most directly convert this pass's negative empirical result into a
precise, citable statement.
