/* P5 TRANSCRIPTIONS (author-written C renderings, NOT upstream code) of dependency examples published in the
 * Linux v7.3 documentation. Each function cites the source file and line of the example it transcribes.
 * READ_ONCE/WRITE_ONCE follow the kernel's volatile-access definition (include/asm-generic/rwonce.h). */
#include <stdint.h>
#define READ_ONCE(x) (*(const volatile __typeof__(x) *)&(x))
#define WRITE_ONCE(x, v) (*(volatile __typeof__(x) *)&(x) = (v))
#define MAX 1

int x, y, b;
char *gp;
struct foo { int a; };
struct foo *gfp;
struct foo default_foo;

/* tools/memory-model/Documentation/explanation.txt:494-497 ("purely syntactic" dependency) */
void p5_mul0(void) { int r1 = READ_ONCE(x); WRITE_ONCE(y, r1 * 0); }

/* Documentation/RCU/rcu_dereference.rst:68-72: avoid "(x-(uintptr_t)x)" for char* pointers */
char p5_cancel(void) { char *p = READ_ONCE(gp); char *q = p - (uintptr_t)p; return READ_ONCE(*q); }

/* Documentation/RCU/rcu_dereference.rst:74-77: "p+a-b" is safe (value still depends on p) */
char p5_pab(int a, int c) { char *p = READ_ONCE(gp); char *q = p + a - c; return READ_ONCE(*q); }

/* Documentation/memory-barriers.txt:798-812 and tools/memory-model/Documentation/control-dependencies.txt:123-133:
 * if (q % MAX) with MAX == 1 */
void p5_mod1(void) { int q = READ_ONCE(x); if (q % MAX) WRITE_ONCE(b, 1); else WRITE_ONCE(b, 2); }

/* tools/memory-model/Documentation/control-dependencies.txt:166-168: if (q || 1 > 0) */
void p5_or_true(void) { int q = READ_ONCE(x); if (q || 1 > 0) WRITE_ONCE(b, 1); }

/* tools/memory-model/Documentation/control-dependencies.txt:158-161: identical stores in both legs */
void p5_same_store(void) { int q = READ_ONCE(x); if (q) WRITE_ONCE(b, 1); else WRITE_ONCE(b, 1); }

/* Documentation/RCU/rcu_dereference.rst ("EXAMPLE WHERE THE COMPILER KNOWS TOO MUCH"): after p == &default_foo the
 * compiler may use &default_foo instead of p, so p->a no longer depends on the load (path-sensitive) */
int p5_cmp(void) { struct foo *p = READ_ONCE(gfp); if (p == &default_foo) return READ_ONCE(p->a); return 0; }
