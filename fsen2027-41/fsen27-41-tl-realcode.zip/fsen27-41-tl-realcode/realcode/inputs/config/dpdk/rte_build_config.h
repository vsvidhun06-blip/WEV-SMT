/* Author-written stand-in for meson's rte_build_config.h (DPDK v26.07, x86_64 defaults from config/meson.build and
   config/x86/meson.build; enable_stdatomic=false, so RTE_ENABLE_STDATOMIC undefined). NOT upstream. */
#ifndef RTE_BUILD_CONFIG_H_STANDIN
#define RTE_BUILD_CONFIG_H_STANDIN
#define RTE_ARCH "x86_64"
#define RTE_ARCH_X86 1
#define RTE_ARCH_X86_64 1
#define RTE_ARCH_64 1
#define RTE_CACHE_LINE_SIZE 64
#define RTE_MAX_LCORE 128
#define RTE_MAX_NUMA_NODES 32
#define RTE_MAX_ETHPORTS 32
#define RTE_PKTMBUF_HEADROOM 128
#define RTE_IOVA_IN_MBUF 1
#define RTE_EXEC_ENV_LINUX 1
#define RTE_EXEC_ENV_IS_LINUX 1
#define RTE_EXEC_ENV_IS_FREEBSD 0
#define RTE_EXEC_ENV_IS_WINDOWS 0
#define RTE_EXEC_ENV "linux"
#define RTE_VER_YEAR 26
#define RTE_VER_MONTH 7
#define RTE_VER_MINOR 0
#define RTE_VER_SUFFIX ""
#define RTE_VER_RELEASE 99
#define RTE_BACKTRACE 1
#define RTE_LIB_RING 1
#define RTE_LIB_STACK 1
#define RTE_LIB_RCU 1
#define RTE_LIB_HASH 1
#define RTE_LIB_MEMPOOL 1
#define RTE_LIB_MBUF 1
#define RTE_LIB_TELEMETRY 1
#define RTE_LIB_KVARGS 1
#define RTE_LIB_LOG 1
#define RTE_LIB_EAL 1
#endif
