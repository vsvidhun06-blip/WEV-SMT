/* Author-written stand-in for configure's urcu/config.h with liburcu 0.15.7 DEFAULT features
   (compiler-atomic-builtins disabled, legacy-mb enabled). NOT upstream. */
#define CONFIG_RCU_SMP 1
#define CONFIG_RCU_TLS __thread
#define CONFIG_RCU_HAVE_CLOCK_GETTIME 1
#define CONFIG_RCU_EMIT_LEGACY_MB 1
#define CONFIG_RCU_HAVE_MULTIFLAVOR 1
