/* Author-written: what tools/testing/shared/shared.mk generates (SHIFT=3 default). NOT upstream. */
#define XA_CHUNK_SHIFT 3
