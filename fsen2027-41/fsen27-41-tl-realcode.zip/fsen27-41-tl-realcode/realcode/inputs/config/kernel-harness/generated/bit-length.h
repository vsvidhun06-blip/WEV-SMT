/* Author-written: what shared.mk generates for LONG_BIT=64. NOT upstream. */
#define CONFIG_64BIT 1
#define CONFIG_PHYS_ADDR_T_64BIT 1
