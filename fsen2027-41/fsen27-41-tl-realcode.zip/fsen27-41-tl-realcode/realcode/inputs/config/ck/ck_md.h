/* Author-written stand-in for configure's ck_md.h (ck 0.7.2 defaults for x86_64; NOT upstream). */
#ifndef CK_MD_H
#define CK_MD_H
#define CK_MD_CACHELINE (64)
#define CK_MD_PAGESIZE (4096)
#define CK_MD_RTM_DISABLE
#define CK_MD_LSE_DISABLE
#define CK_MD_POINTER_PACK_DISABLE
#define CK_MD_SSE_ENABLE
#define CK_MD_PPC32_LWSYNC_DISABLE
#define CK_MD_VMA_BITS 48
#define CK_MD_TSO
#define CK_PR_ENABLE_DOUBLE
#define CK_VERSION "0.7.2"
#define CK_GIT_SHA "realcode-pass"
#endif /* CK_MD_H */
