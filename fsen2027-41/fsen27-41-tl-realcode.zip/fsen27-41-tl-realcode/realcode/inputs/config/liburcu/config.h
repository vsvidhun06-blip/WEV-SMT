/* Author-written stand-in for configure's include/config.h (force-included; NOT upstream). */
#define _GNU_SOURCE 1
#define HAVE_SCHED_GETCPU 1
#define HAVE_SYSCONF 1
#define HAVE_SCHED_SETAFFINITY 1
#define HAVE_GETTID 1
#define HAVE_LINUX_FUTEX_H 1
#define HAVE_SYS_SYSCALL_H 1
#define HAVE_MEMSET 1
#define HAVE_STRERROR 1
#define HAVE_GETCPUID 0
