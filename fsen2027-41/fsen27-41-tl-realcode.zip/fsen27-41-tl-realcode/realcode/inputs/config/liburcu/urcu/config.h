/* Author-written stand-in for configure's urcu/config.h (liburcu 0.15.7, atomic builtins; NOT upstream). */
#define CONFIG_RCU_SMP 1
#define CONFIG_RCU_TLS __thread
#define CONFIG_RCU_HAVE_CLOCK_GETTIME 1
#define CONFIG_RCU_USE_ATOMIC_BUILTINS 1
#define CONFIG_RCU_HAVE_MULTIFLAVOR 1
