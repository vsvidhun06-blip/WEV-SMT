/* Author-written screening controls (NOT upstream code). Expected classes per PROTOCOL.md §5:
   t_xor_self : FAKE-LOCAL      (one instruction, r ^ r, cuts the path)
   t_sub_self : FAKE-LOCAL      (r - r)
   t_identity : REAL            ((r ^ 5) ^ 5 == r)
   t_mask_hi  : FAKE-COMPOSED   (((u64)r << 32) truncated to 32 bits == 0: range restriction, 64-bit)
   t_pack     : FAKE-COMPOSED   for the load of a; REAL for the load of b ((u32)(((u64)a << 32) | b) == b)
   t_ptrdiff  : FAKE-COMPOSED   ((char*)p + 16) - (char*)p == 16, pointer arithmetic through GEP/ptrtoint
   t_cond     : FAKE-COMPOSED   (class K: ((r | 1) & 1) != 0 is always true)
   t_nsw      : REAL (wrap-around), ub_const=CONST  ((r + 1 > r) for signed int, folded only under nsw) */
#include <stdatomic.h>
#include <stdint.h>
atomic_uint x, y; atomic_ulong a64, b64; _Atomic(char *) gp;
atomic_uint a32, b32;
unsigned out_u; uint64_t out_q;

void t_xor_self(void) { unsigned r = atomic_load_explicit(&y, memory_order_relaxed); unsigned t = r ^ r; unsigned s = t + 1u; atomic_store_explicit(&x, s, memory_order_relaxed); }
void t_sub_self(void) { unsigned r = atomic_load_explicit(&y, memory_order_relaxed); unsigned s = r - r; atomic_store_explicit(&x, s, memory_order_relaxed); }
void t_identity(void) { unsigned r = atomic_load_explicit(&y, memory_order_relaxed); unsigned t = r ^ 5u; unsigned s = t ^ 5u; atomic_store_explicit(&x, s, memory_order_relaxed); }
void t_mask_hi(void) { unsigned r = atomic_load_explicit(&y, memory_order_relaxed); uint64_t t = (uint64_t)r << 32; unsigned s = (unsigned)t; atomic_store_explicit(&x, s, memory_order_relaxed); }
void t_pack(void) { unsigned a = atomic_load_explicit(&a32, memory_order_relaxed); unsigned b = atomic_load_explicit(&b32, memory_order_relaxed); uint64_t v = ((uint64_t)a << 32) | b; unsigned lo = (unsigned)v; atomic_store_explicit(&x, lo, memory_order_relaxed); }
void t_ptrdiff(void) { char *p = atomic_load_explicit(&gp, memory_order_relaxed); char *q = p + 16; long d = q - p; atomic_store_explicit(&a64, (unsigned long)d, memory_order_relaxed); }
void t_cond(void) { unsigned r = atomic_load_explicit(&y, memory_order_relaxed); unsigned t = r | 1u; if (t & 1u) atomic_store_explicit(&x, 1u, memory_order_relaxed); }
void t_nsw(void) { int r = (int)atomic_load_explicit(&y, memory_order_relaxed); int t = r + 1; int s = t > r; atomic_store_explicit(&x, (unsigned)s, memory_order_relaxed); }
