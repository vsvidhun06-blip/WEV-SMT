/* Author-written controls for control-gated phis (Amendment 7). NOT upstream code.
 * Expectations were written before any run; "v7" notes give the predicted v7 defect. */
#include <stdatomic.h>

extern atomic_uint X, Y;
extern unsigned N;

void g_sel_gate(void) {      /* EXPECT REAL: x is 1 or 2 depending on r (v7 predicted false FAKE) */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned x;
  if (r > 5) x = (r & 0) + 1; else x = 2;
  atomic_store_explicit(&Y, x, memory_order_relaxed);
}

void g_ite_cancel(void) {    /* EXPECT FAKE-COMPOSED: x == 0 on both paths (r == 0 ? r : 0) */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned x;
  if (r == 0) x = r; else x = 0;
  atomic_store_explicit(&Y, x, memory_order_relaxed);
}

void g_ite_real(void) {      /* EXPECT REAL: x == r (r == 0 ? 0 : r); a swapped true/false mapping gives CONST */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned x;
  if (r == 0) x = 0; else x = r;
  atomic_store_explicit(&Y, x, memory_order_relaxed);
}

void g_tri_cancel(void) {    /* EXPECT FAKE-COMPOSED: triangle, x == 0 always */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned x = r & 0;
  if (r == 0) x = r;
  atomic_store_explicit(&Y, x, memory_order_relaxed);
}

void g_tri_real(void) {      /* EXPECT REAL: x is 0 or 1 depending on r (v7 predicted false FAKE) */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned x = r & 0;
  if (r > 3) x = 1;
  atomic_store_explicit(&Y, x, memory_order_relaxed);
}

void g_switch_real(void) {   /* EXPECT REAL: switch-selected 5 or 6 (v7 predicted false FAKE) */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned x;
  switch (r & 3) { case 0: x = (r & 0) + 5; break; default: x = 6; break; }
  atomic_store_explicit(&Y, x, memory_order_relaxed);
}

void g_loop_trip(void) {     /* EXPECT REAL: s == (r & 7) via the trip count (v7 predicted false FAKE) */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned s = 0;
  for (unsigned i = 0; i < (r & 7); i++) s += 1 + (r & 0);
  atomic_store_explicit(&Y, s, memory_order_relaxed);
}

void g_loop_const(void) {    /* EXPECT FAKE-LOCAL: s == 0 (only def-use path is r & 0) */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned s = 0;
  for (unsigned i = 0; i < N; i++) s += (r & 0);
  atomic_store_explicit(&Y, s, memory_order_relaxed);
}
