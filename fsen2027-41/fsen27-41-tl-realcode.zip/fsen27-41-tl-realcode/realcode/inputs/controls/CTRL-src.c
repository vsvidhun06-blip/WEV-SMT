/* Author-written controls for tools/srcscreen.py (kernel-style; parsed only, never compiled). NOT upstream code.
 * Expected class of the (load, store) pair in each function is given as  EXPECT <cls> [Bop=<keep|remove>]. */
struct s { int f; };

void s_xor_self(int *x, int *y)          /* EXPECT FAKE-LOCAL Bop=remove */
{ int r = READ_ONCE(*x); WRITE_ONCE(*y, r ^ r); }

void s_sub_two(int *x, int *y)           /* EXPECT FAKE-COMPOSED Bop=keep */
{ int r = READ_ONCE(*x); int a = r + 1; int b = a - r; WRITE_ONCE(*y, b); }

void s_identity(int *x, int *y)          /* EXPECT REAL */
{ int r = READ_ONCE(*x); int a = r ^ 5; WRITE_ONCE(*y, a ^ 5); }

void s_mask(int *x, unsigned *y)         /* EXPECT FAKE-COMPOSED Bop=keep */
{ unsigned r = READ_ONCE(*x); unsigned m = r & 0xff; WRITE_ONCE(*y, m >> 8); }

void s_one_expr(int *x, int *y)          /* EXPECT FAKE-LOCAL Bop=keep */
{ int r = READ_ONCE(*x); WRITE_ONCE(*y, (r & 0xff) >> 8); }

void s_branch_killed(int *x, int *y, int c)   /* EXPECT nopair */
{ int r = READ_ONCE(*x); int a = 0; if (c) a = r; WRITE_ONCE(*y, a - a); }

void s_atomic(atomic_t *a, atomic_t *b)  /* EXPECT FAKE-COMPOSED Bop=keep */
{ int r = atomic_read(a); int t = r % 4; atomic_set(b, t / 4); }

void s_rmw(atomic_t *a, int *y)          /* EXPECT FAKE-LOCAL Bop=keep */
{ int o = atomic_fetch_add(1, a); WRITE_ONCE(*y, (o & 1) & 2); }

void s_u8(int *x, unsigned *y)           /* EXPECT FAKE-COMPOSED Bop=keep */
{ int r = READ_ONCE(*x); u8 b = r; WRITE_ONCE(*y, (u32)b >> 8); }

void s_call(int *x, int *y)              /* EXPECT REAL */
{ int r = READ_ONCE(*x); int a = hash(r); WRITE_ONCE(*y, a - hash(0)); }

void s_two_loads(int *x, int *y)         /* EXPECT REAL (two different loads, both pairs REAL) */
{ WRITE_ONCE(*y, READ_ONCE(*x) - READ_ONCE(*x)); }

void s_memread(struct s **pp, int *y)    /* EXPECT REAL (address dependency through p->f is kept) */
{ struct s *p = rcu_dereference(*pp); int v = p->f; WRITE_ONCE(*y, v); }

void s_label(int *x, int *y)             /* EXPECT nopair (label kills straight-line definitions) */
{ int r = READ_ONCE(*x); int a = r - r; again: WRITE_ONCE(*y, a); }

void s_shadow(int *x, int *y)            /* EXPECT REAL (inner declaration does not leak) */
{ int a = READ_ONCE(*x); { int a = 0; WRITE_ONCE(*x, a); } WRITE_ONCE(*y, a + 1); }

void s_loop(int *x, int *y)              /* EXPECT nopair */
{ int r = 0; int i; for (i = 0; i < 3; i++) { r = r + READ_ONCE(*x); } WRITE_ONCE(*y, r - r); }
