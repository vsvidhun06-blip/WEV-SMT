/* Author-written loop controls for the def-use-cycle encoding (Amendment 6). NOT upstream code.
 * Lines: t_loop_after 9-15, t_loop_real 17-22, t_loop_range 24-30, t_cas 32-38, t_chase 40-46. */
#include <stdatomic.h>

extern atomic_uint X, Y;
extern atomic_uintptr_t P;
extern unsigned N;

void t_loop_after(void) {             /* EXPECT FAKE-COMPOSED: (m>>8)+(s-s) with s loop-carried */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned s = 0;
  for (unsigned i = 0; i < N; i++) s += r;
  unsigned m = r & 0xff;
  atomic_store_explicit(&Y, (m >> 8) + (s - s), memory_order_relaxed);
}

void t_loop_real(void) {              /* EXPECT REAL: s = r * N via a loop */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned s = 0;
  for (unsigned i = 0; i < N; i++) s += r;
  atomic_store_explicit(&Y, s, memory_order_relaxed);
}

void t_loop_range(void) {             /* EXPECT REAL (conservative): range is lost through the loop UF */
  unsigned r = atomic_load_explicit(&X, memory_order_relaxed);
  unsigned v = r & 0xff;
  for (unsigned i = 0; i < N; i++) v = v ^ 0u;
  atomic_store_explicit(&Y, v >> 8, memory_order_relaxed);
}

void t_cas(void) {                    /* EXPECT the D sink of the CAS new value REAL (old+1) */
  unsigned old = atomic_load_explicit(&X, memory_order_relaxed);
  while (!atomic_compare_exchange_weak_explicit(&X, &old, old + 1, memory_order_relaxed, memory_order_relaxed)) {
  }
  atomic_store_explicit(&Y, old & 0, memory_order_relaxed);
}

void t_chase(void) {                  /* EXPECT REAL: L inside a cycle (pointer chasing), value stored */
  uintptr_t p = atomic_load_explicit(&P, memory_order_relaxed);
  for (unsigned i = 0; i < N; i++)
    p = atomic_load_explicit((atomic_uintptr_t *)p, memory_order_relaxed);
  atomic_store_explicit(&Y, (unsigned)p, memory_order_relaxed);
}
