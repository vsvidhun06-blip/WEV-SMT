/* CTRL-tl.c -- author-written controls for tools/tlcensus_v1.py (protocol/AMENDMENTS.md, Amendment 8).
 * NOT real-world code. Expected classes are fixed here before the first census run.
 *
 * Line format (parsed by the control checker):  EXPECT <function> <sink kind> <TL class> <TU origin or -> <screen class>
 * Sink kinds as in irscreen_v9: D = data of a marked (atomic) store, P = data of a plain store, A = address,
 * K = branch condition. TL class: forward taint class of the sink operand from the marked source.
 * TU origins: reconv, tn-input, non-uniform, phi, memory (the TU origin closest to the sink is listed).
 *
 * EXPECT tl_id            D TI -           REAL
 * EXPECT tl_add_side      D TI -           REAL
 * EXPECT tl_chain         D TI -           REAL
 * EXPECT tl_mul_odd       D TI -           REAL
 * EXPECT tl_zext_end      D TI -           REAL
 * EXPECT tl_rmw_src       D TI -           REAL
 * EXPECT tl_mul_even      D TN -           REAL
 * EXPECT tl_and_end       D TN -           REAL
 * EXPECT tl_shl_const     D TN -           REAL
 * EXPECT tl_icmp_eq_side  K TN -           REAL
 * EXPECT tl_mask2         D TU tn-input    FAKE-COMPOSED
 * EXPECT tl_cancel2       D TU reconv      FAKE-COMPOSED
 * EXPECT tl_ann_zero      D TU non-uniform FAKE-LOCAL
 * EXPECT tl_ann_var       D TU non-uniform REAL
 * EXPECT tl_icmp_ult_side K TU non-uniform REAL
 * EXPECT tl_trunc_zext    D TU tn-input    REAL
 * EXPECT tl_phi           D TU phi         REAL
 * EXPECT tl_addr          A TU tn-input    REAL
 * EXPECT tl_addr          P TU memory      REAL
 */
#include <stdatomic.h>
#include <stdint.h>

_Atomic uint32_t g, out;
_Atomic uint64_t out64;
uint32_t s_plain, t_plain, sink_plain;
uint32_t arr[4];

#define LD() atomic_load_explicit(&g, memory_order_relaxed)
#define ST(v) atomic_store_explicit(&out, (v), memory_order_relaxed)
#define ST64(v) atomic_store_explicit(&out64, (v), memory_order_relaxed)

void tl_id(void) { uint32_t x = LD(); ST(x); }
void tl_add_side(void) { uint32_t x = LD(); uint32_t y = x + s_plain; ST(y); }
void tl_chain(void) { uint32_t x = LD(); uint32_t a = x ^ s_plain; uint32_t b = a + 5u; uint32_t y = b - t_plain; ST(y); }
void tl_mul_odd(void) { uint32_t x = LD(); uint32_t y = x * 3u; ST(y); }
void tl_zext_end(void) { uint32_t x = LD(); uint64_t y = (uint64_t)x; ST64(y); }
void tl_rmw_src(void) { uint32_t old = atomic_fetch_add_explicit(&g, 1u, memory_order_relaxed); uint32_t y = old ^ 0x55u; ST(y); }
void tl_mul_even(void) { uint32_t x = LD(); uint32_t y = x * 2u; ST(y); }
void tl_and_end(void) { uint32_t x = LD(); uint32_t y = x & 1u; ST(y); }
void tl_shl_const(void) { uint32_t x = LD(); uint32_t y = x << 4; ST(y); }
void tl_icmp_eq_side(void) { uint32_t x = LD(); if (x == s_plain) sink_plain = 1u; }
void tl_mask2(void) { uint32_t x = LD(); uint32_t t = x & 1u; uint32_t y = t & 2u; ST(y); }
void tl_cancel2(void) { uint32_t x = LD(); uint32_t r = s_plain + x; uint32_t y = r - x; ST(y); }
void tl_ann_zero(void) { uint32_t x = LD(); uint32_t u = 0u; uint32_t y = x * u; ST(y); }
void tl_ann_var(void) { uint32_t x = LD(); uint32_t y = x * s_plain; ST(y); }
void tl_icmp_ult_side(void) { uint32_t x = LD(); if (x < s_plain) sink_plain = 1u; }
void tl_trunc_zext(void) { uint32_t x = LD(); uint64_t y = (uint64_t)(uint8_t)x; ST64(y); }
void tl_phi(void) { uint32_t x = LD(); uint32_t c = s_plain; uint32_t y; if (c) y = x + 1u; else y = x + 2u; ST(y); }
void tl_addr(void) { uint32_t x = LD(); uint32_t v = arr[x & 3u]; sink_plain = v; }
