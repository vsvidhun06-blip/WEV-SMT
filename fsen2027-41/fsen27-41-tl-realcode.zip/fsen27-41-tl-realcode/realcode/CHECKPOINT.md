# CHECKPOINT — real-code significance investigation (FSEN 2027 #41)

Workspace: `C:\Users\Vidhu\wev-fsen27-41\realcode-20261110T235600\` (created 2026-11-10T23:56Z).
Inputs (read-only): `recovery-20261109T232448\` (latest), `argform-20261109T203432\` (original verified baseline).
Rules: never write into earlier pass directories; never edit the manuscript; no push/submit/delete; large upstream
sources live in work dirs outside this directory (provenance recorded in `provenance/`); every run logged in `logs/`.

## Ledger (append; newest last)
- [x] S0 2026-11-10T23:56Z baselines verified: argform `sha256sum -c FINAL-HASHES.txt` exit 0, 2,146 OK (manifest
  sha `84e9f825…`); recovery exit 0, 3,316 OK (manifest sha `23cde813…`). Logs: `logs/baseline-*.txt`.
- [x] S0 environment: no WSL distro (only docker-desktop, stopped), Docker engine down, no gcc/clang/opt/make on PATH;
  Python 3.11 + z3 5.0.0 + pycparser 3.0 + networkx; `C:\ws1109\venv-llvm` (llvmlite 0.50.0 = LLVM 22.1.0, ziglang
  0.15.2 = clang 20.1.2); Maven 3.9.11; JDK 21/25; Node; network OK. RAM 15.2 GB (≈4.8 GB free), 32 threads.

- [x] S1 inspected recovery deliverables, family (17 C + litmus), llvm_actual.py (= llvmlite 0.50.0 in-process
  InstCombine of LLVM 22.1.0, NOT `opt`; family compiled by clang 20.1.2 = a different LLVM version), sweep/armcheck.
- [x] S2 PROTOCOL.md frozen 2026-11-11T00:09:01Z sha256 `bd907b34…` (`protocol/PROTOCOL.sha256`).
- [x] S3 corpora fetched (`logs/fetch_corpora.log`, `provenance/corpora.tsv`): ck 0.7.2, libvsync v4.3.0, liburcu
  v0.15.7, mimalloc v3.6.1, genmc v0.20.0, dat3m 4.4.1, nidhugg v0.3.1, dpdk v26.07 (git), linux-7.3, llvm-project
  22.1.0, gcc-15.2.0 (tarballs, sha256 recorded). Work dir `C:\rc1111\` (src/, dl/, venv/).
- [x] S4a screening tool + controls. ACCEPTED: `tools/irscreen_v3.py` sha `d3b3bdc6…`; controls PASS
  (`outputs/controls-v3-20261111T002101Z/`, README there explains UBSan-at-O0 and debug-location anomalies, v2 broken).
  RULE: every compile uses `-fno-sanitize=all`; every run writes to a fresh timestamped dir; nothing is deleted.

- [x] S4b 2026-11-11T00:20–00:55Z. Tarballs extracted to `C:\rc1111\src\{linux-x,llvm-x,gcc-x}` (linux: 30 symlinks
  not creatable on Windows, incl. 2 selftest .c files; `logs/extract.log`). Tool history (all kept): v3 → **v5**
  (recursion/stack + multi-line alignment, Amendment 1; v4 broken: 512 MiB stack rejected) → **v6** (DILocation
  `distinct`/no-column parsing, Amendment 4). v6 sha `805f1ba3…`, controls PASS identical to v3/v5. Amendments
  2 (site/context units) and 3 (resource guards: driver `tools/screen_corpus_v2.py`, 4 jobs, 2.5 GB/job MEMOUT,
  600 s TIMEOUT) and 5 (source screen opaque = UF). v3 pipeline stopped by operator at mimalloc (RAM 0.53 GB);
  v5 pipeline stopped at libvsync (location defect). Logs: `logs/run_p2p3.log`, `run_stageA_v5.log`, `run_stageA_v6.log`.
- [x] S4c Stage A results so far (v6; summaries in `search/stageA/<corpus>-v6-*/summary.txt`, fake_sites.csv):
  - ck 152/155 modules: SLI FAKE-COMPOSED sites A2 K2 (regressions/common.h aff_iterate CPU_SET(c%CORES) after
    seq_cst faa; stack cpu_set_t), FAKE-LOCAL 9 (hclh harness). SL: none.
  - libvsync 182/235: SLI FAKE-COMPOSED K5 (ASSERTs: atomicptr_stamped IS_ALIGNED after GET_ADDRESS mask [inlined
    helper composition, unbounded_queue_lf_recycle]; bitmap or_get/and_get tautological asserts; ebr epoch idx).
    All L are seq_cst loads/RMWs.
  - liburcu 77/99 (builtins config): 0 FAKE. mimalloc 16/17: 0 FAKE (2 SLI MEMOUT). dat3m 137/152: 0 FAKE.
  - P1a linux-7.3 source screen (`tools/srcscreen.py` sha e649c3ec…, controls PASS 15/15): 65,835 files, 15,556
    marked-store sinks, 573 load→store pairs, ALL REAL (96 multi-operator). Rows: `C:\rc1111\build\p1a-linux-src-*`.
  - LARGE (slice > 300) is a large undecided share in liburcu/libvsync (report; consider exploratory re-check).
- Running at 00:55Z: run_stageA_v6 (genmc screen, then nidhugg), run_p4 (LLVM .ll screen, then GCC build+screen),
  run_p1b (radix K1 screen slow: maple-shim; then vma, bpf, K2 variants). liburcu volatile-dereference variant
  (URCU_DEREFERENCE_USE_VOLATILE) still to build.

## Next
- Finish Stage A (genmc, nidhugg, P4, P1b, liburcu-volatile, DPDK subset); Stage B–D triage of FAKE-COMPOSED sites;
  Stage-D rule: L ordering ≥ acquire ⇒ dependency redundant (verdict cannot change); K sinks: report compiler-sense
  control dependence and Arm-architectural ctrl (all po-later writes) separately.
- P5 published examples; theory track (exactness fragment census); deliverables.

- [x] S4d 2026-11-11T01:15:42Z screener soundness work (all versions kept; `protocol/AMENDMENTS.md` 6–7, `TOOL.sha256`):
  - **v7** (Amendment 6): def-use cycles become UFs over their external inputs. Fixes LARGE-by-loop. Loop controls
    `inputs/controls/CTRL-loop.c` PASS.
  - **v8**: BROKEN. llvmlite operands report is_block=False, so the CFG was empty. Kept, never used.
  - **v9** (Amendment 7, sha `b50a95c4…`): control-gated phis (gating-region gates; exact ite for diamonds and
    triangles; gate edges in the cycle graph). Gate controls `inputs/controls/CTRL-gate.c` PASS. v7 gave false
    FAKE-LOCAL on 4/8 gate controls. Standard controls are identical across v3/v5/v6/v7/v9.
  - The v6 and v7 Stage-A screens are SUPERSEDED but kept (`C:\rc1111\build\*-screen-v6-*`, `*-screen-v7-*`, partial).
  - **Running**: `tools/run_v9_A.sh` (ck, libvsync, liburcu, liburcu-vol, mimalloc, dat3m, genmc, then nidhugg
    build with `--flags=-pthread`; the v6 nidhugg build had died in argparse) and `tools/run_v9_B.sh` (p1b radix-K1,
    vma-K1, bpf, radix-K2, vma-K2, DPDK rebuilt with C:/ paths in `flags.txt.v3` (v6 DPDK compiled 0/46), p4llvm,
    p4gcc). Logs `logs/run_v9_{A,B}.log`. p4gcc build: 2,659/5,095 compiled.
  - P5 kernel-documentation transcriptions `inputs/p5/P5-kernel-docs.c` (7 functions, author-written, cited):
    v7 gives `x-(uintptr_t)x` FAKE-COMPOSED, `r1*0` and `q%1` FAKE-LOCAL, p+a-b REAL. `q||1>0` and
    identical-store legs come out REAL: those are outside the value-dependency notion. The `p==&default_foo`
    example is REAL because the screen is path-insensitive. Output: `outputs/p5-kerneldocs-*`. Rerun with v9: TODO.
- [x] T1 2026-11-11T01:34:36Z THEORY: `theory/tl/PwT_TaintLinear.thy` (sha `8e1c0100…`), session `WEV_SMT_TL` (parent
  WEV_SMT_Rev, built from COPIES of the base and add-on theories: `theory/{base-isabelle-copy,addon-formal-copy}`,
  `COPIES.sha256`). Clean build `-c` BUILD_EXIT=0. `TL_Check`: 31 facts, oracles none (`tl/CHECK-RESULT.txt`).
  Logs in `theory/logs/`; earlier failed attempts are kept (`*.attemptN.thy.txt`). Content:
  - three-class taint (TI/TN/TU); `tl_exact`: unless y ends TU, prog_dep ⟺ x ∈ vdep; `tl_frag_exact`;
  - `sri_exact_via_tl` re-derives the paper's vdep_exact_sri;
  - witnesses that each hypothesis is needed: cancel2 (correlation), maskP (range restriction), annP (side-input
    annihilation: `u:=0; y:=x*u`, new).
  Build: cygwin bash → `isabelle build -c -v -o timeout=600 -d base-isabelle-copy -d addon-formal-copy -d tl WEV_SMT_TL`.
- [x] C1 2026-11-11T01:52:13Z COMPILER DIFFERENTIAL (libvsync target sites). v1 grid
  `outputs/compdiff-libvsync-20261111T013718Z` is CONFOUNDED (zig cc maps -O1/-O2/-O3 to "-DNDEBUG -O2"; see its
  CONFOUNDED-READ-FIRST.md); kept. v2 `outputs/compdiff-libvsync-v2-20261111T014632Z` replays zig's argv with the raw
  clang driver; fidelity 12/12 IDENTICAL. RESULTS.md: target sites bitmap.h:164/303, ebr.h:248, stamped:86 vanish at
  O1+ in all columns; siblings survive. 2 screen-REAL sites (smr_nodes_list.h:78/110) are also folded (inbounds
  non-null), so the screen under-approximates. No verdict change (all L seq_cst) → Stage D fails.
- [x] T2 2026-11-11T02:00:53Z TL CENSUS TOOL: Amendment 8 (criterion + checks before any run). Controls
  `inputs/controls/CTRL-tl.c` (expectations frozen, sha 886cba29…) → `controls-tl-20261111T020026Z`: TL CONTROL CHECK PASS SL and SLI,
  19/19, row alignment with screen OK. `tools/tlcensus_v1.py` accepted (TOOL.sha256). Next: run it over the finished v9
  corpora with screen_corpus_v2.py --tool tlcensus_v1.py; join with tools/tlcensus_join_v1.py (to write).
- [x] S5 2026-11-11T02:00:53Z v9 aggregates in search/stageA/{ck,libvsync,liburcu,liburcu-vol,p1b-radix-K1,p1b-vma-K1}-v9-20261111T015228Z.
  New v9 FAKE-COMPOSED: libvsync vatomic unit tests (max_get(&obj, MAX) then assert, on stack objects, single-threaded:
  Stage B fail), p1b-vma-K1 expand_downwards (stub capable()=true in tools/testing/vma: harness artefact, Stage C fail).
- [x] R1 2026-11-11T10:25:45Z RESTART after usage-limit interruption. State found: v9 screens COMPLETE for ck, libvsync, liburcu,
  liburcu-vol, mimalloc, dat3m, genmc, p1b-radix-K1, p1b-vma-K1, p1b-bpf (0 modules), p1b-radix-K2 (3 MEMOUT/TIMEOUT).
  nidhugg build done (8257/8261) but its v9 screen, the p1b-vma-K2 screen and the TL census (ck) never ran a job
  (drivers stalled on the free-RAM guard; available RAM 0.05–0.13 GB). Stopped all three drivers; output dirs
  kept empty. Not started: DPDK rebuild+screen, p4llvm, p4gcc screens. tlcensus_join_v1.py fix verified (below).
- [x] R2 2026-11-11T11:45:16Z TL CENSUS EXECUTED (Amendment 9 + addendum): foreground batches (`tools/run_tl_batch.sh`,
  `run_tl_chain.sh`, lists `search/tl-batches/`), dirs `C:\rc1111\build\tlcensus-v1-<batch>-<ts>` plus the
  p1b-vma-K1 probe dirs. Log `logs/run_tl_batches.log`. Corpora: dat3m, genmc, mimalloc (2 MEMOUT), ck, liburcu,
  liburcu-vol, libvsync, p1b-vma-K1 (SL+SLI), p1b-radix-K1/K2 (SL + SLI split by module; 1 MEMOUT and 1 TIMEOUT each).
  Next: join (tlcensus_join_v2.py, multi-dir), report.
- [x] R3 2026-11-11T11:50:30Z CENSUS JOINED: `search/tlcensus-join-20261111T114530Z/<corpus>/summary.txt`, POOLED.txt.
  CONSISTENCY (prespecified) PASS in all 10 corpora: 0 of 124,956 [CORRECTED in R11: 124,756] joined pairs are TI/TN and FAKE-*. In-fragment
  share varies by corpus (SLI raw pairs: genmc 51%, dat3m 44%, libvsync 21%, ck 12%, liburcu 3.5%, liburcu-vol 0%,
  radix 0%). TU exits are mostly structural (cycle/phi/memory/call: 90.0% of SLI pairs); semantic exits
  (reconv/tn-input/non-uniform) 3.6%. tl_plus extension gains <=23 rows per corpus (NEGATIVE: not worth mechanising).
- [x] R4 2026-11-11T11:50:30Z Missed FAKE-COMPOSED sites triaged (the earlier listing was cut by head -60):
  liburcu(+vol) rculfhash.c:635@2128 (RELAXED load of resize_target :2154; max() then !x across an inlined helper):
  Stage B PASS, C PASS, D FAIL (dominated by REAL ctrl sinks :2126/:2155/:2157 of the same load). Compiler
  differential `outputs/compdiff-rculfhash-20261111T114915Z`: the branch is removed at O1/O2/O3/Os (inlined, branch-free),
  so this is EDGE evidence. radix-tree.c:857 (radix_tree_replace_slot, node=NULL constant: the source is on a dead
  path): Stage C FAIL (vacuous). New v9 aggregates for mimalloc/dat3m/genmc/radix-K2: 0 FAKE-COMPOSED.
- [x] R5 2026-11-11T11:59:32Z §6 family at GENUINE levels: `outputs/family-true-levels-20261111T115507Z` fidelity 68/68,
  genuine O1==O2==O3 IR 68/68, verdicts unchanged (13 NO-dep cancelling, sq-minus + 3 controls dep). Recovery C4 holds.
- [x] R6 2026-11-11T12:02:59Z CORRECTION to S5/R4 (p1b-vma-K1 site dup.h:1532:30, the `||` short-circuit branch): the
  cancelling mechanism is NOT the capable() stub. Kernel mm/mmap.c:231 is `mlock_future_ok(mm, bool is_vma_locked, …)`
  and mm/vma.c:3219 passes `vma_test(vma, VMA_LOCKED_BIT)` (a bool). The userspace harness duplicate
  tools/testing/vma/include/dup.h:1527 still has the OLD signature `(mm, vm_flags_t vm_flags, …)` and tests
  `vm_flags & VM_LOCKED` (bit 13): a 0/1 value masked with bit 13 is always 0 → composed range restriction across
  inlined helpers (_test_bit `1UL & …` → vma_flags_test → vma_test → dup.h). The capable() stub (stubs.h:343, returns
  true) only makes the whole function constant in the harness, so the stale duplicate has no observable effect
  today. Kernel code itself has no cancellation; harness single-threaded (0 pthread files). Stage D FAIL (harness-only
  artefact). Side observation (latent harness inconsistency), NOT a weak-memory finding; nothing reported upstream.
- [x] R7 2026-11-11T12:12:30Z STAGE B-D TRIAGE DONE: `CANDIDATE-INVENTORY.csv` (tools/build_inventory_v1.py; triage
  is manual and written as data in the script). 64 unique FAKE sites (52 FAKE-COMPOSED, 12 FAKE-LOCAL; duplicate
  builds merged). FAKE-COMPOSED funnel: B pass 8 (10 under architectural ctrl) → C pass 7 (9) → D pass 0 → E 0.
  By kind (SLI, 8 distinct corpora): D-sinks 501 sites, 0 FAKE-COMPOSED; all 52 are K (50) or A (2).
  Tables: search/stageA/STAGEA-V9-TABLE-20261111T120043Z.tsv, STAGEA-V9-BYKIND-20261111T120555Z.txt.
  Census report: search/tlcensus-join-20261111T114530Z/CENSUS-REPORT.md (+ addendum). p1b-bpf: libelf.h missing
  (setup failure). Dat3M build NOT attempted: 0.26 GB RAM available; no candidate reaches Stage E anyway.
  NEXT: write the 8 deliverables.
- [x] R8 2026-11-11T12:15:02Z §6 recovery/compiler sources (LB-mem-cancel etc.) at genuine levels:
  `outputs/recovery-compiler-true-levels-20261111T121424Z` fidelity 20/20, O1==O2==O3 20/20; the manuscript's
  LB-mem-cancel statements hold. Manuscript lines 68/595/924/1129-1144 all rest on zig cc runs; their claims are
  reproduced at genuine levels (family 68/68 + these 20/20).
- [x] R9 2026-11-11T12:18:35Z rculfhash differential v2 (tools/compdiff_rculfhash_v2.py), both targets:
  `outputs/compdiff-rculfhash-v2-aarch64-20261111T121754Z`, `…-x86_64-20261111T121757Z`: replay fidelity
  (-DNDEBUG -O2 vs zig cc -O2) IDENTICAL on both; the fake branch (line 635 inlined at :2128) is absent at
  O1/O2/O3/Os, and the dominating REAL branches :2155/:2157 are present at every level, on both targets. The first v2
  runs (…121722Z, …121727Z) are NOT USED (regex skipped 'distinct' DILocations; ill-posed fidelity), see NOT-USED.txt.
  Inventory regenerated with tools/build_inventory_v2.py (only K05 evidence cells changed); the v1 CSV is kept as
  search/CANDIDATE-INVENTORY.v1-20261111T1208Z.csv.
- [x] R10 2026-11-11T12:25:04Z MEMORY CAVEAT (PROTOCOL §3.1) for the mem_opaque Stage-C sites, cleared mechanically by
  tools/opaque_probe_v1.py (imports irscreen_v9 unchanged; re-decides CONST with every opaque UF application unshared
  between the copies): `outputs/opaque-probe-20261111T122327Z/`. rculfhash K05: opaque nodes = the field GEP + the
  two sibling loads of the same uatomic_load (-O0 lowers the non-constant memory-order argument to
  monotonic/acquire/seq_cst variants; the program's order is CMM_RELAXED == __ATOMIC_RELAXED); unshared query UNSAT.
  stamped K06/K07 (run context): opaque = node->next seq_cst loads; all pairs UNSAT unshared. Inventory v3
  (tools/build_inventory_v3.py; changed cells: K05 fragment + stage_C, K06/K07 stage_C); v2 CSV kept as
  search/CANDIDATE-INVENTORY.v2-20261111T1222Z.csv. The v1/v2 inventory wrongly said "no opaque memory" for K05.
- [x] R11 2026-11-11T12:38:49Z DELIVERABLES WRITTEN + VERIFIED. THEOREM-OPPORTUNITIES.md and SCIENTIFIC-VERDICT.md written;
  SEMANTIC-VALIDATION W1 (order of uatomic_load, path_len 3, memory caveat), W4 (schematic path, caveat), W5
  (schematic path) corrected; REAL-CODE-SEARCH gains the Stage-C memory-caveat paragraph and the P1a parse-error
  limitation (6,707 of 8,386 screened files have >= 1 tree-sitter error; still screened via error recovery).
  VERIFICATION (read-only re-derivation of every key number from raw files):
  * v1 `tools/verify_deliverables_v1.py` -> `outputs/verify-deliverables-20261111T123001Z`: 28/29 PASS. C1 FAIL found
    an ARITHMETIC SLIP OF MINE in the deliverables: census joined rows were stated as 124,956 / 87,056; the
    per-build summaries sum to 124,756 / 86,856 (= pooled SL 11,906 + SLI 74,950). Corrected in REAL-CODE-SEARCH,
    THEOREM-OPPORTUNITIES, SCIENTIFIC-VERDICT; CHECKPOINT R2/R3 line annotated in place.
  * Checking the remaining stated numbers against data found further TEXT errors, all corrected: "236" undecided
    SLI sites -> 239 (218 radix-tree harness, 18 libvsync, 3 liburcu); "52 FC found in 8 corpora" -> in 5 of the 8
    (libvsync 45, ck 4, liburcu 1, radix 1, vma 1); "removes every one of the 6 sites" -> every CANCELLED INSTANCE
    (atomicptr_stamped.h:87 survives in a non-fake pool-node context, as COMPILER-RESULTS already said);
    semantic-exit range "0.4-20.7% per corpus" omitted the vma harness outlier 65.4%; "structural = control
    merges and loops" -> the census class also has memory/calls; loops+phis are 97.7% of SLI structural exits
    (62,793 of 74,950 pooled SLI pairs, 83.8%); COMPILER-RESULTS "every level >= -O1" -> O1/O2/O3/Os (-Oz not run).
    Proposed manuscript paragraph (SCIENTIFIC-VERDICT Q7a) rewritten to account for all 52 sites
    (45 thread-local/dead path + 7 Stage-D reasons) and "source access" (two sources are RMWs).
  * v2 (adds coverage table, per-corpus/exclusion breakdowns, libvsync sites.csv, P1a STATS, TL sha, and a TEXT
    section T1/T2) -> `outputs/verify-deliverables-v2-20261111T123800Z`: 42/43; A12 FAIL was a VERIFIER defect
    ("| ck |" prefix also matched later tables -> "?" cells; parsable cells matched).
  * v3 (A12 confined to the coverage-table block) -> `outputs/verify-deliverables-v3-20261111T123819Z`: 43/43 PASS,
    exit 0. All three runs kept.
- [x] R12 2026-11-11T12:45:18Z REPRODUCE.md written. Commands recovered from the run scripts, tool headers, logs and the
  session transcript (the P1a launch and the opaque-probe/true-levels argument lists came from the transcript).
  * tools/pool_tl_origins_v1.py = the inline command that wrote POOLED.txt (2026-11-11T11:47:00Z), verbatim except
    for its output path (argv[2], refuses to overwrite). It regenerates POOLED.txt BYTE-IDENTICALLY:
    `outputs/pooled-regen-20261111T124136Z`. `outputs/pooled-regen-20261111T124108Z` is EMPTY / NOT-USED: tool
    creation was aborted by its own exact-match assertion, because the Git Bash heredoc turned '\n' into a real
    newline even in a quoted heredoc; redone with chr(92).
  * NOTE on R3: its pooled shares (structural 90.0%, semantic 3.6% of SLI pairs) are POOLED.txt's pooling over ALL 10
    builds, duplicates included. The deliverables use CENSUS-REPORT.md's pooling over the 8 distinct corpora
    (85.7%, 4.8%). Both are correct for their denominators.
  * Sanitizers: the step-9 true-levels re-runs replay sweep.py's flags without -fno-sanitize=all (by design, for
    fidelity). Checked all 500 .ll files in the five compile output directories: 0 contain 'ubsan'.
  * TOOLS-FINAL-20261111.sha256: sha256 of all 58 files in tools/. TOOLS-USED-20261111.sha256 is kept unchanged.
- [x] R13 2026-11-11T12:45:18Z FINAL STATUS. All 8 deliverables present and verified.
  * Final verifier: `outputs/verify-deliverables-v3-20261111T124414Z`: 43/43 PASS, exit 0 (after all text edits).
  * Baselines re-verified (`logs/final-baseline-{argform,recovery}-sha256c-20261111T124433Z.txt`): argform 2,146/2,146 OK,
    recovery 3,316/3,316 OK, both exit 0 (the 2 lines matching "FAILED" are file NAMES, verified OK, as at S0).
    Manuscript sha b555e516 and PROTOCOL bd907b34 unchanged. CLAIM-TO-EVIDENCE.md mtime 2026-11-09T23:49 (untouched).
    No git commit or push; no manuscript edit.
  * Deliverable sha256 prefixes: REAL-CODE-SEARCH 4a832d82, CANDIDATE-INVENTORY.csv 01c7d7a2, COMPILER-RESULTS
    6384ed26, SEMANTIC-VALIDATION 635b8bc3, THEOREM-OPPORTUNITIES 49033d2d, SCIENTIFIC-VERDICT 0175c1ae, REPRODUCE
    1c245838 (CHECKPOINT changes with this entry).
  * OUTCOME: not A. C (edge: clang 20.1.2 removes every cancelled instance at the 6 compiled Stage-C sites) + modest B
    (tl_exact, mechanised, census-tested). D at outcome level: 52 FC sites in 5 of 8 corpora; 0 among 501 data sinks;
    0 of 52 verdict-relevant.
  * OPEN (author decisions / not done): apply the proposed manuscript text (SCIENTIFIC-VERDICT Q7a; (b) optional);
    nidhugg, vma-K2, DPDK, p4 and bpf not screened by v9; no herd7/Dat3M/GCC/hardware; O1 verdict-irrelevance
    theorem not mechanised.
