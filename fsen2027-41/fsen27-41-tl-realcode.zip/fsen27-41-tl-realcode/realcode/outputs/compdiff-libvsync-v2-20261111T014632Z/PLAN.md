# Compiler differential v2 (prespecified 2026-11-11T01:46:32Z, before any v2 compile)

Replaces the confounded v1 grid (`compdiff-libvsync-20261111T013718Z/CONFOUNDED-READ-FIRST.md`): zig cc maps -O1/-O2/-O3 to
"-DNDEBUG -O2". v2 calls the raw clang driver bundled with zig (`python -m ziglang clang`, clang 20.1.2, zig 0.15.2).
Its argv is captured once per (file, target, atomics) from `ZIG_VERBOSE_CC=1 python -m ziglang cc … -O2` and replayed
with only these changes: drop -MD/-MV/-MF, -DNDEBUG, zig's -O2, -c/-o/-S/-emit-llvm; then add the cell's -O<n>, and
-DNDEBUG for NDEBUG cells. The base flags are zig's ReleaseFast set for every level, including -O0
(-fno-stack-protector, -fno-omit-frame-pointer, the -target-cpu/-target-feature list, -nostdinc and the four libc -isystem dirs).

Inputs: unmodified upstream libvsync `examples/eg_bitmap.c`, `examples/eg_unbounded_queue_lf_recycle.c` and
`examples/eg_vebr.c`. Grid: target {aarch64-linux-gnu, x86_64-linux-gnu} × atomics {BUILTINS (-DVATOMIC_BUILTINS),
DEFAULT} × asserts {on, NDEBUG} × opt {O0, O1, O2, O3, Os} × output {ll, s}: 240 compiles plus 12 captures.
Measure: `check.py` (byte-identical copy of the v1 checker). A site counts as present if any `__assert_fail` call
with that file and line remains (after inlining, any instance).

Predictions (pre-run; from reading the sources: bitmap.h:155-165/296-304, fallback.h:1361 (or_get = get_or | v in C, also
on the aarch64 asm path), ebr.h:246-248 (idx = epoch % 3), atomicptr_stamped.h:62/84-87):
- P0 fidelity: in each of the 12 families, the replayed (O2, NDEBUG, ll) cell equals zig cc's own -O2 output, apart
  from ModuleID/source_filename lines.
- P1: O0, asserts on: every site present (v1 O0 counts: eg_bitmap 23, lf_recycle 8, eg_vebr 44 sites).
- P2: O1, O2, O3 and Os, asserts on: bitmap.h:164 and bitmap.h:303 absent in all four (target, atomics) columns;
  ebr.h:248 absent; atomicptr_stamped.h:86 absent.
- P2b: atomicptr_stamped.h:87 may stay present, because some cmpxchg contexts pass a non-GET_ADDRESS pointer
  (e.g. qnode) as v. If present, the surviving instances are inspected by hand.
- P3: control sites (non-tautological asserts) mostly present at every level. Each control site that disappears at
  O1+ is listed and explained (e.g. provable from context after inlining), not assumed.
- P4: NDEBUG: no __assert_fail in any cell.
