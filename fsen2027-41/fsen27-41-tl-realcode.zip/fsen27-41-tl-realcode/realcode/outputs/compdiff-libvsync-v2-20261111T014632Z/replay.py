"""Compiler grid v2 (PLAN.md): replay zig's own clang command line through the raw driver, varying only -O<n>/NDEBUG.
Writes only inside its own directory (capture/, ll/, s/, commands.tsv, fidelity.txt). Refuses to overwrite outputs."""
import os, re, subprocess, sys, time

OUT = os.path.dirname(os.path.abspath(__file__))
PY = r'C:\rc1111\venv\Scripts\python.exe'
S = 'C:/rc1111/src/libvsync'
FILES = ['eg_bitmap', 'eg_unbounded_queue_lf_recycle', 'eg_vebr']
TARGETS = ['aarch64-linux-gnu', 'x86_64-linux-gnu']
ATOMICS = ['BUILTINS', 'DEFAULT']
ASSERTS = ['on', 'NDEBUG']
OPTS = ['O0', 'O1', 'O2', 'O3', 'Os']
for d in ('capture', 'll', 's'):
    if not os.path.isdir(os.path.join(OUT, d)):
        sys.exit('missing output dir ' + d)
if os.path.exists(os.path.join(OUT, 'commands.tsv')):
    sys.exit('commands.tsv exists; refusing to overwrite')


def user_flags(at):
    f = ['-fno-sanitize=all', '-g0', '-w', '-I', S + '/include', '-I', S + '/vatomic/include', '-I', S + '/test/include',
         '-I', S + '/verify/include', '-D_GNU_SOURCE', '-pthread']
    if at == 'BUILTINS':
        f.append('-DVATOMIC_BUILTINS')
    return f


def capture(f, tgt, at):
    """zig cc -O2 with ZIG_VERBOSE_CC=1; returns (zig argv after 'clang', zig's own output path)."""
    src = '%s/examples/%s.c' % (S, f)
    out = os.path.join(OUT, 'capture', '%s.%s.%s.zigcc-O2.ll' % (f, tgt, at))
    if os.path.exists(out):
        sys.exit('capture exists: ' + out)
    cmd = [PY, '-m', 'ziglang', 'cc', '-target', tgt, '-O2'] + user_flags(at) + ['-S', '-emit-llvm', '-o', out, src]
    env = dict(os.environ, ZIG_VERBOSE_CC='1')
    p = subprocess.run(cmd, env=env, capture_output=True, text=True)
    with open(out + '.verbose.txt', 'w', encoding='utf-8') as fo:
        fo.write(p.stderr)
    if p.returncode != 0:
        sys.exit('capture failed %s %s %s: %s' % (f, tgt, at, p.stderr[-2000:]))
    lines = [l for l in p.stderr.splitlines() if re.search(r'zig(\.exe)? clang ', l)]
    if len(lines) != 1:
        sys.exit('expected exactly one zig clang line, got %d' % len(lines))
    toks = lines[0].split()
    if any('"' in t or "'" in t for t in toks):
        sys.exit('quoted token in verbose line; whitespace split unsafe')
    i = toks.index('clang')
    return cmd, toks[i + 1:], out


def base_from(toks, src):
    t = list(toks)
    if t[0].replace('\\', '/') != src:
        sys.exit('first token is not the source: ' + t[0])
    t = t[1:]
    out = []
    k = 0
    removed = {'-DNDEBUG': 0, '-O2': 0}
    while k < len(t):
        a = t[k]
        if a in ('-MD', '-MV', '-c', '-S', '-emit-llvm'):
            k += 1
            continue
        if a in ('-MF', '-o'):
            k += 2
            continue
        if a in removed:
            removed[a] += 1
            k += 1
            continue
        if re.fullmatch(r'-O[0-9sz]?', a):
            sys.exit('unexpected extra opt flag ' + a)
        out.append(a)
        k += 1
    if removed != {'-DNDEBUG': 1, '-O2': 1}:
        sys.exit('expected exactly one -DNDEBUG and one -O2 from zig, got %r' % removed)
    return out


def strip_ids(path):
    return [l for l in open(path, encoding='utf-8', errors='replace').read().splitlines()
            if not l.startswith('; ModuleID') and not l.startswith('source_filename')]


rows = ['file\ttarget\tatomics\tasserts\topt\tkind\texit\tms\tcommand']
fid = []
for f in FILES:
    src = '%s/examples/%s.c' % (S, f)
    for tgt in TARGETS:
        for at in ATOMICS:
            ccmd, toks, zout = capture(f, tgt, at)
            rows.append('\t'.join([f, tgt, at, 'CAPTURE', 'O2', 'll', '0', '0', ' '.join(ccmd)]))
            base = base_from(toks, src)
            with open(os.path.join(OUT, 'capture', '%s.%s.%s.base-argv.txt' % (f, tgt, at)), 'w',
                      encoding='utf-8') as fo:
                fo.write('\n'.join(base) + '\n')
            for nd in ASSERTS:
                for o in OPTS:
                    for kind in ('ll', 's'):
                        dst = os.path.join(OUT, kind, '%s.%s.%s.%s.%s.%s' % (f, tgt, at, nd, o, kind))
                        if os.path.exists(dst):
                            sys.exit('exists: ' + dst)
                        cmd = [PY, '-m', 'ziglang', 'clang', src] + base + ['-' + o]
                        if nd == 'NDEBUG':
                            cmd.append('-DNDEBUG')
                        cmd += ['-S'] + (['-emit-llvm'] if kind == 'll' else []) + ['-o', dst]
                        t0 = time.time()
                        p = subprocess.run(cmd, capture_output=True, text=True)
                        ms = int((time.time() - t0) * 1000)
                        with open(dst + '.err', 'w', encoding='utf-8') as fo:
                            fo.write(p.stderr)
                        rows.append('\t'.join([f, tgt, at, nd, o, kind, str(p.returncode), str(ms), ' '.join(cmd)]))
            rep = os.path.join(OUT, 'll', '%s.%s.%s.NDEBUG.O2.ll' % (f, tgt, at))
            same = os.path.exists(rep) and strip_ids(rep) == strip_ids(zout)
            fid.append('%s %s %s replay(O2,NDEBUG) == zig cc -O2 (modulo ModuleID/source_filename): %s' % (
                f, tgt, at, 'IDENTICAL' if same else 'DIFFERENT'))
with open(os.path.join(OUT, 'commands.tsv'), 'w', encoding='utf-8') as fo:
    fo.write('\n'.join(rows) + '\n')
with open(os.path.join(OUT, 'fidelity.txt'), 'w', encoding='utf-8') as fo:
    fo.write('\n'.join(fid) + '\n')
print('\n'.join(fid))
bad = [r for r in rows[1:] if r.split('\t')[6] != '0']
print('compiles: %d, nonzero exit: %d' % (len(rows) - 1, len(bad)))
