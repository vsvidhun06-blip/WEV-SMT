# Compiler differential v2: results (2026-11-11T01:52:13Z)

Tool: zig 0.15.2's bundled clang 20.1.2, raw driver (`python -m ziglang clang`), replaying zig's own argv
(`capture/*.base-argv.txt`) with only -O<n> and -DNDEBUG varied. 252 compiles, all exit 0 (`commands.tsv`).
Analysis: `check.py` (sha256 prefix 5d146a42, identical to v1) → `report.txt`, `sites.csv`; `xref.py` → `xref.txt`.

## Predictions vs observations (PLAN.md written before the runs)
- P0 fidelity: HOLDS. 12/12 families IDENTICAL to zig cc -O2 output (`fidelity.txt`).
- P1 (O0, asserts on, every site present): HOLDS (23 / 8 / 44 sites).
- P2 (target sites absent at O1, O2, O3 and Os in all four target × atomics columns): HOLDS for bitmap.h:164,
  bitmap.h:303, ebr.h:248 and atomicptr_stamped.h:86.
- P2b (:87 may survive): OBSERVED. :87 is present at every level. The only surviving instance at
  aarch64/BUILTINS/O2 (ll line 322, inlined into `run`) checks the alignment of a pool/alloc_qnode node (phi %73), not a
  GET_ADDRESS result. All 10 FAKE-COMPOSED contexts of :87 in the screen have their v from GET_ADDRESS
  (`and i64 %x, -128`), and no instance with such an operand survives.
- P3 (controls mostly present): PARTLY REFUTED. Controls that vanish at O1+: eg_bitmap 4/21 (bitmap.h:176 at O2+,
  :215, :223, :315); lf_recycle 4/6; eg_vebr 27/43. Explanation (xref.txt, source text in this file's appendix):
  - 33 of the 35 vanished controls have NO marked-load pair in the Stage-A SLI screen, so they are not dependency sites.
    They are non-null checks of global, stack, GEP or function-constant pointers after inlining, plus arithmetic facts
    (bitmap.h:215/223: `to = (tid<<6)+63`), a dominating equivalent check (bitmap.h:176: `idx < maps_cnt`, plain
    loads, O2+), store-to-load forwarding (ebr.h:96, right after dbl_list_init stores NULL) and alignment of an
    argument/global (atomicptr_stamped.h:319, set_rlx).
  - 2 vanished controls DO have marked-load pairs, which the screen classes REAL: smr_nodes_list.h:78 and :110,
    `ASSERT(lst)` with `lst = &ebr->retired_lst[epoch % 3]`, epoch from a seq_cst read. In the BV model
    `base + 24*idx` can wrap to 0, so the condition varies. LLVM folds it because an inbounds GEP from a global is
    non-null. The compiler removes dependencies that the BV screen keeps, so the screen's FAKE count UNDER-approximates
    what clang cancels. (The screen is sound for FAKE, conservative for REAL.)
  - Same-function siblings of the target sites survive at every level: bitmap.h:158/159/161 (with :164 in
    vbitmap_set_bit), bitmap.h:297/298/300 (with :303 in vbitmap_clr_bit). So the target folds are site-specific
    folds of the composed expression, not removal of dead code.
- P4 (NDEBUG: no __assert_fail): HOLDS, 0/60 NDEBUG cells.
- DEFAULT atomics on aarch64 (custom LL/SC asm): same as BUILTINS. or_get is `get_or(a,v) | v` in C
  (fallback.h:1361), so the cancellation is visible above the asm.

## What this shows and what it does not
Shows: a production compiler (clang 20.1.2, every optimisation level ≥ O1, both targets, both atomics
implementations) performs exactly the composed cancellations that Stage A found in authentic, unmodified libvsync
code. After optimisation, these control dependencies from a marked access to an assert branch no longer exist. This
is edge evidence that mode-C cancellations occur in real compiled concurrent code.

Does not show: a change of any weak-memory verdict. In every case the source access is seq_cst (libvsync's
unsuffixed default: vatomic64_or_get / and_get / read, vatomicptr_stamped_get via seq_cst load), so later accesses
are ordered after it regardless of dependencies (Stage D: redundant). ebr.h:248 also keeps a real address dependency
to its only downstream store (`retired_lst[idx]`). The sinks are assert branches, and they vanish anyway under NDEBUG.
