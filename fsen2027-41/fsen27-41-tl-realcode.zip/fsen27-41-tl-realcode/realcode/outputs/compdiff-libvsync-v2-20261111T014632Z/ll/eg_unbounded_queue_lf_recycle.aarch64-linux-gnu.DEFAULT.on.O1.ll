; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, [112 x i8], %struct.vqueue_ub_node_s }
%struct.vatomicptr_s = type { ptr }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, [112 x i8] }

@local_pools = local_unnamed_addr global [12 x ptr] zeroinitializer, align 8
@.str.2 = private unnamed_addr constant [6 x i8] c"qnode\00", align 1
@.str.3 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c\00", align 1
@__PRETTY_FUNCTION__.alloc_qnode = private unnamed_addr constant [39 x i8] c"vqueue_ub_node_t *alloc_qnode(vsize_t)\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 128
@.str.4 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.5 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@.str.6 = private unnamed_addr constant [48 x i8] c"((((vuintptr_t)(v)) & ((vuintptr_t)0x7F)) == 0)\00", align 1
@.str.7 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/include/vsync/atomic/atomicptr_stamped.h\00", align 1
@__PRETTY_FUNCTION__.vatomicptr_stamped_set = private unnamed_addr constant [70 x i8] c"void vatomicptr_stamped_set(vatomicptr_stamped_t *, void *, vuint8_t)\00", align 1
@__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg = private unnamed_addr constant [95 x i8] c"vbool_t vatomicptr_stamped_cmpxchg(vatomicptr_stamped_t *, void *, vuint8_t, void *, vuint8_t)\00", align 1
@str = private unnamed_addr constant [15 x i8] c"New allocation\00", align 1
@str.11 = private unnamed_addr constant [19 x i8] c"Recycle allocation\00", align 1

; Function Attrs: nounwind uwtable
define void @destroy_pools() local_unnamed_addr #0 {
  br label %2

1:                                                ; preds = %15
  ret void

2:                                                ; preds = %0, %15
  %3 = phi i64 [ 0, %0 ], [ %16, %15 ]
  %4 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %3
  %5 = load ptr, ptr %4, align 8, !tbaa !6
  %6 = icmp eq ptr %5, null
  br i1 %6, label %15, label %7

7:                                                ; preds = %2, %7
  %8 = phi ptr [ %13, %7 ], [ %5, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 8
  %10 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %9) #11, !srcloc !11
  %11 = ptrtoint ptr %10 to i64
  %12 = and i64 %11, -128
  %13 = inttoptr i64 %12 to ptr
  tail call void @free(ptr noundef %8) #11
  %14 = icmp eq i64 %12, 0
  br i1 %14, label %15, label %7, !llvm.loop !12

15:                                               ; preds = %7, %2
  %16 = add nuw nsw i64 %3, 1
  %17 = icmp eq i64 %16, 12
  br i1 %17, label %1, label %2, !llvm.loop !15
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #3 {
  tail call void @free(ptr noundef %0) #11
  ret void
}

; Function Attrs: nounwind uwtable
define void @retire_cb(ptr noundef %0, ptr noundef %1) local_unnamed_addr #0 {
  %3 = ptrtoint ptr %1 to i64
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %4) #11, !srcloc !11
  %6 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %3
  %7 = load ptr, ptr %6, align 8, !tbaa !6
  %8 = ptrtoint ptr %7 to i64
  %9 = and i64 %8, 127
  %10 = icmp eq i64 %9, 0
  br i1 %10, label %12, label %11

11:                                               ; preds = %2
  tail call void @__assert_fail(ptr noundef nonnull @.str.6, ptr noundef nonnull @.str.7, i32 noundef 291, ptr noundef nonnull @__PRETTY_FUNCTION__.vatomicptr_stamped_set) #12
  unreachable

12:                                               ; preds = %2
  %13 = ptrtoint ptr %5 to i64
  %14 = add i64 %13, 1
  %15 = and i64 %14, 127
  %16 = or disjoint i64 %15, %8
  %17 = inttoptr i64 %16 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %17, ptr nonnull elementtype(ptr) %4) #11, !srcloc !16
  store ptr %0, ptr %6, align 8, !tbaa !6
  ret void
}

; Function Attrs: nounwind uwtable
define nonnull ptr @alloc_qnode(i64 noundef %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %0
  %3 = load ptr, ptr %2, align 8, !tbaa !6
  %4 = icmp eq ptr %3, null
  br i1 %4, label %11, label %5

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %7 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %6) #11, !srcloc !11
  %8 = ptrtoint ptr %7 to i64
  %9 = and i64 %8, -128
  %10 = inttoptr i64 %9 to ptr
  store ptr %10, ptr %2, align 8, !tbaa !6
  br label %13

11:                                               ; preds = %1
  %12 = tail call noalias align 128 dereferenceable_or_null(128) ptr @memalign(i64 noundef 128, i64 noundef 128) #13
  br label %13

13:                                               ; preds = %11, %5
  %14 = phi ptr [ @str, %11 ], [ @str.11, %5 ]
  %15 = phi ptr [ %12, %11 ], [ %3, %5 ]
  %16 = tail call i32 @puts(ptr nonnull dereferenceable(1) %14)
  %17 = icmp eq ptr %15, null
  br i1 %17, label %18, label %19

18:                                               ; preds = %13
  tail call void @__assert_fail(ptr noundef nonnull @.str.2, ptr noundef nonnull @.str.3, i32 noundef 77, ptr noundef nonnull @__PRETTY_FUNCTION__.alloc_qnode) #12
  unreachable

19:                                               ; preds = %13
  ret ptr %15
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @memalign(i64 allocalign noundef, i64 noundef) local_unnamed_addr #5

; Function Attrs: cold noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #0 {
  %2 = ptrtoint ptr %0 to i64
  %3 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %2
  %4 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %2
  br label %5

5:                                                ; preds = %1, %141
  %6 = phi i64 [ 0, %1 ], [ %142, %141 ]
  br label %8

7:                                                ; preds = %141
  ret ptr null

8:                                                ; preds = %48, %5
  %9 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !11
  %10 = ptrtoint ptr %9 to i64
  %11 = and i64 %10, -128
  %12 = inttoptr i64 %11 to ptr
  %13 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !11
  %14 = ptrtoint ptr %13 to i64
  %15 = getelementptr inbounds nuw i8, ptr %12, i64 8
  %16 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %15) #11, !srcloc !11
  %17 = ptrtoint ptr %16 to i64
  %18 = and i64 %17, -128
  %19 = inttoptr i64 %18 to ptr
  %20 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !11
  %21 = ptrtoint ptr %20 to i64
  %22 = and i64 %21, -128
  %23 = icmp eq i64 %11, %22
  %24 = xor i64 %21, %10
  %25 = and i64 %24, 127
  %26 = icmp eq i64 %25, 0
  %27 = select i1 %23, i1 %26, i1 false
  br i1 %27, label %28, label %48

28:                                               ; preds = %8
  %29 = and i64 %14, -128
  %30 = icmp eq i64 %11, %29
  br i1 %30, label %31, label %39

31:                                               ; preds = %28
  %32 = icmp eq i64 %18, 0
  br i1 %32, label %64, label %33

33:                                               ; preds = %31
  %34 = add i64 %14, 1
  %35 = and i64 %34, 127
  %36 = or disjoint i64 %35, %18
  %37 = inttoptr i64 %36 to ptr
  %38 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %37, ptr %13, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !17
  br label %48

39:                                               ; preds = %28
  %40 = load ptr, ptr %19, align 128, !tbaa !18
  %41 = add i64 %10, 1
  %42 = and i64 %41, 127
  %43 = or disjoint i64 %18, %42
  %44 = inttoptr i64 %43 to ptr
  %45 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr %44, ptr %9, ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !17
  %46 = extractvalue { ptr, i32 } %45, 0
  %47 = icmp eq ptr %46, %9
  br i1 %47, label %49, label %48

48:                                               ; preds = %39, %33, %8
  br label %8, !llvm.loop !21

49:                                               ; preds = %39
  %50 = icmp eq i64 %11, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %50, label %64, label %51

51:                                               ; preds = %49
  %52 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %15) #11, !srcloc !11
  %53 = load ptr, ptr %3, align 8, !tbaa !6
  %54 = ptrtoint ptr %53 to i64
  %55 = and i64 %54, 127
  %56 = icmp eq i64 %55, 0
  br i1 %56, label %58, label %57

57:                                               ; preds = %51
  tail call void @__assert_fail(ptr noundef nonnull @.str.6, ptr noundef nonnull @.str.7, i32 noundef 291, ptr noundef nonnull @__PRETTY_FUNCTION__.vatomicptr_stamped_set) #12
  unreachable

58:                                               ; preds = %51
  %59 = ptrtoint ptr %52 to i64
  %60 = add i64 %59, 1
  %61 = and i64 %60, 127
  %62 = or disjoint i64 %61, %54
  %63 = inttoptr i64 %62 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %63, ptr nonnull elementtype(ptr) %15) #11, !srcloc !16
  store ptr %12, ptr %3, align 8, !tbaa !6
  br label %64

64:                                               ; preds = %31, %49, %58
  %65 = phi ptr [ %40, %58 ], [ %40, %49 ], [ null, %31 ]
  %66 = icmp eq ptr %65, null
  br i1 %66, label %67, label %138

67:                                               ; preds = %64
  %68 = tail call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #14
  store i64 %6, ptr %68, align 8, !tbaa !22
  %69 = load ptr, ptr %4, align 8, !tbaa !6
  %70 = icmp eq ptr %69, null
  br i1 %70, label %77, label %71

71:                                               ; preds = %67
  %72 = getelementptr inbounds nuw i8, ptr %69, i64 8
  %73 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %72) #11, !srcloc !11
  %74 = ptrtoint ptr %73 to i64
  %75 = and i64 %74, -128
  %76 = inttoptr i64 %75 to ptr
  store ptr %76, ptr %4, align 8, !tbaa !6
  br label %79

77:                                               ; preds = %67
  %78 = tail call noalias align 128 dereferenceable_or_null(128) ptr @memalign(i64 noundef 128, i64 noundef 128) #13
  br label %79

79:                                               ; preds = %77, %71
  %80 = phi ptr [ @str, %77 ], [ @str.11, %71 ]
  %81 = phi ptr [ %78, %77 ], [ %69, %71 ]
  %82 = tail call i32 @puts(ptr nonnull dereferenceable(1) %80)
  %83 = icmp eq ptr %81, null
  br i1 %83, label %84, label %85

84:                                               ; preds = %79
  tail call void @__assert_fail(ptr noundef nonnull @.str.2, ptr noundef nonnull @.str.3, i32 noundef 77, ptr noundef nonnull @__PRETTY_FUNCTION__.alloc_qnode) #12
  unreachable

85:                                               ; preds = %79
  %86 = load i64, ptr %68, align 8, !tbaa !22
  %87 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, i64 noundef %2, i64 noundef %86)
  store ptr %68, ptr %81, align 128, !tbaa !18
  %88 = getelementptr inbounds nuw i8, ptr %81, i64 8
  %89 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %88) #11, !srcloc !11
  %90 = ptrtoint ptr %89 to i64
  %91 = and i64 %90, 127
  %92 = inttoptr i64 %91 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %92, ptr nonnull elementtype(ptr) %88) #11, !srcloc !16
  %93 = ptrtoint ptr %81 to i64
  %94 = and i64 %93, 127
  %95 = icmp eq i64 %94, 0
  br label %96

96:                                               ; preds = %131, %85
  %97 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !11
  %98 = ptrtoint ptr %97 to i64
  %99 = and i64 %98, -128
  %100 = inttoptr i64 %99 to ptr
  %101 = getelementptr inbounds nuw i8, ptr %100, i64 8
  %102 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %101) #11, !srcloc !11
  %103 = ptrtoint ptr %102 to i64
  %104 = and i64 %103, -128
  %105 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !11
  %106 = ptrtoint ptr %105 to i64
  %107 = and i64 %106, -128
  %108 = icmp eq i64 %99, %107
  %109 = xor i64 %106, %98
  %110 = and i64 %109, 127
  %111 = icmp eq i64 %110, 0
  %112 = select i1 %108, i1 %111, i1 false
  br i1 %112, label %113, label %131

113:                                              ; preds = %96
  %114 = icmp eq i64 %104, 0
  br i1 %114, label %115, label %125

115:                                              ; preds = %113
  br i1 %95, label %117, label %116

116:                                              ; preds = %115
  tail call void @__assert_fail(ptr noundef nonnull @.str.6, ptr noundef nonnull @.str.7, i32 noundef 87, ptr noundef nonnull @__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg) #12
  unreachable

117:                                              ; preds = %115
  %118 = add nuw nsw i64 %103, 1
  %119 = and i64 %118, 127
  %120 = or disjoint i64 %119, %93
  %121 = inttoptr i64 %120 to ptr
  %122 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %121, ptr %102, ptr nonnull elementtype(ptr) %101) #11, !srcloc !17
  %123 = extractvalue { ptr, i32 } %122, 0
  %124 = icmp eq ptr %123, %102
  br i1 %124, label %132, label %131

125:                                              ; preds = %113
  %126 = add i64 %98, 1
  %127 = and i64 %126, 127
  %128 = or disjoint i64 %127, %104
  %129 = inttoptr i64 %128 to ptr
  %130 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %129, ptr %97, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !17
  br label %131

131:                                              ; preds = %125, %117, %96
  br label %96, !llvm.loop !25

132:                                              ; preds = %117
  %133 = add i64 %98, 1
  %134 = and i64 %133, 127
  %135 = or disjoint i64 %134, %93
  %136 = inttoptr i64 %135 to ptr
  %137 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %136, ptr %97, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !17
  br label %141

138:                                              ; preds = %64
  %139 = load i64, ptr %65, align 8, !tbaa !22
  %140 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.5, i64 noundef %2, i64 noundef %139)
  tail call void @free(ptr noundef %65) #11
  br label %141

141:                                              ; preds = %132, %138
  %142 = add nuw nsw i64 %6, 1
  %143 = icmp eq i64 %142, 100
  br i1 %143, label %7, label %5, !llvm.loop !26
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [12 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #11
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 136)) #11, !srcloc !27
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 128), ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !27
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 128), ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !27
  br label %2

2:                                                ; preds = %0, %2
  %3 = phi i64 [ 0, %0 ], [ %7, %2 ]
  %4 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %3
  %5 = inttoptr i64 %3 to ptr
  %6 = call i32 @pthread_create(ptr noundef nonnull %4, ptr noundef null, ptr noundef nonnull @run, ptr noundef %5) #11
  %7 = add nuw nsw i64 %3, 1
  %8 = icmp eq i64 %7, 12
  br i1 %8, label %9, label %2, !llvm.loop !28

9:                                                ; preds = %2, %9
  %10 = phi i64 [ %14, %9 ], [ 0, %2 ]
  %11 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %10
  %12 = load i64, ptr %11, align 8, !tbaa !29
  %13 = call i32 @pthread_join(i64 noundef %12, ptr noundef null) #11
  %14 = add nuw nsw i64 %10, 1
  %15 = icmp eq i64 %14, 12
  br i1 %15, label %16, label %9, !llvm.loop !30

16:                                               ; preds = %9, %63
  %17 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !11
  %18 = ptrtoint ptr %17 to i64
  %19 = and i64 %18, -128
  %20 = inttoptr i64 %19 to ptr
  %21 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !11
  %22 = ptrtoint ptr %21 to i64
  %23 = getelementptr inbounds nuw i8, ptr %20, i64 8
  %24 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %23) #11, !srcloc !11
  %25 = ptrtoint ptr %24 to i64
  %26 = and i64 %25, -128
  %27 = inttoptr i64 %26 to ptr
  %28 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !11
  %29 = ptrtoint ptr %28 to i64
  %30 = and i64 %29, -128
  %31 = icmp eq i64 %19, %30
  %32 = xor i64 %29, %18
  %33 = and i64 %32, 127
  %34 = icmp eq i64 %33, 0
  %35 = select i1 %31, i1 %34, i1 false
  br i1 %35, label %36, label %63

36:                                               ; preds = %16
  %37 = and i64 %22, -128
  %38 = icmp eq i64 %19, %37
  br i1 %38, label %39, label %47

39:                                               ; preds = %36
  %40 = icmp eq i64 %26, 0
  br i1 %40, label %59, label %41

41:                                               ; preds = %39
  %42 = add i64 %22, 1
  %43 = and i64 %42, 127
  %44 = or disjoint i64 %43, %26
  %45 = inttoptr i64 %44 to ptr
  %46 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %45, ptr %21, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #11, !srcloc !17
  br label %63

47:                                               ; preds = %36
  %48 = load ptr, ptr %27, align 128, !tbaa !18
  %49 = add i64 %18, 1
  %50 = and i64 %49, 127
  %51 = or disjoint i64 %26, %50
  %52 = inttoptr i64 %51 to ptr
  %53 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr %52, ptr %17, ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !17
  %54 = extractvalue { ptr, i32 } %53, 0
  %55 = icmp eq ptr %54, %17
  br i1 %55, label %56, label %63

56:                                               ; preds = %47
  %57 = icmp eq i64 %19, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %57, label %59, label %58

58:                                               ; preds = %56
  call void @free(ptr noundef %20) #11
  br label %59

59:                                               ; preds = %39, %56, %58
  %60 = phi ptr [ %48, %58 ], [ %48, %56 ], [ null, %39 ]
  %61 = icmp eq ptr %60, null
  br i1 %61, label %64, label %62

62:                                               ; preds = %59
  call void @free(ptr noundef %60) #11
  br label %63

63:                                               ; preds = %62, %47, %41, %16
  br label %16, !llvm.loop !21

64:                                               ; preds = %59
  %65 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #11, !srcloc !11
  %66 = ptrtoint ptr %65 to i64
  %67 = and i64 %66, -128
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %80, label %69

69:                                               ; preds = %64, %76
  %70 = phi i64 [ %78, %76 ], [ %67, %64 ]
  %71 = inttoptr i64 %70 to ptr
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 8
  %73 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %72) #11, !srcloc !11
  %74 = icmp eq i64 %70, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %74, label %76, label %75

75:                                               ; preds = %69
  call void @free(ptr noundef nonnull %71) #11
  br label %76

76:                                               ; preds = %75, %69
  %77 = ptrtoint ptr %73 to i64
  %78 = and i64 %77, -128
  %79 = icmp eq i64 %78, 0
  br i1 %79, label %80, label %69, !llvm.loop !31

80:                                               ; preds = %76, %64
  br label %81

81:                                               ; preds = %80, %94
  %82 = phi i64 [ %95, %94 ], [ 0, %80 ]
  %83 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %82
  %84 = load ptr, ptr %83, align 8, !tbaa !6
  %85 = icmp eq ptr %84, null
  br i1 %85, label %94, label %86

86:                                               ; preds = %81, %86
  %87 = phi ptr [ %92, %86 ], [ %84, %81 ]
  %88 = getelementptr inbounds nuw i8, ptr %87, i64 8
  %89 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %88) #11, !srcloc !11
  %90 = ptrtoint ptr %89 to i64
  %91 = and i64 %90, -128
  %92 = inttoptr i64 %91 to ptr
  call void @free(ptr noundef %87) #11
  %93 = icmp eq i64 %91, 0
  br i1 %93, label %94, label %86, !llvm.loop !12

94:                                               ; preds = %86, %81
  %95 = add nuw nsw i64 %82, 1
  %96 = icmp eq i64 %95, 12
  br i1 %96, label %97, label %81, !llvm.loop !15

97:                                               ; preds = %94
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #11
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #10

attributes #0 = { nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #3 = { mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #6 = { cold noreturn nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #7 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #8 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #9 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #10 = { nofree nounwind }
attributes #11 = { nounwind }
attributes #12 = { cold noreturn nounwind }
attributes #13 = { nounwind allocsize(1) }
attributes #14 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{!7, !7, i64 0}
!7 = !{!"p1 _ZTS16vqueue_ub_node_s", !8, i64 0}
!8 = !{!"any pointer", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{i64 448035}
!12 = distinct !{!12, !13, !14}
!13 = !{!"llvm.loop.mustprogress"}
!14 = !{!"llvm.loop.unroll.disable"}
!15 = distinct !{!15, !13, !14}
!16 = !{i64 452425}
!17 = !{i64 518862, i64 518897, i64 518913, i64 518947, i64 518982, i64 519003, i64 519047, i64 519077}
!18 = !{!19, !8, i64 0}
!19 = !{!"vqueue_ub_node_s", !8, i64 0, !20, i64 8}
!20 = !{!"vatomicptr_s", !8, i64 0}
!21 = distinct !{!21, !14}
!22 = !{!23, !24, i64 0}
!23 = !{!"data_s", !24, i64 0}
!24 = !{!"long", !9, i64 0}
!25 = distinct !{!25, !14}
!26 = distinct !{!26, !13, !14}
!27 = !{i64 453395}
!28 = distinct !{!28, !13, !14}
!29 = !{!24, !24, i64 0}
!30 = distinct !{!30, !13, !14}
!31 = distinct !{!31, !13, !14}
