; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s, [8 x i8] }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i32, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = local_unnamed_addr global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = local_unnamed_addr global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"ret == 0\00", align 1
@.str.4 = private unnamed_addr constant [42 x i8] c"C:/rc1111/src/libvsync/examples/eg_vebr.c\00", align 1
@__PRETTY_FUNCTION__.main = private unnamed_addr constant [15 x i8] c"int main(void)\00", align 1
@__PRETTY_FUNCTION__.lock_acq = private unnamed_addr constant [22 x i8] c"void lock_acq(void *)\00", align 1
@__PRETTY_FUNCTION__.lock_rel = private unnamed_addr constant [22 x i8] c"void lock_rel(void *)\00", align 1
@.str.6 = private unnamed_addr constant [47 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/ebr.h\00", align 1
@.str.8 = private unnamed_addr constant [67 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/smr_nodes_list.h\00", align 1
@.str.13 = private unnamed_addr constant [41 x i8] c"lcl_epoch == 0 || lcl_epoch >= glb_epoch\00", align 1
@__PRETTY_FUNCTION__.vebr_recycle = private unnamed_addr constant [31 x i8] c"vsize_t vebr_recycle(vebr_t *)\00", align 1
@.str.14 = private unnamed_addr constant [23 x i8] c"ret_epoch >= glb_epoch\00", align 1
@.str.15 = private unnamed_addr constant [24 x i8] c"freed_node->destroy_fun\00", align 1
@__PRETTY_FUNCTION__.smr_nodes_list_destroy = private unnamed_addr constant [45 x i8] c"vsize_t smr_nodes_list_destroy(smr_node_t *)\00", align 1
@.str.19 = private unnamed_addr constant [61 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/dbl_list.h\00", align 1
@.str.21 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/include/vsync/queue/unbounded_queue_lf.h\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_deq = private unnamed_addr constant [69 x i8] c"void *vqueue_ub_deq(vqueue_ub_t *, vqueue_ub_node_handler_t, void *)\00", align 1
@.str.24 = private unnamed_addr constant [75 x i8] c"next && \22next is not expected to be NULL, since the queue is \22 \22not empty\22\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_enq = private unnamed_addr constant [62 x i8] c"void vqueue_ub_enq(vqueue_ub_t *, vqueue_ub_node_t *, void *)\00", align 1
@.str.25 = private unnamed_addr constant [6 x i8] c"qnode\00", align 1
@__PRETTY_FUNCTION__.vebr_exit = private unnamed_addr constant [42 x i8] c"void vebr_exit(vebr_t *, vebr_thread_t *)\00", align 1
@.str.27 = private unnamed_addr constant [22 x i8] c"ebr_thrd->enter_count\00", align 1
@__PRETTY_FUNCTION__.vebr_deregister = private unnamed_addr constant [48 x i8] c"void vebr_deregister(vebr_t *, vebr_thread_t *)\00", align 1
@.str.28 = private unnamed_addr constant [48 x i8] c"vatomic64_read_rlx(&ebr_thrd->epoch_local) == 0\00", align 1
@__PRETTY_FUNCTION__.dbl_list_rem = private unnamed_addr constant [51 x i8] c"void dbl_list_rem(dbl_list_t *, dbl_list_node_t *)\00", align 1
@.str.29 = private unnamed_addr constant [19 x i8] c"prev->next == node\00", align 1
@.str.30 = private unnamed_addr constant [19 x i8] c"list->head != node\00", align 1
@.str.31 = private unnamed_addr constant [19 x i8] c"list->head == node\00", align 1
@.str.32 = private unnamed_addr constant [19 x i8] c"succ->prev == node\00", align 1
@__PRETTY_FUNCTION__.vebr_init = private unnamed_addr constant [41 x i8] c"void vebr_init(vebr_t *, smr_lock_lib_t)\00", align 1
@.str.34 = private unnamed_addr constant [31 x i8] c"smr_lock_lib_is_set(&lock_lib)\00", align 1

; Function Attrs: inlinehint nounwind optsize uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_lock(ptr noundef %0) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %1
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 24, ptr noundef nonnull @__PRETTY_FUNCTION__.lock_acq) #14
  unreachable

5:                                                ; preds = %1
  ret void
}

; Function Attrs: inlinehint nounwind optsize uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %1
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 32, ptr noundef nonnull @__PRETTY_FUNCTION__.lock_rel) #14
  unreachable

5:                                                ; preds = %1
  ret void
}

; Function Attrs: mustprogress nounwind optsize willreturn uwtable
define void @free_cb(ptr noundef %0, ptr nocapture readnone %1) #1 {
  %3 = ptrtoint ptr %0 to i64
  %4 = add i64 %3, -16
  %5 = inttoptr i64 %4 to ptr
  tail call void @free(ptr noundef %5) #13
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind optsize uwtable
define void @retire_cb(ptr noundef initializes((16, 24), (32, 48)) %0, ptr nocapture readnone %1) local_unnamed_addr #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !7
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !9
  %5 = urem i64 %4, 3
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr @free_cb, ptr %7, align 8, !tbaa !10
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store ptr null, ptr %8, align 8, !tbaa !18
  store ptr null, ptr %3, align 8, !tbaa !19
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %9 = load atomic i64, ptr %6 seq_cst, align 8
  %10 = inttoptr i64 %9 to ptr
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %11 = ptrtoint ptr %3 to i64
  br label %12

12:                                               ; preds = %12, %2
  %13 = phi ptr [ %10, %2 ], [ %19, %12 ]
  store ptr %13, ptr %3, align 8, !tbaa !22
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !23
  %14 = ptrtoint ptr %13 to i64
  %15 = cmpxchg ptr %6, i64 %14, i64 %11 release monotonic, align 8
  %16 = extractvalue { i64, i1 } %15, 1
  %17 = extractvalue { i64, i1 } %15, 0
  %18 = inttoptr i64 %17 to ptr
  %19 = select i1 %16, ptr %13, ptr %18
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !24
  %20 = icmp eq ptr %13, %19
  br i1 %20, label %21, label %12, !llvm.loop !25

21:                                               ; preds = %12
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !27
  %23 = atomicrmw add ptr %22, i64 1 monotonic, align 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !28
  ret void
}

; Function Attrs: mustprogress nounwind optsize willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #5 {
  tail call void @free(ptr noundef %0) #13
  ret void
}

; Function Attrs: nounwind optsize uwtable
define void @reclaim() local_unnamed_addr #4 {
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !29
  %1 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !30
  %2 = icmp eq i8 %1, 0
  br i1 %2, label %3, label %69

3:                                                ; preds = %0, %66
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !7
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !9
  %5 = add i64 %4, 2
  %6 = urem i64 %5, 3
  %7 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %6
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !31
  %8 = atomicrmw xchg ptr %7, i64 0 acquire, align 8
  %9 = inttoptr i64 %8 to ptr
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !32
  %10 = getelementptr inbounds nuw i8, ptr %7, i64 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !33
  store atomic i64 0, ptr %10 monotonic, align 16
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !34
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !35
  %12 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  tail call void %11(ptr noundef %12) #13
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !43
  %14 = icmp eq ptr %13, null
  br i1 %14, label %31, label %15

15:                                               ; preds = %3, %27
  %16 = phi ptr [ %29, %27 ], [ %13, %3 ]
  %17 = phi i64 [ %28, %27 ], [ -1, %3 ]
  %18 = getelementptr inbounds nuw i8, ptr %16, i64 16
  br label %19

19:                                               ; preds = %22, %15
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !8
  %20 = load atomic i64, ptr %18 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !9
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %27, label %22

22:                                               ; preds = %19
  %23 = icmp ult i64 %20, %4
  br i1 %23, label %19, label %24

24:                                               ; preds = %22
  %25 = tail call i64 @llvm.umin.i64(i64 %17, i64 %20)
  %26 = freeze i64 %25
  br label %27

27:                                               ; preds = %19, %24
  %28 = phi i64 [ %26, %24 ], [ %17, %19 ]
  %29 = load ptr, ptr %16, align 8, !tbaa !43
  %30 = icmp eq ptr %29, null
  br i1 %30, label %31, label %15, !llvm.loop !44

31:                                               ; preds = %27, %3
  %32 = phi i64 [ -1, %3 ], [ %28, %27 ]
  %33 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !45
  %34 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  tail call void %33(ptr noundef %34) #13
  %35 = icmp eq i64 %32, -1
  br i1 %35, label %41, label %36

36:                                               ; preds = %31
  %37 = icmp ne i64 %32, 0
  %38 = icmp ult i64 %32, %4
  %39 = and i1 %37, %38
  br i1 %39, label %40, label %41

40:                                               ; preds = %36
  tail call void @__assert_fail(ptr noundef nonnull @.str.13, ptr noundef nonnull @.str.6, i32 noundef 285, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_recycle) #14
  unreachable

41:                                               ; preds = %36, %31
  %42 = add i64 %4, 1
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !46
  %43 = cmpxchg ptr @g_vebr, i64 %4, i64 %42 seq_cst seq_cst, align 8
  %44 = extractvalue { i64, i1 } %43, 0
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !47
  %45 = icmp ult i64 %44, %4
  br i1 %45, label %46, label %47

46:                                               ; preds = %41
  tail call void @__assert_fail(ptr noundef nonnull @.str.14, ptr noundef nonnull @.str.6, i32 noundef 298, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_recycle) #14
  unreachable

47:                                               ; preds = %41
  %48 = icmp eq i64 %8, 0
  br i1 %48, label %66, label %49

49:                                               ; preds = %47, %56
  %50 = phi ptr [ %57, %56 ], [ %9, %47 ]
  %51 = phi i64 [ %60, %56 ], [ 0, %47 ]
  %52 = getelementptr inbounds nuw i8, ptr %50, i64 16
  %53 = load ptr, ptr %52, align 8, !tbaa !10
  %54 = icmp eq ptr %53, null
  br i1 %54, label %55, label %56

55:                                               ; preds = %49
  tail call void @__assert_fail(ptr noundef nonnull @.str.15, ptr noundef nonnull @.str.8, i32 noundef 197, ptr noundef nonnull @__PRETTY_FUNCTION__.smr_nodes_list_destroy) #14
  unreachable

56:                                               ; preds = %49
  %57 = load ptr, ptr %50, align 8, !tbaa !19
  %58 = getelementptr inbounds nuw i8, ptr %50, i64 24
  %59 = load ptr, ptr %58, align 8, !tbaa !18
  tail call void %53(ptr noundef nonnull %50, ptr noundef %59) #13
  %60 = add i64 %51, 1
  %61 = icmp eq ptr %57, null
  br i1 %61, label %62, label %49, !llvm.loop !48

62:                                               ; preds = %56
  %63 = icmp eq i64 %60, 0
  br i1 %63, label %66, label %64

64:                                               ; preds = %62
  %65 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %60) #16
  br label %66

66:                                               ; preds = %47, %64, %62
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !29
  %67 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !30
  %68 = icmp eq i8 %67, 0
  br i1 %68, label %3, label %69, !llvm.loop !49

69:                                               ; preds = %66, %0
  ret void
}

; Function Attrs: nofree nounwind optsize
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #6

; Function Attrs: nounwind optsize uwtable
define noundef ptr @run(ptr noundef %0) #4 {
  %2 = alloca %struct.vebr_instance_s, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #15
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq ptr %0, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  tail call void @reclaim() #16
  br label %132

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 16
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !50
  store atomic i64 0, ptr %7 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !51
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store i32 0, ptr %8, align 8, !tbaa !52
  %9 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !35
  %10 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  tail call void %9(ptr noundef %10) #13
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  store ptr %11, ptr %2, align 8, !tbaa !56
  %12 = icmp eq ptr %11, null
  br i1 %12, label %15, label %13

13:                                               ; preds = %6
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store ptr %2, ptr %14, align 8, !tbaa !57
  br label %15

15:                                               ; preds = %6, %13
  store ptr %2, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store ptr null, ptr %16, align 8, !tbaa !57
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %18 = add i64 %17, 1
  store i64 %18, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %19 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !45
  %20 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  call void %19(ptr noundef %20) #13
  %21 = load i32, ptr %8, align 8, !tbaa !52
  br label %58

22:                                               ; preds = %127
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !59
  %23 = load atomic i64, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !60
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %26, label %25

25:                                               ; preds = %22
  call void @__assert_fail(ptr noundef nonnull @.str.28, ptr noundef nonnull @.str.6, i32 noundef 165, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_deregister) #14
  unreachable

26:                                               ; preds = %22
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !35
  %28 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  call void %27(ptr noundef %28) #13
  %29 = load ptr, ptr %2, align 8, !tbaa !56
  %30 = load ptr, ptr %16, align 8, !tbaa !57
  %31 = icmp eq ptr %30, null
  br i1 %31, label %40, label %32

32:                                               ; preds = %26
  %33 = load ptr, ptr %30, align 8, !tbaa !56
  %34 = icmp eq ptr %33, %2
  br i1 %34, label %36, label %35

35:                                               ; preds = %32
  call void @__assert_fail(ptr noundef nonnull @.str.29, ptr noundef nonnull @.str.19, i32 noundef 62, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

36:                                               ; preds = %32
  %37 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  %38 = icmp eq ptr %37, %2
  br i1 %38, label %39, label %44

39:                                               ; preds = %36
  call void @__assert_fail(ptr noundef nonnull @.str.30, ptr noundef nonnull @.str.19, i32 noundef 63, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

40:                                               ; preds = %26
  %41 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  %42 = icmp eq ptr %41, %2
  br i1 %42, label %44, label %43

43:                                               ; preds = %40
  call void @__assert_fail(ptr noundef nonnull @.str.31, ptr noundef nonnull @.str.19, i32 noundef 66, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

44:                                               ; preds = %40, %36
  %45 = phi ptr [ %30, %36 ], [ getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), %40 ]
  store ptr %29, ptr %45, align 8, !tbaa !43
  %46 = icmp eq ptr %29, null
  br i1 %46, label %53, label %47

47:                                               ; preds = %44
  %48 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %49 = load ptr, ptr %48, align 8, !tbaa !57
  %50 = icmp eq ptr %49, %2
  br i1 %50, label %52, label %51

51:                                               ; preds = %47
  call void @__assert_fail(ptr noundef nonnull @.str.32, ptr noundef nonnull @.str.19, i32 noundef 71, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

52:                                               ; preds = %47
  store ptr %30, ptr %48, align 8, !tbaa !57
  br label %53

53:                                               ; preds = %44, %52
  %54 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %55 = add i64 %54, -1
  store i64 %55, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %56 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !45
  %57 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  call void %56(ptr noundef %57) #13
  br label %132

58:                                               ; preds = %15, %127
  %59 = phi i32 [ %21, %15 ], [ %129, %127 ]
  %60 = phi i64 [ 0, %15 ], [ %130, %127 ]
  %61 = add i32 %59, 1
  store i32 %61, ptr %8, align 8, !tbaa !52
  %62 = icmp eq i32 %59, 0
  br i1 %62, label %63, label %65

63:                                               ; preds = %58
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !8
  %64 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !9
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !61
  store atomic i64 %64, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !62
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !6
  fence seq_cst
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !7
  br label %65

65:                                               ; preds = %58, %63
  br label %66

66:                                               ; preds = %87, %65
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %67 = load atomic i64, ptr @g_queue seq_cst, align 8
  %68 = inttoptr i64 %67 to ptr
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %69 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %70 = getelementptr inbounds nuw i8, ptr %68, i64 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %71 = load atomic i64, ptr %70 seq_cst, align 8
  %72 = inttoptr i64 %71 to ptr
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %73 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %74 = icmp eq i64 %67, %73
  br i1 %74, label %75, label %87

75:                                               ; preds = %66
  %76 = icmp eq i64 %67, %69
  %77 = icmp eq i64 %71, 0
  br i1 %76, label %78, label %81

78:                                               ; preds = %75
  br i1 %77, label %93, label %79

79:                                               ; preds = %78
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !63
  %80 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %67, i64 %71 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !64
  br label %87

81:                                               ; preds = %75
  br i1 %77, label %82, label %83

82:                                               ; preds = %81
  call void @__assert_fail(ptr noundef nonnull @.str.24, ptr noundef nonnull @.str.21, i32 noundef 208, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_deq) #14
  unreachable

83:                                               ; preds = %81
  %84 = load ptr, ptr %72, align 8, !tbaa !65
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !63
  %85 = cmpxchg ptr @g_queue, i64 %67, i64 %71 seq_cst seq_cst, align 8
  %86 = extractvalue { i64, i1 } %85, 1
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !64
  br i1 %86, label %88, label %87

87:                                               ; preds = %83, %79, %66
  br label %66

88:                                               ; preds = %83
  %89 = icmp eq i64 %67, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %89, label %91, label %90

90:                                               ; preds = %88
  call void @retire_cb(ptr noundef nonnull %68, ptr nonnull poison) #13, !callees !68
  br label %91

91:                                               ; preds = %88, %90
  %92 = icmp eq ptr %84, null
  br i1 %92, label %93, label %119

93:                                               ; preds = %78, %91
  %94 = call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #17
  store i64 %60, ptr %94, align 8, !tbaa !69
  %95 = call noalias dereferenceable_or_null(48) ptr @malloc(i64 noundef 48) #17
  %96 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef %3, i64 noundef %60) #16
  %97 = icmp eq ptr %95, null
  br i1 %97, label %98, label %99

98:                                               ; preds = %93
  call void @__assert_fail(ptr noundef nonnull @.str.25, ptr noundef nonnull @.str.21, i32 noundef 113, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_enq) #14
  unreachable

99:                                               ; preds = %93
  store ptr %94, ptr %95, align 8, !tbaa !65
  %100 = getelementptr inbounds nuw i8, ptr %95, i64 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !71
  store atomic i64 0, ptr %100 monotonic, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !72
  %101 = ptrtoint ptr %95 to i64
  br label %102

102:                                              ; preds = %116, %99
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %103 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  %104 = inttoptr i64 %103 to ptr
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %106 = load atomic i64, ptr %105 seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %107 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %108 = icmp eq i64 %103, %107
  br i1 %108, label %109, label %116

109:                                              ; preds = %102
  %110 = icmp eq i64 %106, 0
  call void asm sideeffect "", "~{memory}"() #15
  br i1 %110, label %111, label %114

111:                                              ; preds = %109
  %112 = cmpxchg ptr %105, i64 0, i64 %101 seq_cst seq_cst, align 8
  %113 = extractvalue { i64, i1 } %112, 1
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !64
  br i1 %113, label %117, label %116

114:                                              ; preds = %109
  %115 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %103, i64 %106 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !64
  br label %116

116:                                              ; preds = %114, %111, %102
  br label %102

117:                                              ; preds = %111
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !63
  %118 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %103, i64 %101 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !64
  br label %122

119:                                              ; preds = %91
  %120 = load i64, ptr %84, align 8, !tbaa !69
  %121 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %3, i64 noundef %120) #16
  call void @free(ptr noundef nonnull %84) #13
  br label %122

122:                                              ; preds = %119, %117
  %123 = load i32, ptr %8, align 8, !tbaa !52
  switch i32 %123, label %127 [
    i32 0, label %124
    i32 1, label %125
  ]

124:                                              ; preds = %122
  call void @__assert_fail(ptr noundef nonnull @.str.27, ptr noundef nonnull @.str.6, i32 noundef 210, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_exit) #14
  unreachable

125:                                              ; preds = %122
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !61
  store atomic i64 0, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !62
  %126 = load i32, ptr %8, align 8, !tbaa !52
  br label %127

127:                                              ; preds = %122, %125
  %128 = phi i32 [ %123, %122 ], [ %126, %125 ]
  %129 = add i32 %128, -1
  store i32 %129, ptr %8, align 8, !tbaa !52
  %130 = add nuw nsw i64 %60, 1
  %131 = icmp eq i64 %130, 10000
  br i1 %131, label %22, label %58, !llvm.loop !73

132:                                              ; preds = %53, %5
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #15
  ret ptr null
}

; Function Attrs: mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: nounwind optsize uwtable
define noundef i32 @main() local_unnamed_addr #4 {
  %1 = alloca [12 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #15
  %2 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @g_lock, ptr noundef null) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %0
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 113, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #14
  unreachable

5:                                                ; preds = %0
  %6 = load ptr, ptr @g_lock_lib, align 8, !tbaa !74
  %7 = load <2 x ptr>, ptr getelementptr inbounds nuw (i8, ptr @g_lock_lib, i64 8), align 8, !tbaa !74
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), i8 0, i64 16, i1 false)
  br label %13

8:                                                ; preds = %13
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !50
  store atomic i64 1, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !51
  %9 = icmp eq ptr %6, null
  %10 = extractelement <2 x ptr> %7, i64 0
  %11 = icmp eq ptr %10, null
  %12 = select i1 %9, i1 true, i1 %11
  br i1 %12, label %19, label %20

13:                                               ; preds = %13, %5
  %14 = phi i64 [ 0, %5 ], [ %17, %13 ]
  %15 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %14
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !75
  store atomic i64 0, ptr %15 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !76
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !50
  store atomic i64 0, ptr %16 seq_cst, align 16
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !51
  %17 = add nuw nsw i64 %14, 1
  %18 = icmp eq i64 %17, 3
  br i1 %18, label %8, label %13, !llvm.loop !77

19:                                               ; preds = %8
  tail call void @__assert_fail(ptr noundef nonnull @.str.34, ptr noundef nonnull @.str.6, i32 noundef 102, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_init) #14
  unreachable

20:                                               ; preds = %8
  store ptr %6, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !74
  store <2 x ptr> %7, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !74
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), align 8, !tbaa !78
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !71
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 24) monotonic, align 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !72
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !71
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr @g_queue monotonic, align 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !72
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !71
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) monotonic, align 8
  tail call void asm sideeffect "", "~{memory}"() #15, !srcloc !72
  br label %21

21:                                               ; preds = %20, %21
  %22 = phi i64 [ 0, %20 ], [ %26, %21 ]
  %23 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %22
  %24 = inttoptr i64 %22 to ptr
  %25 = call i32 @pthread_create(ptr noundef nonnull %23, ptr noundef null, ptr noundef nonnull @run, ptr noundef %24) #13
  %26 = add nuw nsw i64 %22, 1
  %27 = icmp eq i64 %26, 12
  br i1 %27, label %31, label %21, !llvm.loop !80

28:                                               ; preds = %31
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !81
  store atomic i8 1, ptr @g_stop seq_cst, align 1
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !82
  %29 = load i64, ptr %1, align 8, !tbaa !83
  %30 = call i32 @pthread_join(i64 noundef %29, ptr noundef null) #13
  br label %38

31:                                               ; preds = %21, %31
  %32 = phi i64 [ %36, %31 ], [ 1, %21 ]
  %33 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %32
  %34 = load i64, ptr %33, align 8, !tbaa !83
  %35 = call i32 @pthread_join(i64 noundef %34, ptr noundef null) #13
  %36 = add nuw nsw i64 %32, 1
  %37 = icmp eq i64 %36, 12
  br i1 %37, label %28, label %31, !llvm.loop !84

38:                                               ; preds = %65, %28
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %39 = load atomic i64, ptr @g_queue seq_cst, align 8
  %40 = inttoptr i64 %39 to ptr
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %41 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %42 = getelementptr inbounds nuw i8, ptr %40, i64 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %43 = load atomic i64, ptr %42 seq_cst, align 8
  %44 = inttoptr i64 %43 to ptr
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %45 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %46 = icmp eq i64 %39, %45
  br i1 %46, label %47, label %65

47:                                               ; preds = %38
  %48 = icmp eq i64 %39, %41
  %49 = icmp eq i64 %43, 0
  br i1 %48, label %50, label %53

50:                                               ; preds = %47
  br i1 %49, label %66, label %51

51:                                               ; preds = %50
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !63
  %52 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %39, i64 %43 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !64
  br label %65

53:                                               ; preds = %47
  br i1 %49, label %54, label %55

54:                                               ; preds = %53
  call void @__assert_fail(ptr noundef nonnull @.str.24, ptr noundef nonnull @.str.21, i32 noundef 208, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_deq) #14
  unreachable

55:                                               ; preds = %53
  %56 = load ptr, ptr %44, align 8, !tbaa !65
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !63
  %57 = cmpxchg ptr @g_queue, i64 %39, i64 %43 seq_cst seq_cst, align 8
  %58 = extractvalue { i64, i1 } %57, 1
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !64
  br i1 %58, label %59, label %65

59:                                               ; preds = %55
  %60 = icmp eq i64 %39, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %60, label %62, label %61

61:                                               ; preds = %59
  call void @free(ptr noundef nonnull %40) #13
  br label %62

62:                                               ; preds = %59, %61
  %63 = icmp eq ptr %56, null
  br i1 %63, label %66, label %64

64:                                               ; preds = %62
  call void @free(ptr noundef nonnull %56) #13
  br label %65

65:                                               ; preds = %64, %55, %51, %38
  br label %38, !llvm.loop !85

66:                                               ; preds = %62, %50
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %67 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %78, label %69

69:                                               ; preds = %66, %76
  %70 = phi i64 [ %73, %76 ], [ %67, %66 ]
  %71 = inttoptr i64 %70 to ptr
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !20
  %73 = load atomic i64, ptr %72 seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !21
  %74 = icmp eq i64 %70, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %74, label %76, label %75

75:                                               ; preds = %69
  call void @free(ptr noundef nonnull %71) #13
  br label %76

76:                                               ; preds = %75, %69
  %77 = icmp eq i64 %73, 0
  br i1 %77, label %78, label %69, !llvm.loop !86

78:                                               ; preds = %76, %66
  br label %79

79:                                               ; preds = %78, %98
  %80 = phi i64 [ %99, %98 ], [ 0, %78 ]
  %81 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %80
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !31
  %82 = atomicrmw xchg ptr %81, i64 0 acquire, align 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !32
  %83 = getelementptr inbounds nuw i8, ptr %81, i64 8
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !33
  store atomic i64 0, ptr %83 monotonic, align 16
  call void asm sideeffect "", "~{memory}"() #15, !srcloc !34
  %84 = icmp eq i64 %82, 0
  br i1 %84, label %98, label %85

85:                                               ; preds = %79
  %86 = inttoptr i64 %82 to ptr
  br label %87

87:                                               ; preds = %93, %85
  %88 = phi ptr [ %94, %93 ], [ %86, %85 ]
  %89 = getelementptr inbounds nuw i8, ptr %88, i64 16
  %90 = load ptr, ptr %89, align 8, !tbaa !10
  %91 = icmp eq ptr %90, null
  br i1 %91, label %92, label %93

92:                                               ; preds = %87
  call void @__assert_fail(ptr noundef nonnull @.str.15, ptr noundef nonnull @.str.8, i32 noundef 197, ptr noundef nonnull @__PRETTY_FUNCTION__.smr_nodes_list_destroy) #14
  unreachable

93:                                               ; preds = %87
  %94 = load ptr, ptr %88, align 8, !tbaa !19
  %95 = getelementptr inbounds nuw i8, ptr %88, i64 24
  %96 = load ptr, ptr %95, align 8, !tbaa !18
  call void %90(ptr noundef nonnull %88, ptr noundef %96) #13
  %97 = icmp eq ptr %94, null
  br i1 %97, label %98, label %87, !llvm.loop !48

98:                                               ; preds = %93, %79
  %99 = add nuw nsw i64 %80, 1
  %100 = icmp eq i64 %99, 3
  br i1 %100, label %101, label %79, !llvm.loop !87

101:                                              ; preds = %98
  %102 = call i32 @pthread_mutex_destroy(ptr noundef nonnull @g_lock) #13
  %103 = icmp eq i32 %102, 0
  br i1 %103, label %105, label %104

104:                                              ; preds = %101
  call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 139, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #14
  unreachable

105:                                              ; preds = %101
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #15
  ret i32 0
}

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: cold noreturn nounwind optsize
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nounwind optsize
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: optsize
declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_destroy(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #12

attributes #0 = { inlinehint nounwind optsize uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { mustprogress nounwind optsize willreturn uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { nounwind optsize uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { mustprogress nounwind optsize willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #6 = { nofree nounwind optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #7 = { mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #8 = { nounwind optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #9 = { cold noreturn nounwind optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #10 = { optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #11 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #13 = { nounwind optsize }
attributes #14 = { cold noreturn nounwind optsize }
attributes #15 = { nounwind }
attributes #16 = { optsize }
attributes #17 = { nounwind optsize allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{i64 2147992278}
!7 = !{i64 2147992318}
!8 = !{i64 2147993216}
!9 = !{i64 2147993256}
!10 = !{!11, !14, i64 16}
!11 = !{!"smr_node_s", !12, i64 0, !17, i64 8, !14, i64 16, !14, i64 24}
!12 = !{!"smr_node_core_s", !13, i64 0}
!13 = !{!"p1 _ZTS15smr_node_core_s", !14, i64 0}
!14 = !{!"any pointer", !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C/C++ TBAA"}
!17 = !{!"int", !15, i64 0}
!18 = !{!11, !14, i64 24}
!19 = !{!11, !13, i64 0}
!20 = !{i64 2147993684}
!21 = !{i64 2147993724}
!22 = !{!12, !13, i64 0}
!23 = !{i64 2147998954}
!24 = !{i64 2147998996}
!25 = distinct !{!25, !26}
!26 = !{!"llvm.loop.mustprogress"}
!27 = !{i64 2148004964}
!28 = !{i64 2148005004}
!29 = !{i64 2147992514}
!30 = !{i64 2147992554}
!31 = !{i64 2147996960}
!32 = !{i64 2147997000}
!33 = !{i64 2147994776}
!34 = !{i64 2147994816}
!35 = !{!36, !14, i64 72}
!36 = !{!"vebr_s", !37, i64 0, !15, i64 8, !39, i64 56, !41, i64 72}
!37 = !{!"vatomic64_s", !38, i64 0}
!38 = !{!"long", !15, i64 0}
!39 = !{!"dbl_list_s", !40, i64 0, !38, i64 8}
!40 = !{!"p1 _ZTS15dbl_list_node_s", !14, i64 0}
!41 = !{!"smr_lock_lib_s", !14, i64 0, !14, i64 8, !14, i64 16}
!42 = !{!36, !14, i64 88}
!43 = !{!40, !40, i64 0}
!44 = distinct !{!44, !26}
!45 = !{!36, !14, i64 80}
!46 = !{i64 2147998154}
!47 = !{i64 2147998196}
!48 = distinct !{!48, !26}
!49 = distinct !{!49, !26}
!50 = !{i64 2147994620}
!51 = !{i64 2147994660}
!52 = !{!53, !17, i64 24}
!53 = !{!"vebr_instance_s", !54, i64 0, !37, i64 16, !17, i64 24}
!54 = !{!"dbl_list_node_s", !40, i64 0, !40, i64 8}
!55 = !{!39, !40, i64 0}
!56 = !{!54, !40, i64 0}
!57 = !{!54, !40, i64 8}
!58 = !{!39, !38, i64 8}
!59 = !{i64 2147993372}
!60 = !{i64 2147993412}
!61 = !{i64 2147994698}
!62 = !{i64 2147994738}
!63 = !{i64 2147998794}
!64 = !{i64 2147998836}
!65 = !{!66, !14, i64 0}
!66 = !{!"vqueue_ub_node_s", !14, i64 0, !67, i64 8, !11, i64 16}
!67 = !{!"vatomicptr_s", !14, i64 0}
!68 = !{ptr @destroy_cb, ptr @retire_cb}
!69 = !{!70, !38, i64 0}
!70 = !{!"data_s", !38, i64 0}
!71 = !{i64 2147995244}
!72 = !{i64 2147995284}
!73 = distinct !{!73, !26}
!74 = !{!14, !14, i64 0}
!75 = !{i64 2147995088}
!76 = !{i64 2147995128}
!77 = distinct !{!77, !26}
!78 = !{!79, !14, i64 16}
!79 = !{!"vqueue_ub_s", !67, i64 0, !67, i64 8, !66, i64 16}
!80 = distinct !{!80, !26}
!81 = !{i64 2147993918}
!82 = !{i64 2147993958}
!83 = !{!38, !38, i64 0}
!84 = distinct !{!84, !26}
!85 = distinct !{!85, !26}
!86 = distinct !{!86, !26}
!87 = distinct !{!87, !26}
