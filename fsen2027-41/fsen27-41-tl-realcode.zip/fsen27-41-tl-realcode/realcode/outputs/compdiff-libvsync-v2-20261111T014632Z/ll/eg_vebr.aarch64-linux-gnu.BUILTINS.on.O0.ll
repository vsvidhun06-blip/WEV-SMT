; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s, [8 x i8] }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i32, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }
%struct.data_s = type { i64 }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"ret == 0\00", align 1
@.str.4 = private unnamed_addr constant [42 x i8] c"C:/rc1111/src/libvsync/examples/eg_vebr.c\00", align 1
@__PRETTY_FUNCTION__.main = private unnamed_addr constant [15 x i8] c"int main(void)\00", align 1
@__PRETTY_FUNCTION__.lock_acq = private unnamed_addr constant [22 x i8] c"void lock_acq(void *)\00", align 1
@__PRETTY_FUNCTION__.lock_rel = private unnamed_addr constant [22 x i8] c"void lock_rel(void *)\00", align 1
@.str.5 = private unnamed_addr constant [20 x i8] c"idx <= (vuint64_t)3\00", align 1
@.str.6 = private unnamed_addr constant [47 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/ebr.h\00", align 1
@__PRETTY_FUNCTION__.vebr_retire = private unnamed_addr constant [88 x i8] c"void vebr_retire(vebr_t *, vebr_thread_t *, smr_node_t *, smr_node_destroy_fun, void *)\00", align 1
@.str.7 = private unnamed_addr constant [4 x i8] c"lst\00", align 1
@.str.8 = private unnamed_addr constant [67 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/smr_nodes_list.h\00", align 1
@__PRETTY_FUNCTION__.smr_nodes_list_add = private unnamed_addr constant [88 x i8] c"void smr_nodes_list_add(smr_nodes_list_t *, smr_node_t *, smr_node_destroy_fun, void *)\00", align 1
@.str.9 = private unnamed_addr constant [5 x i8] c"node\00", align 1
@.str.10 = private unnamed_addr constant [12 x i8] c"destroy_fun\00", align 1
@__PRETTY_FUNCTION__._smr_nodes_list_connect = private unnamed_addr constant [87 x i8] c"void _smr_nodes_list_connect(smr_nodes_list_t *, smr_node_core_t *, smr_node_core_t *)\00", align 1
@.str.11 = private unnamed_addr constant [5 x i8] c"head\00", align 1
@.str.12 = private unnamed_addr constant [5 x i8] c"tail\00", align 1
@.str.13 = private unnamed_addr constant [41 x i8] c"lcl_epoch == 0 || lcl_epoch >= glb_epoch\00", align 1
@__PRETTY_FUNCTION__.vebr_recycle = private unnamed_addr constant [31 x i8] c"vsize_t vebr_recycle(vebr_t *)\00", align 1
@.str.14 = private unnamed_addr constant [23 x i8] c"ret_epoch >= glb_epoch\00", align 1
@.str.15 = private unnamed_addr constant [24 x i8] c"freed_node->destroy_fun\00", align 1
@__PRETTY_FUNCTION__.smr_nodes_list_destroy = private unnamed_addr constant [45 x i8] c"vsize_t smr_nodes_list_destroy(smr_node_t *)\00", align 1
@.str.16 = private unnamed_addr constant [4 x i8] c"ebr\00", align 1
@__PRETTY_FUNCTION__.vebr_register = private unnamed_addr constant [46 x i8] c"void vebr_register(vebr_t *, vebr_thread_t *)\00", align 1
@.str.17 = private unnamed_addr constant [9 x i8] c"ebr_thrd\00", align 1
@.str.18 = private unnamed_addr constant [5 x i8] c"list\00", align 1
@.str.19 = private unnamed_addr constant [61 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/dbl_list.h\00", align 1
@__PRETTY_FUNCTION__.dbl_list_add = private unnamed_addr constant [51 x i8] c"void dbl_list_add(dbl_list_t *, dbl_list_node_t *)\00", align 1
@__PRETTY_FUNCTION__.vebr_enter = private unnamed_addr constant [43 x i8] c"void vebr_enter(vebr_t *, vebr_thread_t *)\00", align 1
@.str.20 = private unnamed_addr constant [2 x i8] c"q\00", align 1
@.str.21 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/include/vsync/queue/unbounded_queue_lf.h\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_deq = private unnamed_addr constant [69 x i8] c"void *vqueue_ub_deq(vqueue_ub_t *, vqueue_ub_node_handler_t, void *)\00", align 1
@.str.22 = private unnamed_addr constant [7 x i8] c"retire\00", align 1
@.str.23 = private unnamed_addr constant [62 x i8] c"next is not expected to be NULL, since the queue is not empty\00", align 1
@.str.24 = private unnamed_addr constant [75 x i8] c"next && \22next is not expected to be NULL, since the queue is \22 \22not empty\22\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_enq = private unnamed_addr constant [62 x i8] c"void vqueue_ub_enq(vqueue_ub_t *, vqueue_ub_node_t *, void *)\00", align 1
@.str.25 = private unnamed_addr constant [6 x i8] c"qnode\00", align 1
@.str.26 = private unnamed_addr constant [5 x i8] c"data\00", align 1
@__PRETTY_FUNCTION__.vebr_exit = private unnamed_addr constant [42 x i8] c"void vebr_exit(vebr_t *, vebr_thread_t *)\00", align 1
@.str.27 = private unnamed_addr constant [22 x i8] c"ebr_thrd->enter_count\00", align 1
@__PRETTY_FUNCTION__.vebr_deregister = private unnamed_addr constant [48 x i8] c"void vebr_deregister(vebr_t *, vebr_thread_t *)\00", align 1
@.str.28 = private unnamed_addr constant [48 x i8] c"vatomic64_read_rlx(&ebr_thrd->epoch_local) == 0\00", align 1
@__PRETTY_FUNCTION__.dbl_list_rem = private unnamed_addr constant [51 x i8] c"void dbl_list_rem(dbl_list_t *, dbl_list_node_t *)\00", align 1
@.str.29 = private unnamed_addr constant [19 x i8] c"prev->next == node\00", align 1
@.str.30 = private unnamed_addr constant [19 x i8] c"list->head != node\00", align 1
@.str.31 = private unnamed_addr constant [19 x i8] c"list->head == node\00", align 1
@.str.32 = private unnamed_addr constant [19 x i8] c"succ->prev == node\00", align 1
@__PRETTY_FUNCTION__.vebr_init = private unnamed_addr constant [41 x i8] c"void vebr_init(vebr_t *, smr_lock_lib_t)\00", align 1
@.str.33 = private unnamed_addr constant [32 x i8] c"ebr->threads.head == ((void*)0)\00", align 1
@.str.34 = private unnamed_addr constant [31 x i8] c"smr_lock_lib_is_set(&lock_lib)\00", align 1
@__PRETTY_FUNCTION__.dbl_list_init = private unnamed_addr constant [33 x i8] c"void dbl_list_init(dbl_list_t *)\00", align 1
@__PRETTY_FUNCTION__.smr_nodes_list_init = private unnamed_addr constant [45 x i8] c"void smr_nodes_list_init(smr_nodes_list_t *)\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_init = private unnamed_addr constant [35 x i8] c"void vqueue_ub_init(vqueue_ub_t *)\00", align 1
@__PRETTY_FUNCTION__.vebr_destroy = private unnamed_addr constant [28 x i8] c"void vebr_destroy(vebr_t *)\00", align 1

; Function Attrs: noinline nounwind optnone uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  store ptr %5, ptr %3, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = call i32 @pthread_mutex_lock(ptr noundef %6) #6
  store i32 %7, ptr %4, align 4
  %8 = load i32, ptr %4, align 4
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %11

10:                                               ; preds = %1
  br label %12

11:                                               ; preds = %1
  call void @__assert_fail(ptr noundef @.str.3, ptr noundef @.str.4, i32 noundef 24, ptr noundef @__PRETTY_FUNCTION__.lock_acq) #7
  unreachable

12:                                               ; preds = %10
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  store ptr %5, ptr %3, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = call i32 @pthread_mutex_unlock(ptr noundef %6) #6
  store i32 %7, ptr %4, align 4
  %8 = load i32, ptr %4, align 4
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %11

10:                                               ; preds = %1
  br label %12

11:                                               ; preds = %1
  call void @__assert_fail(ptr noundef @.str.3, ptr noundef @.str.4, i32 noundef 32, ptr noundef @__PRETTY_FUNCTION__.lock_rel) #7
  unreachable

12:                                               ; preds = %10
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define void @free_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = ptrtoint ptr %6 to i64
  %8 = sub i64 %7, 16
  %9 = inttoptr i64 %8 to ptr
  store ptr %9, ptr %5, align 8
  %10 = load ptr, ptr %5, align 8
  call void @free(ptr noundef %10) #6
  %11 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: nounwind
declare void @free(ptr noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define void @retire_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %6 = load ptr, ptr %4, align 8
  store ptr %6, ptr %5, align 8
  %7 = load ptr, ptr %5, align 8
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %8, i32 0, i32 2
  call void @vebr_retire(ptr noundef @g_vebr, ptr noundef %7, ptr noundef %9, ptr noundef @free_cb, ptr noundef null)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vebr_retire(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3, ptr noundef %4) #0 {
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  store ptr %0, ptr %6, align 8
  store ptr %1, ptr %7, align 8
  store ptr %2, ptr %8, align 8
  store ptr %3, ptr %9, align 8
  store ptr %4, ptr %10, align 8
  store i64 0, ptr %11, align 8
  store i64 0, ptr %12, align 8
  call void @vatomic_fence()
  %13 = load ptr, ptr %6, align 8
  %14 = getelementptr inbounds nuw %struct.vebr_s, ptr %13, i32 0, i32 0
  %15 = call i64 @vatomic64_read(ptr noundef %14)
  store i64 %15, ptr %11, align 8
  %16 = load i64, ptr %11, align 8
  %17 = urem i64 %16, 3
  store i64 %17, ptr %12, align 8
  %18 = load i64, ptr %12, align 8
  %19 = icmp ule i64 %18, 3
  br i1 %19, label %20, label %21

20:                                               ; preds = %5
  br label %22

21:                                               ; preds = %5
  call void @__assert_fail(ptr noundef @.str.5, ptr noundef @.str.6, i32 noundef 248, ptr noundef @__PRETTY_FUNCTION__.vebr_retire) #7
  unreachable

22:                                               ; preds = %20
  %23 = load ptr, ptr %6, align 8
  %24 = getelementptr inbounds nuw %struct.vebr_s, ptr %23, i32 0, i32 1
  %25 = load i64, ptr %12, align 8
  %26 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %24, i64 0, i64 %25
  %27 = load ptr, ptr %8, align 8
  %28 = load ptr, ptr %9, align 8
  %29 = load ptr, ptr %10, align 8
  call void @smr_nodes_list_add(ptr noundef %26, ptr noundef %27, ptr noundef %28, ptr noundef %29)
  br label %30

30:                                               ; preds = %22
  br label %31

31:                                               ; preds = %30
  %32 = load ptr, ptr %7, align 8
  br label %33

33:                                               ; preds = %31
  br label %34

34:                                               ; preds = %33
  br label %35

35:                                               ; preds = %34
  br label %36

36:                                               ; preds = %35
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define void @destroy_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  call void @free(ptr noundef %5) #6
  %6 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define void @reclaim() #0 {
  %1 = alloca i64, align 8
  br label %2

2:                                                ; preds = %13, %0
  %3 = call i8 @vatomic8_read(ptr noundef @g_stop)
  %4 = zext i8 %3 to i32
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %14

6:                                                ; preds = %2
  %7 = call i64 @vebr_recycle(ptr noundef @g_vebr)
  store i64 %7, ptr %1, align 8
  %8 = load i64, ptr %1, align 8
  %9 = icmp ugt i64 %8, 0
  br i1 %9, label %10, label %13

10:                                               ; preds = %6
  %11 = load i64, ptr %1, align 8
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, i64 noundef %11)
  br label %13

13:                                               ; preds = %10, %6
  br label %2, !llvm.loop !6

14:                                               ; preds = %2
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i8 @vatomic8_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i8, align 1
  %4 = alloca i8, align 1
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !8
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomic8_s, ptr %5, i32 0, i32 0
  %7 = load atomic i8, ptr %6 seq_cst, align 1
  store i8 %7, ptr %4, align 1
  %8 = load i8, ptr %4, align 1
  store i8 %8, ptr %3, align 1
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !9
  %9 = load i8, ptr %3, align 1
  ret i8 %9
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @vebr_recycle(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  store i64 0, ptr %4, align 8
  store i64 0, ptr %5, align 8
  store i64 0, ptr %6, align 8
  store i64 0, ptr %7, align 8
  store ptr null, ptr %8, align 8
  call void @vatomic_fence()
  %9 = load ptr, ptr %2, align 8
  %10 = getelementptr inbounds nuw %struct.vebr_s, ptr %9, i32 0, i32 0
  %11 = call i64 @vatomic64_read(ptr noundef %10)
  store i64 %11, ptr %5, align 8
  %12 = load i64, ptr %5, align 8
  %13 = add i64 %12, 2
  %14 = urem i64 %13, 3
  store i64 %14, ptr %4, align 8
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_s, ptr %15, i32 0, i32 1
  %17 = load i64, ptr %4, align 8
  %18 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %16, i64 0, i64 %17
  %19 = call ptr @smr_nodes_list_get_and_empty(ptr noundef %18)
  store ptr %19, ptr %8, align 8
  %20 = load ptr, ptr %2, align 8
  %21 = load i64, ptr %5, align 8
  %22 = call i64 @_vebr_sync_epochs(ptr noundef %20, i64 noundef %21, i1 noundef true)
  store i64 %22, ptr %7, align 8
  %23 = load i64, ptr %7, align 8
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %29, label %25

25:                                               ; preds = %1
  %26 = load i64, ptr %7, align 8
  %27 = load i64, ptr %5, align 8
  %28 = icmp uge i64 %26, %27
  br i1 %28, label %29, label %30

29:                                               ; preds = %25, %1
  br label %31

30:                                               ; preds = %25
  call void @__assert_fail(ptr noundef @.str.13, ptr noundef @.str.6, i32 noundef 285, ptr noundef @__PRETTY_FUNCTION__.vebr_recycle) #7
  unreachable

31:                                               ; preds = %29
  %32 = load ptr, ptr %2, align 8
  %33 = getelementptr inbounds nuw %struct.vebr_s, ptr %32, i32 0, i32 0
  %34 = load i64, ptr %5, align 8
  %35 = load i64, ptr %5, align 8
  %36 = add i64 %35, 1
  %37 = call i64 @vatomic64_cmpxchg(ptr noundef %33, i64 noundef %34, i64 noundef %36)
  store i64 %37, ptr %6, align 8
  %38 = load i64, ptr %6, align 8
  %39 = load i64, ptr %5, align 8
  %40 = icmp uge i64 %38, %39
  br i1 %40, label %41, label %42

41:                                               ; preds = %31
  br label %43

42:                                               ; preds = %31
  call void @__assert_fail(ptr noundef @.str.14, ptr noundef @.str.6, i32 noundef 298, ptr noundef @__PRETTY_FUNCTION__.vebr_recycle) #7
  unreachable

43:                                               ; preds = %41
  %44 = load ptr, ptr %8, align 8
  %45 = icmp ne ptr %44, null
  br i1 %45, label %46, label %49

46:                                               ; preds = %43
  %47 = load ptr, ptr %8, align 8
  %48 = call i64 @smr_nodes_list_destroy(ptr noundef %47)
  store i64 %48, ptr %3, align 8
  br label %49

49:                                               ; preds = %46, %43
  %50 = load i64, ptr %3, align 8
  ret i64 %50
}

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone uwtable
define ptr @run(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.vebr_instance_s, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store ptr null, ptr %4, align 8
  %8 = load ptr, ptr %2, align 8
  %9 = ptrtoint ptr %8 to i64
  store i64 %9, ptr %5, align 8
  %10 = load i64, ptr %5, align 8
  %11 = icmp eq i64 %10, 0
  br i1 %11, label %12, label %13

12:                                               ; preds = %1
  call void @reclaim()
  br label %46

13:                                               ; preds = %1
  call void @vebr_register(ptr noundef @g_vebr, ptr noundef %3)
  store i64 0, ptr %6, align 8
  br label %14

14:                                               ; preds = %42, %13
  %15 = load i64, ptr %6, align 8
  %16 = icmp ult i64 %15, 10000
  br i1 %16, label %17, label %45

17:                                               ; preds = %14
  call void @vebr_enter(ptr noundef @g_vebr, ptr noundef %3)
  %18 = call ptr @vqueue_ub_deq(ptr noundef @g_queue, ptr noundef @retire_cb, ptr noundef %3)
  store ptr %18, ptr %4, align 8
  %19 = load ptr, ptr %4, align 8
  %20 = icmp eq ptr %19, null
  br i1 %20, label %21, label %34

21:                                               ; preds = %17
  %22 = call noalias ptr @malloc(i64 noundef 8) #8
  store ptr %22, ptr %4, align 8
  %23 = load i64, ptr %6, align 8
  %24 = load ptr, ptr %4, align 8
  %25 = getelementptr inbounds nuw %struct.data_s, ptr %24, i32 0, i32 0
  store i64 %23, ptr %25, align 8
  %26 = call noalias ptr @malloc(i64 noundef 48) #8
  store ptr %26, ptr %7, align 8
  %27 = load i64, ptr %5, align 8
  %28 = load ptr, ptr %4, align 8
  %29 = getelementptr inbounds nuw %struct.data_s, ptr %28, i32 0, i32 0
  %30 = load i64, ptr %29, align 8
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i64 noundef %27, i64 noundef %30)
  %32 = load ptr, ptr %7, align 8
  %33 = load ptr, ptr %4, align 8
  call void @vqueue_ub_enq(ptr noundef @g_queue, ptr noundef %32, ptr noundef %33)
  br label %41

34:                                               ; preds = %17
  %35 = load i64, ptr %5, align 8
  %36 = load ptr, ptr %4, align 8
  %37 = getelementptr inbounds nuw %struct.data_s, ptr %36, i32 0, i32 0
  %38 = load i64, ptr %37, align 8
  %39 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i64 noundef %35, i64 noundef %38)
  %40 = load ptr, ptr %4, align 8
  call void @free(ptr noundef %40) #6
  br label %41

41:                                               ; preds = %34, %21
  call void @vebr_exit(ptr noundef @g_vebr, ptr noundef %3)
  br label %42

42:                                               ; preds = %41
  %43 = load i64, ptr %6, align 8
  %44 = add i64 %43, 1
  store i64 %44, ptr %6, align 8
  br label %14, !llvm.loop !10

45:                                               ; preds = %14
  call void @vebr_deregister(ptr noundef @g_vebr, ptr noundef %3)
  br label %46

46:                                               ; preds = %45, %12
  ret ptr null
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vebr_register(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %8

7:                                                ; preds = %2
  br label %9

8:                                                ; preds = %2
  call void @__assert_fail(ptr noundef @.str.16, ptr noundef @.str.6, i32 noundef 141, ptr noundef @__PRETTY_FUNCTION__.vebr_register) #7
  unreachable

9:                                                ; preds = %7
  %10 = load ptr, ptr %4, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %12, label %13

12:                                               ; preds = %9
  br label %14

13:                                               ; preds = %9
  call void @__assert_fail(ptr noundef @.str.17, ptr noundef @.str.6, i32 noundef 142, ptr noundef @__PRETTY_FUNCTION__.vebr_register) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %15, i32 0, i32 1
  call void @vatomic64_init(ptr noundef %16, i64 noundef 0)
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %17, i32 0, i32 2
  store i32 0, ptr %18, align 8
  %19 = load ptr, ptr %3, align 8
  %20 = getelementptr inbounds nuw %struct.vebr_s, ptr %19, i32 0, i32 3
  %21 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %20, i32 0, i32 0
  %22 = load ptr, ptr %21, align 8
  %23 = load ptr, ptr %3, align 8
  %24 = getelementptr inbounds nuw %struct.vebr_s, ptr %23, i32 0, i32 3
  %25 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %24, i32 0, i32 2
  %26 = load ptr, ptr %25, align 8
  call void %22(ptr noundef %26)
  %27 = load ptr, ptr %3, align 8
  %28 = getelementptr inbounds nuw %struct.vebr_s, ptr %27, i32 0, i32 2
  %29 = load ptr, ptr %4, align 8
  %30 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %29, i32 0, i32 0
  call void @dbl_list_add(ptr noundef %28, ptr noundef %30)
  %31 = load ptr, ptr %3, align 8
  %32 = getelementptr inbounds nuw %struct.vebr_s, ptr %31, i32 0, i32 3
  %33 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %32, i32 0, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = load ptr, ptr %3, align 8
  %36 = getelementptr inbounds nuw %struct.vebr_s, ptr %35, i32 0, i32 3
  %37 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %36, i32 0, i32 2
  %38 = load ptr, ptr %37, align 8
  call void %34(ptr noundef %38)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vebr_enter(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  store i64 0, ptr %5, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = icmp ne ptr %6, null
  br i1 %7, label %8, label %9

8:                                                ; preds = %2
  br label %10

9:                                                ; preds = %2
  call void @__assert_fail(ptr noundef @.str.16, ptr noundef @.str.6, i32 noundef 183, ptr noundef @__PRETTY_FUNCTION__.vebr_enter) #7
  unreachable

10:                                               ; preds = %8
  %11 = load ptr, ptr %4, align 8
  %12 = icmp ne ptr %11, null
  br i1 %12, label %13, label %14

13:                                               ; preds = %10
  br label %15

14:                                               ; preds = %10
  call void @__assert_fail(ptr noundef @.str.17, ptr noundef @.str.6, i32 noundef 184, ptr noundef @__PRETTY_FUNCTION__.vebr_enter) #7
  unreachable

15:                                               ; preds = %13
  %16 = load ptr, ptr %4, align 8
  %17 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %16, i32 0, i32 2
  %18 = load i32, ptr %17, align 8
  %19 = add i32 %18, 1
  store i32 %19, ptr %17, align 8
  %20 = load ptr, ptr %4, align 8
  %21 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %20, i32 0, i32 2
  %22 = load i32, ptr %21, align 8
  %23 = icmp eq i32 %22, 1
  br i1 %23, label %24, label %31

24:                                               ; preds = %15
  %25 = load ptr, ptr %3, align 8
  %26 = getelementptr inbounds nuw %struct.vebr_s, ptr %25, i32 0, i32 0
  %27 = call i64 @vatomic64_read(ptr noundef %26)
  store i64 %27, ptr %5, align 8
  %28 = load ptr, ptr %4, align 8
  %29 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %28, i32 0, i32 1
  %30 = load i64, ptr %5, align 8
  call void @vatomic64_write_rel(ptr noundef %29, i64 noundef %30)
  call void @vatomic_fence()
  br label %31

31:                                               ; preds = %24, %15
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vqueue_ub_deq(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store ptr null, ptr %9, align 8
  store ptr null, ptr %10, align 8
  store ptr null, ptr %11, align 8
  %12 = load ptr, ptr %5, align 8
  %13 = icmp ne ptr %12, null
  br i1 %13, label %14, label %15

14:                                               ; preds = %3
  br label %16

15:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.20, ptr noundef @.str.21, i32 noundef 179, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_deq) #7
  unreachable

16:                                               ; preds = %14
  %17 = load ptr, ptr %6, align 8
  %18 = icmp ne ptr %17, null
  br i1 %18, label %19, label %20

19:                                               ; preds = %16
  br label %21

20:                                               ; preds = %16
  call void @__assert_fail(ptr noundef @.str.22, ptr noundef @.str.21, i32 noundef 180, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_deq) #7
  unreachable

21:                                               ; preds = %19
  br label %22

22:                                               ; preds = %21, %83
  %23 = load ptr, ptr %5, align 8
  %24 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %23, i32 0, i32 0
  %25 = call ptr @vatomicptr_read(ptr noundef %24)
  store ptr %25, ptr %8, align 8
  %26 = load ptr, ptr %5, align 8
  %27 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %26, i32 0, i32 1
  %28 = call ptr @vatomicptr_read(ptr noundef %27)
  store ptr %28, ptr %9, align 8
  %29 = load ptr, ptr %8, align 8
  %30 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %29, i32 0, i32 1
  %31 = call ptr @vatomicptr_read(ptr noundef %30)
  store ptr %31, ptr %10, align 8
  %32 = load ptr, ptr %8, align 8
  %33 = load ptr, ptr %5, align 8
  %34 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %33, i32 0, i32 0
  %35 = call ptr @vatomicptr_read(ptr noundef %34)
  %36 = icmp eq ptr %32, %35
  br i1 %36, label %37, label %82

37:                                               ; preds = %22
  %38 = load ptr, ptr %8, align 8
  %39 = load ptr, ptr %9, align 8
  %40 = icmp eq ptr %38, %39
  br i1 %40, label %41, label %51

41:                                               ; preds = %37
  %42 = load ptr, ptr %10, align 8
  %43 = icmp eq ptr %42, null
  br i1 %43, label %44, label %45

44:                                               ; preds = %41
  store ptr null, ptr %4, align 8
  br label %84

45:                                               ; preds = %41
  call void @verification_ignore()
  %46 = load ptr, ptr %5, align 8
  %47 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %46, i32 0, i32 1
  %48 = load ptr, ptr %9, align 8
  %49 = load ptr, ptr %10, align 8
  %50 = call ptr @vatomicptr_cmpxchg(ptr noundef %47, ptr noundef %48, ptr noundef %49)
  br label %81

51:                                               ; preds = %37
  %52 = load ptr, ptr %10, align 8
  %53 = icmp ne ptr %52, null
  br i1 %53, label %54, label %56

54:                                               ; preds = %51
  br i1 true, label %55, label %56

55:                                               ; preds = %54
  br label %57

56:                                               ; preds = %54, %51
  call void @__assert_fail(ptr noundef @.str.24, ptr noundef @.str.21, i32 noundef 208, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_deq) #7
  unreachable

57:                                               ; preds = %55
  %58 = load ptr, ptr %10, align 8
  %59 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %58, i32 0, i32 0
  %60 = load ptr, ptr %59, align 8
  store ptr %60, ptr %11, align 8
  %61 = load ptr, ptr %5, align 8
  %62 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %61, i32 0, i32 0
  %63 = load ptr, ptr %8, align 8
  %64 = load ptr, ptr %10, align 8
  %65 = call ptr @vatomicptr_cmpxchg(ptr noundef %62, ptr noundef %63, ptr noundef %64)
  %66 = load ptr, ptr %8, align 8
  %67 = icmp eq ptr %65, %66
  br i1 %67, label %68, label %79

68:                                               ; preds = %57
  %69 = load ptr, ptr %8, align 8
  %70 = load ptr, ptr %5, align 8
  %71 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %70, i32 0, i32 2
  %72 = icmp ne ptr %69, %71
  br i1 %72, label %73, label %77

73:                                               ; preds = %68
  %74 = load ptr, ptr %6, align 8
  %75 = load ptr, ptr %8, align 8
  %76 = load ptr, ptr %7, align 8
  call void %74(ptr noundef %75, ptr noundef %76)
  br label %77

77:                                               ; preds = %73, %68
  %78 = load ptr, ptr %11, align 8
  store ptr %78, ptr %4, align 8
  br label %84

79:                                               ; preds = %57
  call void @verification_ignore()
  br label %80

80:                                               ; preds = %79
  br label %81

81:                                               ; preds = %80, %45
  br label %83

82:                                               ; preds = %22
  call void @verification_ignore()
  br label %83

83:                                               ; preds = %82, %81
  br label %22

84:                                               ; preds = %77, %44
  %85 = load ptr, ptr %4, align 8
  ret ptr %85
}

; Function Attrs: nounwind allocsize(0)
declare noalias ptr @malloc(i64 noundef) #3

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vqueue_ub_enq(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store i8 0, ptr %9, align 1
  %10 = load ptr, ptr %4, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  br label %14

13:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.20, ptr noundef @.str.21, i32 noundef 112, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_enq) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %5, align 8
  %16 = icmp ne ptr %15, null
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  br label %19

18:                                               ; preds = %14
  call void @__assert_fail(ptr noundef @.str.25, ptr noundef @.str.21, i32 noundef 113, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_enq) #7
  unreachable

19:                                               ; preds = %17
  %20 = load ptr, ptr %6, align 8
  %21 = icmp ne ptr %20, null
  br i1 %21, label %22, label %23

22:                                               ; preds = %19
  br label %24

23:                                               ; preds = %19
  call void @__assert_fail(ptr noundef @.str.26, ptr noundef @.str.21, i32 noundef 114, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_enq) #7
  unreachable

24:                                               ; preds = %22
  %25 = load ptr, ptr %6, align 8
  %26 = load ptr, ptr %5, align 8
  %27 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %26, i32 0, i32 0
  store ptr %25, ptr %27, align 8
  %28 = load ptr, ptr %5, align 8
  %29 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %28, i32 0, i32 1
  call void @vatomicptr_write_rlx(ptr noundef %29, ptr noundef null)
  br label %30

30:                                               ; preds = %24, %74
  %31 = load ptr, ptr %4, align 8
  %32 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %31, i32 0, i32 1
  %33 = call ptr @vatomicptr_read(ptr noundef %32)
  store ptr %33, ptr %7, align 8
  %34 = load ptr, ptr %7, align 8
  %35 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %34, i32 0, i32 1
  %36 = call ptr @vatomicptr_read(ptr noundef %35)
  store ptr %36, ptr %8, align 8
  %37 = load ptr, ptr %7, align 8
  %38 = load ptr, ptr %4, align 8
  %39 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %38, i32 0, i32 1
  %40 = call ptr @vatomicptr_read(ptr noundef %39)
  %41 = icmp eq ptr %37, %40
  br i1 %41, label %42, label %73

42:                                               ; preds = %30
  %43 = load ptr, ptr %8, align 8
  %44 = icmp eq ptr %43, null
  br i1 %44, label %45, label %66

45:                                               ; preds = %42
  %46 = load ptr, ptr %7, align 8
  %47 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %46, i32 0, i32 1
  %48 = load ptr, ptr %8, align 8
  %49 = load ptr, ptr %5, align 8
  %50 = call ptr @vatomicptr_cmpxchg(ptr noundef %47, ptr noundef %48, ptr noundef %49)
  %51 = load ptr, ptr %8, align 8
  %52 = icmp eq ptr %50, %51
  br i1 %52, label %53, label %64

53:                                               ; preds = %45
  %54 = load ptr, ptr %4, align 8
  %55 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %54, i32 0, i32 1
  %56 = load ptr, ptr %7, align 8
  %57 = load ptr, ptr %5, align 8
  %58 = call ptr @vatomicptr_cmpxchg(ptr noundef %55, ptr noundef %56, ptr noundef %57)
  %59 = load ptr, ptr %7, align 8
  %60 = icmp eq ptr %58, %59
  %61 = zext i1 %60 to i8
  store i8 %61, ptr %9, align 1
  %62 = load i8, ptr %9, align 1
  %63 = trunc i8 %62 to i1
  call void @verification_assume(i1 noundef %63)
  ret void

64:                                               ; preds = %45
  call void @verification_ignore()
  br label %65

65:                                               ; preds = %64
  br label %72

66:                                               ; preds = %42
  call void @verification_ignore()
  %67 = load ptr, ptr %4, align 8
  %68 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %67, i32 0, i32 1
  %69 = load ptr, ptr %7, align 8
  %70 = load ptr, ptr %8, align 8
  %71 = call ptr @vatomicptr_cmpxchg(ptr noundef %68, ptr noundef %69, ptr noundef %70)
  br label %72

72:                                               ; preds = %66, %65
  br label %74

73:                                               ; preds = %30
  call void @verification_ignore()
  br label %74

74:                                               ; preds = %73, %72
  br label %30
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vebr_exit(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %4, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %8

7:                                                ; preds = %2
  br label %9

8:                                                ; preds = %2
  call void @__assert_fail(ptr noundef @.str.17, ptr noundef @.str.6, i32 noundef 209, ptr noundef @__PRETTY_FUNCTION__.vebr_exit) #7
  unreachable

9:                                                ; preds = %7
  %10 = load ptr, ptr %4, align 8
  %11 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %10, i32 0, i32 2
  %12 = load i32, ptr %11, align 8
  %13 = icmp ne i32 %12, 0
  br i1 %13, label %14, label %15

14:                                               ; preds = %9
  br label %16

15:                                               ; preds = %9
  call void @__assert_fail(ptr noundef @.str.27, ptr noundef @.str.6, i32 noundef 210, ptr noundef @__PRETTY_FUNCTION__.vebr_exit) #7
  unreachable

16:                                               ; preds = %14
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %17, i32 0, i32 2
  %19 = load i32, ptr %18, align 8
  %20 = icmp eq i32 %19, 1
  br i1 %20, label %21, label %24

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %22, i32 0, i32 1
  call void @vatomic64_write_rel(ptr noundef %23, i64 noundef 0)
  br label %24

24:                                               ; preds = %21, %16
  %25 = load ptr, ptr %4, align 8
  %26 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %25, i32 0, i32 2
  %27 = load i32, ptr %26, align 8
  %28 = add i32 %27, -1
  store i32 %28, ptr %26, align 8
  br label %29

29:                                               ; preds = %24
  br label %30

30:                                               ; preds = %29
  %31 = load ptr, ptr %3, align 8
  br label %32

32:                                               ; preds = %30
  br label %33

33:                                               ; preds = %32
  br label %34

34:                                               ; preds = %33
  br label %35

35:                                               ; preds = %34
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vebr_deregister(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %8

7:                                                ; preds = %2
  br label %9

8:                                                ; preds = %2
  call void @__assert_fail(ptr noundef @.str.16, ptr noundef @.str.6, i32 noundef 162, ptr noundef @__PRETTY_FUNCTION__.vebr_deregister) #7
  unreachable

9:                                                ; preds = %7
  %10 = load ptr, ptr %4, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %12, label %13

12:                                               ; preds = %9
  br label %14

13:                                               ; preds = %9
  call void @__assert_fail(ptr noundef @.str.17, ptr noundef @.str.6, i32 noundef 163, ptr noundef @__PRETTY_FUNCTION__.vebr_deregister) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %15, i32 0, i32 1
  %17 = call i64 @vatomic64_read_rlx(ptr noundef %16)
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %14
  br label %21

20:                                               ; preds = %14
  call void @__assert_fail(ptr noundef @.str.28, ptr noundef @.str.6, i32 noundef 165, ptr noundef @__PRETTY_FUNCTION__.vebr_deregister) #7
  unreachable

21:                                               ; preds = %19
  %22 = load ptr, ptr %3, align 8
  %23 = getelementptr inbounds nuw %struct.vebr_s, ptr %22, i32 0, i32 3
  %24 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %23, i32 0, i32 0
  %25 = load ptr, ptr %24, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = getelementptr inbounds nuw %struct.vebr_s, ptr %26, i32 0, i32 3
  %28 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %27, i32 0, i32 2
  %29 = load ptr, ptr %28, align 8
  call void %25(ptr noundef %29)
  %30 = load ptr, ptr %3, align 8
  %31 = getelementptr inbounds nuw %struct.vebr_s, ptr %30, i32 0, i32 2
  %32 = load ptr, ptr %4, align 8
  %33 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %32, i32 0, i32 0
  call void @dbl_list_rem(ptr noundef %31, ptr noundef %33)
  %34 = load ptr, ptr %3, align 8
  %35 = getelementptr inbounds nuw %struct.vebr_s, ptr %34, i32 0, i32 3
  %36 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %35, i32 0, i32 1
  %37 = load ptr, ptr %36, align 8
  %38 = load ptr, ptr %3, align 8
  %39 = getelementptr inbounds nuw %struct.vebr_s, ptr %38, i32 0, i32 3
  %40 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %39, i32 0, i32 2
  %41 = load ptr, ptr %40, align 8
  call void %37(ptr noundef %41)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [12 x i64], align 8
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca %struct.smr_lock_lib_s, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  store ptr null, ptr %3, align 8
  %8 = call i32 @pthread_mutex_init(ptr noundef @g_lock, ptr noundef null) #6
  store i32 %8, ptr %4, align 4
  %9 = load i32, ptr %4, align 4
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %0
  br label %13

12:                                               ; preds = %0
  call void @__assert_fail(ptr noundef @.str.3, ptr noundef @.str.4, i32 noundef 113, ptr noundef @__PRETTY_FUNCTION__.main) #7
  unreachable

13:                                               ; preds = %11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 @g_lock_lib, i64 24, i1 false)
  call void @vebr_init(ptr noundef @g_vebr, ptr noundef %5)
  call void @vqueue_ub_init(ptr noundef @g_queue)
  store i64 0, ptr %6, align 8
  br label %14

14:                                               ; preds = %23, %13
  %15 = load i64, ptr %6, align 8
  %16 = icmp ult i64 %15, 12
  br i1 %16, label %17, label %26

17:                                               ; preds = %14
  %18 = load i64, ptr %6, align 8
  %19 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %18
  %20 = load i64, ptr %6, align 8
  %21 = inttoptr i64 %20 to ptr
  %22 = call i32 @pthread_create(ptr noundef %19, ptr noundef null, ptr noundef @run, ptr noundef %21) #6
  br label %23

23:                                               ; preds = %17
  %24 = load i64, ptr %6, align 8
  %25 = add i64 %24, 1
  store i64 %25, ptr %6, align 8
  br label %14, !llvm.loop !11

26:                                               ; preds = %14
  store i64 1, ptr %7, align 8
  br label %27

27:                                               ; preds = %35, %26
  %28 = load i64, ptr %7, align 8
  %29 = icmp ult i64 %28, 12
  br i1 %29, label %30, label %38

30:                                               ; preds = %27
  %31 = load i64, ptr %7, align 8
  %32 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %31
  %33 = load i64, ptr %32, align 8
  %34 = call i32 @pthread_join(i64 noundef %33, ptr noundef null)
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %7, align 8
  %37 = add i64 %36, 1
  store i64 %37, ptr %7, align 8
  br label %27, !llvm.loop !12

38:                                               ; preds = %27
  call void @vatomic8_write(ptr noundef @g_stop, i8 noundef 1)
  %39 = getelementptr inbounds [12 x i64], ptr %2, i64 0, i64 0
  %40 = load i64, ptr %39, align 8
  %41 = call i32 @pthread_join(i64 noundef %40, ptr noundef null)
  br label %42

42:                                               ; preds = %46, %38
  %43 = call ptr @vqueue_ub_deq(ptr noundef @g_queue, ptr noundef @destroy_cb, ptr noundef null)
  store ptr %43, ptr %3, align 8
  %44 = load ptr, ptr %3, align 8
  %45 = icmp ne ptr %44, null
  br i1 %45, label %46, label %48

46:                                               ; preds = %42
  %47 = load ptr, ptr %3, align 8
  call void @free(ptr noundef %47) #6
  br label %42, !llvm.loop !13

48:                                               ; preds = %42
  call void @vqueue_ub_destroy(ptr noundef @g_queue, ptr noundef @destroy_cb, ptr noundef null)
  call void @vebr_destroy(ptr noundef @g_vebr)
  %49 = call i32 @pthread_mutex_destroy(ptr noundef @g_lock) #6
  store i32 %49, ptr %4, align 4
  %50 = load i32, ptr %4, align 4
  %51 = icmp eq i32 %50, 0
  br i1 %51, label %52, label %53

52:                                               ; preds = %48
  br label %54

53:                                               ; preds = %48
  call void @__assert_fail(ptr noundef @.str.3, ptr noundef @.str.4, i32 noundef 139, ptr noundef @__PRETTY_FUNCTION__.main) #7
  unreachable

54:                                               ; preds = %52
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) #1

; Function Attrs: cold noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) #4

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vebr_init(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = icmp ne ptr %6, null
  br i1 %7, label %8, label %9

8:                                                ; preds = %2
  br label %10

9:                                                ; preds = %2
  call void @__assert_fail(ptr noundef @.str.16, ptr noundef @.str.6, i32 noundef 94, ptr noundef @__PRETTY_FUNCTION__.vebr_init) #7
  unreachable

10:                                               ; preds = %8
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds nuw %struct.vebr_s, ptr %11, i32 0, i32 2
  call void @dbl_list_init(ptr noundef %12)
  %13 = load ptr, ptr %3, align 8
  %14 = getelementptr inbounds nuw %struct.vebr_s, ptr %13, i32 0, i32 2
  %15 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %14, i32 0, i32 0
  %16 = load ptr, ptr %15, align 8
  %17 = icmp eq ptr %16, null
  br i1 %17, label %18, label %19

18:                                               ; preds = %10
  br label %20

19:                                               ; preds = %10
  call void @__assert_fail(ptr noundef @.str.33, ptr noundef @.str.6, i32 noundef 96, ptr noundef @__PRETTY_FUNCTION__.vebr_init) #7
  unreachable

20:                                               ; preds = %18
  store i64 0, ptr %5, align 8
  br label %21

21:                                               ; preds = %29, %20
  %22 = load i64, ptr %5, align 8
  %23 = icmp ult i64 %22, 3
  br i1 %23, label %24, label %32

24:                                               ; preds = %21
  %25 = load ptr, ptr %3, align 8
  %26 = getelementptr inbounds nuw %struct.vebr_s, ptr %25, i32 0, i32 1
  %27 = load i64, ptr %5, align 8
  %28 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %26, i64 0, i64 %27
  call void @smr_nodes_list_init(ptr noundef %28)
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %5, align 8
  %31 = add i64 %30, 1
  store i64 %31, ptr %5, align 8
  br label %21, !llvm.loop !14

32:                                               ; preds = %21
  %33 = load ptr, ptr %3, align 8
  %34 = getelementptr inbounds nuw %struct.vebr_s, ptr %33, i32 0, i32 0
  call void @vatomic64_write(ptr noundef %34, i64 noundef 1)
  %35 = call i1 @smr_lock_lib_is_set(ptr noundef %1)
  br i1 %35, label %36, label %37

36:                                               ; preds = %32
  br label %38

37:                                               ; preds = %32
  call void @__assert_fail(ptr noundef @.str.34, ptr noundef @.str.6, i32 noundef 102, ptr noundef @__PRETTY_FUNCTION__.vebr_init) #7
  unreachable

38:                                               ; preds = %36
  %39 = load ptr, ptr %3, align 8
  %40 = getelementptr inbounds nuw %struct.vebr_s, ptr %39, i32 0, i32 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %40, ptr align 8 %1, i64 24, i1 false)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vqueue_ub_init(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  br label %7

6:                                                ; preds = %1
  call void @__assert_fail(ptr noundef @.str.20, ptr noundef @.str.21, i32 noundef 62, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_init) #7
  unreachable

7:                                                ; preds = %5
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %8, i32 0, i32 2
  %10 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %9, i32 0, i32 0
  store ptr null, ptr %10, align 8
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %11, i32 0, i32 2
  %13 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %12, i32 0, i32 1
  call void @vatomicptr_write_rlx(ptr noundef %13, ptr noundef null)
  %14 = load ptr, ptr %2, align 8
  %15 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %14, i32 0, i32 0
  %16 = load ptr, ptr %2, align 8
  %17 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %16, i32 0, i32 2
  call void @vatomicptr_write_rlx(ptr noundef %15, ptr noundef %17)
  %18 = load ptr, ptr %2, align 8
  %19 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %18, i32 0, i32 1
  %20 = load ptr, ptr %2, align 8
  %21 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %20, i32 0, i32 2
  call void @vatomicptr_write_rlx(ptr noundef %19, ptr noundef %21)
  ret void
}

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) #1

declare i32 @pthread_join(i64 noundef, ptr noundef) #2

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomic8_write(ptr noundef %0, i8 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  store ptr %0, ptr %3, align 8
  store i8 %1, ptr %4, align 1
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !15
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic8_s, ptr %6, i32 0, i32 0
  %8 = load i8, ptr %4, align 1
  store i8 %8, ptr %5, align 1
  %9 = load i8, ptr %5, align 1
  store atomic i8 %9, ptr %7 seq_cst, align 1
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !16
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vqueue_ub_destroy(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %9 = load ptr, ptr %4, align 8
  %10 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %9, i32 0, i32 0
  %11 = call ptr @vatomicptr_read(ptr noundef %10)
  store ptr %11, ptr %7, align 8
  store ptr null, ptr %8, align 8
  br label %12

12:                                               ; preds = %27, %3
  %13 = load ptr, ptr %7, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %15, label %29

15:                                               ; preds = %12
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %16, i32 0, i32 1
  %18 = call ptr @vatomicptr_read(ptr noundef %17)
  store ptr %18, ptr %8, align 8
  %19 = load ptr, ptr %7, align 8
  %20 = load ptr, ptr %4, align 8
  %21 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %20, i32 0, i32 2
  %22 = icmp ne ptr %19, %21
  br i1 %22, label %23, label %27

23:                                               ; preds = %15
  %24 = load ptr, ptr %5, align 8
  %25 = load ptr, ptr %7, align 8
  %26 = load ptr, ptr %6, align 8
  call void %24(ptr noundef %25, ptr noundef %26)
  br label %27

27:                                               ; preds = %23, %15
  %28 = load ptr, ptr %8, align 8
  store ptr %28, ptr %7, align 8
  br label %12, !llvm.loop !17

29:                                               ; preds = %12
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vebr_destroy(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  store ptr null, ptr %4, align 8
  %5 = load ptr, ptr %2, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %8

7:                                                ; preds = %1
  br label %9

8:                                                ; preds = %1
  call void @__assert_fail(ptr noundef @.str.16, ptr noundef @.str.6, i32 noundef 122, ptr noundef @__PRETTY_FUNCTION__.vebr_destroy) #7
  unreachable

9:                                                ; preds = %7
  store i64 0, ptr %3, align 8
  br label %10

10:                                               ; preds = %21, %9
  %11 = load i64, ptr %3, align 8
  %12 = icmp ult i64 %11, 3
  br i1 %12, label %13, label %24

13:                                               ; preds = %10
  %14 = load ptr, ptr %2, align 8
  %15 = getelementptr inbounds nuw %struct.vebr_s, ptr %14, i32 0, i32 1
  %16 = load i64, ptr %3, align 8
  %17 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %15, i64 0, i64 %16
  %18 = call ptr @smr_nodes_list_get_and_empty(ptr noundef %17)
  store ptr %18, ptr %4, align 8
  %19 = load ptr, ptr %4, align 8
  %20 = call i64 @smr_nodes_list_destroy(ptr noundef %19)
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %3, align 8
  %23 = add i64 %22, 1
  store i64 %23, ptr %3, align 8
  br label %10, !llvm.loop !18

24:                                               ; preds = %10
  ret void
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_destroy(ptr noundef) #1

; Function Attrs: nounwind
declare i32 @pthread_mutex_lock(ptr noundef) #1

; Function Attrs: nounwind
declare i32 @pthread_mutex_unlock(ptr noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomic_fence() #0 {
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !19
  fence seq_cst
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !20
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @vatomic64_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !21
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %5, i32 0, i32 0
  %7 = load atomic i64, ptr %6 seq_cst, align 8
  store i64 %7, ptr %4, align 8
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %3, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !22
  %9 = load i64, ptr %3, align 8
  ret i64 %9
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @smr_nodes_list_add(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  store ptr %3, ptr %8, align 8
  %9 = load ptr, ptr %5, align 8
  %10 = icmp ne ptr %9, null
  br i1 %10, label %11, label %12

11:                                               ; preds = %4
  br label %13

12:                                               ; preds = %4
  call void @__assert_fail(ptr noundef @.str.7, ptr noundef @.str.8, i32 noundef 110, ptr noundef @__PRETTY_FUNCTION__.smr_nodes_list_add) #7
  unreachable

13:                                               ; preds = %11
  %14 = load ptr, ptr %6, align 8
  %15 = icmp ne ptr %14, null
  br i1 %15, label %16, label %17

16:                                               ; preds = %13
  br label %18

17:                                               ; preds = %13
  call void @__assert_fail(ptr noundef @.str.9, ptr noundef @.str.8, i32 noundef 111, ptr noundef @__PRETTY_FUNCTION__.smr_nodes_list_add) #7
  unreachable

18:                                               ; preds = %16
  %19 = load ptr, ptr %7, align 8
  %20 = icmp ne ptr %19, null
  br i1 %20, label %21, label %22

21:                                               ; preds = %18
  br label %23

22:                                               ; preds = %18
  call void @__assert_fail(ptr noundef @.str.10, ptr noundef @.str.8, i32 noundef 112, ptr noundef @__PRETTY_FUNCTION__.smr_nodes_list_add) #7
  unreachable

23:                                               ; preds = %21
  %24 = load ptr, ptr %7, align 8
  %25 = load ptr, ptr %6, align 8
  %26 = getelementptr inbounds nuw %struct.smr_node_s, ptr %25, i32 0, i32 2
  store ptr %24, ptr %26, align 8
  %27 = load ptr, ptr %8, align 8
  %28 = load ptr, ptr %6, align 8
  %29 = getelementptr inbounds nuw %struct.smr_node_s, ptr %28, i32 0, i32 3
  store ptr %27, ptr %29, align 8
  %30 = load ptr, ptr %6, align 8
  %31 = getelementptr inbounds nuw %struct.smr_node_s, ptr %30, i32 0, i32 0
  %32 = getelementptr inbounds nuw %struct.smr_node_core_s, ptr %31, i32 0, i32 0
  store ptr null, ptr %32, align 8
  %33 = load ptr, ptr %5, align 8
  %34 = load ptr, ptr %6, align 8
  %35 = getelementptr inbounds nuw %struct.smr_node_s, ptr %34, i32 0, i32 0
  %36 = load ptr, ptr %6, align 8
  %37 = getelementptr inbounds nuw %struct.smr_node_s, ptr %36, i32 0, i32 0
  call void @_smr_nodes_list_connect(ptr noundef %33, ptr noundef %35, ptr noundef %37)
  %38 = load ptr, ptr %5, align 8
  %39 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %38, i32 0, i32 1
  call void @vatomic64_inc_rlx(ptr noundef %39)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @_smr_nodes_list_connect(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  %9 = load ptr, ptr %4, align 8
  %10 = icmp ne ptr %9, null
  br i1 %10, label %11, label %12

11:                                               ; preds = %3
  br label %13

12:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.7, ptr noundef @.str.8, i32 noundef 78, ptr noundef @__PRETTY_FUNCTION__._smr_nodes_list_connect) #7
  unreachable

13:                                               ; preds = %11
  %14 = load ptr, ptr %5, align 8
  %15 = icmp ne ptr %14, null
  br i1 %15, label %16, label %17

16:                                               ; preds = %13
  br label %18

17:                                               ; preds = %13
  call void @__assert_fail(ptr noundef @.str.11, ptr noundef @.str.8, i32 noundef 79, ptr noundef @__PRETTY_FUNCTION__._smr_nodes_list_connect) #7
  unreachable

18:                                               ; preds = %16
  %19 = load ptr, ptr %6, align 8
  %20 = icmp ne ptr %19, null
  br i1 %20, label %21, label %22

21:                                               ; preds = %18
  br label %23

22:                                               ; preds = %18
  call void @__assert_fail(ptr noundef @.str.12, ptr noundef @.str.8, i32 noundef 80, ptr noundef @__PRETTY_FUNCTION__._smr_nodes_list_connect) #7
  unreachable

23:                                               ; preds = %21
  %24 = load ptr, ptr %4, align 8
  %25 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %24, i32 0, i32 0
  %26 = call ptr @vatomicptr_read(ptr noundef %25)
  store ptr %26, ptr %7, align 8
  br label %27

27:                                               ; preds = %40, %23
  %28 = load ptr, ptr %7, align 8
  store ptr %28, ptr %8, align 8
  %29 = load ptr, ptr %8, align 8
  %30 = load ptr, ptr %6, align 8
  %31 = getelementptr inbounds nuw %struct.smr_node_core_s, ptr %30, i32 0, i32 0
  store ptr %29, ptr %31, align 8
  %32 = load ptr, ptr %4, align 8
  %33 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %32, i32 0, i32 0
  %34 = load ptr, ptr %8, align 8
  %35 = load ptr, ptr %5, align 8
  %36 = call ptr @vatomicptr_cmpxchg_rel(ptr noundef %33, ptr noundef %34, ptr noundef %35)
  store ptr %36, ptr %7, align 8
  %37 = load ptr, ptr %7, align 8
  %38 = load ptr, ptr %8, align 8
  %39 = icmp eq ptr %37, %38
  call void @verification_assume(i1 noundef %39)
  br label %40

40:                                               ; preds = %27
  %41 = load ptr, ptr %8, align 8
  %42 = load ptr, ptr %7, align 8
  %43 = icmp ne ptr %41, %42
  br i1 %43, label %27, label %44, !llvm.loop !23

44:                                               ; preds = %40
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomic64_inc_rlx(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = call i64 @vatomic64_get_inc_rlx(ptr noundef %3)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !24
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %5, i32 0, i32 0
  %7 = load atomic i64, ptr %6 seq_cst, align 8
  store i64 %7, ptr %4, align 8
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %3, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !25
  %9 = load ptr, ptr %3, align 8
  ret ptr %9
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_cmpxchg_rel(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %10 = load ptr, ptr %5, align 8
  store ptr %10, ptr %7, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !26
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %6, align 8
  store ptr %13, ptr %8, align 8
  %14 = load i64, ptr %7, align 8
  %15 = load i64, ptr %8, align 8
  %16 = cmpxchg ptr %12, i64 %14, i64 %15 release monotonic, align 8
  %17 = extractvalue { i64, i1 } %16, 0
  %18 = extractvalue { i64, i1 } %16, 1
  br i1 %18, label %20, label %19

19:                                               ; preds = %3
  store i64 %17, ptr %7, align 8
  br label %20

20:                                               ; preds = %19, %3
  %21 = zext i1 %18 to i8
  store i8 %21, ptr %9, align 1
  %22 = load i8, ptr %9, align 1
  %23 = trunc i8 %22 to i1
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !27
  %24 = load ptr, ptr %7, align 8
  ret ptr %24
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @verification_assume(i1 noundef %0) #0 {
  %2 = alloca i8, align 1
  %3 = zext i1 %0 to i8
  store i8 %3, ptr %2, align 1
  br label %4

4:                                                ; preds = %1
  br label %5

5:                                                ; preds = %4
  %6 = load i8, ptr %2, align 1
  %7 = trunc i8 %6 to i1
  br label %8

8:                                                ; preds = %5
  br label %9

9:                                                ; preds = %8
  br label %10

10:                                               ; preds = %9
  br label %11

11:                                               ; preds = %10
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @vatomic64_get_inc_rlx(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = call i64 @vatomic64_get_add_rlx(ptr noundef %3, i64 noundef 1)
  ret i64 %4
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @vatomic64_get_add_rlx(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !28
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %8, i32 0, i32 0
  %10 = load i64, ptr %4, align 8
  store i64 %10, ptr %6, align 8
  %11 = load i64, ptr %6, align 8
  %12 = atomicrmw add ptr %9, i64 %11 monotonic, align 8
  store i64 %12, ptr %7, align 8
  %13 = load i64, ptr %7, align 8
  store i64 %13, ptr %5, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !29
  %14 = load i64, ptr %5, align 8
  ret i64 %14
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @smr_nodes_list_get_and_empty(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %4, i32 0, i32 0
  %6 = call ptr @vatomicptr_xchg_acq(ptr noundef %5, ptr noundef null)
  store ptr %6, ptr %3, align 8
  %7 = load ptr, ptr %2, align 8
  %8 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %7, i32 0, i32 1
  call void @vatomic64_write_rlx(ptr noundef %8, i64 noundef 0)
  %9 = load ptr, ptr %3, align 8
  ret ptr %9
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @_vebr_sync_epochs(ptr noundef %0, i64 noundef %1, i1 noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i8, align 1
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  %14 = zext i1 %2 to i8
  store i8 %14, ptr %6, align 1
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store i64 0, ptr %9, align 8
  store i64 -1, ptr %10, align 8
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_s, ptr %15, i32 0, i32 3
  %17 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %16, i32 0, i32 0
  %18 = load ptr, ptr %17, align 8
  %19 = load ptr, ptr %4, align 8
  %20 = getelementptr inbounds nuw %struct.vebr_s, ptr %19, i32 0, i32 3
  %21 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %20, i32 0, i32 2
  %22 = load ptr, ptr %21, align 8
  call void %18(ptr noundef %22)
  %23 = load ptr, ptr %4, align 8
  %24 = getelementptr inbounds nuw %struct.vebr_s, ptr %23, i32 0, i32 2
  %25 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %24, i32 0, i32 0
  %26 = load ptr, ptr %25, align 8
  store ptr %26, ptr %7, align 8
  br label %27

27:                                               ; preds = %67, %3
  %28 = load ptr, ptr %7, align 8
  %29 = icmp ne ptr %28, null
  br i1 %29, label %30, label %71

30:                                               ; preds = %27
  %31 = load ptr, ptr %7, align 8
  store ptr %31, ptr %8, align 8
  br label %32

32:                                               ; preds = %65, %30
  %33 = load ptr, ptr %8, align 8
  %34 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %33, i32 0, i32 1
  %35 = call i64 @vatomic64_read(ptr noundef %34)
  store i64 %35, ptr %9, align 8
  %36 = load i64, ptr %9, align 8
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %39

38:                                               ; preds = %32
  br label %66

39:                                               ; preds = %32
  %40 = load i64, ptr %9, align 8
  %41 = load i64, ptr %5, align 8
  %42 = icmp uge i64 %40, %41
  br i1 %42, label %43, label %56

43:                                               ; preds = %39
  %44 = load i64, ptr %10, align 8
  store i64 %44, ptr %11, align 8
  %45 = load i64, ptr %9, align 8
  store i64 %45, ptr %12, align 8
  %46 = load i64, ptr %11, align 8
  %47 = load i64, ptr %12, align 8
  %48 = icmp ult i64 %46, %47
  br i1 %48, label %49, label %51

49:                                               ; preds = %43
  %50 = load i64, ptr %11, align 8
  br label %53

51:                                               ; preds = %43
  %52 = load i64, ptr %12, align 8
  br label %53

53:                                               ; preds = %51, %49
  %54 = phi i64 [ %50, %49 ], [ %52, %51 ]
  store i64 %54, ptr %13, align 8
  %55 = load i64, ptr %13, align 8
  store i64 %55, ptr %10, align 8
  br label %66

56:                                               ; preds = %39
  %57 = load i8, ptr %6, align 1
  %58 = trunc i8 %57 to i1
  br i1 %58, label %61, label %59

59:                                               ; preds = %56
  %60 = load i64, ptr %9, align 8
  store i64 %60, ptr %10, align 8
  br label %72

61:                                               ; preds = %56
  call void @verification_ignore()
  br label %62

62:                                               ; preds = %61
  br label %63

63:                                               ; preds = %62
  br label %64

64:                                               ; preds = %63
  br label %65

65:                                               ; preds = %64
  br i1 true, label %32, label %66

66:                                               ; preds = %65, %53, %38
  br label %67

67:                                               ; preds = %66
  %68 = load ptr, ptr %7, align 8
  %69 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %68, i32 0, i32 0
  %70 = load ptr, ptr %69, align 8
  store ptr %70, ptr %7, align 8
  br label %27, !llvm.loop !30

71:                                               ; preds = %27
  br label %72

72:                                               ; preds = %71, %59
  %73 = load ptr, ptr %4, align 8
  %74 = getelementptr inbounds nuw %struct.vebr_s, ptr %73, i32 0, i32 3
  %75 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %74, i32 0, i32 1
  %76 = load ptr, ptr %75, align 8
  %77 = load ptr, ptr %4, align 8
  %78 = getelementptr inbounds nuw %struct.vebr_s, ptr %77, i32 0, i32 3
  %79 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %78, i32 0, i32 2
  %80 = load ptr, ptr %79, align 8
  call void %76(ptr noundef %80)
  %81 = load i64, ptr %10, align 8
  %82 = icmp eq i64 %81, -1
  br i1 %82, label %83, label %84

83:                                               ; preds = %72
  br label %86

84:                                               ; preds = %72
  %85 = load i64, ptr %10, align 8
  br label %86

86:                                               ; preds = %84, %83
  %87 = phi i64 [ 0, %83 ], [ %85, %84 ]
  ret i64 %87
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @vatomic64_cmpxchg(ptr noundef %0, i64 noundef %1, i64 noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  %10 = load i64, ptr %5, align 8
  store i64 %10, ptr %7, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !31
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %6, align 8
  store i64 %13, ptr %8, align 8
  %14 = load i64, ptr %7, align 8
  %15 = load i64, ptr %8, align 8
  %16 = cmpxchg ptr %12, i64 %14, i64 %15 seq_cst seq_cst, align 8
  %17 = extractvalue { i64, i1 } %16, 0
  %18 = extractvalue { i64, i1 } %16, 1
  br i1 %18, label %20, label %19

19:                                               ; preds = %3
  store i64 %17, ptr %7, align 8
  br label %20

20:                                               ; preds = %19, %3
  %21 = zext i1 %18 to i8
  store i8 %21, ptr %9, align 1
  %22 = load i8, ptr %9, align 1
  %23 = trunc i8 %22 to i1
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !32
  %24 = load i64, ptr %7, align 8
  ret i64 %24
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @smr_nodes_list_destroy(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  %6 = load ptr, ptr %2, align 8
  store ptr %6, ptr %4, align 8
  store ptr null, ptr %5, align 8
  br label %7

7:                                                ; preds = %22, %1
  %8 = load ptr, ptr %4, align 8
  %9 = icmp ne ptr %8, null
  br i1 %9, label %10, label %32

10:                                               ; preds = %7
  %11 = load ptr, ptr %4, align 8
  store ptr %11, ptr %5, align 8
  %12 = load ptr, ptr %4, align 8
  %13 = getelementptr inbounds nuw %struct.smr_node_s, ptr %12, i32 0, i32 0
  %14 = getelementptr inbounds nuw %struct.smr_node_core_s, ptr %13, i32 0, i32 0
  %15 = load ptr, ptr %14, align 8
  store ptr %15, ptr %4, align 8
  %16 = load ptr, ptr %5, align 8
  %17 = getelementptr inbounds nuw %struct.smr_node_s, ptr %16, i32 0, i32 2
  %18 = load ptr, ptr %17, align 8
  %19 = icmp ne ptr %18, null
  br i1 %19, label %20, label %21

20:                                               ; preds = %10
  br label %22

21:                                               ; preds = %10
  call void @__assert_fail(ptr noundef @.str.15, ptr noundef @.str.8, i32 noundef 197, ptr noundef @__PRETTY_FUNCTION__.smr_nodes_list_destroy) #7
  unreachable

22:                                               ; preds = %20
  %23 = load ptr, ptr %5, align 8
  %24 = getelementptr inbounds nuw %struct.smr_node_s, ptr %23, i32 0, i32 2
  %25 = load ptr, ptr %24, align 8
  %26 = load ptr, ptr %5, align 8
  %27 = load ptr, ptr %5, align 8
  %28 = getelementptr inbounds nuw %struct.smr_node_s, ptr %27, i32 0, i32 3
  %29 = load ptr, ptr %28, align 8
  call void %25(ptr noundef %26, ptr noundef %29)
  %30 = load i64, ptr %3, align 8
  %31 = add i64 %30, 1
  store i64 %31, ptr %3, align 8
  br label %7, !llvm.loop !33

32:                                               ; preds = %7
  %33 = load i64, ptr %3, align 8
  ret i64 %33
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_xchg_acq(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !34
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %8, i32 0, i32 0
  %10 = load ptr, ptr %4, align 8
  store ptr %10, ptr %6, align 8
  %11 = load i64, ptr %6, align 8
  %12 = atomicrmw xchg ptr %9, i64 %11 acquire, align 8
  store i64 %12, ptr %7, align 8
  %13 = load ptr, ptr %7, align 8
  store ptr %13, ptr %5, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !35
  %14 = load ptr, ptr %5, align 8
  ret ptr %14
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomic64_write_rlx(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !36
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !37
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @verification_ignore() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomic64_init(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  call void @vatomic64_write(ptr noundef %5, i64 noundef %6)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @dbl_list_add(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %8

7:                                                ; preds = %2
  br label %9

8:                                                ; preds = %2
  call void @__assert_fail(ptr noundef @.str.18, ptr noundef @.str.19, i32 noundef 40, ptr noundef @__PRETTY_FUNCTION__.dbl_list_add) #7
  unreachable

9:                                                ; preds = %7
  %10 = load ptr, ptr %4, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %12, label %13

12:                                               ; preds = %9
  br label %14

13:                                               ; preds = %9
  call void @__assert_fail(ptr noundef @.str.9, ptr noundef @.str.19, i32 noundef 41, ptr noundef @__PRETTY_FUNCTION__.dbl_list_add) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %3, align 8
  %16 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %15, i32 0, i32 0
  %17 = load ptr, ptr %16, align 8
  %18 = load ptr, ptr %4, align 8
  %19 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %18, i32 0, i32 0
  store ptr %17, ptr %19, align 8
  %20 = load ptr, ptr %3, align 8
  %21 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %20, i32 0, i32 0
  %22 = load ptr, ptr %21, align 8
  %23 = icmp ne ptr %22, null
  br i1 %23, label %24, label %30

24:                                               ; preds = %14
  %25 = load ptr, ptr %4, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %26, i32 0, i32 0
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %28, i32 0, i32 1
  store ptr %25, ptr %29, align 8
  br label %30

30:                                               ; preds = %24, %14
  %31 = load ptr, ptr %4, align 8
  %32 = load ptr, ptr %3, align 8
  %33 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %32, i32 0, i32 0
  store ptr %31, ptr %33, align 8
  %34 = load ptr, ptr %4, align 8
  %35 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %34, i32 0, i32 1
  store ptr null, ptr %35, align 8
  %36 = load ptr, ptr %3, align 8
  %37 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %36, i32 0, i32 1
  %38 = load i64, ptr %37, align 8
  %39 = add i64 %38, 1
  store i64 %39, ptr %37, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomic64_write(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !38
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !39
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomic64_write_rel(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !40
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !41
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_cmpxchg(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %10 = load ptr, ptr %5, align 8
  store ptr %10, ptr %7, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !42
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %6, align 8
  store ptr %13, ptr %8, align 8
  %14 = load i64, ptr %7, align 8
  %15 = load i64, ptr %8, align 8
  %16 = cmpxchg ptr %12, i64 %14, i64 %15 seq_cst seq_cst, align 8
  %17 = extractvalue { i64, i1 } %16, 0
  %18 = extractvalue { i64, i1 } %16, 1
  br i1 %18, label %20, label %19

19:                                               ; preds = %3
  store i64 %17, ptr %7, align 8
  br label %20

20:                                               ; preds = %19, %3
  %21 = zext i1 %18 to i8
  store i8 %21, ptr %9, align 1
  %22 = load i8, ptr %9, align 1
  %23 = trunc i8 %22 to i1
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !43
  %24 = load ptr, ptr %7, align 8
  ret ptr %24
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomicptr_write_rlx(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !44
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %6, i32 0, i32 0
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !45
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i64 @vatomic64_read_rlx(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !46
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %5, i32 0, i32 0
  %7 = load atomic i64, ptr %6 monotonic, align 8
  store i64 %7, ptr %4, align 8
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %3, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !47
  %9 = load i64, ptr %3, align 8
  ret i64 %9
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @dbl_list_rem(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = icmp ne ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  br label %11

10:                                               ; preds = %2
  call void @__assert_fail(ptr noundef @.str.18, ptr noundef @.str.19, i32 noundef 55, ptr noundef @__PRETTY_FUNCTION__.dbl_list_rem) #7
  unreachable

11:                                               ; preds = %9
  %12 = load ptr, ptr %4, align 8
  %13 = icmp ne ptr %12, null
  br i1 %13, label %14, label %15

14:                                               ; preds = %11
  br label %16

15:                                               ; preds = %11
  call void @__assert_fail(ptr noundef @.str.9, ptr noundef @.str.19, i32 noundef 56, ptr noundef @__PRETTY_FUNCTION__.dbl_list_rem) #7
  unreachable

16:                                               ; preds = %14
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %17, i32 0, i32 0
  %19 = load ptr, ptr %18, align 8
  store ptr %19, ptr %5, align 8
  %20 = load ptr, ptr %4, align 8
  %21 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %20, i32 0, i32 1
  %22 = load ptr, ptr %21, align 8
  store ptr %22, ptr %6, align 8
  %23 = load ptr, ptr %6, align 8
  %24 = icmp ne ptr %23, null
  br i1 %24, label %25, label %45

25:                                               ; preds = %16
  %26 = load ptr, ptr %6, align 8
  %27 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %26, i32 0, i32 0
  %28 = load ptr, ptr %27, align 8
  %29 = load ptr, ptr %4, align 8
  %30 = icmp eq ptr %28, %29
  br i1 %30, label %31, label %32

31:                                               ; preds = %25
  br label %33

32:                                               ; preds = %25
  call void @__assert_fail(ptr noundef @.str.29, ptr noundef @.str.19, i32 noundef 62, ptr noundef @__PRETTY_FUNCTION__.dbl_list_rem) #7
  unreachable

33:                                               ; preds = %31
  %34 = load ptr, ptr %3, align 8
  %35 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %34, i32 0, i32 0
  %36 = load ptr, ptr %35, align 8
  %37 = load ptr, ptr %4, align 8
  %38 = icmp ne ptr %36, %37
  br i1 %38, label %39, label %40

39:                                               ; preds = %33
  br label %41

40:                                               ; preds = %33
  call void @__assert_fail(ptr noundef @.str.30, ptr noundef @.str.19, i32 noundef 63, ptr noundef @__PRETTY_FUNCTION__.dbl_list_rem) #7
  unreachable

41:                                               ; preds = %39
  %42 = load ptr, ptr %5, align 8
  %43 = load ptr, ptr %6, align 8
  %44 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %43, i32 0, i32 0
  store ptr %42, ptr %44, align 8
  br label %57

45:                                               ; preds = %16
  %46 = load ptr, ptr %3, align 8
  %47 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %46, i32 0, i32 0
  %48 = load ptr, ptr %47, align 8
  %49 = load ptr, ptr %4, align 8
  %50 = icmp eq ptr %48, %49
  br i1 %50, label %51, label %52

51:                                               ; preds = %45
  br label %53

52:                                               ; preds = %45
  call void @__assert_fail(ptr noundef @.str.31, ptr noundef @.str.19, i32 noundef 66, ptr noundef @__PRETTY_FUNCTION__.dbl_list_rem) #7
  unreachable

53:                                               ; preds = %51
  %54 = load ptr, ptr %5, align 8
  %55 = load ptr, ptr %3, align 8
  %56 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %55, i32 0, i32 0
  store ptr %54, ptr %56, align 8
  br label %57

57:                                               ; preds = %53, %41
  %58 = load ptr, ptr %5, align 8
  %59 = icmp ne ptr %58, null
  br i1 %59, label %60, label %72

60:                                               ; preds = %57
  %61 = load ptr, ptr %5, align 8
  %62 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %61, i32 0, i32 1
  %63 = load ptr, ptr %62, align 8
  %64 = load ptr, ptr %4, align 8
  %65 = icmp eq ptr %63, %64
  br i1 %65, label %66, label %67

66:                                               ; preds = %60
  br label %68

67:                                               ; preds = %60
  call void @__assert_fail(ptr noundef @.str.32, ptr noundef @.str.19, i32 noundef 71, ptr noundef @__PRETTY_FUNCTION__.dbl_list_rem) #7
  unreachable

68:                                               ; preds = %66
  %69 = load ptr, ptr %6, align 8
  %70 = load ptr, ptr %5, align 8
  %71 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %70, i32 0, i32 1
  store ptr %69, ptr %71, align 8
  br label %72

72:                                               ; preds = %68, %57
  %73 = load ptr, ptr %3, align 8
  %74 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %73, i32 0, i32 1
  %75 = load i64, ptr %74, align 8
  %76 = add i64 %75, -1
  store i64 %76, ptr %74, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @dbl_list_init(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  br label %7

6:                                                ; preds = %1
  call void @__assert_fail(ptr noundef @.str.18, ptr noundef @.str.19, i32 noundef 32, ptr noundef @__PRETTY_FUNCTION__.dbl_list_init) #7
  unreachable

7:                                                ; preds = %5
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %8, i32 0, i32 0
  store ptr null, ptr %9, align 8
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %10, i32 0, i32 1
  store i64 0, ptr %11, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @smr_nodes_list_init(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  br label %7

6:                                                ; preds = %1
  call void @__assert_fail(ptr noundef @.str.7, ptr noundef @.str.8, i32 noundef 34, ptr noundef @__PRETTY_FUNCTION__.smr_nodes_list_init) #7
  unreachable

7:                                                ; preds = %5
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %8, i32 0, i32 0
  call void @vatomicptr_init(ptr noundef %9, ptr noundef null)
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %10, i32 0, i32 1
  call void @vatomic64_init(ptr noundef %11, i64 noundef 0)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i1 @smr_lock_lib_is_set(ptr noundef %0) #0 {
  %2 = alloca i1, align 1
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = icmp ne ptr %4, null
  br i1 %5, label %7, label %6

6:                                                ; preds = %1
  store i1 false, ptr %2, align 1
  br label %20

7:                                                ; preds = %1
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %8, i32 0, i32 0
  %10 = load ptr, ptr %9, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %13, label %12

12:                                               ; preds = %7
  store i1 false, ptr %2, align 1
  br label %20

13:                                               ; preds = %7
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %14, i32 0, i32 1
  %16 = load ptr, ptr %15, align 8
  %17 = icmp ne ptr %16, null
  br i1 %17, label %19, label %18

18:                                               ; preds = %13
  store i1 false, ptr %2, align 1
  br label %20

19:                                               ; preds = %13
  store i1 true, ptr %2, align 1
  br label %20

20:                                               ; preds = %19, %18, %12, %6
  %21 = load i1, ptr %2, align 1
  ret i1 %21
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomicptr_init(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load ptr, ptr %4, align 8
  call void @vatomicptr_write(ptr noundef %5, ptr noundef %6)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomicptr_write(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !48
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %6, i32 0, i32 0
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #6, !srcloc !49
  ret void
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #2 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #3 = { nounwind allocsize(0) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { cold noreturn nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind }
attributes #7 = { cold noreturn nounwind }
attributes #8 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{i64 2147992487}
!9 = !{i64 2147992527}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = !{i64 2147993891}
!16 = !{i64 2147993931}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
!19 = !{i64 2147992251}
!20 = !{i64 2147992291}
!21 = !{i64 2147993189}
!22 = !{i64 2147993229}
!23 = distinct !{!23, !7}
!24 = !{i64 2147993657}
!25 = !{i64 2147993697}
!26 = !{i64 2147998927}
!27 = !{i64 2147998969}
!28 = !{i64 2148004937}
!29 = !{i64 2148004977}
!30 = distinct !{!30, !7}
!31 = !{i64 2147998127}
!32 = !{i64 2147998169}
!33 = distinct !{!33, !7}
!34 = !{i64 2147996933}
!35 = !{i64 2147996973}
!36 = !{i64 2147994749}
!37 = !{i64 2147994789}
!38 = !{i64 2147994593}
!39 = !{i64 2147994633}
!40 = !{i64 2147994671}
!41 = !{i64 2147994711}
!42 = !{i64 2147998767}
!43 = !{i64 2147998809}
!44 = !{i64 2147995217}
!45 = !{i64 2147995257}
!46 = !{i64 2147993345}
!47 = !{i64 2147993385}
!48 = !{i64 2147995061}
!49 = !{i64 2147995101}
