; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, [112 x i8], %struct.vqueue_ub_node_s }
%struct.vatomicptr_s = type { ptr }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, [112 x i8] }
%struct.data_s = type { i64 }

@local_pools = global [12 x ptr] zeroinitializer, align 16
@.str = private unnamed_addr constant [20 x i8] c"Recycle allocation\0A\00", align 1
@.str.1 = private unnamed_addr constant [16 x i8] c"New allocation\0A\00", align 1
@.str.2 = private unnamed_addr constant [6 x i8] c"qnode\00", align 1
@.str.3 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c\00", align 1
@__PRETTY_FUNCTION__.alloc_qnode = private unnamed_addr constant [39 x i8] c"vqueue_ub_node_t *alloc_qnode(vsize_t)\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 128
@.str.4 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.5 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@.str.6 = private unnamed_addr constant [48 x i8] c"((((vuintptr_t)(v)) & ((vuintptr_t)0x7F)) == 0)\00", align 1
@.str.7 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/include/vsync/atomic/atomicptr_stamped.h\00", align 1
@__PRETTY_FUNCTION__.vatomicptr_stamped_set = private unnamed_addr constant [70 x i8] c"void vatomicptr_stamped_set(vatomicptr_stamped_t *, void *, vuint8_t)\00", align 1
@.str.8 = private unnamed_addr constant [50 x i8] c"((((vuintptr_t)(e_v)) & ((vuintptr_t)0x7F)) == 0)\00", align 1
@__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg = private unnamed_addr constant [95 x i8] c"vbool_t vatomicptr_stamped_cmpxchg(vatomicptr_stamped_t *, void *, vuint8_t, void *, vuint8_t)\00", align 1
@.str.9 = private unnamed_addr constant [2 x i8] c"q\00", align 1
@.str.10 = private unnamed_addr constant [72 x i8] c"C:/rc1111/src/libvsync/include/vsync/queue/unbounded_queue_lf_recycle.h\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_enq = private unnamed_addr constant [62 x i8] c"void vqueue_ub_enq(vqueue_ub_t *, vqueue_ub_node_t *, void *)\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_init = private unnamed_addr constant [35 x i8] c"void vqueue_ub_init(vqueue_ub_t *)\00", align 1
@__PRETTY_FUNCTION__.vatomicptr_stamped_set_rlx = private unnamed_addr constant [74 x i8] c"void vatomicptr_stamped_set_rlx(vatomicptr_stamped_t *, void *, vuint8_t)\00", align 1

; Function Attrs: noinline nounwind optnone uwtable
define void @destroy_pools() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  store ptr null, ptr %1, align 8
  store ptr null, ptr %2, align 8
  store i64 0, ptr %3, align 8
  br label %4

4:                                                ; preds = %21, %0
  %5 = load i64, ptr %3, align 8
  %6 = icmp ult i64 %5, 12
  br i1 %6, label %7, label %24

7:                                                ; preds = %4
  %8 = load i64, ptr %3, align 8
  %9 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %8
  %10 = load ptr, ptr %9, align 8
  store ptr %10, ptr %1, align 8
  br label %11

11:                                               ; preds = %14, %7
  %12 = load ptr, ptr %1, align 8
  %13 = icmp ne ptr %12, null
  br i1 %13, label %14, label %20

14:                                               ; preds = %11
  %15 = load ptr, ptr %1, align 8
  %16 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %15, i32 0, i32 1
  %17 = call ptr @vatomicptr_stamped_get_pointer(ptr noundef %16)
  store ptr %17, ptr %2, align 8
  %18 = load ptr, ptr %1, align 8
  call void @free(ptr noundef %18) #6
  %19 = load ptr, ptr %2, align 8
  store ptr %19, ptr %1, align 8
  br label %11, !llvm.loop !6

20:                                               ; preds = %11
  br label %21

21:                                               ; preds = %20
  %22 = load i64, ptr %3, align 8
  %23 = add i64 %22, 1
  store i64 %23, ptr %3, align 8
  br label %4, !llvm.loop !8

24:                                               ; preds = %4
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_stamped_get_pointer(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i8, align 1
  store ptr %0, ptr %2, align 8
  store i8 0, ptr %3, align 1
  %4 = load ptr, ptr %2, align 8
  %5 = call ptr @vatomicptr_stamped_get(ptr noundef %4, ptr noundef %3)
  ret ptr %5
}

; Function Attrs: nounwind
declare void @free(ptr noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define void @destroy_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  call void @free(ptr noundef %5) #6
  %6 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define void @retire_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i8, align 1
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %7 = load ptr, ptr %4, align 8
  %8 = ptrtoint ptr %7 to i64
  store i64 %8, ptr %5, align 8
  store i8 0, ptr %6, align 1
  %9 = load ptr, ptr %3, align 8
  %10 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %9, i32 0, i32 1
  %11 = call ptr @vatomicptr_stamped_get(ptr noundef %10, ptr noundef %6)
  %12 = load ptr, ptr %3, align 8
  %13 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %12, i32 0, i32 1
  %14 = load i64, ptr %5, align 8
  %15 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %14
  %16 = load ptr, ptr %15, align 8
  %17 = load i8, ptr %6, align 1
  %18 = zext i8 %17 to i32
  %19 = add nsw i32 %18, 1
  %20 = trunc i32 %19 to i8
  call void @vatomicptr_stamped_set(ptr noundef %13, ptr noundef %16, i8 noundef zeroext %20)
  %21 = load ptr, ptr %3, align 8
  %22 = load i64, ptr %5, align 8
  %23 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %22
  store ptr %21, ptr %23, align 8
  %24 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_stamped_get(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = call ptr @vatomicptr_read(ptr noundef %6)
  store ptr %7, ptr %5, align 8
  %8 = load ptr, ptr %5, align 8
  %9 = ptrtoint ptr %8 to i64
  %10 = and i64 %9, 127
  %11 = trunc i64 %10 to i8
  %12 = load ptr, ptr %4, align 8
  store i8 %11, ptr %12, align 1
  %13 = load ptr, ptr %5, align 8
  %14 = ptrtoint ptr %13 to i64
  %15 = and i64 %14, -128
  %16 = inttoptr i64 %15 to ptr
  ret ptr %16
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomicptr_stamped_set(ptr noundef %0, ptr noundef %1, i8 noundef zeroext %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i8, align 1
  %7 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store i8 %2, ptr %6, align 1
  %8 = load ptr, ptr %5, align 8
  %9 = ptrtoint ptr %8 to i64
  %10 = and i64 %9, 127
  %11 = icmp eq i64 %10, 0
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  br label %14

13:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.6, ptr noundef @.str.7, i32 noundef 291, ptr noundef @__PRETTY_FUNCTION__.vatomicptr_stamped_set) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %5, align 8
  %16 = ptrtoint ptr %15 to i64
  %17 = load i8, ptr %6, align 1
  %18 = zext i8 %17 to i64
  %19 = and i64 %18, 127
  %20 = trunc i64 %19 to i8
  %21 = zext i8 %20 to i64
  %22 = or i64 %16, %21
  %23 = inttoptr i64 %22 to ptr
  store ptr %23, ptr %7, align 8
  %24 = load ptr, ptr %4, align 8
  %25 = load ptr, ptr %7, align 8
  call void @vatomicptr_write(ptr noundef %24, ptr noundef %25)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define ptr @alloc_qnode(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  %3 = alloca ptr, align 8
  store i64 %0, ptr %2, align 8
  store ptr null, ptr %3, align 8
  %4 = load i64, ptr %2, align 8
  %5 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %4
  %6 = load ptr, ptr %5, align 8
  %7 = icmp ne ptr %6, null
  br i1 %7, label %8, label %20

8:                                                ; preds = %1
  %9 = load i64, ptr %2, align 8
  %10 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %9
  %11 = load ptr, ptr %10, align 8
  store ptr %11, ptr %3, align 8
  %12 = load i64, ptr %2, align 8
  %13 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %14, i32 0, i32 1
  %16 = call ptr @vatomicptr_stamped_get_pointer(ptr noundef %15)
  %17 = load i64, ptr %2, align 8
  %18 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %17
  store ptr %16, ptr %18, align 8
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str)
  br label %23

20:                                               ; preds = %1
  %21 = call noalias align 128 ptr @memalign(i64 noundef 128, i64 noundef 128) #8
  store ptr %21, ptr %3, align 8
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str.1)
  br label %23

23:                                               ; preds = %20, %8
  %24 = load ptr, ptr %3, align 8
  %25 = icmp ne ptr %24, null
  br i1 %25, label %26, label %27

26:                                               ; preds = %23
  br label %28

27:                                               ; preds = %23
  call void @__assert_fail(ptr noundef @.str.2, ptr noundef @.str.3, i32 noundef 77, ptr noundef @__PRETTY_FUNCTION__.alloc_qnode) #7
  unreachable

28:                                               ; preds = %26
  %29 = load ptr, ptr %3, align 8
  ret ptr %29
}

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: nounwind allocsize(1)
declare noalias ptr @memalign(i64 noundef, i64 noundef) #3

; Function Attrs: cold noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) #4

; Function Attrs: noinline nounwind optnone uwtable
define ptr @run(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store ptr null, ptr %3, align 8
  %7 = load ptr, ptr %2, align 8
  %8 = ptrtoint ptr %7 to i64
  store i64 %8, ptr %4, align 8
  store i64 0, ptr %5, align 8
  br label %9

9:                                                ; preds = %40, %1
  %10 = load i64, ptr %5, align 8
  %11 = icmp ult i64 %10, 100
  br i1 %11, label %12, label %43

12:                                               ; preds = %9
  %13 = load i64, ptr %4, align 8
  %14 = inttoptr i64 %13 to ptr
  %15 = call ptr @vqueue_ub_deq(ptr noundef @g_queue, ptr noundef @retire_cb, ptr noundef %14)
  store ptr %15, ptr %3, align 8
  %16 = load ptr, ptr %3, align 8
  %17 = icmp eq ptr %16, null
  br i1 %17, label %18, label %32

18:                                               ; preds = %12
  %19 = call noalias ptr @malloc(i64 noundef 8) #9
  store ptr %19, ptr %3, align 8
  %20 = load i64, ptr %5, align 8
  %21 = load ptr, ptr %3, align 8
  %22 = getelementptr inbounds nuw %struct.data_s, ptr %21, i32 0, i32 0
  store i64 %20, ptr %22, align 8
  %23 = load i64, ptr %4, align 8
  %24 = call ptr @alloc_qnode(i64 noundef %23)
  store ptr %24, ptr %6, align 8
  %25 = load i64, ptr %4, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = getelementptr inbounds nuw %struct.data_s, ptr %26, i32 0, i32 0
  %28 = load i64, ptr %27, align 8
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, i64 noundef %25, i64 noundef %28)
  %30 = load ptr, ptr %6, align 8
  %31 = load ptr, ptr %3, align 8
  call void @vqueue_ub_enq(ptr noundef @g_queue, ptr noundef %30, ptr noundef %31)
  br label %39

32:                                               ; preds = %12
  %33 = load i64, ptr %4, align 8
  %34 = load ptr, ptr %3, align 8
  %35 = getelementptr inbounds nuw %struct.data_s, ptr %34, i32 0, i32 0
  %36 = load i64, ptr %35, align 8
  %37 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, i64 noundef %33, i64 noundef %36)
  %38 = load ptr, ptr %3, align 8
  call void @free(ptr noundef %38) #6
  br label %39

39:                                               ; preds = %32, %18
  br label %40

40:                                               ; preds = %39
  %41 = load i64, ptr %5, align 8
  %42 = add i64 %41, 1
  store i64 %42, ptr %5, align 8
  br label %9, !llvm.loop !9

43:                                               ; preds = %9
  ret ptr null
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vqueue_ub_deq(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i8, align 1
  %12 = alloca i8, align 1
  %13 = alloca i8, align 1
  %14 = alloca i8, align 1
  %15 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store ptr null, ptr %9, align 8
  store ptr null, ptr %10, align 8
  store i8 0, ptr %11, align 1
  store i8 0, ptr %12, align 1
  store i8 0, ptr %13, align 1
  store i8 0, ptr %14, align 1
  store ptr null, ptr %15, align 8
  br label %16

16:                                               ; preds = %3, %83
  %17 = load ptr, ptr %5, align 8
  %18 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %17, i32 0, i32 0
  %19 = call ptr @vatomicptr_stamped_get(ptr noundef %18, ptr noundef %11)
  store ptr %19, ptr %8, align 8
  %20 = load ptr, ptr %5, align 8
  %21 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %20, i32 0, i32 1
  %22 = call ptr @vatomicptr_stamped_get(ptr noundef %21, ptr noundef %12)
  store ptr %22, ptr %9, align 8
  %23 = load ptr, ptr %8, align 8
  %24 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %23, i32 0, i32 1
  %25 = call ptr @vatomicptr_stamped_get(ptr noundef %24, ptr noundef %13)
  store ptr %25, ptr %10, align 8
  %26 = load ptr, ptr %8, align 8
  %27 = load ptr, ptr %5, align 8
  %28 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %27, i32 0, i32 0
  %29 = call ptr @vatomicptr_stamped_get(ptr noundef %28, ptr noundef %14)
  %30 = icmp eq ptr %26, %29
  br i1 %30, label %31, label %83

31:                                               ; preds = %16
  %32 = load i8, ptr %14, align 1
  %33 = zext i8 %32 to i32
  %34 = load i8, ptr %11, align 1
  %35 = zext i8 %34 to i32
  %36 = icmp eq i32 %33, %35
  br i1 %36, label %37, label %83

37:                                               ; preds = %31
  %38 = load ptr, ptr %8, align 8
  %39 = load ptr, ptr %9, align 8
  %40 = icmp eq ptr %38, %39
  br i1 %40, label %41, label %56

41:                                               ; preds = %37
  %42 = load ptr, ptr %10, align 8
  %43 = icmp eq ptr %42, null
  br i1 %43, label %44, label %45

44:                                               ; preds = %41
  store ptr null, ptr %4, align 8
  br label %84

45:                                               ; preds = %41
  call void @verification_ignore()
  %46 = load ptr, ptr %5, align 8
  %47 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %46, i32 0, i32 1
  %48 = load ptr, ptr %9, align 8
  %49 = load i8, ptr %12, align 1
  %50 = load ptr, ptr %10, align 8
  %51 = load i8, ptr %12, align 1
  %52 = zext i8 %51 to i32
  %53 = add nsw i32 %52, 1
  %54 = trunc i32 %53 to i8
  %55 = call zeroext i1 @vatomicptr_stamped_cmpxchg(ptr noundef %47, ptr noundef %48, i8 noundef zeroext %49, ptr noundef %50, i8 noundef zeroext %54)
  br label %82

56:                                               ; preds = %37
  %57 = load ptr, ptr %10, align 8
  %58 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %57, i32 0, i32 0
  %59 = load ptr, ptr %58, align 128
  store ptr %59, ptr %15, align 8
  %60 = load ptr, ptr %5, align 8
  %61 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %60, i32 0, i32 0
  %62 = load ptr, ptr %8, align 8
  %63 = load i8, ptr %11, align 1
  %64 = load ptr, ptr %10, align 8
  %65 = load i8, ptr %11, align 1
  %66 = zext i8 %65 to i32
  %67 = add nsw i32 %66, 1
  %68 = trunc i32 %67 to i8
  %69 = call zeroext i1 @vatomicptr_stamped_cmpxchg(ptr noundef %61, ptr noundef %62, i8 noundef zeroext %63, ptr noundef %64, i8 noundef zeroext %68)
  br i1 %69, label %70, label %81

70:                                               ; preds = %56
  %71 = load ptr, ptr %8, align 8
  %72 = load ptr, ptr %5, align 8
  %73 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %72, i32 0, i32 3
  %74 = icmp ne ptr %71, %73
  br i1 %74, label %75, label %79

75:                                               ; preds = %70
  %76 = load ptr, ptr %6, align 8
  %77 = load ptr, ptr %8, align 8
  %78 = load ptr, ptr %7, align 8
  call void %76(ptr noundef %77, ptr noundef %78)
  br label %79

79:                                               ; preds = %75, %70
  %80 = load ptr, ptr %15, align 8
  store ptr %80, ptr %4, align 8
  br label %84

81:                                               ; preds = %56
  br label %82

82:                                               ; preds = %81, %45
  br label %83

83:                                               ; preds = %82, %31, %16
  br label %16

84:                                               ; preds = %79, %44
  %85 = load ptr, ptr %4, align 8
  ret ptr %85
}

; Function Attrs: nounwind allocsize(0)
declare noalias ptr @malloc(i64 noundef) #5

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vqueue_ub_enq(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  %10 = alloca i8, align 1
  %11 = alloca i8, align 1
  %12 = alloca i8, align 1
  %13 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store i8 0, ptr %9, align 1
  store i8 0, ptr %10, align 1
  store i8 0, ptr %11, align 1
  store i8 0, ptr %12, align 1
  store i8 0, ptr %13, align 1
  %14 = load ptr, ptr %4, align 8
  %15 = icmp ne ptr %14, null
  br i1 %15, label %16, label %17

16:                                               ; preds = %3
  br label %18

17:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.9, ptr noundef @.str.10, i32 noundef 131, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_enq) #7
  unreachable

18:                                               ; preds = %16
  %19 = load ptr, ptr %5, align 8
  %20 = icmp ne ptr %19, null
  br i1 %20, label %21, label %22

21:                                               ; preds = %18
  br label %23

22:                                               ; preds = %18
  call void @__assert_fail(ptr noundef @.str.2, ptr noundef @.str.10, i32 noundef 132, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_enq) #7
  unreachable

23:                                               ; preds = %21
  %24 = load ptr, ptr %6, align 8
  %25 = load ptr, ptr %5, align 8
  %26 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %25, i32 0, i32 0
  store ptr %24, ptr %26, align 128
  %27 = load ptr, ptr %5, align 8
  %28 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %27, i32 0, i32 1
  %29 = call ptr @vatomicptr_stamped_get(ptr noundef %28, ptr noundef %12)
  %30 = load ptr, ptr %5, align 8
  %31 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %30, i32 0, i32 1
  %32 = load i8, ptr %12, align 1
  call void @vatomicptr_stamped_set(ptr noundef %31, ptr noundef null, i8 noundef zeroext %32)
  br label %33

33:                                               ; preds = %23, %94
  %34 = load ptr, ptr %4, align 8
  %35 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %34, i32 0, i32 1
  %36 = call ptr @vatomicptr_stamped_get(ptr noundef %35, ptr noundef %9)
  store ptr %36, ptr %7, align 8
  %37 = load ptr, ptr %7, align 8
  %38 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %37, i32 0, i32 1
  %39 = call ptr @vatomicptr_stamped_get(ptr noundef %38, ptr noundef %10)
  store ptr %39, ptr %8, align 8
  %40 = load ptr, ptr %7, align 8
  %41 = load ptr, ptr %4, align 8
  %42 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %41, i32 0, i32 1
  %43 = call ptr @vatomicptr_stamped_get(ptr noundef %42, ptr noundef %11)
  %44 = icmp eq ptr %40, %43
  br i1 %44, label %45, label %94

45:                                               ; preds = %33
  %46 = load i8, ptr %9, align 1
  %47 = zext i8 %46 to i32
  %48 = load i8, ptr %11, align 1
  %49 = zext i8 %48 to i32
  %50 = icmp eq i32 %47, %49
  br i1 %50, label %51, label %94

51:                                               ; preds = %45
  %52 = load ptr, ptr %8, align 8
  %53 = icmp eq ptr %52, null
  br i1 %53, label %54, label %82

54:                                               ; preds = %51
  %55 = load ptr, ptr %7, align 8
  %56 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %55, i32 0, i32 1
  %57 = load ptr, ptr %8, align 8
  %58 = load i8, ptr %10, align 1
  %59 = load ptr, ptr %5, align 8
  %60 = load i8, ptr %10, align 1
  %61 = zext i8 %60 to i32
  %62 = add nsw i32 %61, 1
  %63 = trunc i32 %62 to i8
  %64 = call zeroext i1 @vatomicptr_stamped_cmpxchg(ptr noundef %56, ptr noundef %57, i8 noundef zeroext %58, ptr noundef %59, i8 noundef zeroext %63)
  br i1 %64, label %65, label %81

65:                                               ; preds = %54
  %66 = load ptr, ptr %4, align 8
  %67 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %66, i32 0, i32 1
  %68 = load ptr, ptr %7, align 8
  %69 = load i8, ptr %9, align 1
  %70 = load ptr, ptr %5, align 8
  %71 = load i8, ptr %9, align 1
  %72 = zext i8 %71 to i32
  %73 = add nsw i32 %72, 1
  %74 = trunc i32 %73 to i8
  %75 = call zeroext i1 @vatomicptr_stamped_cmpxchg(ptr noundef %67, ptr noundef %68, i8 noundef zeroext %69, ptr noundef %70, i8 noundef zeroext %74)
  %76 = zext i1 %75 to i8
  store i8 %76, ptr %13, align 1
  %77 = load i8, ptr %13, align 1
  %78 = trunc i8 %77 to i1
  %79 = load i8, ptr %13, align 1
  %80 = trunc i8 %79 to i1
  call void @verification_assume(i1 noundef zeroext %80)
  ret void

81:                                               ; preds = %54
  br label %93

82:                                               ; preds = %51
  call void @verification_ignore()
  %83 = load ptr, ptr %4, align 8
  %84 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %83, i32 0, i32 1
  %85 = load ptr, ptr %7, align 8
  %86 = load i8, ptr %9, align 1
  %87 = load ptr, ptr %8, align 8
  %88 = load i8, ptr %9, align 1
  %89 = zext i8 %88 to i32
  %90 = add nsw i32 %89, 1
  %91 = trunc i32 %90 to i8
  %92 = call zeroext i1 @vatomicptr_stamped_cmpxchg(ptr noundef %84, ptr noundef %85, i8 noundef zeroext %86, ptr noundef %87, i8 noundef zeroext %91)
  br label %93

93:                                               ; preds = %82, %81
  br label %94

94:                                               ; preds = %93, %45, %33
  br label %33
}

; Function Attrs: noinline nounwind optnone uwtable
define i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [12 x i64], align 16
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  store ptr null, ptr %3, align 8
  call void @vqueue_ub_init(ptr noundef @g_queue)
  store i64 0, ptr %4, align 8
  br label %6

6:                                                ; preds = %15, %0
  %7 = load i64, ptr %4, align 8
  %8 = icmp ult i64 %7, 12
  br i1 %8, label %9, label %18

9:                                                ; preds = %6
  %10 = load i64, ptr %4, align 8
  %11 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %10
  %12 = load i64, ptr %4, align 8
  %13 = inttoptr i64 %12 to ptr
  %14 = call i32 @pthread_create(ptr noundef %11, ptr noundef null, ptr noundef @run, ptr noundef %13) #6
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %4, align 8
  %17 = add i64 %16, 1
  store i64 %17, ptr %4, align 8
  br label %6, !llvm.loop !10

18:                                               ; preds = %6
  store i64 0, ptr %5, align 8
  br label %19

19:                                               ; preds = %27, %18
  %20 = load i64, ptr %5, align 8
  %21 = icmp ult i64 %20, 12
  br i1 %21, label %22, label %30

22:                                               ; preds = %19
  %23 = load i64, ptr %5, align 8
  %24 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %23
  %25 = load i64, ptr %24, align 8
  %26 = call i32 @pthread_join(i64 noundef %25, ptr noundef null)
  br label %27

27:                                               ; preds = %22
  %28 = load i64, ptr %5, align 8
  %29 = add i64 %28, 1
  store i64 %29, ptr %5, align 8
  br label %19, !llvm.loop !11

30:                                               ; preds = %19
  br label %31

31:                                               ; preds = %35, %30
  %32 = call ptr @vqueue_ub_deq(ptr noundef @g_queue, ptr noundef @destroy_cb, ptr noundef null)
  store ptr %32, ptr %3, align 8
  %33 = load ptr, ptr %3, align 8
  %34 = icmp ne ptr %33, null
  br i1 %34, label %35, label %37

35:                                               ; preds = %31
  %36 = load ptr, ptr %3, align 8
  call void @free(ptr noundef %36) #6
  br label %31, !llvm.loop !12

37:                                               ; preds = %31
  call void @vqueue_ub_destroy(ptr noundef @g_queue, ptr noundef @destroy_cb, ptr noundef null)
  call void @destroy_pools()
  ret i32 0
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vqueue_ub_init(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  br label %7

6:                                                ; preds = %1
  call void @__assert_fail(ptr noundef @.str.9, ptr noundef @.str.10, i32 noundef 80, ptr noundef @__PRETTY_FUNCTION__.vqueue_ub_init) #7
  unreachable

7:                                                ; preds = %5
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %8, i32 0, i32 3
  %10 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %9, i32 0, i32 1
  call void @vatomicptr_stamped_set_rlx(ptr noundef %10, ptr noundef null, i8 noundef zeroext 0)
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %13, i32 0, i32 3
  call void @vatomicptr_stamped_set_rlx(ptr noundef %12, ptr noundef %14, i8 noundef zeroext 0)
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %15, i32 0, i32 1
  %17 = load ptr, ptr %2, align 8
  %18 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %17, i32 0, i32 3
  call void @vatomicptr_stamped_set_rlx(ptr noundef %16, ptr noundef %18, i8 noundef zeroext 0)
  ret void
}

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) #1

declare i32 @pthread_join(i64 noundef, ptr noundef) #2

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vqueue_ub_destroy(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  %9 = load ptr, ptr %4, align 8
  %10 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %9, i32 0, i32 0
  %11 = call ptr @vatomicptr_stamped_get_pointer(ptr noundef %10)
  store ptr %11, ptr %8, align 8
  br label %12

12:                                               ; preds = %27, %3
  %13 = load ptr, ptr %8, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %15, label %29

15:                                               ; preds = %12
  %16 = load ptr, ptr %8, align 8
  %17 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %16, i32 0, i32 1
  %18 = call ptr @vatomicptr_stamped_get_pointer(ptr noundef %17)
  store ptr %18, ptr %7, align 8
  %19 = load ptr, ptr %8, align 8
  %20 = load ptr, ptr %4, align 8
  %21 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %20, i32 0, i32 3
  %22 = icmp ne ptr %19, %21
  br i1 %22, label %23, label %27

23:                                               ; preds = %15
  %24 = load ptr, ptr %5, align 8
  %25 = load ptr, ptr %8, align 8
  %26 = load ptr, ptr %6, align 8
  call void %24(ptr noundef %25, ptr noundef %26)
  br label %27

27:                                               ; preds = %23, %15
  %28 = load ptr, ptr %7, align 8
  store ptr %28, ptr %8, align 8
  br label %12, !llvm.loop !13

29:                                               ; preds = %12
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !14
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %5, i32 0, i32 0
  %7 = load atomic i64, ptr %6 seq_cst, align 8
  store i64 %7, ptr %4, align 8
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %3, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !15
  %9 = load ptr, ptr %3, align 8
  ret ptr %9
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomicptr_write(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !16
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %6, i32 0, i32 0
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !17
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @verification_ignore() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal zeroext i1 @vatomicptr_stamped_cmpxchg(ptr noundef %0, ptr noundef %1, i8 noundef zeroext %2, ptr noundef %3, i8 noundef zeroext %4) #0 {
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i8, align 1
  %9 = alloca ptr, align 8
  %10 = alloca i8, align 1
  %11 = alloca ptr, align 8
  %12 = alloca ptr, align 8
  %13 = alloca ptr, align 8
  store ptr %0, ptr %6, align 8
  store ptr %1, ptr %7, align 8
  store i8 %2, ptr %8, align 1
  store ptr %3, ptr %9, align 8
  store i8 %4, ptr %10, align 1
  store ptr null, ptr %11, align 8
  store ptr null, ptr %12, align 8
  store ptr null, ptr %13, align 8
  %14 = load ptr, ptr %7, align 8
  %15 = ptrtoint ptr %14 to i64
  %16 = and i64 %15, 127
  %17 = icmp eq i64 %16, 0
  br i1 %17, label %18, label %19

18:                                               ; preds = %5
  br label %20

19:                                               ; preds = %5
  call void @__assert_fail(ptr noundef @.str.8, ptr noundef @.str.7, i32 noundef 86, ptr noundef @__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg) #7
  unreachable

20:                                               ; preds = %18
  %21 = load ptr, ptr %9, align 8
  %22 = ptrtoint ptr %21 to i64
  %23 = and i64 %22, 127
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %26

25:                                               ; preds = %20
  br label %27

26:                                               ; preds = %20
  call void @__assert_fail(ptr noundef @.str.6, ptr noundef @.str.7, i32 noundef 87, ptr noundef @__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg) #7
  unreachable

27:                                               ; preds = %25
  %28 = load ptr, ptr %7, align 8
  %29 = ptrtoint ptr %28 to i64
  %30 = load i8, ptr %8, align 1
  %31 = zext i8 %30 to i64
  %32 = and i64 %31, 127
  %33 = trunc i64 %32 to i8
  %34 = zext i8 %33 to i64
  %35 = or i64 %29, %34
  %36 = inttoptr i64 %35 to ptr
  store ptr %36, ptr %12, align 8
  %37 = load ptr, ptr %9, align 8
  %38 = ptrtoint ptr %37 to i64
  %39 = load i8, ptr %10, align 1
  %40 = zext i8 %39 to i64
  %41 = and i64 %40, 127
  %42 = trunc i64 %41 to i8
  %43 = zext i8 %42 to i64
  %44 = or i64 %38, %43
  %45 = inttoptr i64 %44 to ptr
  store ptr %45, ptr %13, align 8
  %46 = load ptr, ptr %6, align 8
  %47 = load ptr, ptr %12, align 8
  %48 = load ptr, ptr %13, align 8
  %49 = call ptr @vatomicptr_cmpxchg(ptr noundef %46, ptr noundef %47, ptr noundef %48)
  store ptr %49, ptr %11, align 8
  %50 = load ptr, ptr %11, align 8
  %51 = load ptr, ptr %12, align 8
  %52 = icmp eq ptr %50, %51
  ret i1 %52
}

; Function Attrs: noinline nounwind optnone uwtable
define internal ptr @vatomicptr_cmpxchg(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %10 = load ptr, ptr %5, align 8
  store ptr %10, ptr %7, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !18
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %6, align 8
  store ptr %13, ptr %8, align 8
  %14 = load i64, ptr %7, align 8
  %15 = load i64, ptr %8, align 8
  %16 = cmpxchg ptr %12, i64 %14, i64 %15 seq_cst seq_cst, align 8
  %17 = extractvalue { i64, i1 } %16, 0
  %18 = extractvalue { i64, i1 } %16, 1
  br i1 %18, label %20, label %19

19:                                               ; preds = %3
  store i64 %17, ptr %7, align 8
  br label %20

20:                                               ; preds = %19, %3
  %21 = zext i1 %18 to i8
  store i8 %21, ptr %9, align 1
  %22 = load i8, ptr %9, align 1
  %23 = trunc i8 %22 to i1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !19
  %24 = load ptr, ptr %7, align 8
  ret ptr %24
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @verification_assume(i1 noundef zeroext %0) #0 {
  %2 = alloca i8, align 1
  %3 = zext i1 %0 to i8
  store i8 %3, ptr %2, align 1
  br label %4

4:                                                ; preds = %1
  br label %5

5:                                                ; preds = %4
  %6 = load i8, ptr %2, align 1
  %7 = trunc i8 %6 to i1
  br label %8

8:                                                ; preds = %5
  br label %9

9:                                                ; preds = %8
  br label %10

10:                                               ; preds = %9
  br label %11

11:                                               ; preds = %10
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomicptr_stamped_set_rlx(ptr noundef %0, ptr noundef %1, i8 noundef zeroext %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i8, align 1
  %7 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store i8 %2, ptr %6, align 1
  %8 = load ptr, ptr %5, align 8
  %9 = ptrtoint ptr %8 to i64
  %10 = and i64 %9, 127
  %11 = icmp eq i64 %10, 0
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  br label %14

13:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.6, ptr noundef @.str.7, i32 noundef 319, ptr noundef @__PRETTY_FUNCTION__.vatomicptr_stamped_set_rlx) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %5, align 8
  %16 = ptrtoint ptr %15 to i64
  %17 = load i8, ptr %6, align 1
  %18 = zext i8 %17 to i64
  %19 = and i64 %18, 127
  %20 = trunc i64 %19 to i8
  %21 = zext i8 %20 to i64
  %22 = or i64 %16, %21
  %23 = inttoptr i64 %22 to ptr
  store ptr %23, ptr %7, align 8
  %24 = load ptr, ptr %4, align 8
  %25 = load ptr, ptr %7, align 8
  call void @vatomicptr_write_rlx(ptr noundef %24, ptr noundef %25)
  ret void
}

; Function Attrs: noinline nounwind optnone uwtable
define internal void @vatomicptr_write_rlx(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !20
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %6, i32 0, i32 0
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #6, !srcloc !21
  ret void
}

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #3 = { nounwind allocsize(1) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #4 = { cold noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #5 = { nounwind allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { cold noreturn nounwind }
attributes #8 = { nounwind allocsize(1) }
attributes #9 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = !{i64 2147992881}
!15 = !{i64 2147992921}
!16 = !{i64 2147994285}
!17 = !{i64 2147994325}
!18 = !{i64 2147997991}
!19 = !{i64 2147998033}
!20 = !{i64 2147994441}
!21 = !{i64 2147994481}
