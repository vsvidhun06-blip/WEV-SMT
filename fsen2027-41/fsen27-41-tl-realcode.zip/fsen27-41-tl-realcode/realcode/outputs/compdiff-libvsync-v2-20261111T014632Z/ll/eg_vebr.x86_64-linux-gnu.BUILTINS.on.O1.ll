; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = local_unnamed_addr global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = local_unnamed_addr global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"ret == 0\00", align 1
@.str.4 = private unnamed_addr constant [42 x i8] c"C:/rc1111/src/libvsync/examples/eg_vebr.c\00", align 1
@__PRETTY_FUNCTION__.main = private unnamed_addr constant [15 x i8] c"int main(void)\00", align 1
@__PRETTY_FUNCTION__.lock_acq = private unnamed_addr constant [22 x i8] c"void lock_acq(void *)\00", align 1
@__PRETTY_FUNCTION__.lock_rel = private unnamed_addr constant [22 x i8] c"void lock_rel(void *)\00", align 1
@.str.6 = private unnamed_addr constant [47 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/ebr.h\00", align 1
@.str.8 = private unnamed_addr constant [67 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/smr_nodes_list.h\00", align 1
@.str.13 = private unnamed_addr constant [41 x i8] c"lcl_epoch == 0 || lcl_epoch >= glb_epoch\00", align 1
@__PRETTY_FUNCTION__.vebr_recycle = private unnamed_addr constant [31 x i8] c"vsize_t vebr_recycle(vebr_t *)\00", align 1
@.str.14 = private unnamed_addr constant [23 x i8] c"ret_epoch >= glb_epoch\00", align 1
@.str.15 = private unnamed_addr constant [24 x i8] c"freed_node->destroy_fun\00", align 1
@__PRETTY_FUNCTION__.smr_nodes_list_destroy = private unnamed_addr constant [45 x i8] c"vsize_t smr_nodes_list_destroy(smr_node_t *)\00", align 1
@.str.19 = private unnamed_addr constant [61 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/dbl_list.h\00", align 1
@.str.21 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/include/vsync/queue/unbounded_queue_lf.h\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_deq = private unnamed_addr constant [69 x i8] c"void *vqueue_ub_deq(vqueue_ub_t *, vqueue_ub_node_handler_t, void *)\00", align 1
@.str.24 = private unnamed_addr constant [75 x i8] c"next && \22next is not expected to be NULL, since the queue is \22 \22not empty\22\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_enq = private unnamed_addr constant [62 x i8] c"void vqueue_ub_enq(vqueue_ub_t *, vqueue_ub_node_t *, void *)\00", align 1
@.str.25 = private unnamed_addr constant [6 x i8] c"qnode\00", align 1
@__PRETTY_FUNCTION__.vebr_exit = private unnamed_addr constant [42 x i8] c"void vebr_exit(vebr_t *, vebr_thread_t *)\00", align 1
@.str.27 = private unnamed_addr constant [22 x i8] c"ebr_thrd->enter_count\00", align 1
@__PRETTY_FUNCTION__.vebr_deregister = private unnamed_addr constant [48 x i8] c"void vebr_deregister(vebr_t *, vebr_thread_t *)\00", align 1
@.str.28 = private unnamed_addr constant [48 x i8] c"vatomic64_read_rlx(&ebr_thrd->epoch_local) == 0\00", align 1
@__PRETTY_FUNCTION__.dbl_list_rem = private unnamed_addr constant [51 x i8] c"void dbl_list_rem(dbl_list_t *, dbl_list_node_t *)\00", align 1
@.str.29 = private unnamed_addr constant [19 x i8] c"prev->next == node\00", align 1
@.str.30 = private unnamed_addr constant [19 x i8] c"list->head != node\00", align 1
@.str.31 = private unnamed_addr constant [19 x i8] c"list->head == node\00", align 1
@.str.32 = private unnamed_addr constant [19 x i8] c"succ->prev == node\00", align 1
@__PRETTY_FUNCTION__.vebr_init = private unnamed_addr constant [41 x i8] c"void vebr_init(vebr_t *, smr_lock_lib_t)\00", align 1
@.str.34 = private unnamed_addr constant [31 x i8] c"smr_lock_lib_is_set(&lock_lib)\00", align 1

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_lock(ptr noundef %0) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %1
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 24, ptr noundef nonnull @__PRETTY_FUNCTION__.lock_acq) #14
  unreachable

5:                                                ; preds = %1
  ret void
}

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %1
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 32, ptr noundef nonnull @__PRETTY_FUNCTION__.lock_rel) #14
  unreachable

5:                                                ; preds = %1
  ret void
}

; Function Attrs: mustprogress nounwind willreturn uwtable
define void @free_cb(ptr noundef %0, ptr nocapture readnone %1) #1 {
  %3 = ptrtoint ptr %0 to i64
  %4 = add i64 %3, -16
  %5 = inttoptr i64 %4 to ptr
  tail call void @free(ptr noundef %5) #13
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind uwtable
define void @retire_cb(ptr noundef initializes((16, 24), (32, 48)) %0, ptr nocapture noundef readnone %1) local_unnamed_addr #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %5 = urem i64 %4, 3
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr @free_cb, ptr %7, align 8, !tbaa !10
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store ptr null, ptr %8, align 8, !tbaa !18
  store ptr null, ptr %3, align 8, !tbaa !19
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %9 = load atomic i64, ptr %6 seq_cst, align 8
  %10 = inttoptr i64 %9 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %11 = ptrtoint ptr %3 to i64
  br label %12

12:                                               ; preds = %12, %2
  %13 = phi ptr [ %10, %2 ], [ %19, %12 ]
  store ptr %13, ptr %3, align 8, !tbaa !22
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !23
  %14 = ptrtoint ptr %13 to i64
  %15 = cmpxchg ptr %6, i64 %14, i64 %11 release monotonic, align 8
  %16 = extractvalue { i64, i1 } %15, 1
  %17 = extractvalue { i64, i1 } %15, 0
  %18 = inttoptr i64 %17 to ptr
  %19 = select i1 %16, ptr %13, ptr %18
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !24
  %20 = icmp eq ptr %13, %19
  br i1 %20, label %21, label %12, !llvm.loop !25

21:                                               ; preds = %12
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !28
  %23 = atomicrmw add ptr %22, i64 1 monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !29
  ret void
}

; Function Attrs: mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #5 {
  tail call void @free(ptr noundef %0) #13
  ret void
}

; Function Attrs: nounwind uwtable
define void @reclaim() local_unnamed_addr #4 {
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !30
  %1 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %2 = icmp eq i8 %1, 0
  br i1 %2, label %3, label %69

3:                                                ; preds = %0, %66
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %5 = add i64 %4, 2
  %6 = urem i64 %5, 3
  %7 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %6
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  %8 = atomicrmw xchg ptr %7, i64 0 acquire, align 8
  %9 = inttoptr i64 %8 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  %10 = getelementptr inbounds nuw i8, ptr %7, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !34
  store atomic i64 0, ptr %10 monotonic, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !35
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !36
  %12 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  tail call void %11(ptr noundef %12) #13
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !44
  %14 = icmp eq ptr %13, null
  br i1 %14, label %30, label %15

15:                                               ; preds = %3, %26
  %16 = phi ptr [ %28, %26 ], [ %13, %3 ]
  %17 = phi i64 [ %27, %26 ], [ -1, %3 ]
  %18 = getelementptr inbounds nuw i8, ptr %16, i64 16
  br label %19

19:                                               ; preds = %22, %15
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %20 = load atomic i64, ptr %18 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %26, label %22

22:                                               ; preds = %19
  %23 = icmp ult i64 %20, %4
  br i1 %23, label %19, label %24, !llvm.loop !45

24:                                               ; preds = %22
  %25 = tail call i64 @llvm.umin.i64(i64 %17, i64 %20)
  br label %26

26:                                               ; preds = %19, %24
  %27 = phi i64 [ %25, %24 ], [ %17, %19 ]
  %28 = load ptr, ptr %16, align 8, !tbaa !44
  %29 = icmp eq ptr %28, null
  br i1 %29, label %30, label %15, !llvm.loop !46

30:                                               ; preds = %26, %3
  %31 = phi i64 [ -1, %3 ], [ %27, %26 ]
  %32 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !47
  %33 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  tail call void %32(ptr noundef %33) #13
  %34 = icmp eq i64 %31, -1
  %35 = select i1 %34, i64 0, i64 %31
  %36 = icmp ne i64 %35, 0
  %37 = icmp ult i64 %35, %4
  %38 = and i1 %36, %37
  br i1 %38, label %39, label %40

39:                                               ; preds = %30
  tail call void @__assert_fail(ptr noundef nonnull @.str.13, ptr noundef nonnull @.str.6, i32 noundef 285, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_recycle) #14
  unreachable

40:                                               ; preds = %30
  %41 = add i64 %4, 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !48
  %42 = cmpxchg ptr @g_vebr, i64 %4, i64 %41 seq_cst seq_cst, align 8
  %43 = extractvalue { i64, i1 } %42, 0
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !49
  %44 = icmp ult i64 %43, %4
  br i1 %44, label %45, label %46

45:                                               ; preds = %40
  tail call void @__assert_fail(ptr noundef nonnull @.str.14, ptr noundef nonnull @.str.6, i32 noundef 298, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_recycle) #14
  unreachable

46:                                               ; preds = %40
  %47 = icmp eq i64 %8, 0
  br i1 %47, label %61, label %48

48:                                               ; preds = %46, %55
  %49 = phi ptr [ %56, %55 ], [ %9, %46 ]
  %50 = phi i64 [ %59, %55 ], [ 0, %46 ]
  %51 = getelementptr inbounds nuw i8, ptr %49, i64 16
  %52 = load ptr, ptr %51, align 8, !tbaa !10
  %53 = icmp eq ptr %52, null
  br i1 %53, label %54, label %55

54:                                               ; preds = %48
  tail call void @__assert_fail(ptr noundef nonnull @.str.15, ptr noundef nonnull @.str.8, i32 noundef 197, ptr noundef nonnull @__PRETTY_FUNCTION__.smr_nodes_list_destroy) #14
  unreachable

55:                                               ; preds = %48
  %56 = load ptr, ptr %49, align 8, !tbaa !19
  %57 = getelementptr inbounds nuw i8, ptr %49, i64 24
  %58 = load ptr, ptr %57, align 8, !tbaa !18
  tail call void %52(ptr noundef nonnull %49, ptr noundef %58) #13
  %59 = add i64 %50, 1
  %60 = icmp eq ptr %56, null
  br i1 %60, label %61, label %48, !llvm.loop !50

61:                                               ; preds = %55, %46
  %62 = phi i64 [ 0, %46 ], [ %59, %55 ]
  %63 = icmp eq i64 %62, 0
  br i1 %63, label %66, label %64

64:                                               ; preds = %61
  %65 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %62)
  br label %66

66:                                               ; preds = %64, %61
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !30
  %67 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %68 = icmp eq i8 %67, 0
  br i1 %68, label %3, label %69, !llvm.loop !51

69:                                               ; preds = %66, %0
  ret void
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #4 {
  %2 = alloca %struct.vebr_instance_s, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #13
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq ptr %0, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  tail call void @reclaim()
  br label %153

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !52
  store atomic i64 0, ptr %7 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !53
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store i32 0, ptr %8, align 8, !tbaa !54
  %9 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !36
  %10 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  tail call void %9(ptr noundef %10) #13
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  store ptr %11, ptr %2, align 8, !tbaa !58
  %12 = icmp eq ptr %11, null
  br i1 %12, label %15, label %13

13:                                               ; preds = %6
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store ptr %2, ptr %14, align 8, !tbaa !59
  br label %15

15:                                               ; preds = %6, %13
  store ptr %2, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store ptr null, ptr %16, align 8, !tbaa !59
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %18 = add i64 %17, 1
  store i64 %18, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %19 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !47
  %20 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  call void %19(ptr noundef %20) #13
  br label %58

21:                                               ; preds = %148
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  %22 = load atomic i64, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !62
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %25, label %24

24:                                               ; preds = %21
  call void @__assert_fail(ptr noundef nonnull @.str.28, ptr noundef nonnull @.str.6, i32 noundef 165, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_deregister) #14
  unreachable

25:                                               ; preds = %21
  %26 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !36
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  call void %26(ptr noundef %27) #13
  %28 = load ptr, ptr %2, align 8, !tbaa !58
  %29 = load ptr, ptr %16, align 8, !tbaa !59
  %30 = icmp eq ptr %29, null
  br i1 %30, label %40, label %31

31:                                               ; preds = %25
  %32 = load ptr, ptr %29, align 8, !tbaa !58
  %33 = icmp eq ptr %32, %2
  br i1 %33, label %35, label %34

34:                                               ; preds = %31
  call void @__assert_fail(ptr noundef nonnull @.str.29, ptr noundef nonnull @.str.19, i32 noundef 62, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

35:                                               ; preds = %31
  %36 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  %37 = icmp eq ptr %36, %2
  br i1 %37, label %38, label %39

38:                                               ; preds = %35
  call void @__assert_fail(ptr noundef nonnull @.str.30, ptr noundef nonnull @.str.19, i32 noundef 63, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

39:                                               ; preds = %35
  store ptr %28, ptr %29, align 8, !tbaa !58
  br label %45

40:                                               ; preds = %25
  %41 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  %42 = icmp eq ptr %41, %2
  br i1 %42, label %44, label %43

43:                                               ; preds = %40
  call void @__assert_fail(ptr noundef nonnull @.str.31, ptr noundef nonnull @.str.19, i32 noundef 66, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

44:                                               ; preds = %40
  store ptr %28, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  br label %45

45:                                               ; preds = %44, %39
  %46 = icmp eq ptr %28, null
  br i1 %46, label %53, label %47

47:                                               ; preds = %45
  %48 = getelementptr inbounds nuw i8, ptr %28, i64 8
  %49 = load ptr, ptr %48, align 8, !tbaa !59
  %50 = icmp eq ptr %49, %2
  br i1 %50, label %52, label %51

51:                                               ; preds = %47
  call void @__assert_fail(ptr noundef nonnull @.str.32, ptr noundef nonnull @.str.19, i32 noundef 71, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

52:                                               ; preds = %47
  store ptr %29, ptr %48, align 8, !tbaa !59
  br label %53

53:                                               ; preds = %45, %52
  %54 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %55 = add i64 %54, -1
  store i64 %55, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %56 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !47
  %57 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  call void %56(ptr noundef %57) #13
  br label %153

58:                                               ; preds = %15, %148
  %59 = phi i64 [ 0, %15 ], [ %151, %148 ]
  %60 = load i32, ptr %8, align 8, !tbaa !54
  %61 = add i32 %60, 1
  store i32 %61, ptr %8, align 8, !tbaa !54
  %62 = icmp eq i32 %60, 0
  br i1 %62, label %63, label %65

63:                                               ; preds = %58
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %64 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !63
  store atomic i64 %64, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  br label %65

65:                                               ; preds = %58, %63
  br label %66

66:                                               ; preds = %87, %65
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %67 = load atomic i64, ptr @g_queue seq_cst, align 8
  %68 = inttoptr i64 %67 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %69 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %70 = getelementptr inbounds nuw i8, ptr %68, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %71 = load atomic i64, ptr %70 seq_cst, align 8
  %72 = inttoptr i64 %71 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %73 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %74 = icmp eq i64 %67, %73
  br i1 %74, label %75, label %87

75:                                               ; preds = %66
  %76 = icmp eq i64 %67, %69
  %77 = icmp eq i64 %71, 0
  br i1 %76, label %78, label %81

78:                                               ; preds = %75
  br i1 %77, label %112, label %79

79:                                               ; preds = %78
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !65
  %80 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %69, i64 %71 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !66
  br label %87

81:                                               ; preds = %75
  br i1 %77, label %82, label %83

82:                                               ; preds = %81
  call void @__assert_fail(ptr noundef nonnull @.str.24, ptr noundef nonnull @.str.21, i32 noundef 208, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_deq) #14
  unreachable

83:                                               ; preds = %81
  %84 = load ptr, ptr %72, align 8, !tbaa !67
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !65
  %85 = cmpxchg ptr @g_queue, i64 %67, i64 %71 seq_cst seq_cst, align 8
  %86 = extractvalue { i64, i1 } %85, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !66
  br i1 %86, label %88, label %87

87:                                               ; preds = %83, %79, %66
  br label %66, !llvm.loop !70

88:                                               ; preds = %83
  %89 = icmp eq i64 %67, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %89, label %112, label %90

90:                                               ; preds = %88
  %91 = getelementptr inbounds nuw i8, ptr %68, i64 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %92 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %93 = urem i64 %92, 3
  %94 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %93
  %95 = getelementptr inbounds nuw i8, ptr %68, i64 32
  store ptr @free_cb, ptr %95, align 8, !tbaa !10
  %96 = getelementptr inbounds nuw i8, ptr %68, i64 40
  store ptr null, ptr %96, align 8, !tbaa !18
  store ptr null, ptr %91, align 8, !tbaa !19
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %97 = load atomic i64, ptr %94 seq_cst, align 8
  %98 = inttoptr i64 %97 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %99 = ptrtoint ptr %91 to i64
  br label %100

100:                                              ; preds = %100, %90
  %101 = phi ptr [ %98, %90 ], [ %107, %100 ]
  store ptr %101, ptr %91, align 8, !tbaa !22
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !23
  %102 = ptrtoint ptr %101 to i64
  %103 = cmpxchg ptr %94, i64 %102, i64 %99 release monotonic, align 8
  %104 = extractvalue { i64, i1 } %103, 1
  %105 = extractvalue { i64, i1 } %103, 0
  %106 = inttoptr i64 %105 to ptr
  %107 = select i1 %104, ptr %101, ptr %106
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !24
  %108 = icmp eq ptr %101, %107
  br i1 %108, label %109, label %100, !llvm.loop !25

109:                                              ; preds = %100
  %110 = getelementptr inbounds nuw i8, ptr %94, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !28
  %111 = atomicrmw add ptr %110, i64 1 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !29
  br label %112

112:                                              ; preds = %78, %88, %109
  %113 = phi ptr [ %84, %109 ], [ %84, %88 ], [ null, %78 ]
  %114 = icmp eq ptr %113, null
  br i1 %114, label %115, label %141

115:                                              ; preds = %112
  %116 = call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #15
  store i64 %59, ptr %116, align 8, !tbaa !71
  %117 = call noalias dereferenceable_or_null(48) ptr @malloc(i64 noundef 48) #15
  %118 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef %3, i64 noundef %59)
  %119 = icmp eq ptr %117, null
  br i1 %119, label %120, label %121

120:                                              ; preds = %115
  call void @__assert_fail(ptr noundef nonnull @.str.25, ptr noundef nonnull @.str.21, i32 noundef 113, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_enq) #14
  unreachable

121:                                              ; preds = %115
  store ptr %116, ptr %117, align 8, !tbaa !67
  %122 = getelementptr inbounds nuw i8, ptr %117, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !73
  store atomic i64 0, ptr %122 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !74
  %123 = ptrtoint ptr %117 to i64
  br label %124

124:                                              ; preds = %138, %121
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %125 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  %126 = inttoptr i64 %125 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %127 = getelementptr inbounds nuw i8, ptr %126, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %128 = load atomic i64, ptr %127 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %129 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %130 = icmp eq i64 %125, %129
  br i1 %130, label %131, label %138

131:                                              ; preds = %124
  %132 = icmp eq i64 %128, 0
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13
  br i1 %132, label %133, label %136

133:                                              ; preds = %131
  %134 = cmpxchg ptr %127, i64 0, i64 %123 seq_cst seq_cst, align 8
  %135 = extractvalue { i64, i1 } %134, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !66
  br i1 %135, label %139, label %138

136:                                              ; preds = %131
  %137 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %125, i64 %128 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !66
  br label %138

138:                                              ; preds = %136, %133, %124
  br label %124, !llvm.loop !75

139:                                              ; preds = %133
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !65
  %140 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %125, i64 %123 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !66
  br label %144

141:                                              ; preds = %112
  %142 = load i64, ptr %113, align 8, !tbaa !71
  %143 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %3, i64 noundef %142)
  call void @free(ptr noundef %113) #13
  br label %144

144:                                              ; preds = %141, %139
  %145 = load i32, ptr %8, align 8, !tbaa !54
  switch i32 %145, label %148 [
    i32 0, label %146
    i32 1, label %147
  ]

146:                                              ; preds = %144
  call void @__assert_fail(ptr noundef nonnull @.str.27, ptr noundef nonnull @.str.6, i32 noundef 210, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_exit) #14
  unreachable

147:                                              ; preds = %144
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !63
  store atomic i64 0, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br label %148

148:                                              ; preds = %144, %147
  %149 = load i32, ptr %8, align 8, !tbaa !54
  %150 = add i32 %149, -1
  store i32 %150, ptr %8, align 8, !tbaa !54
  %151 = add nuw nsw i64 %59, 1
  %152 = icmp eq i64 %151, 10000
  br i1 %152, label %21, label %58, !llvm.loop !76

153:                                              ; preds = %53, %5
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #13
  ret ptr null
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #4 {
  %1 = alloca [12 x i64], align 16
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #13
  %2 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @g_lock, ptr noundef null) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %0
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 113, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #14
  unreachable

5:                                                ; preds = %0
  %6 = load ptr, ptr @g_lock_lib, align 8
  %7 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_lock_lib, i64 8), align 8
  %8 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_lock_lib, i64 16), align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), i8 0, i64 16, i1 false)
  br label %13

9:                                                ; preds = %13
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !52
  store atomic i64 1, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !53
  %10 = icmp ne ptr %6, null
  %11 = icmp ne ptr %7, null
  %12 = select i1 %10, i1 %11, i1 false
  br i1 %12, label %20, label %19

13:                                               ; preds = %13, %5
  %14 = phi i64 [ 0, %5 ], [ %17, %13 ]
  %15 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %14
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !77
  store atomic i64 0, ptr %15 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !78
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !52
  store atomic i64 0, ptr %16 seq_cst, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !53
  %17 = add nuw nsw i64 %14, 1
  %18 = icmp eq i64 %17, 3
  br i1 %18, label %9, label %13, !llvm.loop !79

19:                                               ; preds = %9
  tail call void @__assert_fail(ptr noundef nonnull @.str.34, ptr noundef nonnull @.str.6, i32 noundef 102, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_init) #14
  unreachable

20:                                               ; preds = %9
  store ptr %6, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !80
  store ptr %7, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !80
  store ptr %8, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !80
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), align 8, !tbaa !81
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !73
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 24) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !74
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !73
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr @g_queue monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !74
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !73
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !74
  br label %21

21:                                               ; preds = %20, %21
  %22 = phi i64 [ 0, %20 ], [ %26, %21 ]
  %23 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %22
  %24 = inttoptr i64 %22 to ptr
  %25 = call i32 @pthread_create(ptr noundef nonnull %23, ptr noundef null, ptr noundef nonnull @run, ptr noundef %24) #13
  %26 = add nuw nsw i64 %22, 1
  %27 = icmp eq i64 %26, 12
  br i1 %27, label %31, label %21, !llvm.loop !83

28:                                               ; preds = %31
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !84
  store atomic i8 1, ptr @g_stop seq_cst, align 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !85
  %29 = load i64, ptr %1, align 16, !tbaa !86
  %30 = call i32 @pthread_join(i64 noundef %29, ptr noundef null) #13
  br label %38

31:                                               ; preds = %21, %31
  %32 = phi i64 [ %36, %31 ], [ 1, %21 ]
  %33 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %32
  %34 = load i64, ptr %33, align 8, !tbaa !86
  %35 = call i32 @pthread_join(i64 noundef %34, ptr noundef null) #13
  %36 = add nuw nsw i64 %32, 1
  %37 = icmp eq i64 %36, 12
  br i1 %37, label %28, label %31, !llvm.loop !87

38:                                               ; preds = %66, %28
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %39 = load atomic i64, ptr @g_queue seq_cst, align 8
  %40 = inttoptr i64 %39 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %41 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %42 = getelementptr inbounds nuw i8, ptr %40, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %43 = load atomic i64, ptr %42 seq_cst, align 8
  %44 = inttoptr i64 %43 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %45 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %46 = icmp eq i64 %39, %45
  br i1 %46, label %47, label %66

47:                                               ; preds = %38
  %48 = icmp eq i64 %39, %41
  %49 = icmp eq i64 %43, 0
  br i1 %48, label %50, label %53

50:                                               ; preds = %47
  br i1 %49, label %62, label %51

51:                                               ; preds = %50
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !65
  %52 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %41, i64 %43 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !66
  br label %66

53:                                               ; preds = %47
  br i1 %49, label %54, label %55

54:                                               ; preds = %53
  call void @__assert_fail(ptr noundef nonnull @.str.24, ptr noundef nonnull @.str.21, i32 noundef 208, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_deq) #14
  unreachable

55:                                               ; preds = %53
  %56 = load ptr, ptr %44, align 8, !tbaa !67
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !65
  %57 = cmpxchg ptr @g_queue, i64 %39, i64 %43 seq_cst seq_cst, align 8
  %58 = extractvalue { i64, i1 } %57, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !66
  br i1 %58, label %59, label %66

59:                                               ; preds = %55
  %60 = icmp eq i64 %39, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %60, label %62, label %61

61:                                               ; preds = %59
  call void @free(ptr noundef %40) #13
  br label %62

62:                                               ; preds = %50, %59, %61
  %63 = phi ptr [ %56, %61 ], [ %56, %59 ], [ null, %50 ]
  %64 = icmp eq ptr %63, null
  br i1 %64, label %67, label %65

65:                                               ; preds = %62
  call void @free(ptr noundef %63) #13
  br label %66

66:                                               ; preds = %65, %55, %51, %38
  br label %38, !llvm.loop !70

67:                                               ; preds = %62
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %68 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %69 = icmp eq i64 %68, 0
  br i1 %69, label %79, label %70

70:                                               ; preds = %67, %77
  %71 = phi i64 [ %74, %77 ], [ %68, %67 ]
  %72 = inttoptr i64 %71 to ptr
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %74 = load atomic i64, ptr %73 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %75 = icmp eq i64 %71, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %75, label %77, label %76

76:                                               ; preds = %70
  call void @free(ptr noundef nonnull %72) #13
  br label %77

77:                                               ; preds = %76, %70
  %78 = icmp eq i64 %74, 0
  br i1 %78, label %79, label %70, !llvm.loop !88

79:                                               ; preds = %77, %67
  br label %80

80:                                               ; preds = %79, %99
  %81 = phi i64 [ %100, %99 ], [ 0, %79 ]
  %82 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %81
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  %83 = atomicrmw xchg ptr %82, i64 0 acquire, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  %84 = getelementptr inbounds nuw i8, ptr %82, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !34
  store atomic i64 0, ptr %84 monotonic, align 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !35
  %85 = icmp eq i64 %83, 0
  br i1 %85, label %99, label %86

86:                                               ; preds = %80
  %87 = inttoptr i64 %83 to ptr
  br label %88

88:                                               ; preds = %94, %86
  %89 = phi ptr [ %95, %94 ], [ %87, %86 ]
  %90 = getelementptr inbounds nuw i8, ptr %89, i64 16
  %91 = load ptr, ptr %90, align 8, !tbaa !10
  %92 = icmp eq ptr %91, null
  br i1 %92, label %93, label %94

93:                                               ; preds = %88
  call void @__assert_fail(ptr noundef nonnull @.str.15, ptr noundef nonnull @.str.8, i32 noundef 197, ptr noundef nonnull @__PRETTY_FUNCTION__.smr_nodes_list_destroy) #14
  unreachable

94:                                               ; preds = %88
  %95 = load ptr, ptr %89, align 8, !tbaa !19
  %96 = getelementptr inbounds nuw i8, ptr %89, i64 24
  %97 = load ptr, ptr %96, align 8, !tbaa !18
  call void %91(ptr noundef nonnull %89, ptr noundef %97) #13
  %98 = icmp eq ptr %95, null
  br i1 %98, label %99, label %88, !llvm.loop !50

99:                                               ; preds = %94, %80
  %100 = add nuw nsw i64 %81, 1
  %101 = icmp eq i64 %100, 3
  br i1 %101, label %102, label %80, !llvm.loop !89

102:                                              ; preds = %99
  %103 = call i32 @pthread_mutex_destroy(ptr noundef nonnull @g_lock) #13
  %104 = icmp eq i32 %103, 0
  br i1 %104, label %106, label %105

105:                                              ; preds = %102
  call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 139, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #14
  unreachable

106:                                              ; preds = %102
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #13
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: cold noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind
declare i32 @pthread_mutex_destroy(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #12

attributes #0 = { inlinehint nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #1 = { mustprogress nounwind willreturn uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #4 = { nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #6 = { nofree nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #8 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #9 = { cold noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #10 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #11 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #13 = { nounwind }
attributes #14 = { cold noreturn nounwind }
attributes #15 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{i64 2147989819}
!7 = !{i64 2147989859}
!8 = !{i64 2147990757}
!9 = !{i64 2147990797}
!10 = !{!11, !14, i64 16}
!11 = !{!"smr_node_s", !12, i64 0, !17, i64 8, !14, i64 16, !14, i64 24}
!12 = !{!"smr_node_core_s", !13, i64 0}
!13 = !{!"p1 _ZTS15smr_node_core_s", !14, i64 0}
!14 = !{!"any pointer", !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C/C++ TBAA"}
!17 = !{!"int", !15, i64 0}
!18 = !{!11, !14, i64 24}
!19 = !{!11, !13, i64 0}
!20 = !{i64 2147991225}
!21 = !{i64 2147991265}
!22 = !{!12, !13, i64 0}
!23 = !{i64 2147996495}
!24 = !{i64 2147996537}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.mustprogress"}
!27 = !{!"llvm.loop.unroll.disable"}
!28 = !{i64 2148002505}
!29 = !{i64 2148002545}
!30 = !{i64 2147990055}
!31 = !{i64 2147990095}
!32 = !{i64 2147994501}
!33 = !{i64 2147994541}
!34 = !{i64 2147992317}
!35 = !{i64 2147992357}
!36 = !{!37, !14, i64 72}
!37 = !{!"vebr_s", !38, i64 0, !15, i64 8, !40, i64 56, !42, i64 72}
!38 = !{!"vatomic64_s", !39, i64 0}
!39 = !{!"long", !15, i64 0}
!40 = !{!"dbl_list_s", !41, i64 0, !39, i64 8}
!41 = !{!"p1 _ZTS15dbl_list_node_s", !14, i64 0}
!42 = !{!"smr_lock_lib_s", !14, i64 0, !14, i64 8, !14, i64 16}
!43 = !{!37, !14, i64 88}
!44 = !{!41, !41, i64 0}
!45 = distinct !{!45, !27}
!46 = distinct !{!46, !26, !27}
!47 = !{!37, !14, i64 80}
!48 = !{i64 2147995695}
!49 = !{i64 2147995737}
!50 = distinct !{!50, !26, !27}
!51 = distinct !{!51, !26, !27}
!52 = !{i64 2147992161}
!53 = !{i64 2147992201}
!54 = !{!55, !17, i64 24}
!55 = !{!"vebr_instance_s", !56, i64 0, !38, i64 16, !17, i64 24}
!56 = !{!"dbl_list_node_s", !41, i64 0, !41, i64 8}
!57 = !{!40, !41, i64 0}
!58 = !{!56, !41, i64 0}
!59 = !{!56, !41, i64 8}
!60 = !{!40, !39, i64 8}
!61 = !{i64 2147990913}
!62 = !{i64 2147990953}
!63 = !{i64 2147992239}
!64 = !{i64 2147992279}
!65 = !{i64 2147996335}
!66 = !{i64 2147996377}
!67 = !{!68, !14, i64 0}
!68 = !{!"vqueue_ub_node_s", !14, i64 0, !69, i64 8, !11, i64 16}
!69 = !{!"vatomicptr_s", !14, i64 0}
!70 = distinct !{!70, !27}
!71 = !{!72, !39, i64 0}
!72 = !{!"data_s", !39, i64 0}
!73 = !{i64 2147992785}
!74 = !{i64 2147992825}
!75 = distinct !{!75, !27}
!76 = distinct !{!76, !26, !27}
!77 = !{i64 2147992629}
!78 = !{i64 2147992669}
!79 = distinct !{!79, !26, !27}
!80 = !{!14, !14, i64 0}
!81 = !{!82, !14, i64 16}
!82 = !{!"vqueue_ub_s", !69, i64 0, !69, i64 8, !68, i64 16}
!83 = distinct !{!83, !26, !27}
!84 = !{i64 2147991459}
!85 = !{i64 2147991499}
!86 = !{!39, !39, i64 0}
!87 = distinct !{!87, !26, !27}
!88 = distinct !{!88, !26, !27}
!89 = distinct !{!89, !26, !27}
