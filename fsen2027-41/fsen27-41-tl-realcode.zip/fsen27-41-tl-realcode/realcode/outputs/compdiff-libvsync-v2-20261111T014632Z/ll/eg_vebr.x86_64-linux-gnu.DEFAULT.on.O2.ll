; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = local_unnamed_addr global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = local_unnamed_addr global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"ret == 0\00", align 1
@.str.4 = private unnamed_addr constant [42 x i8] c"C:/rc1111/src/libvsync/examples/eg_vebr.c\00", align 1
@__PRETTY_FUNCTION__.main = private unnamed_addr constant [15 x i8] c"int main(void)\00", align 1
@__PRETTY_FUNCTION__.lock_acq = private unnamed_addr constant [22 x i8] c"void lock_acq(void *)\00", align 1
@__PRETTY_FUNCTION__.lock_rel = private unnamed_addr constant [22 x i8] c"void lock_rel(void *)\00", align 1
@.str.6 = private unnamed_addr constant [47 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/ebr.h\00", align 1
@.str.8 = private unnamed_addr constant [67 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/smr_nodes_list.h\00", align 1
@.str.13 = private unnamed_addr constant [41 x i8] c"lcl_epoch == 0 || lcl_epoch >= glb_epoch\00", align 1
@__PRETTY_FUNCTION__.vebr_recycle = private unnamed_addr constant [31 x i8] c"vsize_t vebr_recycle(vebr_t *)\00", align 1
@.str.14 = private unnamed_addr constant [23 x i8] c"ret_epoch >= glb_epoch\00", align 1
@.str.15 = private unnamed_addr constant [24 x i8] c"freed_node->destroy_fun\00", align 1
@__PRETTY_FUNCTION__.smr_nodes_list_destroy = private unnamed_addr constant [45 x i8] c"vsize_t smr_nodes_list_destroy(smr_node_t *)\00", align 1
@.str.19 = private unnamed_addr constant [61 x i8] c"C:/rc1111/src/libvsync/include/vsync/smr/internal/dbl_list.h\00", align 1
@.str.21 = private unnamed_addr constant [64 x i8] c"C:/rc1111/src/libvsync/include/vsync/queue/unbounded_queue_lf.h\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_deq = private unnamed_addr constant [69 x i8] c"void *vqueue_ub_deq(vqueue_ub_t *, vqueue_ub_node_handler_t, void *)\00", align 1
@.str.24 = private unnamed_addr constant [75 x i8] c"next && \22next is not expected to be NULL, since the queue is \22 \22not empty\22\00", align 1
@__PRETTY_FUNCTION__.vqueue_ub_enq = private unnamed_addr constant [62 x i8] c"void vqueue_ub_enq(vqueue_ub_t *, vqueue_ub_node_t *, void *)\00", align 1
@.str.25 = private unnamed_addr constant [6 x i8] c"qnode\00", align 1
@__PRETTY_FUNCTION__.vebr_exit = private unnamed_addr constant [42 x i8] c"void vebr_exit(vebr_t *, vebr_thread_t *)\00", align 1
@.str.27 = private unnamed_addr constant [22 x i8] c"ebr_thrd->enter_count\00", align 1
@__PRETTY_FUNCTION__.vebr_deregister = private unnamed_addr constant [48 x i8] c"void vebr_deregister(vebr_t *, vebr_thread_t *)\00", align 1
@.str.28 = private unnamed_addr constant [48 x i8] c"vatomic64_read_rlx(&ebr_thrd->epoch_local) == 0\00", align 1
@__PRETTY_FUNCTION__.dbl_list_rem = private unnamed_addr constant [51 x i8] c"void dbl_list_rem(dbl_list_t *, dbl_list_node_t *)\00", align 1
@.str.29 = private unnamed_addr constant [19 x i8] c"prev->next == node\00", align 1
@.str.30 = private unnamed_addr constant [19 x i8] c"list->head != node\00", align 1
@.str.31 = private unnamed_addr constant [19 x i8] c"list->head == node\00", align 1
@.str.32 = private unnamed_addr constant [19 x i8] c"succ->prev == node\00", align 1
@__PRETTY_FUNCTION__.vebr_init = private unnamed_addr constant [41 x i8] c"void vebr_init(vebr_t *, smr_lock_lib_t)\00", align 1
@.str.34 = private unnamed_addr constant [31 x i8] c"smr_lock_lib_is_set(&lock_lib)\00", align 1

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_lock(ptr noundef %0) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %1
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 24, ptr noundef nonnull @__PRETTY_FUNCTION__.lock_acq) #14
  unreachable

5:                                                ; preds = %1
  ret void
}

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %1
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 32, ptr noundef nonnull @__PRETTY_FUNCTION__.lock_rel) #14
  unreachable

5:                                                ; preds = %1
  ret void
}

; Function Attrs: mustprogress nounwind willreturn uwtable
define void @free_cb(ptr noundef %0, ptr nocapture readnone %1) #1 {
  %3 = ptrtoint ptr %0 to i64
  %4 = add i64 %3, -16
  %5 = inttoptr i64 %4 to ptr
  tail call void @free(ptr noundef %5) #13
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind uwtable
define void @retire_cb(ptr noundef initializes((16, 24), (32, 48)) %0, ptr nocapture noundef readnone %1) local_unnamed_addr #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %5 = urem i64 %4, 3
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr @free_cb, ptr %7, align 8, !tbaa !10
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store ptr null, ptr %8, align 8, !tbaa !18
  store ptr null, ptr %3, align 8, !tbaa !19
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %9 = load atomic i64, ptr %6 seq_cst, align 8
  %10 = inttoptr i64 %9 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %11 = ptrtoint ptr %3 to i64
  br label %12

12:                                               ; preds = %12, %2
  %13 = phi ptr [ %10, %2 ], [ %19, %12 ]
  store ptr %13, ptr %3, align 8, !tbaa !22
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !23
  %14 = ptrtoint ptr %13 to i64
  %15 = cmpxchg ptr %6, i64 %14, i64 %11 release monotonic, align 8
  %16 = extractvalue { i64, i1 } %15, 1
  %17 = extractvalue { i64, i1 } %15, 0
  %18 = inttoptr i64 %17 to ptr
  %19 = select i1 %16, ptr %13, ptr %18
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !24
  %20 = icmp eq ptr %13, %19
  br i1 %20, label %21, label %12, !llvm.loop !25

21:                                               ; preds = %12
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !27
  %23 = atomicrmw add ptr %22, i64 1 monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !28
  ret void
}

; Function Attrs: mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #5 {
  tail call void @free(ptr noundef %0) #13
  ret void
}

; Function Attrs: nounwind uwtable
define void @reclaim() local_unnamed_addr #4 {
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !29
  %1 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !30
  %2 = icmp eq i8 %1, 0
  br i1 %2, label %3, label %69

3:                                                ; preds = %0, %66
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %5 = add i64 %4, 2
  %6 = urem i64 %5, 3
  %7 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %6
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %8 = atomicrmw xchg ptr %7, i64 0 acquire, align 8
  %9 = inttoptr i64 %8 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  %10 = getelementptr inbounds nuw i8, ptr %7, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  store atomic i64 0, ptr %10 monotonic, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !34
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !35
  %12 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  tail call void %11(ptr noundef %12) #13
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !43
  %14 = icmp eq ptr %13, null
  br i1 %14, label %31, label %15

15:                                               ; preds = %3, %27
  %16 = phi ptr [ %29, %27 ], [ %13, %3 ]
  %17 = phi i64 [ %28, %27 ], [ -1, %3 ]
  %18 = getelementptr inbounds nuw i8, ptr %16, i64 16
  br label %19

19:                                               ; preds = %22, %15
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %20 = load atomic i64, ptr %18 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %21 = icmp eq i64 %20, 0
  br i1 %21, label %27, label %22

22:                                               ; preds = %19
  %23 = icmp ult i64 %20, %4
  br i1 %23, label %19, label %24

24:                                               ; preds = %22
  %25 = tail call i64 @llvm.umin.i64(i64 %17, i64 %20)
  %26 = freeze i64 %25
  br label %27

27:                                               ; preds = %19, %24
  %28 = phi i64 [ %26, %24 ], [ %17, %19 ]
  %29 = load ptr, ptr %16, align 8, !tbaa !43
  %30 = icmp eq ptr %29, null
  br i1 %30, label %31, label %15, !llvm.loop !44

31:                                               ; preds = %27, %3
  %32 = phi i64 [ -1, %3 ], [ %28, %27 ]
  %33 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !45
  %34 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  tail call void %33(ptr noundef %34) #13
  %35 = icmp eq i64 %32, -1
  br i1 %35, label %41, label %36

36:                                               ; preds = %31
  %37 = icmp ne i64 %32, 0
  %38 = icmp ult i64 %32, %4
  %39 = and i1 %37, %38
  br i1 %39, label %40, label %41

40:                                               ; preds = %36
  tail call void @__assert_fail(ptr noundef nonnull @.str.13, ptr noundef nonnull @.str.6, i32 noundef 285, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_recycle) #14
  unreachable

41:                                               ; preds = %36, %31
  %42 = add i64 %4, 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !46
  %43 = cmpxchg ptr @g_vebr, i64 %4, i64 %42 seq_cst seq_cst, align 8
  %44 = extractvalue { i64, i1 } %43, 0
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !47
  %45 = icmp ult i64 %44, %4
  br i1 %45, label %46, label %47

46:                                               ; preds = %41
  tail call void @__assert_fail(ptr noundef nonnull @.str.14, ptr noundef nonnull @.str.6, i32 noundef 298, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_recycle) #14
  unreachable

47:                                               ; preds = %41
  %48 = icmp eq i64 %8, 0
  br i1 %48, label %66, label %49

49:                                               ; preds = %47, %56
  %50 = phi ptr [ %57, %56 ], [ %9, %47 ]
  %51 = phi i64 [ %60, %56 ], [ 0, %47 ]
  %52 = getelementptr inbounds nuw i8, ptr %50, i64 16
  %53 = load ptr, ptr %52, align 8, !tbaa !10
  %54 = icmp eq ptr %53, null
  br i1 %54, label %55, label %56

55:                                               ; preds = %49
  tail call void @__assert_fail(ptr noundef nonnull @.str.15, ptr noundef nonnull @.str.8, i32 noundef 197, ptr noundef nonnull @__PRETTY_FUNCTION__.smr_nodes_list_destroy) #14
  unreachable

56:                                               ; preds = %49
  %57 = load ptr, ptr %50, align 8, !tbaa !19
  %58 = getelementptr inbounds nuw i8, ptr %50, i64 24
  %59 = load ptr, ptr %58, align 8, !tbaa !18
  tail call void %53(ptr noundef nonnull %50, ptr noundef %59) #13
  %60 = add i64 %51, 1
  %61 = icmp eq ptr %57, null
  br i1 %61, label %62, label %49, !llvm.loop !48

62:                                               ; preds = %56
  %63 = icmp eq i64 %60, 0
  br i1 %63, label %66, label %64

64:                                               ; preds = %62
  %65 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %60)
  br label %66

66:                                               ; preds = %47, %64, %62
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !29
  %67 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !30
  %68 = icmp eq i8 %67, 0
  br i1 %68, label %3, label %69, !llvm.loop !49

69:                                               ; preds = %66, %0
  ret void
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #4 {
  %2 = alloca %struct.vebr_instance_s, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #13
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq ptr %0, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  tail call void @reclaim()
  br label %153

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  store atomic i64 0, ptr %7 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !51
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store i32 0, ptr %8, align 8, !tbaa !52
  %9 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !35
  %10 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  tail call void %9(ptr noundef %10) #13
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  store ptr %11, ptr %2, align 8, !tbaa !56
  %12 = icmp eq ptr %11, null
  br i1 %12, label %15, label %13

13:                                               ; preds = %6
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store ptr %2, ptr %14, align 8, !tbaa !57
  br label %15

15:                                               ; preds = %6, %13
  store ptr %2, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store ptr null, ptr %16, align 8, !tbaa !57
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %18 = add i64 %17, 1
  store i64 %18, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %19 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !45
  %20 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  call void %19(ptr noundef %20) #13
  %21 = load i32, ptr %8, align 8, !tbaa !52
  br label %58

22:                                               ; preds = %148
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !59
  %23 = load atomic i64, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !60
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %26, label %25

25:                                               ; preds = %22
  call void @__assert_fail(ptr noundef nonnull @.str.28, ptr noundef nonnull @.str.6, i32 noundef 165, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_deregister) #14
  unreachable

26:                                               ; preds = %22
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !35
  %28 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  call void %27(ptr noundef %28) #13
  %29 = load ptr, ptr %2, align 8, !tbaa !56
  %30 = load ptr, ptr %16, align 8, !tbaa !57
  %31 = icmp eq ptr %30, null
  br i1 %31, label %40, label %32

32:                                               ; preds = %26
  %33 = load ptr, ptr %30, align 8, !tbaa !56
  %34 = icmp eq ptr %33, %2
  br i1 %34, label %36, label %35

35:                                               ; preds = %32
  call void @__assert_fail(ptr noundef nonnull @.str.29, ptr noundef nonnull @.str.19, i32 noundef 62, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

36:                                               ; preds = %32
  %37 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  %38 = icmp eq ptr %37, %2
  br i1 %38, label %39, label %44

39:                                               ; preds = %36
  call void @__assert_fail(ptr noundef nonnull @.str.30, ptr noundef nonnull @.str.19, i32 noundef 63, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

40:                                               ; preds = %26
  %41 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !55
  %42 = icmp eq ptr %41, %2
  br i1 %42, label %44, label %43

43:                                               ; preds = %40
  call void @__assert_fail(ptr noundef nonnull @.str.31, ptr noundef nonnull @.str.19, i32 noundef 66, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

44:                                               ; preds = %40, %36
  %45 = phi ptr [ %30, %36 ], [ getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), %40 ]
  store ptr %29, ptr %45, align 8, !tbaa !43
  %46 = icmp eq ptr %29, null
  br i1 %46, label %53, label %47

47:                                               ; preds = %44
  %48 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %49 = load ptr, ptr %48, align 8, !tbaa !57
  %50 = icmp eq ptr %49, %2
  br i1 %50, label %52, label %51

51:                                               ; preds = %47
  call void @__assert_fail(ptr noundef nonnull @.str.32, ptr noundef nonnull @.str.19, i32 noundef 71, ptr noundef nonnull @__PRETTY_FUNCTION__.dbl_list_rem) #14
  unreachable

52:                                               ; preds = %47
  store ptr %30, ptr %48, align 8, !tbaa !57
  br label %53

53:                                               ; preds = %44, %52
  %54 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %55 = add i64 %54, -1
  store i64 %55, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !58
  %56 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !45
  %57 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !42
  call void %56(ptr noundef %57) #13
  br label %153

58:                                               ; preds = %15, %148
  %59 = phi i32 [ %21, %15 ], [ %150, %148 ]
  %60 = phi i64 [ 0, %15 ], [ %151, %148 ]
  %61 = add i32 %59, 1
  store i32 %61, ptr %8, align 8, !tbaa !52
  %62 = icmp eq i32 %59, 0
  br i1 %62, label %63, label %65

63:                                               ; preds = %58
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %64 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  store atomic i64 %64, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !62
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  br label %65

65:                                               ; preds = %58, %63
  br label %66

66:                                               ; preds = %87, %65
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %67 = load atomic i64, ptr @g_queue seq_cst, align 8
  %68 = inttoptr i64 %67 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %69 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %70 = getelementptr inbounds nuw i8, ptr %68, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %71 = load atomic i64, ptr %70 seq_cst, align 8
  %72 = inttoptr i64 %71 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %73 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %74 = icmp eq i64 %67, %73
  br i1 %74, label %75, label %87

75:                                               ; preds = %66
  %76 = icmp eq i64 %67, %69
  %77 = icmp eq i64 %71, 0
  br i1 %76, label %78, label %81

78:                                               ; preds = %75
  br i1 %77, label %114, label %79

79:                                               ; preds = %78
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !63
  %80 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %67, i64 %71 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br label %87

81:                                               ; preds = %75
  br i1 %77, label %82, label %83

82:                                               ; preds = %81
  call void @__assert_fail(ptr noundef nonnull @.str.24, ptr noundef nonnull @.str.21, i32 noundef 208, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_deq) #14
  unreachable

83:                                               ; preds = %81
  %84 = load ptr, ptr %72, align 8, !tbaa !65
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !63
  %85 = cmpxchg ptr @g_queue, i64 %67, i64 %71 seq_cst seq_cst, align 8
  %86 = extractvalue { i64, i1 } %85, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br i1 %86, label %88, label %87

87:                                               ; preds = %83, %79, %66
  br label %66

88:                                               ; preds = %83
  %89 = icmp eq i64 %67, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %89, label %112, label %90

90:                                               ; preds = %88
  %91 = getelementptr inbounds nuw i8, ptr %68, i64 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %92 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !9
  %93 = urem i64 %92, 3
  %94 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %93
  %95 = getelementptr inbounds nuw i8, ptr %68, i64 32
  store ptr @free_cb, ptr %95, align 8, !tbaa !10
  %96 = getelementptr inbounds nuw i8, ptr %68, i64 40
  store ptr null, ptr %96, align 8, !tbaa !18
  store ptr null, ptr %91, align 8, !tbaa !19
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %97 = load atomic i64, ptr %94 seq_cst, align 8
  %98 = inttoptr i64 %97 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %99 = ptrtoint ptr %91 to i64
  br label %100

100:                                              ; preds = %100, %90
  %101 = phi ptr [ %98, %90 ], [ %107, %100 ]
  store ptr %101, ptr %91, align 8, !tbaa !22
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !23
  %102 = ptrtoint ptr %101 to i64
  %103 = cmpxchg ptr %94, i64 %102, i64 %99 release monotonic, align 8
  %104 = extractvalue { i64, i1 } %103, 1
  %105 = extractvalue { i64, i1 } %103, 0
  %106 = inttoptr i64 %105 to ptr
  %107 = select i1 %104, ptr %101, ptr %106
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !24
  %108 = icmp eq ptr %101, %107
  br i1 %108, label %109, label %100, !llvm.loop !25

109:                                              ; preds = %100
  %110 = getelementptr inbounds nuw i8, ptr %94, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !27
  %111 = atomicrmw add ptr %110, i64 1 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !28
  br label %112

112:                                              ; preds = %88, %109
  %113 = icmp eq ptr %84, null
  br i1 %113, label %114, label %140

114:                                              ; preds = %78, %112
  %115 = call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #15
  store i64 %60, ptr %115, align 8, !tbaa !68
  %116 = call noalias dereferenceable_or_null(48) ptr @malloc(i64 noundef 48) #15
  %117 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef %3, i64 noundef %60)
  %118 = icmp eq ptr %116, null
  br i1 %118, label %119, label %120

119:                                              ; preds = %114
  call void @__assert_fail(ptr noundef nonnull @.str.25, ptr noundef nonnull @.str.21, i32 noundef 113, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_enq) #14
  unreachable

120:                                              ; preds = %114
  store ptr %115, ptr %116, align 8, !tbaa !65
  %121 = getelementptr inbounds nuw i8, ptr %116, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !70
  store atomic i64 0, ptr %121 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !71
  %122 = ptrtoint ptr %116 to i64
  br label %123

123:                                              ; preds = %137, %120
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %124 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  %125 = inttoptr i64 %124 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %126 = getelementptr inbounds nuw i8, ptr %125, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %127 = load atomic i64, ptr %126 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %128 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %129 = icmp eq i64 %124, %128
  br i1 %129, label %130, label %137

130:                                              ; preds = %123
  %131 = icmp eq i64 %127, 0
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13
  br i1 %131, label %132, label %135

132:                                              ; preds = %130
  %133 = cmpxchg ptr %126, i64 0, i64 %122 seq_cst seq_cst, align 8
  %134 = extractvalue { i64, i1 } %133, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br i1 %134, label %138, label %137

135:                                              ; preds = %130
  %136 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %124, i64 %127 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br label %137

137:                                              ; preds = %135, %132, %123
  br label %123

138:                                              ; preds = %132
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !63
  %139 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %124, i64 %122 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br label %143

140:                                              ; preds = %112
  %141 = load i64, ptr %84, align 8, !tbaa !68
  %142 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %3, i64 noundef %141)
  call void @free(ptr noundef nonnull %84) #13
  br label %143

143:                                              ; preds = %140, %138
  %144 = load i32, ptr %8, align 8, !tbaa !52
  switch i32 %144, label %148 [
    i32 0, label %145
    i32 1, label %146
  ]

145:                                              ; preds = %143
  call void @__assert_fail(ptr noundef nonnull @.str.27, ptr noundef nonnull @.str.6, i32 noundef 210, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_exit) #14
  unreachable

146:                                              ; preds = %143
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  store atomic i64 0, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !62
  %147 = load i32, ptr %8, align 8, !tbaa !52
  br label %148

148:                                              ; preds = %143, %146
  %149 = phi i32 [ %144, %143 ], [ %147, %146 ]
  %150 = add i32 %149, -1
  store i32 %150, ptr %8, align 8, !tbaa !52
  %151 = add nuw nsw i64 %60, 1
  %152 = icmp eq i64 %151, 10000
  br i1 %152, label %22, label %58, !llvm.loop !72

153:                                              ; preds = %53, %5
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #13
  ret ptr null
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #4 {
  %1 = alloca [12 x i64], align 16
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #13
  %2 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @g_lock, ptr noundef null) #13
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %5, label %4

4:                                                ; preds = %0
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 113, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #14
  unreachable

5:                                                ; preds = %0
  %6 = load ptr, ptr @g_lock_lib, align 8
  %7 = load <2 x ptr>, ptr getelementptr inbounds nuw (i8, ptr @g_lock_lib, i64 8), align 8
  %8 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_lock_lib, i64 8), align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), i8 0, i64 16, i1 false)
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !73
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8) seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !74
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 16) seq_cst, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !51
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !73
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 24) seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !74
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 32) seq_cst, align 32
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !51
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !73
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 40) seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !74
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 48) seq_cst, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !51
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  store atomic i64 1, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !51
  %9 = icmp ne ptr %6, null
  %10 = icmp ne ptr %8, null
  %11 = select i1 %9, i1 %10, i1 false
  br i1 %11, label %13, label %12

12:                                               ; preds = %5
  tail call void @__assert_fail(ptr noundef nonnull @.str.34, ptr noundef nonnull @.str.6, i32 noundef 102, ptr noundef nonnull @__PRETTY_FUNCTION__.vebr_init) #14
  unreachable

13:                                               ; preds = %5
  store ptr %6, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !75
  store <2 x ptr> %7, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !75
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), align 8, !tbaa !76
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !70
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 24) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !71
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !70
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr @g_queue monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !71
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !70
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !71
  %14 = call i32 @pthread_create(ptr noundef nonnull %1, ptr noundef null, ptr noundef nonnull @run, ptr noundef null) #13
  %15 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %16 = call i32 @pthread_create(ptr noundef nonnull %15, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 1 to ptr)) #13
  %17 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %18 = call i32 @pthread_create(ptr noundef nonnull %17, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 2 to ptr)) #13
  %19 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %20 = call i32 @pthread_create(ptr noundef nonnull %19, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 3 to ptr)) #13
  %21 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %22 = call i32 @pthread_create(ptr noundef nonnull %21, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 4 to ptr)) #13
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 40
  %24 = call i32 @pthread_create(ptr noundef nonnull %23, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 5 to ptr)) #13
  %25 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %26 = call i32 @pthread_create(ptr noundef nonnull %25, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 6 to ptr)) #13
  %27 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %28 = call i32 @pthread_create(ptr noundef nonnull %27, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 7 to ptr)) #13
  %29 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %30 = call i32 @pthread_create(ptr noundef nonnull %29, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 8 to ptr)) #13
  %31 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %32 = call i32 @pthread_create(ptr noundef nonnull %31, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 9 to ptr)) #13
  %33 = getelementptr inbounds nuw i8, ptr %1, i64 80
  %34 = call i32 @pthread_create(ptr noundef nonnull %33, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 10 to ptr)) #13
  %35 = getelementptr inbounds nuw i8, ptr %1, i64 88
  %36 = call i32 @pthread_create(ptr noundef nonnull %35, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 11 to ptr)) #13
  %37 = load i64, ptr %15, align 8, !tbaa !78
  %38 = call i32 @pthread_join(i64 noundef %37, ptr noundef null) #13
  %39 = load i64, ptr %17, align 16, !tbaa !78
  %40 = call i32 @pthread_join(i64 noundef %39, ptr noundef null) #13
  %41 = load i64, ptr %19, align 8, !tbaa !78
  %42 = call i32 @pthread_join(i64 noundef %41, ptr noundef null) #13
  %43 = load i64, ptr %21, align 16, !tbaa !78
  %44 = call i32 @pthread_join(i64 noundef %43, ptr noundef null) #13
  %45 = load i64, ptr %23, align 8, !tbaa !78
  %46 = call i32 @pthread_join(i64 noundef %45, ptr noundef null) #13
  %47 = load i64, ptr %25, align 16, !tbaa !78
  %48 = call i32 @pthread_join(i64 noundef %47, ptr noundef null) #13
  %49 = load i64, ptr %27, align 8, !tbaa !78
  %50 = call i32 @pthread_join(i64 noundef %49, ptr noundef null) #13
  %51 = load i64, ptr %29, align 16, !tbaa !78
  %52 = call i32 @pthread_join(i64 noundef %51, ptr noundef null) #13
  %53 = load i64, ptr %31, align 8, !tbaa !78
  %54 = call i32 @pthread_join(i64 noundef %53, ptr noundef null) #13
  %55 = load i64, ptr %33, align 16, !tbaa !78
  %56 = call i32 @pthread_join(i64 noundef %55, ptr noundef null) #13
  %57 = load i64, ptr %35, align 8, !tbaa !78
  %58 = call i32 @pthread_join(i64 noundef %57, ptr noundef null) #13
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !79
  store atomic i8 1, ptr @g_stop seq_cst, align 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !80
  %59 = load i64, ptr %1, align 16, !tbaa !78
  %60 = call i32 @pthread_join(i64 noundef %59, ptr noundef null) #13
  br label %61

61:                                               ; preds = %88, %13
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %62 = load atomic i64, ptr @g_queue seq_cst, align 8
  %63 = inttoptr i64 %62 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %64 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %65 = getelementptr inbounds nuw i8, ptr %63, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %66 = load atomic i64, ptr %65 seq_cst, align 8
  %67 = inttoptr i64 %66 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %68 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %69 = icmp eq i64 %62, %68
  br i1 %69, label %70, label %88

70:                                               ; preds = %61
  %71 = icmp eq i64 %62, %64
  %72 = icmp eq i64 %66, 0
  br i1 %71, label %73, label %76

73:                                               ; preds = %70
  br i1 %72, label %89, label %74

74:                                               ; preds = %73
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !63
  %75 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %62, i64 %66 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br label %88

76:                                               ; preds = %70
  br i1 %72, label %77, label %78

77:                                               ; preds = %76
  call void @__assert_fail(ptr noundef nonnull @.str.24, ptr noundef nonnull @.str.21, i32 noundef 208, ptr noundef nonnull @__PRETTY_FUNCTION__.vqueue_ub_deq) #14
  unreachable

78:                                               ; preds = %76
  %79 = load ptr, ptr %67, align 8, !tbaa !65
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !63
  %80 = cmpxchg ptr @g_queue, i64 %62, i64 %66 seq_cst seq_cst, align 8
  %81 = extractvalue { i64, i1 } %80, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !64
  br i1 %81, label %82, label %88

82:                                               ; preds = %78
  %83 = icmp eq i64 %62, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %83, label %85, label %84

84:                                               ; preds = %82
  call void @free(ptr noundef nonnull %63) #13
  br label %85

85:                                               ; preds = %82, %84
  %86 = icmp eq ptr %79, null
  br i1 %86, label %89, label %87

87:                                               ; preds = %85
  call void @free(ptr noundef nonnull %79) #13
  br label %88

88:                                               ; preds = %87, %78, %74, %61
  br label %61, !llvm.loop !81

89:                                               ; preds = %85, %73
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %90 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %91 = icmp eq i64 %90, 0
  br i1 %91, label %101, label %92

92:                                               ; preds = %89, %99
  %93 = phi i64 [ %96, %99 ], [ %90, %89 ]
  %94 = inttoptr i64 %93 to ptr
  %95 = getelementptr inbounds nuw i8, ptr %94, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %96 = load atomic i64, ptr %95 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !21
  %97 = icmp eq i64 %93, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %97, label %99, label %98

98:                                               ; preds = %92
  call void @free(ptr noundef nonnull %94) #13
  br label %99

99:                                               ; preds = %98, %92
  %100 = icmp eq i64 %96, 0
  br i1 %100, label %101, label %92, !llvm.loop !82

101:                                              ; preds = %99, %89
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %102 = atomicrmw xchg ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0 acquire, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 16) monotonic, align 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !34
  %103 = icmp eq i64 %102, 0
  br i1 %103, label %117, label %104

104:                                              ; preds = %101
  %105 = inttoptr i64 %102 to ptr
  br label %106

106:                                              ; preds = %112, %104
  %107 = phi ptr [ %113, %112 ], [ %105, %104 ]
  %108 = getelementptr inbounds nuw i8, ptr %107, i64 16
  %109 = load ptr, ptr %108, align 8, !tbaa !10
  %110 = icmp eq ptr %109, null
  br i1 %110, label %111, label %112

111:                                              ; preds = %106, %122, %137
  call void @__assert_fail(ptr noundef nonnull @.str.15, ptr noundef nonnull @.str.8, i32 noundef 197, ptr noundef nonnull @__PRETTY_FUNCTION__.smr_nodes_list_destroy) #14
  unreachable

112:                                              ; preds = %106
  %113 = load ptr, ptr %107, align 8, !tbaa !19
  %114 = getelementptr inbounds nuw i8, ptr %107, i64 24
  %115 = load ptr, ptr %114, align 8, !tbaa !18
  call void %109(ptr noundef nonnull %107, ptr noundef %115) #13
  %116 = icmp eq ptr %113, null
  br i1 %116, label %117, label %106, !llvm.loop !48

117:                                              ; preds = %112, %101
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %118 = atomicrmw xchg ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 24), i64 0 acquire, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 32) monotonic, align 32
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !34
  %119 = icmp eq i64 %118, 0
  br i1 %119, label %132, label %120

120:                                              ; preds = %117
  %121 = inttoptr i64 %118 to ptr
  br label %122

122:                                              ; preds = %127, %120
  %123 = phi ptr [ %128, %127 ], [ %121, %120 ]
  %124 = getelementptr inbounds nuw i8, ptr %123, i64 16
  %125 = load ptr, ptr %124, align 8, !tbaa !10
  %126 = icmp eq ptr %125, null
  br i1 %126, label %111, label %127

127:                                              ; preds = %122
  %128 = load ptr, ptr %123, align 8, !tbaa !19
  %129 = getelementptr inbounds nuw i8, ptr %123, i64 24
  %130 = load ptr, ptr %129, align 8, !tbaa !18
  call void %125(ptr noundef nonnull %123, ptr noundef %130) #13
  %131 = icmp eq ptr %128, null
  br i1 %131, label %132, label %122, !llvm.loop !48

132:                                              ; preds = %127, %117
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %133 = atomicrmw xchg ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 40), i64 0 acquire, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 48) monotonic, align 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !34
  %134 = icmp eq i64 %133, 0
  br i1 %134, label %147, label %135

135:                                              ; preds = %132
  %136 = inttoptr i64 %133 to ptr
  br label %137

137:                                              ; preds = %142, %135
  %138 = phi ptr [ %143, %142 ], [ %136, %135 ]
  %139 = getelementptr inbounds nuw i8, ptr %138, i64 16
  %140 = load ptr, ptr %139, align 8, !tbaa !10
  %141 = icmp eq ptr %140, null
  br i1 %141, label %111, label %142

142:                                              ; preds = %137
  %143 = load ptr, ptr %138, align 8, !tbaa !19
  %144 = getelementptr inbounds nuw i8, ptr %138, i64 24
  %145 = load ptr, ptr %144, align 8, !tbaa !18
  call void %140(ptr noundef nonnull %138, ptr noundef %145) #13
  %146 = icmp eq ptr %143, null
  br i1 %146, label %147, label %137, !llvm.loop !48

147:                                              ; preds = %142, %132
  %148 = call i32 @pthread_mutex_destroy(ptr noundef nonnull @g_lock) #13
  %149 = icmp eq i32 %148, 0
  br i1 %149, label %151, label %150

150:                                              ; preds = %147
  call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4, i32 noundef 139, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #14
  unreachable

151:                                              ; preds = %147
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #13
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: cold noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind
declare i32 @pthread_mutex_destroy(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #11

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #12

attributes #0 = { inlinehint nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #1 = { mustprogress nounwind willreturn uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #4 = { nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #6 = { nofree nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #8 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #9 = { cold noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #10 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #11 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #13 = { nounwind }
attributes #14 = { cold noreturn nounwind }
attributes #15 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{i64 2147990121}
!7 = !{i64 2147990161}
!8 = !{i64 2147991059}
!9 = !{i64 2147991099}
!10 = !{!11, !14, i64 16}
!11 = !{!"smr_node_s", !12, i64 0, !17, i64 8, !14, i64 16, !14, i64 24}
!12 = !{!"smr_node_core_s", !13, i64 0}
!13 = !{!"p1 _ZTS15smr_node_core_s", !14, i64 0}
!14 = !{!"any pointer", !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C/C++ TBAA"}
!17 = !{!"int", !15, i64 0}
!18 = !{!11, !14, i64 24}
!19 = !{!11, !13, i64 0}
!20 = !{i64 2147991527}
!21 = !{i64 2147991567}
!22 = !{!12, !13, i64 0}
!23 = !{i64 2147996797}
!24 = !{i64 2147996839}
!25 = distinct !{!25, !26}
!26 = !{!"llvm.loop.mustprogress"}
!27 = !{i64 2148002807}
!28 = !{i64 2148002847}
!29 = !{i64 2147990357}
!30 = !{i64 2147990397}
!31 = !{i64 2147994803}
!32 = !{i64 2147994843}
!33 = !{i64 2147992619}
!34 = !{i64 2147992659}
!35 = !{!36, !14, i64 72}
!36 = !{!"vebr_s", !37, i64 0, !15, i64 8, !39, i64 56, !41, i64 72}
!37 = !{!"vatomic64_s", !38, i64 0}
!38 = !{!"long", !15, i64 0}
!39 = !{!"dbl_list_s", !40, i64 0, !38, i64 8}
!40 = !{!"p1 _ZTS15dbl_list_node_s", !14, i64 0}
!41 = !{!"smr_lock_lib_s", !14, i64 0, !14, i64 8, !14, i64 16}
!42 = !{!36, !14, i64 88}
!43 = !{!40, !40, i64 0}
!44 = distinct !{!44, !26}
!45 = !{!36, !14, i64 80}
!46 = !{i64 2147995997}
!47 = !{i64 2147996039}
!48 = distinct !{!48, !26}
!49 = distinct !{!49, !26}
!50 = !{i64 2147992463}
!51 = !{i64 2147992503}
!52 = !{!53, !17, i64 24}
!53 = !{!"vebr_instance_s", !54, i64 0, !37, i64 16, !17, i64 24}
!54 = !{!"dbl_list_node_s", !40, i64 0, !40, i64 8}
!55 = !{!39, !40, i64 0}
!56 = !{!54, !40, i64 0}
!57 = !{!54, !40, i64 8}
!58 = !{!39, !38, i64 8}
!59 = !{i64 2147991215}
!60 = !{i64 2147991255}
!61 = !{i64 2147992541}
!62 = !{i64 2147992581}
!63 = !{i64 2147996637}
!64 = !{i64 2147996679}
!65 = !{!66, !14, i64 0}
!66 = !{!"vqueue_ub_node_s", !14, i64 0, !67, i64 8, !11, i64 16}
!67 = !{!"vatomicptr_s", !14, i64 0}
!68 = !{!69, !38, i64 0}
!69 = !{!"data_s", !38, i64 0}
!70 = !{i64 2147993087}
!71 = !{i64 2147993127}
!72 = distinct !{!72, !26}
!73 = !{i64 2147992931}
!74 = !{i64 2147992971}
!75 = !{!14, !14, i64 0}
!76 = !{!77, !14, i64 16}
!77 = !{!"vqueue_ub_s", !67, i64 0, !67, i64 8, !66, i64 16}
!78 = !{!38, !38, i64 0}
!79 = !{i64 2147991761}
!80 = !{i64 2147991801}
!81 = distinct !{!81, !26}
!82 = distinct !{!82, !26}
