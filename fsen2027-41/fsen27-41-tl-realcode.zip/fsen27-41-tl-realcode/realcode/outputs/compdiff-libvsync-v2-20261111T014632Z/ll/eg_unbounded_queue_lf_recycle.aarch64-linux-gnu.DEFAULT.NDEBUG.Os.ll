; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, [112 x i8], %struct.vqueue_ub_node_s }
%struct.vatomicptr_s = type { ptr }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, [112 x i8] }

@local_pools = local_unnamed_addr global [12 x ptr] zeroinitializer, align 8
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 128
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@str = private unnamed_addr constant [15 x i8] c"New allocation\00", align 1
@str.4 = private unnamed_addr constant [19 x i8] c"Recycle allocation\00", align 1

; Function Attrs: nounwind optsize uwtable
define void @destroy_pools() local_unnamed_addr #0 {
  br label %2

1:                                                ; preds = %15
  ret void

2:                                                ; preds = %0, %15
  %3 = phi i64 [ 0, %0 ], [ %16, %15 ]
  %4 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %3
  %5 = load ptr, ptr %4, align 8, !tbaa !6
  %6 = icmp eq ptr %5, null
  br i1 %6, label %15, label %7

7:                                                ; preds = %2, %7
  %8 = phi ptr [ %13, %7 ], [ %5, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 8
  %10 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %9) #10, !srcloc !11
  %11 = ptrtoint ptr %10 to i64
  %12 = and i64 %11, -128
  %13 = inttoptr i64 %12 to ptr
  tail call void @free(ptr noundef nonnull %8) #11
  %14 = icmp eq i64 %12, 0
  br i1 %14, label %15, label %7, !llvm.loop !12

15:                                               ; preds = %7, %2
  %16 = add nuw nsw i64 %3, 1
  %17 = icmp eq i64 %16, 12
  br i1 %17, label %1, label %2, !llvm.loop !14
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind optsize willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #3 {
  tail call void @free(ptr noundef %0) #11
  ret void
}

; Function Attrs: nounwind optsize uwtable
define void @retire_cb(ptr noundef %0, ptr noundef %1) local_unnamed_addr #0 {
  %3 = ptrtoint ptr %1 to i64
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %4) #10, !srcloc !11
  %6 = ptrtoint ptr %5 to i64
  %7 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %3
  %8 = load ptr, ptr %7, align 8, !tbaa !6
  %9 = add i64 %6, 1
  %10 = ptrtoint ptr %8 to i64
  %11 = and i64 %9, 127
  %12 = or i64 %11, %10
  %13 = inttoptr i64 %12 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %13, ptr nonnull elementtype(ptr) %4) #10, !srcloc !15
  store ptr %0, ptr %7, align 8, !tbaa !6
  ret void
}

; Function Attrs: nounwind optsize uwtable
define ptr @alloc_qnode(i64 noundef %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %0
  %3 = load ptr, ptr %2, align 8, !tbaa !6
  %4 = icmp eq ptr %3, null
  br i1 %4, label %11, label %5

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %7 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %6) #10, !srcloc !11
  %8 = ptrtoint ptr %7 to i64
  %9 = and i64 %8, -128
  %10 = inttoptr i64 %9 to ptr
  store ptr %10, ptr %2, align 8, !tbaa !6
  br label %13

11:                                               ; preds = %1
  %12 = tail call noalias align 128 dereferenceable_or_null(128) ptr @memalign(i64 noundef 128, i64 noundef 128) #12
  br label %13

13:                                               ; preds = %11, %5
  %14 = phi ptr [ @str, %11 ], [ @str.4, %5 ]
  %15 = phi ptr [ %12, %11 ], [ %3, %5 ]
  %16 = tail call i32 @puts(ptr nonnull dereferenceable(1) %14)
  ret ptr %15
}

; Function Attrs: nofree nounwind optsize
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @memalign(i64 allocalign noundef, i64 noundef) local_unnamed_addr #5

; Function Attrs: nounwind optsize uwtable
define noundef ptr @run(ptr noundef %0) #0 {
  %2 = ptrtoint ptr %0 to i64
  %3 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %2
  br label %4

4:                                                ; preds = %1, %115
  %5 = phi i64 [ 0, %1 ], [ %116, %115 ]
  br label %7

6:                                                ; preds = %115
  ret ptr null

7:                                                ; preds = %47, %4
  %8 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %9 = ptrtoint ptr %8 to i64
  %10 = and i64 %9, -128
  %11 = inttoptr i64 %10 to ptr
  %12 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %13 = ptrtoint ptr %12 to i64
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %15 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %14) #10, !srcloc !11
  %16 = ptrtoint ptr %15 to i64
  %17 = and i64 %16, -128
  %18 = inttoptr i64 %17 to ptr
  %19 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %20 = ptrtoint ptr %19 to i64
  %21 = and i64 %20, -128
  %22 = icmp eq i64 %10, %21
  %23 = xor i64 %20, %9
  %24 = and i64 %23, 127
  %25 = icmp eq i64 %24, 0
  %26 = select i1 %22, i1 %25, i1 false
  br i1 %26, label %27, label %47

27:                                               ; preds = %7
  %28 = and i64 %13, -128
  %29 = icmp eq i64 %10, %28
  br i1 %29, label %30, label %38

30:                                               ; preds = %27
  %31 = icmp eq i64 %17, 0
  br i1 %31, label %61, label %32

32:                                               ; preds = %30
  %33 = add i64 %13, 1
  %34 = and i64 %33, 127
  %35 = or disjoint i64 %34, %17
  %36 = inttoptr i64 %35 to ptr
  %37 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %36, ptr %12, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %47

38:                                               ; preds = %27
  %39 = load ptr, ptr %18, align 128, !tbaa !17
  %40 = add i64 %9, 1
  %41 = and i64 %40, 127
  %42 = or disjoint i64 %17, %41
  %43 = inttoptr i64 %42 to ptr
  %44 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr %43, ptr %8, ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !16
  %45 = extractvalue { ptr, i32 } %44, 0
  %46 = icmp eq ptr %45, %8
  br i1 %46, label %48, label %47

47:                                               ; preds = %38, %32, %7
  br label %7

48:                                               ; preds = %38
  %49 = icmp eq i64 %10, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %49, label %59, label %50

50:                                               ; preds = %48
  %51 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %14) #10, !srcloc !11
  %52 = ptrtoint ptr %51 to i64
  %53 = load ptr, ptr %3, align 8, !tbaa !6
  %54 = add i64 %52, 1
  %55 = ptrtoint ptr %53 to i64
  %56 = and i64 %54, 127
  %57 = or i64 %56, %55
  %58 = inttoptr i64 %57 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %58, ptr nonnull elementtype(ptr) %14) #10, !srcloc !15
  store ptr %11, ptr %3, align 8, !tbaa !6
  br label %59

59:                                               ; preds = %48, %50
  %60 = icmp eq ptr %39, null
  br i1 %60, label %61, label %112

61:                                               ; preds = %30, %59
  %62 = tail call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #13
  store i64 %5, ptr %62, align 8, !tbaa !20
  %63 = tail call ptr @alloc_qnode(i64 noundef %2) #14
  %64 = load i64, ptr %62, align 8, !tbaa !20
  %65 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %2, i64 noundef %64) #14
  store ptr %62, ptr %63, align 128, !tbaa !17
  %66 = getelementptr inbounds nuw i8, ptr %63, i64 8
  %67 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %66) #10, !srcloc !11
  %68 = ptrtoint ptr %67 to i64
  %69 = and i64 %68, 127
  %70 = inttoptr i64 %69 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %70, ptr nonnull elementtype(ptr) %66) #10, !srcloc !15
  %71 = ptrtoint ptr %63 to i64
  br label %72

72:                                               ; preds = %105, %61
  %73 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %74 = ptrtoint ptr %73 to i64
  %75 = and i64 %74, -128
  %76 = inttoptr i64 %75 to ptr
  %77 = getelementptr inbounds nuw i8, ptr %76, i64 8
  %78 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %77) #10, !srcloc !11
  %79 = ptrtoint ptr %78 to i64
  %80 = and i64 %79, -128
  %81 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %82 = ptrtoint ptr %81 to i64
  %83 = and i64 %82, -128
  %84 = icmp eq i64 %75, %83
  %85 = xor i64 %82, %74
  %86 = and i64 %85, 127
  %87 = icmp eq i64 %86, 0
  %88 = select i1 %84, i1 %87, i1 false
  br i1 %88, label %89, label %105

89:                                               ; preds = %72
  %90 = icmp eq i64 %80, 0
  br i1 %90, label %91, label %99

91:                                               ; preds = %89
  %92 = add nuw nsw i64 %79, 1
  %93 = and i64 %92, 127
  %94 = or i64 %93, %71
  %95 = inttoptr i64 %94 to ptr
  %96 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %95, ptr %78, ptr nonnull elementtype(ptr) %77) #10, !srcloc !16
  %97 = extractvalue { ptr, i32 } %96, 0
  %98 = icmp eq ptr %97, %78
  br i1 %98, label %106, label %105

99:                                               ; preds = %89
  %100 = add i64 %74, 1
  %101 = and i64 %100, 127
  %102 = or disjoint i64 %101, %80
  %103 = inttoptr i64 %102 to ptr
  %104 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %103, ptr %73, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %105

105:                                              ; preds = %99, %91, %72
  br label %72

106:                                              ; preds = %91
  %107 = add i64 %74, 1
  %108 = and i64 %107, 127
  %109 = or i64 %108, %71
  %110 = inttoptr i64 %109 to ptr
  %111 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %110, ptr %73, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %115

112:                                              ; preds = %59
  %113 = load i64, ptr %39, align 8, !tbaa !20
  %114 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.3, i64 noundef %2, i64 noundef %113) #14
  tail call void @free(ptr noundef nonnull %39) #11
  br label %115

115:                                              ; preds = %106, %112
  %116 = add nuw nsw i64 %5, 1
  %117 = icmp eq i64 %116, 100
  br i1 %117, label %6, label %4, !llvm.loop !23
}

; Function Attrs: mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #6

; Function Attrs: nounwind optsize uwtable
define noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [12 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #10
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 136)) #10, !srcloc !24
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 128), ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !24
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 128), ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !24
  br label %2

2:                                                ; preds = %0, %2
  %3 = phi i64 [ 0, %0 ], [ %7, %2 ]
  %4 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %3
  %5 = inttoptr i64 %3 to ptr
  %6 = call i32 @pthread_create(ptr noundef nonnull %4, ptr noundef null, ptr noundef nonnull @run, ptr noundef %5) #11
  %7 = add nuw nsw i64 %3, 1
  %8 = icmp eq i64 %7, 12
  br i1 %8, label %9, label %2, !llvm.loop !25

9:                                                ; preds = %2, %9
  %10 = phi i64 [ %14, %9 ], [ 0, %2 ]
  %11 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %10
  %12 = load i64, ptr %11, align 8, !tbaa !26
  %13 = call i32 @pthread_join(i64 noundef %12, ptr noundef null) #11
  %14 = add nuw nsw i64 %10, 1
  %15 = icmp eq i64 %14, 12
  br i1 %15, label %16, label %9, !llvm.loop !27

16:                                               ; preds = %9, %62
  %17 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %18 = ptrtoint ptr %17 to i64
  %19 = and i64 %18, -128
  %20 = inttoptr i64 %19 to ptr
  %21 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %22 = ptrtoint ptr %21 to i64
  %23 = getelementptr inbounds nuw i8, ptr %20, i64 8
  %24 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %23) #10, !srcloc !11
  %25 = ptrtoint ptr %24 to i64
  %26 = and i64 %25, -128
  %27 = inttoptr i64 %26 to ptr
  %28 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %29 = ptrtoint ptr %28 to i64
  %30 = and i64 %29, -128
  %31 = icmp eq i64 %19, %30
  %32 = xor i64 %29, %18
  %33 = and i64 %32, 127
  %34 = icmp eq i64 %33, 0
  %35 = select i1 %31, i1 %34, i1 false
  br i1 %35, label %36, label %62

36:                                               ; preds = %16
  %37 = and i64 %22, -128
  %38 = icmp eq i64 %19, %37
  br i1 %38, label %39, label %47

39:                                               ; preds = %36
  %40 = icmp eq i64 %26, 0
  br i1 %40, label %63, label %41

41:                                               ; preds = %39
  %42 = add i64 %22, 1
  %43 = and i64 %42, 127
  %44 = or disjoint i64 %43, %26
  %45 = inttoptr i64 %44 to ptr
  %46 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %45, ptr %21, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %62

47:                                               ; preds = %36
  %48 = load ptr, ptr %27, align 128, !tbaa !17
  %49 = add i64 %18, 1
  %50 = and i64 %49, 127
  %51 = or disjoint i64 %26, %50
  %52 = inttoptr i64 %51 to ptr
  %53 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr %52, ptr %17, ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !16
  %54 = extractvalue { ptr, i32 } %53, 0
  %55 = icmp eq ptr %54, %17
  br i1 %55, label %56, label %62

56:                                               ; preds = %47
  %57 = icmp eq i64 %19, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %57, label %59, label %58

58:                                               ; preds = %56
  call void @free(ptr noundef %20) #11
  br label %59

59:                                               ; preds = %56, %58
  %60 = icmp eq ptr %48, null
  br i1 %60, label %63, label %61

61:                                               ; preds = %59
  call void @free(ptr noundef nonnull %48) #11
  br label %62

62:                                               ; preds = %61, %47, %41, %16
  br label %16, !llvm.loop !28

63:                                               ; preds = %59, %39
  %64 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %65 = ptrtoint ptr %64 to i64
  %66 = and i64 %65, -128
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %79, label %68

68:                                               ; preds = %63, %75
  %69 = phi i64 [ %77, %75 ], [ %66, %63 ]
  %70 = inttoptr i64 %69 to ptr
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 8
  %72 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %71) #10, !srcloc !11
  %73 = icmp eq i64 %69, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %73, label %75, label %74

74:                                               ; preds = %68
  call void @free(ptr noundef nonnull %70) #11
  br label %75

75:                                               ; preds = %74, %68
  %76 = ptrtoint ptr %72 to i64
  %77 = and i64 %76, -128
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %68, !llvm.loop !29

79:                                               ; preds = %75, %63
  call void @destroy_pools() #14
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #10
  ret i32 0
}

; Function Attrs: nounwind optsize
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: optsize
declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #9

attributes #0 = { nounwind optsize uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #3 = { mustprogress nounwind optsize willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { nofree nounwind optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #6 = { mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #7 = { nounwind optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #8 = { optsize "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #9 = { nofree nounwind }
attributes #10 = { nounwind }
attributes #11 = { nounwind optsize }
attributes #12 = { nounwind optsize allocsize(1) }
attributes #13 = { nounwind optsize allocsize(0) }
attributes #14 = { optsize }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{!7, !7, i64 0}
!7 = !{!"p1 _ZTS16vqueue_ub_node_s", !8, i64 0}
!8 = !{!"any pointer", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{i64 448080}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = distinct !{!14, !13}
!15 = !{i64 452470}
!16 = !{i64 518907, i64 518942, i64 518958, i64 518992, i64 519027, i64 519048, i64 519092, i64 519122}
!17 = !{!18, !8, i64 0}
!18 = !{!"vqueue_ub_node_s", !8, i64 0, !19, i64 8}
!19 = !{!"vatomicptr_s", !8, i64 0}
!20 = !{!21, !22, i64 0}
!21 = !{!"data_s", !22, i64 0}
!22 = !{!"long", !9, i64 0}
!23 = distinct !{!23, !13}
!24 = !{i64 453440}
!25 = distinct !{!25, !13}
!26 = !{!22, !22, i64 0}
!27 = distinct !{!27, !13}
!28 = distinct !{!28, !13}
!29 = distinct !{!29, !13}
