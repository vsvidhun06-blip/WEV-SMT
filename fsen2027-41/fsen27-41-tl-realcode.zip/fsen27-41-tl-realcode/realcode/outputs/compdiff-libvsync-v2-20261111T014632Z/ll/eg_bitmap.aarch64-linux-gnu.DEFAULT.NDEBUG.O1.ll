; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_bitmap.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_bitmap.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%struct.vatomic64_s = type { i64 }

@g_bitmap = local_unnamed_addr global ptr null, align 8
@.str = private unnamed_addr constant [36 x i8] c"%zu bits were raised, expected %zu\0A\00", align 1

; Function Attrs: nounwind uwtable
define void @reader() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %0, %40
  %2 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %4 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %3) #8, !srcloc !11
  %5 = getelementptr inbounds nuw i8, ptr %2, i64 8
  br label %6

6:                                                ; preds = %35, %1
  %7 = phi i64 [ 0, %1 ], [ %36, %35 ]
  %8 = phi i64 [ %4, %1 ], [ %37, %35 ]
  %9 = phi i64 [ 0, %1 ], [ %39, %35 ]
  %10 = load i64, ptr %2, align 8, !tbaa !12
  %11 = icmp eq i64 %8, 0
  br i1 %11, label %12, label %23

12:                                               ; preds = %6
  %13 = add i64 %7, 1
  %14 = icmp ult i64 %13, %10
  br i1 %14, label %18, label %35

15:                                               ; preds = %18
  %16 = add nuw i64 %19, 1
  %17 = icmp eq i64 %16, %10
  br i1 %17, label %35, label %18, !llvm.loop !14

18:                                               ; preds = %12, %15
  %19 = phi i64 [ %16, %15 ], [ %13, %12 ]
  %20 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %3, i64 %19
  %21 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %20) #8, !srcloc !11
  %22 = icmp eq i64 %21, 0
  br i1 %22, label %15, label %23, !llvm.loop !14

23:                                               ; preds = %18, %6
  %24 = phi i64 [ %7, %6 ], [ %19, %18 ]
  %25 = phi i64 [ %8, %6 ], [ %21, %18 ]
  %26 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %25, i1 true)
  %27 = shl i64 %24, 6
  %28 = or disjoint i64 %26, %27
  %29 = load i64, ptr %5, align 8, !tbaa !12
  %30 = icmp ult i64 %28, %29
  br i1 %30, label %31, label %35

31:                                               ; preds = %23
  %32 = shl nuw i64 1, %26
  %33 = xor i64 %32, -1
  %34 = and i64 %25, %33
  br label %35

35:                                               ; preds = %15, %12, %23, %31
  %36 = phi i64 [ %24, %31 ], [ %24, %23 ], [ %7, %12 ], [ %7, %15 ]
  %37 = phi i64 [ %34, %31 ], [ %25, %23 ], [ %8, %12 ], [ %21, %15 ]
  %38 = phi i1 [ true, %31 ], [ false, %23 ], [ false, %12 ], [ false, %15 ]
  %39 = add i64 %9, 1
  br i1 %38, label %6, label %40, !llvm.loop !17

40:                                               ; preds = %35
  %41 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %9, i64 noundef 693)
  %42 = icmp ult i64 %9, 693
  br i1 %42, label %1, label %43, !llvm.loop !18

43:                                               ; preds = %40
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind uwtable
define void @writer(i64 noundef %0) local_unnamed_addr #0 {
  %2 = and i64 %0, 288230376151711743
  %3 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %4 = and i64 %0, 288230376151711743
  %5 = icmp eq i64 %4, %2
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %7 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %6, i64 0, i64 %4
  %8 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Aorr ${1:x}, ${0:x}, ${3:x}\0Astlxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %7, i64 -1) #8
  br i1 %5, label %17, label %9

9:                                                ; preds = %1
  %10 = add nuw nsw i64 %4, 1
  %11 = icmp samesign ult i64 %10, %2
  br i1 %11, label %15, label %12

12:                                               ; preds = %15, %9
  %13 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %6, i64 0, i64 %2
  %14 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Aorr ${1:x}, ${0:x}, ${3:x}\0Astlxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %13, i64 -1) #8, !srcloc !19
  br label %17

15:                                               ; preds = %9
  %16 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %6, i64 0, i64 %10
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 -1, ptr nonnull elementtype(i64) %16) #8, !srcloc !20
  br label %12

17:                                               ; preds = %1, %12
  %18 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 16
  %20 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %19, i64 0, i64 %4
  %21 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %20) #8, !srcloc !11
  %22 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 16
  %24 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %23, i64 0, i64 %4
  %25 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Aand ${1:x}, ${0:x}, ${3:x}\0Astlxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %24, i64 range(i64 9223372036854775807, -1) -2) #8, !srcloc !21
  %26 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 16
  %28 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %27, i64 0, i64 %4
  %29 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %28) #8, !srcloc !11
  %30 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 16
  %32 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %31, i64 0, i64 %4
  %33 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Aorr ${1:x}, ${0:x}, ${3:x}\0Astlxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %32, i64 range(i64 1, -9223372036854775807) 1) #8, !srcloc !22
  %34 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 16
  %36 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %35, i64 0, i64 %4
  %37 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %36) #8, !srcloc !11
  ret void
}

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #0 {
  %2 = icmp eq ptr %0, inttoptr (i64 11 to ptr)
  br i1 %2, label %3, label %45

3:                                                ; preds = %1, %42
  %4 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 16
  %6 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %5) #8, !srcloc !11
  %7 = getelementptr inbounds nuw i8, ptr %4, i64 8
  br label %8

8:                                                ; preds = %37, %3
  %9 = phi i64 [ 0, %3 ], [ %38, %37 ]
  %10 = phi i64 [ %6, %3 ], [ %39, %37 ]
  %11 = phi i64 [ 0, %3 ], [ %41, %37 ]
  %12 = load i64, ptr %4, align 8, !tbaa !12
  %13 = icmp eq i64 %10, 0
  br i1 %13, label %14, label %25

14:                                               ; preds = %8
  %15 = add i64 %9, 1
  %16 = icmp ult i64 %15, %12
  br i1 %16, label %20, label %37

17:                                               ; preds = %20
  %18 = add nuw i64 %21, 1
  %19 = icmp eq i64 %18, %12
  br i1 %19, label %37, label %20, !llvm.loop !14

20:                                               ; preds = %14, %17
  %21 = phi i64 [ %18, %17 ], [ %15, %14 ]
  %22 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %5, i64 %21
  %23 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %22) #8, !srcloc !11
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %17, label %25, !llvm.loop !14

25:                                               ; preds = %20, %8
  %26 = phi i64 [ %9, %8 ], [ %21, %20 ]
  %27 = phi i64 [ %10, %8 ], [ %23, %20 ]
  %28 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %27, i1 true)
  %29 = shl i64 %26, 6
  %30 = or disjoint i64 %28, %29
  %31 = load i64, ptr %7, align 8, !tbaa !12
  %32 = icmp ult i64 %30, %31
  br i1 %32, label %33, label %37

33:                                               ; preds = %25
  %34 = shl nuw i64 1, %28
  %35 = xor i64 %34, -1
  %36 = and i64 %27, %35
  br label %37

37:                                               ; preds = %17, %33, %25, %14
  %38 = phi i64 [ %26, %33 ], [ %26, %25 ], [ %9, %14 ], [ %9, %17 ]
  %39 = phi i64 [ %36, %33 ], [ %27, %25 ], [ %10, %14 ], [ %23, %17 ]
  %40 = phi i1 [ true, %33 ], [ false, %25 ], [ false, %14 ], [ false, %17 ]
  %41 = add i64 %11, 1
  br i1 %40, label %8, label %42, !llvm.loop !17

42:                                               ; preds = %37
  %43 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %11, i64 noundef 693)
  %44 = icmp ult i64 %11, 693
  br i1 %44, label %3, label %72, !llvm.loop !18

45:                                               ; preds = %1
  %46 = ptrtoint ptr %0 to i64
  %47 = and i64 %46, 288230376151711743
  %48 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 16
  %50 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %49, i64 0, i64 %47
  %51 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Aorr ${1:x}, ${0:x}, ${3:x}\0Astlxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %50, i64 -1) #8, !srcloc !19
  %52 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 16
  %54 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %53, i64 0, i64 %47
  %55 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %54) #8, !srcloc !11
  %56 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 16
  %58 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %57, i64 0, i64 %47
  %59 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Aand ${1:x}, ${0:x}, ${3:x}\0Astlxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %58, i64 range(i64 9223372036854775807, -1) -2) #8, !srcloc !21
  %60 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 16
  %62 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %61, i64 0, i64 %47
  %63 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %62) #8, !srcloc !11
  %64 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 16
  %66 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %65, i64 0, i64 %47
  %67 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Aorr ${1:x}, ${0:x}, ${3:x}\0Astlxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %66, i64 range(i64 1, -9223372036854775807) 1) #8, !srcloc !22
  %68 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 16
  %70 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %69, i64 0, i64 %47
  %71 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %70) #8, !srcloc !11
  br label %72

72:                                               ; preds = %42, %45
  ret ptr null
}

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [12 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #8
  %2 = tail call noalias dereferenceable_or_null(104) ptr @malloc(i64 noundef 104) #9
  store ptr %2, ptr @g_bitmap, align 8, !tbaa !6
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store i64 704, ptr %3, align 8, !tbaa !12
  store i64 11, ptr %2, align 8, !tbaa !12
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  br label %5

5:                                                ; preds = %5, %0
  %6 = phi i64 [ 0, %0 ], [ %8, %5 ]
  %7 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %4, i64 0, i64 %6
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) %7) #8, !srcloc !20
  %8 = add nuw i64 %6, 1
  %9 = load i64, ptr %2, align 8, !tbaa !12
  %10 = icmp ult i64 %8, %9
  br i1 %10, label %5, label %11, !llvm.loop !23

11:                                               ; preds = %5, %11
  %12 = phi i64 [ %16, %11 ], [ 0, %5 ]
  %13 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %12
  %14 = inttoptr i64 %12 to ptr
  %15 = call i32 @pthread_create(ptr noundef nonnull %13, ptr noundef null, ptr noundef nonnull @run, ptr noundef %14) #8
  %16 = add nuw nsw i64 %12, 1
  %17 = icmp eq i64 %16, 12
  br i1 %17, label %20, label %11, !llvm.loop !24

18:                                               ; preds = %20
  %19 = load ptr, ptr @g_bitmap, align 8, !tbaa !6
  call void @free(ptr noundef %19) #8
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #8
  ret i32 0

20:                                               ; preds = %11, %20
  %21 = phi i64 [ %25, %20 ], [ 0, %11 ]
  %22 = getelementptr inbounds nuw [12 x i64], ptr %1, i64 0, i64 %21
  %23 = load i64, ptr %22, align 8, !tbaa !12
  %24 = call i32 @pthread_join(i64 noundef %23, ptr noundef null) #8
  %25 = add nuw nsw i64 %21, 1
  %26 = icmp eq i64 %25, 12
  br i1 %26, label %18, label %20, !llvm.loop !25
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #3

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #4

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #5

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #7

attributes #0 = { nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #3 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #6 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #7 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nounwind }
attributes #9 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{!7, !7, i64 0}
!7 = !{!"p1 _ZTS9vbitmap_s", !8, i64 0}
!8 = !{!"any pointer", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{i64 444339}
!12 = !{!13, !13, i64 0}
!13 = !{!"long", !9, i64 0}
!14 = distinct !{!14, !15, !16}
!15 = !{!"llvm.loop.mustprogress"}
!16 = !{!"llvm.loop.unroll.disable"}
!17 = distinct !{!17, !15, !16}
!18 = distinct !{!18, !15, !16}
!19 = !{i64 573365, i64 573400, i64 573416, i64 573450, i64 573493, i64 573536}
!20 = !{i64 448828}
!21 = !{i64 545953, i64 545988, i64 546004, i64 546038, i64 546081, i64 546124}
!22 = !{i64 546720, i64 546755, i64 546771, i64 546805, i64 546848, i64 546891}
!23 = distinct !{!23, !15, !16}
!24 = distinct !{!24, !15, !16}
!25 = distinct !{!25, !15, !16}
