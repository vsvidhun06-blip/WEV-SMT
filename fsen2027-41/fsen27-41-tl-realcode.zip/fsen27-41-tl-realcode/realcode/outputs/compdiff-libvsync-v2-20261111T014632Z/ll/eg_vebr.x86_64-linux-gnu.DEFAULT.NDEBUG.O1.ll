; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = local_unnamed_addr global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = local_unnamed_addr global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_lock(ptr noundef %0) #12
  ret void
}

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #12
  ret void
}

; Function Attrs: mustprogress nounwind willreturn uwtable
define void @free_cb(ptr noundef %0, ptr nocapture readnone %1) #1 {
  %3 = ptrtoint ptr %0 to i64
  %4 = add i64 %3, -16
  %5 = inttoptr i64 %4 to ptr
  tail call void @free(ptr noundef %5) #12
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind uwtable
define void @retire_cb(ptr noundef initializes((16, 24), (32, 48)) %0, ptr nocapture noundef readnone %1) local_unnamed_addr #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !7
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !9
  %5 = urem i64 %4, 3
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr @free_cb, ptr %7, align 8, !tbaa !10
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store ptr null, ptr %8, align 8, !tbaa !18
  store ptr null, ptr %3, align 8, !tbaa !19
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %9 = load atomic i64, ptr %6 seq_cst, align 8
  %10 = inttoptr i64 %9 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %11 = ptrtoint ptr %3 to i64
  br label %12

12:                                               ; preds = %12, %2
  %13 = phi ptr [ %10, %2 ], [ %19, %12 ]
  store ptr %13, ptr %3, align 8, !tbaa !22
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !23
  %14 = ptrtoint ptr %13 to i64
  %15 = cmpxchg ptr %6, i64 %14, i64 %11 release monotonic, align 8
  %16 = extractvalue { i64, i1 } %15, 1
  %17 = extractvalue { i64, i1 } %15, 0
  %18 = inttoptr i64 %17 to ptr
  %19 = select i1 %16, ptr %13, ptr %18
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !24
  %20 = icmp eq ptr %13, %19
  br i1 %20, label %21, label %12, !llvm.loop !25

21:                                               ; preds = %12
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !28
  %23 = atomicrmw add ptr %22, i64 1 monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !29
  ret void
}

; Function Attrs: mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #5 {
  tail call void @free(ptr noundef %0) #12
  ret void
}

; Function Attrs: nounwind uwtable
define void @reclaim() local_unnamed_addr #4 {
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !30
  %1 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !31
  %2 = icmp eq i8 %1, 0
  br i1 %2, label %3, label %50

3:                                                ; preds = %0, %47
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !6
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !7
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !8
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !9
  %5 = add i64 %4, 2
  %6 = urem i64 %5, 3
  %7 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %6
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !32
  %8 = atomicrmw xchg ptr %7, i64 0 acquire, align 8
  %9 = inttoptr i64 %8 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !33
  %10 = getelementptr inbounds nuw i8, ptr %7, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !34
  store atomic i64 0, ptr %10 monotonic, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !35
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !36
  %12 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  tail call void %11(ptr noundef %12) #12
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !44
  %14 = icmp eq ptr %13, null
  br i1 %14, label %26, label %15

15:                                               ; preds = %3, %23
  %16 = phi ptr [ %24, %23 ], [ %13, %3 ]
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 16
  br label %18

18:                                               ; preds = %18, %15
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !8
  %19 = load atomic i64, ptr %17 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !9
  %20 = icmp ne i64 %19, 0
  %21 = icmp ult i64 %19, %4
  %22 = select i1 %20, i1 %21, i1 false
  br i1 %22, label %18, label %23, !llvm.loop !45

23:                                               ; preds = %18
  %24 = load ptr, ptr %16, align 8, !tbaa !44
  %25 = icmp eq ptr %24, null
  br i1 %25, label %26, label %15, !llvm.loop !46

26:                                               ; preds = %23, %3
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !47
  %28 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  tail call void %27(ptr noundef %28) #12
  %29 = add i64 %4, 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !48
  %30 = cmpxchg ptr @g_vebr, i64 %4, i64 %29 seq_cst seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !49
  %31 = icmp eq i64 %8, 0
  br i1 %31, label %42, label %32

32:                                               ; preds = %26, %32
  %33 = phi ptr [ %35, %32 ], [ %9, %26 ]
  %34 = phi i64 [ %40, %32 ], [ 0, %26 ]
  %35 = load ptr, ptr %33, align 8, !tbaa !19
  %36 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %37 = load ptr, ptr %36, align 8, !tbaa !10
  %38 = getelementptr inbounds nuw i8, ptr %33, i64 24
  %39 = load ptr, ptr %38, align 8, !tbaa !18
  tail call void %37(ptr noundef nonnull %33, ptr noundef %39) #12
  %40 = add i64 %34, 1
  %41 = icmp eq ptr %35, null
  br i1 %41, label %42, label %32, !llvm.loop !50

42:                                               ; preds = %32, %26
  %43 = phi i64 [ 0, %26 ], [ %40, %32 ]
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %47, label %45

45:                                               ; preds = %42
  %46 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %43)
  br label %47

47:                                               ; preds = %45, %42
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !30
  %48 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !31
  %49 = icmp eq i8 %48, 0
  br i1 %49, label %3, label %50, !llvm.loop !51

50:                                               ; preds = %47, %0
  ret void
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #4 {
  %2 = alloca %struct.vebr_instance_s, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #12
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq ptr %0, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  tail call void @reclaim()
  br label %128

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !52
  store atomic i64 0, ptr %7 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !53
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store i32 0, ptr %8, align 8, !tbaa !54
  %9 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !36
  %10 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  tail call void %9(ptr noundef %10) #12
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  store ptr %11, ptr %2, align 8, !tbaa !58
  %12 = icmp eq ptr %11, null
  br i1 %12, label %15, label %13

13:                                               ; preds = %6
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store ptr %2, ptr %14, align 8, !tbaa !59
  br label %15

15:                                               ; preds = %6, %13
  store ptr %2, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store ptr null, ptr %16, align 8, !tbaa !59
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %18 = add i64 %17, 1
  store i64 %18, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %19 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !47
  %20 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  call void %19(ptr noundef %20) #12
  br label %38

21:                                               ; preds = %123
  %22 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !36
  %23 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  call void %22(ptr noundef %23) #12
  %24 = load ptr, ptr %2, align 8, !tbaa !58
  %25 = load ptr, ptr %16, align 8, !tbaa !59
  %26 = icmp eq ptr %25, null
  br i1 %26, label %28, label %27

27:                                               ; preds = %21
  store ptr %24, ptr %25, align 8, !tbaa !58
  br label %29

28:                                               ; preds = %21
  store ptr %24, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !57
  br label %29

29:                                               ; preds = %28, %27
  %30 = icmp eq ptr %24, null
  br i1 %30, label %33, label %31

31:                                               ; preds = %29
  %32 = getelementptr inbounds nuw i8, ptr %24, i64 8
  store ptr %25, ptr %32, align 8, !tbaa !59
  br label %33

33:                                               ; preds = %29, %31
  %34 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %35 = add i64 %34, -1
  store i64 %35, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !60
  %36 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !47
  %37 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !43
  call void %36(ptr noundef %37) #12
  br label %128

38:                                               ; preds = %15, %123
  %39 = phi i64 [ 0, %15 ], [ %126, %123 ]
  %40 = load i32, ptr %8, align 8, !tbaa !54
  %41 = add i32 %40, 1
  store i32 %41, ptr %8, align 8, !tbaa !54
  %42 = icmp eq i32 %40, 0
  br i1 %42, label %43, label %45

43:                                               ; preds = %38
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !8
  %44 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !9
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !61
  store atomic i64 %44, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !62
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !6
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !7
  br label %45

45:                                               ; preds = %38, %43
  br label %46

46:                                               ; preds = %65, %45
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %47 = load atomic i64, ptr @g_queue seq_cst, align 8
  %48 = inttoptr i64 %47 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %49 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %50 = getelementptr inbounds nuw i8, ptr %48, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %51 = load atomic i64, ptr %50 seq_cst, align 8
  %52 = inttoptr i64 %51 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %53 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %54 = icmp eq i64 %47, %53
  br i1 %54, label %55, label %65

55:                                               ; preds = %46
  %56 = icmp eq i64 %47, %49
  br i1 %56, label %57, label %61

57:                                               ; preds = %55
  %58 = icmp eq i64 %51, 0
  br i1 %58, label %90, label %59

59:                                               ; preds = %57
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !63
  %60 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %49, i64 %51 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !64
  br label %65

61:                                               ; preds = %55
  %62 = load ptr, ptr %52, align 8, !tbaa !65
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !63
  %63 = cmpxchg ptr @g_queue, i64 %47, i64 %51 seq_cst seq_cst, align 8
  %64 = extractvalue { i64, i1 } %63, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !64
  br i1 %64, label %66, label %65

65:                                               ; preds = %61, %59, %46
  br label %46, !llvm.loop !68

66:                                               ; preds = %61
  %67 = icmp eq i64 %47, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %67, label %90, label %68

68:                                               ; preds = %66
  %69 = getelementptr inbounds nuw i8, ptr %48, i64 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !6
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !7
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !8
  %70 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !9
  %71 = urem i64 %70, 3
  %72 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %71
  %73 = getelementptr inbounds nuw i8, ptr %48, i64 32
  store ptr @free_cb, ptr %73, align 8, !tbaa !10
  %74 = getelementptr inbounds nuw i8, ptr %48, i64 40
  store ptr null, ptr %74, align 8, !tbaa !18
  store ptr null, ptr %69, align 8, !tbaa !19
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %75 = load atomic i64, ptr %72 seq_cst, align 8
  %76 = inttoptr i64 %75 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %77 = ptrtoint ptr %69 to i64
  br label %78

78:                                               ; preds = %78, %68
  %79 = phi ptr [ %76, %68 ], [ %85, %78 ]
  store ptr %79, ptr %69, align 8, !tbaa !22
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !23
  %80 = ptrtoint ptr %79 to i64
  %81 = cmpxchg ptr %72, i64 %80, i64 %77 release monotonic, align 8
  %82 = extractvalue { i64, i1 } %81, 1
  %83 = extractvalue { i64, i1 } %81, 0
  %84 = inttoptr i64 %83 to ptr
  %85 = select i1 %82, ptr %79, ptr %84
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !24
  %86 = icmp eq ptr %79, %85
  br i1 %86, label %87, label %78, !llvm.loop !25

87:                                               ; preds = %78
  %88 = getelementptr inbounds nuw i8, ptr %72, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !28
  %89 = atomicrmw add ptr %88, i64 1 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !29
  br label %90

90:                                               ; preds = %57, %66, %87
  %91 = phi ptr [ %62, %87 ], [ %62, %66 ], [ null, %57 ]
  %92 = icmp eq ptr %91, null
  br i1 %92, label %93, label %116

93:                                               ; preds = %90
  %94 = call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #13
  store i64 %39, ptr %94, align 8, !tbaa !69
  %95 = call noalias dereferenceable_or_null(48) ptr @malloc(i64 noundef 48) #13
  %96 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef %3, i64 noundef %39)
  store ptr %94, ptr %95, align 8, !tbaa !65
  %97 = getelementptr inbounds nuw i8, ptr %95, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !71
  store atomic i64 0, ptr %97 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !72
  %98 = ptrtoint ptr %95 to i64
  br label %99

99:                                               ; preds = %113, %93
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %100 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  %101 = inttoptr i64 %100 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %102 = getelementptr inbounds nuw i8, ptr %101, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %103 = load atomic i64, ptr %102 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %104 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %105 = icmp eq i64 %100, %104
  br i1 %105, label %106, label %113

106:                                              ; preds = %99
  %107 = icmp eq i64 %103, 0
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12
  br i1 %107, label %108, label %111

108:                                              ; preds = %106
  %109 = cmpxchg ptr %102, i64 0, i64 %98 seq_cst seq_cst, align 8
  %110 = extractvalue { i64, i1 } %109, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !64
  br i1 %110, label %114, label %113

111:                                              ; preds = %106
  %112 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %100, i64 %103 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !64
  br label %113

113:                                              ; preds = %111, %108, %99
  br label %99, !llvm.loop !73

114:                                              ; preds = %108
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !63
  %115 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %100, i64 %98 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !64
  br label %119

116:                                              ; preds = %90
  %117 = load i64, ptr %91, align 8, !tbaa !69
  %118 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %3, i64 noundef %117)
  call void @free(ptr noundef %91) #12
  br label %119

119:                                              ; preds = %116, %114
  %120 = load i32, ptr %8, align 8, !tbaa !54
  %121 = icmp eq i32 %120, 1
  br i1 %121, label %122, label %123

122:                                              ; preds = %119
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !61
  store atomic i64 0, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !62
  br label %123

123:                                              ; preds = %119, %122
  %124 = load i32, ptr %8, align 8, !tbaa !54
  %125 = add i32 %124, -1
  store i32 %125, ptr %8, align 8, !tbaa !54
  %126 = add nuw nsw i64 %39, 1
  %127 = icmp eq i64 %126, 10000
  br i1 %127, label %21, label %38, !llvm.loop !74

128:                                              ; preds = %33, %5
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #12
  ret ptr null
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #4 {
  %1 = alloca %struct.smr_lock_lib_s, align 8
  %2 = alloca [12 x i64], align 16
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %2) #12
  %3 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @g_lock, ptr noundef null) #12
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %1)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %1, ptr noundef nonnull align 8 dereferenceable(24) @g_lock_lib, i64 24, i1 false)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), i8 0, i64 16, i1 false)
  br label %4

4:                                                ; preds = %4, %0
  %5 = phi i64 [ 0, %0 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !75
  store atomic i64 0, ptr %6 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !76
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !52
  store atomic i64 0, ptr %7 seq_cst, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !53
  %8 = add nuw nsw i64 %5, 1
  %9 = icmp eq i64 %8, 3
  br i1 %9, label %10, label %4, !llvm.loop !77

10:                                               ; preds = %4
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !52
  store atomic i64 1, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !53
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), ptr noundef nonnull readonly align 8 dereferenceable(24) %1, i64 24, i1 false), !tbaa.struct !78
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %1)
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), align 8, !tbaa !80
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !71
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 24) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !72
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !71
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr @g_queue monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !72
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !71
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !72
  br label %11

11:                                               ; preds = %10, %11
  %12 = phi i64 [ 0, %10 ], [ %16, %11 ]
  %13 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %12
  %14 = inttoptr i64 %12 to ptr
  %15 = call i32 @pthread_create(ptr noundef nonnull %13, ptr noundef null, ptr noundef nonnull @run, ptr noundef %14) #12
  %16 = add nuw nsw i64 %12, 1
  %17 = icmp eq i64 %16, 12
  br i1 %17, label %21, label %11, !llvm.loop !82

18:                                               ; preds = %21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !83
  store atomic i8 1, ptr @g_stop seq_cst, align 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !84
  %19 = load i64, ptr %2, align 16, !tbaa !85
  %20 = call i32 @pthread_join(i64 noundef %19, ptr noundef null) #12
  br label %28

21:                                               ; preds = %11, %21
  %22 = phi i64 [ %26, %21 ], [ 1, %11 ]
  %23 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %22
  %24 = load i64, ptr %23, align 8, !tbaa !85
  %25 = call i32 @pthread_join(i64 noundef %24, ptr noundef null) #12
  %26 = add nuw nsw i64 %22, 1
  %27 = icmp eq i64 %26, 12
  br i1 %27, label %18, label %21, !llvm.loop !86

28:                                               ; preds = %54, %18
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %29 = load atomic i64, ptr @g_queue seq_cst, align 8
  %30 = inttoptr i64 %29 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %31 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %32 = getelementptr inbounds nuw i8, ptr %30, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %33 = load atomic i64, ptr %32 seq_cst, align 8
  %34 = inttoptr i64 %33 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %35 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %36 = icmp eq i64 %29, %35
  br i1 %36, label %37, label %54

37:                                               ; preds = %28
  %38 = icmp eq i64 %29, %31
  br i1 %38, label %39, label %43

39:                                               ; preds = %37
  %40 = icmp eq i64 %33, 0
  br i1 %40, label %50, label %41

41:                                               ; preds = %39
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !63
  %42 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %31, i64 %33 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !64
  br label %54

43:                                               ; preds = %37
  %44 = load ptr, ptr %34, align 8, !tbaa !65
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !63
  %45 = cmpxchg ptr @g_queue, i64 %29, i64 %33 seq_cst seq_cst, align 8
  %46 = extractvalue { i64, i1 } %45, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !64
  br i1 %46, label %47, label %54

47:                                               ; preds = %43
  %48 = icmp eq i64 %29, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %48, label %50, label %49

49:                                               ; preds = %47
  call void @free(ptr noundef %30) #12
  br label %50

50:                                               ; preds = %39, %47, %49
  %51 = phi ptr [ %44, %49 ], [ %44, %47 ], [ null, %39 ]
  %52 = icmp eq ptr %51, null
  br i1 %52, label %55, label %53

53:                                               ; preds = %50
  call void @free(ptr noundef %51) #12
  br label %54

54:                                               ; preds = %53, %43, %41, %28
  br label %28, !llvm.loop !68

55:                                               ; preds = %50
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %56 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %67, label %58

58:                                               ; preds = %55, %65
  %59 = phi i64 [ %62, %65 ], [ %56, %55 ]
  %60 = inttoptr i64 %59 to ptr
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !20
  %62 = load atomic i64, ptr %61 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !21
  %63 = icmp eq i64 %59, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %63, label %65, label %64

64:                                               ; preds = %58
  call void @free(ptr noundef nonnull %60) #12
  br label %65

65:                                               ; preds = %64, %58
  %66 = icmp eq i64 %62, 0
  br i1 %66, label %67, label %58, !llvm.loop !87

67:                                               ; preds = %65, %55
  br label %68

68:                                               ; preds = %67, %84
  %69 = phi i64 [ %85, %84 ], [ 0, %67 ]
  %70 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %69
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !32
  %71 = atomicrmw xchg ptr %70, i64 0 acquire, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !33
  %72 = getelementptr inbounds nuw i8, ptr %70, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !34
  store atomic i64 0, ptr %72 monotonic, align 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #12, !srcloc !35
  %73 = icmp eq i64 %71, 0
  br i1 %73, label %84, label %74

74:                                               ; preds = %68
  %75 = inttoptr i64 %71 to ptr
  br label %76

76:                                               ; preds = %76, %74
  %77 = phi ptr [ %78, %76 ], [ %75, %74 ]
  %78 = load ptr, ptr %77, align 8, !tbaa !19
  %79 = getelementptr inbounds nuw i8, ptr %77, i64 16
  %80 = load ptr, ptr %79, align 8, !tbaa !10
  %81 = getelementptr inbounds nuw i8, ptr %77, i64 24
  %82 = load ptr, ptr %81, align 8, !tbaa !18
  call void %80(ptr noundef nonnull %77, ptr noundef %82) #12
  %83 = icmp eq ptr %78, null
  br i1 %83, label %84, label %76, !llvm.loop !50

84:                                               ; preds = %76, %68
  %85 = add nuw nsw i64 %69, 1
  %86 = icmp eq i64 %85, 3
  br i1 %86, label %87, label %68, !llvm.loop !88

87:                                               ; preds = %84
  %88 = call i32 @pthread_mutex_destroy(ptr noundef nonnull @g_lock) #12
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %2) #12
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nounwind
declare i32 @pthread_mutex_destroy(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #11

attributes #0 = { inlinehint nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #1 = { mustprogress nounwind willreturn uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #4 = { nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #6 = { nofree nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #8 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #9 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind }
attributes #13 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{i64 2147990138}
!7 = !{i64 2147990178}
!8 = !{i64 2147991076}
!9 = !{i64 2147991116}
!10 = !{!11, !14, i64 16}
!11 = !{!"smr_node_s", !12, i64 0, !17, i64 8, !14, i64 16, !14, i64 24}
!12 = !{!"smr_node_core_s", !13, i64 0}
!13 = !{!"p1 _ZTS15smr_node_core_s", !14, i64 0}
!14 = !{!"any pointer", !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C/C++ TBAA"}
!17 = !{!"int", !15, i64 0}
!18 = !{!11, !14, i64 24}
!19 = !{!11, !13, i64 0}
!20 = !{i64 2147991544}
!21 = !{i64 2147991584}
!22 = !{!12, !13, i64 0}
!23 = !{i64 2147996814}
!24 = !{i64 2147996856}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.mustprogress"}
!27 = !{!"llvm.loop.unroll.disable"}
!28 = !{i64 2148002824}
!29 = !{i64 2148002864}
!30 = !{i64 2147990374}
!31 = !{i64 2147990414}
!32 = !{i64 2147994820}
!33 = !{i64 2147994860}
!34 = !{i64 2147992636}
!35 = !{i64 2147992676}
!36 = !{!37, !14, i64 72}
!37 = !{!"vebr_s", !38, i64 0, !15, i64 8, !40, i64 56, !42, i64 72}
!38 = !{!"vatomic64_s", !39, i64 0}
!39 = !{!"long", !15, i64 0}
!40 = !{!"dbl_list_s", !41, i64 0, !39, i64 8}
!41 = !{!"p1 _ZTS15dbl_list_node_s", !14, i64 0}
!42 = !{!"smr_lock_lib_s", !14, i64 0, !14, i64 8, !14, i64 16}
!43 = !{!37, !14, i64 88}
!44 = !{!41, !41, i64 0}
!45 = distinct !{!45, !27}
!46 = distinct !{!46, !26, !27}
!47 = !{!37, !14, i64 80}
!48 = !{i64 2147996014}
!49 = !{i64 2147996056}
!50 = distinct !{!50, !26, !27}
!51 = distinct !{!51, !26, !27}
!52 = !{i64 2147992480}
!53 = !{i64 2147992520}
!54 = !{!55, !17, i64 24}
!55 = !{!"vebr_instance_s", !56, i64 0, !38, i64 16, !17, i64 24}
!56 = !{!"dbl_list_node_s", !41, i64 0, !41, i64 8}
!57 = !{!40, !41, i64 0}
!58 = !{!56, !41, i64 0}
!59 = !{!56, !41, i64 8}
!60 = !{!40, !39, i64 8}
!61 = !{i64 2147992558}
!62 = !{i64 2147992598}
!63 = !{i64 2147996654}
!64 = !{i64 2147996696}
!65 = !{!66, !14, i64 0}
!66 = !{!"vqueue_ub_node_s", !14, i64 0, !67, i64 8, !11, i64 16}
!67 = !{!"vatomicptr_s", !14, i64 0}
!68 = distinct !{!68, !27}
!69 = !{!70, !39, i64 0}
!70 = !{!"data_s", !39, i64 0}
!71 = !{i64 2147993104}
!72 = !{i64 2147993144}
!73 = distinct !{!73, !27}
!74 = distinct !{!74, !26, !27}
!75 = !{i64 2147992948}
!76 = !{i64 2147992988}
!77 = distinct !{!77, !26, !27}
!78 = !{i64 0, i64 8, !79, i64 8, i64 8, !79, i64 16, i64 8, !79}
!79 = !{!14, !14, i64 0}
!80 = !{!81, !14, i64 16}
!81 = !{!"vqueue_ub_s", !67, i64 0, !67, i64 8, !66, i64 16}
!82 = distinct !{!82, !26, !27}
!83 = !{i64 2147991778}
!84 = !{i64 2147991818}
!85 = !{!39, !39, i64 0}
!86 = distinct !{!86, !26, !27}
!87 = distinct !{!87, !26, !27}
!88 = distinct !{!88, !26, !27}
