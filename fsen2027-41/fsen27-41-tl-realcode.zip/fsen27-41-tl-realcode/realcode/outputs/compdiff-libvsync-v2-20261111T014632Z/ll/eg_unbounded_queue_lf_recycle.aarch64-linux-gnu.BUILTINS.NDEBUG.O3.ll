; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, [112 x i8], %struct.vqueue_ub_node_s }
%struct.vatomicptr_s = type { ptr }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, [112 x i8] }

@local_pools = local_unnamed_addr global [12 x ptr] zeroinitializer, align 8
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 128
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@str = private unnamed_addr constant [15 x i8] c"New allocation\00", align 1
@str.4 = private unnamed_addr constant [19 x i8] c"Recycle allocation\00", align 1

; Function Attrs: nounwind uwtable
define void @destroy_pools() local_unnamed_addr #0 {
  %1 = load ptr, ptr @local_pools, align 8, !tbaa !6
  %2 = icmp eq ptr %1, null
  br i1 %2, label %10, label %3

3:                                                ; preds = %0, %3
  %4 = phi ptr [ %8, %3 ], [ %1, %0 ]
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %6 = load atomic i64, ptr %5 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %7 = and i64 %6, -128
  %8 = inttoptr i64 %7 to ptr
  tail call void @free(ptr noundef nonnull %4) #10
  %9 = icmp eq i64 %7, 0
  br i1 %9, label %10, label %3, !llvm.loop !13

10:                                               ; preds = %3, %0
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 8), align 8, !tbaa !6
  %12 = icmp eq ptr %11, null
  br i1 %12, label %20, label %13

13:                                               ; preds = %10, %13
  %14 = phi ptr [ %18, %13 ], [ %11, %10 ]
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %16 = load atomic i64, ptr %15 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %17 = and i64 %16, -128
  %18 = inttoptr i64 %17 to ptr
  tail call void @free(ptr noundef nonnull %14) #10
  %19 = icmp eq i64 %17, 0
  br i1 %19, label %20, label %13, !llvm.loop !13

20:                                               ; preds = %13, %10
  %21 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 16), align 8, !tbaa !6
  %22 = icmp eq ptr %21, null
  br i1 %22, label %30, label %23

23:                                               ; preds = %20, %23
  %24 = phi ptr [ %28, %23 ], [ %21, %20 ]
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %26 = load atomic i64, ptr %25 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %27 = and i64 %26, -128
  %28 = inttoptr i64 %27 to ptr
  tail call void @free(ptr noundef nonnull %24) #10
  %29 = icmp eq i64 %27, 0
  br i1 %29, label %30, label %23, !llvm.loop !13

30:                                               ; preds = %23, %20
  %31 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 24), align 8, !tbaa !6
  %32 = icmp eq ptr %31, null
  br i1 %32, label %40, label %33

33:                                               ; preds = %30, %33
  %34 = phi ptr [ %38, %33 ], [ %31, %30 ]
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %36 = load atomic i64, ptr %35 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %37 = and i64 %36, -128
  %38 = inttoptr i64 %37 to ptr
  tail call void @free(ptr noundef nonnull %34) #10
  %39 = icmp eq i64 %37, 0
  br i1 %39, label %40, label %33, !llvm.loop !13

40:                                               ; preds = %33, %30
  %41 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 32), align 8, !tbaa !6
  %42 = icmp eq ptr %41, null
  br i1 %42, label %50, label %43

43:                                               ; preds = %40, %43
  %44 = phi ptr [ %48, %43 ], [ %41, %40 ]
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %46 = load atomic i64, ptr %45 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %47 = and i64 %46, -128
  %48 = inttoptr i64 %47 to ptr
  tail call void @free(ptr noundef nonnull %44) #10
  %49 = icmp eq i64 %47, 0
  br i1 %49, label %50, label %43, !llvm.loop !13

50:                                               ; preds = %43, %40
  %51 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 40), align 8, !tbaa !6
  %52 = icmp eq ptr %51, null
  br i1 %52, label %60, label %53

53:                                               ; preds = %50, %53
  %54 = phi ptr [ %58, %53 ], [ %51, %50 ]
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %56 = load atomic i64, ptr %55 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %57 = and i64 %56, -128
  %58 = inttoptr i64 %57 to ptr
  tail call void @free(ptr noundef nonnull %54) #10
  %59 = icmp eq i64 %57, 0
  br i1 %59, label %60, label %53, !llvm.loop !13

60:                                               ; preds = %53, %50
  %61 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 48), align 8, !tbaa !6
  %62 = icmp eq ptr %61, null
  br i1 %62, label %70, label %63

63:                                               ; preds = %60, %63
  %64 = phi ptr [ %68, %63 ], [ %61, %60 ]
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %66 = load atomic i64, ptr %65 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %67 = and i64 %66, -128
  %68 = inttoptr i64 %67 to ptr
  tail call void @free(ptr noundef nonnull %64) #10
  %69 = icmp eq i64 %67, 0
  br i1 %69, label %70, label %63, !llvm.loop !13

70:                                               ; preds = %63, %60
  %71 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 56), align 8, !tbaa !6
  %72 = icmp eq ptr %71, null
  br i1 %72, label %80, label %73

73:                                               ; preds = %70, %73
  %74 = phi ptr [ %78, %73 ], [ %71, %70 ]
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %76 = load atomic i64, ptr %75 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %77 = and i64 %76, -128
  %78 = inttoptr i64 %77 to ptr
  tail call void @free(ptr noundef nonnull %74) #10
  %79 = icmp eq i64 %77, 0
  br i1 %79, label %80, label %73, !llvm.loop !13

80:                                               ; preds = %73, %70
  %81 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 64), align 8, !tbaa !6
  %82 = icmp eq ptr %81, null
  br i1 %82, label %90, label %83

83:                                               ; preds = %80, %83
  %84 = phi ptr [ %88, %83 ], [ %81, %80 ]
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %86 = load atomic i64, ptr %85 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %87 = and i64 %86, -128
  %88 = inttoptr i64 %87 to ptr
  tail call void @free(ptr noundef nonnull %84) #10
  %89 = icmp eq i64 %87, 0
  br i1 %89, label %90, label %83, !llvm.loop !13

90:                                               ; preds = %83, %80
  %91 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 72), align 8, !tbaa !6
  %92 = icmp eq ptr %91, null
  br i1 %92, label %100, label %93

93:                                               ; preds = %90, %93
  %94 = phi ptr [ %98, %93 ], [ %91, %90 ]
  %95 = getelementptr inbounds nuw i8, ptr %94, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %96 = load atomic i64, ptr %95 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %97 = and i64 %96, -128
  %98 = inttoptr i64 %97 to ptr
  tail call void @free(ptr noundef nonnull %94) #10
  %99 = icmp eq i64 %97, 0
  br i1 %99, label %100, label %93, !llvm.loop !13

100:                                              ; preds = %93, %90
  %101 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 80), align 8, !tbaa !6
  %102 = icmp eq ptr %101, null
  br i1 %102, label %110, label %103

103:                                              ; preds = %100, %103
  %104 = phi ptr [ %108, %103 ], [ %101, %100 ]
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %106 = load atomic i64, ptr %105 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %107 = and i64 %106, -128
  %108 = inttoptr i64 %107 to ptr
  tail call void @free(ptr noundef nonnull %104) #10
  %109 = icmp eq i64 %107, 0
  br i1 %109, label %110, label %103, !llvm.loop !13

110:                                              ; preds = %103, %100
  %111 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @local_pools, i64 88), align 8, !tbaa !6
  %112 = icmp eq ptr %111, null
  br i1 %112, label %120, label %113

113:                                              ; preds = %110, %113
  %114 = phi ptr [ %118, %113 ], [ %111, %110 ]
  %115 = getelementptr inbounds nuw i8, ptr %114, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %116 = load atomic i64, ptr %115 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %117 = and i64 %116, -128
  %118 = inttoptr i64 %117 to ptr
  tail call void @free(ptr noundef nonnull %114) #10
  %119 = icmp eq i64 %117, 0
  br i1 %119, label %120, label %113, !llvm.loop !13

120:                                              ; preds = %113, %110
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #3 {
  tail call void @free(ptr noundef %0) #10
  ret void
}

; Function Attrs: nounwind uwtable
define void @retire_cb(ptr noundef %0, ptr noundef %1) local_unnamed_addr #0 {
  %3 = ptrtoint ptr %1 to i64
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %5 = load atomic i64, ptr %4 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %6 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %3
  %7 = load ptr, ptr %6, align 8, !tbaa !6
  %8 = add i64 %5, 1
  %9 = ptrtoint ptr %7 to i64
  %10 = and i64 %8, 127
  %11 = or i64 %10, %9
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !15
  store atomic i64 %11, ptr %4 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !16
  store ptr %0, ptr %6, align 8, !tbaa !6
  ret void
}

; Function Attrs: nounwind uwtable
define ptr @alloc_qnode(i64 noundef %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %0
  %3 = load ptr, ptr %2, align 8, !tbaa !6
  %4 = icmp eq ptr %3, null
  br i1 %4, label %10, label %5

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %7 = load atomic i64, ptr %6 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %8 = and i64 %7, -128
  %9 = inttoptr i64 %8 to ptr
  store ptr %9, ptr %2, align 8, !tbaa !6
  br label %12

10:                                               ; preds = %1
  %11 = tail call noalias align 128 dereferenceable_or_null(128) ptr @memalign(i64 noundef 128, i64 noundef 128) #11
  br label %12

12:                                               ; preds = %10, %5
  %13 = phi ptr [ @str, %10 ], [ @str.4, %5 ]
  %14 = phi ptr [ %11, %10 ], [ %3, %5 ]
  %15 = tail call i32 @puts(ptr nonnull dereferenceable(1) %13)
  ret ptr %14
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @memalign(i64 allocalign noundef, i64 noundef) local_unnamed_addr #5

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #0 {
  %2 = ptrtoint ptr %0 to i64
  %3 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %2
  br label %4

4:                                                ; preds = %1, %110
  %5 = phi i64 [ 0, %1 ], [ %111, %110 ]
  br label %7

6:                                                ; preds = %110
  ret ptr null

7:                                                ; preds = %40, %4
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %8 = load atomic i64, ptr @g_queue seq_cst, align 128
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %9 = and i64 %8, -128
  %10 = inttoptr i64 %9 to ptr
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %11 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %12 = getelementptr inbounds nuw i8, ptr %10, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %13 = load atomic i64, ptr %12 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %14 = and i64 %13, -128
  %15 = inttoptr i64 %14 to ptr
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %16 = load atomic i64, ptr @g_queue seq_cst, align 128
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %17 = and i64 %16, -128
  %18 = icmp eq i64 %9, %17
  %19 = xor i64 %16, %8
  %20 = and i64 %19, 127
  %21 = icmp eq i64 %20, 0
  %22 = select i1 %18, i1 %21, i1 false
  br i1 %22, label %23, label %40

23:                                               ; preds = %7
  %24 = and i64 %11, -128
  %25 = icmp eq i64 %9, %24
  br i1 %25, label %26, label %33

26:                                               ; preds = %23
  %27 = icmp eq i64 %14, 0
  br i1 %27, label %53, label %28

28:                                               ; preds = %26
  %29 = add i64 %11, 1
  %30 = and i64 %29, 127
  %31 = or disjoint i64 %14, %30
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !17
  %32 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %11, i64 %31 seq_cst seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !18
  br label %40

33:                                               ; preds = %23
  %34 = load ptr, ptr %15, align 128, !tbaa !19
  %35 = add i64 %8, 1
  %36 = and i64 %35, 127
  %37 = or disjoint i64 %14, %36
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !17
  %38 = cmpxchg ptr @g_queue, i64 %8, i64 %37 seq_cst seq_cst, align 8
  %39 = extractvalue { i64, i1 } %38, 1
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !18
  br i1 %39, label %41, label %40

40:                                               ; preds = %33, %28, %7
  br label %7

41:                                               ; preds = %33
  %42 = icmp eq i64 %9, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %42, label %51, label %43

43:                                               ; preds = %41
  %44 = getelementptr inbounds nuw i8, ptr %10, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %45 = load atomic i64, ptr %44 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %46 = load ptr, ptr %3, align 8, !tbaa !6
  %47 = add i64 %45, 1
  %48 = ptrtoint ptr %46 to i64
  %49 = and i64 %47, 127
  %50 = or i64 %49, %48
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !15
  store atomic i64 %50, ptr %44 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !16
  store ptr %10, ptr %3, align 8, !tbaa !6
  br label %51

51:                                               ; preds = %41, %43
  %52 = icmp eq ptr %34, null
  br i1 %52, label %53, label %107

53:                                               ; preds = %26, %51
  %54 = tail call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #12
  store i64 %5, ptr %54, align 8, !tbaa !22
  %55 = load ptr, ptr %3, align 8, !tbaa !6
  %56 = icmp eq ptr %55, null
  br i1 %56, label %62, label %57

57:                                               ; preds = %53
  %58 = getelementptr inbounds nuw i8, ptr %55, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %59 = load atomic i64, ptr %58 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %60 = and i64 %59, -128
  %61 = inttoptr i64 %60 to ptr
  store ptr %61, ptr %3, align 8, !tbaa !6
  br label %64

62:                                               ; preds = %53
  %63 = tail call noalias align 128 dereferenceable_or_null(128) ptr @memalign(i64 noundef 128, i64 noundef 128) #11
  br label %64

64:                                               ; preds = %57, %62
  %65 = phi ptr [ @str, %62 ], [ @str.4, %57 ]
  %66 = phi ptr [ %63, %62 ], [ %55, %57 ]
  %67 = tail call i32 @puts(ptr nonnull dereferenceable(1) %65)
  %68 = load i64, ptr %54, align 8, !tbaa !22
  %69 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %2, i64 noundef %68)
  store ptr %54, ptr %66, align 128, !tbaa !19
  %70 = getelementptr inbounds nuw i8, ptr %66, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %71 = load atomic i64, ptr %70 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %72 = and i64 %71, 127
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !15
  store atomic i64 %72, ptr %70 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !16
  %73 = ptrtoint ptr %66 to i64
  br label %74

74:                                               ; preds = %101, %64
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %75 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %76 = and i64 %75, -128
  %77 = inttoptr i64 %76 to ptr
  %78 = getelementptr inbounds nuw i8, ptr %77, i64 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %79 = load atomic i64, ptr %78 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %80 = and i64 %79, -128
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %81 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %82 = and i64 %81, -128
  %83 = icmp eq i64 %76, %82
  %84 = xor i64 %81, %75
  %85 = and i64 %84, 127
  %86 = icmp eq i64 %85, 0
  %87 = select i1 %83, i1 %86, i1 false
  br i1 %87, label %88, label %101

88:                                               ; preds = %74
  %89 = icmp eq i64 %80, 0
  tail call void asm sideeffect "", "~{memory}"() #10
  br i1 %89, label %90, label %96

90:                                               ; preds = %88
  %91 = add nuw nsw i64 %79, 1
  %92 = and i64 %91, 127
  %93 = or i64 %92, %73
  %94 = cmpxchg ptr %78, i64 %79, i64 %93 seq_cst seq_cst, align 8
  %95 = extractvalue { i64, i1 } %94, 1
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !18
  br i1 %95, label %102, label %101

96:                                               ; preds = %88
  %97 = add i64 %75, 1
  %98 = and i64 %97, 127
  %99 = or disjoint i64 %80, %98
  %100 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %75, i64 %99 seq_cst seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !18
  br label %101

101:                                              ; preds = %96, %90, %74
  br label %74

102:                                              ; preds = %90
  %103 = add i64 %75, 1
  %104 = and i64 %103, 127
  %105 = or i64 %104, %73
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !17
  %106 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %75, i64 %105 seq_cst seq_cst, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !18
  br label %110

107:                                              ; preds = %51
  %108 = load i64, ptr %34, align 8, !tbaa !22
  %109 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.3, i64 noundef %2, i64 noundef %108)
  tail call void @free(ptr noundef nonnull %34) #10
  br label %110

110:                                              ; preds = %102, %107
  %111 = add nuw nsw i64 %5, 1
  %112 = icmp eq i64 %111, 100
  br i1 %112, label %6, label %4, !llvm.loop !25
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [12 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #10
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !26
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 136) monotonic, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !27
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !26
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64), ptr @g_queue monotonic, align 128
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !27
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !26
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64), ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) monotonic, align 8
  tail call void asm sideeffect "", "~{memory}"() #10, !srcloc !27
  %2 = call i32 @pthread_create(ptr noundef nonnull %1, ptr noundef null, ptr noundef nonnull @run, ptr noundef null) #10
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %4 = call i32 @pthread_create(ptr noundef nonnull %3, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 1 to ptr)) #10
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %6 = call i32 @pthread_create(ptr noundef nonnull %5, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 2 to ptr)) #10
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %8 = call i32 @pthread_create(ptr noundef nonnull %7, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 3 to ptr)) #10
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %10 = call i32 @pthread_create(ptr noundef nonnull %9, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 4 to ptr)) #10
  %11 = getelementptr inbounds nuw i8, ptr %1, i64 40
  %12 = call i32 @pthread_create(ptr noundef nonnull %11, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 5 to ptr)) #10
  %13 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %14 = call i32 @pthread_create(ptr noundef nonnull %13, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 6 to ptr)) #10
  %15 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %16 = call i32 @pthread_create(ptr noundef nonnull %15, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 7 to ptr)) #10
  %17 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %18 = call i32 @pthread_create(ptr noundef nonnull %17, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 8 to ptr)) #10
  %19 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %20 = call i32 @pthread_create(ptr noundef nonnull %19, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 9 to ptr)) #10
  %21 = getelementptr inbounds nuw i8, ptr %1, i64 80
  %22 = call i32 @pthread_create(ptr noundef nonnull %21, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 10 to ptr)) #10
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 88
  %24 = call i32 @pthread_create(ptr noundef nonnull %23, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 11 to ptr)) #10
  %25 = load i64, ptr %1, align 8, !tbaa !28
  %26 = call i32 @pthread_join(i64 noundef %25, ptr noundef null) #10
  %27 = load i64, ptr %3, align 8, !tbaa !28
  %28 = call i32 @pthread_join(i64 noundef %27, ptr noundef null) #10
  %29 = load i64, ptr %5, align 8, !tbaa !28
  %30 = call i32 @pthread_join(i64 noundef %29, ptr noundef null) #10
  %31 = load i64, ptr %7, align 8, !tbaa !28
  %32 = call i32 @pthread_join(i64 noundef %31, ptr noundef null) #10
  %33 = load i64, ptr %9, align 8, !tbaa !28
  %34 = call i32 @pthread_join(i64 noundef %33, ptr noundef null) #10
  %35 = load i64, ptr %11, align 8, !tbaa !28
  %36 = call i32 @pthread_join(i64 noundef %35, ptr noundef null) #10
  %37 = load i64, ptr %13, align 8, !tbaa !28
  %38 = call i32 @pthread_join(i64 noundef %37, ptr noundef null) #10
  %39 = load i64, ptr %15, align 8, !tbaa !28
  %40 = call i32 @pthread_join(i64 noundef %39, ptr noundef null) #10
  %41 = load i64, ptr %17, align 8, !tbaa !28
  %42 = call i32 @pthread_join(i64 noundef %41, ptr noundef null) #10
  %43 = load i64, ptr %19, align 8, !tbaa !28
  %44 = call i32 @pthread_join(i64 noundef %43, ptr noundef null) #10
  %45 = load i64, ptr %21, align 8, !tbaa !28
  %46 = call i32 @pthread_join(i64 noundef %45, ptr noundef null) #10
  %47 = load i64, ptr %23, align 8, !tbaa !28
  %48 = call i32 @pthread_join(i64 noundef %47, ptr noundef null) #10
  br label %49

49:                                               ; preds = %88, %0
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %50 = load atomic i64, ptr @g_queue seq_cst, align 128
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %51 = and i64 %50, -128
  %52 = inttoptr i64 %51 to ptr
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %53 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %54 = getelementptr inbounds nuw i8, ptr %52, i64 8
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %55 = load atomic i64, ptr %54 seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %56 = and i64 %55, -128
  %57 = inttoptr i64 %56 to ptr
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %58 = load atomic i64, ptr @g_queue seq_cst, align 128
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %59 = and i64 %58, -128
  %60 = icmp eq i64 %51, %59
  %61 = xor i64 %58, %50
  %62 = and i64 %61, 127
  %63 = icmp eq i64 %62, 0
  %64 = select i1 %60, i1 %63, i1 false
  br i1 %64, label %65, label %88

65:                                               ; preds = %49
  %66 = and i64 %53, -128
  %67 = icmp eq i64 %51, %66
  br i1 %67, label %68, label %75

68:                                               ; preds = %65
  %69 = icmp eq i64 %56, 0
  br i1 %69, label %89, label %70

70:                                               ; preds = %68
  %71 = add i64 %53, 1
  %72 = and i64 %71, 127
  %73 = or disjoint i64 %56, %72
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !17
  %74 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %53, i64 %73 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !18
  br label %88

75:                                               ; preds = %65
  %76 = load ptr, ptr %57, align 128, !tbaa !19
  %77 = add i64 %50, 1
  %78 = and i64 %77, 127
  %79 = or disjoint i64 %56, %78
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !17
  %80 = cmpxchg ptr @g_queue, i64 %50, i64 %79 seq_cst seq_cst, align 8
  %81 = extractvalue { i64, i1 } %80, 1
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !18
  br i1 %81, label %82, label %88

82:                                               ; preds = %75
  %83 = icmp eq i64 %51, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %83, label %85, label %84

84:                                               ; preds = %82
  call void @free(ptr noundef nonnull %52) #10
  br label %85

85:                                               ; preds = %82, %84
  %86 = icmp eq ptr %76, null
  br i1 %86, label %89, label %87

87:                                               ; preds = %85
  call void @free(ptr noundef nonnull %76) #10
  br label %88

88:                                               ; preds = %87, %75, %70, %49
  br label %49, !llvm.loop !29

89:                                               ; preds = %85, %68
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %90 = load atomic i64, ptr @g_queue seq_cst, align 128
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %91 = and i64 %90, -128
  %92 = icmp eq i64 %91, 0
  br i1 %92, label %103, label %93

93:                                               ; preds = %89, %100
  %94 = phi i64 [ %101, %100 ], [ %91, %89 ]
  %95 = inttoptr i64 %94 to ptr
  %96 = getelementptr inbounds nuw i8, ptr %95, i64 8
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !11
  %97 = load atomic i64, ptr %96 seq_cst, align 8
  call void asm sideeffect "", "~{memory}"() #10, !srcloc !12
  %98 = icmp eq i64 %94, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %98, label %100, label %99

99:                                               ; preds = %93
  call void @free(ptr noundef nonnull %95) #10
  br label %100

100:                                              ; preds = %99, %93
  %101 = and i64 %97, -128
  %102 = icmp eq i64 %101, 0
  br i1 %102, label %103, label %93, !llvm.loop !30

103:                                              ; preds = %100, %89
  call void @destroy_pools()
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #10
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #7

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #9

attributes #0 = { nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #3 = { mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #6 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #7 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #8 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #9 = { nofree nounwind }
attributes #10 = { nounwind }
attributes #11 = { nounwind allocsize(1) }
attributes #12 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{!7, !7, i64 0}
!7 = !{!"p1 _ZTS16vqueue_ub_node_s", !8, i64 0}
!8 = !{!"any pointer", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{i64 2147995026}
!12 = !{i64 2147995066}
!13 = distinct !{!13, !14}
!14 = !{!"llvm.loop.mustprogress"}
!15 = !{i64 2147996430}
!16 = !{i64 2147996470}
!17 = !{i64 2148000136}
!18 = !{i64 2148000178}
!19 = !{!20, !8, i64 0}
!20 = !{!"vqueue_ub_node_s", !8, i64 0, !21, i64 8}
!21 = !{!"vatomicptr_s", !8, i64 0}
!22 = !{!23, !24, i64 0}
!23 = !{!"data_s", !24, i64 0}
!24 = !{!"long", !9, i64 0}
!25 = distinct !{!25, !14}
!26 = !{i64 2147996586}
!27 = !{i64 2147996626}
!28 = !{!24, !24, i64 0}
!29 = distinct !{!29, !14}
!30 = distinct !{!30, !14}
