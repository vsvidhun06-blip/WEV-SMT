	.file	"eg_bitmap.c"
	.text
	.globl	reader                          // -- Begin function reader
	.p2align	2
	.type	reader,@function
reader:                                 // @reader
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x21, :got:g_bitmap
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
	b	.LBB0_2
.LBB0_1:                                //   in Loop: Header=BB0_2 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.hs	.LBB0_14
.LBB0_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_7 Depth 2
                                        //       Child Loop BB0_11 Depth 3
	ldr	x8, [x21]
	cbz	x8, .LBB0_15
// %bb.3:                               //   in Loop: Header=BB0_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, .LBB0_16
// %bb.4:                               //   in Loop: Header=BB0_2 Depth=1
	add	x10, x8, #16
	//APP
	ldar	x11, [x10]
	//NO_APP
	mov	x9, xzr
	mov	x13, xzr
	add	x10, x8, #24
	b	.LBB0_7
.LBB0_5:                                //   in Loop: Header=BB0_7 Depth=2
	mov	w12, wzr
	add	x13, x20, #1
	tbnz	w12, #0, .LBB0_7
	b	.LBB0_1
.LBB0_6:                                //   in Loop: Header=BB0_7 Depth=2
	mov	w12, #1                         // =0x1
	lsl	x13, x12, x13
	bic	x11, x11, x13
	add	x13, x20, #1
	tbz	w12, #0, .LBB0_1
.LBB0_7:                                //   Parent Loop BB0_2 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB0_11 Depth 3
	mov	x20, x13
	cbz	x11, .LBB0_9
.LBB0_8:                                //   in Loop: Header=BB0_7 Depth=2
	rbit	x12, x11
	ldr	x14, [x8, #8]
	clz	x13, x12
	orr	x12, x13, x9, lsl #6
	cmp	x12, x14
	b.lo	.LBB0_6
	b	.LBB0_5
.LBB0_9:                                //   in Loop: Header=BB0_7 Depth=2
	ldr	x13, [x8]
	add	x12, x9, #1
	cmp	x12, x13
	b.hs	.LBB0_5
// %bb.10:                              //   in Loop: Header=BB0_7 Depth=2
	add	x14, x10, x9, lsl #3
.LBB0_11:                               //   Parent Loop BB0_2 Depth=1
                                        //     Parent Loop BB0_7 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	//APP
	ldar	x11, [x14]
	//NO_APP
	cbnz	x11, .LBB0_13
// %bb.12:                              //   in Loop: Header=BB0_11 Depth=3
	add	x12, x12, #1
	add	x14, x14, #8
	cmp	x13, x12
	b.ne	.LBB0_11
	b	.LBB0_5
.LBB0_13:                               //   in Loop: Header=BB0_7 Depth=2
	mov	x9, x12
	b	.LBB0_8
.LBB0_14:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB0_15:
	.cfi_restore_state
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_iter_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_iter_init
	mov	w2, #314                        // =0x13a
	bl	__assert_fail
.LBB0_16:
	adrp	x0, .L.str.7
	add	x0, x0, :lo12:.L.str.7
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_iter_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_iter_init
	mov	w2, #316                        // =0x13c
	bl	__assert_fail
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        // -- End function
	.globl	writer                          // -- Begin function writer
	.p2align	2
	.type	writer,@function
writer:                                 // @writer
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x9, :got:g_bitmap
	ldr	x9, [x9, :got_lo12:g_bitmap]
	ldr	x11, [x9]
	cbz	x11, .LBB1_34
// %bb.1:
	lsl	x8, x0, #6
	ldr	x10, [x11, #8]
	orr	x12, x8, #0x3f
	cmp	x12, x10
	b.hs	.LBB1_35
// %bb.2:
	ldr	x12, [x11]
	and	x10, x0, #0x3ffffffffffffff
	cmp	x10, x12
	b.hs	.LBB1_36
// %bb.3:
	cmp	x10, x10
	b.ne	.LBB1_6
// %bb.4:
	cmp	x10, x12
	b.hs	.LBB1_33
// %bb.5:
	add	x11, x11, x10, lsl #3
	mov	x12, #-1                        // =0xffffffffffffffff
	add	x11, x11, #16
	//APP
	prfm	pstl1strm, [x11]
.Ltmp0:
	ldaxr	x13, [x11]
	orr	x14, x13, x12
	stlxr	w15, x14, [x11]
	cbnz	w15, .Ltmp0

	//NO_APP
	b	.LBB1_11
.LBB1_6:
	cmp	x10, x12
	b.hs	.LBB1_33
// %bb.7:
	add	x13, x11, #16
	mov	x14, #-1                        // =0xffffffffffffffff
	add	x12, x13, x10, lsl #3
	//APP
	prfm	pstl1strm, [x12]
.Ltmp1:
	ldaxr	x15, [x12]
	orr	x16, x15, x14
	stlxr	w17, x16, [x12]
	cbnz	w17, .Ltmp1

	//NO_APP
	add	x14, x10, #1
	cmp	x14, x10
	b.hs	.LBB1_9
// %bb.8:
	add	x13, x13, x14, lsl #3
	mov	x14, #-1                        // =0xffffffffffffffff
	//APP
	stlr	x14, [x13]
	//NO_APP
.LBB1_9:
	ldr	x11, [x11]
	cmp	x10, x11
	b.hs	.LBB1_33
// %bb.10:
	mov	x11, #-1                        // =0xffffffffffffffff
	//APP
	prfm	pstl1strm, [x12]
.Ltmp2:
	ldaxr	x13, [x12]
	orr	x14, x13, x11
	stlxr	w15, x14, [x12]
	cbnz	w15, .Ltmp2

	//NO_APP
.LBB1_11:
	ldr	x11, [x9]
	cbz	x11, .LBB1_30
// %bb.12:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_31
// %bb.13:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_32
// %bb.14:
	add	x11, x11, x10, lsl #3
	add	x11, x11, #16
	//APP
	ldar	x12, [x11]
	//NO_APP
	tbz	w12, #0, .LBB1_37
// %bb.15:
	ldr	x11, [x9]
	cbz	x11, .LBB1_38
// %bb.16:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_39
// %bb.17:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_40
// %bb.18:
	add	x11, x11, x10, lsl #3
	mov	x12, #-2                        // =0xfffffffffffffffe
	add	x11, x11, #16
	//APP
	prfm	pstl1strm, [x11]
.Ltmp3:
	ldaxr	x13, [x11]
	and	x14, x13, x12
	stlxr	w15, x14, [x11]
	cbnz	w15, .Ltmp3

	//NO_APP
	ldr	x11, [x9]
	cbz	x11, .LBB1_30
// %bb.19:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_31
// %bb.20:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_32
// %bb.21:
	add	x11, x11, x10, lsl #3
	add	x11, x11, #16
	//APP
	ldar	x12, [x11]
	//NO_APP
	tbnz	w12, #0, .LBB1_41
// %bb.22:
	ldr	x11, [x9]
	cbz	x11, .LBB1_42
// %bb.23:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_43
// %bb.24:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_44
// %bb.25:
	add	x11, x11, x10, lsl #3
	mov	w12, #1                         // =0x1
	add	x11, x11, #16
	//APP
	prfm	pstl1strm, [x11]
.Ltmp4:
	ldaxr	x13, [x11]
	orr	x14, x13, x12
	stlxr	w15, x14, [x11]
	cbnz	w15, .Ltmp4

	//NO_APP
	ldr	x9, [x9]
	cbz	x9, .LBB1_30
// %bb.26:
	ldr	x11, [x9, #8]
	cmp	x8, x11
	b.hs	.LBB1_31
// %bb.27:
	ldr	x8, [x9]
	cmp	x10, x8
	b.hs	.LBB1_32
// %bb.28:
	add	x8, x9, x10, lsl #3
	add	x8, x8, #16
	//APP
	ldar	x9, [x8]
	//NO_APP
	tbz	w9, #0, .LBB1_45
// %bb.29:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB1_30:
	.cfi_restore_state
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	mov	w2, #140                        // =0x8c
	bl	__assert_fail
.LBB1_31:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	mov	w2, #141                        // =0x8d
	bl	__assert_fail
.LBB1_32:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	mov	w2, #143                        // =0x8f
	bl	__assert_fail
.LBB1_33:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__._vbitbmap_set_slot
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__._vbitbmap_set_slot
	mov	w2, #176                        // =0xb0
	bl	__assert_fail
.LBB1_34:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	mov	w2, #214                        // =0xd6
	bl	__assert_fail
.LBB1_35:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	mov	w2, #216                        // =0xd8
	bl	__assert_fail
.LBB1_36:
	adrp	x0, .L.str.11
	add	x0, x0, :lo12:.L.str.11
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	mov	w2, #224                        // =0xe0
	bl	__assert_fail
.LBB1_37:
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	mov	w2, #44                         // =0x2c
	bl	__assert_fail
.LBB1_38:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	mov	w2, #297                        // =0x129
	bl	__assert_fail
.LBB1_39:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	mov	w2, #298                        // =0x12a
	bl	__assert_fail
.LBB1_40:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	mov	w2, #300                        // =0x12c
	bl	__assert_fail
.LBB1_41:
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	mov	w2, #48                         // =0x30
	bl	__assert_fail
.LBB1_42:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	mov	w2, #158                        // =0x9e
	bl	__assert_fail
.LBB1_43:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	mov	w2, #159                        // =0x9f
	bl	__assert_fail
.LBB1_44:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	mov	w2, #161                        // =0xa1
	bl	__assert_fail
.LBB1_45:
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	mov	w2, #52                         // =0x34
	bl	__assert_fail
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cmp	x0, #11
	b.eq	.LBB2_2
// %bb.1:
	bl	writer
	b	.LBB2_3
.LBB2_2:
	bl	reader
.LBB2_3:
	mov	x0, xzr
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	w0, #104                        // =0x68
	bl	malloc
	adrp	x22, :got:g_bitmap
	mov	w9, #704                        // =0x2c0
	mov	w10, #11                        // =0xb
	ldr	x22, [x22, :got_lo12:g_bitmap]
	mov	x8, xzr
	stp	x10, x9, [x0]
	add	x9, x0, #16
	mov	x10, xzr
	str	x0, [x22]
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	//APP
	stlr	x8, [x9]
	//NO_APP
	add	x10, x10, #1
	add	x9, x9, #8
	ldr	x11, [x0]
	cmp	x10, x11
	b.lo	.LBB3_1
// %bb.2:
	adrp	x20, :got:run
	mov	x19, xzr
	mov	x21, sp
	ldr	x20, [x20, :got_lo12:run]
.LBB3_3:                                // =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, xzr
	mov	x2, x20
	mov	x3, x19
	bl	pthread_create
	add	x19, x19, #1
	add	x21, x21, #8
	cmp	x19, #12
	b.ne	.LBB3_3
// %bb.4:
	mov	x19, xzr
	mov	x20, sp
.LBB3_5:                                // =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19]
	mov	x1, xzr
	bl	pthread_join
	add	x19, x19, #8
	cmp	x19, #96
	b.ne	.LBB3_5
// %bb.6:
	ldr	x0, [x22]
	bl	free
	mov	w0, wzr
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        // -- End function
	.type	g_bitmap,@object                // @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.xword	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"set == 1"
	.size	.L.str.1, 9

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"C:/rc1111/src/libvsync/examples/eg_bitmap.c"
	.size	.L.str.2, 44

	.type	.L__PRETTY_FUNCTION__.writer,@object // @__PRETTY_FUNCTION__.writer
.L__PRETTY_FUNCTION__.writer:
	.asciz	"void writer(vsize_t)"
	.size	.L__PRETTY_FUNCTION__.writer, 21

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"set == 0"
	.size	.L.str.3, 9

	.type	.L.str.4,@object                // @.str.4
.L.str.4:
	.asciz	"bitmap"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                // @.str.5
.L.str.5:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/bitmap/bitmap.h"
	.size	.L.str.5, 53

	.type	.L__PRETTY_FUNCTION__.vbitmap_iter_init,@object // @__PRETTY_FUNCTION__.vbitmap_iter_init
.L__PRETTY_FUNCTION__.vbitmap_iter_init:
	.asciz	"void vbitmap_iter_init(vbitmap_t *, vbitmap_iter_t *)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_iter_init, 54

	.type	.L.str.7,@object                // @.str.7
.L.str.7:
	.asciz	"bitmap->maps_cnt > 0"
	.size	.L.str.7, 21

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_range,@object // @__PRETTY_FUNCTION__.vbitmap_set_range
.L__PRETTY_FUNCTION__.vbitmap_set_range:
	.asciz	"void vbitmap_set_range(vbitmap_t *, vsize_t, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_range, 54

	.type	.L.str.9,@object                // @.str.9
.L.str.9:
	.asciz	"to < bitmap->bit_cnt"
	.size	.L.str.9, 21

	.type	.L.str.11,@object               // @.str.11
.L.str.11:
	.asciz	"msb_slot < bitmap->maps_cnt"
	.size	.L.str.11, 28

	.type	.L.str.12,@object               // @.str.12
.L.str.12:
	.asciz	"idx < bitmap->maps_cnt"
	.size	.L.str.12, 23

	.type	.L__PRETTY_FUNCTION__._vbitbmap_set_slot,@object // @__PRETTY_FUNCTION__._vbitbmap_set_slot
.L__PRETTY_FUNCTION__._vbitbmap_set_slot:
	.asciz	"void _vbitbmap_set_slot(vbitmap_t *, vsize_t, vuint64_t)"
	.size	.L__PRETTY_FUNCTION__._vbitbmap_set_slot, 57

	.type	.L__PRETTY_FUNCTION__.vbitmap_get,@object // @__PRETTY_FUNCTION__.vbitmap_get
.L__PRETTY_FUNCTION__.vbitmap_get:
	.asciz	"vbool_t vbitmap_get(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_get, 42

	.type	.L.str.13,@object               // @.str.13
.L.str.13:
	.asciz	"bit_idx < bitmap->bit_cnt"
	.size	.L.str.13, 26

	.type	.L__PRETTY_FUNCTION__.vbitmap_clr_bit,@object // @__PRETTY_FUNCTION__.vbitmap_clr_bit
.L__PRETTY_FUNCTION__.vbitmap_clr_bit:
	.asciz	"void vbitmap_clr_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_clr_bit, 43

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_bit,@object // @__PRETTY_FUNCTION__.vbitmap_set_bit
.L__PRETTY_FUNCTION__.vbitmap_set_bit:
	.asciz	"void vbitmap_set_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_bit, 43

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
