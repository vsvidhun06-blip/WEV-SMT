	.file	"eg_bitmap.c"
	.text
	.globl	reader                          # -- Begin function reader
	.p2align	4
	.type	reader,@function
reader:                                 # @reader
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	g_bitmap@GOTPCREL(%rip), %r15
	leaq	.L.str(%rip), %rbx
	jmp	.LBB0_2
	.p2align	4
.LBB0_1:                                #   in Loop: Header=BB0_2 Depth=1
	movl	$693, %edx                      # imm = 0x2B5
	movq	%rbx, %rdi
	movq	%r14, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	cmpq	$693, %r14                      # imm = 0x2B5
	jae	.LBB0_14
.LBB0_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_5 Depth 2
                                        #       Child Loop BB0_9 Depth 3
	movq	(%r15), %rax
	#APP
	#NO_APP
	movq	16(%rax), %rcx
	#APP
	#NO_APP
	xorl	%edx, %edx
	xorl	%edi, %edi
	jmp	.LBB0_5
	.p2align	4
.LBB0_12:                               #   in Loop: Header=BB0_5 Depth=2
	xorl	%esi, %esi
.LBB0_4:                                #   in Loop: Header=BB0_5 Depth=2
	leaq	1(%r14), %rdi
	testb	%sil, %sil
	je	.LBB0_1
.LBB0_5:                                #   Parent Loop BB0_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB0_9 Depth 3
	movq	%rdi, %r14
	testq	%rcx, %rcx
	je	.LBB0_8
.LBB0_6:                                #   in Loop: Header=BB0_5 Depth=2
	rep		bsfq	%rcx, %rsi
	movq	%rdx, %rdi
	shlq	$6, %rdi
	orq	%rsi, %rdi
	cmpq	8(%rax), %rdi
	jae	.LBB0_12
# %bb.3:                                #   in Loop: Header=BB0_5 Depth=2
	btrq	%rsi, %rcx
	movb	$1, %sil
	jmp	.LBB0_4
	.p2align	4
.LBB0_8:                                #   in Loop: Header=BB0_5 Depth=2
	movq	(%rax), %rdi
	leaq	1(%rdx), %rsi
	cmpq	%rdi, %rsi
	jae	.LBB0_12
	.p2align	4
.LBB0_9:                                #   Parent Loop BB0_2 Depth=1
                                        #     Parent Loop BB0_5 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	#APP
	#NO_APP
	movq	16(%rax,%rsi,8), %rcx
	#APP
	#NO_APP
	testq	%rcx, %rcx
	jne	.LBB0_13
# %bb.10:                               #   in Loop: Header=BB0_9 Depth=3
	addq	$1, %rsi
	cmpq	%rsi, %rdi
	jne	.LBB0_9
	jmp	.LBB0_12
.LBB0_13:                               #   in Loop: Header=BB0_5 Depth=2
	movq	%rsi, %rdx
	jmp	.LBB0_6
.LBB0_14:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        # -- End function
	.globl	writer                          # -- Begin function writer
	.p2align	4
	.type	writer,@function
writer:                                 # @writer
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movabsq	$288230376151711743, %rax       # imm = 0x3FFFFFFFFFFFFFF
	andq	%rdi, %rax
	movq	g_bitmap@GOTPCREL(%rip), %rcx
	movq	(%rcx), %rdx
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rdx,%rax,8)
	#APP
	#NO_APP
	movb	$1, %sil
	testb	%sil, %sil
	jne	.LBB1_3
# %bb.1:
	leaq	1(%rax), %rsi
	cmpq	%rax, %rsi
	jae	.LBB1_2
# %bb.4:
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 24(%rdx,%rax,8)
	#APP
	#NO_APP
.LBB1_2:
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rdx,%rax,8)
	#APP
	#NO_APP
.LBB1_3:
	movq	(%rcx), %rdx
	#APP
	#NO_APP
	movq	16(%rdx,%rax,8), %rdx
	#APP
	#NO_APP
	movq	(%rcx), %rdx
	#APP
	#NO_APP
	lock		andq	$-2, 16(%rdx,%rax,8)
	#APP
	#NO_APP
	movq	(%rcx), %rdx
	#APP
	#NO_APP
	movq	16(%rdx,%rax,8), %rdx
	#APP
	#NO_APP
	movq	(%rcx), %rdx
	#APP
	#NO_APP
	lock		orq	$1, 16(%rdx,%rax,8)
	#APP
	#NO_APP
	movq	(%rcx), %rcx
	#APP
	#NO_APP
	movq	16(%rcx,%rax,8), %rax
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$11, %rdi
	je	.LBB2_3
# %bb.1:
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	shlq	$3, %rdi
	movabsq	$2305843009213693944, %rdx      # imm = 0x1FFFFFFFFFFFFFF8
	andq	%rdi, %rdx
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	movq	16(%rcx,%rdx), %rcx
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	lock		andq	$-2, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	movq	16(%rcx,%rdx), %rcx
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	lock		orq	$1, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rax
	#APP
	#NO_APP
	movq	16(%rax,%rdx), %rax
	#APP
	#NO_APP
.LBB2_2:
	xorl	%eax, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB2_3:
	.cfi_def_cfa %rbp, 16
	movq	g_bitmap@GOTPCREL(%rip), %r15
	leaq	.L.str(%rip), %rbx
	jmp	.LBB2_5
	.p2align	4
.LBB2_4:                                #   in Loop: Header=BB2_5 Depth=1
	movl	$693, %edx                      # imm = 0x2B5
	movq	%rbx, %rdi
	movq	%r14, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	cmpq	$693, %r14                      # imm = 0x2B5
	jae	.LBB2_2
.LBB2_5:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_8 Depth 2
                                        #       Child Loop BB2_12 Depth 3
	movq	(%r15), %rax
	#APP
	#NO_APP
	movq	16(%rax), %rcx
	#APP
	#NO_APP
	xorl	%edx, %edx
	xorl	%edi, %edi
	jmp	.LBB2_8
	.p2align	4
.LBB2_15:                               #   in Loop: Header=BB2_8 Depth=2
	xorl	%esi, %esi
.LBB2_7:                                #   in Loop: Header=BB2_8 Depth=2
	leaq	1(%r14), %rdi
	testb	%sil, %sil
	je	.LBB2_4
.LBB2_8:                                #   Parent Loop BB2_5 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB2_12 Depth 3
	movq	%rdi, %r14
	testq	%rcx, %rcx
	je	.LBB2_11
.LBB2_9:                                #   in Loop: Header=BB2_8 Depth=2
	rep		bsfq	%rcx, %rsi
	movq	%rdx, %rdi
	shlq	$6, %rdi
	orq	%rsi, %rdi
	cmpq	8(%rax), %rdi
	jae	.LBB2_15
# %bb.6:                                #   in Loop: Header=BB2_8 Depth=2
	btrq	%rsi, %rcx
	movb	$1, %sil
	jmp	.LBB2_7
	.p2align	4
.LBB2_11:                               #   in Loop: Header=BB2_8 Depth=2
	movq	(%rax), %rdi
	leaq	1(%rdx), %rsi
	cmpq	%rdi, %rsi
	jae	.LBB2_15
	.p2align	4
.LBB2_12:                               #   Parent Loop BB2_5 Depth=1
                                        #     Parent Loop BB2_8 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	#APP
	#NO_APP
	movq	16(%rax,%rsi,8), %rcx
	#APP
	#NO_APP
	testq	%rcx, %rcx
	jne	.LBB2_16
# %bb.13:                               #   in Loop: Header=BB2_12 Depth=3
	addq	$1, %rsi
	cmpq	%rsi, %rdi
	jne	.LBB2_12
	jmp	.LBB2_15
.LBB2_16:                               #   in Loop: Header=BB2_8 Depth=2
	movq	%rsi, %rdx
	jmp	.LBB2_9
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	$104, %edi
	callq	malloc@PLT
	movq	g_bitmap@GOTPCREL(%rip), %r12
	movq	%rax, (%r12)
	movq	$704, 8(%rax)                   # imm = 0x2C0
	movq	$11, (%rax)
	xorl	%ecx, %ecx
	.p2align	4
.LBB3_1:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	xorl	%edx, %edx
	xchgq	%rdx, 16(%rax,%rcx,8)
	#APP
	#NO_APP
	addq	$1, %rcx
	cmpq	(%rax), %rcx
	jb	.LBB3_1
# %bb.2:
	leaq	-128(%rbp), %rbx
	xorl	%r14d, %r14d
	movq	run@GOTPCREL(%rip), %r15
	.p2align	4
.LBB3_3:                                # =>This Inner Loop Header: Depth=1
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	movq	%r14, %rcx
	callq	pthread_create@PLT
	addq	$1, %r14
	addq	$8, %rbx
	cmpq	$12, %r14
	jne	.LBB3_3
# %bb.4:
	xorl	%ebx, %ebx
	.p2align	4
.LBB3_5:                                # =>This Inner Loop Header: Depth=1
	movq	-128(%rbp,%rbx,8), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	addq	$1, %rbx
	cmpq	$12, %rbx
	jne	.LBB3_5
# %bb.6:
	movq	(%r12), %rdi
	callq	free@PLT
	xorl	%eax, %eax
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        # -- End function
	.type	g_bitmap,@object                # @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.quad	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
