	.file	"eg_bitmap.c"
	.text
	.globl	reader                          // -- Begin function reader
	.p2align	2
	.type	reader,@function
reader:                                 // @reader
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	adrp	x21, :got:g_bitmap
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
	b	.LBB0_2
.LBB0_1:                                //   in Loop: Header=BB0_2 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.hs	.LBB0_12
.LBB0_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_5 Depth 2
                                        //       Child Loop BB0_9 Depth 3
	ldr	x9, [x21]
	//APP
	//NO_APP
	mov	x8, xzr
	mov	x13, xzr
	add	x10, x9, #16
	ldar	x11, [x10]
	//APP
	//NO_APP
	add	x10, x9, #24
	b	.LBB0_5
.LBB0_3:                                //   in Loop: Header=BB0_5 Depth=2
	mov	w12, wzr
	add	x13, x20, #1
	tbnz	w12, #0, .LBB0_5
	b	.LBB0_1
.LBB0_4:                                //   in Loop: Header=BB0_5 Depth=2
	mov	w12, #1                         // =0x1
	lsl	x13, x12, x13
	bic	x11, x11, x13
	add	x13, x20, #1
	tbz	w12, #0, .LBB0_1
.LBB0_5:                                //   Parent Loop BB0_2 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB0_9 Depth 3
	mov	x20, x13
	cbz	x11, .LBB0_7
.LBB0_6:                                //   in Loop: Header=BB0_5 Depth=2
	rbit	x12, x11
	ldr	x14, [x9, #8]
	clz	x13, x12
	orr	x12, x13, x8, lsl #6
	cmp	x12, x14
	b.lo	.LBB0_4
	b	.LBB0_3
.LBB0_7:                                //   in Loop: Header=BB0_5 Depth=2
	ldr	x13, [x9]
	add	x12, x8, #1
	cmp	x12, x13
	b.hs	.LBB0_3
// %bb.8:                               //   in Loop: Header=BB0_5 Depth=2
	add	x14, x10, x8, lsl #3
.LBB0_9:                                //   Parent Loop BB0_2 Depth=1
                                        //     Parent Loop BB0_5 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	//APP
	//NO_APP
	ldar	x11, [x14]
	//APP
	//NO_APP
	cbnz	x11, .LBB0_11
// %bb.10:                              //   in Loop: Header=BB0_9 Depth=3
	add	x12, x12, #1
	add	x14, x14, #8
	cmp	x13, x12
	b.ne	.LBB0_9
	b	.LBB0_3
.LBB0_11:                               //   in Loop: Header=BB0_5 Depth=2
	mov	x8, x12
	b	.LBB0_6
.LBB0_12:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        // -- End function
	.globl	writer                          // -- Begin function writer
	.p2align	2
	.type	writer,@function
writer:                                 // @writer
	.cfi_startproc
// %bb.0:
	adrp	x9, :got:g_bitmap
	and	x8, x0, #0x3ffffffffffffff
	mov	x12, #-1                        // =0xffffffffffffffff
	ldr	x9, [x9, :got_lo12:g_bitmap]
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x11, x10, #16
	add	x10, x11, x8, lsl #3
.LBB1_1:                                // =>This Inner Loop Header: Depth=1
	ldaxr	xzr, [x10]
	stlxr	w13, x12, [x10]
	cbnz	w13, .LBB1_1
// %bb.2:
	//APP
	//NO_APP
	cmp	x8, x8
	b.eq	.LBB1_8
// %bb.3:
	add	x12, x8, #1
	cmp	x12, x8
	b.hs	.LBB1_5
// %bb.4:
	add	x11, x11, x12, lsl #3
	mov	x12, #-1                        // =0xffffffffffffffff
	//APP
	//NO_APP
	stlr	x12, [x11]
	//APP
	//NO_APP
.LBB1_5:
	//APP
	//NO_APP
	mov	x11, #-1                        // =0xffffffffffffffff
.LBB1_6:                                // =>This Inner Loop Header: Depth=1
	ldaxr	xzr, [x10]
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB1_6
// %bb.7:
	//APP
	//NO_APP
.LBB1_8:
	ldr	x11, [x9]
	lsl	x10, x8, #3
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
.LBB1_9:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x12, [x11]
	and	x12, x12, #0xfffffffffffffffe
	stlxr	w13, x12, [x11]
	cbnz	w13, .LBB1_9
// %bb.10:
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x10, x11, x10
	add	x10, x10, #16
.LBB1_11:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x11, [x10]
	orr	x11, x11, #0x1
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB1_11
// %bb.12:
	//APP
	//NO_APP
	ldr	x9, [x9]
	//APP
	//NO_APP
	add	x8, x9, x8, lsl #3
	add	x8, x8, #16
	ldar	xzr, [x8]
	//APP
	//NO_APP
	ret
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	cmp	x0, #11
	b.eq	.LBB2_9
// %bb.1:
	adrp	x9, :got:g_bitmap
	and	x8, x0, #0x3ffffffffffffff
	mov	x11, #-1                        // =0xffffffffffffffff
	ldr	x9, [x9, :got_lo12:g_bitmap]
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
.LBB2_2:                                // =>This Inner Loop Header: Depth=1
	ldaxr	xzr, [x10]
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB2_2
// %bb.3:
	//APP
	//NO_APP
	lsl	x10, x8, #3
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
.LBB2_4:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x12, [x11]
	and	x12, x12, #0xfffffffffffffffe
	stlxr	w13, x12, [x11]
	cbnz	w13, .LBB2_4
// %bb.5:
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x10, x11, x10
	add	x10, x10, #16
.LBB2_6:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x11, [x10]
	orr	x11, x11, #0x1
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB2_6
// %bb.7:
	//APP
	//NO_APP
	ldr	x9, [x9]
	//APP
	//NO_APP
	add	x8, x9, x8, lsl #3
	add	x8, x8, #16
	ldar	xzr, [x8]
	//APP
	//NO_APP
.LBB2_8:
	mov	x0, xzr
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB2_9:
	.cfi_restore_state
	adrp	x21, :got:g_bitmap
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
	b	.LBB2_11
.LBB2_10:                               //   in Loop: Header=BB2_11 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.hs	.LBB2_8
.LBB2_11:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB2_14 Depth 2
                                        //       Child Loop BB2_18 Depth 3
	ldr	x9, [x21]
	//APP
	//NO_APP
	mov	x8, xzr
	mov	x13, xzr
	add	x10, x9, #16
	ldar	x11, [x10]
	//APP
	//NO_APP
	add	x10, x9, #24
	b	.LBB2_14
.LBB2_12:                               //   in Loop: Header=BB2_14 Depth=2
	mov	w12, wzr
	add	x13, x20, #1
	tbnz	w12, #0, .LBB2_14
	b	.LBB2_10
.LBB2_13:                               //   in Loop: Header=BB2_14 Depth=2
	mov	w12, #1                         // =0x1
	lsl	x13, x12, x13
	bic	x11, x11, x13
	add	x13, x20, #1
	tbz	w12, #0, .LBB2_10
.LBB2_14:                               //   Parent Loop BB2_11 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB2_18 Depth 3
	mov	x20, x13
	cbz	x11, .LBB2_16
.LBB2_15:                               //   in Loop: Header=BB2_14 Depth=2
	rbit	x12, x11
	ldr	x14, [x9, #8]
	clz	x13, x12
	orr	x12, x13, x8, lsl #6
	cmp	x12, x14
	b.lo	.LBB2_13
	b	.LBB2_12
.LBB2_16:                               //   in Loop: Header=BB2_14 Depth=2
	ldr	x13, [x9]
	add	x12, x8, #1
	cmp	x12, x13
	b.hs	.LBB2_12
// %bb.17:                              //   in Loop: Header=BB2_14 Depth=2
	add	x14, x10, x8, lsl #3
.LBB2_18:                               //   Parent Loop BB2_11 Depth=1
                                        //     Parent Loop BB2_14 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	//APP
	//NO_APP
	ldar	x11, [x14]
	//APP
	//NO_APP
	cbnz	x11, .LBB2_20
// %bb.19:                              //   in Loop: Header=BB2_18 Depth=3
	add	x12, x12, #1
	add	x14, x14, #8
	cmp	x13, x12
	b.ne	.LBB2_18
	b	.LBB2_12
.LBB2_20:                               //   in Loop: Header=BB2_14 Depth=2
	mov	x8, x12
	b	.LBB2_15
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	w0, #104                        // =0x68
	bl	malloc
	adrp	x22, :got:g_bitmap
	mov	x8, xzr
	mov	w9, #704                        // =0x2c0
	ldr	x22, [x22, :got_lo12:g_bitmap]
	mov	w10, #11                        // =0xb
	stp	x10, x9, [x0]
	str	x0, [x22]
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	add	x9, x0, x8, lsl #3
	//APP
	//NO_APP
	add	x8, x8, #1
	add	x9, x9, #16
	stlr	xzr, [x9]
	//APP
	//NO_APP
	ldr	x9, [x0]
	cmp	x8, x9
	b.lo	.LBB3_1
// %bb.2:
	adrp	x20, :got:run
	mov	x19, xzr
	mov	x21, sp
	ldr	x20, [x20, :got_lo12:run]
.LBB3_3:                                // =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, xzr
	mov	x2, x20
	mov	x3, x19
	bl	pthread_create
	add	x19, x19, #1
	add	x21, x21, #8
	cmp	x19, #12
	b.ne	.LBB3_3
// %bb.4:
	mov	x19, xzr
	mov	x20, sp
.LBB3_5:                                // =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19]
	mov	x1, xzr
	bl	pthread_join
	add	x19, x19, #8
	cmp	x19, #96
	b.ne	.LBB3_5
// %bb.6:
	ldr	x0, [x22]
	bl	free
	mov	w0, wzr
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        // -- End function
	.type	g_bitmap,@object                // @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.xword	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
