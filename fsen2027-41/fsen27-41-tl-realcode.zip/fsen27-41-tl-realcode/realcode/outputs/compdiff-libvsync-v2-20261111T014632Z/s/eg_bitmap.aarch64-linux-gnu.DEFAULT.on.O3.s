	.file	"eg_bitmap.c"
	.text
	.globl	reader                          // -- Begin function reader
	.p2align	2
	.type	reader,@function
reader:                                 // @reader
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x21, :got:g_bitmap
	mov	w22, #1                         // =0x1
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
	b	.LBB0_2
.LBB0_1:                                //   in Loop: Header=BB0_2 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.hs	.LBB0_10
.LBB0_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_6 Depth 2
                                        //     Child Loop BB0_8 Depth 2
	ldr	x8, [x21]
	cbz	x8, .LBB0_11
// %bb.3:                               //   in Loop: Header=BB0_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, .LBB0_12
// %bb.4:                               //   in Loop: Header=BB0_2 Depth=1
	add	x10, x8, #16
	//APP
	ldar	x11, [x10]
	//NO_APP
	mov	x9, xzr
	mov	x20, xzr
	add	x10, x8, #24
	cbnz	x11, .LBB0_8
.LBB0_5:                                //   in Loop: Header=BB0_2 Depth=1
	ldr	x12, [x8]
	add	x13, x10, x9, lsl #3
.LBB0_6:                                //   Parent Loop BB0_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x9, #1
	cmp	x9, x12
	b.hs	.LBB0_1
// %bb.7:                               //   in Loop: Header=BB0_6 Depth=2
	//APP
	ldar	x11, [x13]
	//NO_APP
	add	x13, x13, #8
	cbz	x11, .LBB0_6
.LBB0_8:                                //   Parent Loop BB0_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	rbit	x12, x11
	ldr	x14, [x8, #8]
	clz	x12, x12
	orr	x13, x12, x9, lsl #6
	cmp	x13, x14
	b.hs	.LBB0_1
// %bb.9:                               //   in Loop: Header=BB0_8 Depth=2
	lsl	x12, x22, x12
	add	x20, x20, #1
	bic	x11, x11, x12
	cbnz	x11, .LBB0_8
	b	.LBB0_5
.LBB0_10:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB0_11:
	.cfi_restore_state
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_iter_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_iter_init
	mov	w2, #314                        // =0x13a
	bl	__assert_fail
.LBB0_12:
	adrp	x0, .L.str.7
	add	x0, x0, :lo12:.L.str.7
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_iter_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_iter_init
	mov	w2, #316                        // =0x13c
	bl	__assert_fail
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        // -- End function
	.globl	writer                          // -- Begin function writer
	.p2align	2
	.type	writer,@function
writer:                                 // @writer
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x9, :got:g_bitmap
	ldr	x9, [x9, :got_lo12:g_bitmap]
	ldr	x11, [x9]
	cbz	x11, .LBB1_25
// %bb.1:
	lsl	x8, x0, #6
	ldr	x10, [x11, #8]
	orr	x12, x8, #0x3f
	cmp	x12, x10
	b.hs	.LBB1_26
// %bb.2:
	ldr	x12, [x11]
	and	x10, x0, #0x3ffffffffffffff
	cmp	x10, x12
	b.hs	.LBB1_27
// %bb.3:
	add	x11, x11, x10, lsl #3
	mov	x12, #-1                        // =0xffffffffffffffff
	add	x11, x11, #16
	//APP
	prfm	pstl1strm, [x11]
.Ltmp0:
	ldaxr	x13, [x11]
	orr	x14, x13, x12
	stlxr	w15, x14, [x11]
	cbnz	w15, .Ltmp0

	//NO_APP
	ldr	x11, [x9]
	cbz	x11, .LBB1_22
// %bb.4:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_23
// %bb.5:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_24
// %bb.6:
	add	x11, x11, x10, lsl #3
	add	x11, x11, #16
	//APP
	ldar	x12, [x11]
	//NO_APP
	tbz	w12, #0, .LBB1_28
// %bb.7:
	ldr	x11, [x9]
	cbz	x11, .LBB1_29
// %bb.8:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_30
// %bb.9:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_31
// %bb.10:
	add	x11, x11, x10, lsl #3
	mov	x12, #-2                        // =0xfffffffffffffffe
	add	x11, x11, #16
	//APP
	prfm	pstl1strm, [x11]
.Ltmp1:
	ldaxr	x13, [x11]
	and	x14, x13, x12
	stlxr	w15, x14, [x11]
	cbnz	w15, .Ltmp1

	//NO_APP
	ldr	x11, [x9]
	cbz	x11, .LBB1_22
// %bb.11:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_23
// %bb.12:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_24
// %bb.13:
	add	x11, x11, x10, lsl #3
	add	x11, x11, #16
	//APP
	ldar	x12, [x11]
	//NO_APP
	tbnz	w12, #0, .LBB1_32
// %bb.14:
	ldr	x11, [x9]
	cbz	x11, .LBB1_33
// %bb.15:
	ldr	x12, [x11, #8]
	cmp	x8, x12
	b.hs	.LBB1_34
// %bb.16:
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	.LBB1_35
// %bb.17:
	add	x11, x11, x10, lsl #3
	mov	w12, #1                         // =0x1
	add	x11, x11, #16
	//APP
	prfm	pstl1strm, [x11]
.Ltmp2:
	ldaxr	x13, [x11]
	orr	x14, x13, x12
	stlxr	w15, x14, [x11]
	cbnz	w15, .Ltmp2

	//NO_APP
	ldr	x9, [x9]
	cbz	x9, .LBB1_22
// %bb.18:
	ldr	x11, [x9, #8]
	cmp	x8, x11
	b.hs	.LBB1_23
// %bb.19:
	ldr	x8, [x9]
	cmp	x10, x8
	b.hs	.LBB1_24
// %bb.20:
	add	x8, x9, x10, lsl #3
	add	x8, x8, #16
	//APP
	ldar	x9, [x8]
	//NO_APP
	tbz	w9, #0, .LBB1_36
// %bb.21:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB1_22:
	.cfi_restore_state
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	mov	w2, #140                        // =0x8c
	bl	__assert_fail
.LBB1_23:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	mov	w2, #141                        // =0x8d
	bl	__assert_fail
.LBB1_24:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	mov	w2, #143                        // =0x8f
	bl	__assert_fail
.LBB1_25:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	mov	w2, #214                        // =0xd6
	bl	__assert_fail
.LBB1_26:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	mov	w2, #216                        // =0xd8
	bl	__assert_fail
.LBB1_27:
	adrp	x0, .L.str.11
	add	x0, x0, :lo12:.L.str.11
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	mov	w2, #224                        // =0xe0
	bl	__assert_fail
.LBB1_28:
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	mov	w2, #44                         // =0x2c
	bl	__assert_fail
.LBB1_29:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	mov	w2, #297                        // =0x129
	bl	__assert_fail
.LBB1_30:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	mov	w2, #298                        // =0x12a
	bl	__assert_fail
.LBB1_31:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	mov	w2, #300                        // =0x12c
	bl	__assert_fail
.LBB1_32:
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	mov	w2, #48                         // =0x30
	bl	__assert_fail
.LBB1_33:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	mov	w2, #158                        // =0x9e
	bl	__assert_fail
.LBB1_34:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	mov	w2, #159                        // =0x9f
	bl	__assert_fail
.LBB1_35:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	mov	w2, #161                        // =0xa1
	bl	__assert_fail
.LBB1_36:
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	mov	w2, #52                         // =0x34
	bl	__assert_fail
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	cmp	x0, #11
	b.eq	.LBB2_2
// %bb.1:
	bl	writer
	mov	x0, xzr
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB2_2:
	.cfi_restore_state
	bl	reader
	mov	x0, xzr
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        // -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          // -- Begin function main
.LCPI3_0:
	.xword	11                              // 0xb
	.xword	704                             // 0x2c0
	.text
	.globl	main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	str	x21, [sp, #112]                 // 8-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	w0, #104                        // =0x68
	bl	malloc
	adrp	x9, .LCPI3_0
	adrp	x20, :got:g_bitmap
	mov	x8, xzr
	ldr	x20, [x20, :got_lo12:g_bitmap]
	ldr	q0, [x9, :lo12:.LCPI3_0]
	mov	x9, x0
	mov	x10, xzr
	str	x0, [x20]
	str	q0, [x9], #16
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	//APP
	stlr	x8, [x9]
	//NO_APP
	add	x10, x10, #1
	add	x9, x9, #8
	ldr	x11, [x0]
	cmp	x10, x11
	b.lo	.LBB3_1
// %bb.2:
	adrp	x19, :got:run
	mov	x0, sp
	mov	x1, xzr
	ldr	x19, [x19, :got_lo12:run]
	mov	x3, xzr
	mov	x21, sp
	mov	x2, x19
	bl	pthread_create
	add	x0, x21, #8
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #1                          // =0x1
	bl	pthread_create
	add	x0, x21, #16
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #2                          // =0x2
	bl	pthread_create
	add	x0, x21, #24
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #3                          // =0x3
	bl	pthread_create
	add	x0, x21, #32
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #4                          // =0x4
	bl	pthread_create
	add	x0, x21, #40
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #5                          // =0x5
	bl	pthread_create
	add	x0, x21, #48
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #6                          // =0x6
	bl	pthread_create
	add	x0, x21, #56
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #7                          // =0x7
	bl	pthread_create
	add	x0, x21, #64
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #8                          // =0x8
	bl	pthread_create
	add	x0, x21, #72
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #9                          // =0x9
	bl	pthread_create
	add	x0, x21, #80
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #10                         // =0xa
	bl	pthread_create
	add	x0, x21, #88
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #11                         // =0xb
	bl	pthread_create
	ldr	x0, [sp]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #16]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #24]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #32]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #40]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #48]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #56]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #64]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #72]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #80]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #88]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [x20]
	bl	free
	mov	w0, wzr
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldr	x21, [sp, #112]                 // 8-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        // -- End function
	.type	g_bitmap,@object                // @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.xword	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"set == 1"
	.size	.L.str.1, 9

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"C:/rc1111/src/libvsync/examples/eg_bitmap.c"
	.size	.L.str.2, 44

	.type	.L__PRETTY_FUNCTION__.writer,@object // @__PRETTY_FUNCTION__.writer
.L__PRETTY_FUNCTION__.writer:
	.asciz	"void writer(vsize_t)"
	.size	.L__PRETTY_FUNCTION__.writer, 21

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"set == 0"
	.size	.L.str.3, 9

	.type	.L.str.4,@object                // @.str.4
.L.str.4:
	.asciz	"bitmap"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                // @.str.5
.L.str.5:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/bitmap/bitmap.h"
	.size	.L.str.5, 53

	.type	.L__PRETTY_FUNCTION__.vbitmap_iter_init,@object // @__PRETTY_FUNCTION__.vbitmap_iter_init
.L__PRETTY_FUNCTION__.vbitmap_iter_init:
	.asciz	"void vbitmap_iter_init(vbitmap_t *, vbitmap_iter_t *)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_iter_init, 54

	.type	.L.str.7,@object                // @.str.7
.L.str.7:
	.asciz	"bitmap->maps_cnt > 0"
	.size	.L.str.7, 21

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_range,@object // @__PRETTY_FUNCTION__.vbitmap_set_range
.L__PRETTY_FUNCTION__.vbitmap_set_range:
	.asciz	"void vbitmap_set_range(vbitmap_t *, vsize_t, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_range, 54

	.type	.L.str.9,@object                // @.str.9
.L.str.9:
	.asciz	"to < bitmap->bit_cnt"
	.size	.L.str.9, 21

	.type	.L.str.11,@object               // @.str.11
.L.str.11:
	.asciz	"msb_slot < bitmap->maps_cnt"
	.size	.L.str.11, 28

	.type	.L.str.12,@object               // @.str.12
.L.str.12:
	.asciz	"idx < bitmap->maps_cnt"
	.size	.L.str.12, 23

	.type	.L__PRETTY_FUNCTION__.vbitmap_get,@object // @__PRETTY_FUNCTION__.vbitmap_get
.L__PRETTY_FUNCTION__.vbitmap_get:
	.asciz	"vbool_t vbitmap_get(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_get, 42

	.type	.L.str.13,@object               // @.str.13
.L.str.13:
	.asciz	"bit_idx < bitmap->bit_cnt"
	.size	.L.str.13, 26

	.type	.L__PRETTY_FUNCTION__.vbitmap_clr_bit,@object // @__PRETTY_FUNCTION__.vbitmap_clr_bit
.L__PRETTY_FUNCTION__.vbitmap_clr_bit:
	.asciz	"void vbitmap_clr_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_clr_bit, 43

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_bit,@object // @__PRETTY_FUNCTION__.vbitmap_set_bit
.L__PRETTY_FUNCTION__.vbitmap_set_bit:
	.asciz	"void vbitmap_set_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_bit, 43

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
