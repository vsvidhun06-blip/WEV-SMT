	.file	"eg_bitmap.c"
	.text
	.globl	reader                          // -- Begin function reader
	.p2align	2
	.type	reader,@function
reader:                                 // @reader
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	adrp	x21, :got:g_bitmap
	mov	w22, #1                         // =0x1
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
.LBB0_1:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_4 Depth 2
	ldr	x8, [x21]
	//APP
	//NO_APP
	mov	x11, xzr
	mov	x20, xzr
	add	x9, x8, #16
	ldar	x10, [x9]
	//APP
	//NO_APP
	add	x9, x8, #24
	cbz	x10, .LBB0_3
.LBB0_2:                                //   in Loop: Header=BB0_1 Depth=1
	mov	x12, x11
	b	.LBB0_6
.LBB0_3:                                //   in Loop: Header=BB0_1 Depth=1
	ldr	x13, [x8]
.LBB0_4:                                //   Parent Loop BB0_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x12, x11, #1
	cmp	x12, x13
	b.hs	.LBB0_8
// %bb.5:                               //   in Loop: Header=BB0_4 Depth=2
	add	x10, x9, x11, lsl #3
	//APP
	//NO_APP
	mov	x11, x12
	ldar	x10, [x10]
	//APP
	//NO_APP
	cbz	x10, .LBB0_4
.LBB0_6:                                //   in Loop: Header=BB0_1 Depth=1
	rbit	x11, x10
	ldr	x14, [x8, #8]
	clz	x11, x11
	orr	x13, x11, x12, lsl #6
	cmp	x13, x14
	b.hs	.LBB0_8
// %bb.7:                               //   in Loop: Header=BB0_1 Depth=1
	lsl	x11, x22, x11
	add	x20, x20, #1
	bic	x10, x10, x11
	mov	x11, x12
	cbnz	x10, .LBB0_2
	b	.LBB0_3
.LBB0_8:                                //   in Loop: Header=BB0_1 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.lo	.LBB0_1
// %bb.9:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        // -- End function
	.globl	writer                          // -- Begin function writer
	.p2align	2
	.type	writer,@function
writer:                                 // @writer
	.cfi_startproc
// %bb.0:
	adrp	x9, :got:g_bitmap
	and	x8, x0, #0x3ffffffffffffff
	mov	x11, #-1                        // =0xffffffffffffffff
	ldr	x9, [x9, :got_lo12:g_bitmap]
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
.LBB1_1:                                // =>This Inner Loop Header: Depth=1
	ldaxr	xzr, [x10]
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB1_1
// %bb.2:
	//APP
	//NO_APP
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
	ldar	xzr, [x10]
	//APP
	//NO_APP
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
.LBB1_3:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x11, [x10]
	and	x11, x11, #0xfffffffffffffffe
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB1_3
// %bb.4:
	//APP
	//NO_APP
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
	ldar	xzr, [x10]
	//APP
	//NO_APP
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
.LBB1_5:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x11, [x10]
	orr	x11, x11, #0x1
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB1_5
// %bb.6:
	//APP
	//NO_APP
	ldr	x9, [x9]
	//APP
	//NO_APP
	add	x8, x9, x8, lsl #3
	add	x8, x8, #16
	ldar	xzr, [x8]
	//APP
	//NO_APP
	ret
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cmp	x0, #11
	b.eq	.LBB2_2
// %bb.1:
	bl	writer
	b	.LBB2_3
.LBB2_2:
	bl	reader
.LBB2_3:
	mov	x0, xzr
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        // -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          // -- Begin function main
.LCPI3_0:
	.xword	11                              // 0xb
	.xword	704                             // 0x2c0
	.text
	.globl	main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	w0, #104                        // =0x68
	bl	malloc
	adrp	x9, .LCPI3_0
	adrp	x22, :got:g_bitmap
	mov	x8, xzr
	ldr	x22, [x22, :got_lo12:g_bitmap]
	ldr	q0, [x9, :lo12:.LCPI3_0]
	str	x0, [x22]
	str	q0, [x0]
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	add	x9, x0, x8, lsl #3
	//APP
	//NO_APP
	add	x8, x8, #1
	add	x9, x9, #16
	stlr	xzr, [x9]
	//APP
	//NO_APP
	ldr	x9, [x0]
	cmp	x8, x9
	b.lo	.LBB3_1
// %bb.2:
	adrp	x20, :got:run
	mov	x19, xzr
	mov	x21, sp
	ldr	x20, [x20, :got_lo12:run]
.LBB3_3:                                // =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, xzr
	mov	x2, x20
	mov	x3, x19
	bl	pthread_create
	add	x19, x19, #1
	add	x21, x21, #8
	cmp	x19, #12
	b.ne	.LBB3_3
// %bb.4:
	mov	x19, xzr
	mov	x20, sp
.LBB3_5:                                // =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19]
	mov	x1, xzr
	bl	pthread_join
	add	x19, x19, #8
	cmp	x19, #96
	b.ne	.LBB3_5
// %bb.6:
	ldr	x0, [x22]
	bl	free
	mov	w0, wzr
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        // -- End function
	.type	g_bitmap,@object                // @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.xword	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
