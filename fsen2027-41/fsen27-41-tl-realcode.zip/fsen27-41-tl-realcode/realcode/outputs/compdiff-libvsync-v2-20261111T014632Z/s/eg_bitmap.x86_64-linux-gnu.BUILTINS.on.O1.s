	.file	"eg_bitmap.c"
	.text
	.globl	reader                          # -- Begin function reader
	.p2align	4
	.type	reader,@function
reader:                                 # @reader
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	g_bitmap@GOTPCREL(%rip), %r15
	leaq	.L.str(%rip), %rbx
	jmp	.LBB0_2
	.p2align	4
.LBB0_1:                                #   in Loop: Header=BB0_2 Depth=1
	movl	$693, %edx                      # imm = 0x2B5
	movq	%rbx, %rdi
	movq	%r14, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	cmpq	$693, %r14                      # imm = 0x2B5
	jae	.LBB0_16
.LBB0_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_7 Depth 2
                                        #       Child Loop BB0_11 Depth 3
	movq	(%r15), %rax
	testq	%rax, %rax
	je	.LBB0_17
# %bb.3:                                #   in Loop: Header=BB0_2 Depth=1
	cmpq	$0, (%rax)
	je	.LBB0_18
# %bb.4:                                #   in Loop: Header=BB0_2 Depth=1
	#APP
	#NO_APP
	movq	16(%rax), %rcx
	#APP
	#NO_APP
	xorl	%edx, %edx
	xorl	%edi, %edi
	jmp	.LBB0_7
	.p2align	4
.LBB0_14:                               #   in Loop: Header=BB0_7 Depth=2
	xorl	%esi, %esi
.LBB0_6:                                #   in Loop: Header=BB0_7 Depth=2
	leaq	1(%r14), %rdi
	testb	%sil, %sil
	je	.LBB0_1
.LBB0_7:                                #   Parent Loop BB0_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB0_11 Depth 3
	movq	%rdi, %r14
	testq	%rcx, %rcx
	je	.LBB0_10
.LBB0_8:                                #   in Loop: Header=BB0_7 Depth=2
	rep		bsfq	%rcx, %rsi
	movq	%rdx, %rdi
	shlq	$6, %rdi
	orq	%rsi, %rdi
	cmpq	8(%rax), %rdi
	jae	.LBB0_14
# %bb.5:                                #   in Loop: Header=BB0_7 Depth=2
	btrq	%rsi, %rcx
	movb	$1, %sil
	jmp	.LBB0_6
	.p2align	4
.LBB0_10:                               #   in Loop: Header=BB0_7 Depth=2
	movq	(%rax), %rdi
	leaq	1(%rdx), %rsi
	cmpq	%rdi, %rsi
	jae	.LBB0_14
	.p2align	4
.LBB0_11:                               #   Parent Loop BB0_2 Depth=1
                                        #     Parent Loop BB0_7 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	#APP
	#NO_APP
	movq	16(%rax,%rsi,8), %rcx
	#APP
	#NO_APP
	testq	%rcx, %rcx
	jne	.LBB0_15
# %bb.12:                               #   in Loop: Header=BB0_11 Depth=3
	addq	$1, %rsi
	cmpq	%rsi, %rdi
	jne	.LBB0_11
	jmp	.LBB0_14
.LBB0_15:                               #   in Loop: Header=BB0_7 Depth=2
	movq	%rsi, %rdx
	jmp	.LBB0_8
.LBB0_16:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB0_17:
	.cfi_def_cfa %rbp, 16
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_iter_init(%rip), %rcx
	movl	$314, %edx                      # imm = 0x13A
	callq	__assert_fail@PLT
.LBB0_18:
	leaq	.L.str.7(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_iter_init(%rip), %rcx
	movl	$316, %edx                      # imm = 0x13C
	callq	__assert_fail@PLT
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        # -- End function
	.globl	writer                          # -- Begin function writer
	.p2align	4
	.type	writer,@function
writer:                                 # @writer
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_29
# %bb.1:
	movq	%rdi, %rcx
	shlq	$6, %rcx
	movq	%rcx, %rsi
	orq	$63, %rsi
	cmpq	8(%rdx), %rsi
	jae	.LBB1_30
# %bb.2:
	movabsq	$288230376151711743, %rsi       # imm = 0x3FFFFFFFFFFFFFF
	andq	%rsi, %rdi
	movq	(%rdx), %rsi
	cmpq	%rsi, %rdi
	jae	.LBB1_31
# %bb.3:
	cmpq	%rdi, %rdi
	jne	.LBB1_6
# %bb.4:
	cmpq	%rsi, %rdi
	jae	.LBB1_32
# %bb.5:
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rdx,%rdi,8)
	#APP
	#NO_APP
	jmp	.LBB1_10
.LBB1_6:
	cmpq	%rsi, %rdi
	jae	.LBB1_32
# %bb.7:
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rdx,%rdi,8)
	movq	$-1, %rsi
	#APP
	#NO_APP
	leaq	1(%rdi), %r8
	cmpq	%rdi, %r8
	jae	.LBB1_8
# %bb.33:
	#APP
	#NO_APP
	xchgq	%rsi, 24(%rdx,%rdi,8)
	#APP
	#NO_APP
.LBB1_8:
	cmpq	(%rdx), %rdi
	jae	.LBB1_32
# %bb.9:
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rdx,%rdi,8)
	#APP
	#NO_APP
.LBB1_10:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_34
# %bb.11:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_35
# %bb.12:
	cmpq	(%rdx), %rdi
	jae	.LBB1_36
# %bb.13:
	#APP
	#NO_APP
	movq	16(%rdx,%rdi,8), %rdx
	#APP
	#NO_APP
	testb	$1, %dl
	je	.LBB1_37
# %bb.14:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_38
# %bb.15:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_39
# %bb.16:
	cmpq	(%rdx), %rdi
	jae	.LBB1_40
# %bb.17:
	#APP
	#NO_APP
	lock		andq	$-2, 16(%rdx,%rdi,8)
	#APP
	#NO_APP
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_34
# %bb.18:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_35
# %bb.19:
	cmpq	(%rdx), %rdi
	jae	.LBB1_36
# %bb.20:
	#APP
	#NO_APP
	movq	16(%rdx,%rdi,8), %rdx
	#APP
	#NO_APP
	testb	$1, %dl
	jne	.LBB1_41
# %bb.21:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_42
# %bb.22:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_43
# %bb.23:
	cmpq	(%rdx), %rdi
	jae	.LBB1_44
# %bb.24:
	#APP
	#NO_APP
	lock		orq	$1, 16(%rdx,%rdi,8)
	#APP
	#NO_APP
	movq	(%rax), %rax
	testq	%rax, %rax
	je	.LBB1_34
# %bb.25:
	cmpq	8(%rax), %rcx
	jae	.LBB1_35
# %bb.26:
	cmpq	(%rax), %rdi
	jae	.LBB1_36
# %bb.27:
	#APP
	#NO_APP
	movq	16(%rax,%rdi,8), %rax
	#APP
	#NO_APP
	testb	$1, %al
	je	.LBB1_45
# %bb.28:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB1_34:
	.cfi_def_cfa %rbp, 16
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_get(%rip), %rcx
	movl	$140, %edx
	callq	__assert_fail@PLT
.LBB1_35:
	leaq	.L.str.13(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_get(%rip), %rcx
	movl	$141, %edx
	callq	__assert_fail@PLT
.LBB1_36:
	leaq	.L.str.12(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_get(%rip), %rcx
	movl	$143, %edx
	callq	__assert_fail@PLT
.LBB1_32:
	leaq	.L.str.12(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__._vbitbmap_set_slot(%rip), %rcx
	movl	$176, %edx
	callq	__assert_fail@PLT
.LBB1_29:
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_range(%rip), %rcx
	movl	$214, %edx
	callq	__assert_fail@PLT
.LBB1_30:
	leaq	.L.str.9(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_range(%rip), %rcx
	movl	$216, %edx
	callq	__assert_fail@PLT
.LBB1_31:
	leaq	.L.str.11(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_range(%rip), %rcx
	movl	$224, %edx
	callq	__assert_fail@PLT
.LBB1_37:
	leaq	.L.str.1(%rip), %rdi
	leaq	.L.str.2(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.writer(%rip), %rcx
	movl	$44, %edx
	callq	__assert_fail@PLT
.LBB1_38:
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_clr_bit(%rip), %rcx
	movl	$297, %edx                      # imm = 0x129
	callq	__assert_fail@PLT
.LBB1_39:
	leaq	.L.str.13(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_clr_bit(%rip), %rcx
	movl	$298, %edx                      # imm = 0x12A
	callq	__assert_fail@PLT
.LBB1_40:
	leaq	.L.str.12(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_clr_bit(%rip), %rcx
	movl	$300, %edx                      # imm = 0x12C
	callq	__assert_fail@PLT
.LBB1_41:
	leaq	.L.str.3(%rip), %rdi
	leaq	.L.str.2(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.writer(%rip), %rcx
	movl	$48, %edx
	callq	__assert_fail@PLT
.LBB1_42:
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_bit(%rip), %rcx
	movl	$158, %edx
	callq	__assert_fail@PLT
.LBB1_43:
	leaq	.L.str.13(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_bit(%rip), %rcx
	movl	$159, %edx
	callq	__assert_fail@PLT
.LBB1_44:
	leaq	.L.str.12(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_bit(%rip), %rcx
	movl	$161, %edx
	callq	__assert_fail@PLT
.LBB1_45:
	leaq	.L.str.1(%rip), %rdi
	leaq	.L.str.2(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.writer(%rip), %rcx
	movl	$52, %edx
	callq	__assert_fail@PLT
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	cmpq	$11, %rdi
	je	.LBB2_1
# %bb.2:
	callq	writer@PLT
	jmp	.LBB2_3
.LBB2_1:
	callq	reader@PLT
.LBB2_3:
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	$104, %edi
	callq	malloc@PLT
	movq	g_bitmap@GOTPCREL(%rip), %r12
	movq	%rax, (%r12)
	movq	$704, 8(%rax)                   # imm = 0x2C0
	movq	$11, (%rax)
	xorl	%ecx, %ecx
	.p2align	4
.LBB3_1:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	xorl	%edx, %edx
	xchgq	%rdx, 16(%rax,%rcx,8)
	#APP
	#NO_APP
	addq	$1, %rcx
	cmpq	(%rax), %rcx
	jb	.LBB3_1
# %bb.2:
	leaq	-128(%rbp), %rbx
	xorl	%r14d, %r14d
	movq	run@GOTPCREL(%rip), %r15
	.p2align	4
.LBB3_3:                                # =>This Inner Loop Header: Depth=1
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	movq	%r14, %rcx
	callq	pthread_create@PLT
	addq	$1, %r14
	addq	$8, %rbx
	cmpq	$12, %r14
	jne	.LBB3_3
# %bb.4:
	xorl	%ebx, %ebx
	.p2align	4
.LBB3_5:                                # =>This Inner Loop Header: Depth=1
	movq	-128(%rbp,%rbx,8), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	addq	$1, %rbx
	cmpq	$12, %rbx
	jne	.LBB3_5
# %bb.6:
	movq	(%r12), %rdi
	callq	free@PLT
	xorl	%eax, %eax
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        # -- End function
	.type	g_bitmap,@object                # @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.quad	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"set == 1"
	.size	.L.str.1, 9

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"C:/rc1111/src/libvsync/examples/eg_bitmap.c"
	.size	.L.str.2, 44

	.type	.L__PRETTY_FUNCTION__.writer,@object # @__PRETTY_FUNCTION__.writer
.L__PRETTY_FUNCTION__.writer:
	.asciz	"void writer(vsize_t)"
	.size	.L__PRETTY_FUNCTION__.writer, 21

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"set == 0"
	.size	.L.str.3, 9

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"bitmap"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/bitmap/bitmap.h"
	.size	.L.str.5, 53

	.type	.L__PRETTY_FUNCTION__.vbitmap_iter_init,@object # @__PRETTY_FUNCTION__.vbitmap_iter_init
.L__PRETTY_FUNCTION__.vbitmap_iter_init:
	.asciz	"void vbitmap_iter_init(vbitmap_t *, vbitmap_iter_t *)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_iter_init, 54

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"bitmap->maps_cnt > 0"
	.size	.L.str.7, 21

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_range,@object # @__PRETTY_FUNCTION__.vbitmap_set_range
.L__PRETTY_FUNCTION__.vbitmap_set_range:
	.asciz	"void vbitmap_set_range(vbitmap_t *, vsize_t, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_range, 54

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"to < bitmap->bit_cnt"
	.size	.L.str.9, 21

	.type	.L.str.11,@object               # @.str.11
.L.str.11:
	.asciz	"msb_slot < bitmap->maps_cnt"
	.size	.L.str.11, 28

	.type	.L.str.12,@object               # @.str.12
.L.str.12:
	.asciz	"idx < bitmap->maps_cnt"
	.size	.L.str.12, 23

	.type	.L__PRETTY_FUNCTION__._vbitbmap_set_slot,@object # @__PRETTY_FUNCTION__._vbitbmap_set_slot
.L__PRETTY_FUNCTION__._vbitbmap_set_slot:
	.asciz	"void _vbitbmap_set_slot(vbitmap_t *, vsize_t, vuint64_t)"
	.size	.L__PRETTY_FUNCTION__._vbitbmap_set_slot, 57

	.type	.L__PRETTY_FUNCTION__.vbitmap_get,@object # @__PRETTY_FUNCTION__.vbitmap_get
.L__PRETTY_FUNCTION__.vbitmap_get:
	.asciz	"vbool_t vbitmap_get(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_get, 42

	.type	.L.str.13,@object               # @.str.13
.L.str.13:
	.asciz	"bit_idx < bitmap->bit_cnt"
	.size	.L.str.13, 26

	.type	.L__PRETTY_FUNCTION__.vbitmap_clr_bit,@object # @__PRETTY_FUNCTION__.vbitmap_clr_bit
.L__PRETTY_FUNCTION__.vbitmap_clr_bit:
	.asciz	"void vbitmap_clr_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_clr_bit, 43

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_bit,@object # @__PRETTY_FUNCTION__.vbitmap_set_bit
.L__PRETTY_FUNCTION__.vbitmap_set_bit:
	.asciz	"void vbitmap_set_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_bit, 43

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
