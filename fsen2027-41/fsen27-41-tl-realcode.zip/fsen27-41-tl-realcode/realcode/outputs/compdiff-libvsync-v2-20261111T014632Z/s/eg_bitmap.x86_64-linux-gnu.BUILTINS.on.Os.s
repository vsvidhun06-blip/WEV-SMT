	.file	"eg_bitmap.c"
	.text
	.globl	reader                          # -- Begin function reader
	.type	reader,@function
reader:                                 # @reader
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	g_bitmap@GOTPCREL(%rip), %r15
	leaq	.L.str(%rip), %rbx
.LBB0_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_4 Depth 2
                                        #       Child Loop BB0_6 Depth 3
	movq	(%r15), %rax
	testq	%rax, %rax
	je	.LBB0_12
# %bb.2:                                #   in Loop: Header=BB0_1 Depth=1
	cmpq	$0, (%rax)
	je	.LBB0_13
# %bb.3:                                #   in Loop: Header=BB0_1 Depth=1
	#APP
	#NO_APP
	movq	16(%rax), %rdx
	#APP
	#NO_APP
	xorl	%ecx, %ecx
	xorl	%r14d, %r14d
.LBB0_4:                                #   Parent Loop BB0_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB0_6 Depth 3
	testq	%rdx, %rdx
	jne	.LBB0_8
# %bb.5:                                #   in Loop: Header=BB0_4 Depth=2
	movq	(%rax), %rsi
.LBB0_6:                                #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_4 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	incq	%rcx
	cmpq	%rsi, %rcx
	jae	.LBB0_10
# %bb.7:                                #   in Loop: Header=BB0_6 Depth=3
	#APP
	#NO_APP
	movq	16(%rax,%rcx,8), %rdx
	#APP
	#NO_APP
	testq	%rdx, %rdx
	je	.LBB0_6
.LBB0_8:                                #   in Loop: Header=BB0_4 Depth=2
	bsfq	%rdx, %rsi
	movq	%rcx, %rdi
	shlq	$6, %rdi
	orq	%rsi, %rdi
	cmpq	8(%rax), %rdi
	jae	.LBB0_10
# %bb.9:                                #   in Loop: Header=BB0_4 Depth=2
	btrq	%rsi, %rdx
	incq	%r14
	jmp	.LBB0_4
.LBB0_10:                               #   in Loop: Header=BB0_1 Depth=1
	movl	$693, %edx                      # imm = 0x2B5
	movq	%rbx, %rdi
	movq	%r14, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	cmpq	$693, %r14                      # imm = 0x2B5
	jb	.LBB0_1
# %bb.11:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB0_12:
	.cfi_def_cfa %rbp, 16
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_iter_init(%rip), %rcx
	movl	$314, %edx                      # imm = 0x13A
	callq	__assert_fail@PLT
.LBB0_13:
	leaq	.L.str.7(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_iter_init(%rip), %rcx
	movl	$316, %edx                      # imm = 0x13C
	callq	__assert_fail@PLT
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        # -- End function
	.globl	writer                          # -- Begin function writer
	.type	writer,@function
writer:                                 # @writer
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_22
# %bb.1:
	movq	%rdi, %rcx
	shlq	$6, %rcx
	movq	%rcx, %rsi
	orq	$63, %rsi
	cmpq	8(%rdx), %rsi
	jae	.LBB1_23
# %bb.2:
	movabsq	$288230376151711743, %rsi       # imm = 0x3FFFFFFFFFFFFFF
	andq	%rsi, %rdi
	cmpq	(%rdx), %rdi
	jae	.LBB1_24
# %bb.3:
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rdx,%rdi,8)
	#APP
	#NO_APP
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_25
# %bb.4:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_26
# %bb.5:
	cmpq	(%rdx), %rdi
	jae	.LBB1_27
# %bb.6:
	#APP
	#NO_APP
	movq	16(%rdx,%rdi,8), %rdx
	#APP
	#NO_APP
	testb	$1, %dl
	je	.LBB1_28
# %bb.7:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_29
# %bb.8:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_30
# %bb.9:
	cmpq	(%rdx), %rdi
	jae	.LBB1_31
# %bb.10:
	#APP
	#NO_APP
	lock		andq	$-2, 16(%rdx,%rdi,8)
	#APP
	#NO_APP
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_25
# %bb.11:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_26
# %bb.12:
	cmpq	(%rdx), %rdi
	jae	.LBB1_27
# %bb.13:
	#APP
	#NO_APP
	movq	16(%rdx,%rdi,8), %rdx
	#APP
	#NO_APP
	testb	$1, %dl
	jne	.LBB1_32
# %bb.14:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_33
# %bb.15:
	cmpq	8(%rdx), %rcx
	jae	.LBB1_34
# %bb.16:
	cmpq	(%rdx), %rdi
	jae	.LBB1_35
# %bb.17:
	#APP
	#NO_APP
	lock		orq	$1, 16(%rdx,%rdi,8)
	#APP
	#NO_APP
	movq	(%rax), %rax
	testq	%rax, %rax
	je	.LBB1_25
# %bb.18:
	cmpq	8(%rax), %rcx
	jae	.LBB1_26
# %bb.19:
	cmpq	(%rax), %rdi
	jae	.LBB1_27
# %bb.20:
	#APP
	#NO_APP
	movq	16(%rax,%rdi,8), %rax
	#APP
	#NO_APP
	testb	$1, %al
	je	.LBB1_36
# %bb.21:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB1_25:
	.cfi_def_cfa %rbp, 16
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_get(%rip), %rcx
	movl	$140, %edx
	callq	__assert_fail@PLT
.LBB1_26:
	leaq	.L.str.13(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_get(%rip), %rcx
	movl	$141, %edx
	callq	__assert_fail@PLT
.LBB1_27:
	leaq	.L.str.12(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_get(%rip), %rcx
	movl	$143, %edx
	callq	__assert_fail@PLT
.LBB1_22:
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_range(%rip), %rcx
	movl	$214, %edx
	callq	__assert_fail@PLT
.LBB1_23:
	leaq	.L.str.9(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_range(%rip), %rcx
	movl	$216, %edx
	callq	__assert_fail@PLT
.LBB1_24:
	leaq	.L.str.11(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_range(%rip), %rcx
	movl	$224, %edx
	callq	__assert_fail@PLT
.LBB1_28:
	leaq	.L.str.1(%rip), %rdi
	leaq	.L.str.2(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.writer(%rip), %rcx
	movl	$44, %edx
	callq	__assert_fail@PLT
.LBB1_29:
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_clr_bit(%rip), %rcx
	movl	$297, %edx                      # imm = 0x129
	callq	__assert_fail@PLT
.LBB1_30:
	leaq	.L.str.13(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_clr_bit(%rip), %rcx
	movl	$298, %edx                      # imm = 0x12A
	callq	__assert_fail@PLT
.LBB1_31:
	leaq	.L.str.12(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_clr_bit(%rip), %rcx
	movl	$300, %edx                      # imm = 0x12C
	callq	__assert_fail@PLT
.LBB1_32:
	leaq	.L.str.3(%rip), %rdi
	leaq	.L.str.2(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.writer(%rip), %rcx
	movl	$48, %edx
	callq	__assert_fail@PLT
.LBB1_33:
	leaq	.L.str.4(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_bit(%rip), %rcx
	movl	$158, %edx
	callq	__assert_fail@PLT
.LBB1_34:
	leaq	.L.str.13(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_bit(%rip), %rcx
	movl	$159, %edx
	callq	__assert_fail@PLT
.LBB1_35:
	leaq	.L.str.12(%rip), %rdi
	leaq	.L.str.5(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.vbitmap_set_bit(%rip), %rcx
	movl	$161, %edx
	callq	__assert_fail@PLT
.LBB1_36:
	leaq	.L.str.1(%rip), %rdi
	leaq	.L.str.2(%rip), %rsi
	leaq	.L__PRETTY_FUNCTION__.writer(%rip), %rcx
	movl	$52, %edx
	callq	__assert_fail@PLT
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	cmpq	$11, %rdi
	je	.LBB2_1
# %bb.2:
	callq	writer@PLT
	jmp	.LBB2_3
.LBB2_1:
	callq	reader@PLT
.LBB2_3:
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	$104, %edi
	callq	malloc@PLT
	movq	g_bitmap@GOTPCREL(%rip), %r12
	movq	%rax, (%r12)
	movq	$704, 8(%rax)                   # imm = 0x2C0
	movq	$11, (%rax)
	xorl	%ecx, %ecx
.LBB3_1:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	xorl	%edx, %edx
	xchgq	%rdx, 16(%rax,%rcx,8)
	#APP
	#NO_APP
	incq	%rcx
	cmpq	(%rax), %rcx
	jb	.LBB3_1
# %bb.2:
	leaq	-128(%rbp), %rbx
	xorl	%r14d, %r14d
	movq	run@GOTPCREL(%rip), %r15
.LBB3_3:                                # =>This Inner Loop Header: Depth=1
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	movq	%r14, %rcx
	callq	pthread_create@PLT
	incq	%r14
	addq	$8, %rbx
	cmpq	$12, %r14
	jne	.LBB3_3
# %bb.4:
	xorl	%ebx, %ebx
.LBB3_5:                                # =>This Inner Loop Header: Depth=1
	movq	-128(%rbp,%rbx,8), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	incq	%rbx
	cmpq	$12, %rbx
	jne	.LBB3_5
# %bb.6:
	movq	(%r12), %rdi
	callq	free@PLT
	xorl	%eax, %eax
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        # -- End function
	.type	g_bitmap,@object                # @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.quad	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"set == 1"
	.size	.L.str.1, 9

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"C:/rc1111/src/libvsync/examples/eg_bitmap.c"
	.size	.L.str.2, 44

	.type	.L__PRETTY_FUNCTION__.writer,@object # @__PRETTY_FUNCTION__.writer
.L__PRETTY_FUNCTION__.writer:
	.asciz	"void writer(vsize_t)"
	.size	.L__PRETTY_FUNCTION__.writer, 21

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"set == 0"
	.size	.L.str.3, 9

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"bitmap"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/bitmap/bitmap.h"
	.size	.L.str.5, 53

	.type	.L__PRETTY_FUNCTION__.vbitmap_iter_init,@object # @__PRETTY_FUNCTION__.vbitmap_iter_init
.L__PRETTY_FUNCTION__.vbitmap_iter_init:
	.asciz	"void vbitmap_iter_init(vbitmap_t *, vbitmap_iter_t *)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_iter_init, 54

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"bitmap->maps_cnt > 0"
	.size	.L.str.7, 21

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_range,@object # @__PRETTY_FUNCTION__.vbitmap_set_range
.L__PRETTY_FUNCTION__.vbitmap_set_range:
	.asciz	"void vbitmap_set_range(vbitmap_t *, vsize_t, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_range, 54

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"to < bitmap->bit_cnt"
	.size	.L.str.9, 21

	.type	.L.str.11,@object               # @.str.11
.L.str.11:
	.asciz	"msb_slot < bitmap->maps_cnt"
	.size	.L.str.11, 28

	.type	.L.str.12,@object               # @.str.12
.L.str.12:
	.asciz	"idx < bitmap->maps_cnt"
	.size	.L.str.12, 23

	.type	.L__PRETTY_FUNCTION__.vbitmap_get,@object # @__PRETTY_FUNCTION__.vbitmap_get
.L__PRETTY_FUNCTION__.vbitmap_get:
	.asciz	"vbool_t vbitmap_get(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_get, 42

	.type	.L.str.13,@object               # @.str.13
.L.str.13:
	.asciz	"bit_idx < bitmap->bit_cnt"
	.size	.L.str.13, 26

	.type	.L__PRETTY_FUNCTION__.vbitmap_clr_bit,@object # @__PRETTY_FUNCTION__.vbitmap_clr_bit
.L__PRETTY_FUNCTION__.vbitmap_clr_bit:
	.asciz	"void vbitmap_clr_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_clr_bit, 43

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_bit,@object # @__PRETTY_FUNCTION__.vbitmap_set_bit
.L__PRETTY_FUNCTION__.vbitmap_set_bit:
	.asciz	"void vbitmap_set_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_bit, 43

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
