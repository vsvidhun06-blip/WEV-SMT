"""Author-written analysis for PLAN.md: which assert sites (header basename:line) still call __assert_fail in each
cell. Line/file arguments are resolved through phi/select of constants. Read-only on ll/; writes sites.csv, report.txt."""
import csv, os, re

OUT = os.path.dirname(os.path.abspath(__file__))
STR = re.compile(r'^(@[\w.$]+) = .*constant \[\d+ x i8\] c"((?:[^"\\]|\\.)*)"')
CALL = re.compile(r'call void @__assert_fail\((.*)\)')
DEF = re.compile(r'^\s*(%[\w.$]+) = (phi|select) ')


def split_args(s):
    out, depth, cur = [], 0, ''
    for ch in s:
        if ch in '([{<':
            depth += 1
        elif ch in ')]}>':
            depth -= 1
        if ch == ',' and depth == 0:
            out.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def unescape(s):
    return re.sub(r'\\([0-9A-Fa-f]{2})', lambda m: chr(int(m.group(1), 16)), s).replace('\x00', '')


def sites(path):
    text = open(path, encoding='utf-8', errors='replace').read().splitlines()
    strs, defs = {}, {}
    for line in text:
        m = STR.match(line)
        if m:
            strs[m.group(1)] = unescape(m.group(2))
        m = DEF.match(line)
        if m:
            defs[m.group(1)] = (m.group(2), line)

    def vals(tok, want, depth=0):
        tok = tok.split()[-1]
        if want == 'line' and re.fullmatch(r'-?\d+', tok):
            return {int(tok)}
        if want == 'file' and tok in strs:
            return {os.path.basename(strs[tok].replace('\\', '/'))}
        if tok in defs and depth < 20:
            kind, body = defs[tok]
            if kind == 'phi':
                toks = re.findall(r'\[\s*([^,\]]+),', body)
            else:
                toks = [t.split()[-1] for t in split_args(body.split(' select ', 1)[1])[1:]]
            r = set()
            for t in toks:
                r |= vals(t, want, depth + 1)
            return r
        return {'?'}

    found = set()
    for line in text:
        m = CALL.search(line)
        if not m:
            continue
        a = split_args(m.group(1))
        if len(a) < 3:
            continue
        for f in vals(a[1], 'file'):
            for ln in vals(a[2], 'line'):
                found.add('%s:%s' % (f, ln))
    return found


rows = []
for fn in sorted(os.listdir(os.path.join(OUT, 'll'))):
    if not fn.endswith('.ll'):
        continue
    f, tgt, at, nd, o, _ = fn.split('.')
    rows.append((f, tgt, at, nd, o, sites(os.path.join(OUT, 'll', fn))))
TARGET = {'bitmap.h:164', 'bitmap.h:303', 'ebr.h:248', 'atomicptr_stamped.h:86', 'atomicptr_stamped.h:87'}
with open(os.path.join(OUT, 'sites.csv'), 'w', newline='', encoding='utf-8') as fo:
    w = csv.writer(fo)
    w.writerow(['file', 'target', 'atomics', 'asserts', 'opt', 'site', 'is_target_site'])
    for f, tgt, at, nd, o, ss in rows:
        for s in sorted(ss):
            w.writerow([f, tgt, at, nd, o, s, int(s in TARGET)])
rep = []
OPTS = ['O0', 'O1', 'O2', 'O3', 'Os']
for f in sorted({r[0] for r in rows}):
    base = next(r[5] for r in rows if r[0] == f and r[1] == 'aarch64-linux-gnu' and r[2] == 'BUILTINS'
                and r[3] == 'on' and r[4] == 'O0')
    hdr = sorted(base)
    rep.append('== %s: %d assert sites at aarch64/BUILTINS/O0 (target sites marked *)' % (f, len(hdr)))
    for tgt in ('aarch64-linux-gnu', 'x86_64-linux-gnu'):
        for at in ('BUILTINS', 'DEFAULT'):
            cells = {r[4]: r[5] for r in rows if r[0] == f and r[1] == tgt and r[2] == at and r[3] == 'on'}
            rep.append('  %-18s %-8s %s' % (tgt, at, ' '.join('%-3s' % o for o in OPTS)))
            for s in hdr:
                if s in TARGET or any(s not in cells[o] for o in OPTS):
                    rep.append('    %s%-30s %s' % ('*' if s in TARGET else ' ', s,
                                                  ' '.join('%-3s' % ('yes' if s in cells[o] else '-') for o in OPTS)))
            extra = sorted(set().union(*cells.values()) - set(hdr))
            stable = [s for s in hdr if s not in TARGET and all(s in cells[o] for o in OPTS)]
            rep.append('     (%d other sites present at every level%s)' % (
                len(stable), '; sites absent at aarch64/BUILTINS/O0: ' + ','.join(extra) if extra else ''))
    nd = [r for r in rows if r[0] == f and r[3] == 'NDEBUG']
    rep.append('  NDEBUG cells with any __assert_fail call: %d of %d' % (sum(1 for r in nd if r[5]), len(nd)))
open(os.path.join(OUT, 'report.txt'), 'w', encoding='utf-8').write('\n'.join(rep) + '\n')
print('\n'.join(rep))
