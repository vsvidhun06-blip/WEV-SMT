#!/usr/bin/env bash
# Compiler grid (PLAN.md). Writes only inside OUT (hard-coded, quoted).
set -u
OUT='C:/Users/Vidhu/wev-fsen27-41/realcode-20261110T235600/outputs/compdiff-libvsync-20261111T013718Z'
S='C:/rc1111/src/libvsync'; PY='C:/rc1111/venv/Scripts/python.exe'
[ -d "$OUT/ll" ] && [ -d "$OUT/s" ] || { echo "output dirs missing"; exit 1; }
printf 'file\ttarget\tatomics\tasserts\topt\tkind\texit\tsecs\tcommand\n' > "$OUT/commands.tsv"
for f in eg_bitmap eg_unbounded_queue_lf_recycle eg_vebr; do
 for tgt in aarch64-linux-gnu x86_64-linux-gnu; do
  for at in BUILTINS DEFAULT; do
   for nd in on NDEBUG; do
    for o in O0 O1 O2 O3 Os; do
     base="$f.$tgt.$at.$nd.$o"
     for kind in ll s; do
      args=(-m ziglang cc -target "$tgt" "-$o" -fno-sanitize=all -g0 -w -S)
      [ "$kind" = ll ] && args+=(-emit-llvm)
      args+=(-I "$S/include" -I "$S/vatomic/include" -I "$S/test/include" -I "$S/verify/include" -D_GNU_SOURCE -pthread)
      [ "$at" = BUILTINS ] && args+=(-DVATOMIC_BUILTINS)
      [ "$nd" = NDEBUG ] && args+=(-DNDEBUG)
      args+=(-o "$OUT/$kind/$base.$kind" "$S/examples/$f.c")
      t0=$(date +%s%N)
      "$PY" "${args[@]}" 2> "$OUT/$kind/$base.err"; ec=$?
      t1=$(date +%s%N)
      printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\n' "$f" "$tgt" "$at" "$nd" "$o" "$kind" "$ec" "$(( (t1 - t0) / 1000000 ))" "$PY ${args[*]}" >> "$OUT/commands.tsv"
     done
    done
   done
  done
 done
done
echo RUN-DONE
