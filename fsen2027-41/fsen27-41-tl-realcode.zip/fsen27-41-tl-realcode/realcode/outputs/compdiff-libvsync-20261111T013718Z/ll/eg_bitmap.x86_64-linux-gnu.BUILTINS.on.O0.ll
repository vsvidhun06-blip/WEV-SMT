; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_bitmap.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_bitmap.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

%struct.vbitmap_iter_s = type { ptr, i64, i64 }
%struct.vbitmap_s = type { i64, i64, [0 x %struct.vatomic64_s] }
%struct.vatomic64_s = type { i64 }

@g_bitmap = global ptr null, align 8
@.str = private unnamed_addr constant [36 x i8] c"%zu bits were raised, expected %zu\0A\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"set == 1\00", align 1
@.str.2 = private unnamed_addr constant [44 x i8] c"C:/rc1111/src/libvsync/examples/eg_bitmap.c\00", align 1
@__PRETTY_FUNCTION__.writer = private unnamed_addr constant [21 x i8] c"void writer(vsize_t)\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"set == 0\00", align 1
@.str.4 = private unnamed_addr constant [7 x i8] c"bitmap\00", align 1
@.str.5 = private unnamed_addr constant [53 x i8] c"C:/rc1111/src/libvsync/include/vsync/bitmap/bitmap.h\00", align 1
@__PRETTY_FUNCTION__.vbitmap_iter_init = private unnamed_addr constant [54 x i8] c"void vbitmap_iter_init(vbitmap_t *, vbitmap_iter_t *)\00", align 1
@.str.6 = private unnamed_addr constant [5 x i8] c"iter\00", align 1
@.str.7 = private unnamed_addr constant [21 x i8] c"bitmap->maps_cnt > 0\00", align 1
@__PRETTY_FUNCTION__.vbitmap_set_range = private unnamed_addr constant [54 x i8] c"void vbitmap_set_range(vbitmap_t *, vsize_t, vsize_t)\00", align 1
@.str.8 = private unnamed_addr constant [11 x i8] c"from <= to\00", align 1
@.str.9 = private unnamed_addr constant [21 x i8] c"to < bitmap->bit_cnt\00", align 1
@.str.10 = private unnamed_addr constant [21 x i8] c"lsb_slot <= msb_slot\00", align 1
@.str.11 = private unnamed_addr constant [28 x i8] c"msb_slot < bitmap->maps_cnt\00", align 1
@.str.12 = private unnamed_addr constant [23 x i8] c"idx < bitmap->maps_cnt\00", align 1
@__PRETTY_FUNCTION__._vbitbmap_set_slot = private unnamed_addr constant [57 x i8] c"void _vbitbmap_set_slot(vbitmap_t *, vsize_t, vuint64_t)\00", align 1
@__PRETTY_FUNCTION__.vbitmap_get = private unnamed_addr constant [42 x i8] c"vbool_t vbitmap_get(vbitmap_t *, vsize_t)\00", align 1
@.str.13 = private unnamed_addr constant [26 x i8] c"bit_idx < bitmap->bit_cnt\00", align 1
@__PRETTY_FUNCTION__.vbitmap_clr_bit = private unnamed_addr constant [43 x i8] c"void vbitmap_clr_bit(vbitmap_t *, vsize_t)\00", align 1
@.str.14 = private unnamed_addr constant [20 x i8] c"(val & mask) == 0UL\00", align 1
@__PRETTY_FUNCTION__.vbitmap_set_bit = private unnamed_addr constant [43 x i8] c"void vbitmap_set_bit(vbitmap_t *, vsize_t)\00", align 1
@.str.15 = private unnamed_addr constant [21 x i8] c"(val & mask) == mask\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define void @reader() #0 {
  %1 = alloca i64, align 8
  %2 = alloca %struct.vbitmap_iter_s, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store i64 0, ptr %1, align 8
  call void @llvm.memset.p0.i64(ptr align 8 %2, i8 0, i64 24, i1 false)
  store i64 0, ptr %3, align 8
  store i64 693, ptr %4, align 8
  br label %5

5:                                                ; preds = %16, %0
  %6 = load i64, ptr %3, align 8
  %7 = load i64, ptr %4, align 8
  %8 = icmp ult i64 %6, %7
  br i1 %8, label %9, label %20

9:                                                ; preds = %5
  store i64 0, ptr %3, align 8
  %10 = load ptr, ptr @g_bitmap, align 8
  call void @vbitmap_iter_init(ptr noundef %10, ptr noundef %2)
  br label %11

11:                                               ; preds = %13, %9
  %12 = call zeroext i1 @vbitmap_iter_next(ptr noundef %2, ptr noundef %1)
  br i1 %12, label %13, label %16

13:                                               ; preds = %11
  %14 = load i64, ptr %3, align 8
  %15 = add i64 %14, 1
  store i64 %15, ptr %3, align 8
  br label %11, !llvm.loop !6

16:                                               ; preds = %11
  %17 = load i64, ptr %3, align 8
  %18 = load i64, ptr %4, align 8
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, i64 noundef %17, i64 noundef %18)
  br label %5, !llvm.loop !8

20:                                               ; preds = %5
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vbitmap_iter_init(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %7, label %8

7:                                                ; preds = %2
  br label %9

8:                                                ; preds = %2
  call void @__assert_fail(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef 314, ptr noundef @__PRETTY_FUNCTION__.vbitmap_iter_init) #7
  unreachable

9:                                                ; preds = %7
  %10 = load ptr, ptr %4, align 8
  %11 = icmp ne ptr %10, null
  br i1 %11, label %12, label %13

12:                                               ; preds = %9
  br label %14

13:                                               ; preds = %9
  call void @__assert_fail(ptr noundef @.str.6, ptr noundef @.str.5, i32 noundef 315, ptr noundef @__PRETTY_FUNCTION__.vbitmap_iter_init) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %3, align 8
  %16 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %15, i32 0, i32 0
  %17 = load i64, ptr %16, align 8
  %18 = icmp ugt i64 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %14
  br label %21

20:                                               ; preds = %14
  call void @__assert_fail(ptr noundef @.str.7, ptr noundef @.str.5, i32 noundef 316, ptr noundef @__PRETTY_FUNCTION__.vbitmap_iter_init) #7
  unreachable

21:                                               ; preds = %19
  %22 = load ptr, ptr %3, align 8
  %23 = load ptr, ptr %4, align 8
  %24 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %23, i32 0, i32 0
  store ptr %22, ptr %24, align 8
  %25 = load ptr, ptr %4, align 8
  %26 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %25, i32 0, i32 1
  store i64 0, ptr %26, align 8
  %27 = load ptr, ptr %3, align 8
  %28 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %27, i32 0, i32 2
  %29 = getelementptr inbounds [0 x %struct.vatomic64_s], ptr %28, i64 0, i64 0
  %30 = call i64 @vatomic64_read(ptr noundef %29)
  %31 = load ptr, ptr %4, align 8
  %32 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %31, i32 0, i32 2
  store i64 %30, ptr %32, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal zeroext i1 @vbitmap_iter_next(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca i1, align 1
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %13, i32 0, i32 2
  %15 = getelementptr inbounds [0 x %struct.vatomic64_s], ptr %14, i64 0, i64 0
  store ptr %15, ptr %6, align 8
  %16 = load ptr, ptr %4, align 8
  %17 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %16, i32 0, i32 0
  %18 = load ptr, ptr %17, align 8
  %19 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %18, i32 0, i32 0
  %20 = load i64, ptr %19, align 8
  store i64 %20, ptr %7, align 8
  store i64 0, ptr %8, align 8
  store i64 0, ptr %9, align 8
  store i64 0, ptr %10, align 8
  %21 = load ptr, ptr %4, align 8
  %22 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %21, i32 0, i32 2
  %23 = load i64, ptr %22, align 8
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %54

25:                                               ; preds = %2
  %26 = load ptr, ptr %4, align 8
  %27 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %26, i32 0, i32 1
  %28 = load i64, ptr %27, align 8
  %29 = add i64 %28, 1
  store i64 %29, ptr %9, align 8
  br label %30

30:                                               ; preds = %50, %25
  %31 = load i64, ptr %9, align 8
  %32 = load i64, ptr %7, align 8
  %33 = icmp ult i64 %31, %32
  br i1 %33, label %34, label %53

34:                                               ; preds = %30
  %35 = load ptr, ptr %6, align 8
  %36 = load i64, ptr %9, align 8
  %37 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %35, i64 %36
  %38 = call i64 @vatomic64_read(ptr noundef %37)
  %39 = load ptr, ptr %4, align 8
  %40 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %39, i32 0, i32 2
  store i64 %38, ptr %40, align 8
  %41 = load ptr, ptr %4, align 8
  %42 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %41, i32 0, i32 2
  %43 = load i64, ptr %42, align 8
  %44 = icmp ne i64 %43, 0
  br i1 %44, label %45, label %49

45:                                               ; preds = %34
  %46 = load i64, ptr %9, align 8
  %47 = load ptr, ptr %4, align 8
  %48 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %47, i32 0, i32 1
  store i64 %46, ptr %48, align 8
  br label %55

49:                                               ; preds = %34
  br label %50

50:                                               ; preds = %49
  %51 = load i64, ptr %9, align 8
  %52 = add i64 %51, 1
  store i64 %52, ptr %9, align 8
  br label %30, !llvm.loop !9

53:                                               ; preds = %30
  store i1 false, ptr %3, align 1
  br label %87

54:                                               ; preds = %2
  br label %55

55:                                               ; preds = %54, %45
  %56 = load ptr, ptr %4, align 8
  %57 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %56, i32 0, i32 2
  %58 = load i64, ptr %57, align 8
  %59 = call i64 @llvm.cttz.i64(i64 %58, i1 true)
  %60 = trunc i64 %59 to i32
  %61 = sext i32 %60 to i64
  store i64 %61, ptr %8, align 8
  %62 = load ptr, ptr %4, align 8
  %63 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %62, i32 0, i32 1
  %64 = load i64, ptr %63, align 8
  %65 = mul i64 64, %64
  %66 = load i64, ptr %8, align 8
  %67 = add i64 %65, %66
  store i64 %67, ptr %10, align 8
  %68 = load i64, ptr %10, align 8
  %69 = load ptr, ptr %4, align 8
  %70 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %69, i32 0, i32 0
  %71 = load ptr, ptr %70, align 8
  %72 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %71, i32 0, i32 1
  %73 = load i64, ptr %72, align 8
  %74 = icmp uge i64 %68, %73
  br i1 %74, label %75, label %76

75:                                               ; preds = %55
  store i1 false, ptr %3, align 1
  br label %87

76:                                               ; preds = %55
  %77 = load i64, ptr %10, align 8
  %78 = load ptr, ptr %5, align 8
  store i64 %77, ptr %78, align 8
  %79 = load i64, ptr %8, align 8
  %80 = urem i64 %79, 64
  %81 = shl i64 1, %80
  %82 = xor i64 %81, -1
  %83 = load ptr, ptr %4, align 8
  %84 = getelementptr inbounds nuw %struct.vbitmap_iter_s, ptr %83, i32 0, i32 2
  %85 = load i64, ptr %84, align 8
  %86 = and i64 %85, %82
  store i64 %86, ptr %84, align 8
  store i1 true, ptr %3, align 1
  br label %87

87:                                               ; preds = %76, %75, %53
  %88 = load i1, ptr %3, align 1
  ret i1 %88
}

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define void @writer(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  %3 = alloca i8, align 1
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  store i8 0, ptr %3, align 1
  %6 = load i64, ptr %2, align 8
  %7 = mul i64 %6, 64
  store i64 %7, ptr %4, align 8
  %8 = load i64, ptr %4, align 8
  %9 = add i64 %8, 64
  %10 = sub i64 %9, 1
  store i64 %10, ptr %5, align 8
  %11 = load ptr, ptr @g_bitmap, align 8
  %12 = load i64, ptr %4, align 8
  %13 = load i64, ptr %5, align 8
  call void @vbitmap_set_range(ptr noundef %11, i64 noundef %12, i64 noundef %13)
  %14 = load ptr, ptr @g_bitmap, align 8
  %15 = load i64, ptr %4, align 8
  %16 = call zeroext i1 @vbitmap_get(ptr noundef %14, i64 noundef %15)
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %3, align 1
  %18 = load i8, ptr %3, align 1
  %19 = trunc i8 %18 to i1
  %20 = zext i1 %19 to i32
  %21 = icmp eq i32 %20, 1
  br i1 %21, label %22, label %23

22:                                               ; preds = %1
  br label %24

23:                                               ; preds = %1
  call void @__assert_fail(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef 44, ptr noundef @__PRETTY_FUNCTION__.writer) #7
  unreachable

24:                                               ; preds = %22
  %25 = load ptr, ptr @g_bitmap, align 8
  %26 = load i64, ptr %4, align 8
  call void @vbitmap_clr_bit(ptr noundef %25, i64 noundef %26)
  %27 = load ptr, ptr @g_bitmap, align 8
  %28 = load i64, ptr %4, align 8
  %29 = call zeroext i1 @vbitmap_get(ptr noundef %27, i64 noundef %28)
  %30 = zext i1 %29 to i8
  store i8 %30, ptr %3, align 1
  %31 = load i8, ptr %3, align 1
  %32 = trunc i8 %31 to i1
  %33 = zext i1 %32 to i32
  %34 = icmp eq i32 %33, 0
  br i1 %34, label %35, label %36

35:                                               ; preds = %24
  br label %37

36:                                               ; preds = %24
  call void @__assert_fail(ptr noundef @.str.3, ptr noundef @.str.2, i32 noundef 48, ptr noundef @__PRETTY_FUNCTION__.writer) #7
  unreachable

37:                                               ; preds = %35
  %38 = load ptr, ptr @g_bitmap, align 8
  %39 = load i64, ptr %4, align 8
  call void @vbitmap_set_bit(ptr noundef %38, i64 noundef %39)
  %40 = load ptr, ptr @g_bitmap, align 8
  %41 = load i64, ptr %4, align 8
  %42 = call zeroext i1 @vbitmap_get(ptr noundef %40, i64 noundef %41)
  %43 = zext i1 %42 to i8
  store i8 %43, ptr %3, align 1
  %44 = load i8, ptr %3, align 1
  %45 = trunc i8 %44 to i1
  %46 = zext i1 %45 to i32
  %47 = icmp eq i32 %46, 1
  br i1 %47, label %48, label %49

48:                                               ; preds = %37
  br label %50

49:                                               ; preds = %37
  call void @__assert_fail(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef 52, ptr noundef @__PRETTY_FUNCTION__.writer) #7
  unreachable

50:                                               ; preds = %48
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vbitmap_set_range(ptr noundef %0, i64 noundef %1, i64 noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  store i64 0, ptr %7, align 8
  store i64 0, ptr %8, align 8
  store i64 0, ptr %9, align 8
  store i64 0, ptr %10, align 8
  store i64 0, ptr %11, align 8
  %13 = load ptr, ptr %4, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %17

16:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef 214, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_range) #7
  unreachable

17:                                               ; preds = %15
  %18 = load i64, ptr %5, align 8
  %19 = load i64, ptr %6, align 8
  %20 = icmp ule i64 %18, %19
  br i1 %20, label %21, label %22

21:                                               ; preds = %17
  br label %23

22:                                               ; preds = %17
  call void @__assert_fail(ptr noundef @.str.8, ptr noundef @.str.5, i32 noundef 215, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_range) #7
  unreachable

23:                                               ; preds = %21
  %24 = load i64, ptr %6, align 8
  %25 = load ptr, ptr %4, align 8
  %26 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %25, i32 0, i32 1
  %27 = load i64, ptr %26, align 8
  %28 = icmp ult i64 %24, %27
  br i1 %28, label %29, label %30

29:                                               ; preds = %23
  br label %31

30:                                               ; preds = %23
  call void @__assert_fail(ptr noundef @.str.9, ptr noundef @.str.5, i32 noundef 216, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_range) #7
  unreachable

31:                                               ; preds = %29
  %32 = load i64, ptr %5, align 8
  %33 = udiv i64 %32, 64
  store i64 %33, ptr %7, align 8
  %34 = load i64, ptr %6, align 8
  %35 = udiv i64 %34, 64
  store i64 %35, ptr %8, align 8
  %36 = load i64, ptr %5, align 8
  %37 = urem i64 %36, 64
  store i64 %37, ptr %9, align 8
  %38 = load i64, ptr %6, align 8
  %39 = urem i64 %38, 64
  store i64 %39, ptr %10, align 8
  %40 = load i64, ptr %7, align 8
  %41 = load i64, ptr %8, align 8
  %42 = icmp ule i64 %40, %41
  br i1 %42, label %43, label %44

43:                                               ; preds = %31
  br label %45

44:                                               ; preds = %31
  call void @__assert_fail(ptr noundef @.str.10, ptr noundef @.str.5, i32 noundef 223, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_range) #7
  unreachable

45:                                               ; preds = %43
  %46 = load i64, ptr %8, align 8
  %47 = load ptr, ptr %4, align 8
  %48 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %47, i32 0, i32 0
  %49 = load i64, ptr %48, align 8
  %50 = icmp ult i64 %46, %49
  br i1 %50, label %51, label %52

51:                                               ; preds = %45
  br label %53

52:                                               ; preds = %45
  call void @__assert_fail(ptr noundef @.str.11, ptr noundef @.str.5, i32 noundef 224, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_range) #7
  unreachable

53:                                               ; preds = %51
  %54 = load i64, ptr %7, align 8
  %55 = load i64, ptr %8, align 8
  %56 = icmp eq i64 %54, %55
  br i1 %56, label %57, label %64

57:                                               ; preds = %53
  %58 = load i64, ptr %9, align 8
  %59 = load i64, ptr %10, align 8
  %60 = call i64 @_vbitmap_range_mask(i64 noundef %58, i64 noundef %59)
  store i64 %60, ptr %11, align 8
  %61 = load ptr, ptr %4, align 8
  %62 = load i64, ptr %7, align 8
  %63 = load i64, ptr %11, align 8
  call void @_vbitbmap_set_slot(ptr noundef %61, i64 noundef %62, i64 noundef %63)
  br label %90

64:                                               ; preds = %53
  %65 = load i64, ptr %9, align 8
  %66 = call i64 @_vbitmap_lsb_mask(i64 noundef %65)
  store i64 %66, ptr %11, align 8
  %67 = load ptr, ptr %4, align 8
  %68 = load i64, ptr %7, align 8
  %69 = load i64, ptr %11, align 8
  call void @_vbitbmap_set_slot(ptr noundef %67, i64 noundef %68, i64 noundef %69)
  %70 = load i64, ptr %7, align 8
  %71 = add i64 %70, 1
  store i64 %71, ptr %12, align 8
  br label %72

72:                                               ; preds = %81, %64
  %73 = load i64, ptr %12, align 8
  %74 = load i64, ptr %8, align 8
  %75 = icmp ult i64 %73, %74
  br i1 %75, label %76, label %84

76:                                               ; preds = %72
  %77 = load ptr, ptr %4, align 8
  %78 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %77, i32 0, i32 2
  %79 = load i64, ptr %12, align 8
  %80 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %78, i64 0, i64 %79
  call void @vatomic64_write(ptr noundef %80, i64 noundef -1)
  br label %81

81:                                               ; preds = %76
  %82 = load i64, ptr %12, align 8
  %83 = add i64 %82, 1
  store i64 %83, ptr %12, align 8
  br label %72, !llvm.loop !10

84:                                               ; preds = %72
  %85 = load i64, ptr %10, align 8
  %86 = call i64 @_vbitmap_msb_mask(i64 noundef %85)
  store i64 %86, ptr %11, align 8
  %87 = load ptr, ptr %4, align 8
  %88 = load i64, ptr %8, align 8
  %89 = load i64, ptr %11, align 8
  call void @_vbitbmap_set_slot(ptr noundef %87, i64 noundef %88, i64 noundef %89)
  br label %90

90:                                               ; preds = %84, %57
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal zeroext i1 @vbitmap_get(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i8, align 1
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %9 = load ptr, ptr %3, align 8
  %10 = icmp ne ptr %9, null
  br i1 %10, label %11, label %12

11:                                               ; preds = %2
  br label %13

12:                                               ; preds = %2
  call void @__assert_fail(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef 140, ptr noundef @__PRETTY_FUNCTION__.vbitmap_get) #7
  unreachable

13:                                               ; preds = %11
  %14 = load i64, ptr %4, align 8
  %15 = load ptr, ptr %3, align 8
  %16 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %15, i32 0, i32 1
  %17 = load i64, ptr %16, align 8
  %18 = icmp ult i64 %14, %17
  br i1 %18, label %19, label %20

19:                                               ; preds = %13
  br label %21

20:                                               ; preds = %13
  call void @__assert_fail(ptr noundef @.str.13, ptr noundef @.str.5, i32 noundef 141, ptr noundef @__PRETTY_FUNCTION__.vbitmap_get) #7
  unreachable

21:                                               ; preds = %19
  %22 = load i64, ptr %4, align 8
  %23 = udiv i64 %22, 64
  store i64 %23, ptr %5, align 8
  %24 = load i64, ptr %5, align 8
  %25 = load ptr, ptr %3, align 8
  %26 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %25, i32 0, i32 0
  %27 = load i64, ptr %26, align 8
  %28 = icmp ult i64 %24, %27
  br i1 %28, label %29, label %30

29:                                               ; preds = %21
  br label %31

30:                                               ; preds = %21
  call void @__assert_fail(ptr noundef @.str.12, ptr noundef @.str.5, i32 noundef 143, ptr noundef @__PRETTY_FUNCTION__.vbitmap_get) #7
  unreachable

31:                                               ; preds = %29
  %32 = load i64, ptr %4, align 8
  %33 = urem i64 %32, 64
  %34 = shl i64 1, %33
  store i64 %34, ptr %6, align 8
  %35 = load ptr, ptr %3, align 8
  %36 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %35, i32 0, i32 2
  %37 = load i64, ptr %5, align 8
  %38 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %36, i64 0, i64 %37
  %39 = call i64 @vatomic64_read(ptr noundef %38)
  store i64 %39, ptr %7, align 8
  %40 = load i64, ptr %7, align 8
  %41 = load i64, ptr %6, align 8
  %42 = and i64 %40, %41
  %43 = load i64, ptr %6, align 8
  %44 = icmp eq i64 %42, %43
  %45 = zext i1 %44 to i8
  store i8 %45, ptr %8, align 1
  %46 = load i8, ptr %8, align 1
  %47 = trunc i8 %46 to i1
  ret i1 %47
}

; Function Attrs: cold noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vbitmap_clr_bit(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %8 = load ptr, ptr %3, align 8
  %9 = icmp ne ptr %8, null
  br i1 %9, label %10, label %11

10:                                               ; preds = %2
  br label %12

11:                                               ; preds = %2
  call void @__assert_fail(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef 297, ptr noundef @__PRETTY_FUNCTION__.vbitmap_clr_bit) #7
  unreachable

12:                                               ; preds = %10
  %13 = load i64, ptr %4, align 8
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %14, i32 0, i32 1
  %16 = load i64, ptr %15, align 8
  %17 = icmp ult i64 %13, %16
  br i1 %17, label %18, label %19

18:                                               ; preds = %12
  br label %20

19:                                               ; preds = %12
  call void @__assert_fail(ptr noundef @.str.13, ptr noundef @.str.5, i32 noundef 298, ptr noundef @__PRETTY_FUNCTION__.vbitmap_clr_bit) #7
  unreachable

20:                                               ; preds = %18
  %21 = load i64, ptr %4, align 8
  %22 = udiv i64 %21, 64
  store i64 %22, ptr %5, align 8
  %23 = load i64, ptr %5, align 8
  %24 = load ptr, ptr %3, align 8
  %25 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %24, i32 0, i32 0
  %26 = load i64, ptr %25, align 8
  %27 = icmp ult i64 %23, %26
  br i1 %27, label %28, label %29

28:                                               ; preds = %20
  br label %30

29:                                               ; preds = %20
  call void @__assert_fail(ptr noundef @.str.12, ptr noundef @.str.5, i32 noundef 300, ptr noundef @__PRETTY_FUNCTION__.vbitmap_clr_bit) #7
  unreachable

30:                                               ; preds = %28
  %31 = load i64, ptr %4, align 8
  %32 = urem i64 %31, 64
  %33 = shl i64 1, %32
  store i64 %33, ptr %6, align 8
  %34 = load ptr, ptr %3, align 8
  %35 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %34, i32 0, i32 2
  %36 = load i64, ptr %5, align 8
  %37 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %35, i64 0, i64 %36
  %38 = load i64, ptr %6, align 8
  %39 = xor i64 %38, -1
  %40 = call i64 @vatomic64_and_get(ptr noundef %37, i64 noundef %39)
  store i64 %40, ptr %7, align 8
  %41 = load i64, ptr %7, align 8
  %42 = load i64, ptr %6, align 8
  %43 = and i64 %41, %42
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %45, label %46

45:                                               ; preds = %30
  br label %47

46:                                               ; preds = %30
  call void @__assert_fail(ptr noundef @.str.14, ptr noundef @.str.5, i32 noundef 303, ptr noundef @__PRETTY_FUNCTION__.vbitmap_clr_bit) #7
  unreachable

47:                                               ; preds = %45
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vbitmap_set_bit(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %8 = load ptr, ptr %3, align 8
  %9 = icmp ne ptr %8, null
  br i1 %9, label %10, label %11

10:                                               ; preds = %2
  br label %12

11:                                               ; preds = %2
  call void @__assert_fail(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef 158, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_bit) #7
  unreachable

12:                                               ; preds = %10
  %13 = load i64, ptr %4, align 8
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %14, i32 0, i32 1
  %16 = load i64, ptr %15, align 8
  %17 = icmp ult i64 %13, %16
  br i1 %17, label %18, label %19

18:                                               ; preds = %12
  br label %20

19:                                               ; preds = %12
  call void @__assert_fail(ptr noundef @.str.13, ptr noundef @.str.5, i32 noundef 159, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_bit) #7
  unreachable

20:                                               ; preds = %18
  %21 = load i64, ptr %4, align 8
  %22 = udiv i64 %21, 64
  store i64 %22, ptr %5, align 8
  %23 = load i64, ptr %5, align 8
  %24 = load ptr, ptr %3, align 8
  %25 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %24, i32 0, i32 0
  %26 = load i64, ptr %25, align 8
  %27 = icmp ult i64 %23, %26
  br i1 %27, label %28, label %29

28:                                               ; preds = %20
  br label %30

29:                                               ; preds = %20
  call void @__assert_fail(ptr noundef @.str.12, ptr noundef @.str.5, i32 noundef 161, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_bit) #7
  unreachable

30:                                               ; preds = %28
  %31 = load i64, ptr %4, align 8
  %32 = urem i64 %31, 64
  %33 = shl i64 1, %32
  store i64 %33, ptr %6, align 8
  %34 = load ptr, ptr %3, align 8
  %35 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %34, i32 0, i32 2
  %36 = load i64, ptr %5, align 8
  %37 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %35, i64 0, i64 %36
  %38 = load i64, ptr %6, align 8
  %39 = call i64 @vatomic64_or_get(ptr noundef %37, i64 noundef %38)
  store i64 %39, ptr %7, align 8
  %40 = load i64, ptr %7, align 8
  %41 = load i64, ptr %6, align 8
  %42 = and i64 %40, %41
  %43 = load i64, ptr %6, align 8
  %44 = icmp eq i64 %42, %43
  br i1 %44, label %45, label %46

45:                                               ; preds = %30
  br label %47

46:                                               ; preds = %30
  call void @__assert_fail(ptr noundef @.str.15, ptr noundef @.str.5, i32 noundef 164, ptr noundef @__PRETTY_FUNCTION__.vbitmap_set_bit) #7
  unreachable

47:                                               ; preds = %45
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define ptr @run(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = ptrtoint ptr %4 to i64
  store i64 %5, ptr %3, align 8
  %6 = load i64, ptr %3, align 8
  %7 = icmp eq i64 %6, 11
  br i1 %7, label %8, label %9

8:                                                ; preds = %1
  call void @reader()
  br label %11

9:                                                ; preds = %1
  %10 = load i64, ptr %3, align 8
  call void @writer(i64 noundef %10)
  br label %11

11:                                               ; preds = %9, %8
  ret ptr null
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [12 x i64], align 16
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  %6 = call i64 @vbitmap_size(i64 noundef 704)
  store i64 %6, ptr %3, align 8
  %7 = load i64, ptr %3, align 8
  %8 = call noalias ptr @malloc(i64 noundef %7) #8
  store ptr %8, ptr @g_bitmap, align 8
  %9 = load ptr, ptr @g_bitmap, align 8
  call void @vbitmap_init(ptr noundef %9, i64 noundef 704, i1 noundef zeroext false)
  store i64 0, ptr %4, align 8
  br label %10

10:                                               ; preds = %19, %0
  %11 = load i64, ptr %4, align 8
  %12 = icmp ult i64 %11, 12
  br i1 %12, label %13, label %22

13:                                               ; preds = %10
  %14 = load i64, ptr %4, align 8
  %15 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %14
  %16 = load i64, ptr %4, align 8
  %17 = inttoptr i64 %16 to ptr
  %18 = call i32 @pthread_create(ptr noundef %15, ptr noundef null, ptr noundef @run, ptr noundef %17) #9
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %4, align 8
  %21 = add i64 %20, 1
  store i64 %21, ptr %4, align 8
  br label %10, !llvm.loop !11

22:                                               ; preds = %10
  store i64 0, ptr %5, align 8
  br label %23

23:                                               ; preds = %31, %22
  %24 = load i64, ptr %5, align 8
  %25 = icmp ult i64 %24, 12
  br i1 %25, label %26, label %34

26:                                               ; preds = %23
  %27 = load i64, ptr %5, align 8
  %28 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %27
  %29 = load i64, ptr %28, align 8
  %30 = call i32 @pthread_join(i64 noundef %29, ptr noundef null)
  br label %31

31:                                               ; preds = %26
  %32 = load i64, ptr %5, align 8
  %33 = add i64 %32, 1
  store i64 %33, ptr %5, align 8
  br label %23, !llvm.loop !12

34:                                               ; preds = %23
  %35 = load ptr, ptr @g_bitmap, align 8
  call void @free(ptr noundef %35) #9
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vbitmap_size(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  %3 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  %4 = load i64, ptr %2, align 8
  %5 = urem i64 %4, 64
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %7, label %10

7:                                                ; preds = %1
  %8 = load i64, ptr %2, align 8
  %9 = udiv i64 %8, 64
  br label %14

10:                                               ; preds = %1
  %11 = load i64, ptr %2, align 8
  %12 = udiv i64 %11, 64
  %13 = add i64 %12, 1
  br label %14

14:                                               ; preds = %10, %7
  %15 = phi i64 [ %9, %7 ], [ %13, %10 ]
  %16 = mul i64 %15, 8
  store i64 %16, ptr %3, align 8
  %17 = load i64, ptr %3, align 8
  %18 = add i64 16, %17
  ret i64 %18
}

; Function Attrs: nounwind allocsize(0)
declare noalias ptr @malloc(i64 noundef) #4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vbitmap_init(ptr noundef %0, i64 noundef %1, i1 noundef zeroext %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i8, align 1
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  %9 = zext i1 %2 to i8
  store i8 %9, ptr %6, align 1
  %10 = load i8, ptr %6, align 1
  %11 = trunc i8 %10 to i1
  %12 = zext i1 %11 to i64
  %13 = select i1 %11, i64 -1, i64 0
  store i64 %13, ptr %7, align 8
  %14 = load i64, ptr %5, align 8
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %15, i32 0, i32 1
  store i64 %14, ptr %16, align 8
  %17 = load i64, ptr %5, align 8
  %18 = urem i64 %17, 64
  %19 = icmp eq i64 %18, 0
  br i1 %19, label %20, label %23

20:                                               ; preds = %3
  %21 = load i64, ptr %5, align 8
  %22 = udiv i64 %21, 64
  br label %27

23:                                               ; preds = %3
  %24 = load i64, ptr %5, align 8
  %25 = udiv i64 %24, 64
  %26 = add i64 %25, 1
  br label %27

27:                                               ; preds = %23, %20
  %28 = phi i64 [ %22, %20 ], [ %26, %23 ]
  %29 = load ptr, ptr %4, align 8
  %30 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %29, i32 0, i32 0
  store i64 %28, ptr %30, align 8
  store i64 0, ptr %8, align 8
  br label %31

31:                                               ; preds = %43, %27
  %32 = load i64, ptr %8, align 8
  %33 = load ptr, ptr %4, align 8
  %34 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %33, i32 0, i32 0
  %35 = load i64, ptr %34, align 8
  %36 = icmp ult i64 %32, %35
  br i1 %36, label %37, label %46

37:                                               ; preds = %31
  %38 = load ptr, ptr %4, align 8
  %39 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %38, i32 0, i32 2
  %40 = load i64, ptr %8, align 8
  %41 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %39, i64 0, i64 %40
  %42 = load i64, ptr %7, align 8
  call void @vatomic64_init(ptr noundef %41, i64 noundef %42)
  br label %43

43:                                               ; preds = %37
  %44 = load i64, ptr %8, align 8
  %45 = add i64 %44, 1
  store i64 %45, ptr %8, align 8
  br label %31, !llvm.loop !13

46:                                               ; preds = %31
  ret void
}

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) #5

declare i32 @pthread_join(i64 noundef, ptr noundef) #2

; Function Attrs: nounwind
declare void @free(ptr noundef) #5

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !14
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %5, i32 0, i32 0
  %7 = load atomic i64, ptr %6 seq_cst, align 8
  store i64 %7, ptr %4, align 8
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %3, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !15
  %9 = load i64, ptr %3, align 8
  ret i64 %9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @_vbitmap_range_mask(i64 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store i64 %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %8 = load i64, ptr %3, align 8
  %9 = call i64 @_vbitmap_lsb_mask(i64 noundef %8)
  store i64 %9, ptr %5, align 8
  %10 = load i64, ptr %4, align 8
  %11 = call i64 @_vbitmap_msb_mask(i64 noundef %10)
  store i64 %11, ptr %6, align 8
  %12 = load i64, ptr %6, align 8
  %13 = load i64, ptr %5, align 8
  %14 = and i64 %12, %13
  store i64 %14, ptr %7, align 8
  %15 = load i64, ptr %7, align 8
  ret i64 %15
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @_vbitbmap_set_slot(ptr noundef %0, i64 noundef %1, i64 noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  %7 = load i64, ptr %5, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %8, i32 0, i32 0
  %10 = load i64, ptr %9, align 8
  %11 = icmp ult i64 %7, %10
  br i1 %11, label %12, label %13

12:                                               ; preds = %3
  br label %14

13:                                               ; preds = %3
  call void @__assert_fail(ptr noundef @.str.12, ptr noundef @.str.5, i32 noundef 176, ptr noundef @__PRETTY_FUNCTION__._vbitbmap_set_slot) #7
  unreachable

14:                                               ; preds = %12
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.vbitmap_s, ptr %15, i32 0, i32 2
  %17 = load i64, ptr %5, align 8
  %18 = getelementptr inbounds nuw [0 x %struct.vatomic64_s], ptr %16, i64 0, i64 %17
  %19 = load i64, ptr %6, align 8
  call void @vatomic64_or(ptr noundef %18, i64 noundef %19)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @_vbitmap_lsb_mask(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  %3 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  store i64 1, ptr %3, align 8
  %4 = load i64, ptr %3, align 8
  %5 = load i64, ptr %2, align 8
  %6 = shl i64 %4, %5
  store i64 %6, ptr %3, align 8
  %7 = load i64, ptr %3, align 8
  %8 = add i64 %7, -1
  store i64 %8, ptr %3, align 8
  %9 = load i64, ptr %3, align 8
  %10 = xor i64 %9, -1
  ret i64 %10
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_write(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !16
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !17
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @_vbitmap_msb_mask(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  %3 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  store i64 1, ptr %3, align 8
  %4 = load i64, ptr %3, align 8
  %5 = load i64, ptr %2, align 8
  %6 = shl i64 %4, %5
  store i64 %6, ptr %3, align 8
  %7 = load i64, ptr %3, align 8
  %8 = load i64, ptr %3, align 8
  %9 = sub i64 %8, 1
  %10 = add i64 %7, %9
  store i64 %10, ptr %3, align 8
  %11 = load i64, ptr %3, align 8
  ret i64 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_or(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  %7 = call i64 @vatomic64_get_or(ptr noundef %5, i64 noundef %6)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_get_or(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !18
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %8, i32 0, i32 0
  %10 = load i64, ptr %4, align 8
  store i64 %10, ptr %6, align 8
  %11 = load i64, ptr %6, align 8
  %12 = atomicrmw or ptr %9, i64 %11 seq_cst, align 8
  store i64 %12, ptr %7, align 8
  %13 = load i64, ptr %7, align 8
  store i64 %13, ptr %5, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !19
  %14 = load i64, ptr %5, align 8
  ret i64 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_and_get(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  %7 = call i64 @vatomic64_get_and(ptr noundef %5, i64 noundef %6)
  %8 = load i64, ptr %4, align 8
  %9 = and i64 %7, %8
  ret i64 %9
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_get_and(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !20
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %8, i32 0, i32 0
  %10 = load i64, ptr %4, align 8
  store i64 %10, ptr %6, align 8
  %11 = load i64, ptr %6, align 8
  %12 = atomicrmw and ptr %9, i64 %11 seq_cst, align 8
  store i64 %12, ptr %7, align 8
  %13 = load i64, ptr %7, align 8
  store i64 %13, ptr %5, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #9, !srcloc !21
  %14 = load i64, ptr %5, align 8
  ret i64 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_or_get(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  %7 = call i64 @vatomic64_get_or(ptr noundef %5, i64 noundef %6)
  %8 = load i64, ptr %4, align 8
  %9 = or i64 %7, %8
  ret i64 %9
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_init(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  call void @vatomic64_write(ptr noundef %5, i64 noundef %6)
  ret void
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #3 = { cold noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #4 = { nounwind allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #5 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #6 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { cold noreturn nounwind }
attributes #8 = { nounwind allocsize(0) }
attributes #9 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = !{i64 2147989958}
!15 = !{i64 2147989998}
!16 = !{i64 2147991362}
!17 = !{i64 2147991402}
!18 = !{i64 2147998352}
!19 = !{i64 2147998392}
!20 = !{i64 2147996792}
!21 = !{i64 2147996832}
