; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = local_unnamed_addr global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = local_unnamed_addr global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1

; Function Attrs: inlinehint nounwind optsize uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_lock(ptr noundef %0) #12
  ret void
}

; Function Attrs: inlinehint nounwind optsize uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #12
  ret void
}

; Function Attrs: mustprogress nounwind optsize willreturn uwtable
define void @free_cb(ptr noundef %0, ptr nocapture readnone %1) #1 {
  %3 = ptrtoint ptr %0 to i64
  %4 = add i64 %3, -16
  %5 = inttoptr i64 %4 to ptr
  tail call void @free(ptr noundef %5) #12
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind optsize uwtable
define void @retire_cb(ptr noundef initializes((16, 24), (32, 48)) %0, ptr nocapture readnone %1) local_unnamed_addr #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !5
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %5 = urem i64 %4, 3
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr @free_cb, ptr %7, align 8, !tbaa !9
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store ptr null, ptr %8, align 8, !tbaa !17
  store ptr null, ptr %3, align 8, !tbaa !18
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %9 = load atomic i64, ptr %6 seq_cst, align 8
  %10 = inttoptr i64 %9 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %11 = ptrtoint ptr %3 to i64
  br label %12

12:                                               ; preds = %12, %2
  %13 = phi ptr [ %10, %2 ], [ %19, %12 ]
  store ptr %13, ptr %3, align 8, !tbaa !21
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !22
  %14 = ptrtoint ptr %13 to i64
  %15 = cmpxchg ptr %6, i64 %14, i64 %11 release monotonic, align 8
  %16 = extractvalue { i64, i1 } %15, 1
  %17 = extractvalue { i64, i1 } %15, 0
  %18 = inttoptr i64 %17 to ptr
  %19 = select i1 %16, ptr %13, ptr %18
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !23
  %20 = icmp eq ptr %13, %19
  br i1 %20, label %21, label %12, !llvm.loop !24

21:                                               ; preds = %12
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !26
  %23 = atomicrmw add ptr %22, i64 1 monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !27
  ret void
}

; Function Attrs: mustprogress nounwind optsize willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #5 {
  tail call void @free(ptr noundef %0) #12
  ret void
}

; Function Attrs: nounwind optsize uwtable
define void @reclaim() local_unnamed_addr #4 {
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !28
  %1 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !29
  %2 = icmp eq i8 %1, 0
  br i1 %2, label %3, label %49

3:                                                ; preds = %0, %46
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !5
  fence seq_cst
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  %4 = load atomic i64, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %5 = add i64 %4, 2
  %6 = urem i64 %5, 3
  %7 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %6
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !30
  %8 = atomicrmw xchg ptr %7, i64 0 acquire, align 8
  %9 = inttoptr i64 %8 to ptr
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %10 = getelementptr inbounds nuw i8, ptr %7, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  store atomic i64 0, ptr %10 monotonic, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !34
  %12 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !41
  tail call void %11(ptr noundef %12) #12
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !42
  %14 = icmp eq ptr %13, null
  br i1 %14, label %26, label %15

15:                                               ; preds = %3, %23
  %16 = phi ptr [ %24, %23 ], [ %13, %3 ]
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 16
  br label %18

18:                                               ; preds = %18, %15
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  %19 = load atomic i64, ptr %17 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  %20 = icmp ne i64 %19, 0
  %21 = icmp ult i64 %19, %4
  %22 = select i1 %20, i1 %21, i1 false
  br i1 %22, label %18, label %23

23:                                               ; preds = %18
  %24 = load ptr, ptr %16, align 8, !tbaa !42
  %25 = icmp eq ptr %24, null
  br i1 %25, label %26, label %15, !llvm.loop !43

26:                                               ; preds = %23, %3
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !44
  %28 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !41
  tail call void %27(ptr noundef %28) #12
  %29 = add i64 %4, 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !45
  %30 = cmpxchg ptr @g_vebr, i64 %4, i64 %29 seq_cst seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !46
  %31 = icmp eq i64 %8, 0
  br i1 %31, label %46, label %32

32:                                               ; preds = %26, %32
  %33 = phi ptr [ %35, %32 ], [ %9, %26 ]
  %34 = phi i64 [ %40, %32 ], [ 0, %26 ]
  %35 = load ptr, ptr %33, align 8, !tbaa !18
  %36 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %37 = load ptr, ptr %36, align 8, !tbaa !9
  %38 = getelementptr inbounds nuw i8, ptr %33, i64 24
  %39 = load ptr, ptr %38, align 8, !tbaa !17
  tail call void %37(ptr noundef nonnull %33, ptr noundef %39) #12
  %40 = add i64 %34, 1
  %41 = icmp eq ptr %35, null
  br i1 %41, label %42, label %32, !llvm.loop !47

42:                                               ; preds = %32
  %43 = icmp eq i64 %40, 0
  br i1 %43, label %46, label %44

44:                                               ; preds = %42
  %45 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %40) #14
  br label %46

46:                                               ; preds = %26, %44, %42
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !28
  %47 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !29
  %48 = icmp eq i8 %47, 0
  br i1 %48, label %3, label %49, !llvm.loop !48

49:                                               ; preds = %46, %0
  ret void
}

; Function Attrs: nofree nounwind optsize
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #6

; Function Attrs: nounwind optsize uwtable
define noundef ptr @run(ptr noundef %0) #4 {
  %2 = alloca %struct.vebr_instance_s, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #13
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq ptr %0, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  tail call void @reclaim() #14
  br label %108

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !49
  store atomic i64 0, ptr %7 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store i32 0, ptr %8, align 8, !tbaa !51
  %9 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !34
  %10 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !41
  tail call void %9(ptr noundef %10) #12
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !54
  store ptr %11, ptr %2, align 8, !tbaa !55
  %12 = icmp eq ptr %11, null
  br i1 %12, label %15, label %13

13:                                               ; preds = %6
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store ptr %2, ptr %14, align 8, !tbaa !56
  br label %15

15:                                               ; preds = %6, %13
  store ptr %2, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !54
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store ptr null, ptr %16, align 8, !tbaa !56
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !57
  %18 = add i64 %17, 1
  store i64 %18, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !57
  %19 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !44
  %20 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !41
  call void %19(ptr noundef %20) #12
  %21 = load i32, ptr %8, align 8, !tbaa !51
  br label %39

22:                                               ; preds = %103
  %23 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !34
  %24 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !41
  call void %23(ptr noundef %24) #12
  %25 = load ptr, ptr %2, align 8, !tbaa !55
  %26 = load ptr, ptr %16, align 8, !tbaa !56
  %27 = icmp eq ptr %26, null
  br i1 %27, label %29, label %28

28:                                               ; preds = %22
  store ptr %25, ptr %26, align 8, !tbaa !55
  br label %30

29:                                               ; preds = %22
  store ptr %25, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !54
  br label %30

30:                                               ; preds = %29, %28
  %31 = icmp eq ptr %25, null
  br i1 %31, label %34, label %32

32:                                               ; preds = %30
  %33 = getelementptr inbounds nuw i8, ptr %25, i64 8
  store ptr %26, ptr %33, align 8, !tbaa !56
  br label %34

34:                                               ; preds = %30, %32
  %35 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !57
  %36 = add i64 %35, -1
  store i64 %36, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !57
  %37 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !44
  %38 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !41
  call void %37(ptr noundef %38) #12
  br label %108

39:                                               ; preds = %15, %103
  %40 = phi i32 [ %21, %15 ], [ %105, %103 ]
  %41 = phi i64 [ 0, %15 ], [ %106, %103 ]
  %42 = add i32 %40, 1
  store i32 %42, ptr %8, align 8, !tbaa !51
  %43 = icmp eq i32 %40, 0
  br i1 %43, label %44, label %46

44:                                               ; preds = %39
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !7
  %45 = load atomic i64, ptr @g_vebr seq_cst, align 128
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !58
  store atomic i64 %45, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !59
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !5
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !6
  br label %46

46:                                               ; preds = %39, %44
  br label %47

47:                                               ; preds = %66, %46
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %48 = load atomic i64, ptr @g_queue seq_cst, align 8
  %49 = inttoptr i64 %48 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %50 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %51 = getelementptr inbounds nuw i8, ptr %49, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %52 = load atomic i64, ptr %51 seq_cst, align 8
  %53 = inttoptr i64 %52 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %54 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %55 = icmp eq i64 %48, %54
  br i1 %55, label %56, label %66

56:                                               ; preds = %47
  %57 = icmp eq i64 %48, %50
  br i1 %57, label %58, label %62

58:                                               ; preds = %56
  %59 = icmp eq i64 %52, 0
  br i1 %59, label %72, label %60

60:                                               ; preds = %58
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !60
  %61 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %48, i64 %52 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  br label %66

62:                                               ; preds = %56
  %63 = load ptr, ptr %53, align 8, !tbaa !62
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !60
  %64 = cmpxchg ptr @g_queue, i64 %48, i64 %52 seq_cst seq_cst, align 8
  %65 = extractvalue { i64, i1 } %64, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  br i1 %65, label %67, label %66

66:                                               ; preds = %62, %60, %47
  br label %47

67:                                               ; preds = %62
  %68 = icmp eq i64 %48, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %68, label %70, label %69

69:                                               ; preds = %67
  call void @retire_cb(ptr noundef nonnull %49, ptr nonnull poison) #12, !callees !65
  br label %70

70:                                               ; preds = %67, %69
  %71 = icmp eq ptr %63, null
  br i1 %71, label %72, label %95

72:                                               ; preds = %58, %70
  %73 = call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #15
  store i64 %41, ptr %73, align 8, !tbaa !66
  %74 = call noalias dereferenceable_or_null(48) ptr @malloc(i64 noundef 48) #15
  %75 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef %3, i64 noundef %41) #14
  store ptr %73, ptr %74, align 8, !tbaa !62
  %76 = getelementptr inbounds nuw i8, ptr %74, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !68
  store atomic i64 0, ptr %76 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !69
  %77 = ptrtoint ptr %74 to i64
  br label %78

78:                                               ; preds = %92, %72
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %79 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  %80 = inttoptr i64 %79 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %82 = load atomic i64, ptr %81 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %83 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %84 = icmp eq i64 %79, %83
  br i1 %84, label %85, label %92

85:                                               ; preds = %78
  %86 = icmp eq i64 %82, 0
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13
  br i1 %86, label %87, label %90

87:                                               ; preds = %85
  %88 = cmpxchg ptr %81, i64 0, i64 %77 seq_cst seq_cst, align 8
  %89 = extractvalue { i64, i1 } %88, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  br i1 %89, label %93, label %92

90:                                               ; preds = %85
  %91 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %79, i64 %82 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  br label %92

92:                                               ; preds = %90, %87, %78
  br label %78

93:                                               ; preds = %87
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !60
  %94 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %79, i64 %77 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  br label %98

95:                                               ; preds = %70
  %96 = load i64, ptr %63, align 8, !tbaa !66
  %97 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %3, i64 noundef %96) #14
  call void @free(ptr noundef nonnull %63) #12
  br label %98

98:                                               ; preds = %95, %93
  %99 = load i32, ptr %8, align 8, !tbaa !51
  %100 = icmp eq i32 %99, 1
  br i1 %100, label %101, label %103

101:                                              ; preds = %98
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !58
  store atomic i64 0, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !59
  %102 = load i32, ptr %8, align 8, !tbaa !51
  br label %103

103:                                              ; preds = %98, %101
  %104 = phi i32 [ %102, %101 ], [ %99, %98 ]
  %105 = add i32 %104, -1
  store i32 %105, ptr %8, align 8, !tbaa !51
  %106 = add nuw nsw i64 %41, 1
  %107 = icmp eq i64 %106, 10000
  br i1 %107, label %22, label %39, !llvm.loop !70

108:                                              ; preds = %34, %5
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #13
  ret ptr null
}

; Function Attrs: mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: nounwind optsize uwtable
define noundef i32 @main() local_unnamed_addr #4 {
  %1 = alloca %struct.smr_lock_lib_s, align 8
  %2 = alloca [12 x i64], align 16
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %2) #13
  %3 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @g_lock, ptr noundef null) #12
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %1)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %1, ptr noundef nonnull align 8 dereferenceable(24) @g_lock_lib, i64 24, i1 false)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), i8 0, i64 16, i1 false)
  br label %4

4:                                                ; preds = %4, %0
  %5 = phi i64 [ 0, %0 ], [ %8, %4 ]
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !71
  store atomic i64 0, ptr %6 seq_cst, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !72
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !49
  store atomic i64 0, ptr %7 seq_cst, align 16
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  %8 = add nuw nsw i64 %5, 1
  %9 = icmp eq i64 %8, 3
  br i1 %9, label %10, label %4, !llvm.loop !73

10:                                               ; preds = %4
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !49
  store atomic i64 1, ptr @g_vebr seq_cst, align 128
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !50
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), ptr noundef nonnull readonly align 8 dereferenceable(24) %1, i64 24, i1 false), !tbaa.struct !74
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %1)
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), align 8, !tbaa !76
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !68
  store atomic i64 0, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 24) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !69
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !68
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr @g_queue monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !69
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !68
  store atomic i64 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64), ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) monotonic, align 8
  tail call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !69
  br label %11

11:                                               ; preds = %10, %11
  %12 = phi i64 [ 0, %10 ], [ %16, %11 ]
  %13 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %12
  %14 = inttoptr i64 %12 to ptr
  %15 = call i32 @pthread_create(ptr noundef nonnull %13, ptr noundef null, ptr noundef nonnull @run, ptr noundef %14) #12
  %16 = add nuw nsw i64 %12, 1
  %17 = icmp eq i64 %16, 12
  br i1 %17, label %21, label %11, !llvm.loop !78

18:                                               ; preds = %21
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !79
  store atomic i8 1, ptr @g_stop seq_cst, align 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !80
  %19 = load i64, ptr %2, align 16, !tbaa !81
  %20 = call i32 @pthread_join(i64 noundef %19, ptr noundef null) #12
  br label %28

21:                                               ; preds = %11, %21
  %22 = phi i64 [ %26, %21 ], [ 1, %11 ]
  %23 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %22
  %24 = load i64, ptr %23, align 8, !tbaa !81
  %25 = call i32 @pthread_join(i64 noundef %24, ptr noundef null) #12
  %26 = add nuw nsw i64 %22, 1
  %27 = icmp eq i64 %26, 12
  br i1 %27, label %18, label %21, !llvm.loop !82

28:                                               ; preds = %53, %18
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %29 = load atomic i64, ptr @g_queue seq_cst, align 8
  %30 = inttoptr i64 %29 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %31 = load atomic i64, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8) seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %32 = getelementptr inbounds nuw i8, ptr %30, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %33 = load atomic i64, ptr %32 seq_cst, align 8
  %34 = inttoptr i64 %33 to ptr
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %35 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %36 = icmp eq i64 %29, %35
  br i1 %36, label %37, label %53

37:                                               ; preds = %28
  %38 = icmp eq i64 %29, %31
  br i1 %38, label %39, label %43

39:                                               ; preds = %37
  %40 = icmp eq i64 %33, 0
  br i1 %40, label %54, label %41

41:                                               ; preds = %39
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !60
  %42 = cmpxchg ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 8), i64 %29, i64 %33 seq_cst seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  br label %53

43:                                               ; preds = %37
  %44 = load ptr, ptr %34, align 8, !tbaa !62
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !60
  %45 = cmpxchg ptr @g_queue, i64 %29, i64 %33 seq_cst seq_cst, align 8
  %46 = extractvalue { i64, i1 } %45, 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !61
  br i1 %46, label %47, label %53

47:                                               ; preds = %43
  %48 = icmp eq i64 %29, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %48, label %50, label %49

49:                                               ; preds = %47
  call void @free(ptr noundef nonnull %30) #12
  br label %50

50:                                               ; preds = %47, %49
  %51 = icmp eq ptr %44, null
  br i1 %51, label %54, label %52

52:                                               ; preds = %50
  call void @free(ptr noundef nonnull %44) #12
  br label %53

53:                                               ; preds = %52, %43, %41, %28
  br label %28, !llvm.loop !83

54:                                               ; preds = %50, %39
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %55 = load atomic i64, ptr @g_queue seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %56 = icmp eq i64 %55, 0
  br i1 %56, label %66, label %57

57:                                               ; preds = %54, %64
  %58 = phi i64 [ %61, %64 ], [ %55, %54 ]
  %59 = inttoptr i64 %58 to ptr
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !19
  %61 = load atomic i64, ptr %60 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !20
  %62 = icmp eq i64 %58, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16) to i64)
  br i1 %62, label %64, label %63

63:                                               ; preds = %57
  call void @free(ptr noundef nonnull %59) #12
  br label %64

64:                                               ; preds = %63, %57
  %65 = icmp eq i64 %61, 0
  br i1 %65, label %66, label %57, !llvm.loop !84

66:                                               ; preds = %64, %54
  br label %67

67:                                               ; preds = %66, %83
  %68 = phi i64 [ %84, %83 ], [ 0, %66 ]
  %69 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %68
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !30
  %70 = atomicrmw xchg ptr %69, i64 0 acquire, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !31
  %71 = getelementptr inbounds nuw i8, ptr %69, i64 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !32
  store atomic i64 0, ptr %71 monotonic, align 16
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #13, !srcloc !33
  %72 = icmp eq i64 %70, 0
  br i1 %72, label %83, label %73

73:                                               ; preds = %67
  %74 = inttoptr i64 %70 to ptr
  br label %75

75:                                               ; preds = %75, %73
  %76 = phi ptr [ %77, %75 ], [ %74, %73 ]
  %77 = load ptr, ptr %76, align 8, !tbaa !18
  %78 = getelementptr inbounds nuw i8, ptr %76, i64 16
  %79 = load ptr, ptr %78, align 8, !tbaa !9
  %80 = getelementptr inbounds nuw i8, ptr %76, i64 24
  %81 = load ptr, ptr %80, align 8, !tbaa !17
  call void %79(ptr noundef nonnull %76, ptr noundef %81) #12
  %82 = icmp eq ptr %77, null
  br i1 %82, label %83, label %75, !llvm.loop !47

83:                                               ; preds = %75, %67
  %84 = add nuw nsw i64 %68, 1
  %85 = icmp eq i64 %84, 3
  br i1 %85, label %86, label %67, !llvm.loop !85

86:                                               ; preds = %83
  %87 = call i32 @pthread_mutex_destroy(ptr noundef nonnull @g_lock) #12
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %2) #13
  ret i32 0
}

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind optsize
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: optsize
declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_destroy(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind optsize
declare i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #11

attributes #0 = { inlinehint nounwind optsize uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #1 = { mustprogress nounwind optsize willreturn uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nounwind optsize willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #4 = { nounwind optsize uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind optsize willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #6 = { nofree nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind optsize willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #8 = { nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #9 = { optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #10 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind optsize }
attributes #13 = { nounwind }
attributes #14 = { optsize }
attributes #15 = { nounwind optsize allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 2}
!4 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!5 = !{i64 2147989881}
!6 = !{i64 2147989921}
!7 = !{i64 2147990819}
!8 = !{i64 2147990859}
!9 = !{!10, !13, i64 16}
!10 = !{!"smr_node_s", !11, i64 0, !16, i64 8, !13, i64 16, !13, i64 24}
!11 = !{!"smr_node_core_s", !12, i64 0}
!12 = !{!"p1 _ZTS15smr_node_core_s", !13, i64 0}
!13 = !{!"any pointer", !14, i64 0}
!14 = !{!"omnipotent char", !15, i64 0}
!15 = !{!"Simple C/C++ TBAA"}
!16 = !{!"int", !14, i64 0}
!17 = !{!10, !13, i64 24}
!18 = !{!10, !12, i64 0}
!19 = !{i64 2147991287}
!20 = !{i64 2147991327}
!21 = !{!11, !12, i64 0}
!22 = !{i64 2147996557}
!23 = !{i64 2147996599}
!24 = distinct !{!24, !25}
!25 = !{!"llvm.loop.mustprogress"}
!26 = !{i64 2148002567}
!27 = !{i64 2148002607}
!28 = !{i64 2147990117}
!29 = !{i64 2147990157}
!30 = !{i64 2147994563}
!31 = !{i64 2147994603}
!32 = !{i64 2147992379}
!33 = !{i64 2147992419}
!34 = !{!35, !13, i64 72}
!35 = !{!"vebr_s", !36, i64 0, !14, i64 8, !38, i64 56, !40, i64 72}
!36 = !{!"vatomic64_s", !37, i64 0}
!37 = !{!"long", !14, i64 0}
!38 = !{!"dbl_list_s", !39, i64 0, !37, i64 8}
!39 = !{!"p1 _ZTS15dbl_list_node_s", !13, i64 0}
!40 = !{!"smr_lock_lib_s", !13, i64 0, !13, i64 8, !13, i64 16}
!41 = !{!35, !13, i64 88}
!42 = !{!39, !39, i64 0}
!43 = distinct !{!43, !25}
!44 = !{!35, !13, i64 80}
!45 = !{i64 2147995757}
!46 = !{i64 2147995799}
!47 = distinct !{!47, !25}
!48 = distinct !{!48, !25}
!49 = !{i64 2147992223}
!50 = !{i64 2147992263}
!51 = !{!52, !16, i64 24}
!52 = !{!"vebr_instance_s", !53, i64 0, !36, i64 16, !16, i64 24}
!53 = !{!"dbl_list_node_s", !39, i64 0, !39, i64 8}
!54 = !{!38, !39, i64 0}
!55 = !{!53, !39, i64 0}
!56 = !{!53, !39, i64 8}
!57 = !{!38, !37, i64 8}
!58 = !{i64 2147992301}
!59 = !{i64 2147992341}
!60 = !{i64 2147996397}
!61 = !{i64 2147996439}
!62 = !{!63, !13, i64 0}
!63 = !{!"vqueue_ub_node_s", !13, i64 0, !64, i64 8, !10, i64 16}
!64 = !{!"vatomicptr_s", !13, i64 0}
!65 = !{ptr @destroy_cb, ptr @retire_cb}
!66 = !{!67, !37, i64 0}
!67 = !{!"data_s", !37, i64 0}
!68 = !{i64 2147992847}
!69 = !{i64 2147992887}
!70 = distinct !{!70, !25}
!71 = !{i64 2147992691}
!72 = !{i64 2147992731}
!73 = distinct !{!73, !25}
!74 = !{i64 0, i64 8, !75, i64 8, i64 8, !75, i64 16, i64 8, !75}
!75 = !{!13, !13, i64 0}
!76 = !{!77, !13, i64 16}
!77 = !{!"vqueue_ub_s", !64, i64 0, !64, i64 8, !63, i64 16}
!78 = distinct !{!78, !25}
!79 = !{i64 2147991521}
!80 = !{i64 2147991561}
!81 = !{!37, !37, i64 0}
!82 = distinct !{!82, !25}
!83 = distinct !{!83, !25}
!84 = distinct !{!84, !25}
!85 = distinct !{!85, !25}
