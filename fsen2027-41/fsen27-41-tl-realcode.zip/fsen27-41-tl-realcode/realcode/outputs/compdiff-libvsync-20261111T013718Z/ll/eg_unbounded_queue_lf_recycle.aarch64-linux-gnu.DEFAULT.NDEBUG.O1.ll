; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, [112 x i8], %struct.vqueue_ub_node_s }
%struct.vatomicptr_s = type { ptr }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, [112 x i8] }

@local_pools = local_unnamed_addr global [12 x ptr] zeroinitializer, align 8
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 128
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1
@str = private unnamed_addr constant [15 x i8] c"New allocation\00", align 1
@str.4 = private unnamed_addr constant [19 x i8] c"Recycle allocation\00", align 1

; Function Attrs: nounwind uwtable
define void @destroy_pools() local_unnamed_addr #0 {
  br label %2

1:                                                ; preds = %15
  ret void

2:                                                ; preds = %0, %15
  %3 = phi i64 [ 0, %0 ], [ %16, %15 ]
  %4 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %3
  %5 = load ptr, ptr %4, align 8, !tbaa !6
  %6 = icmp eq ptr %5, null
  br i1 %6, label %15, label %7

7:                                                ; preds = %2, %7
  %8 = phi ptr [ %13, %7 ], [ %5, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 8
  %10 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %9) #10, !srcloc !11
  %11 = ptrtoint ptr %10 to i64
  %12 = and i64 %11, -128
  %13 = inttoptr i64 %12 to ptr
  tail call void @free(ptr noundef nonnull %8) #10
  %14 = icmp eq i64 %12, 0
  br i1 %14, label %15, label %7, !llvm.loop !12

15:                                               ; preds = %7, %2
  %16 = add nuw nsw i64 %3, 1
  %17 = icmp eq i64 %16, 12
  br i1 %17, label %1, label %2, !llvm.loop !14
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #3 {
  tail call void @free(ptr noundef %0) #10
  ret void
}

; Function Attrs: nounwind uwtable
define void @retire_cb(ptr noundef %0, ptr noundef %1) local_unnamed_addr #0 {
  %3 = ptrtoint ptr %1 to i64
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %4) #10, !srcloc !11
  %6 = ptrtoint ptr %5 to i64
  %7 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %3
  %8 = load ptr, ptr %7, align 8, !tbaa !6
  %9 = add i64 %6, 1
  %10 = ptrtoint ptr %8 to i64
  %11 = and i64 %9, 127
  %12 = or i64 %11, %10
  %13 = inttoptr i64 %12 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %13, ptr nonnull elementtype(ptr) %4) #10, !srcloc !15
  store ptr %0, ptr %7, align 8, !tbaa !6
  ret void
}

; Function Attrs: nounwind uwtable
define ptr @alloc_qnode(i64 noundef %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %0
  %3 = load ptr, ptr %2, align 8, !tbaa !6
  %4 = icmp eq ptr %3, null
  br i1 %4, label %11, label %5

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %7 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %6) #10, !srcloc !11
  %8 = ptrtoint ptr %7 to i64
  %9 = and i64 %8, -128
  %10 = inttoptr i64 %9 to ptr
  store ptr %10, ptr %2, align 8, !tbaa !6
  br label %13

11:                                               ; preds = %1
  %12 = tail call noalias align 128 dereferenceable_or_null(128) ptr @memalign(i64 noundef 128, i64 noundef 128) #11
  br label %13

13:                                               ; preds = %11, %5
  %14 = phi ptr [ @str, %11 ], [ @str.4, %5 ]
  %15 = phi ptr [ %12, %11 ], [ %3, %5 ]
  %16 = tail call i32 @puts(ptr nonnull dereferenceable(1) %14)
  ret ptr %15
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @memalign(i64 allocalign noundef, i64 noundef) local_unnamed_addr #5

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #0 {
  %2 = ptrtoint ptr %0 to i64
  %3 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %2
  br label %4

4:                                                ; preds = %1, %128
  %5 = phi i64 [ 0, %1 ], [ %129, %128 ]
  br label %7

6:                                                ; preds = %128
  ret ptr null

7:                                                ; preds = %47, %4
  %8 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %9 = ptrtoint ptr %8 to i64
  %10 = and i64 %9, -128
  %11 = inttoptr i64 %10 to ptr
  %12 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %13 = ptrtoint ptr %12 to i64
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %15 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %14) #10, !srcloc !11
  %16 = ptrtoint ptr %15 to i64
  %17 = and i64 %16, -128
  %18 = inttoptr i64 %17 to ptr
  %19 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %20 = ptrtoint ptr %19 to i64
  %21 = and i64 %20, -128
  %22 = icmp eq i64 %10, %21
  %23 = xor i64 %20, %9
  %24 = and i64 %23, 127
  %25 = icmp eq i64 %24, 0
  %26 = select i1 %22, i1 %25, i1 false
  br i1 %26, label %27, label %47

27:                                               ; preds = %7
  %28 = and i64 %13, -128
  %29 = icmp eq i64 %10, %28
  br i1 %29, label %30, label %38

30:                                               ; preds = %27
  %31 = icmp eq i64 %17, 0
  br i1 %31, label %61, label %32

32:                                               ; preds = %30
  %33 = add i64 %13, 1
  %34 = and i64 %33, 127
  %35 = or disjoint i64 %34, %17
  %36 = inttoptr i64 %35 to ptr
  %37 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %36, ptr %12, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %47

38:                                               ; preds = %27
  %39 = load ptr, ptr %18, align 128, !tbaa !17
  %40 = add i64 %9, 1
  %41 = and i64 %40, 127
  %42 = or disjoint i64 %17, %41
  %43 = inttoptr i64 %42 to ptr
  %44 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr %43, ptr %8, ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !16
  %45 = extractvalue { ptr, i32 } %44, 0
  %46 = icmp eq ptr %45, %8
  br i1 %46, label %48, label %47

47:                                               ; preds = %38, %32, %7
  br label %7

48:                                               ; preds = %38
  %49 = icmp eq i64 %10, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %49, label %59, label %50

50:                                               ; preds = %48
  %51 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %14) #10, !srcloc !11
  %52 = ptrtoint ptr %51 to i64
  %53 = load ptr, ptr %3, align 8, !tbaa !6
  %54 = add i64 %52, 1
  %55 = ptrtoint ptr %53 to i64
  %56 = and i64 %54, 127
  %57 = or i64 %56, %55
  %58 = inttoptr i64 %57 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %58, ptr nonnull elementtype(ptr) %14) #10, !srcloc !15
  store ptr %11, ptr %3, align 8, !tbaa !6
  br label %59

59:                                               ; preds = %48, %50
  %60 = icmp eq ptr %39, null
  br i1 %60, label %61, label %125

61:                                               ; preds = %30, %59
  %62 = tail call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #12
  store i64 %5, ptr %62, align 8, !tbaa !20
  %63 = load ptr, ptr %3, align 8, !tbaa !6
  %64 = icmp eq ptr %63, null
  br i1 %64, label %71, label %65

65:                                               ; preds = %61
  %66 = getelementptr inbounds nuw i8, ptr %63, i64 8
  %67 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %66) #10, !srcloc !11
  %68 = ptrtoint ptr %67 to i64
  %69 = and i64 %68, -128
  %70 = inttoptr i64 %69 to ptr
  store ptr %70, ptr %3, align 8, !tbaa !6
  br label %73

71:                                               ; preds = %61
  %72 = tail call noalias align 128 dereferenceable_or_null(128) ptr @memalign(i64 noundef 128, i64 noundef 128) #11
  br label %73

73:                                               ; preds = %65, %71
  %74 = phi ptr [ @str, %71 ], [ @str.4, %65 ]
  %75 = phi ptr [ %72, %71 ], [ %63, %65 ]
  %76 = tail call i32 @puts(ptr nonnull dereferenceable(1) %74)
  %77 = load i64, ptr %62, align 8, !tbaa !20
  %78 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %2, i64 noundef %77)
  store ptr %62, ptr %75, align 128, !tbaa !17
  %79 = getelementptr inbounds nuw i8, ptr %75, i64 8
  %80 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %79) #10, !srcloc !11
  %81 = ptrtoint ptr %80 to i64
  %82 = and i64 %81, 127
  %83 = inttoptr i64 %82 to ptr
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr %83, ptr nonnull elementtype(ptr) %79) #10, !srcloc !15
  %84 = ptrtoint ptr %75 to i64
  br label %85

85:                                               ; preds = %118, %73
  %86 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %87 = ptrtoint ptr %86 to i64
  %88 = and i64 %87, -128
  %89 = inttoptr i64 %88 to ptr
  %90 = getelementptr inbounds nuw i8, ptr %89, i64 8
  %91 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %90) #10, !srcloc !11
  %92 = ptrtoint ptr %91 to i64
  %93 = and i64 %92, -128
  %94 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %95 = ptrtoint ptr %94 to i64
  %96 = and i64 %95, -128
  %97 = icmp eq i64 %88, %96
  %98 = xor i64 %95, %87
  %99 = and i64 %98, 127
  %100 = icmp eq i64 %99, 0
  %101 = select i1 %97, i1 %100, i1 false
  br i1 %101, label %102, label %118

102:                                              ; preds = %85
  %103 = icmp eq i64 %93, 0
  br i1 %103, label %104, label %112

104:                                              ; preds = %102
  %105 = add nuw nsw i64 %92, 1
  %106 = and i64 %105, 127
  %107 = or i64 %106, %84
  %108 = inttoptr i64 %107 to ptr
  %109 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %108, ptr %91, ptr nonnull elementtype(ptr) %90) #10, !srcloc !16
  %110 = extractvalue { ptr, i32 } %109, 0
  %111 = icmp eq ptr %110, %91
  br i1 %111, label %119, label %118

112:                                              ; preds = %102
  %113 = add i64 %87, 1
  %114 = and i64 %113, 127
  %115 = or disjoint i64 %114, %93
  %116 = inttoptr i64 %115 to ptr
  %117 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %116, ptr %86, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %118

118:                                              ; preds = %112, %104, %85
  br label %85

119:                                              ; preds = %104
  %120 = add i64 %87, 1
  %121 = and i64 %120, 127
  %122 = or i64 %121, %84
  %123 = inttoptr i64 %122 to ptr
  %124 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %123, ptr %86, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %128

125:                                              ; preds = %59
  %126 = load i64, ptr %39, align 8, !tbaa !20
  %127 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.3, i64 noundef %2, i64 noundef %126)
  tail call void @free(ptr noundef nonnull %39) #10
  br label %128

128:                                              ; preds = %119, %125
  %129 = add nuw nsw i64 %5, 1
  %130 = icmp eq i64 %129, 100
  br i1 %130, label %6, label %4, !llvm.loop !23
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [12 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #10
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 136)) #10, !srcloc !24
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 128), ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !24
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 128), ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !24
  %2 = call i32 @pthread_create(ptr noundef nonnull %1, ptr noundef null, ptr noundef nonnull @run, ptr noundef null) #10
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %4 = call i32 @pthread_create(ptr noundef nonnull %3, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 1 to ptr)) #10
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %6 = call i32 @pthread_create(ptr noundef nonnull %5, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 2 to ptr)) #10
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %8 = call i32 @pthread_create(ptr noundef nonnull %7, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 3 to ptr)) #10
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %10 = call i32 @pthread_create(ptr noundef nonnull %9, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 4 to ptr)) #10
  %11 = getelementptr inbounds nuw i8, ptr %1, i64 40
  %12 = call i32 @pthread_create(ptr noundef nonnull %11, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 5 to ptr)) #10
  %13 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %14 = call i32 @pthread_create(ptr noundef nonnull %13, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 6 to ptr)) #10
  %15 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %16 = call i32 @pthread_create(ptr noundef nonnull %15, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 7 to ptr)) #10
  %17 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %18 = call i32 @pthread_create(ptr noundef nonnull %17, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 8 to ptr)) #10
  %19 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %20 = call i32 @pthread_create(ptr noundef nonnull %19, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 9 to ptr)) #10
  %21 = getelementptr inbounds nuw i8, ptr %1, i64 80
  %22 = call i32 @pthread_create(ptr noundef nonnull %21, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 10 to ptr)) #10
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 88
  %24 = call i32 @pthread_create(ptr noundef nonnull %23, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 11 to ptr)) #10
  %25 = load i64, ptr %1, align 8, !tbaa !25
  %26 = call i32 @pthread_join(i64 noundef %25, ptr noundef null) #10
  %27 = load i64, ptr %3, align 8, !tbaa !25
  %28 = call i32 @pthread_join(i64 noundef %27, ptr noundef null) #10
  %29 = load i64, ptr %5, align 8, !tbaa !25
  %30 = call i32 @pthread_join(i64 noundef %29, ptr noundef null) #10
  %31 = load i64, ptr %7, align 8, !tbaa !25
  %32 = call i32 @pthread_join(i64 noundef %31, ptr noundef null) #10
  %33 = load i64, ptr %9, align 8, !tbaa !25
  %34 = call i32 @pthread_join(i64 noundef %33, ptr noundef null) #10
  %35 = load i64, ptr %11, align 8, !tbaa !25
  %36 = call i32 @pthread_join(i64 noundef %35, ptr noundef null) #10
  %37 = load i64, ptr %13, align 8, !tbaa !25
  %38 = call i32 @pthread_join(i64 noundef %37, ptr noundef null) #10
  %39 = load i64, ptr %15, align 8, !tbaa !25
  %40 = call i32 @pthread_join(i64 noundef %39, ptr noundef null) #10
  %41 = load i64, ptr %17, align 8, !tbaa !25
  %42 = call i32 @pthread_join(i64 noundef %41, ptr noundef null) #10
  %43 = load i64, ptr %19, align 8, !tbaa !25
  %44 = call i32 @pthread_join(i64 noundef %43, ptr noundef null) #10
  %45 = load i64, ptr %21, align 8, !tbaa !25
  %46 = call i32 @pthread_join(i64 noundef %45, ptr noundef null) #10
  %47 = load i64, ptr %23, align 8, !tbaa !25
  %48 = call i32 @pthread_join(i64 noundef %47, ptr noundef null) #10
  br label %49

49:                                               ; preds = %95, %0
  %50 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %51 = ptrtoint ptr %50 to i64
  %52 = and i64 %51, -128
  %53 = inttoptr i64 %52 to ptr
  %54 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !11
  %55 = ptrtoint ptr %54 to i64
  %56 = getelementptr inbounds nuw i8, ptr %53, i64 8
  %57 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %56) #10, !srcloc !11
  %58 = ptrtoint ptr %57 to i64
  %59 = and i64 %58, -128
  %60 = inttoptr i64 %59 to ptr
  %61 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %62 = ptrtoint ptr %61 to i64
  %63 = and i64 %62, -128
  %64 = icmp eq i64 %52, %63
  %65 = xor i64 %62, %51
  %66 = and i64 %65, 127
  %67 = icmp eq i64 %66, 0
  %68 = select i1 %64, i1 %67, i1 false
  br i1 %68, label %69, label %95

69:                                               ; preds = %49
  %70 = and i64 %55, -128
  %71 = icmp eq i64 %52, %70
  br i1 %71, label %72, label %80

72:                                               ; preds = %69
  %73 = icmp eq i64 %59, 0
  br i1 %73, label %96, label %74

74:                                               ; preds = %72
  %75 = add i64 %55, 1
  %76 = and i64 %75, 127
  %77 = or disjoint i64 %76, %59
  %78 = inttoptr i64 %77 to ptr
  %79 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %78, ptr %54, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #10, !srcloc !16
  br label %95

80:                                               ; preds = %69
  %81 = load ptr, ptr %60, align 128, !tbaa !17
  %82 = add i64 %51, 1
  %83 = and i64 %82, 127
  %84 = or disjoint i64 %59, %83
  %85 = inttoptr i64 %84 to ptr
  %86 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr %85, ptr %50, ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !16
  %87 = extractvalue { ptr, i32 } %86, 0
  %88 = icmp eq ptr %87, %50
  br i1 %88, label %89, label %95

89:                                               ; preds = %80
  %90 = icmp eq i64 %52, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %90, label %92, label %91

91:                                               ; preds = %89
  call void @free(ptr noundef %53) #10
  br label %92

92:                                               ; preds = %89, %91
  %93 = icmp eq ptr %81, null
  br i1 %93, label %96, label %94

94:                                               ; preds = %92
  call void @free(ptr noundef nonnull %81) #10
  br label %95

95:                                               ; preds = %94, %80, %74, %49
  br label %49, !llvm.loop !26

96:                                               ; preds = %92, %72
  %97 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #10, !srcloc !11
  %98 = ptrtoint ptr %97 to i64
  %99 = and i64 %98, -128
  %100 = icmp eq i64 %99, 0
  br i1 %100, label %112, label %101

101:                                              ; preds = %96, %108
  %102 = phi i64 [ %110, %108 ], [ %99, %96 ]
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 8
  %105 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %104) #10, !srcloc !11
  %106 = icmp eq i64 %102, ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 128) to i64)
  br i1 %106, label %108, label %107

107:                                              ; preds = %101
  call void @free(ptr noundef nonnull %103) #10
  br label %108

108:                                              ; preds = %107, %101
  %109 = ptrtoint ptr %105 to i64
  %110 = and i64 %109, -128
  %111 = icmp eq i64 %110, 0
  br i1 %111, label %112, label %101, !llvm.loop !27

112:                                              ; preds = %108, %96
  br label %113

113:                                              ; preds = %112, %126
  %114 = phi i64 [ %127, %126 ], [ 0, %112 ]
  %115 = getelementptr inbounds nuw [12 x ptr], ptr @local_pools, i64 0, i64 %114
  %116 = load ptr, ptr %115, align 8, !tbaa !6
  %117 = icmp eq ptr %116, null
  br i1 %117, label %126, label %118

118:                                              ; preds = %113, %118
  %119 = phi ptr [ %124, %118 ], [ %116, %113 ]
  %120 = getelementptr inbounds nuw i8, ptr %119, i64 8
  %121 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %120) #10, !srcloc !11
  %122 = ptrtoint ptr %121 to i64
  %123 = and i64 %122, -128
  %124 = inttoptr i64 %123 to ptr
  call void @free(ptr noundef nonnull %119) #10
  %125 = icmp eq i64 %123, 0
  br i1 %125, label %126, label %118, !llvm.loop !12

126:                                              ; preds = %118, %113
  %127 = add nuw nsw i64 %114, 1
  %128 = icmp eq i64 %127, 12
  br i1 %128, label %129, label %113, !llvm.loop !14

129:                                              ; preds = %126
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #10
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #7

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #9

attributes #0 = { nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #3 = { mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized,aligned") allocsize(1) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #6 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #7 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #8 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #9 = { nofree nounwind }
attributes #10 = { nounwind }
attributes #11 = { nounwind allocsize(1) }
attributes #12 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{!7, !7, i64 0}
!7 = !{!"p1 _ZTS16vqueue_ub_node_s", !8, i64 0}
!8 = !{!"any pointer", !9, i64 0}
!9 = !{!"omnipotent char", !10, i64 0}
!10 = !{!"Simple C/C++ TBAA"}
!11 = !{i64 448069}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = distinct !{!14, !13}
!15 = !{i64 452459}
!16 = !{i64 518896, i64 518931, i64 518947, i64 518981, i64 519016, i64 519037, i64 519081, i64 519111}
!17 = !{!18, !8, i64 0}
!18 = !{!"vqueue_ub_node_s", !8, i64 0, !19, i64 8}
!19 = !{!"vatomicptr_s", !8, i64 0}
!20 = !{!21, !22, i64 0}
!21 = !{!"data_s", !22, i64 0}
!22 = !{!"long", !9, i64 0}
!23 = distinct !{!23, !13}
!24 = !{i64 453429}
!25 = !{!22, !22, i64 0}
!26 = distinct !{!26, !13}
!27 = distinct !{!27, !13}
