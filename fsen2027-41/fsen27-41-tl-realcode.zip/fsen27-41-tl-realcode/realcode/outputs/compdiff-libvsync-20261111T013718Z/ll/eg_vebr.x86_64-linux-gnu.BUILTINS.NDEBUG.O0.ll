; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i16, i16, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }
%struct.data_s = type { i64 }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  store ptr %5, ptr %3, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = call i32 @pthread_mutex_lock(ptr noundef %6) #5
  store i32 %7, ptr %4, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  store ptr %5, ptr %3, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = call i32 @pthread_mutex_unlock(ptr noundef %6) #5
  store i32 %7, ptr %4, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define void @free_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = ptrtoint ptr %6 to i64
  %8 = sub i64 %7, 16
  %9 = inttoptr i64 %8 to ptr
  store ptr %9, ptr %5, align 8
  %10 = load ptr, ptr %5, align 8
  call void @free(ptr noundef %10) #5
  %11 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: nounwind
declare void @free(ptr noundef) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define void @retire_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %6 = load ptr, ptr %4, align 8
  store ptr %6, ptr %5, align 8
  %7 = load ptr, ptr %5, align 8
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %8, i32 0, i32 2
  call void @vebr_retire(ptr noundef @g_vebr, ptr noundef %7, ptr noundef %9, ptr noundef @free_cb, ptr noundef null)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vebr_retire(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3, ptr noundef %4) #0 {
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  store ptr %0, ptr %6, align 8
  store ptr %1, ptr %7, align 8
  store ptr %2, ptr %8, align 8
  store ptr %3, ptr %9, align 8
  store ptr %4, ptr %10, align 8
  store i64 0, ptr %11, align 8
  store i64 0, ptr %12, align 8
  call void @vatomic_fence()
  %13 = load ptr, ptr %6, align 8
  %14 = getelementptr inbounds nuw %struct.vebr_s, ptr %13, i32 0, i32 0
  %15 = call i64 @vatomic64_read(ptr noundef %14)
  store i64 %15, ptr %11, align 8
  %16 = load i64, ptr %11, align 8
  %17 = urem i64 %16, 3
  store i64 %17, ptr %12, align 8
  %18 = load ptr, ptr %6, align 8
  %19 = getelementptr inbounds nuw %struct.vebr_s, ptr %18, i32 0, i32 1
  %20 = load i64, ptr %12, align 8
  %21 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %19, i64 0, i64 %20
  %22 = load ptr, ptr %8, align 8
  %23 = load ptr, ptr %9, align 8
  %24 = load ptr, ptr %10, align 8
  call void @smr_nodes_list_add(ptr noundef %21, ptr noundef %22, ptr noundef %23, ptr noundef %24)
  br label %25

25:                                               ; preds = %5
  br label %26

26:                                               ; preds = %25
  %27 = load ptr, ptr %7, align 8
  br label %28

28:                                               ; preds = %26
  br label %29

29:                                               ; preds = %28
  br label %30

30:                                               ; preds = %29
  br label %31

31:                                               ; preds = %30
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define void @destroy_cb(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  call void @free(ptr noundef %5) #5
  %6 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define void @reclaim() #0 {
  %1 = alloca i64, align 8
  br label %2

2:                                                ; preds = %13, %0
  %3 = call zeroext i8 @vatomic8_read(ptr noundef @g_stop)
  %4 = zext i8 %3 to i32
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %6, label %14

6:                                                ; preds = %2
  %7 = call i64 @vebr_recycle(ptr noundef @g_vebr)
  store i64 %7, ptr %1, align 8
  %8 = load i64, ptr %1, align 8
  %9 = icmp ugt i64 %8, 0
  br i1 %9, label %10, label %13

10:                                               ; preds = %6
  %11 = load i64, ptr %1, align 8
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, i64 noundef %11)
  br label %13

13:                                               ; preds = %10, %6
  br label %2, !llvm.loop !6

14:                                               ; preds = %2
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal zeroext i8 @vatomic8_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i8, align 1
  %4 = alloca i8, align 1
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !8
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomic8_s, ptr %5, i32 0, i32 0
  %7 = load atomic i8, ptr %6 seq_cst, align 1
  store i8 %7, ptr %4, align 1
  %8 = load i8, ptr %4, align 1
  store i8 %8, ptr %3, align 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !9
  %9 = load i8, ptr %3, align 1
  ret i8 %9
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vebr_recycle(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  store i64 0, ptr %4, align 8
  store i64 0, ptr %5, align 8
  store i64 0, ptr %6, align 8
  store i64 0, ptr %7, align 8
  store ptr null, ptr %8, align 8
  call void @vatomic_fence()
  %9 = load ptr, ptr %2, align 8
  %10 = getelementptr inbounds nuw %struct.vebr_s, ptr %9, i32 0, i32 0
  %11 = call i64 @vatomic64_read(ptr noundef %10)
  store i64 %11, ptr %5, align 8
  %12 = load i64, ptr %5, align 8
  %13 = add i64 %12, 2
  %14 = urem i64 %13, 3
  store i64 %14, ptr %4, align 8
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_s, ptr %15, i32 0, i32 1
  %17 = load i64, ptr %4, align 8
  %18 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %16, i64 0, i64 %17
  %19 = call ptr @smr_nodes_list_get_and_empty(ptr noundef %18)
  store ptr %19, ptr %8, align 8
  %20 = load ptr, ptr %2, align 8
  %21 = load i64, ptr %5, align 8
  %22 = call i64 @_vebr_sync_epochs(ptr noundef %20, i64 noundef %21, i1 noundef zeroext true)
  store i64 %22, ptr %7, align 8
  %23 = load ptr, ptr %2, align 8
  %24 = getelementptr inbounds nuw %struct.vebr_s, ptr %23, i32 0, i32 0
  %25 = load i64, ptr %5, align 8
  %26 = load i64, ptr %5, align 8
  %27 = add i64 %26, 1
  %28 = call i64 @vatomic64_cmpxchg(ptr noundef %24, i64 noundef %25, i64 noundef %27)
  store i64 %28, ptr %6, align 8
  %29 = load ptr, ptr %8, align 8
  %30 = icmp ne ptr %29, null
  br i1 %30, label %31, label %34

31:                                               ; preds = %1
  %32 = load ptr, ptr %8, align 8
  %33 = call i64 @smr_nodes_list_destroy(ptr noundef %32)
  store i64 %33, ptr %3, align 8
  br label %34

34:                                               ; preds = %31, %1
  %35 = load i64, ptr %3, align 8
  ret i64 %35
}

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define ptr @run(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.vebr_instance_s, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store ptr null, ptr %4, align 8
  %8 = load ptr, ptr %2, align 8
  %9 = ptrtoint ptr %8 to i64
  store i64 %9, ptr %5, align 8
  %10 = load i64, ptr %5, align 8
  %11 = icmp eq i64 %10, 0
  br i1 %11, label %12, label %13

12:                                               ; preds = %1
  call void @reclaim()
  br label %46

13:                                               ; preds = %1
  call void @vebr_register(ptr noundef @g_vebr, ptr noundef %3)
  store i64 0, ptr %6, align 8
  br label %14

14:                                               ; preds = %42, %13
  %15 = load i64, ptr %6, align 8
  %16 = icmp ult i64 %15, 10000
  br i1 %16, label %17, label %45

17:                                               ; preds = %14
  call void @vebr_enter(ptr noundef @g_vebr, ptr noundef %3)
  %18 = call ptr @vqueue_ub_deq(ptr noundef @g_queue, ptr noundef @retire_cb, ptr noundef %3)
  store ptr %18, ptr %4, align 8
  %19 = load ptr, ptr %4, align 8
  %20 = icmp eq ptr %19, null
  br i1 %20, label %21, label %34

21:                                               ; preds = %17
  %22 = call noalias ptr @malloc(i64 noundef 8) #6
  store ptr %22, ptr %4, align 8
  %23 = load i64, ptr %6, align 8
  %24 = load ptr, ptr %4, align 8
  %25 = getelementptr inbounds nuw %struct.data_s, ptr %24, i32 0, i32 0
  store i64 %23, ptr %25, align 8
  %26 = call noalias ptr @malloc(i64 noundef 48) #6
  store ptr %26, ptr %7, align 8
  %27 = load i64, ptr %5, align 8
  %28 = load ptr, ptr %4, align 8
  %29 = getelementptr inbounds nuw %struct.data_s, ptr %28, i32 0, i32 0
  %30 = load i64, ptr %29, align 8
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i64 noundef %27, i64 noundef %30)
  %32 = load ptr, ptr %7, align 8
  %33 = load ptr, ptr %4, align 8
  call void @vqueue_ub_enq(ptr noundef @g_queue, ptr noundef %32, ptr noundef %33)
  br label %41

34:                                               ; preds = %17
  %35 = load i64, ptr %5, align 8
  %36 = load ptr, ptr %4, align 8
  %37 = getelementptr inbounds nuw %struct.data_s, ptr %36, i32 0, i32 0
  %38 = load i64, ptr %37, align 8
  %39 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i64 noundef %35, i64 noundef %38)
  %40 = load ptr, ptr %4, align 8
  call void @free(ptr noundef %40) #5
  br label %41

41:                                               ; preds = %34, %21
  call void @vebr_exit(ptr noundef @g_vebr, ptr noundef %3)
  br label %42

42:                                               ; preds = %41
  %43 = load i64, ptr %6, align 8
  %44 = add i64 %43, 1
  store i64 %44, ptr %6, align 8
  br label %14, !llvm.loop !10

45:                                               ; preds = %14
  call void @vebr_deregister(ptr noundef @g_vebr, ptr noundef %3)
  br label %46

46:                                               ; preds = %45, %12
  ret ptr null
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vebr_register(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %5, i32 0, i32 1
  call void @vatomic64_init(ptr noundef %6, i64 noundef 0)
  %7 = load ptr, ptr %4, align 8
  %8 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %7, i32 0, i32 2
  store i32 0, ptr %8, align 8
  %9 = load ptr, ptr %3, align 8
  %10 = getelementptr inbounds nuw %struct.vebr_s, ptr %9, i32 0, i32 3
  %11 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %10, i32 0, i32 0
  %12 = load ptr, ptr %11, align 8
  %13 = load ptr, ptr %3, align 8
  %14 = getelementptr inbounds nuw %struct.vebr_s, ptr %13, i32 0, i32 3
  %15 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %14, i32 0, i32 2
  %16 = load ptr, ptr %15, align 8
  call void %12(ptr noundef %16)
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds nuw %struct.vebr_s, ptr %17, i32 0, i32 2
  %19 = load ptr, ptr %4, align 8
  %20 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %19, i32 0, i32 0
  call void @dbl_list_add(ptr noundef %18, ptr noundef %20)
  %21 = load ptr, ptr %3, align 8
  %22 = getelementptr inbounds nuw %struct.vebr_s, ptr %21, i32 0, i32 3
  %23 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %22, i32 0, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = load ptr, ptr %3, align 8
  %26 = getelementptr inbounds nuw %struct.vebr_s, ptr %25, i32 0, i32 3
  %27 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %26, i32 0, i32 2
  %28 = load ptr, ptr %27, align 8
  call void %24(ptr noundef %28)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vebr_enter(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  store i64 0, ptr %5, align 8
  %6 = load ptr, ptr %4, align 8
  %7 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %6, i32 0, i32 2
  %8 = load i32, ptr %7, align 8
  %9 = add i32 %8, 1
  store i32 %9, ptr %7, align 8
  %10 = load ptr, ptr %4, align 8
  %11 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %10, i32 0, i32 2
  %12 = load i32, ptr %11, align 8
  %13 = icmp eq i32 %12, 1
  br i1 %13, label %14, label %21

14:                                               ; preds = %2
  %15 = load ptr, ptr %3, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_s, ptr %15, i32 0, i32 0
  %17 = call i64 @vatomic64_read(ptr noundef %16)
  store i64 %17, ptr %5, align 8
  %18 = load ptr, ptr %4, align 8
  %19 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %18, i32 0, i32 1
  %20 = load i64, ptr %5, align 8
  call void @vatomic64_write_rel(ptr noundef %19, i64 noundef %20)
  call void @vatomic_fence()
  br label %21

21:                                               ; preds = %14, %2
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @vqueue_ub_deq(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store ptr null, ptr %9, align 8
  store ptr null, ptr %10, align 8
  store ptr null, ptr %11, align 8
  br label %12

12:                                               ; preds = %3, %67
  %13 = load ptr, ptr %5, align 8
  %14 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %13, i32 0, i32 0
  %15 = call ptr @vatomicptr_read(ptr noundef %14)
  store ptr %15, ptr %8, align 8
  %16 = load ptr, ptr %5, align 8
  %17 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %16, i32 0, i32 1
  %18 = call ptr @vatomicptr_read(ptr noundef %17)
  store ptr %18, ptr %9, align 8
  %19 = load ptr, ptr %8, align 8
  %20 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %19, i32 0, i32 1
  %21 = call ptr @vatomicptr_read(ptr noundef %20)
  store ptr %21, ptr %10, align 8
  %22 = load ptr, ptr %8, align 8
  %23 = load ptr, ptr %5, align 8
  %24 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %23, i32 0, i32 0
  %25 = call ptr @vatomicptr_read(ptr noundef %24)
  %26 = icmp eq ptr %22, %25
  br i1 %26, label %27, label %66

27:                                               ; preds = %12
  %28 = load ptr, ptr %8, align 8
  %29 = load ptr, ptr %9, align 8
  %30 = icmp eq ptr %28, %29
  br i1 %30, label %31, label %41

31:                                               ; preds = %27
  %32 = load ptr, ptr %10, align 8
  %33 = icmp eq ptr %32, null
  br i1 %33, label %34, label %35

34:                                               ; preds = %31
  store ptr null, ptr %4, align 8
  br label %68

35:                                               ; preds = %31
  call void @verification_ignore()
  %36 = load ptr, ptr %5, align 8
  %37 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %36, i32 0, i32 1
  %38 = load ptr, ptr %9, align 8
  %39 = load ptr, ptr %10, align 8
  %40 = call ptr @vatomicptr_cmpxchg(ptr noundef %37, ptr noundef %38, ptr noundef %39)
  br label %65

41:                                               ; preds = %27
  %42 = load ptr, ptr %10, align 8
  %43 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %42, i32 0, i32 0
  %44 = load ptr, ptr %43, align 8
  store ptr %44, ptr %11, align 8
  %45 = load ptr, ptr %5, align 8
  %46 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %45, i32 0, i32 0
  %47 = load ptr, ptr %8, align 8
  %48 = load ptr, ptr %10, align 8
  %49 = call ptr @vatomicptr_cmpxchg(ptr noundef %46, ptr noundef %47, ptr noundef %48)
  %50 = load ptr, ptr %8, align 8
  %51 = icmp eq ptr %49, %50
  br i1 %51, label %52, label %63

52:                                               ; preds = %41
  %53 = load ptr, ptr %8, align 8
  %54 = load ptr, ptr %5, align 8
  %55 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %54, i32 0, i32 2
  %56 = icmp ne ptr %53, %55
  br i1 %56, label %57, label %61

57:                                               ; preds = %52
  %58 = load ptr, ptr %6, align 8
  %59 = load ptr, ptr %8, align 8
  %60 = load ptr, ptr %7, align 8
  call void %58(ptr noundef %59, ptr noundef %60)
  br label %61

61:                                               ; preds = %57, %52
  %62 = load ptr, ptr %11, align 8
  store ptr %62, ptr %4, align 8
  br label %68

63:                                               ; preds = %41
  call void @verification_ignore()
  br label %64

64:                                               ; preds = %63
  br label %65

65:                                               ; preds = %64, %35
  br label %67

66:                                               ; preds = %12
  call void @verification_ignore()
  br label %67

67:                                               ; preds = %66, %65
  br label %12

68:                                               ; preds = %61, %34
  %69 = load ptr, ptr %4, align 8
  ret ptr %69
}

; Function Attrs: nounwind allocsize(0)
declare noalias ptr @malloc(i64 noundef) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vqueue_ub_enq(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store i8 0, ptr %9, align 1
  %10 = load ptr, ptr %6, align 8
  %11 = load ptr, ptr %5, align 8
  %12 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %11, i32 0, i32 0
  store ptr %10, ptr %12, align 8
  %13 = load ptr, ptr %5, align 8
  %14 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %13, i32 0, i32 1
  call void @vatomicptr_write_rlx(ptr noundef %14, ptr noundef null)
  br label %15

15:                                               ; preds = %3, %59
  %16 = load ptr, ptr %4, align 8
  %17 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %16, i32 0, i32 1
  %18 = call ptr @vatomicptr_read(ptr noundef %17)
  store ptr %18, ptr %7, align 8
  %19 = load ptr, ptr %7, align 8
  %20 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %19, i32 0, i32 1
  %21 = call ptr @vatomicptr_read(ptr noundef %20)
  store ptr %21, ptr %8, align 8
  %22 = load ptr, ptr %7, align 8
  %23 = load ptr, ptr %4, align 8
  %24 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %23, i32 0, i32 1
  %25 = call ptr @vatomicptr_read(ptr noundef %24)
  %26 = icmp eq ptr %22, %25
  br i1 %26, label %27, label %58

27:                                               ; preds = %15
  %28 = load ptr, ptr %8, align 8
  %29 = icmp eq ptr %28, null
  br i1 %29, label %30, label %51

30:                                               ; preds = %27
  %31 = load ptr, ptr %7, align 8
  %32 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %31, i32 0, i32 1
  %33 = load ptr, ptr %8, align 8
  %34 = load ptr, ptr %5, align 8
  %35 = call ptr @vatomicptr_cmpxchg(ptr noundef %32, ptr noundef %33, ptr noundef %34)
  %36 = load ptr, ptr %8, align 8
  %37 = icmp eq ptr %35, %36
  br i1 %37, label %38, label %49

38:                                               ; preds = %30
  %39 = load ptr, ptr %4, align 8
  %40 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %39, i32 0, i32 1
  %41 = load ptr, ptr %7, align 8
  %42 = load ptr, ptr %5, align 8
  %43 = call ptr @vatomicptr_cmpxchg(ptr noundef %40, ptr noundef %41, ptr noundef %42)
  %44 = load ptr, ptr %7, align 8
  %45 = icmp eq ptr %43, %44
  %46 = zext i1 %45 to i8
  store i8 %46, ptr %9, align 1
  %47 = load i8, ptr %9, align 1
  %48 = trunc i8 %47 to i1
  call void @verification_assume(i1 noundef zeroext %48)
  ret void

49:                                               ; preds = %30
  call void @verification_ignore()
  br label %50

50:                                               ; preds = %49
  br label %57

51:                                               ; preds = %27
  call void @verification_ignore()
  %52 = load ptr, ptr %4, align 8
  %53 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %52, i32 0, i32 1
  %54 = load ptr, ptr %7, align 8
  %55 = load ptr, ptr %8, align 8
  %56 = call ptr @vatomicptr_cmpxchg(ptr noundef %53, ptr noundef %54, ptr noundef %55)
  br label %57

57:                                               ; preds = %51, %50
  br label %59

58:                                               ; preds = %15
  call void @verification_ignore()
  br label %59

59:                                               ; preds = %58, %57
  br label %15
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vebr_exit(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %5, i32 0, i32 2
  %7 = load i32, ptr %6, align 8
  %8 = icmp eq i32 %7, 1
  br i1 %8, label %9, label %12

9:                                                ; preds = %2
  %10 = load ptr, ptr %4, align 8
  %11 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %10, i32 0, i32 1
  call void @vatomic64_write_rel(ptr noundef %11, i64 noundef 0)
  br label %12

12:                                               ; preds = %9, %2
  %13 = load ptr, ptr %4, align 8
  %14 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %13, i32 0, i32 2
  %15 = load i32, ptr %14, align 8
  %16 = add i32 %15, -1
  store i32 %16, ptr %14, align 8
  br label %17

17:                                               ; preds = %12
  br label %18

18:                                               ; preds = %17
  %19 = load ptr, ptr %3, align 8
  br label %20

20:                                               ; preds = %18
  br label %21

21:                                               ; preds = %20
  br label %22

22:                                               ; preds = %21
  br label %23

23:                                               ; preds = %22
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vebr_deregister(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.vebr_s, ptr %5, i32 0, i32 3
  %7 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %6, i32 0, i32 0
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %3, align 8
  %10 = getelementptr inbounds nuw %struct.vebr_s, ptr %9, i32 0, i32 3
  %11 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %10, i32 0, i32 2
  %12 = load ptr, ptr %11, align 8
  call void %8(ptr noundef %12)
  %13 = load ptr, ptr %3, align 8
  %14 = getelementptr inbounds nuw %struct.vebr_s, ptr %13, i32 0, i32 2
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %15, i32 0, i32 0
  call void @dbl_list_rem(ptr noundef %14, ptr noundef %16)
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds nuw %struct.vebr_s, ptr %17, i32 0, i32 3
  %19 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %18, i32 0, i32 1
  %20 = load ptr, ptr %19, align 8
  %21 = load ptr, ptr %3, align 8
  %22 = getelementptr inbounds nuw %struct.vebr_s, ptr %21, i32 0, i32 3
  %23 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %22, i32 0, i32 2
  %24 = load ptr, ptr %23, align 8
  call void %20(ptr noundef %24)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [12 x i64], align 16
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  store ptr null, ptr %3, align 8
  %7 = call i32 @pthread_mutex_init(ptr noundef @g_lock, ptr noundef null) #5
  store i32 %7, ptr %4, align 4
  call void @vebr_init(ptr noundef @g_vebr, ptr noundef byval(%struct.smr_lock_lib_s) align 8 @g_lock_lib)
  call void @vqueue_ub_init(ptr noundef @g_queue)
  store i64 0, ptr %5, align 8
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i64, ptr %5, align 8
  %10 = icmp ult i64 %9, 12
  br i1 %10, label %11, label %20

11:                                               ; preds = %8
  %12 = load i64, ptr %5, align 8
  %13 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %12
  %14 = load i64, ptr %5, align 8
  %15 = inttoptr i64 %14 to ptr
  %16 = call i32 @pthread_create(ptr noundef %13, ptr noundef null, ptr noundef @run, ptr noundef %15) #5
  br label %17

17:                                               ; preds = %11
  %18 = load i64, ptr %5, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %5, align 8
  br label %8, !llvm.loop !11

20:                                               ; preds = %8
  store i64 1, ptr %6, align 8
  br label %21

21:                                               ; preds = %29, %20
  %22 = load i64, ptr %6, align 8
  %23 = icmp ult i64 %22, 12
  br i1 %23, label %24, label %32

24:                                               ; preds = %21
  %25 = load i64, ptr %6, align 8
  %26 = getelementptr inbounds nuw [12 x i64], ptr %2, i64 0, i64 %25
  %27 = load i64, ptr %26, align 8
  %28 = call i32 @pthread_join(i64 noundef %27, ptr noundef null)
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %6, align 8
  %31 = add i64 %30, 1
  store i64 %31, ptr %6, align 8
  br label %21, !llvm.loop !12

32:                                               ; preds = %21
  call void @vatomic8_write(ptr noundef @g_stop, i8 noundef zeroext 1)
  %33 = getelementptr inbounds [12 x i64], ptr %2, i64 0, i64 0
  %34 = load i64, ptr %33, align 16
  %35 = call i32 @pthread_join(i64 noundef %34, ptr noundef null)
  br label %36

36:                                               ; preds = %40, %32
  %37 = call ptr @vqueue_ub_deq(ptr noundef @g_queue, ptr noundef @destroy_cb, ptr noundef null)
  store ptr %37, ptr %3, align 8
  %38 = load ptr, ptr %3, align 8
  %39 = icmp ne ptr %38, null
  br i1 %39, label %40, label %42

40:                                               ; preds = %36
  %41 = load ptr, ptr %3, align 8
  call void @free(ptr noundef %41) #5
  br label %36, !llvm.loop !13

42:                                               ; preds = %36
  call void @vqueue_ub_destroy(ptr noundef @g_queue, ptr noundef @destroy_cb, ptr noundef null)
  call void @vebr_destroy(ptr noundef @g_vebr)
  %43 = call i32 @pthread_mutex_destroy(ptr noundef @g_lock) #5
  store i32 %43, ptr %4, align 4
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vebr_init(ptr noundef %0, ptr noundef byval(%struct.smr_lock_lib_s) align 8 %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.vebr_s, ptr %5, i32 0, i32 2
  call void @dbl_list_init(ptr noundef %6)
  store i64 0, ptr %4, align 8
  br label %7

7:                                                ; preds = %15, %2
  %8 = load i64, ptr %4, align 8
  %9 = icmp ult i64 %8, 3
  br i1 %9, label %10, label %18

10:                                               ; preds = %7
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds nuw %struct.vebr_s, ptr %11, i32 0, i32 1
  %13 = load i64, ptr %4, align 8
  %14 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %12, i64 0, i64 %13
  call void @smr_nodes_list_init(ptr noundef %14)
  br label %15

15:                                               ; preds = %10
  %16 = load i64, ptr %4, align 8
  %17 = add i64 %16, 1
  store i64 %17, ptr %4, align 8
  br label %7, !llvm.loop !14

18:                                               ; preds = %7
  %19 = load ptr, ptr %3, align 8
  %20 = getelementptr inbounds nuw %struct.vebr_s, ptr %19, i32 0, i32 0
  call void @vatomic64_write(ptr noundef %20, i64 noundef 1)
  %21 = load ptr, ptr %3, align 8
  %22 = getelementptr inbounds nuw %struct.vebr_s, ptr %21, i32 0, i32 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %1, i64 24, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vqueue_ub_init(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %3, i32 0, i32 2
  %5 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %4, i32 0, i32 0
  store ptr null, ptr %5, align 8
  %6 = load ptr, ptr %2, align 8
  %7 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %6, i32 0, i32 2
  %8 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %7, i32 0, i32 1
  call void @vatomicptr_write_rlx(ptr noundef %8, ptr noundef null)
  %9 = load ptr, ptr %2, align 8
  %10 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %9, i32 0, i32 0
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %11, i32 0, i32 2
  call void @vatomicptr_write_rlx(ptr noundef %10, ptr noundef %12)
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %13, i32 0, i32 1
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %15, i32 0, i32 2
  call void @vatomicptr_write_rlx(ptr noundef %14, ptr noundef %16)
  ret void
}

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) #1

declare i32 @pthread_join(i64 noundef, ptr noundef) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic8_write(ptr noundef %0, i8 noundef zeroext %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  store ptr %0, ptr %3, align 8
  store i8 %1, ptr %4, align 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !15
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic8_s, ptr %6, i32 0, i32 0
  %8 = load i8, ptr %4, align 1
  store i8 %8, ptr %5, align 1
  %9 = load i8, ptr %5, align 1
  store atomic i8 %9, ptr %7 seq_cst, align 1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !16
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vqueue_ub_destroy(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %9 = load ptr, ptr %4, align 8
  %10 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %9, i32 0, i32 0
  %11 = call ptr @vatomicptr_read(ptr noundef %10)
  store ptr %11, ptr %7, align 8
  store ptr null, ptr %8, align 8
  br label %12

12:                                               ; preds = %27, %3
  %13 = load ptr, ptr %7, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %15, label %29

15:                                               ; preds = %12
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds nuw %struct.vqueue_ub_node_s, ptr %16, i32 0, i32 1
  %18 = call ptr @vatomicptr_read(ptr noundef %17)
  store ptr %18, ptr %8, align 8
  %19 = load ptr, ptr %7, align 8
  %20 = load ptr, ptr %4, align 8
  %21 = getelementptr inbounds nuw %struct.vqueue_ub_s, ptr %20, i32 0, i32 2
  %22 = icmp ne ptr %19, %21
  br i1 %22, label %23, label %27

23:                                               ; preds = %15
  %24 = load ptr, ptr %5, align 8
  %25 = load ptr, ptr %7, align 8
  %26 = load ptr, ptr %6, align 8
  call void %24(ptr noundef %25, ptr noundef %26)
  br label %27

27:                                               ; preds = %23, %15
  %28 = load ptr, ptr %8, align 8
  store ptr %28, ptr %7, align 8
  br label %12, !llvm.loop !17

29:                                               ; preds = %12
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vebr_destroy(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  store ptr null, ptr %4, align 8
  store i64 0, ptr %3, align 8
  br label %5

5:                                                ; preds = %16, %1
  %6 = load i64, ptr %3, align 8
  %7 = icmp ult i64 %6, 3
  br i1 %7, label %8, label %19

8:                                                ; preds = %5
  %9 = load ptr, ptr %2, align 8
  %10 = getelementptr inbounds nuw %struct.vebr_s, ptr %9, i32 0, i32 1
  %11 = load i64, ptr %3, align 8
  %12 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr %10, i64 0, i64 %11
  %13 = call ptr @smr_nodes_list_get_and_empty(ptr noundef %12)
  store ptr %13, ptr %4, align 8
  %14 = load ptr, ptr %4, align 8
  %15 = call i64 @smr_nodes_list_destroy(ptr noundef %14)
  br label %16

16:                                               ; preds = %8
  %17 = load i64, ptr %3, align 8
  %18 = add i64 %17, 1
  store i64 %18, ptr %3, align 8
  br label %5, !llvm.loop !18

19:                                               ; preds = %5
  ret void
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_destroy(ptr noundef) #1

; Function Attrs: nounwind
declare i32 @pthread_mutex_lock(ptr noundef) #1

; Function Attrs: nounwind
declare i32 @pthread_mutex_unlock(ptr noundef) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic_fence() #0 {
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !19
  fence seq_cst
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !20
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !21
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %5, i32 0, i32 0
  %7 = load atomic i64, ptr %6 seq_cst, align 8
  store i64 %7, ptr %4, align 8
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %3, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !22
  %9 = load i64, ptr %3, align 8
  ret i64 %9
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @smr_nodes_list_add(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  store ptr %3, ptr %8, align 8
  %9 = load ptr, ptr %7, align 8
  %10 = load ptr, ptr %6, align 8
  %11 = getelementptr inbounds nuw %struct.smr_node_s, ptr %10, i32 0, i32 2
  store ptr %9, ptr %11, align 8
  %12 = load ptr, ptr %8, align 8
  %13 = load ptr, ptr %6, align 8
  %14 = getelementptr inbounds nuw %struct.smr_node_s, ptr %13, i32 0, i32 3
  store ptr %12, ptr %14, align 8
  %15 = load ptr, ptr %6, align 8
  %16 = getelementptr inbounds nuw %struct.smr_node_s, ptr %15, i32 0, i32 0
  %17 = getelementptr inbounds nuw %struct.smr_node_core_s, ptr %16, i32 0, i32 0
  store ptr null, ptr %17, align 8
  %18 = load ptr, ptr %5, align 8
  %19 = load ptr, ptr %6, align 8
  %20 = getelementptr inbounds nuw %struct.smr_node_s, ptr %19, i32 0, i32 0
  %21 = load ptr, ptr %6, align 8
  %22 = getelementptr inbounds nuw %struct.smr_node_s, ptr %21, i32 0, i32 0
  call void @_smr_nodes_list_connect(ptr noundef %18, ptr noundef %20, ptr noundef %22)
  %23 = load ptr, ptr %5, align 8
  %24 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %23, i32 0, i32 1
  call void @vatomic64_inc_rlx(ptr noundef %24)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @_smr_nodes_list_connect(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  %9 = load ptr, ptr %4, align 8
  %10 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %9, i32 0, i32 0
  %11 = call ptr @vatomicptr_read(ptr noundef %10)
  store ptr %11, ptr %7, align 8
  br label %12

12:                                               ; preds = %25, %3
  %13 = load ptr, ptr %7, align 8
  store ptr %13, ptr %8, align 8
  %14 = load ptr, ptr %8, align 8
  %15 = load ptr, ptr %6, align 8
  %16 = getelementptr inbounds nuw %struct.smr_node_core_s, ptr %15, i32 0, i32 0
  store ptr %14, ptr %16, align 8
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %17, i32 0, i32 0
  %19 = load ptr, ptr %8, align 8
  %20 = load ptr, ptr %5, align 8
  %21 = call ptr @vatomicptr_cmpxchg_rel(ptr noundef %18, ptr noundef %19, ptr noundef %20)
  store ptr %21, ptr %7, align 8
  %22 = load ptr, ptr %7, align 8
  %23 = load ptr, ptr %8, align 8
  %24 = icmp eq ptr %22, %23
  call void @verification_assume(i1 noundef zeroext %24)
  br label %25

25:                                               ; preds = %12
  %26 = load ptr, ptr %8, align 8
  %27 = load ptr, ptr %7, align 8
  %28 = icmp ne ptr %26, %27
  br i1 %28, label %12, label %29, !llvm.loop !23

29:                                               ; preds = %25
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_inc_rlx(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = call i64 @vatomic64_get_inc_rlx(ptr noundef %3)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @vatomicptr_read(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !24
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %5, i32 0, i32 0
  %7 = load atomic i64, ptr %6 seq_cst, align 8
  store i64 %7, ptr %4, align 8
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %3, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !25
  %9 = load ptr, ptr %3, align 8
  ret ptr %9
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @vatomicptr_cmpxchg_rel(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %10 = load ptr, ptr %5, align 8
  store ptr %10, ptr %7, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !26
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %6, align 8
  store ptr %13, ptr %8, align 8
  %14 = load i64, ptr %7, align 8
  %15 = load i64, ptr %8, align 8
  %16 = cmpxchg ptr %12, i64 %14, i64 %15 release monotonic, align 8
  %17 = extractvalue { i64, i1 } %16, 0
  %18 = extractvalue { i64, i1 } %16, 1
  br i1 %18, label %20, label %19

19:                                               ; preds = %3
  store i64 %17, ptr %7, align 8
  br label %20

20:                                               ; preds = %19, %3
  %21 = zext i1 %18 to i8
  store i8 %21, ptr %9, align 1
  %22 = load i8, ptr %9, align 1
  %23 = trunc i8 %22 to i1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !27
  %24 = load ptr, ptr %7, align 8
  ret ptr %24
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @verification_assume(i1 noundef zeroext %0) #0 {
  %2 = alloca i8, align 1
  %3 = zext i1 %0 to i8
  store i8 %3, ptr %2, align 1
  br label %4

4:                                                ; preds = %1
  br label %5

5:                                                ; preds = %4
  %6 = load i8, ptr %2, align 1
  %7 = trunc i8 %6 to i1
  br label %8

8:                                                ; preds = %5
  br label %9

9:                                                ; preds = %8
  br label %10

10:                                               ; preds = %9
  br label %11

11:                                               ; preds = %10
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_get_inc_rlx(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = call i64 @vatomic64_get_add_rlx(ptr noundef %3, i64 noundef 1)
  ret i64 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_get_add_rlx(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !28
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %8, i32 0, i32 0
  %10 = load i64, ptr %4, align 8
  store i64 %10, ptr %6, align 8
  %11 = load i64, ptr %6, align 8
  %12 = atomicrmw add ptr %9, i64 %11 monotonic, align 8
  store i64 %12, ptr %7, align 8
  %13 = load i64, ptr %7, align 8
  store i64 %13, ptr %5, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !29
  %14 = load i64, ptr %5, align 8
  ret i64 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @smr_nodes_list_get_and_empty(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %4, i32 0, i32 0
  %6 = call ptr @vatomicptr_xchg_acq(ptr noundef %5, ptr noundef null)
  store ptr %6, ptr %3, align 8
  %7 = load ptr, ptr %2, align 8
  %8 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %7, i32 0, i32 1
  call void @vatomic64_write_rlx(ptr noundef %8, i64 noundef 0)
  %9 = load ptr, ptr %3, align 8
  ret ptr %9
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @_vebr_sync_epochs(ptr noundef %0, i64 noundef %1, i1 noundef zeroext %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i8, align 1
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  %14 = zext i1 %2 to i8
  store i8 %14, ptr %6, align 1
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  store i64 0, ptr %9, align 8
  store i64 -1, ptr %10, align 8
  %15 = load ptr, ptr %4, align 8
  %16 = getelementptr inbounds nuw %struct.vebr_s, ptr %15, i32 0, i32 3
  %17 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %16, i32 0, i32 0
  %18 = load ptr, ptr %17, align 8
  %19 = load ptr, ptr %4, align 8
  %20 = getelementptr inbounds nuw %struct.vebr_s, ptr %19, i32 0, i32 3
  %21 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %20, i32 0, i32 2
  %22 = load ptr, ptr %21, align 8
  call void %18(ptr noundef %22)
  %23 = load ptr, ptr %4, align 8
  %24 = getelementptr inbounds nuw %struct.vebr_s, ptr %23, i32 0, i32 2
  %25 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %24, i32 0, i32 0
  %26 = load ptr, ptr %25, align 8
  store ptr %26, ptr %7, align 8
  br label %27

27:                                               ; preds = %67, %3
  %28 = load ptr, ptr %7, align 8
  %29 = icmp ne ptr %28, null
  br i1 %29, label %30, label %71

30:                                               ; preds = %27
  %31 = load ptr, ptr %7, align 8
  store ptr %31, ptr %8, align 8
  br label %32

32:                                               ; preds = %65, %30
  %33 = load ptr, ptr %8, align 8
  %34 = getelementptr inbounds nuw %struct.vebr_instance_s, ptr %33, i32 0, i32 1
  %35 = call i64 @vatomic64_read(ptr noundef %34)
  store i64 %35, ptr %9, align 8
  %36 = load i64, ptr %9, align 8
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %39

38:                                               ; preds = %32
  br label %66

39:                                               ; preds = %32
  %40 = load i64, ptr %9, align 8
  %41 = load i64, ptr %5, align 8
  %42 = icmp uge i64 %40, %41
  br i1 %42, label %43, label %56

43:                                               ; preds = %39
  %44 = load i64, ptr %10, align 8
  store i64 %44, ptr %11, align 8
  %45 = load i64, ptr %9, align 8
  store i64 %45, ptr %12, align 8
  %46 = load i64, ptr %11, align 8
  %47 = load i64, ptr %12, align 8
  %48 = icmp ult i64 %46, %47
  br i1 %48, label %49, label %51

49:                                               ; preds = %43
  %50 = load i64, ptr %11, align 8
  br label %53

51:                                               ; preds = %43
  %52 = load i64, ptr %12, align 8
  br label %53

53:                                               ; preds = %51, %49
  %54 = phi i64 [ %50, %49 ], [ %52, %51 ]
  store i64 %54, ptr %13, align 8
  %55 = load i64, ptr %13, align 8
  store i64 %55, ptr %10, align 8
  br label %66

56:                                               ; preds = %39
  %57 = load i8, ptr %6, align 1
  %58 = trunc i8 %57 to i1
  br i1 %58, label %61, label %59

59:                                               ; preds = %56
  %60 = load i64, ptr %9, align 8
  store i64 %60, ptr %10, align 8
  br label %72

61:                                               ; preds = %56
  call void @verification_ignore()
  br label %62

62:                                               ; preds = %61
  br label %63

63:                                               ; preds = %62
  br label %64

64:                                               ; preds = %63
  br label %65

65:                                               ; preds = %64
  br i1 true, label %32, label %66

66:                                               ; preds = %65, %53, %38
  br label %67

67:                                               ; preds = %66
  %68 = load ptr, ptr %7, align 8
  %69 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %68, i32 0, i32 0
  %70 = load ptr, ptr %69, align 8
  store ptr %70, ptr %7, align 8
  br label %27, !llvm.loop !30

71:                                               ; preds = %27
  br label %72

72:                                               ; preds = %71, %59
  %73 = load ptr, ptr %4, align 8
  %74 = getelementptr inbounds nuw %struct.vebr_s, ptr %73, i32 0, i32 3
  %75 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %74, i32 0, i32 1
  %76 = load ptr, ptr %75, align 8
  %77 = load ptr, ptr %4, align 8
  %78 = getelementptr inbounds nuw %struct.vebr_s, ptr %77, i32 0, i32 3
  %79 = getelementptr inbounds nuw %struct.smr_lock_lib_s, ptr %78, i32 0, i32 2
  %80 = load ptr, ptr %79, align 8
  call void %76(ptr noundef %80)
  %81 = load i64, ptr %10, align 8
  %82 = icmp eq i64 %81, -1
  br i1 %82, label %83, label %84

83:                                               ; preds = %72
  br label %86

84:                                               ; preds = %72
  %85 = load i64, ptr %10, align 8
  br label %86

86:                                               ; preds = %84, %83
  %87 = phi i64 [ 0, %83 ], [ %85, %84 ]
  ret i64 %87
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @vatomic64_cmpxchg(ptr noundef %0, i64 noundef %1, i64 noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  %10 = load i64, ptr %5, align 8
  store i64 %10, ptr %7, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !31
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %6, align 8
  store i64 %13, ptr %8, align 8
  %14 = load i64, ptr %7, align 8
  %15 = load i64, ptr %8, align 8
  %16 = cmpxchg ptr %12, i64 %14, i64 %15 seq_cst seq_cst, align 8
  %17 = extractvalue { i64, i1 } %16, 0
  %18 = extractvalue { i64, i1 } %16, 1
  br i1 %18, label %20, label %19

19:                                               ; preds = %3
  store i64 %17, ptr %7, align 8
  br label %20

20:                                               ; preds = %19, %3
  %21 = zext i1 %18 to i8
  store i8 %21, ptr %9, align 1
  %22 = load i8, ptr %9, align 1
  %23 = trunc i8 %22 to i1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !32
  %24 = load i64, ptr %7, align 8
  ret i64 %24
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @smr_nodes_list_destroy(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  %6 = load ptr, ptr %2, align 8
  store ptr %6, ptr %4, align 8
  store ptr null, ptr %5, align 8
  br label %7

7:                                                ; preds = %10, %1
  %8 = load ptr, ptr %4, align 8
  %9 = icmp ne ptr %8, null
  br i1 %9, label %10, label %25

10:                                               ; preds = %7
  %11 = load ptr, ptr %4, align 8
  store ptr %11, ptr %5, align 8
  %12 = load ptr, ptr %4, align 8
  %13 = getelementptr inbounds nuw %struct.smr_node_s, ptr %12, i32 0, i32 0
  %14 = getelementptr inbounds nuw %struct.smr_node_core_s, ptr %13, i32 0, i32 0
  %15 = load ptr, ptr %14, align 8
  store ptr %15, ptr %4, align 8
  %16 = load ptr, ptr %5, align 8
  %17 = getelementptr inbounds nuw %struct.smr_node_s, ptr %16, i32 0, i32 2
  %18 = load ptr, ptr %17, align 8
  %19 = load ptr, ptr %5, align 8
  %20 = load ptr, ptr %5, align 8
  %21 = getelementptr inbounds nuw %struct.smr_node_s, ptr %20, i32 0, i32 3
  %22 = load ptr, ptr %21, align 8
  call void %18(ptr noundef %19, ptr noundef %22)
  %23 = load i64, ptr %3, align 8
  %24 = add i64 %23, 1
  store i64 %24, ptr %3, align 8
  br label %7, !llvm.loop !33

25:                                               ; preds = %7
  %26 = load i64, ptr %3, align 8
  ret i64 %26
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @vatomicptr_xchg_acq(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !34
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %8, i32 0, i32 0
  %10 = load ptr, ptr %4, align 8
  store ptr %10, ptr %6, align 8
  %11 = load i64, ptr %6, align 8
  %12 = atomicrmw xchg ptr %9, i64 %11 acquire, align 8
  store i64 %12, ptr %7, align 8
  %13 = load ptr, ptr %7, align 8
  store ptr %13, ptr %5, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !35
  %14 = load ptr, ptr %5, align 8
  ret ptr %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_write_rlx(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !36
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !37
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @verification_ignore() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_init(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  call void @vatomic64_write(ptr noundef %5, i64 noundef %6)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @dbl_list_add(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %5, i32 0, i32 0
  %7 = load ptr, ptr %6, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %8, i32 0, i32 0
  store ptr %7, ptr %9, align 8
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %10, i32 0, i32 0
  %12 = load ptr, ptr %11, align 8
  %13 = icmp ne ptr %12, null
  br i1 %13, label %14, label %20

14:                                               ; preds = %2
  %15 = load ptr, ptr %4, align 8
  %16 = load ptr, ptr %3, align 8
  %17 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %16, i32 0, i32 0
  %18 = load ptr, ptr %17, align 8
  %19 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %18, i32 0, i32 1
  store ptr %15, ptr %19, align 8
  br label %20

20:                                               ; preds = %14, %2
  %21 = load ptr, ptr %4, align 8
  %22 = load ptr, ptr %3, align 8
  %23 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %22, i32 0, i32 0
  store ptr %21, ptr %23, align 8
  %24 = load ptr, ptr %4, align 8
  %25 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %24, i32 0, i32 1
  store ptr null, ptr %25, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %26, i32 0, i32 1
  %28 = load i64, ptr %27, align 8
  %29 = add i64 %28, 1
  store i64 %29, ptr %27, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_write(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !38
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !39
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomic64_write_rel(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !40
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomic64_s, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  store i64 %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 release, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !41
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @vatomicptr_cmpxchg(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i8, align 1
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %10 = load ptr, ptr %5, align 8
  store ptr %10, ptr %7, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !42
  %11 = load ptr, ptr %4, align 8
  %12 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %6, align 8
  store ptr %13, ptr %8, align 8
  %14 = load i64, ptr %7, align 8
  %15 = load i64, ptr %8, align 8
  %16 = cmpxchg ptr %12, i64 %14, i64 %15 seq_cst seq_cst, align 8
  %17 = extractvalue { i64, i1 } %16, 0
  %18 = extractvalue { i64, i1 } %16, 1
  br i1 %18, label %20, label %19

19:                                               ; preds = %3
  store i64 %17, ptr %7, align 8
  br label %20

20:                                               ; preds = %19, %3
  %21 = zext i1 %18 to i8
  store i8 %21, ptr %9, align 1
  %22 = load i8, ptr %9, align 1
  %23 = trunc i8 %22 to i1
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !43
  %24 = load ptr, ptr %7, align 8
  ret ptr %24
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomicptr_write_rlx(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !44
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %6, i32 0, i32 0
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 monotonic, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !45
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @dbl_list_rem(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %7 = load ptr, ptr %4, align 8
  %8 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %7, i32 0, i32 0
  %9 = load ptr, ptr %8, align 8
  store ptr %9, ptr %5, align 8
  %10 = load ptr, ptr %4, align 8
  %11 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %10, i32 0, i32 1
  %12 = load ptr, ptr %11, align 8
  store ptr %12, ptr %6, align 8
  %13 = load ptr, ptr %6, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %15, label %19

15:                                               ; preds = %2
  %16 = load ptr, ptr %5, align 8
  %17 = load ptr, ptr %6, align 8
  %18 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %17, i32 0, i32 0
  store ptr %16, ptr %18, align 8
  br label %23

19:                                               ; preds = %2
  %20 = load ptr, ptr %5, align 8
  %21 = load ptr, ptr %3, align 8
  %22 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %21, i32 0, i32 0
  store ptr %20, ptr %22, align 8
  br label %23

23:                                               ; preds = %19, %15
  %24 = load ptr, ptr %5, align 8
  %25 = icmp ne ptr %24, null
  br i1 %25, label %26, label %30

26:                                               ; preds = %23
  %27 = load ptr, ptr %6, align 8
  %28 = load ptr, ptr %5, align 8
  %29 = getelementptr inbounds nuw %struct.dbl_list_node_s, ptr %28, i32 0, i32 1
  store ptr %27, ptr %29, align 8
  br label %30

30:                                               ; preds = %26, %23
  %31 = load ptr, ptr %3, align 8
  %32 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %31, i32 0, i32 1
  %33 = load i64, ptr %32, align 8
  %34 = add i64 %33, -1
  store i64 %34, ptr %32, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @dbl_list_init(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %3, i32 0, i32 0
  store ptr null, ptr %4, align 8
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.dbl_list_s, ptr %5, i32 0, i32 1
  store i64 0, ptr %6, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @smr_nodes_list_init(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %3, i32 0, i32 0
  call void @vatomicptr_init(ptr noundef %4, ptr noundef null)
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.smr_nodes_list_s, ptr %5, i32 0, i32 1
  call void @vatomic64_init(ptr noundef %6, i64 noundef 0)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomicptr_init(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load ptr, ptr %4, align 8
  call void @vatomicptr_write(ptr noundef %5, ptr noundef %6)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @vatomicptr_write(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !46
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.vatomicptr_s, ptr %6, i32 0, i32 0
  %8 = load ptr, ptr %4, align 8
  store ptr %8, ptr %5, align 8
  %9 = load i64, ptr %5, align 8
  store atomic i64 %9, ptr %7 seq_cst, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #5, !srcloc !47
  ret void
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #3 = { nounwind allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="4" "target-cpu"="x86-64" "target-features"="+64bit,+cmov,+cx8,+fxsr,+idivq-to-divl,+macrofusion,+mmx,+nopl,+slow-3ops-lea,+slow-incdec,+sse,+sse2,+vzeroupper,+x87,-16bit-mode,-32bit-mode,-adx,-aes,-allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,-amx-transpose,-avx,-avx10.1-256,-avx10.1-512,-avx10.2-256,-avx10.2-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-bmi,-bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,-clflushopt,-clwb,-clzero,-cmpccxadd,-crc32,-cx16,-egpr,-enqcmd,-ermsb,-f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,-false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,-fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,-fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,-fast-scalar-fsqrt,-fast-scalar-shift-masks,-fast-shld-rotate,-fast-variable-crosslane-shuffle,-fast-variable-perlane-shuffle,-fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,-fma,-fma4,-fsgsbase,-fsrm,-gfni,-harden-sls-ijmp,-harden-sls-ret,-hreset,-idivl-to-divb,-inline-asm-use-gpr32,-invpcid,-kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,-lzcnt,-movbe,-movdir64b,-movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,-no-bypass-delay-blend,-no-bypass-delay-mov,-no-bypass-delay-shuffle,-pad-short-functions,-pclmul,-pconfig,-pku,-popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-mask-registers,-prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,-prfchw,-ptwrite,-push2pop2,-raoint,-rdpid,-rdpru,-rdrnd,-rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,-sahf,-sbb-dep-breaking,-serialize,-seses,-sgx,-sha,-sha512,-shstk,-slow-lea,-slow-pmaddwd,-slow-pmulld,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,-sse-unaligned-mem,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tagged-globals,-tbm,-tsxldtrk,-tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,-vaes,-vpclmulqdq,-waitpkg,-wbnoinvd,-widekl,-xop,-xsave,-xsavec,-xsaveopt,-xsaves,-zu" "tune-cpu"="generic" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind }
attributes #6 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{i64 2147990098}
!9 = !{i64 2147990138}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = !{i64 2147991502}
!16 = !{i64 2147991542}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
!19 = !{i64 2147989862}
!20 = !{i64 2147989902}
!21 = !{i64 2147990800}
!22 = !{i64 2147990840}
!23 = distinct !{!23, !7}
!24 = !{i64 2147991268}
!25 = !{i64 2147991308}
!26 = !{i64 2147996538}
!27 = !{i64 2147996580}
!28 = !{i64 2148002548}
!29 = !{i64 2148002588}
!30 = distinct !{!30, !7}
!31 = !{i64 2147995738}
!32 = !{i64 2147995780}
!33 = distinct !{!33, !7}
!34 = !{i64 2147994544}
!35 = !{i64 2147994584}
!36 = !{i64 2147992360}
!37 = !{i64 2147992400}
!38 = !{i64 2147992204}
!39 = !{i64 2147992244}
!40 = !{i64 2147992282}
!41 = !{i64 2147992322}
!42 = !{i64 2147996378}
!43 = !{i64 2147996420}
!44 = !{i64 2147992828}
!45 = !{i64 2147992868}
!46 = !{i64 2147992672}
!47 = !{i64 2147992712}
