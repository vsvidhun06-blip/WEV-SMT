; ModuleID = 'C:/rc1111/src/libvsync/examples/eg_vebr.c'
source_filename = "C:/rc1111/src/libvsync/examples/eg_vebr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux5.10.0-gnu2.31.0"

%union.pthread_mutex_t = type { %struct.__pthread_mutex_s, [8 x i8] }
%struct.__pthread_mutex_s = type { i32, i32, i32, i32, i32, i32, %struct.__pthread_internal_list }
%struct.__pthread_internal_list = type { ptr, ptr }
%struct.smr_lock_lib_s = type { ptr, ptr, ptr }
%struct.vebr_s = type { %struct.vatomic64_s, [3 x %struct.smr_nodes_list_s], %struct.dbl_list_s, %struct.smr_lock_lib_s, [32 x i8] }
%struct.vatomic64_s = type { i64 }
%struct.smr_nodes_list_s = type { %struct.vatomicptr_s, %struct.vatomic64_s }
%struct.vatomicptr_s = type { ptr }
%struct.dbl_list_s = type { ptr, i64 }
%struct.vatomic8_s = type { i8 }
%struct.vqueue_ub_s = type { %struct.vatomicptr_s, %struct.vatomicptr_s, %struct.vqueue_ub_node_s }
%struct.vqueue_ub_node_s = type { ptr, %struct.vatomicptr_s, %struct.smr_node_s }
%struct.smr_node_s = type { %struct.smr_node_core_s, i32, ptr, ptr }
%struct.smr_node_core_s = type { ptr }
%struct.vebr_instance_s = type { %struct.dbl_list_node_s, %struct.vatomic64_s, i32 }
%struct.dbl_list_node_s = type { ptr, ptr }

@g_lock = global %union.pthread_mutex_t zeroinitializer, align 8
@g_lock_lib = local_unnamed_addr global %struct.smr_lock_lib_s { ptr @lock_acq, ptr @lock_rel, ptr @g_lock }, align 8
@g_vebr = global %struct.vebr_s zeroinitializer, align 128
@g_stop = local_unnamed_addr global %struct.vatomic8_s zeroinitializer, align 1
@.str = private unnamed_addr constant [28 x i8] c"%zu node(s) were reclaimed\0A\00", align 1
@g_queue = global %struct.vqueue_ub_s zeroinitializer, align 8
@.str.1 = private unnamed_addr constant [16 x i8] c"[T%zu] enq %zu\0A\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"[T%zu] deq %zu\0A\00", align 1

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_acq(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_lock(ptr noundef %0) #12
  ret void
}

; Function Attrs: inlinehint nounwind uwtable
define internal void @lock_rel(ptr noundef %0) #0 {
  %2 = tail call i32 @pthread_mutex_unlock(ptr noundef %0) #12
  ret void
}

; Function Attrs: mustprogress nounwind willreturn uwtable
define void @free_cb(ptr noundef %0, ptr nocapture readnone %1) #1 {
  %3 = ptrtoint ptr %0 to i64
  %4 = add i64 %3, -16
  %5 = inttoptr i64 %4 to ptr
  tail call void @free(ptr noundef %5) #12
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nounwind uwtable
define void @retire_cb(ptr noundef initializes((16, 24), (32, 48)) %0, ptr nocapture noundef readnone %1) local_unnamed_addr #4 {
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  tail call void asm sideeffect "dmb ish", "~{memory}"() #12, !srcloc !6
  %4 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) @g_vebr) #12, !srcloc !7
  %5 = urem i64 %4, 3
  %6 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %5
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 32
  store ptr @free_cb, ptr %7, align 8, !tbaa !8
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 40
  store ptr null, ptr %8, align 8, !tbaa !16
  store ptr null, ptr %3, align 8, !tbaa !17
  %9 = tail call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %6) #12, !srcloc !18
  br label %10

10:                                               ; preds = %10, %2
  %11 = phi ptr [ %9, %2 ], [ %13, %10 ]
  store ptr %11, ptr %3, align 8, !tbaa !19
  %12 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %3, ptr %11, ptr nonnull elementtype(ptr) %6) #12, !srcloc !20
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = icmp eq ptr %11, %13
  br i1 %14, label %15, label %10, !llvm.loop !21

15:                                               ; preds = %10
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 8
  %17 = tail call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldxr ${0:x}, $4\0Aadd ${1:x}, ${0:x}, ${3:x}\0Astxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %16, i64 1) #12, !srcloc !23
  ret void
}

; Function Attrs: mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @destroy_cb(ptr nocapture noundef %0, ptr nocapture noundef readnone %1) local_unnamed_addr #5 {
  tail call void @free(ptr noundef %0) #12
  ret void
}

; Function Attrs: nounwind uwtable
define void @reclaim() local_unnamed_addr #4 {
  tail call void asm sideeffect "", "~{memory}"() #12, !srcloc !24
  %1 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory}"() #12, !srcloc !25
  %2 = icmp eq i8 %1, 0
  br i1 %2, label %3, label %49

3:                                                ; preds = %0, %46
  tail call void asm sideeffect "dmb ish", "~{memory}"() #12, !srcloc !6
  %4 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) @g_vebr) #12, !srcloc !7
  %5 = add i64 %4, 2
  %6 = urem i64 %5, 3
  %7 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %6
  %8 = tail call { ptr, i32 } asm sideeffect "prfm pstl1strm, $3\0A1:\0Aldaxr ${0:x}, $3\0Astxr  ${1:w}, ${2:x}, $3\0Acbnz ${1:w}, 1b\0A", "=&r,=&r,r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) %7) #12, !srcloc !26
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = getelementptr inbounds nuw i8, ptr %7, i64 8
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) %10) #12, !srcloc !27
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !28
  %12 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !35
  tail call void %11(ptr noundef %12) #12
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !36
  %14 = icmp eq ptr %13, null
  br i1 %14, label %26, label %15

15:                                               ; preds = %3, %23
  %16 = phi ptr [ %24, %23 ], [ %13, %3 ]
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 16
  br label %18

18:                                               ; preds = %18, %15
  %19 = tail call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) %17) #12, !srcloc !7
  %20 = icmp ne i64 %19, 0
  %21 = icmp ult i64 %19, %4
  %22 = select i1 %20, i1 %21, i1 false
  br i1 %22, label %18, label %23

23:                                               ; preds = %18
  %24 = load ptr, ptr %16, align 8, !tbaa !36
  %25 = icmp eq ptr %24, null
  br i1 %25, label %26, label %15, !llvm.loop !37

26:                                               ; preds = %23, %3
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !38
  %28 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !35
  tail call void %27(ptr noundef %28) #12
  %29 = add i64 %4, 1
  %30 = tail call { i64, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(i64 %29, i64 %4, ptr nonnull elementtype(i64) @g_vebr) #12, !srcloc !39
  %31 = icmp eq ptr %9, null
  br i1 %31, label %46, label %32

32:                                               ; preds = %26, %32
  %33 = phi ptr [ %35, %32 ], [ %9, %26 ]
  %34 = phi i64 [ %40, %32 ], [ 0, %26 ]
  %35 = load ptr, ptr %33, align 8, !tbaa !17
  %36 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %37 = load ptr, ptr %36, align 8, !tbaa !8
  %38 = getelementptr inbounds nuw i8, ptr %33, i64 24
  %39 = load ptr, ptr %38, align 8, !tbaa !16
  tail call void %37(ptr noundef nonnull %33, ptr noundef %39) #12
  %40 = add i64 %34, 1
  %41 = icmp eq ptr %35, null
  br i1 %41, label %42, label %32, !llvm.loop !40

42:                                               ; preds = %32
  %43 = icmp eq i64 %40, 0
  br i1 %43, label %46, label %44

44:                                               ; preds = %42
  %45 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %40)
  br label %46

46:                                               ; preds = %26, %44, %42
  tail call void asm sideeffect "", "~{memory}"() #12, !srcloc !24
  %47 = load atomic i8, ptr @g_stop seq_cst, align 1
  tail call void asm sideeffect "", "~{memory}"() #12, !srcloc !25
  %48 = icmp eq i8 %47, 0
  br i1 %48, label %3, label %49, !llvm.loop !41

49:                                               ; preds = %46, %0
  ret void
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #6

; Function Attrs: nounwind uwtable
define noundef ptr @run(ptr noundef %0) #4 {
  %2 = alloca %struct.vebr_instance_s, align 8
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #12
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq ptr %0, null
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  tail call void @reclaim()
  br label %121

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %2, i64 16
  call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) %7) #12, !srcloc !42
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 24
  store i32 0, ptr %8, align 8, !tbaa !43
  %9 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !28
  %10 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !35
  call void %9(ptr noundef %10) #12
  %11 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !46
  store ptr %11, ptr %2, align 8, !tbaa !47
  %12 = icmp eq ptr %11, null
  br i1 %12, label %15, label %13

13:                                               ; preds = %6
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 8
  store ptr %2, ptr %14, align 8, !tbaa !48
  br label %15

15:                                               ; preds = %6, %13
  store ptr %2, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !46
  %16 = getelementptr inbounds nuw i8, ptr %2, i64 8
  store ptr null, ptr %16, align 8, !tbaa !48
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !49
  %18 = add i64 %17, 1
  store i64 %18, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !49
  %19 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !38
  %20 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !35
  call void %19(ptr noundef %20) #12
  %21 = load i32, ptr %8, align 8, !tbaa !43
  br label %39

22:                                               ; preds = %116
  %23 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), align 8, !tbaa !28
  %24 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !35
  call void %23(ptr noundef %24) #12
  %25 = load ptr, ptr %2, align 8, !tbaa !47
  %26 = load ptr, ptr %16, align 8, !tbaa !48
  %27 = icmp eq ptr %26, null
  br i1 %27, label %29, label %28

28:                                               ; preds = %22
  store ptr %25, ptr %26, align 8, !tbaa !47
  br label %30

29:                                               ; preds = %22
  store ptr %25, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), align 8, !tbaa !46
  br label %30

30:                                               ; preds = %29, %28
  %31 = icmp eq ptr %25, null
  br i1 %31, label %34, label %32

32:                                               ; preds = %30
  %33 = getelementptr inbounds nuw i8, ptr %25, i64 8
  store ptr %26, ptr %33, align 8, !tbaa !48
  br label %34

34:                                               ; preds = %30, %32
  %35 = load i64, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !49
  %36 = add i64 %35, -1
  store i64 %36, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 64), align 64, !tbaa !49
  %37 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 80), align 16, !tbaa !38
  %38 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 88), align 8, !tbaa !35
  call void %37(ptr noundef %38) #12
  br label %121

39:                                               ; preds = %15, %116
  %40 = phi i32 [ %21, %15 ], [ %118, %116 ]
  %41 = phi i64 [ 0, %15 ], [ %119, %116 ]
  %42 = add i32 %40, 1
  store i32 %42, ptr %8, align 8, !tbaa !43
  %43 = icmp eq i32 %40, 0
  br i1 %43, label %44, label %46

44:                                               ; preds = %39
  %45 = call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) @g_vebr) #12, !srcloc !7
  call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 %45, ptr nonnull elementtype(i64) %7) #12, !srcloc !50
  call void asm sideeffect "dmb ish", "~{memory}"() #12, !srcloc !6
  br label %46

46:                                               ; preds = %39, %44
  br label %47

47:                                               ; preds = %65, %46
  %48 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !18
  %49 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !18
  %50 = getelementptr inbounds nuw i8, ptr %48, i64 8
  %51 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %50) #12, !srcloc !18
  %52 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !18
  %53 = icmp eq ptr %48, %52
  br i1 %53, label %54, label %65

54:                                               ; preds = %47
  %55 = icmp eq ptr %48, %49
  br i1 %55, label %56, label %60

56:                                               ; preds = %54
  %57 = icmp eq ptr %51, null
  br i1 %57, label %86, label %58

58:                                               ; preds = %56
  %59 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %51, ptr %49, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !51
  br label %65

60:                                               ; preds = %54
  %61 = load ptr, ptr %51, align 8, !tbaa !52
  %62 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %51, ptr %48, ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !51
  %63 = extractvalue { ptr, i32 } %62, 0
  %64 = icmp eq ptr %63, %48
  br i1 %64, label %66, label %65

65:                                               ; preds = %60, %58, %47
  br label %47

66:                                               ; preds = %60
  %67 = icmp eq ptr %48, getelementptr inbounds nuw (i8, ptr @g_queue, i64 16)
  br i1 %67, label %84, label %68

68:                                               ; preds = %66
  %69 = getelementptr inbounds nuw i8, ptr %48, i64 16
  call void asm sideeffect "dmb ish", "~{memory}"() #12, !srcloc !6
  %70 = call i64 asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(i64) @g_vebr) #12, !srcloc !7
  %71 = urem i64 %70, 3
  %72 = getelementptr inbounds nuw [3 x %struct.smr_nodes_list_s], ptr getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8), i64 0, i64 %71
  %73 = getelementptr inbounds nuw i8, ptr %48, i64 32
  store ptr @free_cb, ptr %73, align 8, !tbaa !8
  %74 = getelementptr inbounds nuw i8, ptr %48, i64 40
  store ptr null, ptr %74, align 8, !tbaa !16
  store ptr null, ptr %69, align 8, !tbaa !17
  %75 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %72) #12, !srcloc !18
  br label %76

76:                                               ; preds = %76, %68
  %77 = phi ptr [ %75, %68 ], [ %79, %76 ]
  store ptr %77, ptr %69, align 8, !tbaa !19
  %78 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %69, ptr %77, ptr nonnull elementtype(ptr) %72) #12, !srcloc !20
  %79 = extractvalue { ptr, i32 } %78, 0
  %80 = icmp eq ptr %77, %79
  br i1 %80, label %81, label %76, !llvm.loop !21

81:                                               ; preds = %76
  %82 = getelementptr inbounds nuw i8, ptr %72, i64 8
  %83 = call { i64, i64, i32, i64 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldxr ${0:x}, $4\0Aadd ${1:x}, ${0:x}, ${3:x}\0Astxr ${2:w}, ${1:x}, $4\0Acbnz ${2:w}, 1b\0A", "=&r,=&r,=&r,=&r,*Q,3,~{memory},~{cc}"(ptr nonnull elementtype(i64) %82, i64 1) #12, !srcloc !23
  br label %84

84:                                               ; preds = %66, %81
  %85 = icmp eq ptr %61, null
  br i1 %85, label %86, label %108

86:                                               ; preds = %56, %84
  %87 = call noalias dereferenceable_or_null(8) ptr @malloc(i64 noundef 8) #13
  store i64 %41, ptr %87, align 8, !tbaa !55
  %88 = call noalias dereferenceable_or_null(48) ptr @malloc(i64 noundef 48) #13
  %89 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef %3, i64 noundef %41)
  store ptr %87, ptr %88, align 8, !tbaa !52
  %90 = getelementptr inbounds nuw i8, ptr %88, i64 8
  call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) %90) #12, !srcloc !57
  br label %91

91:                                               ; preds = %105, %86
  %92 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !18
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 8
  %94 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %93) #12, !srcloc !18
  %95 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !18
  %96 = icmp eq ptr %92, %95
  br i1 %96, label %97, label %105

97:                                               ; preds = %91
  %98 = icmp eq ptr %94, null
  br i1 %98, label %99, label %103

99:                                               ; preds = %97
  %100 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %88, ptr null, ptr nonnull elementtype(ptr) %93) #12, !srcloc !51
  %101 = extractvalue { ptr, i32 } %100, 0
  %102 = icmp eq ptr %101, null
  br i1 %102, label %106, label %105

103:                                              ; preds = %97
  %104 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %94, ptr %92, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !51
  br label %105

105:                                              ; preds = %103, %99, %91
  br label %91

106:                                              ; preds = %99
  %107 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %88, ptr %92, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !51
  br label %111

108:                                              ; preds = %84
  %109 = load i64, ptr %61, align 8, !tbaa !55
  %110 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %3, i64 noundef %109)
  call void @free(ptr noundef nonnull %61) #12
  br label %111

111:                                              ; preds = %108, %106
  %112 = load i32, ptr %8, align 8, !tbaa !43
  %113 = icmp eq i32 %112, 1
  br i1 %113, label %114, label %116

114:                                              ; preds = %111
  call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) %7) #12, !srcloc !50
  %115 = load i32, ptr %8, align 8, !tbaa !43
  br label %116

116:                                              ; preds = %111, %114
  %117 = phi i32 [ %115, %114 ], [ %112, %111 ]
  %118 = add i32 %117, -1
  store i32 %118, ptr %8, align 8, !tbaa !43
  %119 = add nuw nsw i64 %41, 1
  %120 = icmp eq i64 %119, 10000
  br i1 %120, label %22, label %39, !llvm.loop !58

121:                                              ; preds = %34, %5
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #12
  ret ptr null
}

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #7

; Function Attrs: nounwind uwtable
define noundef i32 @main() local_unnamed_addr #4 {
  %1 = alloca [12 x i64], align 8
  %2 = alloca %struct.smr_lock_lib_s, align 8
  call void @llvm.lifetime.start.p0(i64 96, ptr nonnull %1) #12
  %3 = tail call i32 @pthread_mutex_init(ptr noundef nonnull @g_lock, ptr noundef null) #12
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %2)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %2, ptr noundef nonnull align 8 dereferenceable(24) @g_lock_lib, i64 24, i1 false), !tbaa.struct !59
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 56), i8 0, i64 16, i1 false)
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8)) #12, !srcloc !61
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 16)) #12, !srcloc !42
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 24)) #12, !srcloc !61
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 32)) #12, !srcloc !42
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 40)) #12, !srcloc !61
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 48)) #12, !srcloc !42
  tail call void asm sideeffect "stlr ${0:x}, $1", "r,*Q,~{memory}"(i64 1, ptr nonnull elementtype(i64) @g_vebr) #12, !srcloc !42
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 72), ptr noundef nonnull readonly align 8 dereferenceable(24) %2, i64 24, i1 false), !tbaa.struct !59
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %2)
  store ptr null, ptr getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), align 8, !tbaa !62
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 24)) #12, !srcloc !57
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !57
  tail call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(ptr nonnull getelementptr inbounds nuw (i8, ptr @g_queue, i64 16), ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !57
  %4 = call i32 @pthread_create(ptr noundef nonnull %1, ptr noundef null, ptr noundef nonnull @run, ptr noundef null) #12
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %6 = call i32 @pthread_create(ptr noundef nonnull %5, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 1 to ptr)) #12
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %8 = call i32 @pthread_create(ptr noundef nonnull %7, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 2 to ptr)) #12
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %10 = call i32 @pthread_create(ptr noundef nonnull %9, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 3 to ptr)) #12
  %11 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %12 = call i32 @pthread_create(ptr noundef nonnull %11, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 4 to ptr)) #12
  %13 = getelementptr inbounds nuw i8, ptr %1, i64 40
  %14 = call i32 @pthread_create(ptr noundef nonnull %13, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 5 to ptr)) #12
  %15 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %16 = call i32 @pthread_create(ptr noundef nonnull %15, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 6 to ptr)) #12
  %17 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %18 = call i32 @pthread_create(ptr noundef nonnull %17, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 7 to ptr)) #12
  %19 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %20 = call i32 @pthread_create(ptr noundef nonnull %19, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 8 to ptr)) #12
  %21 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %22 = call i32 @pthread_create(ptr noundef nonnull %21, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 9 to ptr)) #12
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 80
  %24 = call i32 @pthread_create(ptr noundef nonnull %23, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 10 to ptr)) #12
  %25 = getelementptr inbounds nuw i8, ptr %1, i64 88
  %26 = call i32 @pthread_create(ptr noundef nonnull %25, ptr noundef null, ptr noundef nonnull @run, ptr noundef nonnull inttoptr (i64 11 to ptr)) #12
  %27 = load i64, ptr %5, align 8, !tbaa !64
  %28 = call i32 @pthread_join(i64 noundef %27, ptr noundef null) #12
  %29 = load i64, ptr %7, align 8, !tbaa !64
  %30 = call i32 @pthread_join(i64 noundef %29, ptr noundef null) #12
  %31 = load i64, ptr %9, align 8, !tbaa !64
  %32 = call i32 @pthread_join(i64 noundef %31, ptr noundef null) #12
  %33 = load i64, ptr %11, align 8, !tbaa !64
  %34 = call i32 @pthread_join(i64 noundef %33, ptr noundef null) #12
  %35 = load i64, ptr %13, align 8, !tbaa !64
  %36 = call i32 @pthread_join(i64 noundef %35, ptr noundef null) #12
  %37 = load i64, ptr %15, align 8, !tbaa !64
  %38 = call i32 @pthread_join(i64 noundef %37, ptr noundef null) #12
  %39 = load i64, ptr %17, align 8, !tbaa !64
  %40 = call i32 @pthread_join(i64 noundef %39, ptr noundef null) #12
  %41 = load i64, ptr %19, align 8, !tbaa !64
  %42 = call i32 @pthread_join(i64 noundef %41, ptr noundef null) #12
  %43 = load i64, ptr %21, align 8, !tbaa !64
  %44 = call i32 @pthread_join(i64 noundef %43, ptr noundef null) #12
  %45 = load i64, ptr %23, align 8, !tbaa !64
  %46 = call i32 @pthread_join(i64 noundef %45, ptr noundef null) #12
  %47 = load i64, ptr %25, align 8, !tbaa !64
  %48 = call i32 @pthread_join(i64 noundef %47, ptr noundef null) #12
  call void asm sideeffect "", "~{memory}"() #12, !srcloc !65
  store atomic i8 1, ptr @g_stop seq_cst, align 1
  call void asm sideeffect "", "~{memory}"() #12, !srcloc !66
  %49 = load i64, ptr %1, align 8, !tbaa !64
  %50 = call i32 @pthread_join(i64 noundef %49, ptr noundef null) #12
  br label %51

51:                                               ; preds = %75, %0
  %52 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !18
  %53 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !18
  %54 = getelementptr inbounds nuw i8, ptr %52, i64 8
  %55 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %54) #12, !srcloc !18
  %56 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !18
  %57 = icmp eq ptr %52, %56
  br i1 %57, label %58, label %75

58:                                               ; preds = %51
  %59 = icmp eq ptr %52, %53
  br i1 %59, label %60, label %64

60:                                               ; preds = %58
  %61 = icmp eq ptr %55, null
  br i1 %61, label %76, label %62

62:                                               ; preds = %60
  %63 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %55, ptr %53, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_queue, i64 8)) #12, !srcloc !51
  br label %75

64:                                               ; preds = %58
  %65 = load ptr, ptr %55, align 8, !tbaa !52
  %66 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $4\0A1:\0Aldaxr ${0:x}, $4\0Acmp ${0:x}, ${3:x}\0Ab.ne 2f\0Astlxr  ${1:w}, ${2:x}, $4\0Acbnz ${1:w}, 1b\0A2:\0A", "=&r,=&r,r,r,*Q,~{memory},~{cc}"(ptr nonnull %55, ptr %52, ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !51
  %67 = extractvalue { ptr, i32 } %66, 0
  %68 = icmp eq ptr %67, %52
  br i1 %68, label %69, label %75

69:                                               ; preds = %64
  %70 = icmp eq ptr %52, getelementptr inbounds nuw (i8, ptr @g_queue, i64 16)
  br i1 %70, label %72, label %71

71:                                               ; preds = %69
  call void @free(ptr noundef %52) #12
  br label %72

72:                                               ; preds = %69, %71
  %73 = icmp eq ptr %65, null
  br i1 %73, label %76, label %74

74:                                               ; preds = %72
  call void @free(ptr noundef nonnull %65) #12
  br label %75

75:                                               ; preds = %74, %64, %62, %51
  br label %51, !llvm.loop !67

76:                                               ; preds = %72, %60
  %77 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) @g_queue) #12, !srcloc !18
  %78 = icmp eq ptr %77, null
  br i1 %78, label %87, label %79

79:                                               ; preds = %76, %85
  %80 = phi ptr [ %82, %85 ], [ %77, %76 ]
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 8
  %82 = call ptr asm sideeffect "ldar ${0:x}, $1", "=&r,*Q,~{memory}"(ptr nonnull elementtype(ptr) %81) #12, !srcloc !18
  %83 = icmp eq ptr %80, getelementptr inbounds nuw (i8, ptr @g_queue, i64 16)
  br i1 %83, label %85, label %84

84:                                               ; preds = %79
  call void @free(ptr noundef nonnull %80) #12
  br label %85

85:                                               ; preds = %84, %79
  %86 = icmp eq ptr %82, null
  br i1 %86, label %87, label %79, !llvm.loop !68

87:                                               ; preds = %85, %76
  %88 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $3\0A1:\0Aldaxr ${0:x}, $3\0Astxr  ${1:w}, ${2:x}, $3\0Acbnz ${1:w}, 1b\0A", "=&r,=&r,r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 8)) #12, !srcloc !26
  %89 = extractvalue { ptr, i32 } %88, 0
  call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 16)) #12, !srcloc !27
  %90 = icmp eq ptr %89, null
  br i1 %90, label %99, label %91

91:                                               ; preds = %87, %91
  %92 = phi ptr [ %93, %91 ], [ %89, %87 ]
  %93 = load ptr, ptr %92, align 8, !tbaa !17
  %94 = getelementptr inbounds nuw i8, ptr %92, i64 16
  %95 = load ptr, ptr %94, align 8, !tbaa !8
  %96 = getelementptr inbounds nuw i8, ptr %92, i64 24
  %97 = load ptr, ptr %96, align 8, !tbaa !16
  call void %95(ptr noundef nonnull %92, ptr noundef %97) #12
  %98 = icmp eq ptr %93, null
  br i1 %98, label %99, label %91, !llvm.loop !40

99:                                               ; preds = %91, %87
  %100 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $3\0A1:\0Aldaxr ${0:x}, $3\0Astxr  ${1:w}, ${2:x}, $3\0Acbnz ${1:w}, 1b\0A", "=&r,=&r,r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 24)) #12, !srcloc !26
  %101 = extractvalue { ptr, i32 } %100, 0
  call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 32)) #12, !srcloc !27
  %102 = icmp eq ptr %101, null
  br i1 %102, label %111, label %103

103:                                              ; preds = %99, %103
  %104 = phi ptr [ %105, %103 ], [ %101, %99 ]
  %105 = load ptr, ptr %104, align 8, !tbaa !17
  %106 = getelementptr inbounds nuw i8, ptr %104, i64 16
  %107 = load ptr, ptr %106, align 8, !tbaa !8
  %108 = getelementptr inbounds nuw i8, ptr %104, i64 24
  %109 = load ptr, ptr %108, align 8, !tbaa !16
  call void %107(ptr noundef nonnull %104, ptr noundef %109) #12
  %110 = icmp eq ptr %105, null
  br i1 %110, label %111, label %103, !llvm.loop !40

111:                                              ; preds = %103, %99
  %112 = call { ptr, i32 } asm sideeffect "prfm pstl1strm, $3\0A1:\0Aldaxr ${0:x}, $3\0Astxr  ${1:w}, ${2:x}, $3\0Acbnz ${1:w}, 1b\0A", "=&r,=&r,r,*Q,~{memory}"(ptr null, ptr nonnull elementtype(ptr) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 40)) #12, !srcloc !26
  %113 = extractvalue { ptr, i32 } %112, 0
  call void asm sideeffect "str ${0:x}, $1", "r,*Q,~{memory}"(i64 0, ptr nonnull elementtype(i64) getelementptr inbounds nuw (i8, ptr @g_vebr, i64 48)) #12, !srcloc !27
  %114 = icmp eq ptr %113, null
  br i1 %114, label %123, label %115

115:                                              ; preds = %111, %115
  %116 = phi ptr [ %117, %115 ], [ %113, %111 ]
  %117 = load ptr, ptr %116, align 8, !tbaa !17
  %118 = getelementptr inbounds nuw i8, ptr %116, i64 16
  %119 = load ptr, ptr %118, align 8, !tbaa !8
  %120 = getelementptr inbounds nuw i8, ptr %116, i64 24
  %121 = load ptr, ptr %120, align 8, !tbaa !16
  call void %119(ptr noundef nonnull %116, ptr noundef %121) #12
  %122 = icmp eq ptr %117, null
  br i1 %122, label %123, label %115, !llvm.loop !40

123:                                              ; preds = %115, %111
  %124 = call i32 @pthread_mutex_destroy(ptr noundef nonnull @g_lock) #12
  call void @llvm.lifetime.end.p0(i64 96, ptr nonnull %1) #12
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @pthread_mutex_init(ptr noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #9

; Function Attrs: nounwind
declare i32 @pthread_create(ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #8

declare i32 @pthread_join(i64 noundef, ptr noundef) local_unnamed_addr #10

; Function Attrs: nounwind
declare i32 @pthread_mutex_destroy(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_lock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nounwind
declare i32 @pthread_mutex_unlock(ptr noundef) local_unnamed_addr #8

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #11

attributes #0 = { inlinehint nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #1 = { mustprogress nounwind willreturn uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #4 = { nounwind uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #5 = { mustprogress nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #6 = { nofree nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #7 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite) "alloc-family"="malloc" "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #8 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #9 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #10 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+enable-select-opt,+ete,+fp-armv8,+fuse-adrp-add,+fuse-aes,+neon,+trbe,+use-postra-scheduler,-CONTEXTIDREL2,-addr-lsl-slow-14,-aes,-aggressive-fma,-alternate-sextload-cvt-f32-pattern,-altnzcv,-alu-lsl-fast,-am,-amvs,-arith-bcc-fusion,-arith-cbz-fusion,-ascend-store-address,-avoid-ldapur,-balance-fp-ops,-bf16,-brbe,-bti,-call-saved-x10,-call-saved-x11,-call-saved-x12,-call-saved-x13,-call-saved-x14,-call-saved-x15,-call-saved-x18,-call-saved-x8,-call-saved-x9,-ccdp,-ccidx,-ccpp,-chk,-clrbhb,-cmp-bcc-fusion,-cmpbr,-complxnum,-cpa,-crc,-crypto,-cssc,-d128,-disable-latency-sched-heuristic,-disable-ldp,-disable-stp,-dit,-dotprod,-ecv,-el2vmsa,-el3,-exynos-cheap-as-move,-f32mm,-f64mm,-f8f16mm,-f8f32mm,-faminmax,-fgt,-fix-cortex-a53-835769,-flagm,-fmv,-force-32bit-jump-tables,-fp16fml,-fp8,-fp8dot2,-fp8dot4,-fp8fma,-fpac,-fprcvt,-fptoint,-fujitsu-monaka,-fullfp16,-fuse-address,-fuse-addsub-2reg-const1,-fuse-arith-logic,-fuse-crypto-eor,-fuse-csel,-fuse-literals,-gcs,-harden-sls-blr,-harden-sls-nocomdat,-harden-sls-retbr,-hbc,-hcx,-i8mm,-ite,-jsconv,-ldp-aligned-only,-lor,-ls64,-lse,-lse128,-lse2,-lsfe,-lsui,-lut,-mec,-mops,-mpam,-mte,-nmi,-no-bti-at-return-twice,-no-neg-immediates,-no-sve-fp-ld1r,-no-zcz-fp,-nv,-occmo,-outline-atomics,-pan,-pan-rwv,-pauth,-pauth-lr,-pcdphint,-perfmon,-pops,-predictable-select-expensive,-predres,-prfm-slc-target,-rand,-ras,-rasv2,-rcpc,-rcpc-immo,-rcpc3,-rdm,-reserve-lr-for-ra,-reserve-x1,-reserve-x10,-reserve-x11,-reserve-x12,-reserve-x13,-reserve-x14,-reserve-x15,-reserve-x18,-reserve-x2,-reserve-x20,-reserve-x21,-reserve-x22,-reserve-x23,-reserve-x24,-reserve-x25,-reserve-x26,-reserve-x27,-reserve-x28,-reserve-x3,-reserve-x4,-reserve-x5,-reserve-x6,-reserve-x7,-reserve-x9,-rme,-sb,-sel2,-sha2,-sha3,-slow-misaligned-128store,-slow-paired-128,-slow-strqro-store,-sm4,-sme,-sme-b16b16,-sme-f16f16,-sme-f64f64,-sme-f8f16,-sme-f8f32,-sme-fa64,-sme-i16i64,-sme-lutv2,-sme-mop4,-sme-tmop,-sme2,-sme2p1,-sme2p2,-spe,-spe-eef,-specres2,-specrestrict,-ssbs,-ssve-aes,-ssve-bitperm,-ssve-fp8dot2,-ssve-fp8dot4,-ssve-fp8fma,-store-pair-suppress,-stp-aligned-only,-strict-align,-sve,-sve-aes,-sve-aes2,-sve-b16b16,-sve-bfscale,-sve-bitperm,-sve-f16f32mm,-sve2,-sve2-aes,-sve2-bitperm,-sve2-sha3,-sve2-sm4,-sve2p1,-sve2p2,-tagged-globals,-the,-tlb-rmi,-tlbiw,-tme,-tpidr-el1,-tpidr-el2,-tpidr-el3,-tpidrro-el0,-tracev8.4,-uaops,-use-experimental-zeroing-pseudos,-use-fixed-over-scalable-if-equal-cost,-use-reciprocal-square-root,-v8.1a,-v8.2a,-v8.3a,-v8.4a,-v8.5a,-v8.6a,-v8.7a,-v8.8a,-v8.9a,-v8a,-v8r,-v9.1a,-v9.2a,-v9.3a,-v9.4a,-v9.5a,-v9.6a,-v9a,-vh,-wfxt,-xs,-zcm,-zcz,-zcz-fp-workaround,-zcz-gp" }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nounwind }
attributes #13 = { nounwind allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 7, !"Dwarf Version", i32 4}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"}
!6 = !{i64 442742}
!7 = !{i64 445164}
!8 = !{!9, !12, i64 16}
!9 = !{!"smr_node_s", !10, i64 0, !15, i64 8, !12, i64 16, !12, i64 24}
!10 = !{!"smr_node_core_s", !11, i64 0}
!11 = !{!"p1 _ZTS15smr_node_core_s", !12, i64 0}
!12 = !{!"any pointer", !13, i64 0}
!13 = !{!"omnipotent char", !14, i64 0}
!14 = !{!"Simple C/C++ TBAA"}
!15 = !{!"int", !13, i64 0}
!16 = !{!9, !12, i64 24}
!17 = !{!9, !11, i64 0}
!18 = !{i64 446699}
!19 = !{!10, !11, i64 0}
!20 = !{i64 519109, i64 519144, i64 519160, i64 519193, i64 519228, i64 519249, i64 519293, i64 519323}
!21 = distinct !{!21, !22}
!22 = !{!"llvm.loop.mustprogress"}
!23 = !{i64 560848, i64 560883, i64 560899, i64 560932, i64 560975, i64 561017}
!24 = !{i64 2148134739}
!25 = !{i64 2148134779}
!26 = !{i64 509112, i64 509147, i64 509163, i64 509197, i64 509240}
!27 = !{i64 450621}
!28 = !{!29, !12, i64 72}
!29 = !{!"vebr_s", !30, i64 0, !13, i64 8, !32, i64 56, !34, i64 72}
!30 = !{!"vatomic64_s", !31, i64 0}
!31 = !{!"long", !13, i64 0}
!32 = !{!"dbl_list_s", !33, i64 0, !31, i64 8}
!33 = !{!"p1 _ZTS15dbl_list_node_s", !12, i64 0}
!34 = !{!"smr_lock_lib_s", !12, i64 0, !12, i64 8, !12, i64 16}
!35 = !{!29, !12, i64 88}
!36 = !{!33, !33, i64 0}
!37 = distinct !{!37, !22}
!38 = !{!29, !12, i64 80}
!39 = !{i64 514348, i64 514383, i64 514399, i64 514433, i64 514468, i64 514489, i64 514533, i64 514563}
!40 = distinct !{!40, !22}
!41 = distinct !{!41, !22}
!42 = !{i64 449653}
!43 = !{!44, !15, i64 24}
!44 = !{!"vebr_instance_s", !45, i64 0, !30, i64 16, !15, i64 24}
!45 = !{!"dbl_list_node_s", !33, i64 0, !33, i64 8}
!46 = !{!32, !33, i64 0}
!47 = !{!45, !33, i64 0}
!48 = !{!45, !33, i64 8}
!49 = !{!32, !31, i64 8}
!50 = !{i64 450137}
!51 = !{i64 517526, i64 517561, i64 517577, i64 517611, i64 517646, i64 517667, i64 517711, i64 517741}
!52 = !{!53, !12, i64 0}
!53 = !{!"vqueue_ub_node_s", !12, i64 0, !54, i64 8, !9, i64 16}
!54 = !{!"vatomicptr_s", !12, i64 0}
!55 = !{!56, !31, i64 0}
!56 = !{!"data_s", !31, i64 0}
!57 = !{i64 452059}
!58 = distinct !{!58, !22}
!59 = !{i64 0, i64 8, !60, i64 8, i64 8, !60, i64 16, i64 8, !60}
!60 = !{!12, !12, i64 0}
!61 = !{i64 451089}
!62 = !{!63, !12, i64 16}
!63 = !{!"vqueue_ub_s", !54, i64 0, !54, i64 8, !53, i64 16}
!64 = !{!31, !31, i64 0}
!65 = !{i64 2148135441}
!66 = !{i64 2148135481}
!67 = distinct !{!67, !22}
!68 = distinct !{!68, !22}
