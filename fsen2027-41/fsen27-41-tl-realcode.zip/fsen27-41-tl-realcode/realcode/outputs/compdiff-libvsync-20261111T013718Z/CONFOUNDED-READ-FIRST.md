# THIS GRID IS CONFOUNDED: do not use report.txt as optimizer evidence (recorded 2026-11-11T01:44:57Z)

`python -m ziglang cc` (zig 0.15.2) does not pass the -O flag through to clang. It maps the level to a zig optimize
mode and then emits its own flags (shown by `ZIG_VERBOSE_CC=1`; full aarch64 -O2 command line in
`confound-evidence/ZIG_VERBOSE_CC.aarch64.O2.txt`):

| user flag | flags zig gives clang |
|---|---|
| -O0 | -O0 (also -fstack-protector-strong -fsanitize=undefined…, overridden by our later -fno-sanitize=all) |
| -O1, -O2, -O3 | **-DNDEBUG -O2** -fno-stack-protector |
| -Os | **-DNDEBUG -Os** -fomit-frame-pointer |

Consequences for this grid:
1. The O1, O2 and O3 cells are one configuration, clang -O2.
2. Every "asserts on" cell above O0 was really compiled with NDEBUG, so ASSERT() expanded to nothing. The absence of
   every assert site at O1+ in report.txt (target sites AND controls) is a preprocessor effect, not an optimizer effect.
3. P2 and P3 of PLAN.md were not tested by this grid.

The grid, its commands and outputs are kept unchanged. The corrected experiment, in a fresh directory, replays zig's
exact clang command through the raw driver (`zig clang`) and varies only -O<n> and -DNDEBUG:
`outputs/compdiff-libvsync-v2-*`.

Scope note for other experiments in this investigation: the Stage-A corpora were all built at -O0
(-Xclang -disable-O0-optnone), so they are not affected. Any earlier pass that compiled with `zig cc -O1/-O2/-O3` was
really -O2 -DNDEBUG; that is not re-audited here.
