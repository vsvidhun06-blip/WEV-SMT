#!/usr/bin/env bash
# Writes only inside its own directory.
set -u
OUT="$(cd "$(dirname "$0")" && pwd -W 2>/dev/null || cd "$(dirname "$0")" && pwd)"
S='C:/rc1111/src/libvsync'; PY='C:/rc1111/venv/Scripts/python.exe'
INC="-I $S/include -I $S/vatomic/include -I $S/test/include -I $S/verify/include -D_GNU_SOURCE -pthread"
printf 'file\ttarget\tatomics\tasserts\topt\tkind\texit\tsecs\tcommand\n' > "$OUT/commands.tsv"
for f in eg_bitmap eg_unbounded_queue_lf_recycle eg_vebr; do
 for tgt in aarch64-linux-gnu x86_64-linux-gnu; do
  for at in BUILTINS DEFAULT; do
   for nd in on NDEBUG; do
    for o in O0 O1 O2 O3 Os; do
     X=""; [ "$at" = BUILTINS ] && X="-DVATOMIC_BUILTINS"; [ "$nd" = NDEBUG ] && X="$X -DNDEBUG"
     base="$f.$tgt.$at.$nd.$o"
     for kind in ll s; do
      if [ $kind = ll ]; then K="-S -emit-llvm"; else K="-S"; fi
      t0=$(date +%s.%N)
      cmd="$PY -m ziglang cc -target $tgt -$o -fno-sanitize=all -g0 -w $K $INC $X -o $OUT/$kind/$base.$kind $S/examples/$f.c"
      $cmd 2> "$OUT/$kind/$base.err"; ec=$?
      t1=$(date +%s.%N)
      printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%.2f\t%s\n' "$f" "$tgt" "$at" "$nd" "$o" "$kind" "$ec" "$(echo "$t1 - $t0" | bc)" "$cmd" >> "$OUT/commands.tsv"
     done
    done
   done
  done
 done
done
echo RUN-DONE
