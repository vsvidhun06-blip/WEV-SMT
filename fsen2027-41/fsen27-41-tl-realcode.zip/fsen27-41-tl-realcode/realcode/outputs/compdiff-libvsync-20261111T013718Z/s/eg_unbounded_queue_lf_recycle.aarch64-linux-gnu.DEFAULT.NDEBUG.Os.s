	.file	"eg_unbounded_queue_lf_recycle.c"
	.text
	.globl	destroy_pools                   // -- Begin function destroy_pools
	.p2align	2
	.type	destroy_pools,@function
destroy_pools:                          // @destroy_pools
	.cfi_startproc
// %bb.0:
	stp	x30, x21, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	adrp	x19, :got:local_pools
	mov	x20, xzr
	ldr	x19, [x19, :got_lo12:local_pools]
.LBB0_1:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_2 Depth 2
	ldr	x0, [x19, x20, lsl #3]
	cbz	x0, .LBB0_3
.LBB0_2:                                //   Parent Loop BB0_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x8, x0, #8
	//APP
	ldar	x9, [x8]
	//NO_APP
	and	x21, x9, #0xffffffffffffff80
	bl	free
	mov	x0, x21
	cbnz	x21, .LBB0_2
.LBB0_3:                                //   in Loop: Header=BB0_1 Depth=1
	add	x20, x20, #1
	cmp	x20, #12
	b.ne	.LBB0_1
// %bb.4:
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x30, x21, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	ret
.Lfunc_end0:
	.size	destroy_pools, .Lfunc_end0-destroy_pools
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	b	free
.Lfunc_end1:
	.size	destroy_cb, .Lfunc_end1-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	add	x8, x0, #8
	//APP
	ldar	x9, [x8]
	//NO_APP
	adrp	x10, :got:local_pools
	ldr	x10, [x10, :got_lo12:local_pools]
	add	w9, w9, #1
	and	x9, x9, #0x7f
	ldr	x11, [x10, x1, lsl #3]
	orr	x9, x9, x11
	//APP
	stlr	x9, [x8]
	//NO_APP
	str	x0, [x10, x1, lsl #3]
	ret
.Lfunc_end2:
	.size	retire_cb, .Lfunc_end2-retire_cb
	.cfi_endproc
                                        // -- End function
	.globl	alloc_qnode                     // -- Begin function alloc_qnode
	.p2align	2
	.type	alloc_qnode,@function
alloc_qnode:                            // @alloc_qnode
	.cfi_startproc
// %bb.0:
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	adrp	x8, :got:local_pools
	ldr	x8, [x8, :got_lo12:local_pools]
	ldr	x19, [x8, x0, lsl #3]
	cbz	x19, .LBB3_2
// %bb.1:
	add	x9, x19, #8
	//APP
	ldar	x10, [x9]
	//NO_APP
	and	x9, x10, #0xffffffffffffff80
	str	x9, [x8, x0, lsl #3]
	adrp	x0, .Lstr.4
	add	x0, x0, :lo12:.Lstr.4
	b	.LBB3_3
.LBB3_2:
	mov	w0, #128                        // =0x80
	mov	w1, #128                        // =0x80
	bl	memalign
	mov	x19, x0
	adrp	x0, .Lstr
	add	x0, x0, :lo12:.Lstr
.LBB3_3:
	bl	puts
	mov	x0, x19
	ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	ret
.Lfunc_end3:
	.size	alloc_qnode, .Lfunc_end3-alloc_qnode
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	str	x30, [sp, #-80]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 80
	stp	x26, x25, [sp, #16]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w30, -80
	adrp	x25, :got:g_queue
	adrp	x26, :got:local_pools
	mov	x19, x0
	ldr	x25, [x25, :got_lo12:g_queue]
	ldr	x26, [x26, :got_lo12:local_pools]
	mov	x24, xzr
	adrp	x20, .L.str.2
	add	x20, x20, :lo12:.L.str.2
	adrp	x21, .L.str.3
	add	x21, x21, :lo12:.L.str.3
.LBB4_1:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_11 Depth 2
	//APP
	ldar	x9, [x25]
	//NO_APP
	and	x8, x9, #0xffffffffffffff80
	add	x11, x25, #8
	//APP
	ldar	x10, [x11]
	//NO_APP
	orr	x11, x8, #0x8
	//APP
	ldar	x12, [x11]
	//NO_APP
	//APP
	ldar	x11, [x25]
	//NO_APP
	and	x13, x11, #0xffffffffffffff80
	eor	w11, w11, w9
	cmp	x8, x13
	and	x11, x11, #0x7f
	ccmp	x11, #0, #0, eq
	and	x11, x12, #0xffffffffffffff80
	b.ne	.LBB4_1
// %bb.2:                               //   in Loop: Header=BB4_1 Depth=1
	and	x12, x10, #0xffffffffffffff80
	cmp	x8, x12
	b.ne	.LBB4_5
// %bb.3:                               //   in Loop: Header=BB4_1 Depth=1
	cbz	x11, .LBB4_10
// %bb.4:                               //   in Loop: Header=BB4_1 Depth=1
	add	w8, w10, #1
	add	x9, x25, #8
	and	x8, x8, #0x7f
	orr	x8, x8, x11
	//APP
	prfm	pstl1strm, [x9]
.Ltmp0:
	ldaxr	x11, [x9]
	cmp	x11, x10
	b.ne	.Ltmp1
	stlxr	w12, x8, [x9]
	cbnz	w12, .Ltmp0
.Ltmp1:

	//NO_APP
	b	.LBB4_1
.LBB4_5:                                //   in Loop: Header=BB4_1 Depth=1
	add	w10, w9, #1
	ldr	x22, [x11]
	and	x10, x10, #0x7f
	orr	x10, x11, x10
	//APP
	prfm	pstl1strm, [x25]
.Ltmp2:
	ldaxr	x11, [x25]
	cmp	x11, x9
	b.ne	.Ltmp3
	stlxr	w12, x10, [x25]
	cbnz	w12, .Ltmp2
.Ltmp3:

	//NO_APP
	cmp	x11, x9
	b.ne	.LBB4_1
// %bb.6:                               //   in Loop: Header=BB4_1 Depth=1
	add	x9, x25, #128
	cmp	x8, x9
	b.eq	.LBB4_8
// %bb.7:                               //   in Loop: Header=BB4_1 Depth=1
	add	x9, x8, #8
	//APP
	ldar	x10, [x9]
	//NO_APP
	ldr	x11, [x26, x19, lsl #3]
	add	w10, w10, #1
	and	x10, x10, #0x7f
	orr	x10, x10, x11
	//APP
	stlr	x10, [x9]
	//NO_APP
	str	x8, [x26, x19, lsl #3]
.LBB4_8:                                //   in Loop: Header=BB4_1 Depth=1
	cbz	x22, .LBB4_10
// %bb.9:                               //   in Loop: Header=BB4_1 Depth=1
	ldr	x2, [x22]
	mov	x0, x21
	mov	x1, x19
	bl	printf
	mov	x0, x22
	bl	free
	b	.LBB4_16
.LBB4_10:                               //   in Loop: Header=BB4_1 Depth=1
	mov	w0, #8                          // =0x8
	bl	malloc
	mov	x23, x0
	str	x24, [x0]
	mov	x0, x19
	bl	alloc_qnode
	ldr	x2, [x23]
	mov	x22, x0
	mov	x0, x20
	mov	x1, x19
	bl	printf
	mov	x8, x22
	str	x23, [x8], #8
	//APP
	ldar	x9, [x8]
	//NO_APP
	and	x9, x9, #0x7f
	//APP
	stlr	x9, [x8]
	//NO_APP
.LBB4_11:                               //   Parent Loop BB4_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x11, x25, #8
	//APP
	ldar	x8, [x11]
	//NO_APP
	and	x10, x8, #0xffffffffffffff80
	orr	x12, x10, #0x8
	//APP
	ldar	x9, [x12]
	//NO_APP
	//APP
	ldar	x12, [x11]
	//NO_APP
	and	x11, x12, #0xffffffffffffff80
	eor	w12, w12, w8
	cmp	x10, x11
	and	x11, x9, #0xffffffffffffff80
	and	x12, x12, #0x7f
	ccmp	x12, #0, #0, eq
	b.ne	.LBB4_11
// %bb.12:                              //   in Loop: Header=BB4_11 Depth=2
	cbz	x11, .LBB4_14
// %bb.13:                              //   in Loop: Header=BB4_11 Depth=2
	add	w9, w8, #1
	add	x10, x25, #8
	and	x9, x9, #0x7f
	orr	x9, x9, x11
	//APP
	prfm	pstl1strm, [x10]
.Ltmp4:
	ldaxr	x11, [x10]
	cmp	x11, x8
	b.ne	.Ltmp5
	stlxr	w12, x9, [x10]
	cbnz	w12, .Ltmp4
.Ltmp5:

	//NO_APP
	b	.LBB4_11
.LBB4_14:                               //   in Loop: Header=BB4_11 Depth=2
	add	w11, w9, #1
	add	x10, x10, #8
	and	x11, x11, #0x7f
	orr	x11, x11, x22
	//APP
	prfm	pstl1strm, [x10]
.Ltmp6:
	ldaxr	x12, [x10]
	cmp	x12, x9
	b.ne	.Ltmp7
	stlxr	w13, x11, [x10]
	cbnz	w13, .Ltmp6
.Ltmp7:

	//NO_APP
	cmp	x12, x9
	b.ne	.LBB4_11
// %bb.15:                              //   in Loop: Header=BB4_1 Depth=1
	add	w9, w8, #1
	add	x10, x25, #8
	and	x9, x9, #0x7f
	orr	x9, x9, x22
	//APP
	prfm	pstl1strm, [x10]
.Ltmp8:
	ldaxr	x11, [x10]
	cmp	x11, x8
	b.ne	.Ltmp9
	stlxr	w12, x9, [x10]
	cbnz	w12, .Ltmp8
.Ltmp9:

	//NO_APP
.LBB4_16:                               //   in Loop: Header=BB4_1 Depth=1
	add	x24, x24, #1
	cmp	x24, #100
	b.ne	.LBB4_1
// %bb.17:
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	mov	x0, xzr
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             // 16-byte Folded Reload
	ldr	x30, [sp], #80                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w30
	ret
.Lfunc_end4:
	.size	run, .Lfunc_end4-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x30, x23, [sp, #96]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w30, -48
	adrp	x23, :got:g_queue
	mov	x19, xzr
	adrp	x20, :got:run
	ldr	x23, [x23, :got_lo12:g_queue]
	mov	x21, sp
	mov	x22, xzr
	add	x8, x23, #136
	//APP
	str	x19, [x8]
	//NO_APP
	add	x9, x23, #8
	add	x8, x23, #128
	//APP
	str	x8, [x23]
	//NO_APP
	//APP
	str	x8, [x9]
	//NO_APP
	ldr	x20, [x20, :got_lo12:run]
.LBB5_1:                                // =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	mov	x3, x22
	bl	pthread_create
	add	x22, x22, #1
	add	x21, x21, #8
	cmp	x22, #12
	b.ne	.LBB5_1
// %bb.2:
	mov	x19, xzr
	mov	x20, sp
.LBB5_3:                                // =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19]
	mov	x1, xzr
	bl	pthread_join
	add	x19, x19, #8
	cmp	x19, #96
	b.ne	.LBB5_3
	b	.LBB5_10
.LBB5_4:                                //   in Loop: Header=BB5_10 Depth=1
	add	w8, w9, #1
	and	x8, x8, #0x7f
	orr	x8, x8, x10
	add	x10, x23, #8
	//APP
	prfm	pstl1strm, [x10]
.Ltmp10:
	ldaxr	x11, [x10]
	cmp	x11, x9
	b.ne	.Ltmp11
	stlxr	w12, x8, [x10]
	cbnz	w12, .Ltmp10
.Ltmp11:

	//NO_APP
	b	.LBB5_10
.LBB5_5:                                //   in Loop: Header=BB5_10 Depth=1
	add	w9, w8, #1
	ldr	x19, [x10]
	and	x9, x9, #0x7f
	orr	x9, x10, x9
	//APP
	prfm	pstl1strm, [x23]
.Ltmp12:
	ldaxr	x10, [x23]
	cmp	x10, x8
	b.ne	.Ltmp13
	stlxr	w11, x9, [x23]
	cbnz	w11, .Ltmp12
.Ltmp13:

	//NO_APP
	cmp	x10, x8
	b.ne	.LBB5_10
// %bb.6:                               //   in Loop: Header=BB5_10 Depth=1
	add	x8, x23, #128
	cmp	x0, x8
	b.eq	.LBB5_8
// %bb.7:                               //   in Loop: Header=BB5_10 Depth=1
	bl	free
.LBB5_8:                                //   in Loop: Header=BB5_10 Depth=1
	cbz	x19, .LBB5_13
// %bb.9:                               //   in Loop: Header=BB5_10 Depth=1
	mov	x0, x19
	bl	free
.LBB5_10:                               // =>This Inner Loop Header: Depth=1
	//APP
	ldar	x8, [x23]
	//NO_APP
	and	x0, x8, #0xffffffffffffff80
	add	x10, x23, #8
	//APP
	ldar	x9, [x10]
	//NO_APP
	orr	x10, x0, #0x8
	//APP
	ldar	x11, [x10]
	//NO_APP
	//APP
	ldar	x10, [x23]
	//NO_APP
	and	x12, x10, #0xffffffffffffff80
	eor	w10, w10, w8
	cmp	x0, x12
	and	x10, x10, #0x7f
	ccmp	x10, #0, #0, eq
	and	x10, x11, #0xffffffffffffff80
	b.ne	.LBB5_10
// %bb.11:                              //   in Loop: Header=BB5_10 Depth=1
	and	x11, x9, #0xffffffffffffff80
	cmp	x0, x11
	b.ne	.LBB5_5
// %bb.12:                              //   in Loop: Header=BB5_10 Depth=1
	cbnz	x10, .LBB5_4
.LBB5_13:
	adrp	x8, :got:g_queue
	ldr	x8, [x8, :got_lo12:g_queue]
	//APP
	ldar	x9, [x8]
	//NO_APP
	ands	x0, x9, #0xffffffffffffff80
	b.eq	.LBB5_18
// %bb.14:
	add	x19, x8, #128
.LBB5_15:                               // =>This Inner Loop Header: Depth=1
	add	x8, x0, #8
	//APP
	ldar	x20, [x8]
	//NO_APP
	cmp	x0, x19
	b.eq	.LBB5_17
// %bb.16:                              //   in Loop: Header=BB5_15 Depth=1
	bl	free
.LBB5_17:                               //   in Loop: Header=BB5_15 Depth=1
	ands	x0, x20, #0xffffffffffffff80
	b.ne	.LBB5_15
.LBB5_18:
	bl	destroy_pools
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	mov	w0, wzr
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldp	x30, x23, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	ret
.Lfunc_end5:
	.size	main, .Lfunc_end5-main
	.cfi_endproc
                                        // -- End function
	.type	local_pools,@object             // @local_pools
	.bss
	.globl	local_pools
	.p2align	3, 0x0
local_pools:
	.zero	96
	.size	local_pools, 96

	.type	g_queue,@object                 // @g_queue
	.globl	g_queue
	.p2align	7, 0x0
g_queue:
	.zero	256
	.size	g_queue, 256

	.type	.L.str.2,@object                // @.str.2
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.2:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.2, 16

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.3, 16

	.type	.Lstr,@object                   // @str
.Lstr:
	.asciz	"New allocation"
	.size	.Lstr, 15

	.type	.Lstr.4,@object                 // @str.4
.Lstr.4:
	.asciz	"Recycle allocation"
	.size	.Lstr.4, 19

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
	.addrsig_sym g_queue
