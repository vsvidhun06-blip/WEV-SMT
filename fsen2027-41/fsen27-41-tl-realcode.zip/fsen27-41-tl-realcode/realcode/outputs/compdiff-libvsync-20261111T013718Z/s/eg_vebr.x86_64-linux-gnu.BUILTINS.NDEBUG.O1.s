	.file	"eg_vebr.c"
	.text
	.p2align	4                               # -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               # @lock_acq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	pthread_mutex_lock@PLT          # TAILCALL
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               # @lock_rel
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	pthread_mutex_unlock@PLT        # TAILCALL
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        # -- End function
	.globl	free_cb                         # -- Begin function free_cb
	.p2align	4
	.type	free_cb,@function
free_cb:                                # @free_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	addq	$-16, %rdi
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	free@PLT                        # TAILCALL
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        # -- End function
	.globl	retire_cb                       # -- Begin function retire_cb
	.p2align	4
	.type	retire_cb,@function
retire_cb:                              # @retire_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	leaq	16(%rdi), %rsi
	#APP
	#NO_APP
	mfence
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	g_vebr@GOTPCREL(%rip), %r8
	movq	(%r8), %rcx
	#APP
	#NO_APP
	movabsq	$-6148914691236517205, %rdx     # imm = 0xAAAAAAAAAAAAAAAB
	movq	%rcx, %rax
	mulq	%rdx
	shrl	%edx
	leal	(%rdx,%rdx,2), %eax
	subl	%eax, %ecx
	shll	$4, %ecx
	leaq	(%r8,%rcx), %rdx
	addq	$8, %rdx
	movq	free_cb@GOTPCREL(%rip), %rax
	movq	%rax, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 16(%rdi)
	#APP
	#NO_APP
	movq	8(%r8,%rcx), %rcx
	#APP
	#NO_APP
	.p2align	4
.LBB3_1:                                # =>This Inner Loop Header: Depth=1
	movq	%rcx, (%rsi)
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rsi, (%rdx)
	cmoveq	%rcx, %rax
	#APP
	#NO_APP
	cmpq	%rax, %rcx
	movq	%rax, %rcx
	jne	.LBB3_1
# %bb.2:
	#APP
	#NO_APP
	lock		addq	$1, 8(%rdx)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        # -- End function
	.globl	destroy_cb                      # -- Begin function destroy_cb
	.p2align	4
	.type	destroy_cb,@function
destroy_cb:                             # @destroy_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	free@PLT                        # TAILCALL
.Lfunc_end4:
	.size	destroy_cb, .Lfunc_end4-destroy_cb
	.cfi_endproc
                                        # -- End function
	.globl	reclaim                         # -- Begin function reclaim
	.p2align	4
	.type	reclaim,@function
reclaim:                                # @reclaim
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	#APP
	#NO_APP
	movq	g_stop@GOTPCREL(%rip), %r12
	movzbl	(%r12), %eax
	#APP
	#NO_APP
	testb	%al, %al
	je	.LBB5_1
.LBB5_13:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB5_1:
	.cfi_def_cfa %rbp, 16
	movq	g_vebr@GOTPCREL(%rip), %r13
	jmp	.LBB5_2
	.p2align	4
.LBB5_12:                               #   in Loop: Header=BB5_2 Depth=1
	#APP
	#NO_APP
	movzbl	(%r12), %eax
	#APP
	#NO_APP
	testb	%al, %al
	jne	.LBB5_13
.LBB5_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB5_3 Depth 2
                                        #       Child Loop BB5_4 Depth 3
                                        #     Child Loop BB5_9 Depth 2
	#APP
	#NO_APP
	mfence
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r13), %r15
	leaq	2(%r15), %rcx
	movq	%rcx, %rax
	movabsq	$-6148914691236517205, %rdx     # imm = 0xAAAAAAAAAAAAAAAB
	mulq	%rdx
	#APP
	#NO_APP
	shrl	%edx
	leal	(%rdx,%rdx,2), %eax
	subl	%eax, %ecx
	shll	$4, %ecx
	#APP
	#NO_APP
	xorl	%ebx, %ebx
	xchgq	%rbx, 8(%r13,%rcx)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	$0, 16(%r13,%rcx)
	#APP
	#NO_APP
	movq	88(%r13), %rdi
	callq	*72(%r13)
	movq	56(%r13), %rax
	jmp	.LBB5_3
	.p2align	4
.LBB5_6:                                #   in Loop: Header=BB5_3 Depth=2
	movq	(%rax), %rax
.LBB5_3:                                #   Parent Loop BB5_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB5_4 Depth 3
	testq	%rax, %rax
	je	.LBB5_7
	.p2align	4
.LBB5_4:                                #   Parent Loop BB5_2 Depth=1
                                        #     Parent Loop BB5_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	#APP
	#NO_APP
	movq	16(%rax), %rcx
	#APP
	#NO_APP
	testq	%rcx, %rcx
	je	.LBB5_6
# %bb.5:                                #   in Loop: Header=BB5_4 Depth=3
	cmpq	%r15, %rcx
	jb	.LBB5_4
	jmp	.LBB5_6
	.p2align	4
.LBB5_7:                                #   in Loop: Header=BB5_2 Depth=1
	movq	88(%r13), %rdi
	callq	*80(%r13)
	leaq	1(%r15), %rcx
	#APP
	#NO_APP
	movq	%r15, %rax
	lock		cmpxchgq	%rcx, (%r13)
	#APP
	#NO_APP
	testq	%rbx, %rbx
	je	.LBB5_12
# %bb.8:                                #   in Loop: Header=BB5_2 Depth=1
	xorl	%r15d, %r15d
	.p2align	4
.LBB5_9:                                #   Parent Loop BB5_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rbx), %r14
	movq	24(%rbx), %rsi
	movq	%rbx, %rdi
	callq	*16(%rbx)
	addq	$-1, %r15
	movq	%r14, %rbx
	testq	%r14, %r14
	jne	.LBB5_9
# %bb.10:                               #   in Loop: Header=BB5_2 Depth=1
	testq	%r15, %r15
	je	.LBB5_12
# %bb.11:                               #   in Loop: Header=BB5_2 Depth=1
	negq	%r15
	leaq	.L.str(%rip), %rdi
	movq	%r15, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	jmp	.LBB5_12
.Lfunc_end5:
	.size	reclaim, .Lfunc_end5-reclaim
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB6_1
# %bb.2:
	movq	%rdi, %rbx
	#APP
	#NO_APP
	xorl	%eax, %eax
	xchgq	%rax, -56(%rbp)
	#APP
	#NO_APP
	movl	$0, -48(%rbp)
	movq	g_vebr@GOTPCREL(%rip), %r14
	movq	88(%r14), %rdi
	callq	*72(%r14)
	movq	56(%r14), %rax
	movq	%rax, -72(%rbp)
	testq	%rax, %rax
	je	.LBB6_4
# %bb.3:
	leaq	-72(%rbp), %rcx
	movq	%rcx, 8(%rax)
.LBB6_4:
	leaq	-72(%rbp), %rax
	movq	%rax, 56(%r14)
	movq	$0, -64(%rbp)
	addq	$1, 64(%r14)
	movq	88(%r14), %rdi
	callq	*80(%r14)
	movl	-48(%rbp), %eax
	movq	g_queue@GOTPCREL(%rip), %r14
	leaq	16(%r14), %rcx
	movq	%rcx, -80(%rbp)                 # 8-byte Spill
	xorl	%r12d, %r12d
	jmp	.LBB6_5
	.p2align	4
.LBB6_32:                               #   in Loop: Header=BB6_5 Depth=1
	addl	$-1, %eax
	movl	%eax, -48(%rbp)
	addq	$1, %r12
	cmpq	$10000, %r12                    # imm = 0x2710
	je	.LBB6_11
.LBB6_5:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB6_7 Depth 2
                                        #     Child Loop BB6_21 Depth 2
                                        #     Child Loop BB6_25 Depth 2
	leal	1(%rax), %ecx
	movl	%ecx, -48(%rbp)
	testl	%eax, %eax
	jne	.LBB6_7
# %bb.6:                                #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	movq	g_vebr@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	%rax, -56(%rbp)
	#APP
	#NO_APP
	#APP
	#NO_APP
	mfence
	#APP
	#NO_APP
	jmp	.LBB6_7
	.p2align	4
.LBB6_18:                               #   in Loop: Header=BB6_7 Depth=2
	movq	(%rdx), %r13
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rdx, (%r14)
	setne	%al
	#APP
	#NO_APP
	testb	%al, %al
	je	.LBB6_19
.LBB6_7:                                #   Parent Loop BB6_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	#APP
	#NO_APP
	movq	(%r14), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%r14), %rax
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rcx), %rdx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r14), %rsi
	#APP
	#NO_APP
	cmpq	%rsi, %rcx
	jne	.LBB6_7
# %bb.8:                                #   in Loop: Header=BB6_7 Depth=2
	cmpq	%rax, %rcx
	jne	.LBB6_18
# %bb.9:                                #   in Loop: Header=BB6_7 Depth=2
	testq	%rdx, %rdx
	je	.LBB6_24
# %bb.10:                               #   in Loop: Header=BB6_7 Depth=2
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rdx, 8(%r14)
	#APP
	#NO_APP
	jmp	.LBB6_7
	.p2align	4
.LBB6_19:                               #   in Loop: Header=BB6_5 Depth=1
	cmpq	-80(%rbp), %rcx                 # 8-byte Folded Reload
	je	.LBB6_23
# %bb.20:                               #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	mfence
	leaq	16(%rcx), %rdi
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	g_vebr@GOTPCREL(%rip), %r8
	movq	(%r8), %rsi
	#APP
	#NO_APP
	movq	%rsi, %rax
	movabsq	$-6148914691236517205, %rdx     # imm = 0xAAAAAAAAAAAAAAAB
	mulq	%rdx
	shrl	%edx
	leal	(%rdx,%rdx,2), %eax
	subl	%eax, %esi
	shll	$4, %esi
	leaq	(%r8,%rsi), %rdx
	addq	$8, %rdx
	movq	free_cb@GOTPCREL(%rip), %rax
	movq	%rax, 32(%rcx)
	movq	$0, 40(%rcx)
	movq	$0, 16(%rcx)
	#APP
	#NO_APP
	movq	8(%r8,%rsi), %rcx
	#APP
	#NO_APP
	.p2align	4
.LBB6_21:                               #   Parent Loop BB6_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rcx, (%rdi)
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rdi, (%rdx)
	cmoveq	%rcx, %rax
	#APP
	#NO_APP
	cmpq	%rax, %rcx
	movq	%rax, %rcx
	jne	.LBB6_21
# %bb.22:                               #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	lock		addq	$1, 8(%rdx)
	#APP
	#NO_APP
.LBB6_23:                               #   in Loop: Header=BB6_5 Depth=1
	testq	%r13, %r13
	je	.LBB6_24
# %bb.29:                               #   in Loop: Header=BB6_5 Depth=1
	movq	(%r13), %rdx
	leaq	.L.str.2(%rip), %rdi
	movq	%rbx, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	movq	%r13, %rdi
	callq	free@PLT
	jmp	.LBB6_30
	.p2align	4
.LBB6_24:                               #   in Loop: Header=BB6_5 Depth=1
	movl	$8, %edi
	callq	malloc@PLT
	movq	%rax, %r15
	movq	%r12, (%rax)
	movl	$48, %edi
	callq	malloc@PLT
	movq	%rax, %r13
	leaq	.L.str.1(%rip), %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	xorl	%eax, %eax
	callq	printf@PLT
	movq	%r15, (%r13)
	#APP
	#NO_APP
	movq	$0, 8(%r13)
	#APP
	#NO_APP
	jmp	.LBB6_25
	.p2align	4
.LBB6_33:                               #   in Loop: Header=BB6_25 Depth=2
	movq	%rcx, %rax
	lock		cmpxchgq	%rdx, 8(%r14)
	#APP
	#NO_APP
.LBB6_25:                               #   Parent Loop BB6_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	#APP
	#NO_APP
	movq	8(%r14), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rcx), %rdx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%r14), %rax
	#APP
	#NO_APP
	cmpq	%rax, %rcx
	jne	.LBB6_25
# %bb.26:                               #   in Loop: Header=BB6_25 Depth=2
	#APP
	#NO_APP
	testq	%rdx, %rdx
	jne	.LBB6_33
# %bb.27:                               #   in Loop: Header=BB6_25 Depth=2
	xorl	%eax, %eax
	lock		cmpxchgq	%r13, 8(%rcx)
	sete	%al
	#APP
	#NO_APP
	testb	%al, %al
	je	.LBB6_25
# %bb.28:                               #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%r13, 8(%r14)
	#APP
	#NO_APP
.LBB6_30:                               #   in Loop: Header=BB6_5 Depth=1
	movl	-48(%rbp), %eax
	cmpl	$1, %eax
	jne	.LBB6_32
# %bb.31:                               #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	movq	$0, -56(%rbp)
	#APP
	#NO_APP
	movl	-48(%rbp), %eax
	jmp	.LBB6_32
.LBB6_11:
	movq	g_vebr@GOTPCREL(%rip), %rbx
	movq	88(%rbx), %rdi
	callq	*72(%rbx)
	movq	-72(%rbp), %rax
	movq	-64(%rbp), %rcx
	testq	%rcx, %rcx
	je	.LBB6_13
# %bb.12:
	movq	%rax, (%rcx)
	testq	%rax, %rax
	je	.LBB6_16
.LBB6_15:
	movq	%rcx, 8(%rax)
.LBB6_16:
	addq	$-1, 64(%rbx)
	movq	88(%rbx), %rdi
	callq	*80(%rbx)
	jmp	.LBB6_17
.LBB6_1:
	callq	reclaim@PLT
.LBB6_17:
	xorl	%eax, %eax
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB6_13:
	.cfi_def_cfa %rbp, 16
	movq	%rax, 56(%rbx)
	testq	%rax, %rax
	jne	.LBB6_15
	jmp	.LBB6_16
.Lfunc_end6:
	.size	run, .Lfunc_end6-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	g_lock@GOTPCREL(%rip), %rdi
	xorl	%ebx, %ebx
	xorl	%esi, %esi
	callq	pthread_mutex_init@PLT
	movq	g_lock_lib@GOTPCREL(%rip), %rax
	movq	16(%rax), %rcx
	movq	%rcx, -112(%rbp)
	movups	(%rax), %xmm0
	movaps	%xmm0, -128(%rbp)
	xorps	%xmm0, %xmm0
	movq	g_vebr@GOTPCREL(%rip), %r14
	movups	%xmm0, 56(%r14)
	#APP
	#NO_APP
	xorl	%eax, %eax
	xchgq	%rax, 8(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	xorl	%eax, %eax
	xchgq	%rax, 16(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	xorl	%eax, %eax
	xchgq	%rax, 24(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	xorl	%eax, %eax
	xchgq	%rax, 32(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	xorl	%eax, %eax
	xchgq	%rax, 40(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	xchgq	%rbx, 48(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movl	$1, %eax
	xchgq	%rax, (%r14)
	#APP
	#NO_APP
	movq	-112(%rbp), %rax
	movq	%rax, 88(%r14)
	movaps	-128(%rbp), %xmm0
	movups	%xmm0, 72(%r14)
	movq	g_queue@GOTPCREL(%rip), %r12
	movq	$0, 16(%r12)
	leaq	16(%r12), %r15
	#APP
	#NO_APP
	movq	$0, 24(%r12)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	%r15, (%r12)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	%r15, 8(%r12)
	#APP
	#NO_APP
	movq	run@GOTPCREL(%rip), %rbx
	leaq	-128(%rbp), %rdi
	xorl	%esi, %esi
	movq	%rbx, %rdx
	xorl	%ecx, %ecx
	callq	pthread_create@PLT
	leaq	-120(%rbp), %rdi
	movl	$1, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-112(%rbp), %rdi
	movl	$2, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-104(%rbp), %rdi
	movl	$3, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-96(%rbp), %rdi
	movl	$4, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-88(%rbp), %rdi
	movl	$5, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-80(%rbp), %rdi
	movl	$6, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-72(%rbp), %rdi
	movl	$7, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-64(%rbp), %rdi
	movl	$8, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-56(%rbp), %rdi
	movl	$9, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-48(%rbp), %rdi
	movl	$10, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-40(%rbp), %rdi
	movl	$11, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	movq	-120(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-112(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-104(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-96(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-88(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-80(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-72(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-64(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-56(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-48(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-40(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	#APP
	#NO_APP
	movq	g_stop@GOTPCREL(%rip), %rax
	movb	$1, %cl
	xchgb	%cl, (%rax)
	#APP
	#NO_APP
	movq	-128(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	.p2align	4
.LBB7_1:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	movq	(%r12), %rdi
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%r12), %rax
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rdi), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r12), %rdx
	#APP
	#NO_APP
	cmpq	%rdx, %rdi
	jne	.LBB7_1
# %bb.2:                                #   in Loop: Header=BB7_1 Depth=1
	cmpq	%rax, %rdi
	jne	.LBB7_5
# %bb.3:                                #   in Loop: Header=BB7_1 Depth=1
	testq	%rcx, %rcx
	je	.LBB7_10
# %bb.4:                                #   in Loop: Header=BB7_1 Depth=1
	#APP
	#NO_APP
	movq	%rdi, %rax
	lock		cmpxchgq	%rcx, 8(%r12)
	#APP
	#NO_APP
	jmp	.LBB7_1
	.p2align	4
.LBB7_5:                                #   in Loop: Header=BB7_1 Depth=1
	movq	(%rcx), %rbx
	#APP
	#NO_APP
	movq	%rdi, %rax
	lock		cmpxchgq	%rcx, (%r12)
	setne	%al
	#APP
	#NO_APP
	testb	%al, %al
	jne	.LBB7_1
# %bb.6:                                #   in Loop: Header=BB7_1 Depth=1
	cmpq	%r15, %rdi
	je	.LBB7_8
# %bb.7:                                #   in Loop: Header=BB7_1 Depth=1
	callq	free@PLT
.LBB7_8:                                #   in Loop: Header=BB7_1 Depth=1
	testq	%rbx, %rbx
	je	.LBB7_10
# %bb.9:                                #   in Loop: Header=BB7_1 Depth=1
	movq	%rbx, %rdi
	callq	free@PLT
	jmp	.LBB7_1
.LBB7_10:
	#APP
	#NO_APP
	movq	(%r12), %rdi
	#APP
	#NO_APP
	testq	%rdi, %rdi
	jne	.LBB7_11
.LBB7_14:
	#APP
	#NO_APP
	xorl	%edi, %edi
	xchgq	%rdi, 8(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	$0, 16(%r14)
	#APP
	#NO_APP
	testq	%rdi, %rdi
	je	.LBB7_16
	.p2align	4
.LBB7_15:                               # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %rbx
	movq	24(%rdi), %rsi
	callq	*16(%rdi)
	movq	%rbx, %rdi
	testq	%rbx, %rbx
	jne	.LBB7_15
.LBB7_16:
	#APP
	#NO_APP
	xorl	%edi, %edi
	xchgq	%rdi, 24(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	$0, 32(%r14)
	#APP
	#NO_APP
	testq	%rdi, %rdi
	je	.LBB7_18
	.p2align	4
.LBB7_17:                               # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %rbx
	movq	24(%rdi), %rsi
	callq	*16(%rdi)
	movq	%rbx, %rdi
	testq	%rbx, %rbx
	jne	.LBB7_17
.LBB7_18:
	#APP
	#NO_APP
	xorl	%edi, %edi
	xchgq	%rdi, 40(%r14)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	$0, 48(%r14)
	#APP
	#NO_APP
	testq	%rdi, %rdi
	je	.LBB7_20
	.p2align	4
.LBB7_19:                               # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %rbx
	movq	24(%rdi), %rsi
	callq	*16(%rdi)
	movq	%rbx, %rdi
	testq	%rbx, %rbx
	jne	.LBB7_19
.LBB7_20:
	movq	g_lock@GOTPCREL(%rip), %rdi
	callq	pthread_mutex_destroy@PLT
	xorl	%eax, %eax
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
	.p2align	4
.LBB7_13:                               #   in Loop: Header=BB7_11 Depth=1
	.cfi_def_cfa %rbp, 16
	movq	%rbx, %rdi
	testq	%rbx, %rbx
	je	.LBB7_14
.LBB7_11:                               # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	movq	8(%rdi), %rbx
	#APP
	#NO_APP
	cmpq	%r15, %rdi
	je	.LBB7_13
# %bb.12:                               #   in Loop: Header=BB7_11 Depth=1
	callq	free@PLT
	jmp	.LBB7_13
.Lfunc_end7:
	.size	main, .Lfunc_end7-main
	.cfi_endproc
                                        # -- End function
	.type	g_lock,@object                  # @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	40
	.size	g_lock, 40

	.type	g_lock_lib,@object              # @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.quad	lock_acq
	.quad	lock_rel
	.quad	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  # @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  # @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 # @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym run
	.addrsig_sym g_lock
	.addrsig_sym g_vebr
	.addrsig_sym g_queue
