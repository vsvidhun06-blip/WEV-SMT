	.file	"eg_unbounded_queue_lf_recycle.c"
	.text
	.globl	destroy_pools                   // -- Begin function destroy_pools
	.p2align	2
	.type	destroy_pools,@function
destroy_pools:                          // @destroy_pools
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	adrp	x19, :got:local_pools
	mov	x20, xzr
	ldr	x19, [x19, :got_lo12:local_pools]
	b	.LBB0_2
.LBB0_1:                                //   in Loop: Header=BB0_2 Depth=1
	add	x20, x20, #1
	cmp	x20, #12
	b.eq	.LBB0_4
.LBB0_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_3 Depth 2
	ldr	x0, [x19, x20, lsl #3]
	cbz	x0, .LBB0_1
.LBB0_3:                                //   Parent Loop BB0_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x8, x0, #8
	//APP
	//NO_APP
	ldar	x8, [x8]
	//APP
	//NO_APP
	and	x21, x8, #0xffffffffffffff80
	bl	free
	mov	x0, x21
	cbnz	x21, .LBB0_3
	b	.LBB0_1
.LBB0_4:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	destroy_pools, .Lfunc_end0-destroy_pools
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	b	free
.Lfunc_end1:
	.size	destroy_cb, .Lfunc_end1-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	//APP
	//NO_APP
	add	x8, x0, #8
	adrp	x10, :got:local_pools
	ldar	x9, [x8]
	ldr	x10, [x10, :got_lo12:local_pools]
	//APP
	//NO_APP
	ldr	x11, [x10, x1, lsl #3]
	add	w9, w9, #1
	//APP
	//NO_APP
	and	x9, x9, #0x7f
	orr	x9, x9, x11
	stlr	x9, [x8]
	//APP
	//NO_APP
	str	x0, [x10, x1, lsl #3]
	ret
.Lfunc_end2:
	.size	retire_cb, .Lfunc_end2-retire_cb
	.cfi_endproc
                                        // -- End function
	.globl	alloc_qnode                     // -- Begin function alloc_qnode
	.p2align	2
	.type	alloc_qnode,@function
alloc_qnode:                            // @alloc_qnode
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	adrp	x8, :got:local_pools
	ldr	x8, [x8, :got_lo12:local_pools]
	ldr	x19, [x8, x0, lsl #3]
	cbz	x19, .LBB3_2
// %bb.1:
	add	x9, x19, #8
	//APP
	//NO_APP
	ldar	x9, [x9]
	//APP
	//NO_APP
	and	x9, x9, #0xffffffffffffff80
	str	x9, [x8, x0, lsl #3]
	adrp	x0, .Lstr.4
	add	x0, x0, :lo12:.Lstr.4
	b	.LBB3_3
.LBB3_2:
	mov	w0, #128                        // =0x80
	mov	w1, #128                        // =0x80
	bl	memalign
	mov	x19, x0
	adrp	x0, .Lstr
	add	x0, x0, :lo12:.Lstr
.LBB3_3:
	bl	puts
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	alloc_qnode, .Lfunc_end3-alloc_qnode
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-96]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	stp	x28, x27, [sp, #16]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	adrp	x25, :got:g_queue
	adrp	x26, :got:local_pools
	mov	x19, x0
	ldr	x25, [x25, :got_lo12:g_queue]
	ldr	x26, [x26, :got_lo12:local_pools]
	mov	x24, xzr
	adrp	x27, .Lstr
	add	x27, x27, :lo12:.Lstr
	adrp	x20, .L.str.2
	add	x20, x20, :lo12:.L.str.2
	adrp	x28, .Lstr.4
	add	x28, x28, :lo12:.Lstr.4
	adrp	x21, .L.str.3
	add	x21, x21, :lo12:.L.str.3
	b	.LBB4_2
.LBB4_1:                                //   in Loop: Header=BB4_2 Depth=1
	clrex
	//APP
	//NO_APP
.LBB4_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_10 Depth 2
                                        //     Child Loop BB4_7 Depth 2
                                        //     Child Loop BB4_24 Depth 2
                                        //       Child Loop BB4_27 Depth 3
                                        //       Child Loop BB4_30 Depth 3
                                        //     Child Loop BB4_34 Depth 2
	//APP
	//NO_APP
	add	x10, x25, #8
	ldar	x9, [x25]
	//APP
	//NO_APP
	//APP
	//NO_APP
	and	x8, x9, #0xffffffffffffff80
	ldar	x10, [x10]
	//APP
	//NO_APP
	orr	x11, x8, #0x8
	//APP
	//NO_APP
	ldar	x11, [x11]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x12, [x25]
	//APP
	//NO_APP
	and	x13, x12, #0xffffffffffffff80
	cmp	x8, x13
	b.ne	.LBB4_2
// %bb.3:                               //   in Loop: Header=BB4_2 Depth=1
	eor	w12, w12, w9
	and	x12, x12, #0x7f
	cbnz	x12, .LBB4_2
// %bb.4:                               //   in Loop: Header=BB4_2 Depth=1
	and	x12, x10, #0xffffffffffffff80
	and	x11, x11, #0xffffffffffffff80
	cmp	x8, x12
	b.ne	.LBB4_9
// %bb.5:                               //   in Loop: Header=BB4_2 Depth=1
	cbz	x11, .LBB4_18
// %bb.6:                               //   in Loop: Header=BB4_2 Depth=1
	add	w8, w10, #1
	//APP
	//NO_APP
	and	x8, x8, #0x7f
	orr	x8, x11, x8
.LBB4_7:                                //   Parent Loop BB4_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x25, #8
	ldaxr	x11, [x9]
	cmp	x11, x10
	b.ne	.LBB4_16
// %bb.8:                               //   in Loop: Header=BB4_7 Depth=2
	stlxr	w11, x8, [x9]
	cbnz	w11, .LBB4_7
	b	.LBB4_17
.LBB4_9:                                //   in Loop: Header=BB4_2 Depth=1
	add	w10, w9, #1
	ldr	x22, [x11]
	//APP
	//NO_APP
	and	x10, x10, #0x7f
	orr	x10, x11, x10
.LBB4_10:                               //   Parent Loop BB4_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x11, [x25]
	cmp	x11, x9
	b.ne	.LBB4_1
// %bb.11:                              //   in Loop: Header=BB4_10 Depth=2
	stlxr	w11, x10, [x25]
	cbnz	w11, .LBB4_10
// %bb.12:                              //   in Loop: Header=BB4_2 Depth=1
	//APP
	//NO_APP
	add	x9, x25, #128
	cmp	x8, x9
	b.eq	.LBB4_14
// %bb.13:                              //   in Loop: Header=BB4_2 Depth=1
	add	x9, x8, #8
	//APP
	//NO_APP
	ldar	x10, [x9]
	//APP
	//NO_APP
	ldr	x11, [x26, x19, lsl #3]
	//APP
	//NO_APP
	add	w10, w10, #1
	and	x10, x10, #0x7f
	orr	x10, x10, x11
	stlr	x10, [x9]
	//APP
	//NO_APP
	str	x8, [x26, x19, lsl #3]
.LBB4_14:                               //   in Loop: Header=BB4_2 Depth=1
	cbz	x22, .LBB4_18
// %bb.15:                              //   in Loop: Header=BB4_2 Depth=1
	ldr	x2, [x22]
	mov	x0, x21
	mov	x1, x19
	bl	printf
	mov	x0, x22
	bl	free
	b	.LBB4_38
.LBB4_16:                               //   in Loop: Header=BB4_2 Depth=1
	clrex
.LBB4_17:                               //   in Loop: Header=BB4_2 Depth=1
	//APP
	//NO_APP
	b	.LBB4_2
.LBB4_18:                               //   in Loop: Header=BB4_2 Depth=1
	mov	w0, #8                          // =0x8
	bl	malloc
	ldr	x22, [x26, x19, lsl #3]
	mov	x23, x0
	str	x24, [x0]
	cbz	x22, .LBB4_20
// %bb.19:                              //   in Loop: Header=BB4_2 Depth=1
	add	x8, x22, #8
	//APP
	//NO_APP
	mov	x0, x28
	ldar	x8, [x8]
	//APP
	//NO_APP
	and	x8, x8, #0xffffffffffffff80
	str	x8, [x26, x19, lsl #3]
	b	.LBB4_21
.LBB4_20:                               //   in Loop: Header=BB4_2 Depth=1
	mov	w0, #128                        // =0x80
	mov	w1, #128                        // =0x80
	bl	memalign
	mov	x22, x0
	mov	x0, x27
.LBB4_21:                               //   in Loop: Header=BB4_2 Depth=1
	bl	puts
	ldr	x2, [x23]
	mov	x0, x20
	mov	x1, x19
	bl	printf
	mov	x8, x22
	str	x23, [x8], #8
	//APP
	//NO_APP
	ldar	x9, [x8]
	//APP
	//NO_APP
	//APP
	//NO_APP
	and	x9, x9, #0x7f
	stlr	x9, [x8]
	//APP
	//NO_APP
	b	.LBB4_24
.LBB4_22:                               //   in Loop: Header=BB4_24 Depth=2
	clrex
.LBB4_23:                               //   in Loop: Header=BB4_24 Depth=2
	//APP
	//NO_APP
.LBB4_24:                               //   Parent Loop BB4_2 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB4_27 Depth 3
                                        //       Child Loop BB4_30 Depth 3
	//APP
	//NO_APP
	add	x11, x25, #8
	ldar	x8, [x11]
	//APP
	//NO_APP
	//APP
	//NO_APP
	and	x12, x8, #0xffffffffffffff80
	orr	x9, x12, #0x8
	ldar	x10, [x9]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x11, [x11]
	//APP
	//NO_APP
	and	x13, x11, #0xffffffffffffff80
	eor	w11, w11, w8
	and	x11, x11, #0x7f
	cmp	x12, x13
	ccmp	x11, #0, #0, eq
	b.ne	.LBB4_24
// %bb.25:                              //   in Loop: Header=BB4_24 Depth=2
	//APP
	//NO_APP
	and	x11, x10, #0xffffffffffffff80
	cbz	x11, .LBB4_29
// %bb.26:                              //   in Loop: Header=BB4_24 Depth=2
	add	w9, w8, #1
	and	x9, x9, #0x7f
	orr	x9, x11, x9
.LBB4_27:                               //   Parent Loop BB4_2 Depth=1
                                        //     Parent Loop BB4_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x10, x25, #8
	ldaxr	x11, [x10]
	cmp	x11, x8
	b.ne	.LBB4_22
// %bb.28:                              //   in Loop: Header=BB4_27 Depth=3
	stlxr	w11, x9, [x10]
	cbnz	w11, .LBB4_27
	b	.LBB4_23
.LBB4_29:                               //   in Loop: Header=BB4_24 Depth=2
	add	w11, w10, #1
	and	x11, x11, #0x7f
	orr	x11, x11, x22
.LBB4_30:                               //   Parent Loop BB4_2 Depth=1
                                        //     Parent Loop BB4_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	ldaxr	x12, [x9]
	cmp	x12, x10
	b.ne	.LBB4_32
// %bb.31:                              //   in Loop: Header=BB4_30 Depth=3
	stlxr	w12, x11, [x9]
	cbnz	w12, .LBB4_30
	b	.LBB4_33
.LBB4_32:                               //   in Loop: Header=BB4_24 Depth=2
	clrex
	//APP
	//NO_APP
	b	.LBB4_24
.LBB4_33:                               //   in Loop: Header=BB4_2 Depth=1
	//APP
	//NO_APP
	add	w9, w8, #1
	//APP
	//NO_APP
	and	x9, x9, #0x7f
	orr	x9, x9, x22
.LBB4_34:                               //   Parent Loop BB4_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x10, x25, #8
	ldaxr	x11, [x10]
	cmp	x11, x8
	b.ne	.LBB4_36
// %bb.35:                              //   in Loop: Header=BB4_34 Depth=2
	stlxr	w11, x9, [x10]
	cbnz	w11, .LBB4_34
	b	.LBB4_37
.LBB4_36:                               //   in Loop: Header=BB4_2 Depth=1
	clrex
.LBB4_37:                               //   in Loop: Header=BB4_2 Depth=1
	//APP
	//NO_APP
.LBB4_38:                               //   in Loop: Header=BB4_2 Depth=1
	add	x24, x24, #1
	cmp	x24, #100
	b.ne	.LBB4_2
// %bb.39:
	mov	x0, xzr
	.cfi_def_cfa wsp, 96
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #96             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end4:
	.size	run, .Lfunc_end4-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	str	x21, [sp, #112]                 // 8-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	adrp	x20, :got:g_queue
	adrp	x19, :got:run
	mov	x0, sp
	ldr	x20, [x20, :got_lo12:g_queue]
	//APP
	//NO_APP
	mov	x1, xzr
	mov	x3, xzr
	mov	x21, sp
	str	xzr, [x20, #136]
	add	x8, x20, #128
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	x8, [x20]
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	x8, [x20, #8]
	//APP
	//NO_APP
	ldr	x19, [x19, :got_lo12:run]
	mov	x2, x19
	bl	pthread_create
	add	x0, x21, #8
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #1                          // =0x1
	bl	pthread_create
	add	x0, x21, #16
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #2                          // =0x2
	bl	pthread_create
	add	x0, x21, #24
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #3                          // =0x3
	bl	pthread_create
	add	x0, x21, #32
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #4                          // =0x4
	bl	pthread_create
	add	x0, x21, #40
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #5                          // =0x5
	bl	pthread_create
	add	x0, x21, #48
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #6                          // =0x6
	bl	pthread_create
	add	x0, x21, #56
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #7                          // =0x7
	bl	pthread_create
	add	x0, x21, #64
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #8                          // =0x8
	bl	pthread_create
	add	x0, x21, #72
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #9                          // =0x9
	bl	pthread_create
	add	x0, x21, #80
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #10                         // =0xa
	bl	pthread_create
	add	x0, x21, #88
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #11                         // =0xb
	bl	pthread_create
	ldr	x0, [sp]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #16]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #24]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #32]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #40]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #48]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #56]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #64]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #72]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #80]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #88]
	mov	x1, xzr
	bl	pthread_join
	b	.LBB5_2
.LBB5_1:                                //   in Loop: Header=BB5_2 Depth=1
	clrex
	//APP
	//NO_APP
.LBB5_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_10 Depth 2
                                        //     Child Loop BB5_7 Depth 2
	//APP
	//NO_APP
	add	x9, x20, #8
	ldar	x8, [x20]
	//APP
	//NO_APP
	//APP
	//NO_APP
	and	x0, x8, #0xffffffffffffff80
	ldar	x9, [x9]
	//APP
	//NO_APP
	orr	x10, x0, #0x8
	//APP
	//NO_APP
	ldar	x10, [x10]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x11, [x20]
	//APP
	//NO_APP
	and	x12, x11, #0xffffffffffffff80
	cmp	x0, x12
	b.ne	.LBB5_2
// %bb.3:                               //   in Loop: Header=BB5_2 Depth=1
	eor	w11, w11, w8
	and	x11, x11, #0x7f
	cbnz	x11, .LBB5_2
// %bb.4:                               //   in Loop: Header=BB5_2 Depth=1
	and	x11, x9, #0xffffffffffffff80
	and	x10, x10, #0xffffffffffffff80
	cmp	x0, x11
	b.ne	.LBB5_9
// %bb.5:                               //   in Loop: Header=BB5_2 Depth=1
	cbz	x10, .LBB5_18
// %bb.6:                               //   in Loop: Header=BB5_2 Depth=1
	add	w8, w9, #1
	//APP
	//NO_APP
	and	x8, x8, #0x7f
	orr	x8, x10, x8
.LBB5_7:                                //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x10, x20, #8
	ldaxr	x11, [x10]
	cmp	x11, x9
	b.ne	.LBB5_16
// %bb.8:                               //   in Loop: Header=BB5_7 Depth=2
	stlxr	w11, x8, [x10]
	cbnz	w11, .LBB5_7
	b	.LBB5_17
.LBB5_9:                                //   in Loop: Header=BB5_2 Depth=1
	add	w9, w8, #1
	ldr	x19, [x10]
	//APP
	//NO_APP
	and	x9, x9, #0x7f
	orr	x9, x10, x9
.LBB5_10:                               //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x10, [x20]
	cmp	x10, x8
	b.ne	.LBB5_1
// %bb.11:                              //   in Loop: Header=BB5_10 Depth=2
	stlxr	w10, x9, [x20]
	cbnz	w10, .LBB5_10
// %bb.12:                              //   in Loop: Header=BB5_2 Depth=1
	//APP
	//NO_APP
	add	x8, x20, #128
	cmp	x0, x8
	b.eq	.LBB5_14
// %bb.13:                              //   in Loop: Header=BB5_2 Depth=1
	bl	free
.LBB5_14:                               //   in Loop: Header=BB5_2 Depth=1
	cbz	x19, .LBB5_18
// %bb.15:                              //   in Loop: Header=BB5_2 Depth=1
	mov	x0, x19
	bl	free
	b	.LBB5_2
.LBB5_16:                               //   in Loop: Header=BB5_2 Depth=1
	clrex
.LBB5_17:                               //   in Loop: Header=BB5_2 Depth=1
	//APP
	//NO_APP
	b	.LBB5_2
.LBB5_18:
	//APP
	//NO_APP
	ldar	x8, [x20]
	//APP
	//NO_APP
	ands	x0, x8, #0xffffffffffffff80
	b.eq	.LBB5_23
// %bb.19:
	add	x19, x20, #128
	b	.LBB5_21
.LBB5_20:                               //   in Loop: Header=BB5_21 Depth=1
	ands	x0, x20, #0xffffffffffffff80
	b.eq	.LBB5_23
.LBB5_21:                               // =>This Inner Loop Header: Depth=1
	add	x8, x0, #8
	//APP
	//NO_APP
	cmp	x0, x19
	ldar	x20, [x8]
	//APP
	//NO_APP
	b.eq	.LBB5_20
// %bb.22:                              //   in Loop: Header=BB5_21 Depth=1
	bl	free
	b	.LBB5_20
.LBB5_23:
	adrp	x19, :got:local_pools
	mov	x20, xzr
	ldr	x19, [x19, :got_lo12:local_pools]
	b	.LBB5_25
.LBB5_24:                               //   in Loop: Header=BB5_25 Depth=1
	add	x20, x20, #1
	cmp	x20, #12
	b.eq	.LBB5_27
.LBB5_25:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_26 Depth 2
	ldr	x0, [x19, x20, lsl #3]
	cbz	x0, .LBB5_24
.LBB5_26:                               //   Parent Loop BB5_25 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x8, x0, #8
	//APP
	//NO_APP
	ldar	x8, [x8]
	//APP
	//NO_APP
	and	x21, x8, #0xffffffffffffff80
	bl	free
	mov	x0, x21
	cbnz	x21, .LBB5_26
	b	.LBB5_24
.LBB5_27:
	mov	w0, wzr
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldr	x21, [sp, #112]                 // 8-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end5:
	.size	main, .Lfunc_end5-main
	.cfi_endproc
                                        // -- End function
	.type	local_pools,@object             // @local_pools
	.bss
	.globl	local_pools
	.p2align	3, 0x0
local_pools:
	.zero	96
	.size	local_pools, 96

	.type	g_queue,@object                 // @g_queue
	.globl	g_queue
	.p2align	7, 0x0
g_queue:
	.zero	256
	.size	g_queue, 256

	.type	.L.str.2,@object                // @.str.2
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.2:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.2, 16

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.3, 16

	.type	.Lstr,@object                   // @str
.Lstr:
	.asciz	"New allocation"
	.size	.Lstr, 15

	.type	.Lstr.4,@object                 // @str.4
.Lstr.4:
	.asciz	"Recycle allocation"
	.size	.Lstr.4, 19

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
	.addrsig_sym g_queue
