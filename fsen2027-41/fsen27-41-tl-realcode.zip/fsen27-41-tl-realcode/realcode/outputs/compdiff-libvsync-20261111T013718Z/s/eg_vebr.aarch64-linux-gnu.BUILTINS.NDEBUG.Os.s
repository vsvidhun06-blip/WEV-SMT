	.file	"eg_vebr.c"
	.text
	.p2align	2                               // -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               // @lock_acq
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_lock
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               // @lock_rel
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_unlock
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        // -- End function
	.globl	free_cb                         // -- Begin function free_cb
	.p2align	2
	.type	free_cb,@function
free_cb:                                // @free_cb
	.cfi_startproc
// %bb.0:
	sub	x0, x0, #16
	b	free
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	//APP
	//NO_APP
	adrp	x8, :got:g_vebr
	mov	x10, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	dmb	ish
	movk	x10, #43691
	//APP
	//NO_APP
	ldr	x8, [x8, :got_lo12:g_vebr]
	//APP
	//NO_APP
	ldar	x9, [x8]
	//APP
	//NO_APP
	umulh	x10, x9, x10
	lsr	x11, x10, #1
	lsl	x11, x11, #1
	add	x10, x11, x10, lsr #1
	adrp	x11, :got:free_cb
	ldr	x11, [x11, :got_lo12:free_cb]
	str	xzr, [x0, #16]!
	sub	x9, x9, x10
	add	x8, x8, x9, lsl #4
	stp	x11, xzr, [x0, #16]
	//APP
	//NO_APP
	add	x8, x8, #8
	ldar	x9, [x8]
	//APP
	//NO_APP
.LBB3_1:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB3_2 Depth 2
	str	x9, [x0]
	//APP
	//NO_APP
.LBB3_2:                                //   Parent Loop BB3_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldxr	x10, [x8]
	cmp	x10, x9
	b.ne	.LBB3_5
// %bb.3:                               //   in Loop: Header=BB3_2 Depth=2
	stlxr	w11, x0, [x8]
	cbnz	w11, .LBB3_2
// %bb.4:                               //   in Loop: Header=BB3_1 Depth=1
	mov	w11, #1                         // =0x1
	b	.LBB3_6
.LBB3_5:                                //   in Loop: Header=BB3_1 Depth=1
	mov	w11, wzr
	clrex
.LBB3_6:                                //   in Loop: Header=BB3_1 Depth=1
	cmp	w11, #0
	//APP
	//NO_APP
	csel	x10, x9, x10, ne
	cmp	x9, x10
	mov	x9, x10
	b.ne	.LBB3_1
// %bb.7:
	//APP
	//NO_APP
	add	x8, x8, #8
.LBB3_8:                                // =>This Inner Loop Header: Depth=1
	ldxr	x9, [x8]
	add	x9, x9, #1
	stxr	w10, x9, [x8]
	cbnz	w10, .LBB3_8
// %bb.9:
	//APP
	//NO_APP
	ret
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	b	free
.Lfunc_end4:
	.size	destroy_cb, .Lfunc_end4-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	reclaim                         // -- Begin function reclaim
	.p2align	2
	.type	reclaim,@function
reclaim:                                // @reclaim
	.cfi_startproc
// %bb.0:
	stp	x30, x25, [sp, #-64]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x24, x23, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w30, -64
	adrp	x21, :got:g_stop
	ldr	x21, [x21, :got_lo12:g_stop]
	//APP
	//NO_APP
	ldarb	w8, [x21]
	//APP
	//NO_APP
	cbnz	w8, .LBB5_18
// %bb.1:
	adrp	x22, :got:g_vebr
	mov	x23, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x22, [x22, :got_lo12:g_vebr]
	movk	x23, #43691
.LBB5_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_3 Depth 2
                                        //     Child Loop BB5_5 Depth 2
                                        //     Child Loop BB5_9 Depth 2
                                        //     Child Loop BB5_14 Depth 2
	//APP
	//NO_APP
	dmb	ish
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x24, [x22]
	//APP
	//NO_APP
	//APP
	//NO_APP
	add	x8, x24, #2
	umulh	x9, x8, x23
	lsr	x10, x9, #1
	lsl	x10, x10, #1
	add	x9, x10, x9, lsr #1
	sub	x8, x8, x9
	add	x8, x22, x8, lsl #4
	add	x8, x8, #8
.LBB5_3:                                //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x20, [x8]
	stxr	w9, xzr, [x8]
	cbnz	w9, .LBB5_3
// %bb.4:                               //   in Loop: Header=BB5_2 Depth=1
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	xzr, [x8, #8]
	//APP
	//NO_APP
	ldr	x8, [x22, #72]
	ldr	x0, [x22, #88]
	blr	x8
	ldr	x8, [x22, #56]
	cbz	x8, .LBB5_8
.LBB5_5:                                //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	//APP
	//NO_APP
	add	x9, x8, #16
	ldar	x9, [x9]
	//APP
	//NO_APP
	cbz	x9, .LBB5_7
// %bb.6:                               //   in Loop: Header=BB5_5 Depth=2
	cmp	x9, x24
	b.lo	.LBB5_5
.LBB5_7:                                //   in Loop: Header=BB5_5 Depth=2
	ldr	x8, [x8]
	cbnz	x8, .LBB5_5
.LBB5_8:                                //   in Loop: Header=BB5_2 Depth=1
	ldp	x8, x0, [x22, #80]
	blr	x8
	//APP
	//NO_APP
	add	x8, x24, #1
.LBB5_9:                                //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x9, [x22]
	cmp	x9, x24
	b.ne	.LBB5_11
// %bb.10:                              //   in Loop: Header=BB5_9 Depth=2
	stlxr	w9, x8, [x22]
	cbnz	w9, .LBB5_9
	b	.LBB5_12
.LBB5_11:                               //   in Loop: Header=BB5_2 Depth=1
	clrex
.LBB5_12:                               //   in Loop: Header=BB5_2 Depth=1
	//APP
	//NO_APP
	cbz	x20, .LBB5_17
// %bb.13:                              //   in Loop: Header=BB5_2 Depth=1
	mov	x24, xzr
.LBB5_14:                               //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldp	x8, x1, [x20, #16]
	mov	x0, x20
	ldr	x25, [x20]
	blr	x8
	sub	x24, x24, #1
	mov	x20, x25
	cbnz	x25, .LBB5_14
// %bb.15:                              //   in Loop: Header=BB5_2 Depth=1
	cbz	x24, .LBB5_17
// %bb.16:                              //   in Loop: Header=BB5_2 Depth=1
	neg	x1, x24
	mov	x0, x19
	bl	printf
.LBB5_17:                               //   in Loop: Header=BB5_2 Depth=1
	//APP
	//NO_APP
	ldarb	w8, [x21]
	//APP
	//NO_APP
	cbz	w8, .LBB5_2
.LBB5_18:
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             // 16-byte Folded Reload
	ldp	x30, x25, [sp], #64             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w30
	ret
.Lfunc_end5:
	.size	reclaim, .Lfunc_end5-reclaim
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	str	x30, [sp, #32]                  // 8-byte Folded Spill
	stp	x28, x27, [sp, #48]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -96
	.cfi_remember_state
	cbz	x0, .LBB6_44
// %bb.1:
	mov	x26, sp
	//APP
	//NO_APP
	adrp	x25, :got:g_vebr
	add	x8, x26, #16
	mov	x19, x0
	stlr	xzr, [x8]
	ldr	x25, [x25, :got_lo12:g_vebr]
	//APP
	//NO_APP
	str	wzr, [sp, #24]
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldr	x8, [x25, #56]
	str	x8, [sp]
	cbz	x8, .LBB6_3
// %bb.2:
	str	x26, [x8, #8]
.LBB6_3:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	str	xzr, [sp, #8]
	add	x8, x8, #1
	stp	x26, x8, [x25, #56]
	blr	x9
	adrp	x27, :got:g_queue
	mov	x20, xzr
	adrp	x21, .L.str.1
	add	x21, x21, :lo12:.L.str.1
	ldr	x27, [x27, :got_lo12:g_queue]
	ldr	w8, [sp, #24]
	mov	w28, #10000                     // =0x2710
	adrp	x22, .L.str.2
	add	x22, x22, :lo12:.L.str.2
.LBB6_4:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB6_6 Depth 2
                                        //       Child Loop BB6_13 Depth 3
                                        //       Child Loop BB6_10 Depth 3
                                        //     Child Loop BB6_23 Depth 2
                                        //       Child Loop BB6_25 Depth 3
                                        //       Child Loop BB6_27 Depth 3
                                        //     Child Loop BB6_33 Depth 2
	add	w9, w8, #1
	str	w9, [sp, #24]
	cbnz	w8, .LBB6_6
// %bb.5:                               //   in Loop: Header=BB6_4 Depth=1
	//APP
	//NO_APP
	add	x9, x26, #16
	ldar	x8, [x25]
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	x8, [x9]
	//APP
	//NO_APP
	//APP
	//NO_APP
	dmb	ish
	//APP
	//NO_APP
.LBB6_6:                                //   Parent Loop BB6_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB6_13 Depth 3
                                        //       Child Loop BB6_10 Depth 3
	//APP
	//NO_APP
	add	x8, x27, #8
	ldar	x0, [x27]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x9, [x8]
	//APP
	//NO_APP
	add	x8, x0, #8
	//APP
	//NO_APP
	ldar	x8, [x8]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x10, [x27]
	//APP
	//NO_APP
	cmp	x0, x10
	b.ne	.LBB6_6
// %bb.7:                               //   in Loop: Header=BB6_6 Depth=2
	cmp	x0, x9
	b.ne	.LBB6_12
// %bb.8:                               //   in Loop: Header=BB6_6 Depth=2
	cbz	x8, .LBB6_22
// %bb.9:                               //   in Loop: Header=BB6_6 Depth=2
	//APP
	//NO_APP
.LBB6_10:                               //   Parent Loop BB6_4 Depth=1
                                        //     Parent Loop BB6_6 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x9, x27, #8
	ldaxr	x10, [x9]
	cmp	x10, x0
	b.ne	.LBB6_16
// %bb.11:                              //   in Loop: Header=BB6_10 Depth=3
	stlxr	w10, x8, [x9]
	cbnz	w10, .LBB6_10
	b	.LBB6_17
.LBB6_12:                               //   in Loop: Header=BB6_6 Depth=2
	ldr	x23, [x8]
	//APP
	//NO_APP
.LBB6_13:                               //   Parent Loop BB6_4 Depth=1
                                        //     Parent Loop BB6_6 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	ldaxr	x9, [x27]
	cmp	x9, x0
	b.ne	.LBB6_15
// %bb.14:                              //   in Loop: Header=BB6_13 Depth=3
	stlxr	w9, x8, [x27]
	cbnz	w9, .LBB6_13
	b	.LBB6_18
.LBB6_15:                               //   in Loop: Header=BB6_6 Depth=2
	clrex
	//APP
	//NO_APP
	b	.LBB6_6
.LBB6_16:                               //   in Loop: Header=BB6_6 Depth=2
	clrex
.LBB6_17:                               //   in Loop: Header=BB6_6 Depth=2
	//APP
	//NO_APP
	b	.LBB6_6
.LBB6_18:                               //   in Loop: Header=BB6_4 Depth=1
	//APP
	//NO_APP
	add	x8, x27, #16
	cmp	x0, x8
	b.eq	.LBB6_20
// %bb.19:                              //   in Loop: Header=BB6_4 Depth=1
	bl	retire_cb
.LBB6_20:                               //   in Loop: Header=BB6_4 Depth=1
	cbz	x23, .LBB6_22
// %bb.21:                              //   in Loop: Header=BB6_4 Depth=1
	ldr	x2, [x23]
	mov	x0, x22
	mov	x1, x19
	bl	printf
	mov	x0, x23
	bl	free
	b	.LBB6_37
.LBB6_22:                               //   in Loop: Header=BB6_4 Depth=1
	mov	w0, #8                          // =0x8
	bl	malloc
	mov	x24, x0
	str	x20, [x0]
	mov	w0, #48                         // =0x30
	bl	malloc
	mov	x23, x0
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	bl	printf
	mov	x8, x23
	str	x24, [x8], #8
	//APP
	//NO_APP
	str	xzr, [x8]
	//APP
	//NO_APP
.LBB6_23:                               //   Parent Loop BB6_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB6_25 Depth 3
                                        //       Child Loop BB6_27 Depth 3
	//APP
	//NO_APP
	add	x11, x27, #8
	ldar	x8, [x11]
	//APP
	//NO_APP
	//APP
	//NO_APP
	add	x9, x8, #8
	ldar	x10, [x9]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x11, [x11]
	//APP
	//NO_APP
	cmp	x8, x11
	b.ne	.LBB6_23
// %bb.24:                              //   in Loop: Header=BB6_23 Depth=2
	//APP
	//NO_APP
	cbz	x10, .LBB6_27
.LBB6_25:                               //   Parent Loop BB6_4 Depth=1
                                        //     Parent Loop BB6_23 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x9, x27, #8
	ldaxr	x11, [x9]
	cmp	x11, x8
	b.ne	.LBB6_29
// %bb.26:                              //   in Loop: Header=BB6_25 Depth=3
	stlxr	w11, x10, [x9]
	cbnz	w11, .LBB6_25
	b	.LBB6_30
.LBB6_27:                               //   Parent Loop BB6_4 Depth=1
                                        //     Parent Loop BB6_23 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	ldaxr	x10, [x9]
	cbnz	x10, .LBB6_31
// %bb.28:                              //   in Loop: Header=BB6_27 Depth=3
	stlxr	w10, x23, [x9]
	cbnz	w10, .LBB6_27
	b	.LBB6_32
.LBB6_29:                               //   in Loop: Header=BB6_23 Depth=2
	clrex
.LBB6_30:                               //   in Loop: Header=BB6_23 Depth=2
	//APP
	//NO_APP
	b	.LBB6_23
.LBB6_31:                               //   in Loop: Header=BB6_23 Depth=2
	clrex
	//APP
	//NO_APP
	b	.LBB6_23
.LBB6_32:                               //   in Loop: Header=BB6_4 Depth=1
	//APP
	//NO_APP
	//APP
	//NO_APP
.LBB6_33:                               //   Parent Loop BB6_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x27, #8
	ldaxr	x10, [x9]
	cmp	x10, x8
	b.ne	.LBB6_35
// %bb.34:                              //   in Loop: Header=BB6_33 Depth=2
	stlxr	w10, x23, [x9]
	cbnz	w10, .LBB6_33
	b	.LBB6_36
.LBB6_35:                               //   in Loop: Header=BB6_4 Depth=1
	clrex
.LBB6_36:                               //   in Loop: Header=BB6_4 Depth=1
	//APP
	//NO_APP
.LBB6_37:                               //   in Loop: Header=BB6_4 Depth=1
	ldr	w8, [sp, #24]
	cmp	w8, #1
	b.ne	.LBB6_39
// %bb.38:                              //   in Loop: Header=BB6_4 Depth=1
	add	x8, x26, #16
	//APP
	//NO_APP
	stlr	xzr, [x8]
	//APP
	//NO_APP
	ldr	w8, [sp, #24]
.LBB6_39:                               //   in Loop: Header=BB6_4 Depth=1
	add	x20, x20, #1
	sub	w8, w8, #1
	cmp	x20, x28
	str	w8, [sp, #24]
	b.ne	.LBB6_4
// %bb.40:
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldp	x9, x8, [sp]
	cbz	x8, .LBB6_46
// %bb.41:
	str	x9, [x8]
	cbz	x9, .LBB6_43
.LBB6_42:
	str	x8, [x9, #8]
.LBB6_43:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	sub	x8, x8, #1
	str	x8, [x25, #64]
	blr	x9
	b	.LBB6_45
.LBB6_44:
	bl	reclaim
.LBB6_45:
	ldp	x20, x19, [sp, #112]            // 16-byte Folded Reload
	mov	x0, xzr
	ldp	x22, x21, [sp, #96]             // 16-byte Folded Reload
	ldr	x30, [sp, #32]                  // 8-byte Folded Reload
	ldp	x24, x23, [sp, #80]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	ret
.LBB6_46:
	.cfi_restore_state
	str	x9, [x25, #56]
	cbnz	x9, .LBB6_42
	b	.LBB6_43
.Lfunc_end6:
	.size	run, .Lfunc_end6-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x30, x23, [sp, #96]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w30, -48
	adrp	x0, :got:g_lock
	mov	x1, xzr
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_init
	adrp	x8, :got:g_lock_lib
	adrp	x22, :got:g_vebr
	mov	w9, #3                          // =0x3
	ldr	x8, [x8, :got_lo12:g_lock_lib]
	ldr	q0, [x8]
	ldr	x8, [x8, #16]
	ldr	x22, [x22, :got_lo12:g_vebr]
	str	x8, [sp, #16]
	add	x8, x22, #16
	str	q0, [sp]
	stp	xzr, xzr, [x22, #56]
.LBB7_1:                                // =>This Inner Loop Header: Depth=1
	sub	x10, x8, #8
	//APP
	//NO_APP
	subs	x9, x9, #1
	stlr	xzr, [x10]
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	xzr, [x8]
	add	x8, x8, #16
	//APP
	//NO_APP
	b.ne	.LBB7_1
// %bb.2:
	mov	w8, #1                          // =0x1
	//APP
	//NO_APP
	adrp	x23, :got:g_queue
	stlr	x8, [x22]
	adrp	x20, :got:run
	mov	x19, xzr
	//APP
	//NO_APP
	mov	x21, sp
	ldr	q0, [sp]
	ldr	x23, [x23, :got_lo12:g_queue]
	ldr	x8, [sp, #16]
	mov	x9, x23
	stur	q0, [x22, #72]
	str	x8, [x22, #88]
	str	xzr, [x9, #16]!
	//APP
	//NO_APP
	str	xzr, [x23, #24]
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	x9, [x23]
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	x9, [x23, #8]
	//APP
	//NO_APP
	ldr	x20, [x20, :got_lo12:run]
.LBB7_3:                                // =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, xzr
	mov	x2, x20
	mov	x3, x19
	bl	pthread_create
	add	x19, x19, #1
	add	x21, x21, #8
	cmp	x19, #12
	b.ne	.LBB7_3
// %bb.4:
	mov	w19, #8                         // =0x8
	mov	x20, sp
.LBB7_5:                                // =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19]
	mov	x1, xzr
	bl	pthread_join
	add	x19, x19, #8
	cmp	x19, #96
	b.ne	.LBB7_5
// %bb.6:
	adrp	x8, :got:g_stop
	mov	w9, #1                          // =0x1
	mov	x1, xzr
	ldr	x8, [x8, :got_lo12:g_stop]
	//APP
	//NO_APP
	stlrb	w9, [x8]
	//APP
	//NO_APP
	ldr	x0, [sp]
	bl	pthread_join
.LBB7_7:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_14 Depth 2
                                        //     Child Loop BB7_11 Depth 2
	//APP
	//NO_APP
	add	x8, x23, #8
	ldar	x0, [x23]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x9, [x8]
	//APP
	//NO_APP
	add	x8, x0, #8
	//APP
	//NO_APP
	ldar	x8, [x8]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x10, [x23]
	//APP
	//NO_APP
	cmp	x0, x10
	b.ne	.LBB7_7
// %bb.8:                               //   in Loop: Header=BB7_7 Depth=1
	cmp	x0, x9
	b.ne	.LBB7_13
// %bb.9:                               //   in Loop: Header=BB7_7 Depth=1
	cbz	x8, .LBB7_23
// %bb.10:                              //   in Loop: Header=BB7_7 Depth=1
	//APP
	//NO_APP
.LBB7_11:                               //   Parent Loop BB7_7 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x23, #8
	ldaxr	x10, [x9]
	cmp	x10, x0
	b.ne	.LBB7_21
// %bb.12:                              //   in Loop: Header=BB7_11 Depth=2
	stlxr	w10, x8, [x9]
	cbnz	w10, .LBB7_11
	b	.LBB7_22
.LBB7_13:                               //   in Loop: Header=BB7_7 Depth=1
	ldr	x19, [x8]
	//APP
	//NO_APP
.LBB7_14:                               //   Parent Loop BB7_7 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x9, [x23]
	cmp	x9, x0
	b.ne	.LBB7_20
// %bb.15:                              //   in Loop: Header=BB7_14 Depth=2
	stlxr	w9, x8, [x23]
	cbnz	w9, .LBB7_14
// %bb.16:                              //   in Loop: Header=BB7_7 Depth=1
	//APP
	//NO_APP
	add	x8, x23, #16
	cmp	x0, x8
	b.eq	.LBB7_18
// %bb.17:                              //   in Loop: Header=BB7_7 Depth=1
	bl	free
.LBB7_18:                               //   in Loop: Header=BB7_7 Depth=1
	cbz	x19, .LBB7_23
// %bb.19:                              //   in Loop: Header=BB7_7 Depth=1
	mov	x0, x19
	bl	free
	b	.LBB7_7
.LBB7_20:                               //   in Loop: Header=BB7_7 Depth=1
	clrex
	//APP
	//NO_APP
	b	.LBB7_7
.LBB7_21:                               //   in Loop: Header=BB7_7 Depth=1
	clrex
.LBB7_22:                               //   in Loop: Header=BB7_7 Depth=1
	//APP
	//NO_APP
	b	.LBB7_7
.LBB7_23:
	//APP
	//NO_APP
	ldar	x0, [x23]
	//APP
	//NO_APP
	cbz	x0, .LBB7_28
// %bb.24:
	add	x19, x23, #16
.LBB7_25:                               // =>This Inner Loop Header: Depth=1
	add	x8, x0, #8
	//APP
	//NO_APP
	cmp	x0, x19
	ldar	x20, [x8]
	//APP
	//NO_APP
	b.eq	.LBB7_27
// %bb.26:                              //   in Loop: Header=BB7_25 Depth=1
	bl	free
.LBB7_27:                               //   in Loop: Header=BB7_25 Depth=1
	mov	x0, x20
	cbnz	x20, .LBB7_25
.LBB7_28:
	mov	x19, xzr
.LBB7_29:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_30 Depth 2
                                        //     Child Loop BB7_32 Depth 2
	add	x8, x22, x19, lsl #4
	//APP
	//NO_APP
	add	x8, x8, #8
.LBB7_30:                               //   Parent Loop BB7_29 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x0, [x8]
	stxr	w9, xzr, [x8]
	cbnz	w9, .LBB7_30
// %bb.31:                              //   in Loop: Header=BB7_29 Depth=1
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	xzr, [x8, #8]
	//APP
	//NO_APP
	cbz	x0, .LBB7_33
.LBB7_32:                               //   Parent Loop BB7_29 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldp	x8, x1, [x0, #16]
	ldr	x20, [x0]
	blr	x8
	mov	x0, x20
	cbnz	x20, .LBB7_32
.LBB7_33:                               //   in Loop: Header=BB7_29 Depth=1
	add	x19, x19, #1
	cmp	x19, #3
	b.ne	.LBB7_29
// %bb.34:
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_destroy
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	mov	w0, wzr
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldp	x30, x23, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	ret
.Lfunc_end7:
	.size	main, .Lfunc_end7-main
	.cfi_endproc
                                        // -- End function
	.type	g_lock,@object                  // @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	48
	.size	g_lock, 48

	.type	g_lock_lib,@object              // @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.xword	lock_acq
	.xword	lock_rel
	.xword	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  // @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  // @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 // @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                // @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym run
	.addrsig_sym g_lock
	.addrsig_sym g_vebr
	.addrsig_sym g_queue
