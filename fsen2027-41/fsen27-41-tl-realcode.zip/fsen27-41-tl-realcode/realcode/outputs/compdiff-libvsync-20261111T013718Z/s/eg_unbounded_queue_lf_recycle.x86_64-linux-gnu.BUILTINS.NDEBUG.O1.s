	.file	"eg_unbounded_queue_lf_recycle.c"
	.text
	.globl	destroy_pools                   # -- Begin function destroy_pools
	.p2align	4
	.type	destroy_pools,@function
destroy_pools:                          # @destroy_pools
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	xorl	%ebx, %ebx
	movq	local_pools@GOTPCREL(%rip), %r14
	jmp	.LBB0_1
	.p2align	4
.LBB0_3:                                #   in Loop: Header=BB0_1 Depth=1
	addq	$1, %rbx
	cmpq	$12, %rbx
	je	.LBB0_4
.LBB0_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_2 Depth 2
	movq	(%r14,%rbx,8), %rdi
	testq	%rdi, %rdi
	je	.LBB0_3
	.p2align	4
.LBB0_2:                                #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	#APP
	#NO_APP
	movq	8(%rdi), %r15
	#APP
	#NO_APP
	callq	free@PLT
	andq	$-128, %r15
	movq	%r15, %rdi
	jne	.LBB0_2
	jmp	.LBB0_3
.LBB0_4:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end0:
	.size	destroy_pools, .Lfunc_end0-destroy_pools
	.cfi_endproc
                                        # -- End function
	.globl	destroy_cb                      # -- Begin function destroy_cb
	.p2align	4
	.type	destroy_cb,@function
destroy_cb:                             # @destroy_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	free@PLT                        # TAILCALL
.Lfunc_end1:
	.size	destroy_cb, .Lfunc_end1-destroy_cb
	.cfi_endproc
                                        # -- End function
	.globl	retire_cb                       # -- Begin function retire_cb
	.p2align	4
	.type	retire_cb,@function
retire_cb:                              # @retire_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	#APP
	#NO_APP
	movq	8(%rdi), %rax
	#APP
	#NO_APP
	movq	local_pools@GOTPCREL(%rip), %rcx
	addl	$1, %eax
	andl	$127, %eax
	orq	(%rcx,%rsi,8), %rax
	#APP
	#NO_APP
	xchgq	%rax, 8(%rdi)
	#APP
	#NO_APP
	movq	%rdi, (%rcx,%rsi,8)
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end2:
	.size	retire_cb, .Lfunc_end2-retire_cb
	.cfi_endproc
                                        # -- End function
	.globl	alloc_qnode                     # -- Begin function alloc_qnode
	.p2align	4
	.type	alloc_qnode,@function
alloc_qnode:                            # @alloc_qnode
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	local_pools@GOTPCREL(%rip), %rax
	movq	(%rax,%rdi,8), %rbx
	testq	%rbx, %rbx
	je	.LBB3_2
# %bb.1:
	#APP
	#NO_APP
	movq	8(%rbx), %rcx
	#APP
	#NO_APP
	andq	$-128, %rcx
	movq	%rcx, (%rax,%rdi,8)
	leaq	.Lstr.4(%rip), %rdi
	jmp	.LBB3_3
.LBB3_2:
	movl	$128, %edi
	movl	$128, %esi
	callq	memalign@PLT
	movq	%rax, %rbx
	leaq	.Lstr(%rip), %rdi
.LBB3_3:
	callq	puts@PLT
	movq	%rbx, %rax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	alloc_qnode, .Lfunc_end3-alloc_qnode
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	movq	g_queue@GOTPCREL(%rip), %r15
	leaq	128(%r15), %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	xorl	%r14d, %r14d
	jmp	.LBB4_1
	.p2align	4
.LBB4_5:                                #   in Loop: Header=BB4_1 Depth=1
	movq	(%rsi), %r12
	leal	1(%rax), %ecx
	andl	$127, %ecx
	orq	%rsi, %rcx
	#APP
	#NO_APP
	lock		cmpxchgq	%rcx, (%r15)
	setne	%al
	#APP
	#NO_APP
	testb	%al, %al
	je	.LBB4_6
.LBB4_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB4_13 Depth 2
	#APP
	#NO_APP
	movq	(%r15), %rax
	#APP
	#NO_APP
	movq	%rax, %rdx
	andq	$-128, %rdx
	#APP
	#NO_APP
	movq	8(%r15), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rdx), %rsi
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r15), %rdi
	#APP
	#NO_APP
	movq	%rdi, %r8
	andq	$-128, %r8
	xorq	%rdx, %r8
	xorq	%rax, %rdi
	andl	$127, %edi
	orq	%r8, %rdi
	jne	.LBB4_1
# %bb.2:                                #   in Loop: Header=BB4_1 Depth=1
	andq	$-128, %rsi
	movq	%rcx, %rdi
	andq	$-128, %rdi
	cmpq	%rdi, %rdx
	jne	.LBB4_5
# %bb.3:                                #   in Loop: Header=BB4_1 Depth=1
	testq	%rsi, %rsi
	je	.LBB4_9
# %bb.4:                                #   in Loop: Header=BB4_1 Depth=1
	leal	1(%rcx), %eax
	andl	$127, %eax
	orq	%rax, %rsi
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rsi, 8(%r15)
	#APP
	#NO_APP
	jmp	.LBB4_1
.LBB4_6:                                #   in Loop: Header=BB4_1 Depth=1
	cmpq	-48(%rbp), %rdx                 # 8-byte Folded Reload
	je	.LBB4_8
# %bb.7:                                #   in Loop: Header=BB4_1 Depth=1
	#APP
	#NO_APP
	movq	8(%rdx), %rax
	#APP
	#NO_APP
	addl	$1, %eax
	andl	$127, %eax
	movq	local_pools@GOTPCREL(%rip), %rcx
	orq	(%rcx,%rbx,8), %rax
	#APP
	#NO_APP
	xchgq	%rax, 8(%rdx)
	#APP
	#NO_APP
	movq	%rdx, (%rcx,%rbx,8)
.LBB4_8:                                #   in Loop: Header=BB4_1 Depth=1
	testq	%r12, %r12
	je	.LBB4_9
# %bb.17:                               #   in Loop: Header=BB4_1 Depth=1
	movq	(%r12), %rdx
	leaq	.L.str.3(%rip), %rdi
	movq	%rbx, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	movq	%r12, %rdi
	callq	free@PLT
	jmp	.LBB4_18
.LBB4_9:                                #   in Loop: Header=BB4_1 Depth=1
	movl	$8, %edi
	callq	malloc@PLT
	movq	%rax, %r13
	movq	%r14, (%rax)
	movq	local_pools@GOTPCREL(%rip), %rcx
	movq	(%rcx,%rbx,8), %r12
	testq	%r12, %r12
	je	.LBB4_11
# %bb.10:                               #   in Loop: Header=BB4_1 Depth=1
	#APP
	#NO_APP
	movq	8(%r12), %rax
	#APP
	#NO_APP
	andq	$-128, %rax
	movq	%rax, (%rcx,%rbx,8)
	leaq	.Lstr.4(%rip), %rdi
	jmp	.LBB4_12
.LBB4_11:                               #   in Loop: Header=BB4_1 Depth=1
	movl	$128, %edi
	movl	$128, %esi
	callq	memalign@PLT
	movq	%rax, %r12
	leaq	.Lstr(%rip), %rdi
.LBB4_12:                               #   in Loop: Header=BB4_1 Depth=1
	callq	puts@PLT
	movq	(%r13), %rdx
	leaq	.L.str.2(%rip), %rdi
	movq	%rbx, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	movq	%r13, (%r12)
	#APP
	#NO_APP
	movq	8(%r12), %rax
	#APP
	#NO_APP
	andl	$127, %eax
	#APP
	#NO_APP
	xchgq	%rax, 8(%r12)
	#APP
	#NO_APP
	jmp	.LBB4_13
	.p2align	4
.LBB4_20:                               #   in Loop: Header=BB4_13 Depth=2
	leal	1(%rcx), %eax
	andl	$127, %eax
	orq	%rax, %rsi
	movq	%rcx, %rax
	lock		cmpxchgq	%rsi, 8(%r15)
	#APP
	#NO_APP
.LBB4_13:                               #   Parent Loop BB4_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	#APP
	#NO_APP
	movq	8(%r15), %rcx
	#APP
	#NO_APP
	movq	%rcx, %rdx
	andq	$-128, %rdx
	#APP
	#NO_APP
	movq	8(%rdx), %rax
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%r15), %rsi
	#APP
	#NO_APP
	movq	%rsi, %rdi
	andq	$-128, %rdi
	xorq	%rdx, %rdi
	xorq	%rcx, %rsi
	andl	$127, %esi
	orq	%rdi, %rsi
	jne	.LBB4_13
# %bb.14:                               #   in Loop: Header=BB4_13 Depth=2
	movq	%rax, %rsi
	andq	$-128, %rsi
	#APP
	#NO_APP
	testq	%rsi, %rsi
	jne	.LBB4_20
# %bb.15:                               #   in Loop: Header=BB4_13 Depth=2
	leal	1(%rax), %esi
	andl	$127, %esi
	orq	%r12, %rsi
	lock		cmpxchgq	%rsi, 8(%rdx)
	sete	%al
	#APP
	#NO_APP
	testb	%al, %al
	je	.LBB4_13
# %bb.16:                               #   in Loop: Header=BB4_1 Depth=1
	leal	1(%rcx), %edx
	andl	$127, %edx
	orq	%r12, %rdx
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rdx, 8(%r15)
	#APP
	#NO_APP
.LBB4_18:                               #   in Loop: Header=BB4_1 Depth=1
	addq	$1, %r14
	cmpq	$100, %r14
	jne	.LBB4_1
# %bb.19:
	xorl	%eax, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end4:
	.size	run, .Lfunc_end4-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	#APP
	#NO_APP
	movq	g_queue@GOTPCREL(%rip), %r15
	movq	$0, 136(%r15)
	#APP
	#NO_APP
	#APP
	#NO_APP
	leaq	128(%r15), %r14
	movq	%r14, (%r15)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	%r14, 8(%r15)
	#APP
	#NO_APP
	movq	run@GOTPCREL(%rip), %rbx
	leaq	-128(%rbp), %rdi
	xorl	%esi, %esi
	movq	%rbx, %rdx
	xorl	%ecx, %ecx
	callq	pthread_create@PLT
	leaq	-120(%rbp), %rdi
	movl	$1, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-112(%rbp), %rdi
	movl	$2, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-104(%rbp), %rdi
	movl	$3, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-96(%rbp), %rdi
	movl	$4, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-88(%rbp), %rdi
	movl	$5, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-80(%rbp), %rdi
	movl	$6, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-72(%rbp), %rdi
	movl	$7, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-64(%rbp), %rdi
	movl	$8, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-56(%rbp), %rdi
	movl	$9, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-48(%rbp), %rdi
	movl	$10, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-40(%rbp), %rdi
	movl	$11, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	movq	-128(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-120(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-112(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-104(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-96(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-88(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-80(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-72(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-64(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-56(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-48(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-40(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	.p2align	4
.LBB5_1:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	movq	(%r15), %rax
	#APP
	#NO_APP
	movq	%rax, %rdi
	andq	$-128, %rdi
	#APP
	#NO_APP
	movq	8(%r15), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rdi), %rdx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r15), %rsi
	#APP
	#NO_APP
	movq	%rsi, %r8
	andq	$-128, %r8
	xorq	%rdi, %r8
	xorq	%rax, %rsi
	andl	$127, %esi
	orq	%r8, %rsi
	jne	.LBB5_1
# %bb.2:                                #   in Loop: Header=BB5_1 Depth=1
	andq	$-128, %rdx
	movq	%rcx, %rsi
	andq	$-128, %rsi
	cmpq	%rsi, %rdi
	jne	.LBB5_5
# %bb.3:                                #   in Loop: Header=BB5_1 Depth=1
	testq	%rdx, %rdx
	je	.LBB5_10
# %bb.4:                                #   in Loop: Header=BB5_1 Depth=1
	leal	1(%rcx), %eax
	andl	$127, %eax
	orq	%rax, %rdx
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rdx, 8(%r15)
	#APP
	#NO_APP
	jmp	.LBB5_1
	.p2align	4
.LBB5_5:                                #   in Loop: Header=BB5_1 Depth=1
	movq	(%rdx), %rbx
	leal	1(%rax), %ecx
	andl	$127, %ecx
	orq	%rdx, %rcx
	#APP
	#NO_APP
	lock		cmpxchgq	%rcx, (%r15)
	setne	%al
	#APP
	#NO_APP
	testb	%al, %al
	jne	.LBB5_1
# %bb.6:                                #   in Loop: Header=BB5_1 Depth=1
	cmpq	%r14, %rdi
	je	.LBB5_8
# %bb.7:                                #   in Loop: Header=BB5_1 Depth=1
	callq	free@PLT
.LBB5_8:                                #   in Loop: Header=BB5_1 Depth=1
	testq	%rbx, %rbx
	je	.LBB5_10
# %bb.9:                                #   in Loop: Header=BB5_1 Depth=1
	movq	%rbx, %rdi
	callq	free@PLT
	jmp	.LBB5_1
.LBB5_10:
	#APP
	#NO_APP
	movq	(%r15), %rdi
	#APP
	#NO_APP
	andq	$-128, %rdi
	jne	.LBB5_11
.LBB5_14:
	xorl	%ebx, %ebx
	movq	local_pools@GOTPCREL(%rip), %r14
	jmp	.LBB5_15
	.p2align	4
.LBB5_17:                               #   in Loop: Header=BB5_15 Depth=1
	addq	$1, %rbx
	cmpq	$12, %rbx
	je	.LBB5_18
.LBB5_15:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB5_16 Depth 2
	movq	(%r14,%rbx,8), %rdi
	testq	%rdi, %rdi
	je	.LBB5_17
	.p2align	4
.LBB5_16:                               #   Parent Loop BB5_15 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	#APP
	#NO_APP
	movq	8(%rdi), %r15
	#APP
	#NO_APP
	callq	free@PLT
	andq	$-128, %r15
	movq	%r15, %rdi
	jne	.LBB5_16
	jmp	.LBB5_17
	.p2align	4
.LBB5_13:                               #   in Loop: Header=BB5_11 Depth=1
	andq	$-128, %rbx
	movq	%rbx, %rdi
	je	.LBB5_14
.LBB5_11:                               # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	movq	8(%rdi), %rbx
	#APP
	#NO_APP
	cmpq	%r14, %rdi
	je	.LBB5_13
# %bb.12:                               #   in Loop: Header=BB5_11 Depth=1
	callq	free@PLT
	jmp	.LBB5_13
.LBB5_18:
	xorl	%eax, %eax
	addq	$104, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end5:
	.size	main, .Lfunc_end5-main
	.cfi_endproc
                                        # -- End function
	.type	local_pools,@object             # @local_pools
	.bss
	.globl	local_pools
	.p2align	4, 0x0
local_pools:
	.zero	96
	.size	local_pools, 96

	.type	g_queue,@object                 # @g_queue
	.globl	g_queue
	.p2align	7, 0x0
g_queue:
	.zero	256
	.size	g_queue, 256

	.type	.L.str.2,@object                # @.str.2
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.2:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.2, 16

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.3, 16

	.type	.Lstr,@object                   # @str
.Lstr:
	.asciz	"New allocation"
	.size	.Lstr, 15

	.type	.Lstr.4,@object                 # @str.4
.Lstr.4:
	.asciz	"Recycle allocation"
	.size	.Lstr.4, 19

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
	.addrsig_sym g_queue
