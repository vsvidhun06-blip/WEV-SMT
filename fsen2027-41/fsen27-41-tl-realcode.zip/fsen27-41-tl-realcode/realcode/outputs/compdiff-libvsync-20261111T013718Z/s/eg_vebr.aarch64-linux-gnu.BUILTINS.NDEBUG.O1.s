	.file	"eg_vebr.c"
	.text
	.p2align	2                               // -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               // @lock_acq
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_lock
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               // @lock_rel
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_unlock
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        // -- End function
	.globl	free_cb                         // -- Begin function free_cb
	.p2align	2
	.type	free_cb,@function
free_cb:                                // @free_cb
	.cfi_startproc
// %bb.0:
	sub	x0, x0, #16
	b	free
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	//APP
	//NO_APP
	adrp	x8, :got:g_vebr
	mov	x10, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	dmb	ish
	movk	x10, #43691
	ldr	x8, [x8, :got_lo12:g_vebr]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x9, [x8]
	umulh	x10, x9, x10
	lsr	x10, x10, #1
	add	x10, x10, x10, lsl #1
	sub	x9, x9, x10
	adrp	x10, :got:free_cb
	ldr	x10, [x10, :got_lo12:free_cb]
	add	x8, x8, x9, lsl #4
	//APP
	//NO_APP
	str	xzr, [x0, #16]!
	stp	x10, xzr, [x0, #16]
	add	x8, x8, #8
	//APP
	//NO_APP
	ldar	x9, [x8]
	//APP
	//NO_APP
	b	.LBB3_3
.LBB3_1:                                //   in Loop: Header=BB3_3 Depth=1
	mov	w11, wzr
	clrex
.LBB3_2:                                //   in Loop: Header=BB3_3 Depth=1
	cmp	w11, #0
	//APP
	//NO_APP
	csel	x10, x9, x10, ne
	cmp	x9, x10
	mov	x9, x10
	b.eq	.LBB3_7
.LBB3_3:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB3_4 Depth 2
	str	x9, [x0]
	//APP
	//NO_APP
.LBB3_4:                                //   Parent Loop BB3_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldxr	x10, [x8]
	cmp	x10, x9
	b.ne	.LBB3_1
// %bb.5:                               //   in Loop: Header=BB3_4 Depth=2
	stlxr	w11, x0, [x8]
	cbnz	w11, .LBB3_4
// %bb.6:                               //   in Loop: Header=BB3_3 Depth=1
	mov	w11, #1                         // =0x1
	b	.LBB3_2
.LBB3_7:
	//APP
	//NO_APP
	add	x8, x8, #8
.LBB3_8:                                // =>This Inner Loop Header: Depth=1
	ldxr	x9, [x8]
	add	x9, x9, #1
	stxr	w10, x9, [x8]
	cbnz	w10, .LBB3_8
// %bb.9:
	//APP
	//NO_APP
	ret
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	b	free
.Lfunc_end4:
	.size	destroy_cb, .Lfunc_end4-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	reclaim                         // -- Begin function reclaim
	.p2align	2
	.type	reclaim,@function
reclaim:                                // @reclaim
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-64]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x24, x23, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_remember_state
	adrp	x20, :got:g_stop
	ldr	x20, [x20, :got_lo12:g_stop]
	//APP
	//NO_APP
	ldarb	w8, [x20]
	//APP
	//NO_APP
	cbz	w8, .LBB5_2
.LBB5_1:
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #64             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB5_2:
	.cfi_restore_state
	adrp	x21, :got:g_vebr
	mov	x22, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_vebr]
	movk	x22, #43691
	b	.LBB5_4
.LBB5_3:                                //   in Loop: Header=BB5_4 Depth=1
	//APP
	//NO_APP
	ldarb	w8, [x20]
	//APP
	//NO_APP
	cbnz	w8, .LBB5_1
.LBB5_4:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_5 Depth 2
                                        //     Child Loop BB5_12 Depth 2
                                        //     Child Loop BB5_8 Depth 2
                                        //     Child Loop BB5_16 Depth 2
	//APP
	//NO_APP
	dmb	ish
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x23, [x21]
	//APP
	//NO_APP
	//APP
	//NO_APP
	add	x8, x23, #2
	umulh	x9, x8, x22
	lsr	x9, x9, #1
	add	x9, x9, x9, lsl #1
	sub	x8, x8, x9
	add	x8, x21, x8, lsl #4
	add	x8, x8, #8
.LBB5_5:                                //   Parent Loop BB5_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x24, [x8]
	stxr	w9, xzr, [x8]
	cbnz	w9, .LBB5_5
// %bb.6:                               //   in Loop: Header=BB5_4 Depth=1
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	xzr, [x8, #8]
	//APP
	//NO_APP
	ldr	x8, [x21, #72]
	ldr	x0, [x21, #88]
	blr	x8
	ldr	x8, [x21, #56]
	cbnz	x8, .LBB5_12
.LBB5_7:                                //   in Loop: Header=BB5_4 Depth=1
	ldp	x8, x0, [x21, #80]
	blr	x8
	//APP
	//NO_APP
	add	x8, x23, #1
	mov	x0, x24
.LBB5_8:                                //   Parent Loop BB5_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x9, [x21]
	cmp	x9, x23
	b.ne	.LBB5_14
// %bb.9:                               //   in Loop: Header=BB5_8 Depth=2
	stlxr	w9, x8, [x21]
	cbnz	w9, .LBB5_8
// %bb.10:                              //   in Loop: Header=BB5_4 Depth=1
	//APP
	//NO_APP
	cbnz	x0, .LBB5_15
	b	.LBB5_3
.LBB5_11:                               //   in Loop: Header=BB5_12 Depth=2
	ldr	x8, [x8]
	cbz	x8, .LBB5_7
.LBB5_12:                               //   Parent Loop BB5_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	//APP
	//NO_APP
	add	x9, x8, #16
	ldar	x9, [x9]
	//APP
	//NO_APP
	cbz	x9, .LBB5_11
// %bb.13:                              //   in Loop: Header=BB5_12 Depth=2
	cmp	x9, x23
	b.lo	.LBB5_12
	b	.LBB5_11
.LBB5_14:                               //   in Loop: Header=BB5_4 Depth=1
	clrex
	//APP
	//NO_APP
	cbz	x0, .LBB5_3
.LBB5_15:                               //   in Loop: Header=BB5_4 Depth=1
	mov	x23, xzr
.LBB5_16:                               //   Parent Loop BB5_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldp	x8, x1, [x0, #16]
	ldr	x24, [x0]
	blr	x8
	sub	x23, x23, #1
	mov	x0, x24
	cbnz	x24, .LBB5_16
// %bb.17:                              //   in Loop: Header=BB5_4 Depth=1
	cbz	x23, .LBB5_3
// %bb.18:                              //   in Loop: Header=BB5_4 Depth=1
	neg	x1, x23
	mov	x0, x19
	bl	printf
	b	.LBB5_3
.Lfunc_end5:
	.size	reclaim, .Lfunc_end5-reclaim
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
	cbz	x0, .LBB6_53
// %bb.1:
	mov	x26, sp
	//APP
	//NO_APP
	adrp	x25, :got:g_vebr
	add	x8, x26, #16
	mov	x19, x0
	stlr	xzr, [x8]
	ldr	x25, [x25, :got_lo12:g_vebr]
	//APP
	//NO_APP
	str	wzr, [sp, #24]
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldr	x8, [x25, #56]
	str	x8, [sp]
	cbz	x8, .LBB6_3
// %bb.2:
	str	x26, [x8, #8]
.LBB6_3:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	str	xzr, [sp, #8]
	add	x8, x8, #1
	stp	x26, x8, [x25, #56]
	blr	x9
	adrp	x27, :got:g_queue
	mov	x21, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	mov	x20, xzr
	ldr	x27, [x27, :got_lo12:g_queue]
	ldr	w8, [sp, #24]
	mov	w28, #10000                     // =0x2710
	adrp	x22, .L.str.2
	add	x22, x22, :lo12:.L.str.2
	movk	x21, #43691
	b	.LBB6_5
.LBB6_4:                                //   in Loop: Header=BB6_5 Depth=1
	add	x20, x20, #1
	sub	w8, w8, #1
	cmp	x20, x28
	str	w8, [sp, #24]
	b.eq	.LBB6_49
.LBB6_5:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB6_8 Depth 2
                                        //       Child Loop BB6_15 Depth 3
                                        //       Child Loop BB6_12 Depth 3
                                        //     Child Loop BB6_23 Depth 2
                                        //       Child Loop BB6_24 Depth 3
                                        //     Child Loop BB6_28 Depth 2
                                        //     Child Loop BB6_35 Depth 2
                                        //       Child Loop BB6_37 Depth 3
                                        //       Child Loop BB6_39 Depth 3
                                        //     Child Loop BB6_43 Depth 2
	add	w9, w8, #1
	str	w9, [sp, #24]
	cbnz	w8, .LBB6_8
// %bb.6:                               //   in Loop: Header=BB6_5 Depth=1
	//APP
	//NO_APP
	add	x9, x26, #16
	ldar	x8, [x25]
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	x8, [x9]
	//APP
	//NO_APP
	//APP
	//NO_APP
	dmb	ish
	//APP
	//NO_APP
	b	.LBB6_8
.LBB6_7:                                //   in Loop: Header=BB6_8 Depth=2
	clrex
	//APP
	//NO_APP
.LBB6_8:                                //   Parent Loop BB6_5 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB6_15 Depth 3
                                        //       Child Loop BB6_12 Depth 3
	//APP
	//NO_APP
	add	x9, x27, #8
	ldar	x8, [x27]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x10, [x9]
	//APP
	//NO_APP
	add	x9, x8, #8
	//APP
	//NO_APP
	ldar	x9, [x9]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x11, [x27]
	//APP
	//NO_APP
	cmp	x8, x11
	b.ne	.LBB6_8
// %bb.9:                               //   in Loop: Header=BB6_8 Depth=2
	cmp	x8, x10
	b.ne	.LBB6_14
// %bb.10:                              //   in Loop: Header=BB6_8 Depth=2
	cbz	x9, .LBB6_32
// %bb.11:                              //   in Loop: Header=BB6_8 Depth=2
	//APP
	//NO_APP
.LBB6_12:                               //   Parent Loop BB6_5 Depth=1
                                        //     Parent Loop BB6_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x10, x27, #8
	ldaxr	x11, [x10]
	cmp	x11, x8
	b.ne	.LBB6_17
// %bb.13:                              //   in Loop: Header=BB6_12 Depth=3
	stlxr	w11, x9, [x10]
	cbnz	w11, .LBB6_12
	b	.LBB6_18
.LBB6_14:                               //   in Loop: Header=BB6_8 Depth=2
	ldr	x23, [x9]
	//APP
	//NO_APP
.LBB6_15:                               //   Parent Loop BB6_5 Depth=1
                                        //     Parent Loop BB6_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	ldaxr	x10, [x27]
	cmp	x10, x8
	b.ne	.LBB6_7
// %bb.16:                              //   in Loop: Header=BB6_15 Depth=3
	stlxr	w10, x9, [x27]
	cbnz	w10, .LBB6_15
	b	.LBB6_19
.LBB6_17:                               //   in Loop: Header=BB6_8 Depth=2
	clrex
.LBB6_18:                               //   in Loop: Header=BB6_8 Depth=2
	//APP
	//NO_APP
	b	.LBB6_8
.LBB6_19:                               //   in Loop: Header=BB6_5 Depth=1
	//APP
	//NO_APP
	add	x9, x27, #16
	cmp	x8, x9
	b.eq	.LBB6_30
// %bb.20:                              //   in Loop: Header=BB6_5 Depth=1
	//APP
	//NO_APP
	dmb	ish
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x9, [x25]
	//APP
	//NO_APP
	str	xzr, [x8, #16]!
	umulh	x10, x9, x21
	lsr	x10, x10, #1
	add	x10, x10, x10, lsl #1
	sub	x9, x9, x10
	adrp	x10, :got:free_cb
	ldr	x10, [x10, :got_lo12:free_cb]
	add	x9, x25, x9, lsl #4
	stp	x10, xzr, [x8, #16]
	add	x9, x9, #8
	//APP
	//NO_APP
	ldar	x10, [x9]
	//APP
	//NO_APP
	b	.LBB6_23
.LBB6_21:                               //   in Loop: Header=BB6_23 Depth=2
	mov	w12, wzr
	clrex
.LBB6_22:                               //   in Loop: Header=BB6_23 Depth=2
	cmp	w12, #0
	//APP
	//NO_APP
	csel	x11, x10, x11, ne
	cmp	x10, x11
	mov	x10, x11
	b.eq	.LBB6_27
.LBB6_23:                               //   Parent Loop BB6_5 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB6_24 Depth 3
	str	x10, [x8]
	//APP
	//NO_APP
.LBB6_24:                               //   Parent Loop BB6_5 Depth=1
                                        //     Parent Loop BB6_23 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	ldxr	x11, [x9]
	cmp	x11, x10
	b.ne	.LBB6_21
// %bb.25:                              //   in Loop: Header=BB6_24 Depth=3
	stlxr	w12, x8, [x9]
	cbnz	w12, .LBB6_24
// %bb.26:                              //   in Loop: Header=BB6_23 Depth=2
	mov	w12, #1                         // =0x1
	b	.LBB6_22
.LBB6_27:                               //   in Loop: Header=BB6_5 Depth=1
	//APP
	//NO_APP
	add	x8, x9, #8
.LBB6_28:                               //   Parent Loop BB6_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldxr	x9, [x8]
	add	x9, x9, #1
	stxr	w10, x9, [x8]
	cbnz	w10, .LBB6_28
// %bb.29:                              //   in Loop: Header=BB6_5 Depth=1
	//APP
	//NO_APP
.LBB6_30:                               //   in Loop: Header=BB6_5 Depth=1
	cbz	x23, .LBB6_32
// %bb.31:                              //   in Loop: Header=BB6_5 Depth=1
	ldr	x2, [x23]
	mov	x0, x22
	mov	x1, x19
	bl	printf
	mov	x0, x23
	bl	free
	b	.LBB6_47
.LBB6_32:                               //   in Loop: Header=BB6_5 Depth=1
	mov	w0, #8                          // =0x8
	bl	malloc
	mov	x24, x0
	str	x20, [x0]
	mov	w0, #48                         // =0x30
	bl	malloc
	mov	x23, x0
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	mov	x1, x19
	mov	x2, x20
	bl	printf
	mov	x8, x23
	str	x24, [x8], #8
	//APP
	//NO_APP
	str	xzr, [x8]
	//APP
	//NO_APP
	b	.LBB6_35
.LBB6_33:                               //   in Loop: Header=BB6_35 Depth=2
	clrex
.LBB6_34:                               //   in Loop: Header=BB6_35 Depth=2
	//APP
	//NO_APP
.LBB6_35:                               //   Parent Loop BB6_5 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB6_37 Depth 3
                                        //       Child Loop BB6_39 Depth 3
	//APP
	//NO_APP
	add	x11, x27, #8
	ldar	x8, [x11]
	//APP
	//NO_APP
	//APP
	//NO_APP
	add	x9, x8, #8
	ldar	x10, [x9]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x11, [x11]
	//APP
	//NO_APP
	cmp	x8, x11
	b.ne	.LBB6_35
// %bb.36:                              //   in Loop: Header=BB6_35 Depth=2
	//APP
	//NO_APP
	cbz	x10, .LBB6_39
.LBB6_37:                               //   Parent Loop BB6_5 Depth=1
                                        //     Parent Loop BB6_35 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x9, x27, #8
	ldaxr	x11, [x9]
	cmp	x11, x8
	b.ne	.LBB6_33
// %bb.38:                              //   in Loop: Header=BB6_37 Depth=3
	stlxr	w11, x10, [x9]
	cbnz	w11, .LBB6_37
	b	.LBB6_34
.LBB6_39:                               //   Parent Loop BB6_5 Depth=1
                                        //     Parent Loop BB6_35 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	ldaxr	x10, [x9]
	cbnz	x10, .LBB6_41
// %bb.40:                              //   in Loop: Header=BB6_39 Depth=3
	stlxr	w10, x23, [x9]
	cbnz	w10, .LBB6_39
	b	.LBB6_42
.LBB6_41:                               //   in Loop: Header=BB6_35 Depth=2
	clrex
	//APP
	//NO_APP
	b	.LBB6_35
.LBB6_42:                               //   in Loop: Header=BB6_5 Depth=1
	//APP
	//NO_APP
	//APP
	//NO_APP
.LBB6_43:                               //   Parent Loop BB6_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x27, #8
	ldaxr	x10, [x9]
	cmp	x10, x8
	b.ne	.LBB6_45
// %bb.44:                              //   in Loop: Header=BB6_43 Depth=2
	stlxr	w10, x23, [x9]
	cbnz	w10, .LBB6_43
	b	.LBB6_46
.LBB6_45:                               //   in Loop: Header=BB6_5 Depth=1
	clrex
.LBB6_46:                               //   in Loop: Header=BB6_5 Depth=1
	//APP
	//NO_APP
.LBB6_47:                               //   in Loop: Header=BB6_5 Depth=1
	ldr	w8, [sp, #24]
	cmp	w8, #1
	b.ne	.LBB6_4
// %bb.48:                              //   in Loop: Header=BB6_5 Depth=1
	add	x8, x26, #16
	//APP
	//NO_APP
	stlr	xzr, [x8]
	//APP
	//NO_APP
	ldr	w8, [sp, #24]
	b	.LBB6_4
.LBB6_49:
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldp	x9, x8, [sp]
	cbz	x8, .LBB6_55
// %bb.50:
	str	x9, [x8]
	cbz	x9, .LBB6_52
.LBB6_51:
	str	x8, [x9, #8]
.LBB6_52:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	sub	x8, x8, #1
	str	x8, [x25, #64]
	blr	x9
	b	.LBB6_54
.LBB6_53:
	bl	reclaim
.LBB6_54:
	mov	x0, xzr
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_55:
	.cfi_restore_state
	str	x9, [x25, #56]
	cbnz	x9, .LBB6_51
	b	.LBB6_52
.Lfunc_end6:
	.size	run, .Lfunc_end6-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	str	x23, [sp, #112]                 // 8-byte Folded Spill
	stp	x22, x21, [sp, #128]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	adrp	x0, :got:g_lock
	mov	x1, xzr
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_init
	adrp	x8, :got:g_lock_lib
	adrp	x20, :got:g_vebr
	mov	w22, #1                         // =0x1
	ldr	x8, [x8, :got_lo12:g_lock_lib]
	ldr	x20, [x20, :got_lo12:g_vebr]
	adrp	x21, :got:g_queue
	adrp	x19, :got:run
	mov	x0, sp
	mov	x1, xzr
	ldr	q0, [x8]
	ldr	x8, [x8, #16]
	stp	xzr, xzr, [x20, #56]
	add	x9, x20, #8
	mov	x3, xzr
	mov	x23, sp
	str	q0, [sp]
	str	x8, [sp, #16]
	add	x8, x20, #16
	//APP
	//NO_APP
	stlr	xzr, [x9]
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	xzr, [x8]
	add	x8, x20, #24
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	xzr, [x8]
	add	x8, x20, #32
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	xzr, [x8]
	add	x8, x20, #40
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	xzr, [x8]
	add	x8, x20, #48
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	xzr, [x8]
	//APP
	//NO_APP
	//APP
	//NO_APP
	stlr	x22, [x20]
	//APP
	//NO_APP
	ldr	x8, [sp, #16]
	ldr	x21, [x21, :got_lo12:g_queue]
	ldr	q0, [sp]
	str	x8, [x20, #88]
	mov	x8, x21
	stur	q0, [x20, #72]
	str	xzr, [x8, #16]!
	//APP
	//NO_APP
	str	xzr, [x21, #24]
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	x8, [x21]
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	x8, [x21, #8]
	//APP
	//NO_APP
	ldr	x19, [x19, :got_lo12:run]
	mov	x2, x19
	bl	pthread_create
	add	x0, x23, #8
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #1                          // =0x1
	bl	pthread_create
	add	x0, x23, #16
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #2                          // =0x2
	bl	pthread_create
	add	x0, x23, #24
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #3                          // =0x3
	bl	pthread_create
	add	x0, x23, #32
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #4                          // =0x4
	bl	pthread_create
	add	x0, x23, #40
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #5                          // =0x5
	bl	pthread_create
	add	x0, x23, #48
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #6                          // =0x6
	bl	pthread_create
	add	x0, x23, #56
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #7                          // =0x7
	bl	pthread_create
	add	x0, x23, #64
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #8                          // =0x8
	bl	pthread_create
	add	x0, x23, #72
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #9                          // =0x9
	bl	pthread_create
	add	x0, x23, #80
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #10                         // =0xa
	bl	pthread_create
	add	x0, x23, #88
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #11                         // =0xb
	bl	pthread_create
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #16]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #24]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #32]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #40]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #48]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #56]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #64]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #72]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #80]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #88]
	mov	x1, xzr
	bl	pthread_join
	adrp	x8, :got:g_stop
	mov	x1, xzr
	ldr	x8, [x8, :got_lo12:g_stop]
	//APP
	//NO_APP
	stlrb	w22, [x8]
	//APP
	//NO_APP
	ldr	x0, [sp]
	bl	pthread_join
	b	.LBB7_2
.LBB7_1:                                //   in Loop: Header=BB7_2 Depth=1
	clrex
	//APP
	//NO_APP
.LBB7_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_9 Depth 2
                                        //     Child Loop BB7_6 Depth 2
	//APP
	//NO_APP
	add	x8, x21, #8
	ldar	x0, [x21]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x9, [x8]
	//APP
	//NO_APP
	add	x8, x0, #8
	//APP
	//NO_APP
	ldar	x8, [x8]
	//APP
	//NO_APP
	//APP
	//NO_APP
	ldar	x10, [x21]
	//APP
	//NO_APP
	cmp	x0, x10
	b.ne	.LBB7_2
// %bb.3:                               //   in Loop: Header=BB7_2 Depth=1
	cmp	x0, x9
	b.ne	.LBB7_8
// %bb.4:                               //   in Loop: Header=BB7_2 Depth=1
	cbz	x8, .LBB7_17
// %bb.5:                               //   in Loop: Header=BB7_2 Depth=1
	//APP
	//NO_APP
.LBB7_6:                                //   Parent Loop BB7_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x21, #8
	ldaxr	x10, [x9]
	cmp	x10, x0
	b.ne	.LBB7_15
// %bb.7:                               //   in Loop: Header=BB7_6 Depth=2
	stlxr	w10, x8, [x9]
	cbnz	w10, .LBB7_6
	b	.LBB7_16
.LBB7_8:                                //   in Loop: Header=BB7_2 Depth=1
	ldr	x19, [x8]
	//APP
	//NO_APP
.LBB7_9:                                //   Parent Loop BB7_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x9, [x21]
	cmp	x9, x0
	b.ne	.LBB7_1
// %bb.10:                              //   in Loop: Header=BB7_9 Depth=2
	stlxr	w9, x8, [x21]
	cbnz	w9, .LBB7_9
// %bb.11:                              //   in Loop: Header=BB7_2 Depth=1
	//APP
	//NO_APP
	add	x8, x21, #16
	cmp	x0, x8
	b.eq	.LBB7_13
// %bb.12:                              //   in Loop: Header=BB7_2 Depth=1
	bl	free
.LBB7_13:                               //   in Loop: Header=BB7_2 Depth=1
	cbz	x19, .LBB7_17
// %bb.14:                              //   in Loop: Header=BB7_2 Depth=1
	mov	x0, x19
	bl	free
	b	.LBB7_2
.LBB7_15:                               //   in Loop: Header=BB7_2 Depth=1
	clrex
.LBB7_16:                               //   in Loop: Header=BB7_2 Depth=1
	//APP
	//NO_APP
	b	.LBB7_2
.LBB7_17:
	//APP
	//NO_APP
	ldar	x0, [x21]
	//APP
	//NO_APP
	cbz	x0, .LBB7_22
// %bb.18:
	add	x19, x21, #16
	b	.LBB7_20
.LBB7_19:                               //   in Loop: Header=BB7_20 Depth=1
	mov	x0, x21
	cbz	x21, .LBB7_22
.LBB7_20:                               // =>This Inner Loop Header: Depth=1
	add	x8, x0, #8
	//APP
	//NO_APP
	cmp	x0, x19
	ldar	x21, [x8]
	//APP
	//NO_APP
	b.eq	.LBB7_19
// %bb.21:                              //   in Loop: Header=BB7_20 Depth=1
	bl	free
	b	.LBB7_19
.LBB7_22:
	//APP
	//NO_APP
	add	x8, x20, #8
.LBB7_23:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x0, [x8]
	stxr	w9, xzr, [x8]
	cbnz	w9, .LBB7_23
// %bb.24:
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	xzr, [x20, #16]
	//APP
	//NO_APP
	cbz	x0, .LBB7_26
.LBB7_25:                               // =>This Inner Loop Header: Depth=1
	ldp	x8, x1, [x0, #16]
	ldr	x19, [x0]
	blr	x8
	mov	x0, x19
	cbnz	x19, .LBB7_25
.LBB7_26:
	//APP
	//NO_APP
	add	x8, x20, #24
.LBB7_27:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x0, [x8]
	stxr	w9, xzr, [x8]
	cbnz	w9, .LBB7_27
// %bb.28:
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	xzr, [x20, #32]
	//APP
	//NO_APP
	cbz	x0, .LBB7_30
.LBB7_29:                               // =>This Inner Loop Header: Depth=1
	ldp	x8, x1, [x0, #16]
	ldr	x19, [x0]
	blr	x8
	mov	x0, x19
	cbnz	x19, .LBB7_29
.LBB7_30:
	//APP
	//NO_APP
	add	x8, x20, #40
.LBB7_31:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x0, [x8]
	stxr	w9, xzr, [x8]
	cbnz	w9, .LBB7_31
// %bb.32:
	//APP
	//NO_APP
	//APP
	//NO_APP
	str	xzr, [x20, #48]
	//APP
	//NO_APP
	cbz	x0, .LBB7_34
.LBB7_33:                               // =>This Inner Loop Header: Depth=1
	ldp	x8, x1, [x0, #16]
	ldr	x19, [x0]
	blr	x8
	mov	x0, x19
	cbnz	x19, .LBB7_33
.LBB7_34:
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_destroy
	mov	w0, wzr
	.cfi_def_cfa wsp, 160
	ldp	x20, x19, [sp, #144]            // 16-byte Folded Reload
	ldr	x23, [sp, #112]                 // 8-byte Folded Reload
	ldp	x22, x21, [sp, #128]            // 16-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end7:
	.size	main, .Lfunc_end7-main
	.cfi_endproc
                                        // -- End function
	.type	g_lock,@object                  // @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	48
	.size	g_lock, 48

	.type	g_lock_lib,@object              // @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.xword	lock_acq
	.xword	lock_rel
	.xword	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  // @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  // @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 // @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                // @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym run
	.addrsig_sym g_lock
	.addrsig_sym g_vebr
	.addrsig_sym g_queue
