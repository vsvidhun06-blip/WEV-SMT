	.file	"eg_vebr.c"
	.text
	.type	lock_acq,@function              # -- Begin function lock_acq
lock_acq:                               # @lock_acq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	pthread_mutex_lock@PLT          # TAILCALL
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        # -- End function
	.type	lock_rel,@function              # -- Begin function lock_rel
lock_rel:                               # @lock_rel
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	pthread_mutex_unlock@PLT        # TAILCALL
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        # -- End function
	.globl	free_cb                         # -- Begin function free_cb
	.type	free_cb,@function
free_cb:                                # @free_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	addq	$-16, %rdi
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	free@PLT                        # TAILCALL
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        # -- End function
	.globl	retire_cb                       # -- Begin function retire_cb
	.type	retire_cb,@function
retire_cb:                              # @retire_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	#APP
	#NO_APP
	mfence
	leaq	16(%rdi), %rsi
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	g_vebr@GOTPCREL(%rip), %r8
	movq	(%r8), %rcx
	#APP
	#NO_APP
	movabsq	$-6148914691236517205, %rdx     # imm = 0xAAAAAAAAAAAAAAAB
	movq	%rcx, %rax
	mulq	%rdx
	shrl	%edx
	leal	(%rdx,%rdx,2), %eax
	subl	%eax, %ecx
	shll	$4, %ecx
	leaq	(%r8,%rcx), %rdx
	addq	$8, %rdx
	movq	free_cb@GOTPCREL(%rip), %rax
	movq	%rax, 32(%rdi)
	xorl	%eax, %eax
	movq	%rax, 40(%rdi)
	movq	%rax, 16(%rdi)
	#APP
	#NO_APP
	movq	(%rdx), %rcx
	#APP
	#NO_APP
.LBB3_1:                                # =>This Inner Loop Header: Depth=1
	movq	%rcx, (%rsi)
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%rsi, (%rdx)
	cmoveq	%rcx, %rax
	#APP
	#NO_APP
	cmpq	%rax, %rcx
	movq	%rax, %rcx
	jne	.LBB3_1
# %bb.2:
	#APP
	#NO_APP
	lock		incq	8(%rdx)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        # -- End function
	.globl	destroy_cb                      # -- Begin function destroy_cb
	.type	destroy_cb,@function
destroy_cb:                             # @destroy_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	free@PLT                        # TAILCALL
.Lfunc_end4:
	.size	destroy_cb, .Lfunc_end4-destroy_cb
	.cfi_endproc
                                        # -- End function
	.globl	reclaim                         # -- Begin function reclaim
	.type	reclaim,@function
reclaim:                                # @reclaim
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	#APP
	#NO_APP
	movq	g_stop@GOTPCREL(%rip), %r12
	movb	(%r12), %al
	#APP
	#NO_APP
	testb	%al, %al
	jne	.LBB5_13
# %bb.1:
	movq	g_vebr@GOTPCREL(%rip), %r13
.LBB5_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB5_3 Depth 2
                                        #       Child Loop BB5_4 Depth 3
                                        #     Child Loop BB5_9 Depth 2
	#APP
	#NO_APP
	mfence
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r13), %r15
	leaq	2(%r15), %rcx
	movq	%rcx, %rax
	movabsq	$-6148914691236517205, %rdx     # imm = 0xAAAAAAAAAAAAAAAB
	mulq	%rdx
	#APP
	#NO_APP
	shrl	%edx
	leal	(%rdx,%rdx,2), %eax
	subl	%eax, %ecx
	shll	$4, %ecx
	#APP
	#NO_APP
	xorl	%ebx, %ebx
	xchgq	%rbx, 8(%r13,%rcx)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	$0, 16(%r13,%rcx)
	#APP
	#NO_APP
	movq	88(%r13), %rdi
	callq	*72(%r13)
	movq	56(%r13), %rax
.LBB5_3:                                #   Parent Loop BB5_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB5_4 Depth 3
	testq	%rax, %rax
	je	.LBB5_7
.LBB5_4:                                #   Parent Loop BB5_2 Depth=1
                                        #     Parent Loop BB5_3 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	#APP
	#NO_APP
	movq	16(%rax), %rcx
	#APP
	#NO_APP
	testq	%rcx, %rcx
	je	.LBB5_6
# %bb.5:                                #   in Loop: Header=BB5_4 Depth=3
	cmpq	%r15, %rcx
	jb	.LBB5_4
.LBB5_6:                                #   in Loop: Header=BB5_3 Depth=2
	movq	(%rax), %rax
	jmp	.LBB5_3
.LBB5_7:                                #   in Loop: Header=BB5_2 Depth=1
	movq	88(%r13), %rdi
	callq	*80(%r13)
	leaq	1(%r15), %rcx
	#APP
	#NO_APP
	movq	%r15, %rax
	lock		cmpxchgq	%rcx, (%r13)
	#APP
	#NO_APP
	testq	%rbx, %rbx
	je	.LBB5_12
# %bb.8:                                #   in Loop: Header=BB5_2 Depth=1
	xorl	%r15d, %r15d
.LBB5_9:                                #   Parent Loop BB5_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rbx), %r14
	movq	24(%rbx), %rsi
	movq	%rbx, %rdi
	callq	*16(%rbx)
	decq	%r15
	movq	%r14, %rbx
	testq	%r14, %r14
	jne	.LBB5_9
# %bb.10:                               #   in Loop: Header=BB5_2 Depth=1
	testq	%r15, %r15
	je	.LBB5_12
# %bb.11:                               #   in Loop: Header=BB5_2 Depth=1
	negq	%r15
	leaq	.L.str(%rip), %rdi
	movq	%r15, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
.LBB5_12:                               #   in Loop: Header=BB5_2 Depth=1
	#APP
	#NO_APP
	movb	(%r12), %al
	#APP
	#NO_APP
	testb	%al, %al
	je	.LBB5_2
.LBB5_13:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end5:
	.size	reclaim, .Lfunc_end5-reclaim
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB6_1
# %bb.2:
	movq	%rdi, %rbx
	#APP
	#NO_APP
	xorl	%eax, %eax
	xchgq	%rax, -56(%rbp)
	#APP
	#NO_APP
	movl	$0, -48(%rbp)
	movq	g_vebr@GOTPCREL(%rip), %r15
	movq	88(%r15), %rdi
	callq	*72(%r15)
	movq	56(%r15), %rax
	movq	%rax, -72(%rbp)
	testq	%rax, %rax
	je	.LBB6_4
# %bb.3:
	leaq	-72(%rbp), %rcx
	movq	%rcx, 8(%rax)
.LBB6_4:
	leaq	-72(%rbp), %r14
	movq	%r14, 56(%r15)
	movq	$0, 8(%r14)
	incq	64(%r15)
	movq	88(%r15), %rdi
	callq	*80(%r15)
	movl	24(%r14), %eax
	movq	g_queue@GOTPCREL(%rip), %r14
	leaq	16(%r14), %rcx
	movq	%rcx, -80(%rbp)                 # 8-byte Spill
	xorl	%r12d, %r12d
.LBB6_5:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB6_7 Depth 2
                                        #     Child Loop BB6_23 Depth 2
	leal	1(%rax), %ecx
	movl	%ecx, -48(%rbp)
	testl	%eax, %eax
	jne	.LBB6_7
# %bb.6:                                #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	movq	g_vebr@GOTPCREL(%rip), %rax
	movq	(%rax), %rax
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	%rax, -56(%rbp)
	#APP
	#NO_APP
	#APP
	#NO_APP
	mfence
	#APP
	#NO_APP
.LBB6_7:                                #   Parent Loop BB6_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	#APP
	#NO_APP
	movq	(%r14), %rdi
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%r14), %rax
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rdi), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r14), %rdx
	#APP
	#NO_APP
	cmpq	%rdx, %rdi
	jne	.LBB6_7
# %bb.8:                                #   in Loop: Header=BB6_7 Depth=2
	cmpq	%rax, %rdi
	jne	.LBB6_18
# %bb.9:                                #   in Loop: Header=BB6_7 Depth=2
	testq	%rcx, %rcx
	je	.LBB6_22
# %bb.10:                               #   in Loop: Header=BB6_7 Depth=2
	#APP
	#NO_APP
	movq	%rdi, %rax
	lock		cmpxchgq	%rcx, 8(%r14)
	#APP
	#NO_APP
	jmp	.LBB6_7
.LBB6_18:                               #   in Loop: Header=BB6_7 Depth=2
	movq	(%rcx), %r13
	#APP
	#NO_APP
	movq	%rdi, %rax
	lock		cmpxchgq	%rcx, (%r14)
	setne	%al
	#APP
	#NO_APP
	testb	%al, %al
	jne	.LBB6_7
# %bb.19:                               #   in Loop: Header=BB6_5 Depth=1
	cmpq	-80(%rbp), %rdi                 # 8-byte Folded Reload
	je	.LBB6_21
# %bb.20:                               #   in Loop: Header=BB6_5 Depth=1
	callq	retire_cb@PLT
.LBB6_21:                               #   in Loop: Header=BB6_5 Depth=1
	testq	%r13, %r13
	je	.LBB6_22
# %bb.27:                               #   in Loop: Header=BB6_5 Depth=1
	movq	(%r13), %rdx
	leaq	.L.str.2(%rip), %rdi
	movq	%rbx, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	movq	%r13, %rdi
	callq	free@PLT
	jmp	.LBB6_28
.LBB6_22:                               #   in Loop: Header=BB6_5 Depth=1
	movl	$8, %edi
	callq	malloc@PLT
	movq	%rax, %r15
	movq	%r12, (%rax)
	movl	$48, %edi
	callq	malloc@PLT
	movq	%rax, %r13
	leaq	.L.str.1(%rip), %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	xorl	%eax, %eax
	callq	printf@PLT
	movq	%r15, (%r13)
	#APP
	#NO_APP
	movq	$0, 8(%r13)
	#APP
	#NO_APP
.LBB6_23:                               #   Parent Loop BB6_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	#APP
	#NO_APP
	movq	8(%r14), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rcx), %rdx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%r14), %rax
	#APP
	#NO_APP
	cmpq	%rax, %rcx
	jne	.LBB6_23
# %bb.24:                               #   in Loop: Header=BB6_23 Depth=2
	#APP
	#NO_APP
	testq	%rdx, %rdx
	je	.LBB6_25
# %bb.31:                               #   in Loop: Header=BB6_23 Depth=2
	movq	%rcx, %rax
	lock		cmpxchgq	%rdx, 8(%r14)
	#APP
	#NO_APP
	jmp	.LBB6_23
.LBB6_25:                               #   in Loop: Header=BB6_23 Depth=2
	xorl	%eax, %eax
	lock		cmpxchgq	%r13, 8(%rcx)
	sete	%al
	#APP
	#NO_APP
	testb	%al, %al
	je	.LBB6_23
# %bb.26:                               #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	movq	%rcx, %rax
	lock		cmpxchgq	%r13, 8(%r14)
	#APP
	#NO_APP
.LBB6_28:                               #   in Loop: Header=BB6_5 Depth=1
	movl	-48(%rbp), %eax
	cmpl	$1, %eax
	jne	.LBB6_30
# %bb.29:                               #   in Loop: Header=BB6_5 Depth=1
	#APP
	#NO_APP
	movq	$0, -56(%rbp)
	#APP
	#NO_APP
	movl	-48(%rbp), %eax
.LBB6_30:                               #   in Loop: Header=BB6_5 Depth=1
	decl	%eax
	movl	%eax, -48(%rbp)
	incq	%r12
	cmpq	$10000, %r12                    # imm = 0x2710
	jne	.LBB6_5
# %bb.11:
	movq	g_vebr@GOTPCREL(%rip), %rbx
	movq	88(%rbx), %rdi
	callq	*72(%rbx)
	movq	-72(%rbp), %rax
	movq	-64(%rbp), %rcx
	testq	%rcx, %rcx
	je	.LBB6_13
# %bb.12:
	movq	%rax, (%rcx)
	jmp	.LBB6_14
.LBB6_1:
	callq	reclaim@PLT
	jmp	.LBB6_17
.LBB6_13:
	movq	%rax, 56(%rbx)
.LBB6_14:
	testq	%rax, %rax
	je	.LBB6_16
# %bb.15:
	movq	%rcx, 8(%rax)
.LBB6_16:
	decq	64(%rbx)
	movq	88(%rbx), %rdi
	callq	*80(%rbx)
.LBB6_17:
	xorl	%eax, %eax
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end6:
	.size	run, .Lfunc_end6-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	g_lock@GOTPCREL(%rip), %rdi
	xorl	%esi, %esi
	callq	pthread_mutex_init@PLT
	movq	g_lock_lib@GOTPCREL(%rip), %rax
	movq	16(%rax), %rcx
	movq	%rcx, -128(%rbp)
	movups	(%rax), %xmm0
	movaps	%xmm0, -144(%rbp)
	xorps	%xmm0, %xmm0
	movq	g_vebr@GOTPCREL(%rip), %r12
	movups	%xmm0, 56(%r12)
	movl	$16, %eax
.LBB7_1:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	xorl	%ecx, %ecx
	xchgq	%rcx, -8(%r12,%rax)
	#APP
	#NO_APP
	#APP
	#NO_APP
	xorl	%ecx, %ecx
	xchgq	%rcx, (%r12,%rax)
	#APP
	#NO_APP
	addq	$16, %rax
	cmpq	$64, %rax
	jne	.LBB7_1
# %bb.2:
	#APP
	#NO_APP
	movl	$1, %eax
	xchgq	%rax, (%r12)
	#APP
	#NO_APP
	leaq	-144(%rbp), %rbx
	movq	16(%rbx), %rax
	movq	%rax, 88(%r12)
	movaps	(%rbx), %xmm0
	movups	%xmm0, 72(%r12)
	movq	g_queue@GOTPCREL(%rip), %r13
	movq	$0, 16(%r13)
	leaq	16(%r13), %rax
	#APP
	#NO_APP
	movq	$0, 24(%r13)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	%rax, (%r13)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	movq	%rax, 8(%r13)
	#APP
	#NO_APP
	xorl	%r14d, %r14d
	movq	run@GOTPCREL(%rip), %r15
.LBB7_3:                                # =>This Inner Loop Header: Depth=1
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	movq	%r14, %rcx
	callq	pthread_create@PLT
	incq	%r14
	addq	$8, %rbx
	cmpq	$12, %r14
	jne	.LBB7_3
# %bb.4:
	movl	$1, %ebx
.LBB7_5:                                # =>This Inner Loop Header: Depth=1
	movq	-144(%rbp,%rbx,8), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	incq	%rbx
	cmpq	$12, %rbx
	jne	.LBB7_5
# %bb.6:
	#APP
	#NO_APP
	movq	g_stop@GOTPCREL(%rip), %rax
	movb	$1, %cl
	xchgb	%cl, (%rax)
	#APP
	#NO_APP
	movq	-144(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-48(%rbp), %r14                 # 8-byte Reload
.LBB7_7:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	movq	(%r13), %rdi
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%r13), %rax
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	8(%rdi), %rcx
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	(%r13), %rdx
	#APP
	#NO_APP
	cmpq	%rdx, %rdi
	jne	.LBB7_7
# %bb.8:                                #   in Loop: Header=BB7_7 Depth=1
	cmpq	%rax, %rdi
	jne	.LBB7_11
# %bb.9:                                #   in Loop: Header=BB7_7 Depth=1
	testq	%rcx, %rcx
	je	.LBB7_16
# %bb.10:                               #   in Loop: Header=BB7_7 Depth=1
	#APP
	#NO_APP
	movq	%rdi, %rax
	lock		cmpxchgq	%rcx, 8(%r13)
	#APP
	#NO_APP
	jmp	.LBB7_7
.LBB7_11:                               #   in Loop: Header=BB7_7 Depth=1
	movq	(%rcx), %rbx
	#APP
	#NO_APP
	movq	%rdi, %rax
	lock		cmpxchgq	%rcx, (%r13)
	setne	%al
	#APP
	#NO_APP
	testb	%al, %al
	jne	.LBB7_7
# %bb.12:                               #   in Loop: Header=BB7_7 Depth=1
	cmpq	%r14, %rdi
	je	.LBB7_14
# %bb.13:                               #   in Loop: Header=BB7_7 Depth=1
	callq	free@PLT
.LBB7_14:                               #   in Loop: Header=BB7_7 Depth=1
	testq	%rbx, %rbx
	je	.LBB7_16
# %bb.15:                               #   in Loop: Header=BB7_7 Depth=1
	movq	%rbx, %rdi
	callq	free@PLT
	jmp	.LBB7_7
.LBB7_16:
	#APP
	#NO_APP
	movq	(%r13), %rdi
	#APP
	#NO_APP
	testq	%rdi, %rdi
	je	.LBB7_20
.LBB7_17:                               # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	movq	8(%rdi), %rbx
	#APP
	#NO_APP
	cmpq	%r14, %rdi
	je	.LBB7_19
# %bb.18:                               #   in Loop: Header=BB7_17 Depth=1
	callq	free@PLT
.LBB7_19:                               #   in Loop: Header=BB7_17 Depth=1
	movq	%rbx, %rdi
	testq	%rbx, %rbx
	jne	.LBB7_17
.LBB7_20:
	xorl	%ebx, %ebx
.LBB7_21:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB7_22 Depth 2
	movq	%rbx, %rax
	shlq	$4, %rax
	#APP
	#NO_APP
	xorl	%edi, %edi
	xchgq	%rdi, 8(%r12,%rax)
	#APP
	#NO_APP
	#APP
	#NO_APP
	movq	$0, 16(%r12,%rax)
	#APP
	#NO_APP
	testq	%rdi, %rdi
	je	.LBB7_23
.LBB7_22:                               #   Parent Loop BB7_21 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rdi), %r14
	movq	24(%rdi), %rsi
	callq	*16(%rdi)
	movq	%r14, %rdi
	testq	%r14, %r14
	jne	.LBB7_22
.LBB7_23:                               #   in Loop: Header=BB7_21 Depth=1
	incq	%rbx
	cmpq	$3, %rbx
	jne	.LBB7_21
# %bb.24:
	movq	g_lock@GOTPCREL(%rip), %rdi
	callq	pthread_mutex_destroy@PLT
	xorl	%eax, %eax
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end7:
	.size	main, .Lfunc_end7-main
	.cfi_endproc
                                        # -- End function
	.type	g_lock,@object                  # @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	40
	.size	g_lock, 40

	.type	g_lock_lib,@object              # @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.quad	lock_acq
	.quad	lock_rel
	.quad	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  # @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  # @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 # @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym run
	.addrsig_sym g_lock
	.addrsig_sym g_vebr
	.addrsig_sym g_queue
