	.file	"eg_bitmap.c"
	.text
	.globl	reader                          // -- Begin function reader
	.p2align	2
	.type	reader,@function
reader:                                 // @reader
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	xzr, [x29, #-16]
	str	xzr, [sp, #24]
	str	xzr, [sp, #32]
	str	xzr, [sp, #40]
	str	xzr, [sp, #16]
	mov	x8, #693                        // =0x2b5
	str	x8, [sp, #8]
	b	.LBB0_1
.LBB0_1:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_3 Depth 2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.hs	.LBB0_6
	b	.LBB0_2
.LBB0_2:                                //   in Loop: Header=BB0_1 Depth=1
	str	xzr, [sp, #16]
	adrp	x8, :got:g_bitmap
	ldr	x8, [x8, :got_lo12:g_bitmap]
	ldr	x0, [x8]
	add	x1, sp, #24
	bl	vbitmap_iter_init
	b	.LBB0_3
.LBB0_3:                                //   Parent Loop BB0_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x0, sp, #24
	sub	x1, x29, #16
	bl	vbitmap_iter_next
	tbz	w0, #0, .LBB0_5
	b	.LBB0_4
.LBB0_4:                                //   in Loop: Header=BB0_3 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB0_3
.LBB0_5:                                //   in Loop: Header=BB0_1 Depth=1
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	adrp	x0, .L.str
	add	x0, x0, :lo12:.L.str
	bl	printf
	b	.LBB0_1
.LBB0_6:
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB0_8
	b	.LBB0_7
.LBB0_7:
	bl	__stack_chk_fail
.LBB0_8:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_iter_init
	.type	vbitmap_iter_init,@function
vbitmap_iter_init:                      // @vbitmap_iter_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB1_2
	b	.LBB1_1
.LBB1_1:
	b	.LBB1_3
.LBB1_2:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #314                        // =0x13a
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_iter_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_iter_init
	bl	__assert_fail
.LBB1_3:
	ldr	x8, [sp]
	cbz	x8, .LBB1_5
	b	.LBB1_4
.LBB1_4:
	b	.LBB1_6
.LBB1_5:
	adrp	x0, .L.str.6
	add	x0, x0, :lo12:.L.str.6
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #315                        // =0x13b
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_iter_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_iter_init
	bl	__assert_fail
.LBB1_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	subs	x8, x8, #0
	b.ls	.LBB1_8
	b	.LBB1_7
.LBB1_7:
	b	.LBB1_9
.LBB1_8:
	adrp	x0, .L.str.7
	add	x0, x0, :lo12:.L.str.7
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #316                        // =0x13c
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_iter_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_iter_init
	bl	__assert_fail
.LBB1_9:
	ldr	x8, [sp, #8]
	ldr	x9, [sp]
	str	x8, [x9]
	ldr	x8, [sp]
	str	xzr, [x8, #8]
	ldr	x8, [sp, #8]
	add	x0, x8, #16
	bl	vatomic64_read
	ldr	x8, [sp]
	str	x0, [x8, #16]
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end1:
	.size	vbitmap_iter_init, .Lfunc_end1-vbitmap_iter_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_iter_next
	.type	vbitmap_iter_next,@function
vbitmap_iter_next:                      // @vbitmap_iter_next
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #16
	str	x8, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	str	xzr, [sp]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	cbnz	x8, .LBB2_8
	b	.LBB2_1
.LBB2_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB2_2
.LBB2_2:                                // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	.LBB2_7
	b	.LBB2_3
.LBB2_3:                                //   in Loop: Header=BB2_2 Depth=1
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #8]
	add	x0, x8, x9, lsl #3
	bl	vatomic64_read
	ldur	x8, [x29, #-16]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	cbz	x8, .LBB2_5
	b	.LBB2_4
.LBB2_4:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #8]
	b	.LBB2_9
.LBB2_5:                                //   in Loop: Header=BB2_2 Depth=1
	b	.LBB2_6
.LBB2_6:                                //   in Loop: Header=BB2_2 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB2_2
.LBB2_7:
	mov	w8, wzr
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	.LBB2_12
.LBB2_8:
	b	.LBB2_9
.LBB2_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	rbit	x8, x8
	clz	x8, x8
	str	x8, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x9, [x8, #8]
	mov	x8, #64                         // =0x40
	mul	x8, x8, x9
	ldr	x9, [sp, #16]
	add	x8, x8, x9
	str	x8, [sp]
	ldr	x8, [sp]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.lo	.LBB2_11
	b	.LBB2_10
.LBB2_10:
	mov	w8, wzr
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	.LBB2_12
.LBB2_11:
	ldr	x8, [sp]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	mov	x10, #64                        // =0x40
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x9, x8, x9
	mov	x8, #1                          // =0x1
	lsl	x10, x8, x9
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	bic	x8, x8, x10
	str	x8, [x9, #16]
	mov	w8, #1                          // =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	.LBB2_12
.LBB2_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	vbitmap_iter_next, .Lfunc_end2-vbitmap_iter_next
	.cfi_endproc
                                        // -- End function
	.globl	writer                          // -- Begin function writer
	.p2align	2
	.type	writer,@function
writer:                                 // @writer
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	sturb	wzr, [x29, #-9]
	ldur	x8, [x29, #-8]
	lsl	x8, x8, #6
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-24]
	add	x8, x8, #64
	subs	x8, x8, #1
	str	x8, [sp, #32]
	adrp	x8, :got:g_bitmap
	ldr	x8, [x8, :got_lo12:g_bitmap]
	str	x8, [sp, #24]                   // 8-byte Folded Spill
	ldr	x0, [x8]
	ldur	x1, [x29, #-24]
	ldr	x2, [sp, #32]
	bl	vbitmap_set_range
	ldr	x8, [sp, #24]                   // 8-byte Folded Reload
	ldr	x0, [x8]
	ldur	x1, [x29, #-24]
	bl	vbitmap_get
	mov	w8, #1                          // =0x1
	and	w8, w0, w8
	sturb	w8, [x29, #-9]
	ldurb	w8, [x29, #-9]
	and	w8, w8, #0x1
	subs	w8, w8, #1
	b.ne	.LBB3_2
	b	.LBB3_1
.LBB3_1:
	b	.LBB3_3
.LBB3_2:
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	mov	w2, #44                         // =0x2c
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	bl	__assert_fail
.LBB3_3:
	adrp	x8, :got:g_bitmap
	ldr	x8, [x8, :got_lo12:g_bitmap]
	str	x8, [sp, #16]                   // 8-byte Folded Spill
	ldr	x0, [x8]
	ldur	x1, [x29, #-24]
	bl	vbitmap_clr_bit
	ldr	x8, [sp, #16]                   // 8-byte Folded Reload
	ldr	x0, [x8]
	ldur	x1, [x29, #-24]
	bl	vbitmap_get
	mov	w8, #1                          // =0x1
	and	w8, w0, w8
	sturb	w8, [x29, #-9]
	ldurb	w8, [x29, #-9]
	tbnz	w8, #0, .LBB3_5
	b	.LBB3_4
.LBB3_4:
	b	.LBB3_6
.LBB3_5:
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	mov	w2, #48                         // =0x30
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	bl	__assert_fail
.LBB3_6:
	adrp	x8, :got:g_bitmap
	ldr	x8, [x8, :got_lo12:g_bitmap]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	ldr	x0, [x8]
	ldur	x1, [x29, #-24]
	bl	vbitmap_set_bit
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	ldr	x0, [x8]
	ldur	x1, [x29, #-24]
	bl	vbitmap_get
	mov	w8, #1                          // =0x1
	and	w8, w0, w8
	sturb	w8, [x29, #-9]
	ldurb	w8, [x29, #-9]
	and	w8, w8, #0x1
	subs	w8, w8, #1
	b.ne	.LBB3_8
	b	.LBB3_7
.LBB3_7:
	b	.LBB3_9
.LBB3_8:
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	adrp	x1, .L.str.2
	add	x1, x1, :lo12:.L.str.2
	mov	w2, #52                         // =0x34
	adrp	x3, .L__PRETTY_FUNCTION__.writer
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.writer
	bl	__assert_fail
.LBB3_9:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	writer, .Lfunc_end3-writer
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_set_range
	.type	vbitmap_set_range,@function
vbitmap_set_range:                      // @vbitmap_set_range
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x29, x30, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	stur	xzr, [x29, #-32]
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB4_2
	b	.LBB4_1
.LBB4_1:
	b	.LBB4_3
.LBB4_2:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #214                        // =0xd6
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	bl	__assert_fail
.LBB4_3:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.hi	.LBB4_5
	b	.LBB4_4
.LBB4_4:
	b	.LBB4_6
.LBB4_5:
	adrp	x0, .L.str.8
	add	x0, x0, :lo12:.L.str.8
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #215                        // =0xd7
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	bl	__assert_fail
.LBB4_6:
	ldur	x8, [x29, #-24]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	.LBB4_8
	b	.LBB4_7
.LBB4_7:
	b	.LBB4_9
.LBB4_8:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #216                        // =0xd8
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	bl	__assert_fail
.LBB4_9:
	ldur	x8, [x29, #-16]
	mov	x10, #64                        // =0x40
	udiv	x8, x8, x10
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-24]
	udiv	x8, x8, x10
	str	x8, [sp, #40]
	ldur	x8, [x29, #-16]
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	str	x8, [sp, #24]
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.hi	.LBB4_11
	b	.LBB4_10
.LBB4_10:
	b	.LBB4_12
.LBB4_11:
	adrp	x0, .L.str.10
	add	x0, x0, :lo12:.L.str.10
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #223                        // =0xdf
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	bl	__assert_fail
.LBB4_12:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	.LBB4_14
	b	.LBB4_13
.LBB4_13:
	b	.LBB4_15
.LBB4_14:
	adrp	x0, .L.str.11
	add	x0, x0, :lo12:.L.str.11
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #224                        // =0xe0
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_range
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_range
	bl	__assert_fail
.LBB4_15:
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.ne	.LBB4_17
	b	.LBB4_16
.LBB4_16:
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #24]
	bl	_vbitmap_range_mask
	str	x0, [sp, #16]
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-32]
	ldr	x2, [sp, #16]
	bl	_vbitbmap_set_slot
	b	.LBB4_22
.LBB4_17:
	ldr	x0, [sp, #32]
	bl	_vbitmap_lsb_mask
	str	x0, [sp, #16]
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-32]
	ldr	x2, [sp, #16]
	bl	_vbitbmap_set_slot
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB4_18
.LBB4_18:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.hs	.LBB4_21
	b	.LBB4_19
.LBB4_19:                               //   in Loop: Header=BB4_18 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #16
	ldr	x9, [sp, #8]
	add	x0, x8, x9, lsl #3
	mov	x1, #-1                         // =0xffffffffffffffff
	bl	vatomic64_write
	b	.LBB4_20
.LBB4_20:                               //   in Loop: Header=BB4_18 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB4_18
.LBB4_21:
	ldr	x0, [sp, #24]
	bl	_vbitmap_msb_mask
	str	x0, [sp, #16]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #40]
	ldr	x2, [sp, #16]
	bl	_vbitbmap_set_slot
	b	.LBB4_22
.LBB4_22:
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]             // 16-byte Folded Reload
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end4:
	.size	vbitmap_set_range, .Lfunc_end4-vbitmap_set_range
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_get
	.type	vbitmap_get,@function
vbitmap_get:                            // @vbitmap_get
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB5_2
	b	.LBB5_1
.LBB5_1:
	b	.LBB5_3
.LBB5_2:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #140                        // =0x8c
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	bl	__assert_fail
.LBB5_3:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	.LBB5_5
	b	.LBB5_4
.LBB5_4:
	b	.LBB5_6
.LBB5_5:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #141                        // =0x8d
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	bl	__assert_fail
.LBB5_6:
	ldur	x8, [x29, #-16]
	mov	x9, #64                         // =0x40
	udiv	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	.LBB5_8
	b	.LBB5_7
.LBB5_7:
	b	.LBB5_9
.LBB5_8:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #143                        // =0x8f
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_get
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_get
	bl	__assert_fail
.LBB5_9:
	ldur	x8, [x29, #-16]
	mov	x10, #64                        // =0x40
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x9, x8, x9
	mov	x8, #1                          // =0x1
	lsl	x8, x8, x9
	str	x8, [sp, #16]
	ldur	x8, [x29, #-8]
	add	x8, x8, #16
	ldr	x9, [sp, #24]
	add	x0, x8, x9, lsl #3
	bl	vatomic64_read
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	and	x8, x8, x9
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	cset	w8, eq
	strb	w8, [sp, #7]
	ldrb	w8, [sp, #7]
	and	w0, w8, #0x1
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end5:
	.size	vbitmap_get, .Lfunc_end5-vbitmap_get
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_clr_bit
	.type	vbitmap_clr_bit,@function
vbitmap_clr_bit:                        // @vbitmap_clr_bit
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB6_2
	b	.LBB6_1
.LBB6_1:
	b	.LBB6_3
.LBB6_2:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #297                        // =0x129
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	bl	__assert_fail
.LBB6_3:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	.LBB6_5
	b	.LBB6_4
.LBB6_4:
	b	.LBB6_6
.LBB6_5:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #298                        // =0x12a
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	bl	__assert_fail
.LBB6_6:
	ldur	x8, [x29, #-16]
	mov	x9, #64                         // =0x40
	udiv	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	.LBB6_8
	b	.LBB6_7
.LBB6_7:
	b	.LBB6_9
.LBB6_8:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #300                        // =0x12c
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	bl	__assert_fail
.LBB6_9:
	ldur	x8, [x29, #-16]
	mov	x10, #64                        // =0x40
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x9, x8, x9
	mov	x8, #1                          // =0x1
	lsl	x8, x8, x9
	str	x8, [sp, #16]
	ldur	x8, [x29, #-8]
	add	x8, x8, #16
	ldr	x9, [sp, #24]
	add	x0, x8, x9, lsl #3
	ldr	x8, [sp, #16]
	mvn	x1, x8
	bl	vatomic64_and_get
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	and	x8, x8, x9
	cbnz	x8, .LBB6_11
	b	.LBB6_10
.LBB6_10:
	b	.LBB6_12
.LBB6_11:
	adrp	x0, .L.str.14
	add	x0, x0, :lo12:.L.str.14
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #303                        // =0x12f
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_clr_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_clr_bit
	bl	__assert_fail
.LBB6_12:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end6:
	.size	vbitmap_clr_bit, .Lfunc_end6-vbitmap_clr_bit
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_set_bit
	.type	vbitmap_set_bit,@function
vbitmap_set_bit:                        // @vbitmap_set_bit
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB7_2
	b	.LBB7_1
.LBB7_1:
	b	.LBB7_3
.LBB7_2:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #158                        // =0x9e
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	bl	__assert_fail
.LBB7_3:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	.LBB7_5
	b	.LBB7_4
.LBB7_4:
	b	.LBB7_6
.LBB7_5:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #159                        // =0x9f
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	bl	__assert_fail
.LBB7_6:
	ldur	x8, [x29, #-16]
	mov	x9, #64                         // =0x40
	udiv	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	.LBB7_8
	b	.LBB7_7
.LBB7_7:
	b	.LBB7_9
.LBB7_8:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #161                        // =0xa1
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	bl	__assert_fail
.LBB7_9:
	ldur	x8, [x29, #-16]
	mov	x10, #64                        // =0x40
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x9, x8, x9
	mov	x8, #1                          // =0x1
	lsl	x8, x8, x9
	str	x8, [sp, #16]
	ldur	x8, [x29, #-8]
	add	x8, x8, #16
	ldr	x9, [sp, #24]
	add	x0, x8, x9, lsl #3
	ldr	x1, [sp, #16]
	bl	vatomic64_or_get
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	and	x8, x8, x9
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	.LBB7_11
	b	.LBB7_10
.LBB7_10:
	b	.LBB7_12
.LBB7_11:
	adrp	x0, .L.str.15
	add	x0, x0, :lo12:.L.str.15
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #164                        // =0xa4
	adrp	x3, .L__PRETTY_FUNCTION__.vbitmap_set_bit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vbitmap_set_bit
	bl	__assert_fail
.LBB7_12:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end7:
	.size	vbitmap_set_bit, .Lfunc_end7-vbitmap_set_bit
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [sp]
	ldr	x8, [sp]
	subs	x8, x8, #11
	b.ne	.LBB8_2
	b	.LBB8_1
.LBB8_1:
	bl	reader
	b	.LBB8_3
.LBB8_2:
	ldr	x0, [sp]
	bl	writer
	b	.LBB8_3
.LBB8_3:
	mov	x0, xzr
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end8:
	.size	run, .Lfunc_end8-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #176
	.cfi_def_cfa_offset 176
	stp	x29, x30, [sp, #160]            // 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	mov	w8, wzr
	str	w8, [sp, #20]                   // 4-byte Folded Spill
	str	wzr, [sp, #52]
	mov	x0, #704                        // =0x2c0
	str	x0, [sp, #8]                    // 8-byte Folded Spill
	bl	vbitmap_size
	str	x0, [sp, #40]
	ldr	x0, [sp, #40]
	bl	malloc
	ldr	x1, [sp, #8]                    // 8-byte Folded Reload
	ldr	w8, [sp, #20]                   // 4-byte Folded Reload
	adrp	x9, :got:g_bitmap
	ldr	x9, [x9, :got_lo12:g_bitmap]
	str	x0, [x9]
	ldr	x0, [x9]
	and	w2, w8, #0x1
	bl	vbitmap_init
	str	xzr, [sp, #32]
	b	.LBB9_1
.LBB9_1:                                // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	subs	x8, x8, #12
	b.hs	.LBB9_4
	b	.LBB9_2
.LBB9_2:                                //   in Loop: Header=BB9_1 Depth=1
	ldr	x9, [sp, #32]
	add	x8, sp, #56
	add	x0, x8, x9, lsl #3
	ldr	x3, [sp, #32]
	mov	x1, xzr
	adrp	x2, :got:run
	ldr	x2, [x2, :got_lo12:run]
	bl	pthread_create
	b	.LBB9_3
.LBB9_3:                                //   in Loop: Header=BB9_1 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	.LBB9_1
.LBB9_4:
	str	xzr, [sp, #24]
	b	.LBB9_5
.LBB9_5:                                // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	subs	x8, x8, #12
	b.hs	.LBB9_8
	b	.LBB9_6
.LBB9_6:                                //   in Loop: Header=BB9_5 Depth=1
	ldr	x9, [sp, #24]
	add	x8, sp, #56
	ldr	x0, [x8, x9, lsl #3]
	mov	x1, xzr
	bl	pthread_join
	b	.LBB9_7
.LBB9_7:                                //   in Loop: Header=BB9_5 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	.LBB9_5
.LBB9_8:
	adrp	x8, :got:g_bitmap
	ldr	x8, [x8, :got_lo12:g_bitmap]
	ldr	x0, [x8]
	bl	free
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB9_10
	b	.LBB9_9
.LBB9_9:
	bl	__stack_chk_fail
.LBB9_10:
	mov	w0, wzr
	.cfi_def_cfa wsp, 176
	ldp	x29, x30, [sp, #160]            // 16-byte Folded Reload
	add	sp, sp, #176
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end9:
	.size	main, .Lfunc_end9-main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_size
	.type	vbitmap_size,@function
vbitmap_size:                           // @vbitmap_size
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	mov	x10, #64                        // =0x40
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	cbnz	x8, .LBB10_2
	b	.LBB10_1
.LBB10_1:
	ldr	x8, [sp, #24]
	mov	x9, #64                         // =0x40
	udiv	x8, x8, x9
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	b	.LBB10_3
.LBB10_2:
	ldr	x8, [sp, #24]
	mov	x9, #64                         // =0x40
	udiv	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	b	.LBB10_3
.LBB10_3:
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	lsl	x8, x8, #3
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	add	x0, x8, #16
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end10:
	.size	vbitmap_size, .Lfunc_end10-vbitmap_size
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vbitmap_init
	.type	vbitmap_init,@function
vbitmap_init:                           // @vbitmap_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	sturb	w2, [x29, #-17]
	ldurb	w9, [x29, #-17]
	mov	x8, xzr
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinv	x8, x8, xzr, eq
	str	x8, [sp, #16]
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-8]
	str	x8, [x9, #8]
	ldur	x8, [x29, #-16]
	mov	x10, #64                        // =0x40
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	cbnz	x8, .LBB11_2
	b	.LBB11_1
.LBB11_1:
	ldur	x8, [x29, #-16]
	mov	x9, #64                         // =0x40
	udiv	x8, x8, x9
	str	x8, [sp]                        // 8-byte Folded Spill
	b	.LBB11_3
.LBB11_2:
	ldur	x8, [x29, #-16]
	mov	x9, #64                         // =0x40
	udiv	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp]                        // 8-byte Folded Spill
	b	.LBB11_3
.LBB11_3:
	ldr	x8, [sp]                        // 8-byte Folded Reload
	ldur	x9, [x29, #-8]
	str	x8, [x9]
	str	xzr, [sp, #8]
	b	.LBB11_4
.LBB11_4:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	.LBB11_7
	b	.LBB11_5
.LBB11_5:                               //   in Loop: Header=BB11_4 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #16
	ldr	x9, [sp, #8]
	add	x0, x8, x9, lsl #3
	ldr	x1, [sp, #16]
	bl	vatomic64_init
	b	.LBB11_6
.LBB11_6:                               //   in Loop: Header=BB11_4 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB11_4
.LBB11_7:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end11:
	.size	vbitmap_init, .Lfunc_end11-vbitmap_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_read
	.type	vatomic64_read,@function
vatomic64_read:                         // @vatomic64_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x9, [sp, #8]
	//APP
	ldar	x8, [x9]
	//NO_APP
	str	x8, [sp]
	ldr	x0, [sp]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end12:
	.size	vatomic64_read, .Lfunc_end12-vatomic64_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _vbitmap_range_mask
	.type	_vbitmap_range_mask,@function
_vbitmap_range_mask:                    // @_vbitmap_range_mask
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x0, [x29, #-8]
	bl	_vbitmap_lsb_mask
	str	x0, [sp, #24]
	ldur	x0, [x29, #-16]
	bl	_vbitmap_msb_mask
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	and	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x0, [sp, #8]
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end13:
	.size	_vbitmap_range_mask, .Lfunc_end13-_vbitmap_range_mask
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _vbitbmap_set_slot
	.type	_vbitbmap_set_slot,@function
_vbitbmap_set_slot:                     // @_vbitbmap_set_slot
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	.LBB14_2
	b	.LBB14_1
.LBB14_1:
	b	.LBB14_3
.LBB14_2:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.5
	add	x1, x1, :lo12:.L.str.5
	mov	w2, #176                        // =0xb0
	adrp	x3, .L__PRETTY_FUNCTION__._vbitbmap_set_slot
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__._vbitbmap_set_slot
	bl	__assert_fail
.LBB14_3:
	ldur	x8, [x29, #-8]
	add	x8, x8, #16
	ldr	x9, [sp, #16]
	add	x0, x8, x9, lsl #3
	ldr	x1, [sp, #8]
	bl	vatomic64_or
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end14:
	.size	_vbitbmap_set_slot, .Lfunc_end14-_vbitbmap_set_slot
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _vbitmap_lsb_mask
	.type	_vbitmap_lsb_mask,@function
_vbitmap_lsb_mask:                      // @_vbitmap_lsb_mask
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	mov	x8, #1                          // =0x1
	str	x8, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	lsl	x8, x8, x9
	str	x8, [sp]
	ldr	x8, [sp]
	subs	x8, x8, #1
	str	x8, [sp]
	ldr	x8, [sp]
	mvn	x0, x8
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end15:
	.size	_vbitmap_lsb_mask, .Lfunc_end15-_vbitmap_lsb_mask
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_write
	.type	vatomic64_write,@function
vatomic64_write:                        // @vatomic64_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	//APP
	stlr	x8, [x9]
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end16:
	.size	vatomic64_write, .Lfunc_end16-vatomic64_write
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _vbitmap_msb_mask
	.type	_vbitmap_msb_mask,@function
_vbitmap_msb_mask:                      // @_vbitmap_msb_mask
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	mov	x8, #1                          // =0x1
	str	x8, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	lsl	x8, x8, x9
	str	x8, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp]
	subs	x9, x9, #1
	add	x8, x8, x9
	str	x8, [sp]
	ldr	x0, [sp]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end17:
	.size	_vbitmap_msb_mask, .Lfunc_end17-_vbitmap_msb_mask
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_or
	.type	vatomic64_or,@function
vatomic64_or:                           // @vatomic64_or
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	x12, [sp, #40]
	//APP
	prfm	pstl1strm, [x12]
.Ltmp6:
	ldaxr	x11, [x12]
	orr	x10, x11, x8
	stlxr	w9, x10, [x12]
	cbnz	w9, .Ltmp6

	//NO_APP
	str	x11, [sp, #24]
	str	x10, [sp, #16]
	str	w9, [sp, #12]
	str	x8, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end18:
	.size	vatomic64_or, .Lfunc_end18-vatomic64_or
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_and_get
	.type	vatomic64_and_get,@function
vatomic64_and_get:                      // @vatomic64_and_get
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	vatomic64_get_and
	ldr	x8, [sp]
	and	x0, x0, x8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end19:
	.size	vatomic64_and_get, .Lfunc_end19-vatomic64_and_get
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_get_and
	.type	vatomic64_get_and,@function
vatomic64_get_and:                      // @vatomic64_get_and
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	x12, [sp, #40]
	//APP
	prfm	pstl1strm, [x12]
.Ltmp8:
	ldaxr	x11, [x12]
	and	x10, x11, x8
	stlxr	w9, x10, [x12]
	cbnz	w9, .Ltmp8

	//NO_APP
	str	x11, [sp, #24]
	str	x10, [sp, #8]
	str	w9, [sp, #20]
	str	x8, [sp, #32]
	ldr	x0, [sp, #24]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end20:
	.size	vatomic64_get_and, .Lfunc_end20-vatomic64_get_and
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_or_get
	.type	vatomic64_or_get,@function
vatomic64_or_get:                       // @vatomic64_or_get
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	vatomic64_get_or
	ldr	x8, [sp]
	orr	x0, x0, x8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end21:
	.size	vatomic64_or_get, .Lfunc_end21-vatomic64_or_get
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_get_or
	.type	vatomic64_get_or,@function
vatomic64_get_or:                       // @vatomic64_get_or
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	x12, [sp, #40]
	//APP
	prfm	pstl1strm, [x12]
.Ltmp10:
	ldaxr	x11, [x12]
	orr	x10, x11, x8
	stlxr	w9, x10, [x12]
	cbnz	w9, .Ltmp10

	//NO_APP
	str	x11, [sp, #24]
	str	x10, [sp, #8]
	str	w9, [sp, #20]
	str	x8, [sp, #32]
	ldr	x0, [sp, #24]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end22:
	.size	vatomic64_get_or, .Lfunc_end22-vatomic64_get_or
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_init
	.type	vatomic64_init,@function
vatomic64_init:                         // @vatomic64_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	vatomic64_write
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end23:
	.size	vatomic64_init, .Lfunc_end23-vatomic64_init
	.cfi_endproc
                                        // -- End function
	.type	g_bitmap,@object                // @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.xword	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"set == 1"
	.size	.L.str.1, 9

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"C:/rc1111/src/libvsync/examples/eg_bitmap.c"
	.size	.L.str.2, 44

	.type	.L__PRETTY_FUNCTION__.writer,@object // @__PRETTY_FUNCTION__.writer
.L__PRETTY_FUNCTION__.writer:
	.asciz	"void writer(vsize_t)"
	.size	.L__PRETTY_FUNCTION__.writer, 21

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"set == 0"
	.size	.L.str.3, 9

	.type	.L.str.4,@object                // @.str.4
.L.str.4:
	.asciz	"bitmap"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                // @.str.5
.L.str.5:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/bitmap/bitmap.h"
	.size	.L.str.5, 53

	.type	.L__PRETTY_FUNCTION__.vbitmap_iter_init,@object // @__PRETTY_FUNCTION__.vbitmap_iter_init
.L__PRETTY_FUNCTION__.vbitmap_iter_init:
	.asciz	"void vbitmap_iter_init(vbitmap_t *, vbitmap_iter_t *)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_iter_init, 54

	.type	.L.str.6,@object                // @.str.6
.L.str.6:
	.asciz	"iter"
	.size	.L.str.6, 5

	.type	.L.str.7,@object                // @.str.7
.L.str.7:
	.asciz	"bitmap->maps_cnt > 0"
	.size	.L.str.7, 21

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_range,@object // @__PRETTY_FUNCTION__.vbitmap_set_range
.L__PRETTY_FUNCTION__.vbitmap_set_range:
	.asciz	"void vbitmap_set_range(vbitmap_t *, vsize_t, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_range, 54

	.type	.L.str.8,@object                // @.str.8
.L.str.8:
	.asciz	"from <= to"
	.size	.L.str.8, 11

	.type	.L.str.9,@object                // @.str.9
.L.str.9:
	.asciz	"to < bitmap->bit_cnt"
	.size	.L.str.9, 21

	.type	.L.str.10,@object               // @.str.10
.L.str.10:
	.asciz	"lsb_slot <= msb_slot"
	.size	.L.str.10, 21

	.type	.L.str.11,@object               // @.str.11
.L.str.11:
	.asciz	"msb_slot < bitmap->maps_cnt"
	.size	.L.str.11, 28

	.type	.L.str.12,@object               // @.str.12
.L.str.12:
	.asciz	"idx < bitmap->maps_cnt"
	.size	.L.str.12, 23

	.type	.L__PRETTY_FUNCTION__._vbitbmap_set_slot,@object // @__PRETTY_FUNCTION__._vbitbmap_set_slot
.L__PRETTY_FUNCTION__._vbitbmap_set_slot:
	.asciz	"void _vbitbmap_set_slot(vbitmap_t *, vsize_t, vuint64_t)"
	.size	.L__PRETTY_FUNCTION__._vbitbmap_set_slot, 57

	.type	.L__PRETTY_FUNCTION__.vbitmap_get,@object // @__PRETTY_FUNCTION__.vbitmap_get
.L__PRETTY_FUNCTION__.vbitmap_get:
	.asciz	"vbool_t vbitmap_get(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_get, 42

	.type	.L.str.13,@object               // @.str.13
.L.str.13:
	.asciz	"bit_idx < bitmap->bit_cnt"
	.size	.L.str.13, 26

	.type	.L__PRETTY_FUNCTION__.vbitmap_clr_bit,@object // @__PRETTY_FUNCTION__.vbitmap_clr_bit
.L__PRETTY_FUNCTION__.vbitmap_clr_bit:
	.asciz	"void vbitmap_clr_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_clr_bit, 43

	.type	.L.str.14,@object               // @.str.14
.L.str.14:
	.asciz	"(val & mask) == 0UL"
	.size	.L.str.14, 20

	.type	.L__PRETTY_FUNCTION__.vbitmap_set_bit,@object // @__PRETTY_FUNCTION__.vbitmap_set_bit
.L__PRETTY_FUNCTION__.vbitmap_set_bit:
	.asciz	"void vbitmap_set_bit(vbitmap_t *, vsize_t)"
	.size	.L__PRETTY_FUNCTION__.vbitmap_set_bit, 43

	.type	.L.str.15,@object               // @.str.15
.L.str.15:
	.asciz	"(val & mask) == mask"
	.size	.L.str.15, 21

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym reader
	.addrsig_sym vbitmap_iter_init
	.addrsig_sym vbitmap_iter_next
	.addrsig_sym printf
	.addrsig_sym writer
	.addrsig_sym vbitmap_set_range
	.addrsig_sym vbitmap_get
	.addrsig_sym __assert_fail
	.addrsig_sym vbitmap_clr_bit
	.addrsig_sym vbitmap_set_bit
	.addrsig_sym run
	.addrsig_sym vbitmap_size
	.addrsig_sym malloc
	.addrsig_sym vbitmap_init
	.addrsig_sym pthread_create
	.addrsig_sym pthread_join
	.addrsig_sym free
	.addrsig_sym vatomic64_read
	.addrsig_sym _vbitmap_range_mask
	.addrsig_sym _vbitbmap_set_slot
	.addrsig_sym _vbitmap_lsb_mask
	.addrsig_sym vatomic64_write
	.addrsig_sym _vbitmap_msb_mask
	.addrsig_sym vatomic64_or
	.addrsig_sym vatomic64_and_get
	.addrsig_sym vatomic64_get_and
	.addrsig_sym vatomic64_or_get
	.addrsig_sym vatomic64_get_or
	.addrsig_sym vatomic64_init
	.addrsig_sym g_bitmap
