	.file	"eg_unbounded_queue_lf_recycle.c"
	.text
	.globl	destroy_pools                   // -- Begin function destroy_pools
	.p2align	2
	.type	destroy_pools,@function
destroy_pools:                          // @destroy_pools
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	b	.LBB0_1
.LBB0_1:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_3 Depth 2
	ldr	x8, [sp, #8]
	subs	x8, x8, #12
	b.hs	.LBB0_7
	b	.LBB0_2
.LBB0_2:                                //   in Loop: Header=BB0_1 Depth=1
	ldr	x9, [sp, #8]
	adrp	x8, :got:local_pools
	ldr	x8, [x8, :got_lo12:local_pools]
	ldr	x8, [x8, x9, lsl #3]
	stur	x8, [x29, #-8]
	b	.LBB0_3
.LBB0_3:                                //   Parent Loop BB0_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB0_5
	b	.LBB0_4
.LBB0_4:                                //   in Loop: Header=BB0_3 Depth=2
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	bl	vatomicptr_stamped_get_pointer
	str	x0, [sp, #16]
	ldur	x0, [x29, #-8]
	bl	free
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	.LBB0_3
.LBB0_5:                                //   in Loop: Header=BB0_1 Depth=1
	b	.LBB0_6
.LBB0_6:                                //   in Loop: Header=BB0_1 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB0_1
.LBB0_7:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	destroy_pools, .Lfunc_end0-destroy_pools
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_stamped_get_pointer
	.type	vatomicptr_stamped_get_pointer,@function
vatomicptr_stamped_get_pointer:         // @vatomicptr_stamped_get_pointer
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #8]
	sub	x1, x29, #9
	sturb	wzr, [x29, #-9]
	ldr	x0, [sp, #8]
	bl	vatomicptr_stamped_get
	str	x0, [sp]                        // 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB1_2
	b	.LBB1_1
.LBB1_1:
	bl	__stack_chk_fail
.LBB1_2:
	ldr	x0, [sp]                        // 8-byte Folded Reload
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end1:
	.size	vatomicptr_stamped_get_pointer, .Lfunc_end1-vatomicptr_stamped_get_pointer
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	bl	free
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	destroy_cb, .Lfunc_end2-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	sub	x1, x29, #9
	sturb	wzr, [x29, #-9]
	ldr	x8, [sp, #24]
	add	x0, x8, #8
	bl	vatomicptr_stamped_get
	ldr	x8, [sp, #24]
	ldr	x10, [sp, #8]
	adrp	x9, :got:local_pools
	ldr	x9, [x9, :got_lo12:local_pools]
	str	x9, [sp]                        // 8-byte Folded Spill
	ldr	x1, [x9, x10, lsl #3]
	ldurb	w9, [x29, #-9]
	add	w2, w9, #1
	add	x0, x8, #8
	bl	vatomicptr_stamped_set
	ldr	x9, [sp]                        // 8-byte Folded Reload
	ldr	x8, [sp, #24]
	ldr	x10, [sp, #8]
	str	x8, [x9, x10, lsl #3]
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB3_2
	b	.LBB3_1
.LBB3_1:
	bl	__stack_chk_fail
.LBB3_2:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_stamped_get
	.type	vatomicptr_stamped_get,@function
vatomicptr_stamped_get:                 // @vatomicptr_stamped_get
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	bl	vatomicptr_read
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	and	x8, x8, #0x7f
	ldr	x9, [sp, #16]
                                        // kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9]
	ldr	x8, [sp, #8]
	and	x0, x8, #0xffffffffffffff80
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end4:
	.size	vatomicptr_stamped_get, .Lfunc_end4-vatomicptr_stamped_get
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_stamped_set
	.type	vatomicptr_stamped_set,@function
vatomicptr_stamped_set:                 // @vatomicptr_stamped_set
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	strb	w2, [sp, #15]
	ldr	x8, [sp, #16]
	ldrb	w9, [sp, #15]
                                        // kill: def $x9 killed $w9
	and	x9, x9, #0x7f
	orr	x8, x8, x9
	str	x8, [sp]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp]
	bl	vatomicptr_write
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end5:
	.size	vatomicptr_stamped_set, .Lfunc_end5-vatomicptr_stamped_set
	.cfi_endproc
                                        // -- End function
	.globl	alloc_qnode                     // -- Begin function alloc_qnode
	.p2align	2
	.type	alloc_qnode,@function
alloc_qnode:                            // @alloc_qnode
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	ldur	x9, [x29, #-8]
	adrp	x8, :got:local_pools
	ldr	x8, [x8, :got_lo12:local_pools]
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, .LBB6_2
	b	.LBB6_1
.LBB6_1:
	ldur	x9, [x29, #-8]
	adrp	x8, :got:local_pools
	ldr	x8, [x8, :got_lo12:local_pools]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	ldr	x9, [x8, x9, lsl #3]
	str	x9, [sp, #16]
	ldur	x9, [x29, #-8]
	ldr	x8, [x8, x9, lsl #3]
	add	x0, x8, #8
	bl	vatomicptr_stamped_get_pointer
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	ldur	x9, [x29, #-8]
	str	x0, [x8, x9, lsl #3]
	adrp	x0, .L.str
	add	x0, x0, :lo12:.L.str
	bl	printf
	b	.LBB6_3
.LBB6_2:
	mov	x1, #128                        // =0x80
	mov	x0, x1
	bl	memalign
	str	x0, [sp, #16]
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	bl	printf
	b	.LBB6_3
.LBB6_3:
	ldr	x0, [sp, #16]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end6:
	.size	alloc_qnode, .Lfunc_end6-alloc_qnode
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-16]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #24]
	str	xzr, [sp, #16]
	b	.LBB7_1
.LBB7_1:                                // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #100
	b.hs	.LBB7_7
	b	.LBB7_2
.LBB7_2:                                //   in Loop: Header=BB7_1 Depth=1
	ldr	x2, [sp, #24]
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:retire_cb
	ldr	x1, [x1, :got_lo12:retire_cb]
	bl	vqueue_ub_deq
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, .LBB7_4
	b	.LBB7_3
.LBB7_3:                                //   in Loop: Header=BB7_1 Depth=1
	mov	x0, #8                          // =0x8
	bl	malloc
	stur	x0, [x29, #-16]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	ldr	x0, [sp, #24]
	bl	alloc_qnode
	str	x0, [sp, #8]
	ldr	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x2, [x8]
	adrp	x0, .L.str.2
	add	x0, x0, :lo12:.L.str.2
	bl	printf
	ldr	x1, [sp, #8]
	ldur	x2, [x29, #-16]
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	bl	vqueue_ub_enq
	b	.LBB7_5
.LBB7_4:                                //   in Loop: Header=BB7_1 Depth=1
	ldr	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x2, [x8]
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	bl	printf
	ldur	x0, [x29, #-16]
	bl	free
	b	.LBB7_5
.LBB7_5:                                //   in Loop: Header=BB7_1 Depth=1
	b	.LBB7_6
.LBB7_6:                                //   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB7_1
.LBB7_7:
	mov	x0, xzr
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end7:
	.size	run, .Lfunc_end7-run
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_deq
	.type	vqueue_ub_deq,@function
vqueue_ub_deq:                          // @vqueue_ub_deq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	str	x2, [sp, #48]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	sturb	wzr, [x29, #-9]
	sturb	wzr, [x29, #-10]
	sturb	wzr, [x29, #-11]
	sturb	wzr, [x29, #-12]
	str	xzr, [sp, #16]
	b	.LBB8_1
.LBB8_1:                                // =>This Inner Loop Header: Depth=1
	ldur	x0, [x29, #-32]
	sub	x1, x29, #9
	bl	vatomicptr_stamped_get
	str	x0, [sp, #40]
	ldur	x8, [x29, #-32]
	add	x0, x8, #8
	sub	x1, x29, #10
	bl	vatomicptr_stamped_get
	str	x0, [sp, #32]
	ldr	x8, [sp, #40]
	add	x0, x8, #8
	sub	x1, x29, #11
	bl	vatomicptr_stamped_get
	str	x0, [sp, #24]
	ldr	x8, [sp, #40]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	ldur	x0, [x29, #-32]
	sub	x1, x29, #12
	bl	vatomicptr_stamped_get
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	subs	x8, x8, x0
	b.ne	.LBB8_13
	b	.LBB8_2
.LBB8_2:                                //   in Loop: Header=BB8_1 Depth=1
	ldurb	w8, [x29, #-12]
	ldurb	w9, [x29, #-9]
	subs	w8, w8, w9
	b.ne	.LBB8_13
	b	.LBB8_3
.LBB8_3:                                //   in Loop: Header=BB8_1 Depth=1
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.ne	.LBB8_7
	b	.LBB8_4
.LBB8_4:                                //   in Loop: Header=BB8_1 Depth=1
	ldr	x8, [sp, #24]
	cbnz	x8, .LBB8_6
	b	.LBB8_5
.LBB8_5:
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	.LBB8_14
.LBB8_6:                                //   in Loop: Header=BB8_1 Depth=1
	bl	verification_ignore
	ldur	x8, [x29, #-32]
	add	x0, x8, #8
	ldr	x1, [sp, #32]
	ldurb	w2, [x29, #-10]
	ldr	x3, [sp, #24]
	ldurb	w8, [x29, #-10]
	add	w4, w8, #1
	bl	vatomicptr_stamped_cmpxchg
	b	.LBB8_12
.LBB8_7:                                //   in Loop: Header=BB8_1 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	str	x8, [sp, #16]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #40]
	ldurb	w2, [x29, #-9]
	ldr	x3, [sp, #24]
	ldurb	w8, [x29, #-9]
	add	w4, w8, #1
	bl	vatomicptr_stamped_cmpxchg
	tbz	w0, #0, .LBB8_11
	b	.LBB8_8
.LBB8_8:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-32]
	add	x9, x9, #128
	subs	x8, x8, x9
	b.eq	.LBB8_10
	b	.LBB8_9
.LBB8_9:
	ldur	x8, [x29, #-40]
	ldr	x0, [sp, #40]
	ldr	x1, [sp, #48]
	blr	x8
	b	.LBB8_10
.LBB8_10:
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-24]
	b	.LBB8_14
.LBB8_11:                               //   in Loop: Header=BB8_1 Depth=1
	b	.LBB8_12
.LBB8_12:                               //   in Loop: Header=BB8_1 Depth=1
	b	.LBB8_13
.LBB8_13:                               //   in Loop: Header=BB8_1 Depth=1
	b	.LBB8_1
.LBB8_14:
	ldur	x8, [x29, #-24]
	str	x8, [sp]                        // 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB8_16
	b	.LBB8_15
.LBB8_15:
	bl	__stack_chk_fail
.LBB8_16:
	ldr	x0, [sp]                        // 8-byte Folded Reload
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end8:
	.size	vqueue_ub_deq, .Lfunc_end8-vqueue_ub_deq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_enq
	.type	vqueue_ub_enq,@function
vqueue_ub_enq:                          // @vqueue_ub_enq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-32]
	stur	x2, [x29, #-40]
	mov	x8, xzr
	str	x8, [sp, #24]                   // 8-byte Folded Spill
	str	xzr, [sp, #48]
	str	xzr, [sp, #40]
	sturb	wzr, [x29, #-9]
	sturb	wzr, [x29, #-10]
	sturb	wzr, [x29, #-11]
	sub	x1, x29, #12
	sturb	wzr, [x29, #-12]
	strb	wzr, [sp, #39]
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	ldur	x8, [x29, #-32]
	add	x0, x8, #8
	bl	vatomicptr_stamped_get
	ldr	x1, [sp, #24]                   // 8-byte Folded Reload
	ldur	x8, [x29, #-32]
	ldurb	w2, [x29, #-12]
	add	x0, x8, #8
	bl	vatomicptr_stamped_set
	b	.LBB9_1
.LBB9_1:                                // =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-24]
	add	x0, x8, #8
	sub	x1, x29, #9
	bl	vatomicptr_stamped_get
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	add	x0, x8, #8
	sub	x1, x29, #10
	bl	vatomicptr_stamped_get
	str	x0, [sp, #40]
	ldr	x8, [sp, #48]
	str	x8, [sp, #16]                   // 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	add	x0, x8, #8
	sub	x1, x29, #11
	bl	vatomicptr_stamped_get
	ldr	x8, [sp, #16]                   // 8-byte Folded Reload
	subs	x8, x8, x0
	b.ne	.LBB9_11
	b	.LBB9_2
.LBB9_2:                                //   in Loop: Header=BB9_1 Depth=1
	ldurb	w8, [x29, #-9]
	ldurb	w9, [x29, #-11]
	subs	w8, w8, w9
	b.ne	.LBB9_11
	b	.LBB9_3
.LBB9_3:                                //   in Loop: Header=BB9_1 Depth=1
	ldr	x8, [sp, #40]
	cbnz	x8, .LBB9_9
	b	.LBB9_4
.LBB9_4:                                //   in Loop: Header=BB9_1 Depth=1
	ldr	x8, [sp, #48]
	add	x0, x8, #8
	ldr	x1, [sp, #40]
	ldurb	w2, [x29, #-10]
	ldur	x3, [x29, #-32]
	ldurb	w8, [x29, #-10]
	add	w4, w8, #1
	bl	vatomicptr_stamped_cmpxchg
	tbz	w0, #0, .LBB9_8
	b	.LBB9_5
.LBB9_5:
	ldur	x8, [x29, #-24]
	add	x0, x8, #8
	ldr	x1, [sp, #48]
	ldurb	w2, [x29, #-9]
	ldur	x3, [x29, #-32]
	ldurb	w8, [x29, #-9]
	mov	w9, #1                          // =0x1
	str	w9, [sp, #12]                   // 4-byte Folded Spill
	add	w4, w8, #1
	bl	vatomicptr_stamped_cmpxchg
	ldr	w8, [sp, #12]                   // 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #39]
	ldrb	w8, [sp, #39]
	and	w0, w8, #0x1
	bl	verification_assume
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB9_7
	b	.LBB9_6
.LBB9_6:
	bl	__stack_chk_fail
.LBB9_7:
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB9_8:                                //   in Loop: Header=BB9_1 Depth=1
	.cfi_restore_state
	b	.LBB9_10
.LBB9_9:                                //   in Loop: Header=BB9_1 Depth=1
	bl	verification_ignore
	ldur	x8, [x29, #-24]
	add	x0, x8, #8
	ldr	x1, [sp, #48]
	ldurb	w2, [x29, #-9]
	ldr	x3, [sp, #40]
	ldurb	w8, [x29, #-9]
	add	w4, w8, #1
	bl	vatomicptr_stamped_cmpxchg
	b	.LBB9_10
.LBB9_10:                               //   in Loop: Header=BB9_1 Depth=1
	b	.LBB9_11
.LBB9_11:                               //   in Loop: Header=BB9_1 Depth=1
	b	.LBB9_1
.Lfunc_end9:
	.size	vqueue_ub_enq, .Lfunc_end9-vqueue_ub_enq
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	stp	x29, x30, [sp, #144]            // 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	wzr, [sp, #36]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	bl	vqueue_ub_init
	str	xzr, [sp, #16]
	b	.LBB10_1
.LBB10_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #12
	b.hs	.LBB10_4
	b	.LBB10_2
.LBB10_2:                               //   in Loop: Header=BB10_1 Depth=1
	ldr	x9, [sp, #16]
	add	x8, sp, #40
	add	x0, x8, x9, lsl #3
	ldr	x3, [sp, #16]
	mov	x1, xzr
	adrp	x2, :got:run
	ldr	x2, [x2, :got_lo12:run]
	bl	pthread_create
	b	.LBB10_3
.LBB10_3:                               //   in Loop: Header=BB10_1 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB10_1
.LBB10_4:
	str	xzr, [sp, #8]
	b	.LBB10_5
.LBB10_5:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	subs	x8, x8, #12
	b.hs	.LBB10_8
	b	.LBB10_6
.LBB10_6:                               //   in Loop: Header=BB10_5 Depth=1
	ldr	x9, [sp, #8]
	add	x8, sp, #40
	ldr	x0, [x8, x9, lsl #3]
	mov	x1, xzr
	bl	pthread_join
	b	.LBB10_7
.LBB10_7:                               //   in Loop: Header=BB10_5 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB10_5
.LBB10_8:
	b	.LBB10_9
.LBB10_9:                               // =>This Inner Loop Header: Depth=1
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:destroy_cb
	ldr	x1, [x1, :got_lo12:destroy_cb]
	mov	x2, xzr
	bl	vqueue_ub_deq
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbz	x8, .LBB10_11
	b	.LBB10_10
.LBB10_10:                              //   in Loop: Header=BB10_9 Depth=1
	ldr	x0, [sp, #24]
	bl	free
	b	.LBB10_9
.LBB10_11:
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:destroy_cb
	ldr	x1, [x1, :got_lo12:destroy_cb]
	mov	x2, xzr
	bl	vqueue_ub_destroy
	bl	destroy_pools
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB10_13
	b	.LBB10_12
.LBB10_12:
	bl	__stack_chk_fail
.LBB10_13:
	mov	w0, wzr
	.cfi_def_cfa wsp, 160
	ldp	x29, x30, [sp, #144]            // 16-byte Folded Reload
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end10:
	.size	main, .Lfunc_end10-main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_init
	.type	vqueue_ub_init,@function
vqueue_ub_init:                         // @vqueue_ub_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	add	x0, x8, #136
	mov	x1, xzr
	mov	w2, wzr
	str	w2, [sp, #4]                    // 4-byte Folded Spill
	bl	vatomicptr_stamped_set_rlx
	ldr	w2, [sp, #4]                    // 4-byte Folded Reload
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #8]
	add	x1, x8, #128
	bl	vatomicptr_stamped_set_rlx
	ldr	w2, [sp, #4]                    // 4-byte Folded Reload
	ldr	x9, [sp, #8]
	ldr	x8, [sp, #8]
	add	x0, x9, #8
	add	x1, x8, #128
	bl	vatomicptr_stamped_set_rlx
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end11:
	.size	vqueue_ub_init, .Lfunc_end11-vqueue_ub_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_destroy
	.type	vqueue_ub_destroy,@function
vqueue_ub_destroy:                      // @vqueue_ub_destroy
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	x0, [x29, #-8]
	bl	vatomicptr_stamped_get_pointer
	str	x0, [sp, #8]
	b	.LBB12_1
.LBB12_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	cbz	x8, .LBB12_5
	b	.LBB12_2
.LBB12_2:                               //   in Loop: Header=BB12_1 Depth=1
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	bl	vatomicptr_stamped_get_pointer
	str	x0, [sp, #16]
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-8]
	add	x9, x9, #128
	subs	x8, x8, x9
	b.eq	.LBB12_4
	b	.LBB12_3
.LBB12_3:                               //   in Loop: Header=BB12_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #24]
	blr	x8
	b	.LBB12_4
.LBB12_4:                               //   in Loop: Header=BB12_1 Depth=1
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	b	.LBB12_1
.LBB12_5:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end12:
	.size	vqueue_ub_destroy, .Lfunc_end12-vqueue_ub_destroy
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_read
	.type	vatomicptr_read,@function
vatomicptr_read:                        // @vatomicptr_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	//APP
	//NO_APP
	ldr	x8, [sp, #24]
	ldar	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [sp, #16]
	//APP
	//NO_APP
	ldr	x0, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end13:
	.size	vatomicptr_read, .Lfunc_end13-vatomicptr_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_write
	.type	vatomicptr_write,@function
vatomicptr_write:                       // @vatomicptr_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	//APP
	//NO_APP
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	stlr	x8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end14:
	.size	vatomicptr_write, .Lfunc_end14-vatomicptr_write
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function verification_ignore
	.type	verification_ignore,@function
verification_ignore:                    // @verification_ignore
	.cfi_startproc
// %bb.0:
	ret
.Lfunc_end15:
	.size	verification_ignore, .Lfunc_end15-verification_ignore
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_stamped_cmpxchg
	.type	vatomicptr_stamped_cmpxchg,@function
vatomicptr_stamped_cmpxchg:             // @vatomicptr_stamped_cmpxchg
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	sturb	w2, [x29, #-17]
	str	x3, [sp, #32]
	strb	w4, [sp, #31]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	str	xzr, [sp]
	ldur	x8, [x29, #-16]
	ldurb	w9, [x29, #-17]
                                        // kill: def $x9 killed $w9
	and	x9, x9, #0x7f
	orr	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #32]
	ldrb	w9, [sp, #31]
                                        // kill: def $x9 killed $w9
	and	x9, x9, #0x7f
	orr	x8, x8, x9
	str	x8, [sp]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	ldr	x2, [sp]
	bl	vatomicptr_cmpxchg
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	cset	w0, eq
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end16:
	.size	vatomicptr_stamped_cmpxchg, .Lfunc_end16-vatomicptr_stamped_cmpxchg
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_cmpxchg
	.type	vatomicptr_cmpxchg,@function
vatomicptr_cmpxchg:                     // @vatomicptr_cmpxchg
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #56]
	str	x1, [sp, #48]
	str	x2, [sp, #40]
	ldr	x8, [sp, #48]
	str	x8, [sp, #32]
	//APP
	//NO_APP
	ldr	x11, [sp, #56]
	ldr	x8, [sp, #40]
	str	x8, [sp, #24]
	ldr	x9, [sp, #32]
	ldr	x12, [sp, #24]
.LBB17_1:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x8, [x11]
	cmp	x8, x9
	b.ne	.LBB17_3
// %bb.2:                               //   in Loop: Header=BB17_1 Depth=1
	stlxr	w10, x12, [x11]
	cbnz	w10, .LBB17_1
.LBB17_3:
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	subs	x10, x8, x9
	cset	w10, eq
	str	w10, [sp, #16]                  // 4-byte Folded Spill
	subs	x8, x8, x9
	b.eq	.LBB17_5
	b	.LBB17_4
.LBB17_4:
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #32]
	b	.LBB17_5
.LBB17_5:
	ldr	w8, [sp, #16]                   // 4-byte Folded Reload
	strb	w8, [sp, #23]
	//APP
	//NO_APP
	ldr	x0, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end17:
	.size	vatomicptr_cmpxchg, .Lfunc_end17-vatomicptr_cmpxchg
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function verification_assume
	.type	verification_assume,@function
verification_assume:                    // @verification_assume
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	b	.LBB18_1
.LBB18_1:
	b	.LBB18_2
.LBB18_2:
	b	.LBB18_3
.LBB18_3:
	b	.LBB18_4
.LBB18_4:
	b	.LBB18_5
.LBB18_5:
	b	.LBB18_6
.LBB18_6:
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end18:
	.size	verification_assume, .Lfunc_end18-verification_assume
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_stamped_set_rlx
	.type	vatomicptr_stamped_set_rlx,@function
vatomicptr_stamped_set_rlx:             // @vatomicptr_stamped_set_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	strb	w2, [sp, #15]
	ldr	x8, [sp, #16]
	ldrb	w9, [sp, #15]
                                        // kill: def $x9 killed $w9
	and	x9, x9, #0x7f
	orr	x8, x8, x9
	str	x8, [sp]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp]
	bl	vatomicptr_write_rlx
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end19:
	.size	vatomicptr_stamped_set_rlx, .Lfunc_end19-vatomicptr_stamped_set_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_write_rlx
	.type	vatomicptr_write_rlx,@function
vatomicptr_write_rlx:                   // @vatomicptr_write_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	//APP
	//NO_APP
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end20:
	.size	vatomicptr_write_rlx, .Lfunc_end20-vatomicptr_write_rlx
	.cfi_endproc
                                        // -- End function
	.type	local_pools,@object             // @local_pools
	.bss
	.globl	local_pools
	.p2align	3, 0x0
local_pools:
	.zero	96
	.size	local_pools, 96

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Recycle allocation\n"
	.size	.L.str, 20

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"New allocation\n"
	.size	.L.str.1, 16

	.type	g_queue,@object                 // @g_queue
	.bss
	.globl	g_queue
	.p2align	7, 0x0
g_queue:
	.zero	256
	.size	g_queue, 256

	.type	.L.str.2,@object                // @.str.2
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.2:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.2, 16

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.3, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym destroy_pools
	.addrsig_sym vatomicptr_stamped_get_pointer
	.addrsig_sym free
	.addrsig_sym destroy_cb
	.addrsig_sym retire_cb
	.addrsig_sym vatomicptr_stamped_get
	.addrsig_sym vatomicptr_stamped_set
	.addrsig_sym alloc_qnode
	.addrsig_sym printf
	.addrsig_sym memalign
	.addrsig_sym run
	.addrsig_sym vqueue_ub_deq
	.addrsig_sym malloc
	.addrsig_sym vqueue_ub_enq
	.addrsig_sym vqueue_ub_init
	.addrsig_sym pthread_create
	.addrsig_sym pthread_join
	.addrsig_sym vqueue_ub_destroy
	.addrsig_sym vatomicptr_read
	.addrsig_sym vatomicptr_write
	.addrsig_sym verification_ignore
	.addrsig_sym vatomicptr_stamped_cmpxchg
	.addrsig_sym vatomicptr_cmpxchg
	.addrsig_sym verification_assume
	.addrsig_sym vatomicptr_stamped_set_rlx
	.addrsig_sym vatomicptr_write_rlx
	.addrsig_sym local_pools
	.addrsig_sym g_queue
