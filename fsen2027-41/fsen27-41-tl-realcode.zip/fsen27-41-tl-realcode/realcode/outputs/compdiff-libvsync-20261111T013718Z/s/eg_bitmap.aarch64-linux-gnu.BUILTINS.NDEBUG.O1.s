	.file	"eg_bitmap.c"
	.text
	.globl	reader                          // -- Begin function reader
	.p2align	2
	.type	reader,@function
reader:                                 // @reader
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	adrp	x21, :got:g_bitmap
	mov	w22, #1                         // =0x1
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
	b	.LBB0_2
.LBB0_1:                                //   in Loop: Header=BB0_2 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.hs	.LBB0_9
.LBB0_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_5 Depth 2
	ldr	x8, [x21]
	//APP
	//NO_APP
	mov	x11, xzr
	mov	x20, xzr
	add	x9, x8, #16
	ldar	x10, [x9]
	//APP
	//NO_APP
	add	x9, x8, #24
	cbz	x10, .LBB0_4
.LBB0_3:                                //   in Loop: Header=BB0_2 Depth=1
	mov	x12, x11
	b	.LBB0_7
.LBB0_4:                                //   in Loop: Header=BB0_2 Depth=1
	ldr	x13, [x8]
.LBB0_5:                                //   Parent Loop BB0_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x12, x11, #1
	cmp	x12, x13
	b.hs	.LBB0_1
// %bb.6:                               //   in Loop: Header=BB0_5 Depth=2
	add	x10, x9, x11, lsl #3
	//APP
	//NO_APP
	mov	x11, x12
	ldar	x10, [x10]
	//APP
	//NO_APP
	cbz	x10, .LBB0_5
.LBB0_7:                                //   in Loop: Header=BB0_2 Depth=1
	rbit	x11, x10
	ldr	x14, [x8, #8]
	clz	x11, x11
	orr	x13, x11, x12, lsl #6
	cmp	x13, x14
	b.hs	.LBB0_1
// %bb.8:                               //   in Loop: Header=BB0_2 Depth=1
	lsl	x11, x22, x11
	add	x20, x20, #1
	bic	x10, x10, x11
	mov	x11, x12
	cbnz	x10, .LBB0_3
	b	.LBB0_4
.LBB0_9:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        // -- End function
	.globl	writer                          // -- Begin function writer
	.p2align	2
	.type	writer,@function
writer:                                 // @writer
	.cfi_startproc
// %bb.0:
	adrp	x9, :got:g_bitmap
	and	x8, x0, #0x3ffffffffffffff
	mov	x11, #-1                        // =0xffffffffffffffff
	ldr	x9, [x9, :got_lo12:g_bitmap]
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
.LBB1_1:                                // =>This Inner Loop Header: Depth=1
	ldaxr	xzr, [x10]
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB1_1
// %bb.2:
	//APP
	//NO_APP
	lsl	x10, x8, #3
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
.LBB1_3:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x12, [x11]
	and	x12, x12, #0xfffffffffffffffe
	stlxr	w13, x12, [x11]
	cbnz	w13, .LBB1_3
// %bb.4:
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x10, x11, x10
	add	x10, x10, #16
.LBB1_5:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x11, [x10]
	orr	x11, x11, #0x1
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB1_5
// %bb.6:
	//APP
	//NO_APP
	ldr	x9, [x9]
	//APP
	//NO_APP
	add	x8, x9, x8, lsl #3
	add	x8, x8, #16
	ldar	xzr, [x8]
	//APP
	//NO_APP
	ret
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	cmp	x0, #11
	b.eq	.LBB2_9
// %bb.1:
	adrp	x9, :got:g_bitmap
	and	x8, x0, #0x3ffffffffffffff
	mov	x11, #-1                        // =0xffffffffffffffff
	ldr	x9, [x9, :got_lo12:g_bitmap]
	ldr	x10, [x9]
	//APP
	//NO_APP
	add	x10, x10, x8, lsl #3
	add	x10, x10, #16
.LBB2_2:                                // =>This Inner Loop Header: Depth=1
	ldaxr	xzr, [x10]
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB2_2
// %bb.3:
	//APP
	//NO_APP
	lsl	x10, x8, #3
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
.LBB2_4:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x12, [x11]
	and	x12, x12, #0xfffffffffffffffe
	stlxr	w13, x12, [x11]
	cbnz	w13, .LBB2_4
// %bb.5:
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x11, x11, x10
	add	x11, x11, #16
	ldar	xzr, [x11]
	//APP
	//NO_APP
	ldr	x11, [x9]
	//APP
	//NO_APP
	add	x10, x11, x10
	add	x10, x10, #16
.LBB2_6:                                // =>This Inner Loop Header: Depth=1
	ldaxr	x11, [x10]
	orr	x11, x11, #0x1
	stlxr	w12, x11, [x10]
	cbnz	w12, .LBB2_6
// %bb.7:
	//APP
	//NO_APP
	ldr	x9, [x9]
	//APP
	//NO_APP
	add	x8, x9, x8, lsl #3
	add	x8, x8, #16
	ldar	xzr, [x8]
	//APP
	//NO_APP
.LBB2_8:
	mov	x0, xzr
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB2_9:
	.cfi_restore_state
	adrp	x21, :got:g_bitmap
	mov	w22, #1                         // =0x1
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
	b	.LBB2_11
.LBB2_10:                               //   in Loop: Header=BB2_11 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.hs	.LBB2_8
.LBB2_11:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB2_14 Depth 2
	ldr	x8, [x21]
	//APP
	//NO_APP
	mov	x11, xzr
	mov	x20, xzr
	add	x9, x8, #16
	ldar	x10, [x9]
	//APP
	//NO_APP
	add	x9, x8, #24
	cbz	x10, .LBB2_13
.LBB2_12:                               //   in Loop: Header=BB2_11 Depth=1
	mov	x12, x11
	b	.LBB2_16
.LBB2_13:                               //   in Loop: Header=BB2_11 Depth=1
	ldr	x13, [x8]
.LBB2_14:                               //   Parent Loop BB2_11 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x12, x11, #1
	cmp	x12, x13
	b.hs	.LBB2_10
// %bb.15:                              //   in Loop: Header=BB2_14 Depth=2
	add	x10, x9, x11, lsl #3
	//APP
	//NO_APP
	mov	x11, x12
	ldar	x10, [x10]
	//APP
	//NO_APP
	cbz	x10, .LBB2_14
.LBB2_16:                               //   in Loop: Header=BB2_11 Depth=1
	rbit	x11, x10
	ldr	x14, [x8, #8]
	clz	x11, x11
	orr	x13, x11, x12, lsl #6
	cmp	x13, x14
	b.hs	.LBB2_10
// %bb.17:                              //   in Loop: Header=BB2_11 Depth=1
	lsl	x11, x22, x11
	add	x20, x20, #1
	bic	x10, x10, x11
	mov	x11, x12
	cbnz	x10, .LBB2_12
	b	.LBB2_13
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        // -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          // -- Begin function main
.LCPI3_0:
	.xword	11                              // 0xb
	.xword	704                             // 0x2c0
	.text
	.globl	main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	str	x21, [sp, #112]                 // 8-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	w0, #104                        // =0x68
	bl	malloc
	adrp	x9, .LCPI3_0
	adrp	x20, :got:g_bitmap
	mov	x8, xzr
	ldr	x20, [x20, :got_lo12:g_bitmap]
	ldr	q0, [x9, :lo12:.LCPI3_0]
	str	x0, [x20]
	str	q0, [x0]
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	add	x9, x0, x8, lsl #3
	//APP
	//NO_APP
	add	x8, x8, #1
	add	x9, x9, #16
	stlr	xzr, [x9]
	//APP
	//NO_APP
	ldr	x9, [x0]
	cmp	x8, x9
	b.lo	.LBB3_1
// %bb.2:
	adrp	x19, :got:run
	mov	x0, sp
	mov	x1, xzr
	ldr	x19, [x19, :got_lo12:run]
	mov	x3, xzr
	mov	x21, sp
	mov	x2, x19
	bl	pthread_create
	add	x0, x21, #8
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #1                          // =0x1
	bl	pthread_create
	add	x0, x21, #16
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #2                          // =0x2
	bl	pthread_create
	add	x0, x21, #24
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #3                          // =0x3
	bl	pthread_create
	add	x0, x21, #32
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #4                          // =0x4
	bl	pthread_create
	add	x0, x21, #40
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #5                          // =0x5
	bl	pthread_create
	add	x0, x21, #48
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #6                          // =0x6
	bl	pthread_create
	add	x0, x21, #56
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #7                          // =0x7
	bl	pthread_create
	add	x0, x21, #64
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #8                          // =0x8
	bl	pthread_create
	add	x0, x21, #72
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #9                          // =0x9
	bl	pthread_create
	add	x0, x21, #80
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #10                         // =0xa
	bl	pthread_create
	add	x0, x21, #88
	mov	x1, xzr
	mov	x2, x19
	mov	w3, #11                         // =0xb
	bl	pthread_create
	ldr	x0, [sp]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #16]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #24]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #32]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #40]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #48]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #56]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #64]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #72]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #80]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #88]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [x20]
	bl	free
	mov	w0, wzr
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldr	x21, [sp, #112]                 // 8-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        // -- End function
	.type	g_bitmap,@object                // @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.xword	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
