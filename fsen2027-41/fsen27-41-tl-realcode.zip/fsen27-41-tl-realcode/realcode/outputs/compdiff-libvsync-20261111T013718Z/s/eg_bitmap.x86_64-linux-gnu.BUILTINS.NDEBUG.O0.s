	.file	"eg_bitmap.c"
	.text
	.globl	reader                          # -- Begin function reader
	.p2align	4
	.type	reader,@function
reader:                                 # @reader
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$64, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movq	$0, -16(%rbp)
	leaq	-40(%rbp), %rdi
	xorl	%esi, %esi
	movl	$24, %edx
	callq	memset@PLT
	movq	$0, -48(%rbp)
	movq	$693, -56(%rbp)                 # imm = 0x2B5
.LBB0_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_3 Depth 2
	movq	-48(%rbp), %rax
	cmpq	-56(%rbp), %rax
	jae	.LBB0_6
# %bb.2:                                #   in Loop: Header=BB0_1 Depth=1
	movq	$0, -48(%rbp)
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	leaq	-40(%rbp), %rsi
	callq	vbitmap_iter_init
.LBB0_3:                                #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leaq	-40(%rbp), %rdi
	leaq	-16(%rbp), %rsi
	callq	vbitmap_iter_next
	testb	$1, %al
	jne	.LBB0_4
	jmp	.LBB0_5
.LBB0_4:                                #   in Loop: Header=BB0_3 Depth=2
	movq	-48(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -48(%rbp)
	jmp	.LBB0_3
.LBB0_5:                                #   in Loop: Header=BB0_1 Depth=1
	movq	-48(%rbp), %rsi
	movq	-56(%rbp), %rdx
	leaq	.L.str(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
	jmp	.LBB0_1
.LBB0_6:
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB0_8
# %bb.7:
	addq	$64, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB0_8:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_iter_init
	.type	vbitmap_iter_init,@function
vbitmap_iter_init:                      # @vbitmap_iter_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-16(%rbp), %rax
	movq	$0, 8(%rax)
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	callq	vatomic64_read
	movq	%rax, %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, 16(%rax)
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end1:
	.size	vbitmap_iter_init, .Lfunc_end1-vbitmap_iter_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_iter_next
	.type	vbitmap_iter_next,@function
vbitmap_iter_next:                      # @vbitmap_iter_next
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$64, %rsp
	movq	%rdi, -16(%rbp)
	movq	%rsi, -24(%rbp)
	movq	-16(%rbp), %rax
	movq	(%rax), %rax
	addq	$16, %rax
	movq	%rax, -32(%rbp)
	movq	-16(%rbp), %rax
	movq	(%rax), %rax
	movq	(%rax), %rax
	movq	%rax, -40(%rbp)
	movq	$0, -48(%rbp)
	movq	$0, -56(%rbp)
	movq	$0, -64(%rbp)
	movq	-16(%rbp), %rax
	cmpq	$0, 16(%rax)
	jne	.LBB2_8
# %bb.1:
	movq	-16(%rbp), %rax
	movq	8(%rax), %rax
	addq	$1, %rax
	movq	%rax, -56(%rbp)
.LBB2_2:                                # =>This Inner Loop Header: Depth=1
	movq	-56(%rbp), %rax
	cmpq	-40(%rbp), %rax
	jae	.LBB2_7
# %bb.3:                                #   in Loop: Header=BB2_2 Depth=1
	movq	-32(%rbp), %rdi
	movq	-56(%rbp), %rax
	shlq	$3, %rax
	addq	%rax, %rdi
	callq	vatomic64_read
	movq	%rax, %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, 16(%rax)
	movq	-16(%rbp), %rax
	cmpq	$0, 16(%rax)
	je	.LBB2_5
# %bb.4:
	movq	-56(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, 8(%rax)
	jmp	.LBB2_9
.LBB2_5:                                #   in Loop: Header=BB2_2 Depth=1
	jmp	.LBB2_6
.LBB2_6:                                #   in Loop: Header=BB2_2 Depth=1
	movq	-56(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -56(%rbp)
	jmp	.LBB2_2
.LBB2_7:
	movb	$0, -1(%rbp)
	jmp	.LBB2_12
.LBB2_8:
	jmp	.LBB2_9
.LBB2_9:
	movq	-16(%rbp), %rax
	movq	16(%rax), %rcx
                                        # implicit-def: $rax
	rep		bsfq	%rcx, %rax
                                        # kill: def $eax killed $eax killed $rax
	cltq
	movq	%rax, -48(%rbp)
	movq	-16(%rbp), %rax
	movq	8(%rax), %rax
	shlq	$6, %rax
	addq	-48(%rbp), %rax
	movq	%rax, -64(%rbp)
	movq	-64(%rbp), %rax
	movq	-16(%rbp), %rcx
	movq	(%rcx), %rcx
	cmpq	8(%rcx), %rax
	jb	.LBB2_11
# %bb.10:
	movb	$0, -1(%rbp)
	jmp	.LBB2_12
.LBB2_11:
	movq	-64(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-48(%rbp), %rcx
	andq	$63, %rcx
	movl	$1, %eax
                                        # kill: def $cl killed $rcx
	shlq	%cl, %rax
	movq	%rax, %rcx
	xorq	$-1, %rcx
	movq	-16(%rbp), %rax
	andq	16(%rax), %rcx
	movq	%rcx, 16(%rax)
	movb	$1, -1(%rbp)
.LBB2_12:
	movb	-1(%rbp), %al
	andb	$1, %al
	addq	$64, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end2:
	.size	vbitmap_iter_next, .Lfunc_end2-vbitmap_iter_next
	.cfi_endproc
                                        # -- End function
	.globl	writer                          # -- Begin function writer
	.p2align	4
	.type	writer,@function
writer:                                 # @writer
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movb	$0, -9(%rbp)
	movq	-8(%rbp), %rax
	shlq	$6, %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	addq	$64, %rax
	subq	$1, %rax
	movq	%rax, -32(%rbp)
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	-24(%rbp), %rsi
	movq	-32(%rbp), %rdx
	callq	vbitmap_set_range
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	-24(%rbp), %rsi
	callq	vbitmap_get
	andb	$1, %al
	movb	%al, -9(%rbp)
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	-24(%rbp), %rsi
	callq	vbitmap_clr_bit
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	-24(%rbp), %rsi
	callq	vbitmap_get
	andb	$1, %al
	movb	%al, -9(%rbp)
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	-24(%rbp), %rsi
	callq	vbitmap_set_bit
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	-24(%rbp), %rsi
	callq	vbitmap_get
	andb	$1, %al
	movb	%al, -9(%rbp)
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	writer, .Lfunc_end3-writer
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_set_range
	.type	vbitmap_set_range,@function
vbitmap_set_range:                      # @vbitmap_set_range
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$80, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	$0, -32(%rbp)
	movq	$0, -40(%rbp)
	movq	$0, -48(%rbp)
	movq	$0, -56(%rbp)
	movq	$0, -64(%rbp)
	movq	-16(%rbp), %rax
	shrq	$6, %rax
	movq	%rax, -32(%rbp)
	movq	-24(%rbp), %rax
	shrq	$6, %rax
	movq	%rax, -40(%rbp)
	movq	-16(%rbp), %rax
	andq	$63, %rax
	movq	%rax, -48(%rbp)
	movq	-24(%rbp), %rax
	andq	$63, %rax
	movq	%rax, -56(%rbp)
	movq	-32(%rbp), %rax
	cmpq	-40(%rbp), %rax
	jne	.LBB4_2
# %bb.1:
	movq	-48(%rbp), %rdi
	movq	-56(%rbp), %rsi
	callq	_vbitmap_range_mask
	movq	%rax, -64(%rbp)
	movq	-8(%rbp), %rdi
	movq	-32(%rbp), %rsi
	movq	-64(%rbp), %rdx
	callq	_vbitbmap_set_slot
	jmp	.LBB4_7
.LBB4_2:
	movq	-48(%rbp), %rdi
	callq	_vbitmap_lsb_mask
	movq	%rax, -64(%rbp)
	movq	-8(%rbp), %rdi
	movq	-32(%rbp), %rsi
	movq	-64(%rbp), %rdx
	callq	_vbitbmap_set_slot
	movq	-32(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -72(%rbp)
.LBB4_3:                                # =>This Inner Loop Header: Depth=1
	movq	-72(%rbp), %rax
	cmpq	-40(%rbp), %rax
	jae	.LBB4_6
# %bb.4:                                #   in Loop: Header=BB4_3 Depth=1
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	movq	-72(%rbp), %rax
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	$-1, %rsi
	callq	vatomic64_write
# %bb.5:                                #   in Loop: Header=BB4_3 Depth=1
	movq	-72(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -72(%rbp)
	jmp	.LBB4_3
.LBB4_6:
	movq	-56(%rbp), %rdi
	callq	_vbitmap_msb_mask
	movq	%rax, -64(%rbp)
	movq	-8(%rbp), %rdi
	movq	-40(%rbp), %rsi
	movq	-64(%rbp), %rdx
	callq	_vbitbmap_set_slot
.LBB4_7:
	addq	$80, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end4:
	.size	vbitmap_set_range, .Lfunc_end4-vbitmap_set_range
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_get
	.type	vbitmap_get,@function
vbitmap_get:                            # @vbitmap_get
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	shrq	$6, %rax
	movq	%rax, -24(%rbp)
	movq	-16(%rbp), %rcx
	andq	$63, %rcx
	movl	$1, %eax
                                        # kill: def $cl killed $rcx
	shlq	%cl, %rax
	movq	%rax, -32(%rbp)
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	movq	-24(%rbp), %rax
	shlq	$3, %rax
	addq	%rax, %rdi
	callq	vatomic64_read
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	andq	-32(%rbp), %rax
	cmpq	-32(%rbp), %rax
	sete	%al
	andb	$1, %al
	movb	%al, -41(%rbp)
	movb	-41(%rbp), %al
	andb	$1, %al
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end5:
	.size	vbitmap_get, .Lfunc_end5-vbitmap_get
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_clr_bit
	.type	vbitmap_clr_bit,@function
vbitmap_clr_bit:                        # @vbitmap_clr_bit
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	shrq	$6, %rax
	movq	%rax, -24(%rbp)
	movq	-16(%rbp), %rcx
	andq	$63, %rcx
	movl	$1, %eax
                                        # kill: def $cl killed $rcx
	shlq	%cl, %rax
	movq	%rax, -32(%rbp)
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	movq	-24(%rbp), %rax
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	-32(%rbp), %rsi
	xorq	$-1, %rsi
	callq	vatomic64_and_get
	movq	%rax, -40(%rbp)
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end6:
	.size	vbitmap_clr_bit, .Lfunc_end6-vbitmap_clr_bit
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_set_bit
	.type	vbitmap_set_bit,@function
vbitmap_set_bit:                        # @vbitmap_set_bit
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	shrq	$6, %rax
	movq	%rax, -24(%rbp)
	movq	-16(%rbp), %rcx
	andq	$63, %rcx
	movl	$1, %eax
                                        # kill: def $cl killed $rcx
	shlq	%cl, %rax
	movq	%rax, -32(%rbp)
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	movq	-24(%rbp), %rax
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	-32(%rbp), %rsi
	callq	vatomic64_or_get
	movq	%rax, -40(%rbp)
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end7:
	.size	vbitmap_set_bit, .Lfunc_end7-vbitmap_set_bit
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, -16(%rbp)
	cmpq	$11, -16(%rbp)
	jne	.LBB8_2
# %bb.1:
	callq	reader@PLT
	jmp	.LBB8_3
.LBB8_2:
	movq	-16(%rbp), %rdi
	callq	writer@PLT
.LBB8_3:
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end8:
	.size	run, .Lfunc_end8-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$144, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movl	$0, -116(%rbp)
	movl	$704, %edi                      # imm = 0x2C0
	callq	vbitmap_size
	movq	%rax, -128(%rbp)
	movq	-128(%rbp), %rdi
	callq	malloc@PLT
	movq	%rax, %rcx
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	%rcx, (%rax)
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movl	$704, %esi                      # imm = 0x2C0
	xorl	%edx, %edx
	callq	vbitmap_init
	movq	$0, -136(%rbp)
.LBB9_1:                                # =>This Inner Loop Header: Depth=1
	cmpq	$12, -136(%rbp)
	jae	.LBB9_4
# %bb.2:                                #   in Loop: Header=BB9_1 Depth=1
	movq	-136(%rbp), %rax
	leaq	-112(%rbp), %rdi
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	-136(%rbp), %rcx
	xorl	%eax, %eax
	movl	%eax, %esi
	movq	run@GOTPCREL(%rip), %rdx
	callq	pthread_create@PLT
# %bb.3:                                #   in Loop: Header=BB9_1 Depth=1
	movq	-136(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -136(%rbp)
	jmp	.LBB9_1
.LBB9_4:
	movq	$0, -144(%rbp)
.LBB9_5:                                # =>This Inner Loop Header: Depth=1
	cmpq	$12, -144(%rbp)
	jae	.LBB9_8
# %bb.6:                                #   in Loop: Header=BB9_5 Depth=1
	movq	-144(%rbp), %rax
	movq	-112(%rbp,%rax,8), %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	pthread_join@PLT
# %bb.7:                                #   in Loop: Header=BB9_5 Depth=1
	movq	-144(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -144(%rbp)
	jmp	.LBB9_5
.LBB9_8:
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	callq	free@PLT
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB9_10
# %bb.9:
	xorl	%eax, %eax
	addq	$144, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB9_10:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end9:
	.size	main, .Lfunc_end9-main
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_size
	.type	vbitmap_size,@function
vbitmap_size:                           # @vbitmap_size
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	andq	$63, %rax
	cmpq	$0, %rax
	jne	.LBB10_2
# %bb.1:
	movq	-8(%rbp), %rax
	shrq	$6, %rax
	movq	%rax, -24(%rbp)                 # 8-byte Spill
	jmp	.LBB10_3
.LBB10_2:
	movq	-8(%rbp), %rax
	shrq	$6, %rax
	addq	$1, %rax
	movq	%rax, -24(%rbp)                 # 8-byte Spill
.LBB10_3:
	movq	-24(%rbp), %rax                 # 8-byte Reload
	shlq	$3, %rax
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rax
	addq	$16, %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end10:
	.size	vbitmap_size, .Lfunc_end10-vbitmap_size
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vbitmap_init
	.type	vbitmap_init,@function
vbitmap_init:                           # @vbitmap_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movb	%dl, %al
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	andb	$1, %al
	movb	%al, -17(%rbp)
	movb	-17(%rbp), %dl
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
	movq	$-1, %rcx
	testb	$1, %dl
	cmovneq	%rcx, %rax
	movq	%rax, -32(%rbp)
	movq	-16(%rbp), %rcx
	movq	-8(%rbp), %rax
	movq	%rcx, 8(%rax)
	movq	-16(%rbp), %rax
	andq	$63, %rax
	cmpq	$0, %rax
	jne	.LBB11_2
# %bb.1:
	movq	-16(%rbp), %rax
	shrq	$6, %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	jmp	.LBB11_3
.LBB11_2:
	movq	-16(%rbp), %rax
	shrq	$6, %rax
	addq	$1, %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
.LBB11_3:
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	movq	-8(%rbp), %rax
	movq	%rcx, (%rax)
	movq	$0, -40(%rbp)
.LBB11_4:                               # =>This Inner Loop Header: Depth=1
	movq	-40(%rbp), %rax
	movq	-8(%rbp), %rcx
	cmpq	(%rcx), %rax
	jae	.LBB11_7
# %bb.5:                                #   in Loop: Header=BB11_4 Depth=1
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	movq	-40(%rbp), %rax
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	-32(%rbp), %rsi
	callq	vatomic64_init
# %bb.6:                                #   in Loop: Header=BB11_4 Depth=1
	movq	-40(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -40(%rbp)
	jmp	.LBB11_4
.LBB11_7:
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end11:
	.size	vbitmap_init, .Lfunc_end11-vbitmap_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_read
	.type	vatomic64_read,@function
vatomic64_read:                         # @vatomic64_read
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, -16(%rbp)
	#APP
	#NO_APP
	movq	-16(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end12:
	.size	vatomic64_read, .Lfunc_end12-vatomic64_read
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function _vbitmap_range_mask
	.type	_vbitmap_range_mask,@function
_vbitmap_range_mask:                    # @_vbitmap_range_mask
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	callq	_vbitmap_lsb_mask
	movq	%rax, -24(%rbp)
	movq	-16(%rbp), %rdi
	callq	_vbitmap_msb_mask
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rax
	andq	-24(%rbp), %rax
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end13:
	.size	_vbitmap_range_mask, .Lfunc_end13-_vbitmap_range_mask
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function _vbitbmap_set_slot
	.type	_vbitbmap_set_slot,@function
_vbitbmap_set_slot:                     # @_vbitbmap_set_slot
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	movq	-16(%rbp), %rax
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	-24(%rbp), %rsi
	callq	vatomic64_or
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end14:
	.size	_vbitbmap_set_slot, .Lfunc_end14-_vbitbmap_set_slot
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function _vbitmap_lsb_mask
	.type	_vbitmap_lsb_mask,@function
_vbitmap_lsb_mask:                      # @_vbitmap_lsb_mask
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	$1, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rcx
                                        # kill: def $cl killed $rcx
	shlq	%cl, %rax
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rax
	addq	$-1, %rax
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rax
	xorq	$-1, %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end15:
	.size	_vbitmap_lsb_mask, .Lfunc_end15-_vbitmap_lsb_mask
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_write
	.type	vatomic64_write,@function
vatomic64_write:                        # @vatomic64_write
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	xchgq	%rax, (%rcx)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end16:
	.size	vatomic64_write, .Lfunc_end16-vatomic64_write
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function _vbitmap_msb_mask
	.type	_vbitmap_msb_mask,@function
_vbitmap_msb_mask:                      # @_vbitmap_msb_mask
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	$1, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rcx
                                        # kill: def $cl killed $rcx
	shlq	%cl, %rax
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	-16(%rbp), %rcx
	subq	$1, %rcx
	addq	%rcx, %rax
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end17:
	.size	_vbitmap_msb_mask, .Lfunc_end17-_vbitmap_msb_mask
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_or
	.type	vatomic64_or,@function
vatomic64_or:                           # @vatomic64_or
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	movq	-16(%rbp), %rsi
	callq	vatomic64_get_or
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end18:
	.size	vatomic64_or, .Lfunc_end18-vatomic64_or
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_get_or
	.type	vatomic64_get_or,@function
vatomic64_get_or:                       # @vatomic64_get_or
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	movq	-16(%rbp), %rcx
	movq	%rcx, -32(%rbp)
	movq	-32(%rbp), %rcx
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
.LBB19_1:                               # =>This Inner Loop Header: Depth=1
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	-56(%rbp), %rsi                 # 8-byte Reload
	movq	%rax, %rdx
	orq	%rsi, %rdx
	lock		cmpxchgq	%rdx, (%rcx)
	sete	%cl
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	testb	$1, %cl
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	jne	.LBB19_2
	jmp	.LBB19_1
.LBB19_2:
	movq	-72(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -24(%rbp)
	#APP
	#NO_APP
	movq	-24(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end19:
	.size	vatomic64_get_or, .Lfunc_end19-vatomic64_get_or
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_and_get
	.type	vatomic64_and_get,@function
vatomic64_and_get:                      # @vatomic64_and_get
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	movq	-16(%rbp), %rsi
	callq	vatomic64_get_and
	andq	-16(%rbp), %rax
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end20:
	.size	vatomic64_and_get, .Lfunc_end20-vatomic64_and_get
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_get_and
	.type	vatomic64_get_and,@function
vatomic64_get_and:                      # @vatomic64_get_and
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	movq	-16(%rbp), %rcx
	movq	%rcx, -32(%rbp)
	movq	-32(%rbp), %rcx
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movq	(%rax), %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
.LBB21_1:                               # =>This Inner Loop Header: Depth=1
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	-56(%rbp), %rsi                 # 8-byte Reload
	movq	%rax, %rdx
	andq	%rsi, %rdx
	lock		cmpxchgq	%rdx, (%rcx)
	sete	%cl
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	testb	$1, %cl
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	jne	.LBB21_2
	jmp	.LBB21_1
.LBB21_2:
	movq	-72(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -24(%rbp)
	#APP
	#NO_APP
	movq	-24(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end21:
	.size	vatomic64_get_and, .Lfunc_end21-vatomic64_get_and
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_or_get
	.type	vatomic64_or_get,@function
vatomic64_or_get:                       # @vatomic64_or_get
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	movq	-16(%rbp), %rsi
	callq	vatomic64_get_or
	orq	-16(%rbp), %rax
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end22:
	.size	vatomic64_or_get, .Lfunc_end22-vatomic64_or_get
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_init
	.type	vatomic64_init,@function
vatomic64_init:                         # @vatomic64_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	movq	-16(%rbp), %rsi
	callq	vatomic64_write
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end23:
	.size	vatomic64_init, .Lfunc_end23-vatomic64_init
	.cfi_endproc
                                        # -- End function
	.type	g_bitmap,@object                # @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.quad	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym reader
	.addrsig_sym vbitmap_iter_init
	.addrsig_sym vbitmap_iter_next
	.addrsig_sym printf
	.addrsig_sym writer
	.addrsig_sym vbitmap_set_range
	.addrsig_sym vbitmap_get
	.addrsig_sym vbitmap_clr_bit
	.addrsig_sym vbitmap_set_bit
	.addrsig_sym run
	.addrsig_sym vbitmap_size
	.addrsig_sym malloc
	.addrsig_sym vbitmap_init
	.addrsig_sym pthread_create
	.addrsig_sym pthread_join
	.addrsig_sym free
	.addrsig_sym vatomic64_read
	.addrsig_sym _vbitmap_range_mask
	.addrsig_sym _vbitbmap_set_slot
	.addrsig_sym _vbitmap_lsb_mask
	.addrsig_sym vatomic64_write
	.addrsig_sym _vbitmap_msb_mask
	.addrsig_sym vatomic64_or
	.addrsig_sym vatomic64_get_or
	.addrsig_sym vatomic64_and_get
	.addrsig_sym vatomic64_get_and
	.addrsig_sym vatomic64_or_get
	.addrsig_sym vatomic64_init
	.addrsig_sym __stack_chk_fail
	.addrsig_sym g_bitmap
