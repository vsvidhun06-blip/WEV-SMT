	.file	"eg_vebr.c"
	.text
	.p2align	2                               // -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               // @lock_acq
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_lock
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               // @lock_rel
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_unlock
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        // -- End function
	.globl	free_cb                         // -- Begin function free_cb
	.p2align	2
	.type	free_cb,@function
free_cb:                                // @free_cb
	.cfi_startproc
// %bb.0:
	sub	x0, x0, #16
	b	free
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	adrp	x8, :got:g_vebr
	mov	x10, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	ldr	x8, [x8, :got_lo12:g_vebr]
	//APP
	dmb	ish
	//NO_APP
	movk	x10, #43691
	//APP
	ldar	x9, [x8]
	//NO_APP
	umulh	x10, x9, x10
	lsr	x10, x10, #1
	add	x10, x10, x10, lsl #1
	sub	x9, x9, x10
	adrp	x10, :got:free_cb
	ldr	x10, [x10, :got_lo12:free_cb]
	add	x8, x8, x9, lsl #4
	str	xzr, [x0, #16]!
	stp	x10, xzr, [x0, #16]
	add	x8, x8, #8
	//APP
	ldar	x9, [x8]
	//NO_APP
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	str	x9, [x0]
	//APP
	prfm	pstl1strm, [x8]
.Ltmp0:
	ldxr	x10, [x8]
	cmp	x10, x9
	b.ne	.Ltmp1
	stlxr	w11, x0, [x8]
	cbnz	w11, .Ltmp0
.Ltmp1:

	//NO_APP
	cmp	x9, x10
	mov	x9, x10
	b.ne	.LBB3_1
// %bb.2:
	mov	w9, #1                          // =0x1
	add	x8, x8, #8
	//APP
	prfm	pstl1strm, [x8]
.Ltmp2:
	ldxr	x10, [x8]
	add	x11, x10, x9
	stxr	w12, x11, [x8]
	cbnz	w12, .Ltmp2

	//NO_APP
	ret
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	b	free
.Lfunc_end4:
	.size	destroy_cb, .Lfunc_end4-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	reclaim                         // -- Begin function reclaim
	.p2align	2
	.type	reclaim,@function
reclaim:                                // @reclaim
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-80]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	str	x25, [sp, #16]                  // 8-byte Folded Spill
	stp	x24, x23, [sp, #32]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -64
	.cfi_offset w30, -72
	.cfi_offset w29, -80
	.cfi_remember_state
	adrp	x20, :got:g_stop
	ldr	x20, [x20, :got_lo12:g_stop]
	//APP
	//NO_APP
	ldarb	w8, [x20]
	//APP
	//NO_APP
	cbz	w8, .LBB5_2
.LBB5_1:
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldr	x25, [sp, #16]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #80             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB5_2:
	.cfi_restore_state
	adrp	x22, :got:g_vebr
	mov	x23, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	mov	x21, xzr
	ldr	x22, [x22, :got_lo12:g_vebr]
	movk	x23, #43691
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	b	.LBB5_4
.LBB5_3:                                //   in Loop: Header=BB5_4 Depth=1
	//APP
	//NO_APP
	ldarb	w8, [x20]
	//APP
	//NO_APP
	cbnz	w8, .LBB5_1
.LBB5_4:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_5 Depth 2
                                        //     Child Loop BB5_9 Depth 2
	//APP
	dmb	ish
	//NO_APP
	//APP
	ldar	x24, [x22]
	//NO_APP
	add	x8, x24, #2
	umulh	x9, x8, x23
	lsr	x9, x9, #1
	add	x9, x9, x9, lsl #1
	sub	x8, x8, x9
	add	x8, x22, x8, lsl #4
	add	x9, x8, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp3:
	ldaxr	x25, [x9]
	stxr	w10, x21, [x9]
	cbnz	w10, .Ltmp3

	//NO_APP
	add	x8, x8, #16
	//APP
	str	x21, [x8]
	//NO_APP
	ldr	x8, [x22, #72]
	ldr	x0, [x22, #88]
	blr	x8
	ldr	x8, [x22, #56]
	cbz	x8, .LBB5_7
.LBB5_5:                                //   Parent Loop BB5_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x8, #16
	//APP
	ldar	x10, [x9]
	//NO_APP
	cmp	x10, #0
	ccmp	x10, x24, #2, ne
	b.lo	.LBB5_5
// %bb.6:                               //   in Loop: Header=BB5_5 Depth=2
	ldr	x8, [x8]
	cbnz	x8, .LBB5_5
.LBB5_7:                                //   in Loop: Header=BB5_4 Depth=1
	ldp	x8, x0, [x22, #80]
	blr	x8
	add	x8, x24, #1
	//APP
	prfm	pstl1strm, [x22]
.Ltmp4:
	ldaxr	x9, [x22]
	cmp	x9, x24
	b.ne	.Ltmp5
	stlxr	w10, x8, [x22]
	cbnz	w10, .Ltmp4
.Ltmp5:

	//NO_APP
	cbz	x25, .LBB5_3
// %bb.8:                               //   in Loop: Header=BB5_4 Depth=1
	mov	x0, x25
	mov	x24, xzr
.LBB5_9:                                //   Parent Loop BB5_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldp	x8, x1, [x0, #16]
	ldr	x25, [x0]
	blr	x8
	sub	x24, x24, #1
	mov	x0, x25
	cbnz	x25, .LBB5_9
// %bb.10:                              //   in Loop: Header=BB5_4 Depth=1
	cbz	x24, .LBB5_3
// %bb.11:                              //   in Loop: Header=BB5_4 Depth=1
	sub	x1, x21, x24
	mov	x0, x19
	bl	printf
	b	.LBB5_3
.Lfunc_end5:
	.size	reclaim, .Lfunc_end5-reclaim
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
	cbz	x0, .LBB6_30
// %bb.1:
	adrp	x25, :got:g_vebr
	mov	x26, sp
	mov	x8, xzr
	ldr	x25, [x25, :got_lo12:g_vebr]
	add	x9, x26, #16
	//APP
	stlr	x8, [x9]
	//NO_APP
	mov	x19, x0
	str	wzr, [sp, #24]
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldr	x8, [x25, #56]
	str	x8, [sp]
	cbz	x8, .LBB6_3
// %bb.2:
	str	x26, [x8, #8]
.LBB6_3:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	mov	x27, xzr
	str	xzr, [sp, #8]
	add	x8, x8, #1
	stp	x26, x8, [x25, #56]
	blr	x9
	adrp	x28, :got:g_queue
	adrp	x20, .L.str.1
	add	x20, x20, :lo12:.L.str.1
	ldr	x28, [x28, :got_lo12:g_queue]
	ldr	w8, [sp, #24]
	mov	w21, #10000                     // =0x2710
	mov	x22, xzr
	b	.LBB6_5
.LBB6_4:                                //   in Loop: Header=BB6_5 Depth=1
	add	x22, x22, #1
	sub	w8, w8, #1
	cmp	x22, x21
	str	w8, [sp, #24]
	b.eq	.LBB6_26
.LBB6_5:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB6_8 Depth 2
                                        //     Child Loop BB6_14 Depth 2
                                        //     Child Loop BB6_20 Depth 2
	add	w9, w8, #1
	str	w9, [sp, #24]
	cbnz	w8, .LBB6_8
// %bb.6:                               //   in Loop: Header=BB6_5 Depth=1
	//APP
	ldar	x8, [x25]
	//NO_APP
	add	x9, x26, #16
	//APP
	stlr	x8, [x9]
	//NO_APP
	//APP
	dmb	ish
	//NO_APP
	b	.LBB6_8
.LBB6_7:                                //   in Loop: Header=BB6_8 Depth=2
	ldr	x23, [x9]
	//APP
	prfm	pstl1strm, [x28]
.Ltmp6:
	ldaxr	x10, [x28]
	cmp	x10, x8
	b.ne	.Ltmp7
	stlxr	w11, x9, [x28]
	cbnz	w11, .Ltmp6
.Ltmp7:

	//NO_APP
	cmp	x10, x8
	b.eq	.LBB6_12
.LBB6_8:                                //   Parent Loop BB6_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	//APP
	ldar	x8, [x28]
	//NO_APP
	add	x9, x28, #8
	add	x11, x8, #8
	//APP
	ldar	x10, [x9]
	//NO_APP
	//APP
	ldar	x9, [x11]
	//NO_APP
	//APP
	ldar	x11, [x28]
	//NO_APP
	cmp	x8, x11
	b.ne	.LBB6_8
// %bb.9:                               //   in Loop: Header=BB6_8 Depth=2
	cmp	x8, x10
	b.ne	.LBB6_7
// %bb.10:                              //   in Loop: Header=BB6_8 Depth=2
	cbz	x9, .LBB6_18
// %bb.11:                              //   in Loop: Header=BB6_8 Depth=2
	add	x8, x28, #8
	//APP
	prfm	pstl1strm, [x8]
.Ltmp8:
	ldaxr	x11, [x8]
	cmp	x11, x10
	b.ne	.Ltmp9
	stlxr	w12, x9, [x8]
	cbnz	w12, .Ltmp8
.Ltmp9:

	//NO_APP
	b	.LBB6_8
.LBB6_12:                               //   in Loop: Header=BB6_5 Depth=1
	add	x9, x28, #16
	cmp	x8, x9
	b.eq	.LBB6_16
// %bb.13:                              //   in Loop: Header=BB6_5 Depth=1
	mov	x10, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	//APP
	dmb	ish
	//NO_APP
	movk	x10, #43691
	//APP
	ldar	x9, [x25]
	//NO_APP
	umulh	x10, x9, x10
	str	xzr, [x8, #16]!
	lsr	x10, x10, #1
	add	x10, x10, x10, lsl #1
	sub	x9, x9, x10
	adrp	x10, :got:free_cb
	ldr	x10, [x10, :got_lo12:free_cb]
	add	x9, x25, x9, lsl #4
	stp	x10, xzr, [x8, #16]
	add	x9, x9, #8
	//APP
	ldar	x10, [x9]
	//NO_APP
.LBB6_14:                               //   Parent Loop BB6_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	str	x10, [x8]
	//APP
	prfm	pstl1strm, [x9]
.Ltmp10:
	ldxr	x11, [x9]
	cmp	x11, x10
	b.ne	.Ltmp11
	stlxr	w12, x8, [x9]
	cbnz	w12, .Ltmp10
.Ltmp11:

	//NO_APP
	cmp	x10, x11
	mov	x10, x11
	b.ne	.LBB6_14
// %bb.15:                              //   in Loop: Header=BB6_5 Depth=1
	add	x8, x9, #8
	mov	w9, #1                          // =0x1
	//APP
	prfm	pstl1strm, [x8]
.Ltmp12:
	ldxr	x10, [x8]
	add	x11, x10, x9
	stxr	w12, x11, [x8]
	cbnz	w12, .Ltmp12

	//NO_APP
.LBB6_16:                               //   in Loop: Header=BB6_5 Depth=1
	cbz	x23, .LBB6_18
// %bb.17:                              //   in Loop: Header=BB6_5 Depth=1
	ldr	x2, [x23]
	adrp	x0, .L.str.2
	add	x0, x0, :lo12:.L.str.2
	mov	x1, x19
	bl	printf
	mov	x0, x23
	bl	free
	b	.LBB6_24
.LBB6_18:                               //   in Loop: Header=BB6_5 Depth=1
	mov	w0, #8                          // =0x8
	bl	malloc
	mov	x24, x0
	str	x22, [x0]
	mov	w0, #48                         // =0x30
	bl	malloc
	mov	x23, x0
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	printf
	mov	x8, x23
	str	x24, [x8], #8
	//APP
	str	x27, [x8]
	//NO_APP
	b	.LBB6_20
.LBB6_19:                               //   in Loop: Header=BB6_20 Depth=2
	add	x10, x28, #8
	//APP
	prfm	pstl1strm, [x10]
.Ltmp13:
	ldaxr	x11, [x10]
	cmp	x11, x8
	b.ne	.Ltmp14
	stlxr	w12, x9, [x10]
	cbnz	w12, .Ltmp13
.Ltmp14:

	//NO_APP
.LBB6_20:                               //   Parent Loop BB6_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x10, x28, #8
	//APP
	ldar	x8, [x10]
	//NO_APP
	add	x11, x8, #8
	//APP
	ldar	x9, [x11]
	//NO_APP
	//APP
	ldar	x11, [x10]
	//NO_APP
	cmp	x8, x11
	b.ne	.LBB6_20
// %bb.21:                              //   in Loop: Header=BB6_20 Depth=2
	cbnz	x9, .LBB6_19
// %bb.22:                              //   in Loop: Header=BB6_20 Depth=2
	add	x9, x8, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp15:
	ldaxr	x10, [x9]
	cmp	x10, x27
	b.ne	.Ltmp16
	stlxr	w11, x23, [x9]
	cbnz	w11, .Ltmp15
.Ltmp16:

	//NO_APP
	cbnz	x10, .LBB6_20
// %bb.23:                              //   in Loop: Header=BB6_5 Depth=1
	add	x9, x28, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp17:
	ldaxr	x10, [x9]
	cmp	x10, x8
	b.ne	.Ltmp18
	stlxr	w11, x23, [x9]
	cbnz	w11, .Ltmp17
.Ltmp18:

	//NO_APP
.LBB6_24:                               //   in Loop: Header=BB6_5 Depth=1
	ldr	w8, [sp, #24]
	cmp	w8, #1
	b.ne	.LBB6_4
// %bb.25:                              //   in Loop: Header=BB6_5 Depth=1
	add	x8, x26, #16
	//APP
	stlr	x27, [x8]
	//NO_APP
	ldr	w8, [sp, #24]
	b	.LBB6_4
.LBB6_26:
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldp	x9, x8, [sp]
	cbz	x8, .LBB6_32
// %bb.27:
	str	x9, [x8]
	cbz	x9, .LBB6_29
.LBB6_28:
	str	x8, [x9, #8]
.LBB6_29:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	sub	x8, x8, #1
	str	x8, [x25, #64]
	blr	x9
	b	.LBB6_31
.LBB6_30:
	bl	reclaim
.LBB6_31:
	mov	x0, xzr
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_32:
	.cfi_restore_state
	str	x9, [x25, #56]
	cbnz	x9, .LBB6_28
	b	.LBB6_29
.Lfunc_end6:
	.size	run, .Lfunc_end6-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #176
	.cfi_def_cfa_offset 176
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	str	x25, [sp, #112]                 // 8-byte Folded Spill
	stp	x24, x23, [sp, #128]            // 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -64
	.cfi_offset w30, -72
	.cfi_offset w29, -80
	adrp	x0, :got:g_lock
	mov	x1, xzr
	mov	x19, xzr
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_init
	adrp	x8, :got:g_lock_lib
	adrp	x21, :got:g_vebr
	mov	w24, #1                         // =0x1
	ldr	x8, [x8, :got_lo12:g_lock_lib]
	ldr	x21, [x21, :got_lo12:g_vebr]
	adrp	x22, :got:g_queue
	adrp	x20, :got:run
	mov	x0, sp
	mov	x1, xzr
	ldr	q0, [x8]
	ldr	x8, [x8, #16]
	stp	xzr, xzr, [x21, #56]
	add	x9, x21, #8
	mov	x3, xzr
	mov	x25, sp
	str	q0, [sp]
	str	x8, [sp, #16]
	add	x8, x21, #16
	//APP
	stlr	x19, [x9]
	//NO_APP
	add	x9, x21, #24
	//APP
	stlr	x19, [x8]
	//NO_APP
	add	x8, x21, #32
	//APP
	stlr	x19, [x9]
	//NO_APP
	add	x9, x21, #40
	//APP
	stlr	x19, [x8]
	//NO_APP
	add	x8, x21, #48
	//APP
	stlr	x19, [x9]
	//NO_APP
	//APP
	stlr	x19, [x8]
	//NO_APP
	//APP
	stlr	x24, [x21]
	//NO_APP
	ldr	q0, [sp]
	ldr	x22, [x22, :got_lo12:g_queue]
	ldr	x8, [sp, #16]
	mov	x9, x22
	stur	q0, [x21, #72]
	add	x23, x22, #8
	str	x8, [x21, #88]
	add	x8, x22, #24
	str	xzr, [x9, #16]!
	//APP
	str	x19, [x8]
	//NO_APP
	//APP
	str	x9, [x22]
	//NO_APP
	//APP
	str	x9, [x23]
	//NO_APP
	ldr	x20, [x20, :got_lo12:run]
	mov	x2, x20
	bl	pthread_create
	add	x0, x25, #8
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #1                          // =0x1
	bl	pthread_create
	add	x0, x25, #16
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #2                          // =0x2
	bl	pthread_create
	add	x0, x25, #24
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #3                          // =0x3
	bl	pthread_create
	add	x0, x25, #32
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #4                          // =0x4
	bl	pthread_create
	add	x0, x25, #40
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #5                          // =0x5
	bl	pthread_create
	add	x0, x25, #48
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #6                          // =0x6
	bl	pthread_create
	add	x0, x25, #56
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #7                          // =0x7
	bl	pthread_create
	add	x0, x25, #64
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #8                          // =0x8
	bl	pthread_create
	add	x0, x25, #72
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #9                          // =0x9
	bl	pthread_create
	add	x0, x25, #80
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #10                         // =0xa
	bl	pthread_create
	add	x0, x25, #88
	mov	x1, xzr
	mov	x2, x20
	mov	w3, #11                         // =0xb
	bl	pthread_create
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #16]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #24]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #32]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #40]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #48]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #56]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #64]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #72]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #80]
	mov	x1, xzr
	bl	pthread_join
	ldr	x0, [sp, #88]
	mov	x1, xzr
	bl	pthread_join
	adrp	x8, :got:g_stop
	mov	x1, xzr
	ldr	x8, [x8, :got_lo12:g_stop]
	//APP
	//NO_APP
	stlrb	w24, [x8]
	//APP
	//NO_APP
	ldr	x0, [sp]
	bl	pthread_join
.LBB7_1:                                // =>This Inner Loop Header: Depth=1
	//APP
	ldar	x0, [x22]
	//NO_APP
	add	x10, x0, #8
	//APP
	ldar	x9, [x23]
	//NO_APP
	//APP
	ldar	x8, [x10]
	//NO_APP
	//APP
	ldar	x10, [x22]
	//NO_APP
	cmp	x0, x10
	b.ne	.LBB7_1
// %bb.2:                               //   in Loop: Header=BB7_1 Depth=1
	cmp	x0, x9
	b.eq	.LBB7_8
// %bb.3:                               //   in Loop: Header=BB7_1 Depth=1
	ldr	x19, [x8]
	//APP
	prfm	pstl1strm, [x22]
.Ltmp19:
	ldaxr	x9, [x22]
	cmp	x9, x0
	b.ne	.Ltmp20
	stlxr	w10, x8, [x22]
	cbnz	w10, .Ltmp19
.Ltmp20:

	//NO_APP
	cmp	x9, x0
	b.ne	.LBB7_1
// %bb.4:                               //   in Loop: Header=BB7_1 Depth=1
	add	x8, x22, #16
	cmp	x0, x8
	b.eq	.LBB7_6
// %bb.5:                               //   in Loop: Header=BB7_1 Depth=1
	bl	free
.LBB7_6:                                //   in Loop: Header=BB7_1 Depth=1
	cbz	x19, .LBB7_10
// %bb.7:                               //   in Loop: Header=BB7_1 Depth=1
	mov	x0, x19
	bl	free
	b	.LBB7_1
.LBB7_8:                                //   in Loop: Header=BB7_1 Depth=1
	cbz	x8, .LBB7_10
// %bb.9:                               //   in Loop: Header=BB7_1 Depth=1
	add	x10, x22, #8
	//APP
	prfm	pstl1strm, [x10]
.Ltmp21:
	ldaxr	x11, [x10]
	cmp	x11, x9
	b.ne	.Ltmp22
	stlxr	w12, x8, [x10]
	cbnz	w12, .Ltmp21
.Ltmp22:

	//NO_APP
	b	.LBB7_1
.LBB7_10:
	adrp	x8, :got:g_queue
	ldr	x8, [x8, :got_lo12:g_queue]
	//APP
	ldar	x0, [x8]
	//NO_APP
	cbz	x0, .LBB7_15
// %bb.11:
	add	x19, x8, #16
	b	.LBB7_13
.LBB7_12:                               //   in Loop: Header=BB7_13 Depth=1
	mov	x0, x20
	cbz	x20, .LBB7_15
.LBB7_13:                               // =>This Inner Loop Header: Depth=1
	add	x8, x0, #8
	//APP
	ldar	x20, [x8]
	//NO_APP
	cmp	x0, x19
	b.eq	.LBB7_12
// %bb.14:                              //   in Loop: Header=BB7_13 Depth=1
	bl	free
	b	.LBB7_12
.LBB7_15:
	mov	x8, xzr
	add	x9, x21, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp23:
	ldaxr	x0, [x9]
	stxr	w10, x8, [x9]
	cbnz	w10, .Ltmp23

	//NO_APP
	add	x9, x21, #16
	//APP
	str	x8, [x9]
	//NO_APP
	cbz	x0, .LBB7_17
.LBB7_16:                               // =>This Inner Loop Header: Depth=1
	ldp	x8, x1, [x0, #16]
	ldr	x19, [x0]
	blr	x8
	mov	x0, x19
	cbnz	x19, .LBB7_16
.LBB7_17:
	mov	x8, xzr
	add	x9, x21, #24
	//APP
	prfm	pstl1strm, [x9]
.Ltmp24:
	ldaxr	x0, [x9]
	stxr	w10, x8, [x9]
	cbnz	w10, .Ltmp24

	//NO_APP
	add	x9, x21, #32
	//APP
	str	x8, [x9]
	//NO_APP
	cbz	x0, .LBB7_19
.LBB7_18:                               // =>This Inner Loop Header: Depth=1
	ldp	x8, x1, [x0, #16]
	ldr	x19, [x0]
	blr	x8
	mov	x0, x19
	cbnz	x19, .LBB7_18
.LBB7_19:
	mov	x8, xzr
	add	x9, x21, #40
	//APP
	prfm	pstl1strm, [x9]
.Ltmp25:
	ldaxr	x0, [x9]
	stxr	w10, x8, [x9]
	cbnz	w10, .Ltmp25

	//NO_APP
	add	x9, x21, #48
	//APP
	str	x8, [x9]
	//NO_APP
	cbz	x0, .LBB7_21
.LBB7_20:                               // =>This Inner Loop Header: Depth=1
	ldp	x8, x1, [x0, #16]
	ldr	x19, [x0]
	blr	x8
	mov	x0, x19
	cbnz	x19, .LBB7_20
.LBB7_21:
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_destroy
	mov	w0, wzr
	.cfi_def_cfa wsp, 176
	ldp	x20, x19, [sp, #160]            // 16-byte Folded Reload
	ldr	x25, [sp, #112]                 // 8-byte Folded Reload
	ldp	x22, x21, [sp, #144]            // 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            // 16-byte Folded Reload
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #176
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end7:
	.size	main, .Lfunc_end7-main
	.cfi_endproc
                                        // -- End function
	.type	g_lock,@object                  // @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	48
	.size	g_lock, 48

	.type	g_lock_lib,@object              // @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.xword	lock_acq
	.xword	lock_rel
	.xword	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  // @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  // @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 // @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                // @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym run
	.addrsig_sym g_lock
	.addrsig_sym g_vebr
	.addrsig_sym g_queue
