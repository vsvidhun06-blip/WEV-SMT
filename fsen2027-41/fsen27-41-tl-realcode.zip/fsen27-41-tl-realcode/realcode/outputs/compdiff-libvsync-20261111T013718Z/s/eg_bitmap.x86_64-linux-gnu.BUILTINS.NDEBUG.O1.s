	.file	"eg_bitmap.c"
	.text
	.globl	reader                          # -- Begin function reader
	.p2align	4
	.type	reader,@function
reader:                                 # @reader
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	g_bitmap@GOTPCREL(%rip), %r15
	leaq	.L.str(%rip), %rbx
	jmp	.LBB0_1
	.p2align	4
.LBB0_8:                                #   in Loop: Header=BB0_1 Depth=1
	movl	$693, %edx                      # imm = 0x2B5
	movq	%rbx, %rdi
	movq	%r14, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	cmpq	$693, %r14                      # imm = 0x2B5
	jae	.LBB0_9
.LBB0_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_4 Depth 2
                                        #     Child Loop BB0_6 Depth 2
	movq	(%r15), %rax
	#APP
	#NO_APP
	movq	16(%rax), %rdx
	#APP
	#NO_APP
	xorl	%ecx, %ecx
	xorl	%r14d, %r14d
	testq	%rdx, %rdx
	jne	.LBB0_6
.LBB0_3:                                #   in Loop: Header=BB0_1 Depth=1
	movq	(%rax), %rsi
	.p2align	4
.LBB0_4:                                #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	addq	$1, %rcx
	cmpq	%rsi, %rcx
	jae	.LBB0_8
# %bb.5:                                #   in Loop: Header=BB0_4 Depth=2
	#APP
	#NO_APP
	movq	16(%rax,%rcx,8), %rdx
	#APP
	#NO_APP
	testq	%rdx, %rdx
	je	.LBB0_4
.LBB0_6:                                #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	rep		bsfq	%rdx, %rsi
	movq	%rcx, %rdi
	shlq	$6, %rdi
	orq	%rsi, %rdi
	cmpq	8(%rax), %rdi
	jae	.LBB0_8
# %bb.7:                                #   in Loop: Header=BB0_6 Depth=2
	btrq	%rsi, %rdx
	addq	$1, %r14
	testq	%rdx, %rdx
	jne	.LBB0_6
	jmp	.LBB0_3
.LBB0_9:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        # -- End function
	.globl	writer                          # -- Begin function writer
	.p2align	4
	.type	writer,@function
writer:                                 # @writer
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	shlq	$3, %rdi
	movabsq	$2305843009213693944, %rdx      # imm = 0x1FFFFFFFFFFFFFF8
	andq	%rdi, %rdx
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	movq	16(%rcx,%rdx), %rcx
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	lock		andq	$-2, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	movq	16(%rcx,%rdx), %rcx
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	lock		orq	$1, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rax
	#APP
	#NO_APP
	movq	16(%rax,%rdx), %rax
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$11, %rdi
	je	.LBB2_1
# %bb.10:
	movq	g_bitmap@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	shlq	$3, %rdi
	movabsq	$2305843009213693944, %rdx      # imm = 0x1FFFFFFFFFFFFFF8
	andq	%rdi, %rdx
	#APP
	#NO_APP
	movq	$-1, %rsi
	xchgq	%rsi, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	movq	16(%rcx,%rdx), %rcx
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	lock		andq	$-2, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	movq	16(%rcx,%rdx), %rcx
	#APP
	#NO_APP
	movq	(%rax), %rcx
	#APP
	#NO_APP
	lock		orq	$1, 16(%rcx,%rdx)
	#APP
	#NO_APP
	movq	(%rax), %rax
	#APP
	#NO_APP
	movq	16(%rax,%rdx), %rax
	#APP
	#NO_APP
.LBB2_11:
	xorl	%eax, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB2_1:
	.cfi_def_cfa %rbp, 16
	movq	g_bitmap@GOTPCREL(%rip), %r15
	leaq	.L.str(%rip), %rbx
	jmp	.LBB2_2
	.p2align	4
.LBB2_9:                                #   in Loop: Header=BB2_2 Depth=1
	movl	$693, %edx                      # imm = 0x2B5
	movq	%rbx, %rdi
	movq	%r14, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
	cmpq	$693, %r14                      # imm = 0x2B5
	jae	.LBB2_11
.LBB2_2:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_5 Depth 2
                                        #     Child Loop BB2_7 Depth 2
	movq	(%r15), %rax
	#APP
	#NO_APP
	movq	16(%rax), %rdx
	#APP
	#NO_APP
	xorl	%ecx, %ecx
	xorl	%r14d, %r14d
	testq	%rdx, %rdx
	jne	.LBB2_7
.LBB2_4:                                #   in Loop: Header=BB2_2 Depth=1
	movq	(%rax), %rsi
	.p2align	4
.LBB2_5:                                #   Parent Loop BB2_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	addq	$1, %rcx
	cmpq	%rsi, %rcx
	jae	.LBB2_9
# %bb.6:                                #   in Loop: Header=BB2_5 Depth=2
	#APP
	#NO_APP
	movq	16(%rax,%rcx,8), %rdx
	#APP
	#NO_APP
	testq	%rdx, %rdx
	je	.LBB2_5
.LBB2_7:                                #   Parent Loop BB2_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	rep		bsfq	%rdx, %rsi
	movq	%rcx, %rdi
	shlq	$6, %rdi
	orq	%rsi, %rdi
	cmpq	8(%rax), %rdi
	jae	.LBB2_9
# %bb.8:                                #   in Loop: Header=BB2_7 Depth=2
	btrq	%rsi, %rdx
	addq	$1, %r14
	testq	%rdx, %rdx
	jne	.LBB2_7
	jmp	.LBB2_4
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movl	$104, %edi
	callq	malloc@PLT
	movq	g_bitmap@GOTPCREL(%rip), %r14
	movq	%rax, (%r14)
	movq	$704, 8(%rax)                   # imm = 0x2C0
	movq	$11, (%rax)
	xorl	%ecx, %ecx
	.p2align	4
.LBB3_1:                                # =>This Inner Loop Header: Depth=1
	#APP
	#NO_APP
	xorl	%edx, %edx
	xchgq	%rdx, 16(%rax,%rcx,8)
	#APP
	#NO_APP
	addq	$1, %rcx
	cmpq	(%rax), %rcx
	jb	.LBB3_1
# %bb.2:
	movq	run@GOTPCREL(%rip), %rbx
	leaq	-112(%rbp), %rdi
	xorl	%esi, %esi
	movq	%rbx, %rdx
	xorl	%ecx, %ecx
	callq	pthread_create@PLT
	leaq	-104(%rbp), %rdi
	movl	$1, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-96(%rbp), %rdi
	movl	$2, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-88(%rbp), %rdi
	movl	$3, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-80(%rbp), %rdi
	movl	$4, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-72(%rbp), %rdi
	movl	$5, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-64(%rbp), %rdi
	movl	$6, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-56(%rbp), %rdi
	movl	$7, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-48(%rbp), %rdi
	movl	$8, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-40(%rbp), %rdi
	movl	$9, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-32(%rbp), %rdi
	movl	$10, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	leaq	-24(%rbp), %rdi
	movl	$11, %ecx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	pthread_create@PLT
	movq	-112(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-104(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-96(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-88(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-80(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-72(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-64(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-56(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-48(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-40(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-32(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	-24(%rbp), %rdi
	xorl	%esi, %esi
	callq	pthread_join@PLT
	movq	(%r14), %rdi
	callq	free@PLT
	xorl	%eax, %eax
	addq	$96, %rsp
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        # -- End function
	.type	g_bitmap,@object                # @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.quad	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
