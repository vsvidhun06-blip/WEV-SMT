	.file	"eg_unbounded_queue_lf_recycle.c"
	.text
	.globl	destroy_pools                   # -- Begin function destroy_pools
	.p2align	4
	.type	destroy_pools,@function
destroy_pools:                          # @destroy_pools
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	$0, -8(%rbp)
	movq	$0, -16(%rbp)
	movq	$0, -24(%rbp)
.LBB0_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_3 Depth 2
	cmpq	$12, -24(%rbp)
	jae	.LBB0_7
# %bb.2:                                #   in Loop: Header=BB0_1 Depth=1
	movq	-24(%rbp), %rcx
	movq	local_pools@GOTPCREL(%rip), %rax
	movq	(%rax,%rcx,8), %rax
	movq	%rax, -8(%rbp)
.LBB0_3:                                #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpq	$0, -8(%rbp)
	je	.LBB0_5
# %bb.4:                                #   in Loop: Header=BB0_3 Depth=2
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_stamped_get_pointer
	movq	%rax, -16(%rbp)
	movq	-8(%rbp), %rdi
	callq	free@PLT
	movq	-16(%rbp), %rax
	movq	%rax, -8(%rbp)
	jmp	.LBB0_3
.LBB0_5:                                #   in Loop: Header=BB0_1 Depth=1
	jmp	.LBB0_6
.LBB0_6:                                #   in Loop: Header=BB0_1 Depth=1
	movq	-24(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -24(%rbp)
	jmp	.LBB0_1
.LBB0_7:
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end0:
	.size	destroy_pools, .Lfunc_end0-destroy_pools
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_stamped_get_pointer
	.type	vatomicptr_stamped_get_pointer,@function
vatomicptr_stamped_get_pointer:         # @vatomicptr_stamped_get_pointer
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movq	%rdi, -24(%rbp)
	movb	$0, -9(%rbp)
	movq	-24(%rbp), %rdi
	leaq	-9(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, -32(%rbp)                 # 8-byte Spill
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB1_2
# %bb.1:
	movq	-32(%rbp), %rax                 # 8-byte Reload
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB1_2:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end1:
	.size	vatomicptr_stamped_get_pointer, .Lfunc_end1-vatomicptr_stamped_get_pointer
	.cfi_endproc
                                        # -- End function
	.globl	destroy_cb                      # -- Begin function destroy_cb
	.p2align	4
	.type	destroy_cb,@function
destroy_cb:                             # @destroy_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	callq	free@PLT
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end2:
	.size	destroy_cb, .Lfunc_end2-destroy_cb
	.cfi_endproc
                                        # -- End function
	.globl	retire_cb                       # -- Begin function retire_cb
	.p2align	4
	.type	retire_cb,@function
retire_cb:                              # @retire_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	-32(%rbp), %rax
	movq	%rax, -40(%rbp)
	movb	$0, -9(%rbp)
	movq	-24(%rbp), %rdi
	addq	$8, %rdi
	leaq	-9(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	-24(%rbp), %rdi
	addq	$8, %rdi
	movq	-40(%rbp), %rcx
	movq	local_pools@GOTPCREL(%rip), %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	movq	(%rax,%rcx,8), %rsi
	movzbl	-9(%rbp), %eax
	addl	$1, %eax
                                        # kill: def $al killed $al killed $eax
	movzbl	%al, %edx
	callq	vatomicptr_stamped_set
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	-24(%rbp), %rdx
	movq	-40(%rbp), %rcx
	movq	%rdx, (%rax,%rcx,8)
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB3_2
# %bb.1:
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB3_2:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_stamped_get
	.type	vatomicptr_stamped_get,@function
vatomicptr_stamped_get:                 # @vatomicptr_stamped_get
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	callq	vatomicptr_read
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	andq	$127, %rax
	movb	%al, %cl
	movq	-16(%rbp), %rax
	movb	%cl, (%rax)
	movq	-24(%rbp), %rax
	andq	$-128, %rax
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end4:
	.size	vatomicptr_stamped_get, .Lfunc_end4-vatomicptr_stamped_get
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_stamped_set
	.type	vatomicptr_stamped_set,@function
vatomicptr_stamped_set:                 # @vatomicptr_stamped_set
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movb	%dl, %al
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movb	%al, -17(%rbp)
	movq	-16(%rbp), %rax
	andq	$127, %rax
	cmpq	$0, %rax
	jne	.LBB5_2
# %bb.1:
	jmp	.LBB5_3
.LBB5_2:
	leaq	.L.str.6(%rip), %rdi
	leaq	.L.str.7(%rip), %rsi
	movl	$291, %edx                      # imm = 0x123
	leaq	.L__PRETTY_FUNCTION__.vatomicptr_stamped_set(%rip), %rcx
	callq	__assert_fail@PLT
.LBB5_3:
	movq	-16(%rbp), %rax
	movzbl	-17(%rbp), %ecx
                                        # kill: def $rcx killed $ecx
	andq	$127, %rcx
                                        # kill: def $cl killed $cl killed $rcx
	movzbl	%cl, %ecx
                                        # kill: def $rcx killed $ecx
	orq	%rcx, %rax
	movq	%rax, -32(%rbp)
	movq	-8(%rbp), %rdi
	movq	-32(%rbp), %rsi
	callq	vatomicptr_write
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end5:
	.size	vatomicptr_stamped_set, .Lfunc_end5-vatomicptr_stamped_set
	.cfi_endproc
                                        # -- End function
	.globl	alloc_qnode                     # -- Begin function alloc_qnode
	.p2align	4
	.type	alloc_qnode,@function
alloc_qnode:                            # @alloc_qnode
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	$0, -16(%rbp)
	movq	-8(%rbp), %rcx
	movq	local_pools@GOTPCREL(%rip), %rax
	cmpq	$0, (%rax,%rcx,8)
	je	.LBB6_2
# %bb.1:
	movq	-8(%rbp), %rcx
	movq	local_pools@GOTPCREL(%rip), %rax
	movq	(%rax,%rcx,8), %rax
	movq	%rax, -16(%rbp)
	movq	-8(%rbp), %rcx
	movq	local_pools@GOTPCREL(%rip), %rax
	movq	(%rax,%rcx,8), %rdi
	addq	$8, %rdi
	callq	vatomicptr_stamped_get_pointer
	movq	%rax, %rdx
	movq	-8(%rbp), %rcx
	movq	local_pools@GOTPCREL(%rip), %rax
	movq	%rdx, (%rax,%rcx,8)
	leaq	.L.str(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
	jmp	.LBB6_3
.LBB6_2:
	movl	$128, %esi
	movq	%rsi, %rdi
	callq	memalign@PLT
	movq	%rax, -16(%rbp)
	leaq	.L.str.1(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
.LBB6_3:
	cmpq	$0, -16(%rbp)
	je	.LBB6_5
# %bb.4:
	jmp	.LBB6_6
.LBB6_5:
	leaq	.L.str.2(%rip), %rdi
	leaq	.L.str.3(%rip), %rsi
	movl	$77, %edx
	leaq	.L__PRETTY_FUNCTION__.alloc_qnode(%rip), %rcx
	callq	__assert_fail@PLT
.LBB6_6:
	movq	-16(%rbp), %rax
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end6:
	.size	alloc_qnode, .Lfunc_end6-alloc_qnode
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	$0, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	$0, -32(%rbp)
.LBB7_1:                                # =>This Inner Loop Header: Depth=1
	cmpq	$100, -32(%rbp)
	jae	.LBB7_7
# %bb.2:                                #   in Loop: Header=BB7_1 Depth=1
	movq	-24(%rbp), %rdx
	movq	g_queue@GOTPCREL(%rip), %rdi
	movq	retire_cb@GOTPCREL(%rip), %rsi
	callq	vqueue_ub_deq
	movq	%rax, -16(%rbp)
	cmpq	$0, -16(%rbp)
	jne	.LBB7_4
# %bb.3:                                #   in Loop: Header=BB7_1 Depth=1
	movl	$8, %edi
	callq	malloc@PLT
	movq	%rax, -16(%rbp)
	movq	-32(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-24(%rbp), %rdi
	callq	alloc_qnode@PLT
	movq	%rax, -40(%rbp)
	movq	-24(%rbp), %rsi
	movq	-16(%rbp), %rax
	movq	(%rax), %rdx
	leaq	.L.str.4(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
	movq	-40(%rbp), %rsi
	movq	-16(%rbp), %rdx
	movq	g_queue@GOTPCREL(%rip), %rdi
	callq	vqueue_ub_enq
	jmp	.LBB7_5
.LBB7_4:                                #   in Loop: Header=BB7_1 Depth=1
	movq	-24(%rbp), %rsi
	movq	-16(%rbp), %rax
	movq	(%rax), %rdx
	leaq	.L.str.5(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
	movq	-16(%rbp), %rdi
	callq	free@PLT
.LBB7_5:                                #   in Loop: Header=BB7_1 Depth=1
	jmp	.LBB7_6
.LBB7_6:                                #   in Loop: Header=BB7_1 Depth=1
	movq	-32(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -32(%rbp)
	jmp	.LBB7_1
.LBB7_7:
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end7:
	.size	run, .Lfunc_end7-run
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_deq
	.type	vqueue_ub_deq,@function
vqueue_ub_deq:                          # @vqueue_ub_deq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$96, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%rsi, -40(%rbp)
	movq	%rdx, -48(%rbp)
	movq	$0, -56(%rbp)
	movq	$0, -64(%rbp)
	movq	$0, -72(%rbp)
	movb	$0, -9(%rbp)
	movb	$0, -10(%rbp)
	movb	$0, -11(%rbp)
	movb	$0, -12(%rbp)
	movq	$0, -80(%rbp)
.LBB8_1:                                # =>This Inner Loop Header: Depth=1
	movq	-32(%rbp), %rdi
	leaq	-9(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, -56(%rbp)
	movq	-32(%rbp), %rdi
	addq	$8, %rdi
	leaq	-10(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, -64(%rbp)
	movq	-56(%rbp), %rdi
	addq	$8, %rdi
	leaq	-11(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, -72(%rbp)
	movq	-56(%rbp), %rax
	movq	%rax, -88(%rbp)                 # 8-byte Spill
	movq	-32(%rbp), %rdi
	leaq	-12(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, %rcx
	movq	-88(%rbp), %rax                 # 8-byte Reload
	cmpq	%rcx, %rax
	jne	.LBB8_13
# %bb.2:                                #   in Loop: Header=BB8_1 Depth=1
	movzbl	-12(%rbp), %eax
	movzbl	-9(%rbp), %ecx
	cmpl	%ecx, %eax
	jne	.LBB8_13
# %bb.3:                                #   in Loop: Header=BB8_1 Depth=1
	movq	-56(%rbp), %rax
	cmpq	-64(%rbp), %rax
	jne	.LBB8_7
# %bb.4:                                #   in Loop: Header=BB8_1 Depth=1
	cmpq	$0, -72(%rbp)
	jne	.LBB8_6
# %bb.5:
	movq	$0, -24(%rbp)
	jmp	.LBB8_14
.LBB8_6:                                #   in Loop: Header=BB8_1 Depth=1
	callq	verification_ignore
	movq	-32(%rbp), %rdi
	addq	$8, %rdi
	movq	-64(%rbp), %rsi
	movb	-10(%rbp), %dl
	movq	-72(%rbp), %rcx
	movzbl	-10(%rbp), %eax
	addl	$1, %eax
                                        # kill: def $al killed $al killed $eax
	movzbl	%dl, %edx
	movzbl	%al, %r8d
	callq	vatomicptr_stamped_cmpxchg
	jmp	.LBB8_12
.LBB8_7:                                #   in Loop: Header=BB8_1 Depth=1
	movq	-72(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -80(%rbp)
	movq	-32(%rbp), %rdi
	movq	-56(%rbp), %rsi
	movb	-9(%rbp), %dl
	movq	-72(%rbp), %rcx
	movzbl	-9(%rbp), %eax
	addl	$1, %eax
                                        # kill: def $al killed $al killed $eax
	movzbl	%dl, %edx
	movzbl	%al, %r8d
	callq	vatomicptr_stamped_cmpxchg
	testb	$1, %al
	jne	.LBB8_8
	jmp	.LBB8_11
.LBB8_8:
	movq	-56(%rbp), %rax
	movq	-32(%rbp), %rcx
	addq	$128, %rcx
	cmpq	%rcx, %rax
	je	.LBB8_10
# %bb.9:
	movq	-40(%rbp), %rax
	movq	-56(%rbp), %rdi
	movq	-48(%rbp), %rsi
	callq	*%rax
.LBB8_10:
	movq	-80(%rbp), %rax
	movq	%rax, -24(%rbp)
	jmp	.LBB8_14
.LBB8_11:                               #   in Loop: Header=BB8_1 Depth=1
	jmp	.LBB8_12
.LBB8_12:                               #   in Loop: Header=BB8_1 Depth=1
	jmp	.LBB8_13
.LBB8_13:                               #   in Loop: Header=BB8_1 Depth=1
	jmp	.LBB8_1
.LBB8_14:
	movq	-24(%rbp), %rax
	movq	%rax, -96(%rbp)                 # 8-byte Spill
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB8_16
# %bb.15:
	movq	-96(%rbp), %rax                 # 8-byte Reload
	addq	$96, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB8_16:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end8:
	.size	vqueue_ub_deq, .Lfunc_end8-vqueue_ub_deq
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_enq
	.type	vqueue_ub_enq,@function
vqueue_ub_enq:                          # @vqueue_ub_enq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$80, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	movq	%rdx, -40(%rbp)
	movq	$0, -48(%rbp)
	movq	$0, -56(%rbp)
	movb	$0, -9(%rbp)
	movb	$0, -10(%rbp)
	movb	$0, -11(%rbp)
	movb	$0, -12(%rbp)
	movb	$0, -57(%rbp)
	cmpq	$0, -24(%rbp)
	je	.LBB9_2
# %bb.1:
	jmp	.LBB9_3
.LBB9_2:
	leaq	.L.str.9(%rip), %rdi
	leaq	.L.str.10(%rip), %rsi
	movl	$131, %edx
	leaq	.L__PRETTY_FUNCTION__.vqueue_ub_enq(%rip), %rcx
	callq	__assert_fail@PLT
.LBB9_3:
	cmpq	$0, -32(%rbp)
	je	.LBB9_5
# %bb.4:
	jmp	.LBB9_6
.LBB9_5:
	leaq	.L.str.2(%rip), %rdi
	leaq	.L.str.10(%rip), %rsi
	movl	$132, %edx
	leaq	.L__PRETTY_FUNCTION__.vqueue_ub_enq(%rip), %rcx
	callq	__assert_fail@PLT
.LBB9_6:
	movq	-40(%rbp), %rcx
	movq	-32(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-32(%rbp), %rdi
	addq	$8, %rdi
	leaq	-12(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	-32(%rbp), %rdi
	addq	$8, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	movzbl	-12(%rbp), %edx
	callq	vatomicptr_stamped_set
.LBB9_7:                                # =>This Inner Loop Header: Depth=1
	movq	-24(%rbp), %rdi
	addq	$8, %rdi
	leaq	-9(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, -48(%rbp)
	movq	-48(%rbp), %rdi
	addq	$8, %rdi
	leaq	-10(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, -56(%rbp)
	movq	-48(%rbp), %rax
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	movq	-24(%rbp), %rdi
	addq	$8, %rdi
	leaq	-11(%rbp), %rsi
	callq	vatomicptr_stamped_get
	movq	%rax, %rcx
	movq	-72(%rbp), %rax                 # 8-byte Reload
	cmpq	%rcx, %rax
	jne	.LBB9_16
# %bb.8:                                #   in Loop: Header=BB9_7 Depth=1
	movzbl	-9(%rbp), %eax
	movzbl	-11(%rbp), %ecx
	cmpl	%ecx, %eax
	jne	.LBB9_16
# %bb.9:                                #   in Loop: Header=BB9_7 Depth=1
	cmpq	$0, -56(%rbp)
	jne	.LBB9_14
# %bb.10:                               #   in Loop: Header=BB9_7 Depth=1
	movq	-48(%rbp), %rdi
	addq	$8, %rdi
	movq	-56(%rbp), %rsi
	movb	-10(%rbp), %dl
	movq	-32(%rbp), %rcx
	movzbl	-10(%rbp), %eax
	addl	$1, %eax
                                        # kill: def $al killed $al killed $eax
	movzbl	%dl, %edx
	movzbl	%al, %r8d
	callq	vatomicptr_stamped_cmpxchg
	testb	$1, %al
	jne	.LBB9_11
	jmp	.LBB9_13
.LBB9_11:
	movq	-24(%rbp), %rdi
	addq	$8, %rdi
	movq	-48(%rbp), %rsi
	movzbl	-9(%rbp), %edx
	movq	-32(%rbp), %rcx
	movl	%edx, %eax
	addl	$1, %eax
                                        # kill: def $al killed $al killed $eax
	movzbl	%al, %r8d
	callq	vatomicptr_stamped_cmpxchg
	movb	%al, -57(%rbp)
	movzbl	-57(%rbp), %edi
	andl	$1, %edi
	callq	verification_assume
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB9_17
# %bb.12:
	addq	$80, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB9_13:                               #   in Loop: Header=BB9_7 Depth=1
	.cfi_def_cfa %rbp, 16
	jmp	.LBB9_15
.LBB9_14:                               #   in Loop: Header=BB9_7 Depth=1
	callq	verification_ignore
	movq	-24(%rbp), %rdi
	addq	$8, %rdi
	movq	-48(%rbp), %rsi
	movb	-9(%rbp), %dl
	movq	-56(%rbp), %rcx
	movzbl	-9(%rbp), %eax
	addl	$1, %eax
                                        # kill: def $al killed $al killed $eax
	movzbl	%dl, %edx
	movzbl	%al, %r8d
	callq	vatomicptr_stamped_cmpxchg
.LBB9_15:                               #   in Loop: Header=BB9_7 Depth=1
	jmp	.LBB9_16
.LBB9_16:                               #   in Loop: Header=BB9_7 Depth=1
	jmp	.LBB9_7
.LBB9_17:
	callq	__stack_chk_fail@PLT
.Lfunc_end9:
	.size	vqueue_ub_enq, .Lfunc_end9-vqueue_ub_enq
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$144, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movl	$0, -116(%rbp)
	movq	$0, -128(%rbp)
	movq	g_queue@GOTPCREL(%rip), %rdi
	callq	vqueue_ub_init
	movq	$0, -136(%rbp)
.LBB10_1:                               # =>This Inner Loop Header: Depth=1
	cmpq	$12, -136(%rbp)
	jae	.LBB10_4
# %bb.2:                                #   in Loop: Header=BB10_1 Depth=1
	movq	-136(%rbp), %rax
	leaq	-112(%rbp), %rdi
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	-136(%rbp), %rcx
	xorl	%eax, %eax
	movl	%eax, %esi
	movq	run@GOTPCREL(%rip), %rdx
	callq	pthread_create@PLT
# %bb.3:                                #   in Loop: Header=BB10_1 Depth=1
	movq	-136(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -136(%rbp)
	jmp	.LBB10_1
.LBB10_4:
	movq	$0, -144(%rbp)
.LBB10_5:                               # =>This Inner Loop Header: Depth=1
	cmpq	$12, -144(%rbp)
	jae	.LBB10_8
# %bb.6:                                #   in Loop: Header=BB10_5 Depth=1
	movq	-144(%rbp), %rax
	movq	-112(%rbp,%rax,8), %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	pthread_join@PLT
# %bb.7:                                #   in Loop: Header=BB10_5 Depth=1
	movq	-144(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -144(%rbp)
	jmp	.LBB10_5
.LBB10_8:
	jmp	.LBB10_9
.LBB10_9:                               # =>This Inner Loop Header: Depth=1
	movq	g_queue@GOTPCREL(%rip), %rdi
	movq	destroy_cb@GOTPCREL(%rip), %rsi
	xorl	%eax, %eax
	movl	%eax, %edx
	callq	vqueue_ub_deq
	movq	%rax, -128(%rbp)
	cmpq	$0, -128(%rbp)
	je	.LBB10_11
# %bb.10:                               #   in Loop: Header=BB10_9 Depth=1
	movq	-128(%rbp), %rdi
	callq	free@PLT
	jmp	.LBB10_9
.LBB10_11:
	movq	g_queue@GOTPCREL(%rip), %rdi
	movq	destroy_cb@GOTPCREL(%rip), %rsi
	xorl	%eax, %eax
	movl	%eax, %edx
	callq	vqueue_ub_destroy
	callq	destroy_pools@PLT
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB10_13
# %bb.12:
	xorl	%eax, %eax
	addq	$144, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB10_13:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end10:
	.size	main, .Lfunc_end10-main
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_init
	.type	vqueue_ub_init,@function
vqueue_ub_init:                         # @vqueue_ub_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	cmpq	$0, -8(%rbp)
	je	.LBB11_2
# %bb.1:
	jmp	.LBB11_3
.LBB11_2:
	leaq	.L.str.9(%rip), %rdi
	leaq	.L.str.10(%rip), %rsi
	movl	$80, %edx
	leaq	.L__PRETTY_FUNCTION__.vqueue_ub_init(%rip), %rcx
	callq	__assert_fail@PLT
.LBB11_3:
	movq	-8(%rbp), %rdi
	addq	$128, %rdi
	addq	$8, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	xorl	%edx, %edx
	callq	vatomicptr_stamped_set_rlx
	movq	-8(%rbp), %rdi
	movq	-8(%rbp), %rsi
	addq	$128, %rsi
	xorl	%edx, %edx
	callq	vatomicptr_stamped_set_rlx
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-8(%rbp), %rsi
	addq	$128, %rsi
	xorl	%edx, %edx
	callq	vatomicptr_stamped_set_rlx
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end11:
	.size	vqueue_ub_init, .Lfunc_end11-vqueue_ub_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_destroy
	.type	vqueue_ub_destroy,@function
vqueue_ub_destroy:                      # @vqueue_ub_destroy
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	$0, -32(%rbp)
	movq	$0, -40(%rbp)
	movq	-8(%rbp), %rdi
	callq	vatomicptr_stamped_get_pointer
	movq	%rax, -40(%rbp)
.LBB12_1:                               # =>This Inner Loop Header: Depth=1
	cmpq	$0, -40(%rbp)
	je	.LBB12_5
# %bb.2:                                #   in Loop: Header=BB12_1 Depth=1
	movq	-40(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_stamped_get_pointer
	movq	%rax, -32(%rbp)
	movq	-40(%rbp), %rax
	movq	-8(%rbp), %rcx
	addq	$128, %rcx
	cmpq	%rcx, %rax
	je	.LBB12_4
# %bb.3:                                #   in Loop: Header=BB12_1 Depth=1
	movq	-16(%rbp), %rax
	movq	-40(%rbp), %rdi
	movq	-24(%rbp), %rsi
	callq	*%rax
.LBB12_4:                               #   in Loop: Header=BB12_1 Depth=1
	movq	-32(%rbp), %rax
	movq	%rax, -40(%rbp)
	jmp	.LBB12_1
.LBB12_5:
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end12:
	.size	vqueue_ub_destroy, .Lfunc_end12-vqueue_ub_destroy
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_read
	.type	vatomicptr_read,@function
vatomicptr_read:                        # @vatomicptr_read
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, -16(%rbp)
	#APP
	#NO_APP
	movq	-16(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end13:
	.size	vatomicptr_read, .Lfunc_end13-vatomicptr_read
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_write
	.type	vatomicptr_write,@function
vatomicptr_write:                       # @vatomicptr_write
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	xchgq	%rax, (%rcx)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end14:
	.size	vatomicptr_write, .Lfunc_end14-vatomicptr_write
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function verification_ignore
	.type	verification_ignore,@function
verification_ignore:                    # @verification_ignore
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end15:
	.size	verification_ignore, .Lfunc_end15-verification_ignore
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_stamped_cmpxchg
	.type	vatomicptr_stamped_cmpxchg,@function
vatomicptr_stamped_cmpxchg:             # @vatomicptr_stamped_cmpxchg
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$64, %rsp
	movb	%r8b, %al
                                        # kill: def $dl killed $dl killed $edx
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movb	%dl, -17(%rbp)
	movq	%rcx, -32(%rbp)
	movb	%al, -33(%rbp)
	movq	$0, -48(%rbp)
	movq	$0, -56(%rbp)
	movq	$0, -64(%rbp)
	movq	-16(%rbp), %rax
	andq	$127, %rax
	cmpq	$0, %rax
	jne	.LBB16_2
# %bb.1:
	jmp	.LBB16_3
.LBB16_2:
	leaq	.L.str.8(%rip), %rdi
	leaq	.L.str.7(%rip), %rsi
	movl	$86, %edx
	leaq	.L__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg(%rip), %rcx
	callq	__assert_fail@PLT
.LBB16_3:
	movq	-32(%rbp), %rax
	andq	$127, %rax
	cmpq	$0, %rax
	jne	.LBB16_5
# %bb.4:
	jmp	.LBB16_6
.LBB16_5:
	leaq	.L.str.6(%rip), %rdi
	leaq	.L.str.7(%rip), %rsi
	movl	$87, %edx
	leaq	.L__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg(%rip), %rcx
	callq	__assert_fail@PLT
.LBB16_6:
	movq	-16(%rbp), %rax
	movzbl	-17(%rbp), %ecx
                                        # kill: def $rcx killed $ecx
	andq	$127, %rcx
                                        # kill: def $cl killed $cl killed $rcx
	movzbl	%cl, %ecx
                                        # kill: def $rcx killed $ecx
	orq	%rcx, %rax
	movq	%rax, -56(%rbp)
	movq	-32(%rbp), %rax
	movzbl	-33(%rbp), %ecx
                                        # kill: def $rcx killed $ecx
	andq	$127, %rcx
                                        # kill: def $cl killed $cl killed $rcx
	movzbl	%cl, %ecx
                                        # kill: def $rcx killed $ecx
	orq	%rcx, %rax
	movq	%rax, -64(%rbp)
	movq	-8(%rbp), %rdi
	movq	-56(%rbp), %rsi
	movq	-64(%rbp), %rdx
	callq	vatomicptr_cmpxchg
	movq	%rax, -48(%rbp)
	movq	-48(%rbp), %rax
	cmpq	-56(%rbp), %rax
	sete	%al
	andb	$1, %al
	addq	$64, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end16:
	.size	vatomicptr_stamped_cmpxchg, .Lfunc_end16-vatomicptr_stamped_cmpxchg
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_cmpxchg
	.type	vatomicptr_cmpxchg,@function
vatomicptr_cmpxchg:                     # @vatomicptr_cmpxchg
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, -32(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rax, -40(%rbp)
	movq	-32(%rbp), %rax
	movq	-40(%rbp), %rdx
	lock		cmpxchgq	%rdx, (%rcx)
	movq	%rax, %rcx
	sete	%al
	movb	%al, -57(%rbp)                  # 1-byte Spill
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	testb	$1, %al
	jne	.LBB17_2
# %bb.1:
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -32(%rbp)
.LBB17_2:
	movb	-57(%rbp), %al                  # 1-byte Reload
	andb	$1, %al
	movb	%al, -41(%rbp)
	#APP
	#NO_APP
	movq	-32(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end17:
	.size	vatomicptr_cmpxchg, .Lfunc_end17-vatomicptr_cmpxchg
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function verification_assume
	.type	verification_assume,@function
verification_assume:                    # @verification_assume
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movb	%dil, %al
	andb	$1, %al
	movb	%al, -1(%rbp)
# %bb.1:
	jmp	.LBB18_2
.LBB18_2:
# %bb.3:
	jmp	.LBB18_4
.LBB18_4:
	jmp	.LBB18_5
.LBB18_5:
	jmp	.LBB18_6
.LBB18_6:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end18:
	.size	verification_assume, .Lfunc_end18-verification_assume
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_stamped_set_rlx
	.type	vatomicptr_stamped_set_rlx,@function
vatomicptr_stamped_set_rlx:             # @vatomicptr_stamped_set_rlx
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movb	%dl, %al
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movb	%al, -17(%rbp)
	movq	-16(%rbp), %rax
	andq	$127, %rax
	cmpq	$0, %rax
	jne	.LBB19_2
# %bb.1:
	jmp	.LBB19_3
.LBB19_2:
	leaq	.L.str.6(%rip), %rdi
	leaq	.L.str.7(%rip), %rsi
	movl	$319, %edx                      # imm = 0x13F
	leaq	.L__PRETTY_FUNCTION__.vatomicptr_stamped_set_rlx(%rip), %rcx
	callq	__assert_fail@PLT
.LBB19_3:
	movq	-16(%rbp), %rax
	movzbl	-17(%rbp), %ecx
                                        # kill: def $rcx killed $ecx
	andq	$127, %rcx
                                        # kill: def $cl killed $cl killed $rcx
	movzbl	%cl, %ecx
                                        # kill: def $rcx killed $ecx
	orq	%rcx, %rax
	movq	%rax, -32(%rbp)
	movq	-8(%rbp), %rdi
	movq	-32(%rbp), %rsi
	callq	vatomicptr_write_rlx
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end19:
	.size	vatomicptr_stamped_set_rlx, .Lfunc_end19-vatomicptr_stamped_set_rlx
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_write_rlx
	.type	vatomicptr_write_rlx,@function
vatomicptr_write_rlx:                   # @vatomicptr_write_rlx
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rcx
	movq	%rcx, -24(%rbp)
	movq	-24(%rbp), %rcx
	movq	%rcx, (%rax)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end20:
	.size	vatomicptr_write_rlx, .Lfunc_end20-vatomicptr_write_rlx
	.cfi_endproc
                                        # -- End function
	.type	local_pools,@object             # @local_pools
	.bss
	.globl	local_pools
	.p2align	4, 0x0
local_pools:
	.zero	96
	.size	local_pools, 96

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Recycle allocation\n"
	.size	.L.str, 20

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"New allocation\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"qnode"
	.size	.L.str.2, 6

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"C:/rc1111/src/libvsync/examples/eg_unbounded_queue_lf_recycle.c"
	.size	.L.str.3, 64

	.type	.L__PRETTY_FUNCTION__.alloc_qnode,@object # @__PRETTY_FUNCTION__.alloc_qnode
.L__PRETTY_FUNCTION__.alloc_qnode:
	.asciz	"vqueue_ub_node_t *alloc_qnode(vsize_t)"
	.size	.L__PRETTY_FUNCTION__.alloc_qnode, 39

	.type	g_queue,@object                 # @g_queue
	.bss
	.globl	g_queue
	.p2align	7, 0x0
g_queue:
	.zero	256
	.size	g_queue, 256

	.type	.L.str.4,@object                # @.str.4
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.4:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.4, 16

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.5, 16

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"((((vuintptr_t)(v)) & ((vuintptr_t)0x7F)) == 0)"
	.size	.L.str.6, 48

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/atomic/atomicptr_stamped.h"
	.size	.L.str.7, 64

	.type	.L__PRETTY_FUNCTION__.vatomicptr_stamped_set,@object # @__PRETTY_FUNCTION__.vatomicptr_stamped_set
.L__PRETTY_FUNCTION__.vatomicptr_stamped_set:
	.asciz	"void vatomicptr_stamped_set(vatomicptr_stamped_t *, void *, vuint8_t)"
	.size	.L__PRETTY_FUNCTION__.vatomicptr_stamped_set, 70

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"((((vuintptr_t)(e_v)) & ((vuintptr_t)0x7F)) == 0)"
	.size	.L.str.8, 50

	.type	.L__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg,@object # @__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg
.L__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg:
	.asciz	"vbool_t vatomicptr_stamped_cmpxchg(vatomicptr_stamped_t *, void *, vuint8_t, void *, vuint8_t)"
	.size	.L__PRETTY_FUNCTION__.vatomicptr_stamped_cmpxchg, 95

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"q"
	.size	.L.str.9, 2

	.type	.L.str.10,@object               # @.str.10
.L.str.10:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/queue/unbounded_queue_lf_recycle.h"
	.size	.L.str.10, 72

	.type	.L__PRETTY_FUNCTION__.vqueue_ub_enq,@object # @__PRETTY_FUNCTION__.vqueue_ub_enq
.L__PRETTY_FUNCTION__.vqueue_ub_enq:
	.asciz	"void vqueue_ub_enq(vqueue_ub_t *, vqueue_ub_node_t *, void *)"
	.size	.L__PRETTY_FUNCTION__.vqueue_ub_enq, 62

	.type	.L__PRETTY_FUNCTION__.vqueue_ub_init,@object # @__PRETTY_FUNCTION__.vqueue_ub_init
.L__PRETTY_FUNCTION__.vqueue_ub_init:
	.asciz	"void vqueue_ub_init(vqueue_ub_t *)"
	.size	.L__PRETTY_FUNCTION__.vqueue_ub_init, 35

	.type	.L__PRETTY_FUNCTION__.vatomicptr_stamped_set_rlx,@object # @__PRETTY_FUNCTION__.vatomicptr_stamped_set_rlx
.L__PRETTY_FUNCTION__.vatomicptr_stamped_set_rlx:
	.asciz	"void vatomicptr_stamped_set_rlx(vatomicptr_stamped_t *, void *, vuint8_t)"
	.size	.L__PRETTY_FUNCTION__.vatomicptr_stamped_set_rlx, 74

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym destroy_pools
	.addrsig_sym vatomicptr_stamped_get_pointer
	.addrsig_sym free
	.addrsig_sym destroy_cb
	.addrsig_sym retire_cb
	.addrsig_sym vatomicptr_stamped_get
	.addrsig_sym vatomicptr_stamped_set
	.addrsig_sym alloc_qnode
	.addrsig_sym printf
	.addrsig_sym memalign
	.addrsig_sym __assert_fail
	.addrsig_sym run
	.addrsig_sym vqueue_ub_deq
	.addrsig_sym malloc
	.addrsig_sym vqueue_ub_enq
	.addrsig_sym vqueue_ub_init
	.addrsig_sym pthread_create
	.addrsig_sym pthread_join
	.addrsig_sym vqueue_ub_destroy
	.addrsig_sym vatomicptr_read
	.addrsig_sym vatomicptr_write
	.addrsig_sym verification_ignore
	.addrsig_sym vatomicptr_stamped_cmpxchg
	.addrsig_sym vatomicptr_cmpxchg
	.addrsig_sym verification_assume
	.addrsig_sym vatomicptr_stamped_set_rlx
	.addrsig_sym vatomicptr_write_rlx
	.addrsig_sym __stack_chk_fail
	.addrsig_sym local_pools
	.addrsig_sym g_queue
