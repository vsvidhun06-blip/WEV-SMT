	.file	"eg_vebr.c"
	.text
	.p2align	4                               # -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               # @lock_acq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rdi
	callq	pthread_mutex_lock@PLT
	movl	%eax, -20(%rbp)
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               # @lock_rel
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, -16(%rbp)
	movq	-16(%rbp), %rdi
	callq	pthread_mutex_unlock@PLT
	movl	%eax, -20(%rbp)
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        # -- End function
	.globl	free_cb                         # -- Begin function free_cb
	.p2align	4
	.type	free_cb,@function
free_cb:                                # @free_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	subq	$16, %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rdi
	callq	free@PLT
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        # -- End function
	.globl	retire_cb                       # -- Begin function retire_cb
	.p2align	4
	.type	retire_cb,@function
retire_cb:                              # @retire_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rsi
	movq	-8(%rbp), %rdx
	addq	$16, %rdx
	movq	g_vebr@GOTPCREL(%rip), %rdi
	movq	free_cb@GOTPCREL(%rip), %rcx
	xorl	%eax, %eax
	movl	%eax, %r8d
	callq	vebr_retire
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_retire
	.type	vebr_retire,@function
vebr_retire:                            # @vebr_retire
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$64, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	%rcx, -32(%rbp)
	movq	%r8, -40(%rbp)
	movq	$0, -48(%rbp)
	movq	$0, -56(%rbp)
	callq	vatomic_fence
	movq	-8(%rbp), %rdi
	callq	vatomic64_read
	movq	%rax, -48(%rbp)
	movq	-48(%rbp), %rax
	movl	$3, %ecx
	xorl	%edx, %edx
                                        # kill: def $rdx killed $edx
	divq	%rcx
	movq	%rdx, -56(%rbp)
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-56(%rbp), %rax
	shlq	$4, %rax
	addq	%rax, %rdi
	movq	-24(%rbp), %rsi
	movq	-32(%rbp), %rdx
	movq	-40(%rbp), %rcx
	callq	smr_nodes_list_add
# %bb.1:
	jmp	.LBB4_2
.LBB4_2:
# %bb.3:
	jmp	.LBB4_4
.LBB4_4:
	jmp	.LBB4_5
.LBB4_5:
	jmp	.LBB4_6
.LBB4_6:
	addq	$64, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end4:
	.size	vebr_retire, .Lfunc_end4-vebr_retire
	.cfi_endproc
                                        # -- End function
	.globl	destroy_cb                      # -- Begin function destroy_cb
	.p2align	4
	.type	destroy_cb,@function
destroy_cb:                             # @destroy_cb
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	callq	free@PLT
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end5:
	.size	destroy_cb, .Lfunc_end5-destroy_cb
	.cfi_endproc
                                        # -- End function
	.globl	reclaim                         # -- Begin function reclaim
	.p2align	4
	.type	reclaim,@function
reclaim:                                # @reclaim
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
.LBB6_1:                                # =>This Inner Loop Header: Depth=1
	movq	g_stop@GOTPCREL(%rip), %rdi
	callq	vatomic8_read
	movzbl	%al, %eax
	cmpl	$0, %eax
	jne	.LBB6_5
# %bb.2:                                #   in Loop: Header=BB6_1 Depth=1
	movq	g_vebr@GOTPCREL(%rip), %rdi
	callq	vebr_recycle
	movq	%rax, -8(%rbp)
	cmpq	$0, -8(%rbp)
	jbe	.LBB6_4
# %bb.3:                                #   in Loop: Header=BB6_1 Depth=1
	movq	-8(%rbp), %rsi
	leaq	.L.str(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
.LBB6_4:                                #   in Loop: Header=BB6_1 Depth=1
	jmp	.LBB6_1
.LBB6_5:
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end6:
	.size	reclaim, .Lfunc_end6-reclaim
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic8_read
	.type	vatomic8_read,@function
vatomic8_read:                          # @vatomic8_read
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movb	(%rax), %al
	movb	%al, -10(%rbp)
	movb	-10(%rbp), %al
	movb	%al, -9(%rbp)
	#APP
	#NO_APP
	movb	-9(%rbp), %al
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end7:
	.size	vatomic8_read, .Lfunc_end7-vatomic8_read
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_recycle
	.type	vebr_recycle,@function
vebr_recycle:                           # @vebr_recycle
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$64, %rsp
	movq	%rdi, -8(%rbp)
	movq	$0, -16(%rbp)
	movq	$0, -24(%rbp)
	movq	$0, -32(%rbp)
	movq	$0, -40(%rbp)
	movq	$0, -48(%rbp)
	movq	$0, -56(%rbp)
	callq	vatomic_fence
	movq	-8(%rbp), %rdi
	callq	vatomic64_read
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rax
	addq	$2, %rax
	movl	$3, %ecx
	xorl	%edx, %edx
                                        # kill: def $rdx killed $edx
	divq	%rcx
	movq	%rdx, -24(%rbp)
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-24(%rbp), %rax
	shlq	$4, %rax
	addq	%rax, %rdi
	callq	smr_nodes_list_get_and_empty
	movq	%rax, -56(%rbp)
	movq	-8(%rbp), %rdi
	movq	-32(%rbp), %rsi
	movl	$1, %edx
	callq	_vebr_sync_epochs
	movq	%rax, -48(%rbp)
	movq	-8(%rbp), %rdi
	movq	-32(%rbp), %rsi
	movq	-32(%rbp), %rdx
	addq	$1, %rdx
	callq	vatomic64_cmpxchg
	movq	%rax, -40(%rbp)
	cmpq	$0, -56(%rbp)
	je	.LBB8_2
# %bb.1:
	movq	-56(%rbp), %rdi
	callq	smr_nodes_list_destroy
	movq	%rax, -16(%rbp)
.LBB8_2:
	movq	-16(%rbp), %rax
	addq	$64, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end8:
	.size	vebr_recycle, .Lfunc_end8-vebr_recycle
	.cfi_endproc
                                        # -- End function
	.globl	run                             # -- Begin function run
	.p2align	4
	.type	run,@function
run:                                    # @run
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$80, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movq	%rdi, -48(%rbp)
	movq	$0, -56(%rbp)
	movq	-48(%rbp), %rax
	movq	%rax, -64(%rbp)
	cmpq	$0, -64(%rbp)
	jne	.LBB9_2
# %bb.1:
	callq	reclaim@PLT
	jmp	.LBB9_10
.LBB9_2:
	movq	g_vebr@GOTPCREL(%rip), %rdi
	leaq	-40(%rbp), %rsi
	callq	vebr_register
	movq	$0, -72(%rbp)
.LBB9_3:                                # =>This Inner Loop Header: Depth=1
	cmpq	$10000, -72(%rbp)               # imm = 0x2710
	jae	.LBB9_9
# %bb.4:                                #   in Loop: Header=BB9_3 Depth=1
	movq	g_vebr@GOTPCREL(%rip), %rdi
	leaq	-40(%rbp), %rsi
	callq	vebr_enter
	movq	g_queue@GOTPCREL(%rip), %rdi
	movq	retire_cb@GOTPCREL(%rip), %rsi
	leaq	-40(%rbp), %rdx
	callq	vqueue_ub_deq
	movq	%rax, -56(%rbp)
	cmpq	$0, -56(%rbp)
	jne	.LBB9_6
# %bb.5:                                #   in Loop: Header=BB9_3 Depth=1
	movl	$8, %edi
	callq	malloc@PLT
	movq	%rax, -56(%rbp)
	movq	-72(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, (%rax)
	movl	$48, %edi
	callq	malloc@PLT
	movq	%rax, -80(%rbp)
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	(%rax), %rdx
	leaq	.L.str.1(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
	movq	-80(%rbp), %rsi
	movq	-56(%rbp), %rdx
	movq	g_queue@GOTPCREL(%rip), %rdi
	callq	vqueue_ub_enq
	jmp	.LBB9_7
.LBB9_6:                                #   in Loop: Header=BB9_3 Depth=1
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	(%rax), %rdx
	leaq	.L.str.2(%rip), %rdi
	movb	$0, %al
	callq	printf@PLT
	movq	-56(%rbp), %rdi
	callq	free@PLT
.LBB9_7:                                #   in Loop: Header=BB9_3 Depth=1
	movq	g_vebr@GOTPCREL(%rip), %rdi
	leaq	-40(%rbp), %rsi
	callq	vebr_exit
# %bb.8:                                #   in Loop: Header=BB9_3 Depth=1
	movq	-72(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -72(%rbp)
	jmp	.LBB9_3
.LBB9_9:
	movq	g_vebr@GOTPCREL(%rip), %rdi
	leaq	-40(%rbp), %rsi
	callq	vebr_deregister
.LBB9_10:
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB9_12
# %bb.11:
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
	addq	$80, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB9_12:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end9:
	.size	run, .Lfunc_end9-run
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_register
	.type	vebr_register,@function
vebr_register:                          # @vebr_register
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rdi
	addq	$16, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomic64_init
	movq	-16(%rbp), %rax
	movl	$0, 24(%rax)
	movq	-8(%rbp), %rax
	movq	72(%rax), %rax
	movq	-8(%rbp), %rcx
	movq	88(%rcx), %rdi
	callq	*%rax
	movq	-8(%rbp), %rdi
	addq	$56, %rdi
	movq	-16(%rbp), %rsi
	callq	dbl_list_add
	movq	-8(%rbp), %rax
	movq	80(%rax), %rax
	movq	-8(%rbp), %rcx
	movq	88(%rcx), %rdi
	callq	*%rax
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end10:
	.size	vebr_register, .Lfunc_end10-vebr_register
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_enter
	.type	vebr_enter,@function
vebr_enter:                             # @vebr_enter
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	$0, -24(%rbp)
	movq	-16(%rbp), %rax
	movl	24(%rax), %ecx
	addl	$1, %ecx
	movl	%ecx, 24(%rax)
	movq	-16(%rbp), %rax
	cmpl	$1, 24(%rax)
	jne	.LBB11_2
# %bb.1:
	movq	-8(%rbp), %rdi
	callq	vatomic64_read
	movq	%rax, -24(%rbp)
	movq	-16(%rbp), %rdi
	addq	$16, %rdi
	movq	-24(%rbp), %rsi
	callq	vatomic64_write_rel
	callq	vatomic_fence
.LBB11_2:
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end11:
	.size	vebr_enter, .Lfunc_end11-vebr_enter
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_deq
	.type	vqueue_ub_deq,@function
vqueue_ub_deq:                          # @vqueue_ub_deq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$80, %rsp
	movq	%rdi, -16(%rbp)
	movq	%rsi, -24(%rbp)
	movq	%rdx, -32(%rbp)
	movq	$0, -40(%rbp)
	movq	$0, -48(%rbp)
	movq	$0, -56(%rbp)
	movq	$0, -64(%rbp)
.LBB12_1:                               # =>This Inner Loop Header: Depth=1
	movq	-16(%rbp), %rdi
	callq	vatomicptr_read
	movq	%rax, -40(%rbp)
	movq	-16(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_read
	movq	%rax, -48(%rbp)
	movq	-40(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_read
	movq	%rax, -56(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	movq	-16(%rbp), %rdi
	callq	vatomicptr_read
	movq	%rax, %rcx
	movq	-72(%rbp), %rax                 # 8-byte Reload
	cmpq	%rcx, %rax
	jne	.LBB12_13
# %bb.2:                                #   in Loop: Header=BB12_1 Depth=1
	movq	-40(%rbp), %rax
	cmpq	-48(%rbp), %rax
	jne	.LBB12_6
# %bb.3:                                #   in Loop: Header=BB12_1 Depth=1
	cmpq	$0, -56(%rbp)
	jne	.LBB12_5
# %bb.4:
	movq	$0, -8(%rbp)
	jmp	.LBB12_15
.LBB12_5:                               #   in Loop: Header=BB12_1 Depth=1
	callq	verification_ignore
	movq	-16(%rbp), %rdi
	addq	$8, %rdi
	movq	-48(%rbp), %rsi
	movq	-56(%rbp), %rdx
	callq	vatomicptr_cmpxchg
	jmp	.LBB12_12
.LBB12_6:                               #   in Loop: Header=BB12_1 Depth=1
	movq	-56(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -64(%rbp)
	movq	-16(%rbp), %rdi
	movq	-40(%rbp), %rsi
	movq	-56(%rbp), %rdx
	callq	vatomicptr_cmpxchg
	cmpq	-40(%rbp), %rax
	jne	.LBB12_10
# %bb.7:
	movq	-40(%rbp), %rax
	movq	-16(%rbp), %rcx
	addq	$16, %rcx
	cmpq	%rcx, %rax
	je	.LBB12_9
# %bb.8:
	movq	-24(%rbp), %rax
	movq	-40(%rbp), %rdi
	movq	-32(%rbp), %rsi
	callq	*%rax
.LBB12_9:
	movq	-64(%rbp), %rax
	movq	%rax, -8(%rbp)
	jmp	.LBB12_15
.LBB12_10:                              #   in Loop: Header=BB12_1 Depth=1
	callq	verification_ignore
# %bb.11:                               #   in Loop: Header=BB12_1 Depth=1
	jmp	.LBB12_12
.LBB12_12:                              #   in Loop: Header=BB12_1 Depth=1
	jmp	.LBB12_14
.LBB12_13:                              #   in Loop: Header=BB12_1 Depth=1
	callq	verification_ignore
.LBB12_14:                              #   in Loop: Header=BB12_1 Depth=1
	jmp	.LBB12_1
.LBB12_15:
	movq	-8(%rbp), %rax
	addq	$80, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end12:
	.size	vqueue_ub_deq, .Lfunc_end12-vqueue_ub_deq
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_enq
	.type	vqueue_ub_enq,@function
vqueue_ub_enq:                          # @vqueue_ub_enq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$64, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	$0, -32(%rbp)
	movq	$0, -40(%rbp)
	movb	$0, -41(%rbp)
	movq	-24(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-16(%rbp), %rdi
	addq	$8, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomicptr_write_rlx
.LBB13_1:                               # =>This Inner Loop Header: Depth=1
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_read
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_read
	movq	%rax, -40(%rbp)
	movq	-32(%rbp), %rax
	movq	%rax, -56(%rbp)                 # 8-byte Spill
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_read
	movq	%rax, %rcx
	movq	-56(%rbp), %rax                 # 8-byte Reload
	cmpq	%rcx, %rax
	jne	.LBB13_9
# %bb.2:                                #   in Loop: Header=BB13_1 Depth=1
	cmpq	$0, -40(%rbp)
	jne	.LBB13_7
# %bb.3:                                #   in Loop: Header=BB13_1 Depth=1
	movq	-32(%rbp), %rdi
	addq	$8, %rdi
	movq	-40(%rbp), %rsi
	movq	-16(%rbp), %rdx
	callq	vatomicptr_cmpxchg
	cmpq	-40(%rbp), %rax
	jne	.LBB13_5
# %bb.4:
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-32(%rbp), %rsi
	movq	-16(%rbp), %rdx
	callq	vatomicptr_cmpxchg
	cmpq	-32(%rbp), %rax
	sete	%al
	andb	$1, %al
	movb	%al, -41(%rbp)
	movb	-41(%rbp), %al
	andb	$1, %al
	movzbl	%al, %edi
	callq	verification_assume
	addq	$64, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB13_5:                               #   in Loop: Header=BB13_1 Depth=1
	.cfi_def_cfa %rbp, 16
	callq	verification_ignore
# %bb.6:                                #   in Loop: Header=BB13_1 Depth=1
	jmp	.LBB13_8
.LBB13_7:                               #   in Loop: Header=BB13_1 Depth=1
	callq	verification_ignore
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-32(%rbp), %rsi
	movq	-40(%rbp), %rdx
	callq	vatomicptr_cmpxchg
.LBB13_8:                               #   in Loop: Header=BB13_1 Depth=1
	jmp	.LBB13_10
.LBB13_9:                               #   in Loop: Header=BB13_1 Depth=1
	callq	verification_ignore
.LBB13_10:                              #   in Loop: Header=BB13_1 Depth=1
	jmp	.LBB13_1
.Lfunc_end13:
	.size	vqueue_ub_enq, .Lfunc_end13-vqueue_ub_enq
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_exit
	.type	vebr_exit,@function
vebr_exit:                              # @vebr_exit
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	cmpl	$1, 24(%rax)
	jne	.LBB14_2
# %bb.1:
	movq	-16(%rbp), %rdi
	addq	$16, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomic64_write_rel
.LBB14_2:
	movq	-16(%rbp), %rax
	movl	24(%rax), %ecx
	addl	$-1, %ecx
	movl	%ecx, 24(%rax)
# %bb.3:
	jmp	.LBB14_4
.LBB14_4:
# %bb.5:
	jmp	.LBB14_6
.LBB14_6:
	jmp	.LBB14_7
.LBB14_7:
	jmp	.LBB14_8
.LBB14_8:
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end14:
	.size	vebr_exit, .Lfunc_end14-vebr_exit
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_deregister
	.type	vebr_deregister,@function
vebr_deregister:                        # @vebr_deregister
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	72(%rax), %rax
	movq	-8(%rbp), %rcx
	movq	88(%rcx), %rdi
	callq	*%rax
	movq	-8(%rbp), %rdi
	addq	$56, %rdi
	movq	-16(%rbp), %rsi
	callq	dbl_list_rem
	movq	-8(%rbp), %rax
	movq	80(%rax), %rax
	movq	-8(%rbp), %rcx
	movq	88(%rcx), %rdi
	callq	*%rax
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end15:
	.size	vebr_deregister, .Lfunc_end15-vebr_deregister
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$176, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	movl	$0, -116(%rbp)
	movq	$0, -128(%rbp)
	movq	g_lock@GOTPCREL(%rip), %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	pthread_mutex_init@PLT
	movl	%eax, -132(%rbp)
	movq	g_vebr@GOTPCREL(%rip), %rdi
	movq	g_lock_lib@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movq	%rcx, (%rsp)
	movq	8(%rax), %rcx
	movq	%rcx, 8(%rsp)
	movq	16(%rax), %rax
	movq	%rax, 16(%rsp)
	callq	vebr_init
	movq	g_queue@GOTPCREL(%rip), %rdi
	callq	vqueue_ub_init
	movq	$0, -144(%rbp)
.LBB16_1:                               # =>This Inner Loop Header: Depth=1
	cmpq	$12, -144(%rbp)
	jae	.LBB16_4
# %bb.2:                                #   in Loop: Header=BB16_1 Depth=1
	movq	-144(%rbp), %rax
	leaq	-112(%rbp), %rdi
	shlq	$3, %rax
	addq	%rax, %rdi
	movq	-144(%rbp), %rcx
	xorl	%eax, %eax
	movl	%eax, %esi
	movq	run@GOTPCREL(%rip), %rdx
	callq	pthread_create@PLT
# %bb.3:                                #   in Loop: Header=BB16_1 Depth=1
	movq	-144(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -144(%rbp)
	jmp	.LBB16_1
.LBB16_4:
	movq	$1, -152(%rbp)
.LBB16_5:                               # =>This Inner Loop Header: Depth=1
	cmpq	$12, -152(%rbp)
	jae	.LBB16_8
# %bb.6:                                #   in Loop: Header=BB16_5 Depth=1
	movq	-152(%rbp), %rax
	movq	-112(%rbp,%rax,8), %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	pthread_join@PLT
# %bb.7:                                #   in Loop: Header=BB16_5 Depth=1
	movq	-152(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -152(%rbp)
	jmp	.LBB16_5
.LBB16_8:
	movq	g_stop@GOTPCREL(%rip), %rdi
	movl	$1, %esi
	callq	vatomic8_write
	movq	-112(%rbp), %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	pthread_join@PLT
.LBB16_9:                               # =>This Inner Loop Header: Depth=1
	movq	g_queue@GOTPCREL(%rip), %rdi
	movq	destroy_cb@GOTPCREL(%rip), %rsi
	xorl	%eax, %eax
	movl	%eax, %edx
	callq	vqueue_ub_deq
	movq	%rax, -128(%rbp)
	cmpq	$0, -128(%rbp)
	je	.LBB16_11
# %bb.10:                               #   in Loop: Header=BB16_9 Depth=1
	movq	-128(%rbp), %rdi
	callq	free@PLT
	jmp	.LBB16_9
.LBB16_11:
	movq	g_queue@GOTPCREL(%rip), %rdi
	movq	destroy_cb@GOTPCREL(%rip), %rsi
	xorl	%eax, %eax
	movl	%eax, %edx
	callq	vqueue_ub_destroy
	movq	g_vebr@GOTPCREL(%rip), %rdi
	callq	vebr_destroy
	movq	g_lock@GOTPCREL(%rip), %rdi
	callq	pthread_mutex_destroy@PLT
	movl	%eax, -132(%rbp)
	movq	%fs:40, %rax
	movq	-8(%rbp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB16_13
# %bb.12:
	xorl	%eax, %eax
	addq	$176, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB16_13:
	.cfi_def_cfa %rbp, 16
	callq	__stack_chk_fail@PLT
.Lfunc_end16:
	.size	main, .Lfunc_end16-main
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_init
	.type	vebr_init,@function
vebr_init:                              # @vebr_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	leaq	16(%rbp), %rax
	movq	%rax, -24(%rbp)                 # 8-byte Spill
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
	addq	$56, %rdi
	callq	dbl_list_init
	movq	$0, -16(%rbp)
.LBB17_1:                               # =>This Inner Loop Header: Depth=1
	cmpq	$3, -16(%rbp)
	jae	.LBB17_4
# %bb.2:                                #   in Loop: Header=BB17_1 Depth=1
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-16(%rbp), %rax
	shlq	$4, %rax
	addq	%rax, %rdi
	callq	smr_nodes_list_init
# %bb.3:                                #   in Loop: Header=BB17_1 Depth=1
	movq	-16(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -16(%rbp)
	jmp	.LBB17_1
.LBB17_4:
	movq	-8(%rbp), %rdi
	movl	$1, %esi
	callq	vatomic64_write
	movq	-24(%rbp), %rcx                 # 8-byte Reload
	movq	-8(%rbp), %rax
	movq	(%rcx), %rdx
	movq	%rdx, 72(%rax)
	movq	8(%rcx), %rdx
	movq	%rdx, 80(%rax)
	movq	16(%rcx), %rcx
	movq	%rcx, 88(%rax)
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end17:
	.size	vebr_init, .Lfunc_end17-vebr_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_init
	.type	vqueue_ub_init,@function
vqueue_ub_init:                         # @vqueue_ub_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	$0, 16(%rax)
	movq	-8(%rbp), %rdi
	addq	$16, %rdi
	addq	$8, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomicptr_write_rlx
	movq	-8(%rbp), %rdi
	movq	-8(%rbp), %rsi
	addq	$16, %rsi
	callq	vatomicptr_write_rlx
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-8(%rbp), %rsi
	addq	$16, %rsi
	callq	vatomicptr_write_rlx
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end18:
	.size	vqueue_ub_init, .Lfunc_end18-vqueue_ub_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic8_write
	.type	vatomic8_write,@function
vatomic8_write:                         # @vatomic8_write
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movb	%sil, %al
	movq	%rdi, -8(%rbp)
	movb	%al, -9(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movb	-9(%rbp), %al
	movb	%al, -10(%rbp)
	movb	-10(%rbp), %al
	xchgb	%al, (%rcx)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end19:
	.size	vatomic8_write, .Lfunc_end19-vatomic8_write
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vqueue_ub_destroy
	.type	vqueue_ub_destroy,@function
vqueue_ub_destroy:                      # @vqueue_ub_destroy
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-8(%rbp), %rdi
	callq	vatomicptr_read
	movq	%rax, -32(%rbp)
	movq	$0, -40(%rbp)
.LBB20_1:                               # =>This Inner Loop Header: Depth=1
	cmpq	$0, -32(%rbp)
	je	.LBB20_5
# %bb.2:                                #   in Loop: Header=BB20_1 Depth=1
	movq	-32(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomicptr_read
	movq	%rax, -40(%rbp)
	movq	-32(%rbp), %rax
	movq	-8(%rbp), %rcx
	addq	$16, %rcx
	cmpq	%rcx, %rax
	je	.LBB20_4
# %bb.3:                                #   in Loop: Header=BB20_1 Depth=1
	movq	-16(%rbp), %rax
	movq	-32(%rbp), %rdi
	movq	-24(%rbp), %rsi
	callq	*%rax
.LBB20_4:                               #   in Loop: Header=BB20_1 Depth=1
	movq	-40(%rbp), %rax
	movq	%rax, -32(%rbp)
	jmp	.LBB20_1
.LBB20_5:
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end20:
	.size	vqueue_ub_destroy, .Lfunc_end20-vqueue_ub_destroy
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vebr_destroy
	.type	vebr_destroy,@function
vebr_destroy:                           # @vebr_destroy
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	$0, -16(%rbp)
	movq	$0, -24(%rbp)
	movq	$0, -16(%rbp)
.LBB21_1:                               # =>This Inner Loop Header: Depth=1
	cmpq	$3, -16(%rbp)
	jae	.LBB21_4
# %bb.2:                                #   in Loop: Header=BB21_1 Depth=1
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	movq	-16(%rbp), %rax
	shlq	$4, %rax
	addq	%rax, %rdi
	callq	smr_nodes_list_get_and_empty
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rdi
	callq	smr_nodes_list_destroy
# %bb.3:                                #   in Loop: Header=BB21_1 Depth=1
	movq	-16(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -16(%rbp)
	jmp	.LBB21_1
.LBB21_4:
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end21:
	.size	vebr_destroy, .Lfunc_end21-vebr_destroy
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic_fence
	.type	vatomic_fence,@function
vatomic_fence:                          # @vatomic_fence
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	#APP
	#NO_APP
	mfence
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end22:
	.size	vatomic_fence, .Lfunc_end22-vatomic_fence
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_read
	.type	vatomic64_read,@function
vatomic64_read:                         # @vatomic64_read
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, -16(%rbp)
	#APP
	#NO_APP
	movq	-16(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end23:
	.size	vatomic64_read, .Lfunc_end23-vatomic64_read
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function smr_nodes_list_add
	.type	smr_nodes_list_add,@function
smr_nodes_list_add:                     # @smr_nodes_list_add
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	%rcx, -32(%rbp)
	movq	-24(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, 16(%rax)
	movq	-32(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, 24(%rax)
	movq	-16(%rbp), %rax
	movq	$0, (%rax)
	movq	-8(%rbp), %rdi
	movq	-16(%rbp), %rsi
	movq	-16(%rbp), %rdx
	callq	_smr_nodes_list_connect
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	callq	vatomic64_inc_rlx
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end24:
	.size	smr_nodes_list_add, .Lfunc_end24-smr_nodes_list_add
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function _smr_nodes_list_connect
	.type	_smr_nodes_list_connect,@function
_smr_nodes_list_connect:                # @_smr_nodes_list_connect
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$48, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	$0, -32(%rbp)
	movq	$0, -40(%rbp)
	movq	-8(%rbp), %rdi
	callq	vatomicptr_read
	movq	%rax, -32(%rbp)
.LBB25_1:                               # =>This Inner Loop Header: Depth=1
	movq	-32(%rbp), %rax
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-8(%rbp), %rdi
	movq	-40(%rbp), %rsi
	movq	-16(%rbp), %rdx
	callq	vatomicptr_cmpxchg_rel
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rax
	cmpq	-40(%rbp), %rax
	sete	%al
	movzbl	%al, %edi
	andl	$1, %edi
	callq	verification_assume
# %bb.2:                                #   in Loop: Header=BB25_1 Depth=1
	movq	-40(%rbp), %rax
	cmpq	-32(%rbp), %rax
	jne	.LBB25_1
# %bb.3:
	addq	$48, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end25:
	.size	_smr_nodes_list_connect, .Lfunc_end25-_smr_nodes_list_connect
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_inc_rlx
	.type	vatomic64_inc_rlx,@function
vatomic64_inc_rlx:                      # @vatomic64_inc_rlx
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
	callq	vatomic64_get_inc_rlx
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end26:
	.size	vatomic64_inc_rlx, .Lfunc_end26-vatomic64_inc_rlx
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_read
	.type	vatomicptr_read,@function
vatomicptr_read:                        # @vatomicptr_read
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	movq	%rax, -16(%rbp)
	#APP
	#NO_APP
	movq	-16(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end27:
	.size	vatomicptr_read, .Lfunc_end27-vatomicptr_read
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_cmpxchg_rel
	.type	vatomicptr_cmpxchg_rel,@function
vatomicptr_cmpxchg_rel:                 # @vatomicptr_cmpxchg_rel
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, -32(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rax, -40(%rbp)
	movq	-32(%rbp), %rax
	movq	-40(%rbp), %rdx
	lock		cmpxchgq	%rdx, (%rcx)
	movq	%rax, %rcx
	sete	%al
	movb	%al, -57(%rbp)                  # 1-byte Spill
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	testb	$1, %al
	jne	.LBB28_2
# %bb.1:
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -32(%rbp)
.LBB28_2:
	movb	-57(%rbp), %al                  # 1-byte Reload
	andb	$1, %al
	movb	%al, -41(%rbp)
	#APP
	#NO_APP
	movq	-32(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end28:
	.size	vatomicptr_cmpxchg_rel, .Lfunc_end28-vatomicptr_cmpxchg_rel
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function verification_assume
	.type	verification_assume,@function
verification_assume:                    # @verification_assume
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movb	%dil, %al
	andb	$1, %al
	movb	%al, -1(%rbp)
# %bb.1:
	jmp	.LBB29_2
.LBB29_2:
# %bb.3:
	jmp	.LBB29_4
.LBB29_4:
	jmp	.LBB29_5
.LBB29_5:
	jmp	.LBB29_6
.LBB29_6:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end29:
	.size	verification_assume, .Lfunc_end29-verification_assume
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_get_inc_rlx
	.type	vatomic64_get_inc_rlx,@function
vatomic64_get_inc_rlx:                  # @vatomic64_get_inc_rlx
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
	movl	$1, %esi
	callq	vatomic64_get_add_rlx
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end30:
	.size	vatomic64_get_inc_rlx, .Lfunc_end30-vatomic64_get_inc_rlx
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_get_add_rlx
	.type	vatomic64_get_add_rlx,@function
vatomic64_get_add_rlx:                  # @vatomic64_get_add_rlx
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rax
	lock		xaddq	%rax, (%rcx)
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -24(%rbp)
	#APP
	#NO_APP
	movq	-24(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end31:
	.size	vatomic64_get_add_rlx, .Lfunc_end31-vatomic64_get_add_rlx
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function smr_nodes_list_get_and_empty
	.type	smr_nodes_list_get_and_empty,@function
smr_nodes_list_get_and_empty:           # @smr_nodes_list_get_and_empty
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomicptr_xchg_acq
	movq	%rax, -16(%rbp)
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomic64_write_rlx
	movq	-16(%rbp), %rax
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end32:
	.size	smr_nodes_list_get_and_empty, .Lfunc_end32-smr_nodes_list_get_and_empty
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function _vebr_sync_epochs
	.type	_vebr_sync_epochs,@function
_vebr_sync_epochs:                      # @_vebr_sync_epochs
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$96, %rsp
	movb	%dl, %al
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	andb	$1, %al
	movb	%al, -17(%rbp)
	movq	$0, -32(%rbp)
	movq	$0, -40(%rbp)
	movq	$0, -48(%rbp)
	movq	$-1, -56(%rbp)
	movq	-8(%rbp), %rax
	movq	72(%rax), %rax
	movq	-8(%rbp), %rcx
	movq	88(%rcx), %rdi
	callq	*%rax
	movq	-8(%rbp), %rax
	movq	56(%rax), %rax
	movq	%rax, -32(%rbp)
.LBB33_1:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB33_3 Depth 2
	cmpq	$0, -32(%rbp)
	je	.LBB33_19
# %bb.2:                                #   in Loop: Header=BB33_1 Depth=1
	movq	-32(%rbp), %rax
	movq	%rax, -40(%rbp)
.LBB33_3:                               #   Parent Loop BB33_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	-40(%rbp), %rdi
	addq	$16, %rdi
	callq	vatomic64_read
	movq	%rax, -48(%rbp)
	cmpq	$0, -48(%rbp)
	jne	.LBB33_5
# %bb.4:                                #   in Loop: Header=BB33_1 Depth=1
	jmp	.LBB33_17
.LBB33_5:                               #   in Loop: Header=BB33_3 Depth=2
	movq	-48(%rbp), %rax
	cmpq	-16(%rbp), %rax
	jb	.LBB33_10
# %bb.6:                                #   in Loop: Header=BB33_1 Depth=1
	movq	-56(%rbp), %rax
	movq	%rax, -64(%rbp)
	movq	-48(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-64(%rbp), %rax
	cmpq	-72(%rbp), %rax
	jae	.LBB33_8
# %bb.7:                                #   in Loop: Header=BB33_1 Depth=1
	movq	-64(%rbp), %rax
	movq	%rax, -88(%rbp)                 # 8-byte Spill
	jmp	.LBB33_9
.LBB33_8:                               #   in Loop: Header=BB33_1 Depth=1
	movq	-72(%rbp), %rax
	movq	%rax, -88(%rbp)                 # 8-byte Spill
.LBB33_9:                               #   in Loop: Header=BB33_1 Depth=1
	movq	-88(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -80(%rbp)
	movq	-80(%rbp), %rax
	movq	%rax, -56(%rbp)
	jmp	.LBB33_17
.LBB33_10:                              #   in Loop: Header=BB33_3 Depth=2
	testb	$1, -17(%rbp)
	jne	.LBB33_12
# %bb.11:
	movq	-48(%rbp), %rax
	movq	%rax, -56(%rbp)
	jmp	.LBB33_20
.LBB33_12:                              #   in Loop: Header=BB33_3 Depth=2
	callq	verification_ignore
# %bb.13:                               #   in Loop: Header=BB33_3 Depth=2
	jmp	.LBB33_14
.LBB33_14:                              #   in Loop: Header=BB33_3 Depth=2
	jmp	.LBB33_15
.LBB33_15:                              #   in Loop: Header=BB33_3 Depth=2
	jmp	.LBB33_16
.LBB33_16:                              #   in Loop: Header=BB33_3 Depth=2
	movb	$1, %al
	testb	$1, %al
	jne	.LBB33_3
	jmp	.LBB33_17
.LBB33_17:                              #   in Loop: Header=BB33_1 Depth=1
	jmp	.LBB33_18
.LBB33_18:                              #   in Loop: Header=BB33_1 Depth=1
	movq	-32(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -32(%rbp)
	jmp	.LBB33_1
.LBB33_19:
	jmp	.LBB33_20
.LBB33_20:
	movq	-8(%rbp), %rax
	movq	80(%rax), %rax
	movq	-8(%rbp), %rcx
	movq	88(%rcx), %rdi
	callq	*%rax
	cmpq	$-1, -56(%rbp)
	jne	.LBB33_22
# %bb.21:
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
	movq	%rax, -96(%rbp)                 # 8-byte Spill
	jmp	.LBB33_23
.LBB33_22:
	movq	-56(%rbp), %rax
	movq	%rax, -96(%rbp)                 # 8-byte Spill
.LBB33_23:
	movq	-96(%rbp), %rax                 # 8-byte Reload
	addq	$96, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end33:
	.size	_vebr_sync_epochs, .Lfunc_end33-_vebr_sync_epochs
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_cmpxchg
	.type	vatomic64_cmpxchg,@function
vatomic64_cmpxchg:                      # @vatomic64_cmpxchg
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, -32(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rax, -40(%rbp)
	movq	-32(%rbp), %rax
	movq	-40(%rbp), %rdx
	lock		cmpxchgq	%rdx, (%rcx)
	movq	%rax, %rcx
	sete	%al
	movb	%al, -57(%rbp)                  # 1-byte Spill
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	testb	$1, %al
	jne	.LBB34_2
# %bb.1:
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -32(%rbp)
.LBB34_2:
	movb	-57(%rbp), %al                  # 1-byte Reload
	andb	$1, %al
	movb	%al, -41(%rbp)
	#APP
	#NO_APP
	movq	-32(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end34:
	.size	vatomic64_cmpxchg, .Lfunc_end34-vatomic64_cmpxchg
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function smr_nodes_list_destroy
	.type	smr_nodes_list_destroy,@function
smr_nodes_list_destroy:                 # @smr_nodes_list_destroy
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	$0, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	$0, -32(%rbp)
.LBB35_1:                               # =>This Inner Loop Header: Depth=1
	cmpq	$0, -24(%rbp)
	je	.LBB35_3
# %bb.2:                                #   in Loop: Header=BB35_1 Depth=1
	movq	-24(%rbp), %rax
	movq	%rax, -32(%rbp)
	movq	-24(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -24(%rbp)
	movq	-32(%rbp), %rax
	movq	16(%rax), %rax
	movq	-32(%rbp), %rdi
	movq	-32(%rbp), %rcx
	movq	24(%rcx), %rsi
	callq	*%rax
	movq	-16(%rbp), %rax
	addq	$1, %rax
	movq	%rax, -16(%rbp)
	jmp	.LBB35_1
.LBB35_3:
	movq	-16(%rbp), %rax
	addq	$32, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end35:
	.size	smr_nodes_list_destroy, .Lfunc_end35-smr_nodes_list_destroy
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_xchg_acq
	.type	vatomicptr_xchg_acq,@function
vatomicptr_xchg_acq:                    # @vatomicptr_xchg_acq
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rax
	xchgq	%rax, (%rcx)
	movq	%rax, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -24(%rbp)
	#APP
	#NO_APP
	movq	-24(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end36:
	.size	vatomicptr_xchg_acq, .Lfunc_end36-vatomicptr_xchg_acq
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_write_rlx
	.type	vatomic64_write_rlx,@function
vatomic64_write_rlx:                    # @vatomic64_write_rlx
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rcx
	movq	%rcx, -24(%rbp)
	movq	-24(%rbp), %rcx
	movq	%rcx, (%rax)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end37:
	.size	vatomic64_write_rlx, .Lfunc_end37-vatomic64_write_rlx
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function verification_ignore
	.type	verification_ignore,@function
verification_ignore:                    # @verification_ignore
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end38:
	.size	verification_ignore, .Lfunc_end38-verification_ignore
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_init
	.type	vatomic64_init,@function
vatomic64_init:                         # @vatomic64_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	movq	-16(%rbp), %rsi
	callq	vatomic64_write
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end39:
	.size	vatomic64_init, .Lfunc_end39-vatomic64_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function dbl_list_add
	.type	dbl_list_add,@function
dbl_list_add:                           # @dbl_list_add
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rax
	movq	(%rax), %rcx
	movq	-16(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-8(%rbp), %rax
	cmpq	$0, (%rax)
	je	.LBB40_2
# %bb.1:
	movq	-16(%rbp), %rcx
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	%rcx, 8(%rax)
.LBB40_2:
	movq	-16(%rbp), %rcx
	movq	-8(%rbp), %rax
	movq	%rcx, (%rax)
	movq	-16(%rbp), %rax
	movq	$0, 8(%rax)
	movq	-8(%rbp), %rax
	movq	8(%rax), %rcx
	addq	$1, %rcx
	movq	%rcx, 8(%rax)
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end40:
	.size	dbl_list_add, .Lfunc_end40-dbl_list_add
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_write
	.type	vatomic64_write,@function
vatomic64_write:                        # @vatomic64_write
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	xchgq	%rax, (%rcx)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end41:
	.size	vatomic64_write, .Lfunc_end41-vatomic64_write
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomic64_write_rel
	.type	vatomic64_write_rel,@function
vatomic64_write_rel:                    # @vatomic64_write_rel
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rcx
	movq	%rcx, -24(%rbp)
	movq	-24(%rbp), %rcx
	movq	%rcx, (%rax)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end42:
	.size	vatomic64_write_rel, .Lfunc_end42-vatomic64_write_rel
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_cmpxchg
	.type	vatomicptr_cmpxchg,@function
vatomicptr_cmpxchg:                     # @vatomicptr_cmpxchg
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	movq	-16(%rbp), %rax
	movq	%rax, -32(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rax, -40(%rbp)
	movq	-32(%rbp), %rax
	movq	-40(%rbp), %rdx
	lock		cmpxchgq	%rdx, (%rcx)
	movq	%rax, %rcx
	sete	%al
	movb	%al, -57(%rbp)                  # 1-byte Spill
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	testb	$1, %al
	jne	.LBB43_2
# %bb.1:
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -32(%rbp)
.LBB43_2:
	movb	-57(%rbp), %al                  # 1-byte Reload
	andb	$1, %al
	movb	%al, -41(%rbp)
	#APP
	#NO_APP
	movq	-32(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end43:
	.size	vatomicptr_cmpxchg, .Lfunc_end43-vatomicptr_cmpxchg
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_write_rlx
	.type	vatomicptr_write_rlx,@function
vatomicptr_write_rlx:                   # @vatomicptr_write_rlx
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rcx
	movq	%rcx, -24(%rbp)
	movq	-24(%rbp), %rcx
	movq	%rcx, (%rax)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end44:
	.size	vatomicptr_write_rlx, .Lfunc_end44-vatomicptr_write_rlx
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function dbl_list_rem
	.type	dbl_list_rem,@function
dbl_list_rem:                           # @dbl_list_rem
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-16(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -24(%rbp)
	movq	-16(%rbp), %rax
	movq	8(%rax), %rax
	movq	%rax, -32(%rbp)
	cmpq	$0, -32(%rbp)
	je	.LBB45_2
# %bb.1:
	movq	-24(%rbp), %rcx
	movq	-32(%rbp), %rax
	movq	%rcx, (%rax)
	jmp	.LBB45_3
.LBB45_2:
	movq	-24(%rbp), %rcx
	movq	-8(%rbp), %rax
	movq	%rcx, (%rax)
.LBB45_3:
	cmpq	$0, -24(%rbp)
	je	.LBB45_5
# %bb.4:
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, 8(%rax)
.LBB45_5:
	movq	-8(%rbp), %rax
	movq	8(%rax), %rcx
	addq	$-1, %rcx
	movq	%rcx, 8(%rax)
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end45:
	.size	dbl_list_rem, .Lfunc_end45-dbl_list_rem
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function dbl_list_init
	.type	dbl_list_init,@function
dbl_list_init:                          # @dbl_list_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	$0, (%rax)
	movq	-8(%rbp), %rax
	movq	$0, 8(%rax)
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end46:
	.size	dbl_list_init, .Lfunc_end46-dbl_list_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function smr_nodes_list_init
	.type	smr_nodes_list_init,@function
smr_nodes_list_init:                    # @smr_nodes_list_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomicptr_init
	movq	-8(%rbp), %rdi
	addq	$8, %rdi
	xorl	%eax, %eax
	movl	%eax, %esi
	callq	vatomic64_init
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end47:
	.size	smr_nodes_list_init, .Lfunc_end47-smr_nodes_list_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_init
	.type	vatomicptr_init,@function
vatomicptr_init:                        # @vatomicptr_init
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	-8(%rbp), %rdi
	movq	-16(%rbp), %rsi
	callq	vatomicptr_write
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end48:
	.size	vatomicptr_init, .Lfunc_end48-vatomicptr_init
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function vatomicptr_write
	.type	vatomicptr_write,@function
vatomicptr_write:                       # @vatomicptr_write
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	#APP
	#NO_APP
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	-24(%rbp), %rax
	xchgq	%rax, (%rcx)
	#APP
	#NO_APP
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end49:
	.size	vatomicptr_write, .Lfunc_end49-vatomicptr_write
	.cfi_endproc
                                        # -- End function
	.type	g_lock,@object                  # @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	40
	.size	g_lock, 40

	.type	g_lock_lib,@object              # @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.quad	lock_acq
	.quad	lock_rel
	.quad	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  # @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  # @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 # @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym free
	.addrsig_sym retire_cb
	.addrsig_sym vebr_retire
	.addrsig_sym destroy_cb
	.addrsig_sym reclaim
	.addrsig_sym vatomic8_read
	.addrsig_sym vebr_recycle
	.addrsig_sym printf
	.addrsig_sym run
	.addrsig_sym vebr_register
	.addrsig_sym vebr_enter
	.addrsig_sym vqueue_ub_deq
	.addrsig_sym malloc
	.addrsig_sym vqueue_ub_enq
	.addrsig_sym vebr_exit
	.addrsig_sym vebr_deregister
	.addrsig_sym pthread_mutex_init
	.addrsig_sym vebr_init
	.addrsig_sym vqueue_ub_init
	.addrsig_sym pthread_create
	.addrsig_sym pthread_join
	.addrsig_sym vatomic8_write
	.addrsig_sym vqueue_ub_destroy
	.addrsig_sym vebr_destroy
	.addrsig_sym pthread_mutex_destroy
	.addrsig_sym pthread_mutex_lock
	.addrsig_sym pthread_mutex_unlock
	.addrsig_sym vatomic_fence
	.addrsig_sym vatomic64_read
	.addrsig_sym smr_nodes_list_add
	.addrsig_sym _smr_nodes_list_connect
	.addrsig_sym vatomic64_inc_rlx
	.addrsig_sym vatomicptr_read
	.addrsig_sym vatomicptr_cmpxchg_rel
	.addrsig_sym verification_assume
	.addrsig_sym vatomic64_get_inc_rlx
	.addrsig_sym vatomic64_get_add_rlx
	.addrsig_sym smr_nodes_list_get_and_empty
	.addrsig_sym _vebr_sync_epochs
	.addrsig_sym vatomic64_cmpxchg
	.addrsig_sym smr_nodes_list_destroy
	.addrsig_sym vatomicptr_xchg_acq
	.addrsig_sym vatomic64_write_rlx
	.addrsig_sym verification_ignore
	.addrsig_sym vatomic64_init
	.addrsig_sym dbl_list_add
	.addrsig_sym vatomic64_write
	.addrsig_sym vatomic64_write_rel
	.addrsig_sym vatomicptr_cmpxchg
	.addrsig_sym vatomicptr_write_rlx
	.addrsig_sym dbl_list_rem
	.addrsig_sym dbl_list_init
	.addrsig_sym smr_nodes_list_init
	.addrsig_sym vatomicptr_init
	.addrsig_sym vatomicptr_write
	.addrsig_sym __stack_chk_fail
	.addrsig_sym g_lock
	.addrsig_sym g_lock_lib
	.addrsig_sym g_vebr
	.addrsig_sym g_stop
	.addrsig_sym g_queue
