	.file	"eg_vebr.c"
	.text
	.p2align	2                               // -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               // @lock_acq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	bl	pthread_mutex_lock
	str	w0, [sp, #12]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               // @lock_rel
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	bl	pthread_mutex_unlock
	str	w0, [sp, #12]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        // -- End function
	.globl	free_cb                         // -- Begin function free_cb
	.p2align	2
	.type	free_cb,@function
free_cb:                                // @free_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	subs	x8, x8, #16
	str	x8, [sp, #8]
	ldr	x0, [sp, #8]
	bl	free
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x1, [sp, #8]
	ldur	x8, [x29, #-8]
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	add	x2, x8, #16
	adrp	x3, :got:free_cb
	ldr	x3, [x3, :got_lo12:free_cb]
	mov	x4, xzr
	bl	vebr_retire
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_retire
	.type	vebr_retire,@function
vebr_retire:                            // @vebr_retire
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	str	x3, [sp, #32]
	str	x4, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	bl	vatomic_fence
	ldur	x0, [x29, #-8]
	bl	vatomic64_read
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	mov	x10, #3                         // =0x3
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	str	x8, [sp, #8]
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	ldur	x1, [x29, #-24]
	ldr	x2, [sp, #32]
	ldr	x3, [sp, #24]
	add	x8, x8, #8
	add	x0, x8, x9, lsl #4
	bl	smr_nodes_list_add
	b	.LBB4_1
.LBB4_1:
	b	.LBB4_2
.LBB4_2:
	b	.LBB4_3
.LBB4_3:
	b	.LBB4_4
.LBB4_4:
	b	.LBB4_5
.LBB4_5:
	b	.LBB4_6
.LBB4_6:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end4:
	.size	vebr_retire, .Lfunc_end4-vebr_retire
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	bl	free
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end5:
	.size	destroy_cb, .Lfunc_end5-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	reclaim                         // -- Begin function reclaim
	.p2align	2
	.type	reclaim,@function
reclaim:                                // @reclaim
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	b	.LBB6_1
.LBB6_1:                                // =>This Inner Loop Header: Depth=1
	adrp	x0, :got:g_stop
	ldr	x0, [x0, :got_lo12:g_stop]
	bl	vatomic8_read
	and	w8, w0, #0xff
	cbnz	w8, .LBB6_5
	b	.LBB6_2
.LBB6_2:                                //   in Loop: Header=BB6_1 Depth=1
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	bl	vebr_recycle
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #0
	b.ls	.LBB6_4
	b	.LBB6_3
.LBB6_3:                                //   in Loop: Header=BB6_1 Depth=1
	ldr	x1, [sp, #8]
	adrp	x0, .L.str
	add	x0, x0, :lo12:.L.str
	bl	printf
	b	.LBB6_4
.LBB6_4:                                //   in Loop: Header=BB6_1 Depth=1
	b	.LBB6_1
.LBB6_5:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end6:
	.size	reclaim, .Lfunc_end6-reclaim
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic8_read
	.type	vatomic8_read,@function
vatomic8_read:                          // @vatomic8_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	//APP
	//NO_APP
	ldr	x8, [sp, #8]
	ldarb	w8, [x8]
	strb	w8, [sp, #6]
	ldrb	w8, [sp, #6]
	strb	w8, [sp, #7]
	//APP
	//NO_APP
	ldrb	w0, [sp, #7]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end7:
	.size	vatomic8_read, .Lfunc_end7-vatomic8_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_recycle
	.type	vebr_recycle,@function
vebr_recycle:                           // @vebr_recycle
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	xzr, [x29, #-16]
	stur	xzr, [x29, #-24]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	bl	vatomic_fence
	ldur	x0, [x29, #-8]
	bl	vatomic64_read
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	add	x8, x8, #2
	mov	x10, #3                         // =0x3
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-8]
	ldur	x9, [x29, #-24]
	add	x8, x8, #8
	add	x0, x8, x9, lsl #4
	bl	smr_nodes_list_get_and_empty
	str	x0, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #32]
	mov	w8, #1                          // =0x1
	and	w2, w8, #0x1
	bl	_vebr_sync_epochs
	str	x0, [sp, #16]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #32]
	ldr	x8, [sp, #32]
	add	x2, x8, #1
	bl	vatomic64_cmpxchg
	str	x0, [sp, #24]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB8_2
	b	.LBB8_1
.LBB8_1:
	ldr	x0, [sp, #8]
	bl	smr_nodes_list_destroy
	stur	x0, [x29, #-16]
	b	.LBB8_2
.LBB8_2:
	ldur	x0, [x29, #-16]
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end8:
	.size	vebr_recycle, .Lfunc_end8-vebr_recycle
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #48]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	ldr	x8, [sp, #48]
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, .LBB9_2
	b	.LBB9_1
.LBB9_1:
	bl	reclaim
	b	.LBB9_10
.LBB9_2:
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	bl	vebr_register
	str	xzr, [sp, #24]
	b	.LBB9_3
.LBB9_3:                                // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	mov	x9, #10000                      // =0x2710
	subs	x8, x8, x9
	b.hs	.LBB9_9
	b	.LBB9_4
.LBB9_4:                                //   in Loop: Header=BB9_3 Depth=1
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	str	x1, [sp, #8]                    // 8-byte Folded Spill
	bl	vebr_enter
	ldr	x2, [sp, #8]                    // 8-byte Folded Reload
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:retire_cb
	ldr	x1, [x1, :got_lo12:retire_cb]
	bl	vqueue_ub_deq
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, .LBB9_6
	b	.LBB9_5
.LBB9_5:                                //   in Loop: Header=BB9_3 Depth=1
	mov	x0, #8                          // =0x8
	bl	malloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #40]
	str	x8, [x9]
	mov	x0, #48                         // =0x30
	bl	malloc
	str	x0, [sp, #16]
	ldr	x1, [sp, #32]
	ldr	x8, [sp, #40]
	ldr	x2, [x8]
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	bl	printf
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #40]
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	bl	vqueue_ub_enq
	b	.LBB9_7
.LBB9_6:                                //   in Loop: Header=BB9_3 Depth=1
	ldr	x1, [sp, #32]
	ldr	x8, [sp, #40]
	ldr	x2, [x8]
	adrp	x0, .L.str.2
	add	x0, x0, :lo12:.L.str.2
	bl	printf
	ldr	x0, [sp, #40]
	bl	free
	b	.LBB9_7
.LBB9_7:                                //   in Loop: Header=BB9_3 Depth=1
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	bl	vebr_exit
	b	.LBB9_8
.LBB9_8:                                //   in Loop: Header=BB9_3 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	.LBB9_3
.LBB9_9:
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	bl	vebr_deregister
	b	.LBB9_10
.LBB9_10:
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB9_12
	b	.LBB9_11
.LBB9_11:
	bl	__stack_chk_fail
.LBB9_12:
	mov	x0, xzr
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end9:
	.size	run, .Lfunc_end9-run
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_register
	.type	vebr_register,@function
vebr_register:                          // @vebr_register
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	add	x0, x8, #16
	mov	x1, xzr
	bl	vatomic64_init
	ldr	x8, [sp]
	str	wzr, [x8, #24]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	ldr	x8, [sp, #8]
	ldr	x1, [sp]
	add	x0, x8, #56
	bl	dbl_list_add
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #80]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end10:
	.size	vebr_register, .Lfunc_end10-vebr_register
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_enter
	.type	vebr_enter,@function
vebr_enter:                             // @vebr_enter
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	xzr, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	w8, [x9, #24]
	add	w8, w8, #1
	str	w8, [x9, #24]
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.ne	.LBB11_2
	b	.LBB11_1
.LBB11_1:
	ldur	x0, [x29, #-8]
	bl	vatomic64_read
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	add	x0, x8, #16
	ldr	x1, [sp, #8]
	bl	vatomic64_write_rel
	bl	vatomic_fence
	b	.LBB11_2
.LBB11_2:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end11:
	.size	vebr_enter, .Lfunc_end11-vebr_enter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_deq
	.type	vqueue_ub_deq,@function
vqueue_ub_deq:                          // @vqueue_ub_deq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x29, x30, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	b	.LBB12_1
.LBB12_1:                               // =>This Inner Loop Header: Depth=1
	ldur	x0, [x29, #-16]
	bl	vatomicptr_read
	str	x0, [sp, #40]
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #32]
	ldr	x8, [sp, #40]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #24]
	ldr	x8, [sp, #40]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	bl	vatomicptr_read
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	subs	x8, x8, x0
	b.ne	.LBB12_13
	b	.LBB12_2
.LBB12_2:                               //   in Loop: Header=BB12_1 Depth=1
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.ne	.LBB12_6
	b	.LBB12_3
.LBB12_3:                               //   in Loop: Header=BB12_1 Depth=1
	ldr	x8, [sp, #24]
	cbnz	x8, .LBB12_5
	b	.LBB12_4
.LBB12_4:
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	.LBB12_15
.LBB12_5:                               //   in Loop: Header=BB12_1 Depth=1
	bl	verification_ignore
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #24]
	bl	vatomicptr_cmpxchg
	b	.LBB12_12
.LBB12_6:                               //   in Loop: Header=BB12_1 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	str	x8, [sp, #16]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #40]
	ldr	x2, [sp, #24]
	bl	vatomicptr_cmpxchg
	ldr	x8, [sp, #40]
	subs	x8, x0, x8
	b.ne	.LBB12_10
	b	.LBB12_7
.LBB12_7:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-16]
	add	x9, x9, #16
	subs	x8, x8, x9
	b.eq	.LBB12_9
	b	.LBB12_8
.LBB12_8:
	ldur	x8, [x29, #-24]
	ldr	x0, [sp, #40]
	ldur	x1, [x29, #-32]
	blr	x8
	b	.LBB12_9
.LBB12_9:
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	.LBB12_15
.LBB12_10:                              //   in Loop: Header=BB12_1 Depth=1
	bl	verification_ignore
	b	.LBB12_11
.LBB12_11:                              //   in Loop: Header=BB12_1 Depth=1
	b	.LBB12_12
.LBB12_12:                              //   in Loop: Header=BB12_1 Depth=1
	b	.LBB12_14
.LBB12_13:                              //   in Loop: Header=BB12_1 Depth=1
	bl	verification_ignore
	b	.LBB12_14
.LBB12_14:                              //   in Loop: Header=BB12_1 Depth=1
	b	.LBB12_1
.LBB12_15:
	ldur	x0, [x29, #-8]
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]             // 16-byte Folded Reload
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end12:
	.size	vqueue_ub_deq, .Lfunc_end12-vqueue_ub_deq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_enq
	.type	vqueue_ub_enq,@function
vqueue_ub_enq:                          // @vqueue_ub_enq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	mov	x1, xzr
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	strb	wzr, [sp, #23]
	ldur	x8, [x29, #-24]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	bl	vatomicptr_write_rlx
	b	.LBB13_1
.LBB13_1:                               // =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #24]
	ldr	x8, [sp, #32]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	bl	vatomicptr_read
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	subs	x8, x8, x0
	b.ne	.LBB13_9
	b	.LBB13_2
.LBB13_2:                               //   in Loop: Header=BB13_1 Depth=1
	ldr	x8, [sp, #24]
	cbnz	x8, .LBB13_7
	b	.LBB13_3
.LBB13_3:                               //   in Loop: Header=BB13_1 Depth=1
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	ldr	x1, [sp, #24]
	ldur	x2, [x29, #-16]
	bl	vatomicptr_cmpxchg
	ldr	x8, [sp, #24]
	subs	x8, x0, x8
	b.ne	.LBB13_5
	b	.LBB13_4
.LBB13_4:
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	ldr	x1, [sp, #32]
	ldur	x2, [x29, #-16]
	bl	vatomicptr_cmpxchg
	ldr	x8, [sp, #32]
	subs	x8, x0, x8
	cset	w8, eq
	strb	w8, [sp, #23]
	ldrb	w8, [sp, #23]
	and	w0, w8, #0x1
	bl	verification_assume
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB13_5:                               //   in Loop: Header=BB13_1 Depth=1
	.cfi_restore_state
	bl	verification_ignore
	b	.LBB13_6
.LBB13_6:                               //   in Loop: Header=BB13_1 Depth=1
	b	.LBB13_8
.LBB13_7:                               //   in Loop: Header=BB13_1 Depth=1
	bl	verification_ignore
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #24]
	bl	vatomicptr_cmpxchg
	b	.LBB13_8
.LBB13_8:                               //   in Loop: Header=BB13_1 Depth=1
	b	.LBB13_10
.LBB13_9:                               //   in Loop: Header=BB13_1 Depth=1
	bl	verification_ignore
	b	.LBB13_10
.LBB13_10:                              //   in Loop: Header=BB13_1 Depth=1
	b	.LBB13_1
.Lfunc_end13:
	.size	vqueue_ub_enq, .Lfunc_end13-vqueue_ub_enq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_exit
	.type	vebr_exit,@function
vebr_exit:                              // @vebr_exit
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.ne	.LBB14_2
	b	.LBB14_1
.LBB14_1:
	ldr	x8, [sp]
	add	x0, x8, #16
	mov	x1, xzr
	bl	vatomic64_write_rel
	b	.LBB14_2
.LBB14_2:
	ldr	x9, [sp]
	ldr	w8, [x9, #24]
	subs	w8, w8, #1
	str	w8, [x9, #24]
	b	.LBB14_3
.LBB14_3:
	b	.LBB14_4
.LBB14_4:
	b	.LBB14_5
.LBB14_5:
	b	.LBB14_6
.LBB14_6:
	b	.LBB14_7
.LBB14_7:
	b	.LBB14_8
.LBB14_8:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end14:
	.size	vebr_exit, .Lfunc_end14-vebr_exit
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_deregister
	.type	vebr_deregister,@function
vebr_deregister:                        // @vebr_deregister
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	ldr	x8, [sp, #8]
	ldr	x1, [sp]
	add	x0, x8, #56
	bl	dbl_list_rem
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #80]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end15:
	.size	vebr_deregister, .Lfunc_end15-vebr_deregister
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #192
	.cfi_def_cfa_offset 192
	stp	x29, x30, [sp, #176]            // 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	wzr, [sp, #44]
	mov	x1, xzr
	str	xzr, [sp, #32]
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_init
	str	w0, [sp, #28]
	adrp	x8, :got:g_lock_lib
	ldr	x8, [x8, :got_lo12:g_lock_lib]
	ldr	q0, [x8]
	add	x1, sp, #48
	str	q0, [sp, #48]
	ldr	x8, [x8, #16]
	str	x8, [sp, #64]
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	bl	vebr_init
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	bl	vqueue_ub_init
	str	xzr, [sp, #16]
	b	.LBB16_1
.LBB16_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #12
	b.hs	.LBB16_4
	b	.LBB16_2
.LBB16_2:                               //   in Loop: Header=BB16_1 Depth=1
	ldr	x9, [sp, #16]
	add	x8, sp, #72
	add	x0, x8, x9, lsl #3
	ldr	x3, [sp, #16]
	mov	x1, xzr
	adrp	x2, :got:run
	ldr	x2, [x2, :got_lo12:run]
	bl	pthread_create
	b	.LBB16_3
.LBB16_3:                               //   in Loop: Header=BB16_1 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB16_1
.LBB16_4:
	mov	x8, #1                          // =0x1
	str	x8, [sp, #8]
	b	.LBB16_5
.LBB16_5:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	subs	x8, x8, #12
	b.hs	.LBB16_8
	b	.LBB16_6
.LBB16_6:                               //   in Loop: Header=BB16_5 Depth=1
	ldr	x9, [sp, #8]
	add	x8, sp, #72
	ldr	x0, [x8, x9, lsl #3]
	mov	x1, xzr
	bl	pthread_join
	b	.LBB16_7
.LBB16_7:                               //   in Loop: Header=BB16_5 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB16_5
.LBB16_8:
	adrp	x0, :got:g_stop
	ldr	x0, [x0, :got_lo12:g_stop]
	mov	w1, #1                          // =0x1
	bl	vatomic8_write
	ldr	x0, [sp, #72]
	mov	x1, xzr
	bl	pthread_join
	b	.LBB16_9
.LBB16_9:                               // =>This Inner Loop Header: Depth=1
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:destroy_cb
	ldr	x1, [x1, :got_lo12:destroy_cb]
	mov	x2, xzr
	bl	vqueue_ub_deq
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbz	x8, .LBB16_11
	b	.LBB16_10
.LBB16_10:                              //   in Loop: Header=BB16_9 Depth=1
	ldr	x0, [sp, #32]
	bl	free
	b	.LBB16_9
.LBB16_11:
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:destroy_cb
	ldr	x1, [x1, :got_lo12:destroy_cb]
	mov	x2, xzr
	bl	vqueue_ub_destroy
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	bl	vebr_destroy
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_destroy
	str	w0, [sp, #28]
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB16_13
	b	.LBB16_12
.LBB16_12:
	bl	__stack_chk_fail
.LBB16_13:
	mov	w0, wzr
	.cfi_def_cfa wsp, 192
	ldp	x29, x30, [sp, #176]            // 16-byte Folded Reload
	add	sp, sp, #192
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end16:
	.size	main, .Lfunc_end16-main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_init
	.type	vebr_init,@function
vebr_init:                              // @vebr_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp]                        // 8-byte Folded Spill
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	add	x0, x8, #56
	bl	dbl_list_init
	str	xzr, [sp, #8]
	b	.LBB17_1
.LBB17_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	subs	x8, x8, #3
	b.hs	.LBB17_4
	b	.LBB17_2
.LBB17_2:                               //   in Loop: Header=BB17_1 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #8
	ldr	x9, [sp, #8]
	add	x0, x8, x9, lsl #4
	bl	smr_nodes_list_init
	b	.LBB17_3
.LBB17_3:                               //   in Loop: Header=BB17_1 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB17_1
.LBB17_4:
	ldur	x0, [x29, #-8]
	mov	x1, #1                          // =0x1
	bl	vatomic64_write
	ldr	x8, [sp]                        // 8-byte Folded Reload
	ldur	x9, [x29, #-8]
	ldr	q0, [x8]
	stur	q0, [x9, #72]
	ldr	x8, [x8, #16]
	str	x8, [x9, #88]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end17:
	.size	vebr_init, .Lfunc_end17-vebr_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_init
	.type	vqueue_ub_init,@function
vqueue_ub_init:                         // @vqueue_ub_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	x1, xzr
	str	xzr, [x8, #16]
	ldr	x8, [sp, #8]
	add	x0, x8, #24
	bl	vatomicptr_write_rlx
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #8]
	add	x1, x8, #16
	bl	vatomicptr_write_rlx
	ldr	x9, [sp, #8]
	ldr	x8, [sp, #8]
	add	x0, x9, #8
	add	x1, x8, #16
	bl	vatomicptr_write_rlx
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end18:
	.size	vqueue_ub_init, .Lfunc_end18-vqueue_ub_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic8_write
	.type	vatomic8_write,@function
vatomic8_write:                         // @vatomic8_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strb	w1, [sp, #7]
	//APP
	//NO_APP
	ldr	x9, [sp, #8]
	ldrb	w8, [sp, #7]
	strb	w8, [sp, #6]
	ldrb	w8, [sp, #6]
	stlrb	w8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end19:
	.size	vatomic8_write, .Lfunc_end19-vatomic8_write
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_destroy
	.type	vqueue_ub_destroy,@function
vqueue_ub_destroy:                      // @vqueue_ub_destroy
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
	ldur	x0, [x29, #-8]
	bl	vatomicptr_read
	str	x0, [sp, #16]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	b	.LBB20_1
.LBB20_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	cbz	x8, .LBB20_5
	b	.LBB20_2
.LBB20_2:                               //   in Loop: Header=BB20_1 Depth=1
	ldr	x8, [sp, #16]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-8]
	add	x9, x9, #16
	subs	x8, x8, x9
	b.eq	.LBB20_4
	b	.LBB20_3
.LBB20_3:                               //   in Loop: Header=BB20_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	blr	x8
	b	.LBB20_4
.LBB20_4:                               //   in Loop: Header=BB20_1 Depth=1
	ldr	x8, [sp, #8]
	str	x8, [sp, #16]
	b	.LBB20_1
.LBB20_5:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end20:
	.size	vqueue_ub_destroy, .Lfunc_end20-vqueue_ub_destroy
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_destroy
	.type	vebr_destroy,@function
vebr_destroy:                           // @vebr_destroy
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	xzr, [sp, #16]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	str	xzr, [sp, #16]
	b	.LBB21_1
.LBB21_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #3
	b.hs	.LBB21_4
	b	.LBB21_2
.LBB21_2:                               //   in Loop: Header=BB21_1 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #8
	ldr	x9, [sp, #16]
	add	x0, x8, x9, lsl #4
	bl	smr_nodes_list_get_and_empty
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	smr_nodes_list_destroy
	b	.LBB21_3
.LBB21_3:                               //   in Loop: Header=BB21_1 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB21_1
.LBB21_4:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end21:
	.size	vebr_destroy, .Lfunc_end21-vebr_destroy
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic_fence
	.type	vatomic_fence,@function
vatomic_fence:                          // @vatomic_fence
	.cfi_startproc
// %bb.0:
	//APP
	dmb	ish
	//NO_APP
	ret
.Lfunc_end22:
	.size	vatomic_fence, .Lfunc_end22-vatomic_fence
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_read
	.type	vatomic64_read,@function
vatomic64_read:                         // @vatomic64_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x9, [sp, #8]
	//APP
	ldar	x8, [x9]
	//NO_APP
	str	x8, [sp]
	ldr	x0, [sp]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end23:
	.size	vatomic64_read, .Lfunc_end23-vatomic64_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_add
	.type	smr_nodes_list_add,@function
smr_nodes_list_add:                     // @smr_nodes_list_add
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9, #16]
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	str	x8, [x9, #24]
	ldr	x8, [sp, #16]
                                        // kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #16]
	bl	_smr_nodes_list_connect
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	bl	vatomic64_inc_rlx
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end24:
	.size	smr_nodes_list_add, .Lfunc_end24-smr_nodes_list_add
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _smr_nodes_list_connect
	.type	_smr_nodes_list_connect,@function
_smr_nodes_list_connect:                // @_smr_nodes_list_connect
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	x0, [x29, #-8]
	bl	vatomicptr_read
	str	x0, [sp, #16]
	b	.LBB25_1
.LBB25_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	ldur	x2, [x29, #-16]
	bl	vatomicptr_cmpxchg_rel
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	cset	w0, eq
	bl	verification_assume
	b	.LBB25_2
.LBB25_2:                               //   in Loop: Header=BB25_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	.LBB25_1
	b	.LBB25_3
.LBB25_3:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end25:
	.size	_smr_nodes_list_connect, .Lfunc_end25-_smr_nodes_list_connect
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_inc_rlx
	.type	vatomic64_inc_rlx,@function
vatomic64_inc_rlx:                      // @vatomic64_inc_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	vatomic64_get_inc_rlx
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end26:
	.size	vatomic64_inc_rlx, .Lfunc_end26-vatomic64_inc_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_read
	.type	vatomicptr_read,@function
vatomicptr_read:                        // @vatomicptr_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x9, [sp, #8]
	//APP
	ldar	x8, [x9]
	//NO_APP
	str	x8, [sp]
	ldr	x0, [sp]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end27:
	.size	vatomicptr_read, .Lfunc_end27-vatomicptr_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_cmpxchg_rel
	.type	vatomicptr_cmpxchg_rel,@function
vatomicptr_cmpxchg_rel:                 // @vatomicptr_cmpxchg_rel
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	str	x2, [sp, #24]
	ldr	x10, [sp, #24]
	ldr	x11, [sp, #32]
	ldr	x12, [sp, #40]
	//APP
	prfm	pstl1strm, [x12]
.Ltmp5:
	ldxr	x9, [x12]
	cmp	x9, x11
	b.ne	.Ltmp6
	stlxr	w8, x10, [x12]
	cbnz	w8, .Ltmp5
.Ltmp6:

	//NO_APP
	str	x9, [sp, #16]
	str	w8, [sp, #12]
	ldr	x0, [sp, #16]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end28:
	.size	vatomicptr_cmpxchg_rel, .Lfunc_end28-vatomicptr_cmpxchg_rel
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function verification_assume
	.type	verification_assume,@function
verification_assume:                    // @verification_assume
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	b	.LBB29_1
.LBB29_1:
	b	.LBB29_2
.LBB29_2:
	b	.LBB29_3
.LBB29_3:
	b	.LBB29_4
.LBB29_4:
	b	.LBB29_5
.LBB29_5:
	b	.LBB29_6
.LBB29_6:
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end29:
	.size	verification_assume, .Lfunc_end29-verification_assume
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_get_inc_rlx
	.type	vatomic64_get_inc_rlx,@function
vatomic64_get_inc_rlx:                  // @vatomic64_get_inc_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, #1                          // =0x1
	bl	vatomic64_get_add_rlx
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end30:
	.size	vatomic64_get_inc_rlx, .Lfunc_end30-vatomic64_get_inc_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_get_add_rlx
	.type	vatomic64_get_add_rlx,@function
vatomic64_get_add_rlx:                  // @vatomic64_get_add_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	x12, [sp, #40]
	//APP
	prfm	pstl1strm, [x12]
.Ltmp9:
	ldxr	x11, [x12]
	add	x10, x11, x8
	stxr	w9, x10, [x12]
	cbnz	w9, .Ltmp9

	//NO_APP
	str	x11, [sp, #24]
	str	x10, [sp, #8]
	str	w9, [sp, #20]
	str	x8, [sp, #32]
	ldr	x0, [sp, #24]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end31:
	.size	vatomic64_get_add_rlx, .Lfunc_end31-vatomic64_get_add_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_get_and_empty
	.type	smr_nodes_list_get_and_empty,@function
smr_nodes_list_get_and_empty:           // @smr_nodes_list_get_and_empty
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	vatomicptr_xchg_acq
	str	x0, [sp]
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	mov	x1, xzr
	bl	vatomic64_write_rlx
	ldr	x0, [sp]
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end32:
	.size	smr_nodes_list_get_and_empty, .Lfunc_end32-smr_nodes_list_get_and_empty
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _vebr_sync_epochs
	.type	_vebr_sync_epochs,@function
_vebr_sync_epochs:                      // @_vebr_sync_epochs
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	sturb	w2, [x29, #-17]
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-32]
	stur	xzr, [x29, #-40]
	str	xzr, [sp, #48]
	mov	x8, #-1                         // =0xffffffffffffffff
	str	x8, [sp, #40]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-8]
	ldr	x0, [x9, #88]
	blr	x8
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #56]
	stur	x8, [x29, #-32]
	b	.LBB33_1
.LBB33_1:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB33_3 Depth 2
	ldur	x8, [x29, #-32]
	cbz	x8, .LBB33_19
	b	.LBB33_2
.LBB33_2:                               //   in Loop: Header=BB33_1 Depth=1
	ldur	x8, [x29, #-32]
	stur	x8, [x29, #-40]
	b	.LBB33_3
.LBB33_3:                               //   Parent Loop BB33_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldur	x8, [x29, #-40]
	add	x0, x8, #16
	bl	vatomic64_read
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, .LBB33_5
	b	.LBB33_4
.LBB33_4:                               //   in Loop: Header=BB33_1 Depth=1
	b	.LBB33_17
.LBB33_5:                               //   in Loop: Header=BB33_3 Depth=2
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-16]
	subs	x8, x8, x9
	b.lo	.LBB33_10
	b	.LBB33_6
.LBB33_6:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #40]
	str	x8, [sp, #32]
	ldr	x8, [sp, #48]
	str	x8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	.LBB33_8
	b	.LBB33_7
.LBB33_7:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #32]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	b	.LBB33_9
.LBB33_8:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	b	.LBB33_9
.LBB33_9:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	str	x8, [sp, #40]
	b	.LBB33_17
.LBB33_10:                              //   in Loop: Header=BB33_3 Depth=2
	ldurb	w8, [x29, #-17]
	tbnz	w8, #0, .LBB33_12
	b	.LBB33_11
.LBB33_11:
	ldr	x8, [sp, #48]
	str	x8, [sp, #40]
	b	.LBB33_20
.LBB33_12:                              //   in Loop: Header=BB33_3 Depth=2
	bl	verification_ignore
	b	.LBB33_13
.LBB33_13:                              //   in Loop: Header=BB33_3 Depth=2
	b	.LBB33_14
.LBB33_14:                              //   in Loop: Header=BB33_3 Depth=2
	b	.LBB33_15
.LBB33_15:                              //   in Loop: Header=BB33_3 Depth=2
	b	.LBB33_16
.LBB33_16:                              //   in Loop: Header=BB33_3 Depth=2
	mov	w8, #1                          // =0x1
	tbnz	w8, #0, .LBB33_3
	b	.LBB33_17
.LBB33_17:                              //   in Loop: Header=BB33_1 Depth=1
	b	.LBB33_18
.LBB33_18:                              //   in Loop: Header=BB33_1 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	stur	x8, [x29, #-32]
	b	.LBB33_1
.LBB33_19:
	b	.LBB33_20
.LBB33_20:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #80]
	ldur	x9, [x29, #-8]
	ldr	x0, [x9, #88]
	blr	x8
	ldr	x8, [sp, #40]
	adds	x8, x8, #1
	b.ne	.LBB33_22
	b	.LBB33_21
.LBB33_21:
	mov	x8, xzr
	str	x8, [sp]                        // 8-byte Folded Spill
	b	.LBB33_23
.LBB33_22:
	ldr	x8, [sp, #40]
	str	x8, [sp]                        // 8-byte Folded Spill
	b	.LBB33_23
.LBB33_23:
	ldr	x0, [sp]                        // 8-byte Folded Reload
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end33:
	.size	_vebr_sync_epochs, .Lfunc_end33-_vebr_sync_epochs
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_cmpxchg
	.type	vatomic64_cmpxchg,@function
vatomic64_cmpxchg:                      // @vatomic64_cmpxchg
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	str	x2, [sp, #24]
	ldr	x10, [sp, #24]
	ldr	x11, [sp, #32]
	ldr	x12, [sp, #40]
	//APP
	prfm	pstl1strm, [x12]
.Ltmp11:
	ldaxr	x9, [x12]
	cmp	x9, x11
	b.ne	.Ltmp12
	stlxr	w8, x10, [x12]
	cbnz	w8, .Ltmp11
.Ltmp12:

	//NO_APP
	str	x9, [sp, #16]
	str	w8, [sp, #12]
	ldr	x0, [sp, #16]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end34:
	.size	vatomic64_cmpxchg, .Lfunc_end34-vatomic64_cmpxchg
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_destroy
	.type	smr_nodes_list_destroy,@function
smr_nodes_list_destroy:                 // @smr_nodes_list_destroy
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #8]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp]
	b	.LBB35_1
.LBB35_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	cbz	x8, .LBB35_3
	b	.LBB35_2
.LBB35_2:                               //   in Loop: Header=BB35_1 Depth=1
	ldr	x8, [sp, #8]
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp]
	ldr	x8, [x8, #16]
	ldr	x0, [sp]
	ldr	x9, [sp]
	ldr	x1, [x9, #24]
	blr	x8
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB35_1
.LBB35_3:
	ldr	x0, [sp, #16]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end35:
	.size	smr_nodes_list_destroy, .Lfunc_end35-smr_nodes_list_destroy
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_xchg_acq
	.type	vatomicptr_xchg_acq,@function
vatomicptr_xchg_acq:                    // @vatomicptr_xchg_acq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x10, [sp, #16]
	ldr	x11, [sp, #24]
	//APP
	prfm	pstl1strm, [x11]
.Ltmp14:
	ldaxr	x9, [x11]
	stxr	w8, x10, [x11]
	cbnz	w8, .Ltmp14

	//NO_APP
	str	x9, [sp, #8]
	str	w8, [sp, #4]
	ldr	x0, [sp, #8]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end36:
	.size	vatomicptr_xchg_acq, .Lfunc_end36-vatomicptr_xchg_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_write_rlx
	.type	vatomic64_write_rlx,@function
vatomic64_write_rlx:                    // @vatomic64_write_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	//APP
	str	x8, [x9]
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end37:
	.size	vatomic64_write_rlx, .Lfunc_end37-vatomic64_write_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function verification_ignore
	.type	verification_ignore,@function
verification_ignore:                    // @verification_ignore
	.cfi_startproc
// %bb.0:
	ret
.Lfunc_end38:
	.size	verification_ignore, .Lfunc_end38-verification_ignore
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_init
	.type	vatomic64_init,@function
vatomic64_init:                         // @vatomic64_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	vatomic64_write
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end39:
	.size	vatomic64_init, .Lfunc_end39-vatomic64_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function dbl_list_add
	.type	dbl_list_add,@function
dbl_list_add:                           // @dbl_list_add
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbz	x8, .LBB40_2
	b	.LBB40_1
.LBB40_1:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	str	x8, [x9, #8]
	b	.LBB40_2
.LBB40_2:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x8, [sp]
                                        // kill: def $x9 killed $xzr
	str	xzr, [x8, #8]
	ldr	x9, [sp, #8]
	ldr	x8, [x9, #8]
	add	x8, x8, #1
	str	x8, [x9, #8]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end40:
	.size	dbl_list_add, .Lfunc_end40-dbl_list_add
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_write
	.type	vatomic64_write,@function
vatomic64_write:                        // @vatomic64_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	//APP
	stlr	x8, [x9]
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end41:
	.size	vatomic64_write, .Lfunc_end41-vatomic64_write
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_write_rel
	.type	vatomic64_write_rel,@function
vatomic64_write_rel:                    // @vatomic64_write_rel
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	//APP
	stlr	x8, [x9]
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end42:
	.size	vatomic64_write_rel, .Lfunc_end42-vatomic64_write_rel
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_cmpxchg
	.type	vatomicptr_cmpxchg,@function
vatomicptr_cmpxchg:                     // @vatomicptr_cmpxchg
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	str	x2, [sp, #24]
	ldr	x10, [sp, #24]
	ldr	x11, [sp, #32]
	ldr	x12, [sp, #40]
	//APP
	prfm	pstl1strm, [x12]
.Ltmp20:
	ldaxr	x9, [x12]
	cmp	x9, x11
	b.ne	.Ltmp21
	stlxr	w8, x10, [x12]
	cbnz	w8, .Ltmp20
.Ltmp21:

	//NO_APP
	str	x9, [sp, #16]
	str	w8, [sp, #12]
	ldr	x0, [sp, #16]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end43:
	.size	vatomicptr_cmpxchg, .Lfunc_end43-vatomicptr_cmpxchg
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_write_rlx
	.type	vatomicptr_write_rlx,@function
vatomicptr_write_rlx:                   // @vatomicptr_write_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	//APP
	str	x8, [x9]
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end44:
	.size	vatomicptr_write_rlx, .Lfunc_end44-vatomicptr_write_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function dbl_list_rem
	.type	dbl_list_rem,@function
dbl_list_rem:                           // @dbl_list_rem
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	str	x8, [sp]
	ldr	x8, [sp]
	cbz	x8, .LBB45_2
	b	.LBB45_1
.LBB45_1:
	ldr	x8, [sp, #8]
	ldr	x9, [sp]
	str	x8, [x9]
	b	.LBB45_3
.LBB45_2:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	b	.LBB45_3
.LBB45_3:
	ldr	x8, [sp, #8]
	cbz	x8, .LBB45_5
	b	.LBB45_4
.LBB45_4:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9, #8]
	b	.LBB45_5
.LBB45_5:
	ldr	x9, [sp, #24]
	ldr	x8, [x9, #8]
	subs	x8, x8, #1
	str	x8, [x9, #8]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end45:
	.size	dbl_list_rem, .Lfunc_end45-dbl_list_rem
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function dbl_list_init
	.type	dbl_list_init,@function
dbl_list_init:                          // @dbl_list_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
                                        // kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	xzr, [x8, #8]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end46:
	.size	dbl_list_init, .Lfunc_end46-dbl_list_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_init
	.type	smr_nodes_list_init,@function
smr_nodes_list_init:                    // @smr_nodes_list_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	vatomicptr_init
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	mov	x1, xzr
	bl	vatomic64_init
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end47:
	.size	smr_nodes_list_init, .Lfunc_end47-smr_nodes_list_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_init
	.type	vatomicptr_init,@function
vatomicptr_init:                        // @vatomicptr_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	vatomicptr_write
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end48:
	.size	vatomicptr_init, .Lfunc_end48-vatomicptr_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_write
	.type	vatomicptr_write,@function
vatomicptr_write:                       // @vatomicptr_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	//APP
	stlr	x8, [x9]
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end49:
	.size	vatomicptr_write, .Lfunc_end49-vatomicptr_write
	.cfi_endproc
                                        // -- End function
	.type	g_lock,@object                  // @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	48
	.size	g_lock, 48

	.type	g_lock_lib,@object              // @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.xword	lock_acq
	.xword	lock_rel
	.xword	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  // @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  // @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 // @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                // @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym free
	.addrsig_sym retire_cb
	.addrsig_sym vebr_retire
	.addrsig_sym destroy_cb
	.addrsig_sym reclaim
	.addrsig_sym vatomic8_read
	.addrsig_sym vebr_recycle
	.addrsig_sym printf
	.addrsig_sym run
	.addrsig_sym vebr_register
	.addrsig_sym vebr_enter
	.addrsig_sym vqueue_ub_deq
	.addrsig_sym malloc
	.addrsig_sym vqueue_ub_enq
	.addrsig_sym vebr_exit
	.addrsig_sym vebr_deregister
	.addrsig_sym pthread_mutex_init
	.addrsig_sym vebr_init
	.addrsig_sym vqueue_ub_init
	.addrsig_sym pthread_create
	.addrsig_sym pthread_join
	.addrsig_sym vatomic8_write
	.addrsig_sym vqueue_ub_destroy
	.addrsig_sym vebr_destroy
	.addrsig_sym pthread_mutex_destroy
	.addrsig_sym pthread_mutex_lock
	.addrsig_sym pthread_mutex_unlock
	.addrsig_sym vatomic_fence
	.addrsig_sym vatomic64_read
	.addrsig_sym smr_nodes_list_add
	.addrsig_sym _smr_nodes_list_connect
	.addrsig_sym vatomic64_inc_rlx
	.addrsig_sym vatomicptr_read
	.addrsig_sym vatomicptr_cmpxchg_rel
	.addrsig_sym verification_assume
	.addrsig_sym vatomic64_get_inc_rlx
	.addrsig_sym vatomic64_get_add_rlx
	.addrsig_sym smr_nodes_list_get_and_empty
	.addrsig_sym _vebr_sync_epochs
	.addrsig_sym vatomic64_cmpxchg
	.addrsig_sym smr_nodes_list_destroy
	.addrsig_sym vatomicptr_xchg_acq
	.addrsig_sym vatomic64_write_rlx
	.addrsig_sym verification_ignore
	.addrsig_sym vatomic64_init
	.addrsig_sym dbl_list_add
	.addrsig_sym vatomic64_write
	.addrsig_sym vatomic64_write_rel
	.addrsig_sym vatomicptr_cmpxchg
	.addrsig_sym vatomicptr_write_rlx
	.addrsig_sym dbl_list_rem
	.addrsig_sym dbl_list_init
	.addrsig_sym smr_nodes_list_init
	.addrsig_sym vatomicptr_init
	.addrsig_sym vatomicptr_write
	.addrsig_sym g_lock
	.addrsig_sym g_lock_lib
	.addrsig_sym g_vebr
	.addrsig_sym g_stop
	.addrsig_sym g_queue
