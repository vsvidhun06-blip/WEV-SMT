	.file	"eg_vebr.c"
	.text
	.p2align	2                               // -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               // @lock_acq
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_lock
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               // @lock_rel
	.cfi_startproc
// %bb.0:
	b	pthread_mutex_unlock
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        // -- End function
	.globl	free_cb                         // -- Begin function free_cb
	.p2align	2
	.type	free_cb,@function
free_cb:                                // @free_cb
	.cfi_startproc
// %bb.0:
	sub	x0, x0, #16
	b	free
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	adrp	x8, :got:g_vebr
	mov	x10, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	ldr	x8, [x8, :got_lo12:g_vebr]
	//APP
	dmb	ish
	//NO_APP
	movk	x10, #43691
	//APP
	ldar	x9, [x8]
	//NO_APP
	umulh	x10, x9, x10
	lsr	x11, x10, #1
	lsl	x11, x11, #1
	add	x10, x11, x10, lsr #1
	sub	x9, x9, x10
	adrp	x10, :got:free_cb
	ldr	x10, [x10, :got_lo12:free_cb]
	add	x8, x8, x9, lsl #4
	str	xzr, [x0, #16]!
	stp	x10, xzr, [x0, #16]
	add	x8, x8, #8
	//APP
	ldar	x9, [x8]
	//NO_APP
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	str	x9, [x0]
	//APP
	prfm	pstl1strm, [x8]
.Ltmp0:
	ldxr	x10, [x8]
	cmp	x10, x9
	b.ne	.Ltmp1
	stlxr	w11, x0, [x8]
	cbnz	w11, .Ltmp0
.Ltmp1:

	//NO_APP
	cmp	x9, x10
	mov	x9, x10
	b.ne	.LBB3_1
// %bb.2:
	mov	w9, #1                          // =0x1
	add	x8, x8, #8
	//APP
	prfm	pstl1strm, [x8]
.Ltmp2:
	ldxr	x10, [x8]
	add	x11, x10, x9
	stxr	w12, x11, [x8]
	cbnz	w12, .Ltmp2

	//NO_APP
	ret
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	b	free
.Lfunc_end4:
	.size	destroy_cb, .Lfunc_end4-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	reclaim                         // -- Begin function reclaim
	.p2align	2
	.type	reclaim,@function
reclaim:                                // @reclaim
	.cfi_startproc
// %bb.0:
	str	x30, [sp, #-80]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 80
	stp	x26, x25, [sp, #16]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w30, -80
	adrp	x21, :got:g_stop
	ldr	x21, [x21, :got_lo12:g_stop]
	//APP
	//NO_APP
	ldarb	w8, [x21]
	//APP
	//NO_APP
	cbnz	w8, .LBB5_11
// %bb.1:
	adrp	x23, :got:g_vebr
	mov	x24, #-6148914691236517206      // =0xaaaaaaaaaaaaaaaa
	mov	x22, xzr
	ldr	x23, [x23, :got_lo12:g_vebr]
	movk	x24, #43691
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
.LBB5_2:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_3 Depth 2
                                        //     Child Loop BB5_7 Depth 2
	//APP
	dmb	ish
	//NO_APP
	//APP
	ldar	x25, [x23]
	//NO_APP
	add	x8, x25, #2
	umulh	x9, x8, x24
	lsr	x10, x9, #1
	lsl	x10, x10, #1
	add	x9, x10, x9, lsr #1
	sub	x8, x8, x9
	add	x8, x23, x8, lsl #4
	add	x9, x8, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp3:
	ldaxr	x20, [x9]
	stxr	w10, x22, [x9]
	cbnz	w10, .Ltmp3

	//NO_APP
	add	x8, x8, #16
	//APP
	str	x22, [x8]
	//NO_APP
	ldr	x8, [x23, #72]
	ldr	x0, [x23, #88]
	blr	x8
	ldr	x8, [x23, #56]
	cbz	x8, .LBB5_5
.LBB5_3:                                //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x9, x8, #16
	//APP
	ldar	x10, [x9]
	//NO_APP
	cmp	x10, #0
	ccmp	x10, x25, #2, ne
	b.lo	.LBB5_3
// %bb.4:                               //   in Loop: Header=BB5_3 Depth=2
	ldr	x8, [x8]
	cbnz	x8, .LBB5_3
.LBB5_5:                                //   in Loop: Header=BB5_2 Depth=1
	ldp	x8, x0, [x23, #80]
	blr	x8
	add	x8, x25, #1
	//APP
	prfm	pstl1strm, [x23]
.Ltmp4:
	ldaxr	x9, [x23]
	cmp	x9, x25
	b.ne	.Ltmp5
	stlxr	w10, x8, [x23]
	cbnz	w10, .Ltmp4
.Ltmp5:

	//NO_APP
	cbz	x20, .LBB5_10
// %bb.6:                               //   in Loop: Header=BB5_2 Depth=1
	mov	x25, xzr
.LBB5_7:                                //   Parent Loop BB5_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldp	x8, x1, [x20, #16]
	mov	x0, x20
	ldr	x26, [x20]
	blr	x8
	sub	x25, x25, #1
	mov	x20, x26
	cbnz	x26, .LBB5_7
// %bb.8:                               //   in Loop: Header=BB5_2 Depth=1
	cbz	x25, .LBB5_10
// %bb.9:                               //   in Loop: Header=BB5_2 Depth=1
	sub	x1, x22, x25
	mov	x0, x19
	bl	printf
.LBB5_10:                               //   in Loop: Header=BB5_2 Depth=1
	//APP
	//NO_APP
	ldarb	w8, [x21]
	//APP
	//NO_APP
	cbz	w8, .LBB5_2
.LBB5_11:
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             // 16-byte Folded Reload
	ldr	x30, [sp], #80                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w30
	ret
.Lfunc_end5:
	.size	reclaim, .Lfunc_end5-reclaim
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
	cbz	x0, .LBB6_28
// %bb.1:
	adrp	x25, :got:g_vebr
	mov	x26, sp
	mov	x8, xzr
	ldr	x25, [x25, :got_lo12:g_vebr]
	add	x9, x26, #16
	//APP
	stlr	x8, [x9]
	//NO_APP
	mov	x19, x0
	str	wzr, [sp, #24]
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldr	x8, [x25, #56]
	str	x8, [sp]
	cbz	x8, .LBB6_3
// %bb.2:
	str	x26, [x8, #8]
.LBB6_3:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	mov	x27, xzr
	str	xzr, [sp, #8]
	add	x8, x8, #1
	stp	x26, x8, [x25, #56]
	blr	x9
	adrp	x28, :got:g_queue
	ldr	w8, [sp, #24]
	adrp	x20, .L.str.1
	add	x20, x20, :lo12:.L.str.1
	ldr	x28, [x28, :got_lo12:g_queue]
	mov	w29, #10000                     // =0x2710
	adrp	x21, .L.str.2
	add	x21, x21, :lo12:.L.str.2
	mov	x22, xzr
.LBB6_4:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB6_6 Depth 2
                                        //     Child Loop BB6_16 Depth 2
	add	w9, w8, #1
	str	w9, [sp, #24]
	cbnz	w8, .LBB6_6
// %bb.5:                               //   in Loop: Header=BB6_4 Depth=1
	//APP
	ldar	x8, [x25]
	//NO_APP
	add	x9, x26, #16
	//APP
	stlr	x8, [x9]
	//NO_APP
	//APP
	dmb	ish
	//NO_APP
.LBB6_6:                                //   Parent Loop BB6_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	//APP
	ldar	x0, [x28]
	//NO_APP
	add	x8, x28, #8
	add	x10, x0, #8
	//APP
	ldar	x9, [x8]
	//NO_APP
	//APP
	ldar	x8, [x10]
	//NO_APP
	//APP
	ldar	x10, [x28]
	//NO_APP
	cmp	x0, x10
	b.ne	.LBB6_6
// %bb.7:                               //   in Loop: Header=BB6_6 Depth=2
	cmp	x0, x9
	b.eq	.LBB6_9
// %bb.8:                               //   in Loop: Header=BB6_6 Depth=2
	ldr	x23, [x8]
	//APP
	prfm	pstl1strm, [x28]
.Ltmp6:
	ldaxr	x9, [x28]
	cmp	x9, x0
	b.ne	.Ltmp7
	stlxr	w10, x8, [x28]
	cbnz	w10, .Ltmp6
.Ltmp7:

	//NO_APP
	cmp	x9, x0
	b.ne	.LBB6_6
	b	.LBB6_11
.LBB6_9:                                //   in Loop: Header=BB6_6 Depth=2
	cbz	x8, .LBB6_15
// %bb.10:                              //   in Loop: Header=BB6_6 Depth=2
	add	x10, x28, #8
	//APP
	prfm	pstl1strm, [x10]
.Ltmp8:
	ldaxr	x11, [x10]
	cmp	x11, x9
	b.ne	.Ltmp9
	stlxr	w12, x8, [x10]
	cbnz	w12, .Ltmp8
.Ltmp9:

	//NO_APP
	b	.LBB6_6
.LBB6_11:                               //   in Loop: Header=BB6_4 Depth=1
	add	x8, x28, #16
	cmp	x0, x8
	b.eq	.LBB6_13
// %bb.12:                              //   in Loop: Header=BB6_4 Depth=1
	bl	retire_cb
.LBB6_13:                               //   in Loop: Header=BB6_4 Depth=1
	cbz	x23, .LBB6_15
// %bb.14:                              //   in Loop: Header=BB6_4 Depth=1
	ldr	x2, [x23]
	mov	x0, x21
	mov	x1, x19
	bl	printf
	mov	x0, x23
	bl	free
	b	.LBB6_21
.LBB6_15:                               //   in Loop: Header=BB6_4 Depth=1
	mov	w0, #8                          // =0x8
	bl	malloc
	mov	x24, x0
	str	x22, [x0]
	mov	w0, #48                         // =0x30
	bl	malloc
	mov	x23, x0
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	printf
	mov	x8, x23
	str	x24, [x8], #8
	//APP
	str	x27, [x8]
	//NO_APP
.LBB6_16:                               //   Parent Loop BB6_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x10, x28, #8
	//APP
	ldar	x8, [x10]
	//NO_APP
	add	x11, x8, #8
	//APP
	ldar	x9, [x11]
	//NO_APP
	//APP
	ldar	x11, [x10]
	//NO_APP
	cmp	x8, x11
	b.ne	.LBB6_16
// %bb.17:                              //   in Loop: Header=BB6_16 Depth=2
	cbz	x9, .LBB6_19
// %bb.18:                              //   in Loop: Header=BB6_16 Depth=2
	add	x10, x28, #8
	//APP
	prfm	pstl1strm, [x10]
.Ltmp10:
	ldaxr	x11, [x10]
	cmp	x11, x8
	b.ne	.Ltmp11
	stlxr	w12, x9, [x10]
	cbnz	w12, .Ltmp10
.Ltmp11:

	//NO_APP
	b	.LBB6_16
.LBB6_19:                               //   in Loop: Header=BB6_16 Depth=2
	add	x9, x8, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp12:
	ldaxr	x10, [x9]
	cmp	x10, x27
	b.ne	.Ltmp13
	stlxr	w11, x23, [x9]
	cbnz	w11, .Ltmp12
.Ltmp13:

	//NO_APP
	cbnz	x10, .LBB6_16
// %bb.20:                              //   in Loop: Header=BB6_4 Depth=1
	add	x9, x28, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp14:
	ldaxr	x10, [x9]
	cmp	x10, x8
	b.ne	.Ltmp15
	stlxr	w11, x23, [x9]
	cbnz	w11, .Ltmp14
.Ltmp15:

	//NO_APP
.LBB6_21:                               //   in Loop: Header=BB6_4 Depth=1
	ldr	w8, [sp, #24]
	cmp	w8, #1
	b.ne	.LBB6_23
// %bb.22:                              //   in Loop: Header=BB6_4 Depth=1
	add	x8, x26, #16
	//APP
	stlr	x27, [x8]
	//NO_APP
	ldr	w8, [sp, #24]
.LBB6_23:                               //   in Loop: Header=BB6_4 Depth=1
	add	x22, x22, #1
	sub	w8, w8, #1
	cmp	x22, x29
	str	w8, [sp, #24]
	b.ne	.LBB6_4
// %bb.24:
	ldr	x8, [x25, #72]
	ldr	x0, [x25, #88]
	blr	x8
	ldp	x9, x8, [sp]
	cbz	x8, .LBB6_30
// %bb.25:
	str	x9, [x8]
	cbz	x9, .LBB6_27
.LBB6_26:
	str	x8, [x9, #8]
.LBB6_27:
	ldr	x8, [x25, #64]
	ldp	x9, x0, [x25, #80]
	sub	x8, x8, #1
	str	x8, [x25, #64]
	blr	x9
	b	.LBB6_29
.LBB6_28:
	bl	reclaim
.LBB6_29:
	ldp	x20, x19, [sp, #112]            // 16-byte Folded Reload
	mov	x0, xzr
	ldp	x22, x21, [sp, #96]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_30:
	.cfi_restore_state
	str	x9, [x25, #56]
	cbnz	x9, .LBB6_26
	b	.LBB6_27
.Lfunc_end6:
	.size	run, .Lfunc_end6-run
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	str	x30, [sp, #96]                  // 8-byte Folded Spill
	stp	x24, x23, [sp, #112]            // 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w30, -64
	adrp	x0, :got:g_lock
	mov	x1, xzr
	mov	x19, xzr
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_init
	adrp	x8, :got:g_lock_lib
	adrp	x23, :got:g_vebr
	mov	w9, #3                          // =0x3
	ldr	x8, [x8, :got_lo12:g_lock_lib]
	ldr	q0, [x8]
	ldr	x8, [x8, #16]
	ldr	x23, [x23, :got_lo12:g_vebr]
	str	x8, [sp, #16]
	add	x8, x23, #16
	str	q0, [sp]
	stp	xzr, xzr, [x23, #56]
.LBB7_1:                                // =>This Inner Loop Header: Depth=1
	sub	x10, x8, #8
	//APP
	stlr	x19, [x10]
	//NO_APP
	subs	x9, x9, #1
	//APP
	stlr	x19, [x8]
	//NO_APP
	add	x8, x8, #16
	b.ne	.LBB7_1
// %bb.2:
	mov	w8, #1                          // =0x1
	//APP
	stlr	x8, [x23]
	//NO_APP
	adrp	x24, :got:g_queue
	ldr	q0, [sp]
	ldr	x24, [x24, :got_lo12:g_queue]
	ldr	x8, [sp, #16]
	mov	x19, xzr
	adrp	x20, :got:run
	mov	x21, sp
	mov	x9, x24
	stur	q0, [x23, #72]
	mov	x22, xzr
	str	x8, [x23, #88]
	add	x8, x24, #24
	str	xzr, [x9, #16]!
	//APP
	str	x19, [x8]
	//NO_APP
	add	x8, x24, #8
	//APP
	str	x9, [x24]
	//NO_APP
	//APP
	str	x9, [x8]
	//NO_APP
	ldr	x20, [x20, :got_lo12:run]
.LBB7_3:                                // =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	mov	x3, x22
	bl	pthread_create
	add	x22, x22, #1
	add	x21, x21, #8
	cmp	x22, #12
	b.ne	.LBB7_3
// %bb.4:
	mov	w19, #8                         // =0x8
	mov	x20, sp
.LBB7_5:                                // =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19]
	mov	x1, xzr
	bl	pthread_join
	add	x19, x19, #8
	cmp	x19, #96
	b.ne	.LBB7_5
// %bb.6:
	adrp	x8, :got:g_stop
	mov	w9, #1                          // =0x1
	mov	x1, xzr
	ldr	x8, [x8, :got_lo12:g_stop]
	//APP
	//NO_APP
	stlrb	w9, [x8]
	//APP
	//NO_APP
	ldr	x0, [sp]
	bl	pthread_join
.LBB7_7:                                // =>This Inner Loop Header: Depth=1
	//APP
	ldar	x0, [x24]
	//NO_APP
	add	x8, x24, #8
	add	x10, x0, #8
	//APP
	ldar	x9, [x8]
	//NO_APP
	//APP
	ldar	x8, [x10]
	//NO_APP
	//APP
	ldar	x10, [x24]
	//NO_APP
	cmp	x0, x10
	b.ne	.LBB7_7
// %bb.8:                               //   in Loop: Header=BB7_7 Depth=1
	cmp	x0, x9
	b.eq	.LBB7_14
// %bb.9:                               //   in Loop: Header=BB7_7 Depth=1
	ldr	x19, [x8]
	//APP
	prfm	pstl1strm, [x24]
.Ltmp16:
	ldaxr	x9, [x24]
	cmp	x9, x0
	b.ne	.Ltmp17
	stlxr	w10, x8, [x24]
	cbnz	w10, .Ltmp16
.Ltmp17:

	//NO_APP
	cmp	x9, x0
	b.ne	.LBB7_7
// %bb.10:                              //   in Loop: Header=BB7_7 Depth=1
	add	x8, x24, #16
	cmp	x0, x8
	b.eq	.LBB7_12
// %bb.11:                              //   in Loop: Header=BB7_7 Depth=1
	bl	free
.LBB7_12:                               //   in Loop: Header=BB7_7 Depth=1
	cbz	x19, .LBB7_16
// %bb.13:                              //   in Loop: Header=BB7_7 Depth=1
	mov	x0, x19
	bl	free
	b	.LBB7_7
.LBB7_14:                               //   in Loop: Header=BB7_7 Depth=1
	cbz	x8, .LBB7_16
// %bb.15:                              //   in Loop: Header=BB7_7 Depth=1
	add	x10, x24, #8
	//APP
	prfm	pstl1strm, [x10]
.Ltmp18:
	ldaxr	x11, [x10]
	cmp	x11, x9
	b.ne	.Ltmp19
	stlxr	w12, x8, [x10]
	cbnz	w12, .Ltmp18
.Ltmp19:

	//NO_APP
	b	.LBB7_7
.LBB7_16:
	adrp	x8, :got:g_queue
	ldr	x8, [x8, :got_lo12:g_queue]
	//APP
	ldar	x0, [x8]
	//NO_APP
	cbz	x0, .LBB7_21
// %bb.17:
	add	x19, x8, #16
.LBB7_18:                               // =>This Inner Loop Header: Depth=1
	add	x8, x0, #8
	//APP
	ldar	x20, [x8]
	//NO_APP
	cmp	x0, x19
	b.eq	.LBB7_20
// %bb.19:                              //   in Loop: Header=BB7_18 Depth=1
	bl	free
.LBB7_20:                               //   in Loop: Header=BB7_18 Depth=1
	mov	x0, x20
	cbnz	x20, .LBB7_18
.LBB7_21:
	mov	x19, xzr
	mov	x20, xzr
.LBB7_22:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_23 Depth 2
	add	x8, x23, x20, lsl #4
	add	x9, x8, #8
	//APP
	prfm	pstl1strm, [x9]
.Ltmp20:
	ldaxr	x0, [x9]
	stxr	w10, x19, [x9]
	cbnz	w10, .Ltmp20

	//NO_APP
	add	x8, x8, #16
	//APP
	str	x19, [x8]
	//NO_APP
	cbz	x0, .LBB7_24
.LBB7_23:                               //   Parent Loop BB7_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldp	x8, x1, [x0, #16]
	ldr	x21, [x0]
	blr	x8
	mov	x0, x21
	cbnz	x21, .LBB7_23
.LBB7_24:                               //   in Loop: Header=BB7_22 Depth=1
	add	x20, x20, #1
	cmp	x20, #3
	b.ne	.LBB7_22
// %bb.25:
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_destroy
	ldp	x20, x19, [sp, #144]            // 16-byte Folded Reload
	mov	w0, wzr
	ldp	x22, x21, [sp, #128]            // 16-byte Folded Reload
	ldr	x30, [sp, #96]                  // 8-byte Folded Reload
	ldp	x24, x23, [sp, #112]            // 16-byte Folded Reload
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w30
	ret
.Lfunc_end7:
	.size	main, .Lfunc_end7-main
	.cfi_endproc
                                        // -- End function
	.type	g_lock,@object                  // @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	48
	.size	g_lock, 48

	.type	g_lock_lib,@object              // @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.xword	lock_acq
	.xword	lock_rel
	.xword	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  // @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  // @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 // @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                // @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym run
	.addrsig_sym g_lock
	.addrsig_sym g_vebr
	.addrsig_sym g_queue
