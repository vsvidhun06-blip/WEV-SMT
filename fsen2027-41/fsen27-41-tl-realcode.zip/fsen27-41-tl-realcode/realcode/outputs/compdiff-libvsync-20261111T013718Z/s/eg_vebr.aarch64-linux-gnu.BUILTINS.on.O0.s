	.file	"eg_vebr.c"
	.text
	.p2align	2                               // -- Begin function lock_acq
	.type	lock_acq,@function
lock_acq:                               // @lock_acq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	bl	pthread_mutex_lock
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbnz	w8, .LBB0_2
	b	.LBB0_1
.LBB0_1:
	b	.LBB0_3
.LBB0_2:
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	adrp	x1, .L.str.4
	add	x1, x1, :lo12:.L.str.4
	mov	w2, #24                         // =0x18
	adrp	x3, .L__PRETTY_FUNCTION__.lock_acq
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.lock_acq
	bl	__assert_fail
.LBB0_3:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	lock_acq, .Lfunc_end0-lock_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function lock_rel
	.type	lock_rel,@function
lock_rel:                               // @lock_rel
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	bl	pthread_mutex_unlock
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbnz	w8, .LBB1_2
	b	.LBB1_1
.LBB1_1:
	b	.LBB1_3
.LBB1_2:
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	adrp	x1, .L.str.4
	add	x1, x1, :lo12:.L.str.4
	mov	w2, #32                         // =0x20
	adrp	x3, .L__PRETTY_FUNCTION__.lock_rel
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.lock_rel
	bl	__assert_fail
.LBB1_3:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end1:
	.size	lock_rel, .Lfunc_end1-lock_rel
	.cfi_endproc
                                        // -- End function
	.globl	free_cb                         // -- Begin function free_cb
	.p2align	2
	.type	free_cb,@function
free_cb:                                // @free_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	subs	x8, x8, #16
	str	x8, [sp, #8]
	ldr	x0, [sp, #8]
	bl	free
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	free_cb, .Lfunc_end2-free_cb
	.cfi_endproc
                                        // -- End function
	.globl	retire_cb                       // -- Begin function retire_cb
	.p2align	2
	.type	retire_cb,@function
retire_cb:                              // @retire_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x1, [sp, #8]
	ldur	x8, [x29, #-8]
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	add	x2, x8, #16
	adrp	x3, :got:free_cb
	ldr	x3, [x3, :got_lo12:free_cb]
	mov	x4, xzr
	bl	vebr_retire
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	retire_cb, .Lfunc_end3-retire_cb
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_retire
	.type	vebr_retire,@function
vebr_retire:                            // @vebr_retire
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	str	x3, [sp, #32]
	str	x4, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	bl	vatomic_fence
	ldur	x0, [x29, #-8]
	bl	vatomic64_read
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	mov	x10, #3                         // =0x3
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #3
	b.hi	.LBB4_2
	b	.LBB4_1
.LBB4_1:
	b	.LBB4_3
.LBB4_2:
	adrp	x0, .L.str.5
	add	x0, x0, :lo12:.L.str.5
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #248                        // =0xf8
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_retire
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_retire
	bl	__assert_fail
.LBB4_3:
	ldur	x8, [x29, #-8]
	add	x8, x8, #8
	ldr	x9, [sp, #8]
	add	x0, x8, x9, lsl #4
	ldur	x1, [x29, #-24]
	ldr	x2, [sp, #32]
	ldr	x3, [sp, #24]
	bl	smr_nodes_list_add
	b	.LBB4_4
.LBB4_4:
	b	.LBB4_5
.LBB4_5:
	b	.LBB4_6
.LBB4_6:
	b	.LBB4_7
.LBB4_7:
	b	.LBB4_8
.LBB4_8:
	b	.LBB4_9
.LBB4_9:
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end4:
	.size	vebr_retire, .Lfunc_end4-vebr_retire
	.cfi_endproc
                                        // -- End function
	.globl	destroy_cb                      // -- Begin function destroy_cb
	.p2align	2
	.type	destroy_cb,@function
destroy_cb:                             // @destroy_cb
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	bl	free
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end5:
	.size	destroy_cb, .Lfunc_end5-destroy_cb
	.cfi_endproc
                                        // -- End function
	.globl	reclaim                         // -- Begin function reclaim
	.p2align	2
	.type	reclaim,@function
reclaim:                                // @reclaim
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	b	.LBB6_1
.LBB6_1:                                // =>This Inner Loop Header: Depth=1
	adrp	x0, :got:g_stop
	ldr	x0, [x0, :got_lo12:g_stop]
	bl	vatomic8_read
	and	w8, w0, #0xff
	cbnz	w8, .LBB6_5
	b	.LBB6_2
.LBB6_2:                                //   in Loop: Header=BB6_1 Depth=1
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	bl	vebr_recycle
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #0
	b.ls	.LBB6_4
	b	.LBB6_3
.LBB6_3:                                //   in Loop: Header=BB6_1 Depth=1
	ldr	x1, [sp, #8]
	adrp	x0, .L.str
	add	x0, x0, :lo12:.L.str
	bl	printf
	b	.LBB6_4
.LBB6_4:                                //   in Loop: Header=BB6_1 Depth=1
	b	.LBB6_1
.LBB6_5:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end6:
	.size	reclaim, .Lfunc_end6-reclaim
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic8_read
	.type	vatomic8_read,@function
vatomic8_read:                          // @vatomic8_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	//APP
	//NO_APP
	ldr	x8, [sp, #8]
	ldarb	w8, [x8]
	strb	w8, [sp, #6]
	ldrb	w8, [sp, #6]
	strb	w8, [sp, #7]
	//APP
	//NO_APP
	ldrb	w0, [sp, #7]
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end7:
	.size	vatomic8_read, .Lfunc_end7-vatomic8_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_recycle
	.type	vebr_recycle,@function
vebr_recycle:                           // @vebr_recycle
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	xzr, [x29, #-16]
	stur	xzr, [x29, #-24]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	bl	vatomic_fence
	ldur	x0, [x29, #-8]
	bl	vatomic64_read
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	add	x8, x8, #2
	mov	x10, #3                         // =0x3
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-8]
	ldur	x9, [x29, #-24]
	add	x8, x8, #8
	add	x0, x8, x9, lsl #4
	bl	smr_nodes_list_get_and_empty
	str	x0, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #32]
	mov	w8, #1                          // =0x1
	and	w2, w8, #0x1
	bl	_vebr_sync_epochs
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, .LBB8_2
	b	.LBB8_1
.LBB8_1:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.lo	.LBB8_3
	b	.LBB8_2
.LBB8_2:
	b	.LBB8_4
.LBB8_3:
	adrp	x0, .L.str.13
	add	x0, x0, :lo12:.L.str.13
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #285                        // =0x11d
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_recycle
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_recycle
	bl	__assert_fail
.LBB8_4:
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #32]
	ldr	x8, [sp, #32]
	add	x2, x8, #1
	bl	vatomic64_cmpxchg
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.lo	.LBB8_6
	b	.LBB8_5
.LBB8_5:
	b	.LBB8_7
.LBB8_6:
	adrp	x0, .L.str.14
	add	x0, x0, :lo12:.L.str.14
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #298                        // =0x12a
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_recycle
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_recycle
	bl	__assert_fail
.LBB8_7:
	ldr	x8, [sp, #8]
	cbz	x8, .LBB8_9
	b	.LBB8_8
.LBB8_8:
	ldr	x0, [sp, #8]
	bl	smr_nodes_list_destroy
	stur	x0, [x29, #-16]
	b	.LBB8_9
.LBB8_9:
	ldur	x0, [x29, #-16]
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end8:
	.size	vebr_recycle, .Lfunc_end8-vebr_recycle
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #48]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	ldr	x8, [sp, #48]
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, .LBB9_2
	b	.LBB9_1
.LBB9_1:
	bl	reclaim
	b	.LBB9_10
.LBB9_2:
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	bl	vebr_register
	str	xzr, [sp, #24]
	b	.LBB9_3
.LBB9_3:                                // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	mov	x9, #10000                      // =0x2710
	subs	x8, x8, x9
	b.hs	.LBB9_9
	b	.LBB9_4
.LBB9_4:                                //   in Loop: Header=BB9_3 Depth=1
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	str	x1, [sp, #8]                    // 8-byte Folded Spill
	bl	vebr_enter
	ldr	x2, [sp, #8]                    // 8-byte Folded Reload
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:retire_cb
	ldr	x1, [x1, :got_lo12:retire_cb]
	bl	vqueue_ub_deq
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, .LBB9_6
	b	.LBB9_5
.LBB9_5:                                //   in Loop: Header=BB9_3 Depth=1
	mov	x0, #8                          // =0x8
	bl	malloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #40]
	str	x8, [x9]
	mov	x0, #48                         // =0x30
	bl	malloc
	str	x0, [sp, #16]
	ldr	x1, [sp, #32]
	ldr	x8, [sp, #40]
	ldr	x2, [x8]
	adrp	x0, .L.str.1
	add	x0, x0, :lo12:.L.str.1
	bl	printf
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #40]
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	bl	vqueue_ub_enq
	b	.LBB9_7
.LBB9_6:                                //   in Loop: Header=BB9_3 Depth=1
	ldr	x1, [sp, #32]
	ldr	x8, [sp, #40]
	ldr	x2, [x8]
	adrp	x0, .L.str.2
	add	x0, x0, :lo12:.L.str.2
	bl	printf
	ldr	x0, [sp, #40]
	bl	free
	b	.LBB9_7
.LBB9_7:                                //   in Loop: Header=BB9_3 Depth=1
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	bl	vebr_exit
	b	.LBB9_8
.LBB9_8:                                //   in Loop: Header=BB9_3 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	.LBB9_3
.LBB9_9:
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	sub	x1, x29, #40
	bl	vebr_deregister
	b	.LBB9_10
.LBB9_10:
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB9_12
	b	.LBB9_11
.LBB9_11:
	bl	__stack_chk_fail
.LBB9_12:
	mov	x0, xzr
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end9:
	.size	run, .Lfunc_end9-run
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_register
	.type	vebr_register,@function
vebr_register:                          // @vebr_register
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB10_2
	b	.LBB10_1
.LBB10_1:
	b	.LBB10_3
.LBB10_2:
	adrp	x0, .L.str.16
	add	x0, x0, :lo12:.L.str.16
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #141                        // =0x8d
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_register
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_register
	bl	__assert_fail
.LBB10_3:
	ldr	x8, [sp]
	cbz	x8, .LBB10_5
	b	.LBB10_4
.LBB10_4:
	b	.LBB10_6
.LBB10_5:
	adrp	x0, .L.str.17
	add	x0, x0, :lo12:.L.str.17
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #142                        // =0x8e
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_register
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_register
	bl	__assert_fail
.LBB10_6:
	ldr	x8, [sp]
	add	x0, x8, #16
	mov	x1, xzr
	bl	vatomic64_init
	ldr	x8, [sp]
	str	wzr, [x8, #24]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	ldr	x8, [sp, #8]
	add	x0, x8, #56
	ldr	x1, [sp]
	bl	dbl_list_add
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #80]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end10:
	.size	vebr_register, .Lfunc_end10-vebr_register
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_enter
	.type	vebr_enter,@function
vebr_enter:                             // @vebr_enter
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB11_2
	b	.LBB11_1
.LBB11_1:
	b	.LBB11_3
.LBB11_2:
	adrp	x0, .L.str.16
	add	x0, x0, :lo12:.L.str.16
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #183                        // =0xb7
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_enter
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_enter
	bl	__assert_fail
.LBB11_3:
	ldr	x8, [sp, #16]
	cbz	x8, .LBB11_5
	b	.LBB11_4
.LBB11_4:
	b	.LBB11_6
.LBB11_5:
	adrp	x0, .L.str.17
	add	x0, x0, :lo12:.L.str.17
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #184                        // =0xb8
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_enter
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_enter
	bl	__assert_fail
.LBB11_6:
	ldr	x9, [sp, #16]
	ldr	w8, [x9, #24]
	add	w8, w8, #1
	str	w8, [x9, #24]
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.ne	.LBB11_8
	b	.LBB11_7
.LBB11_7:
	ldur	x0, [x29, #-8]
	bl	vatomic64_read
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	add	x0, x8, #16
	ldr	x1, [sp, #8]
	bl	vatomic64_write_rel
	bl	vatomic_fence
	b	.LBB11_8
.LBB11_8:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end11:
	.size	vebr_enter, .Lfunc_end11-vebr_enter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_deq
	.type	vqueue_ub_deq,@function
vqueue_ub_deq:                          // @vqueue_ub_deq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x29, x30, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, .LBB12_2
	b	.LBB12_1
.LBB12_1:
	b	.LBB12_3
.LBB12_2:
	adrp	x0, .L.str.20
	add	x0, x0, :lo12:.L.str.20
	adrp	x1, .L.str.21
	add	x1, x1, :lo12:.L.str.21
	mov	w2, #179                        // =0xb3
	adrp	x3, .L__PRETTY_FUNCTION__.vqueue_ub_deq
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vqueue_ub_deq
	bl	__assert_fail
.LBB12_3:
	ldur	x8, [x29, #-24]
	cbz	x8, .LBB12_5
	b	.LBB12_4
.LBB12_4:
	b	.LBB12_6
.LBB12_5:
	adrp	x0, .L.str.22
	add	x0, x0, :lo12:.L.str.22
	adrp	x1, .L.str.21
	add	x1, x1, :lo12:.L.str.21
	mov	w2, #180                        // =0xb4
	adrp	x3, .L__PRETTY_FUNCTION__.vqueue_ub_deq
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vqueue_ub_deq
	bl	__assert_fail
.LBB12_6:
	b	.LBB12_7
.LBB12_7:                               // =>This Inner Loop Header: Depth=1
	ldur	x0, [x29, #-16]
	bl	vatomicptr_read
	str	x0, [sp, #40]
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #32]
	ldr	x8, [sp, #40]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #24]
	ldr	x8, [sp, #40]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	bl	vatomicptr_read
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	subs	x8, x8, x0
	b.ne	.LBB12_23
	b	.LBB12_8
.LBB12_8:                               //   in Loop: Header=BB12_7 Depth=1
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.ne	.LBB12_12
	b	.LBB12_9
.LBB12_9:                               //   in Loop: Header=BB12_7 Depth=1
	ldr	x8, [sp, #24]
	cbnz	x8, .LBB12_11
	b	.LBB12_10
.LBB12_10:
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	.LBB12_25
.LBB12_11:                              //   in Loop: Header=BB12_7 Depth=1
	bl	verification_ignore
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #24]
	bl	vatomicptr_cmpxchg
	b	.LBB12_22
.LBB12_12:                              //   in Loop: Header=BB12_7 Depth=1
	ldr	x8, [sp, #24]
	cbz	x8, .LBB12_15
	b	.LBB12_13
.LBB12_13:                              //   in Loop: Header=BB12_7 Depth=1
	mov	w8, #1                          // =0x1
	tbz	w8, #0, .LBB12_15
	b	.LBB12_14
.LBB12_14:                              //   in Loop: Header=BB12_7 Depth=1
	b	.LBB12_16
.LBB12_15:
	adrp	x0, .L.str.24
	add	x0, x0, :lo12:.L.str.24
	adrp	x1, .L.str.21
	add	x1, x1, :lo12:.L.str.21
	mov	w2, #208                        // =0xd0
	adrp	x3, .L__PRETTY_FUNCTION__.vqueue_ub_deq
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vqueue_ub_deq
	bl	__assert_fail
.LBB12_16:                              //   in Loop: Header=BB12_7 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	str	x8, [sp, #16]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #40]
	ldr	x2, [sp, #24]
	bl	vatomicptr_cmpxchg
	ldr	x8, [sp, #40]
	subs	x8, x0, x8
	b.ne	.LBB12_20
	b	.LBB12_17
.LBB12_17:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-16]
	add	x9, x9, #16
	subs	x8, x8, x9
	b.eq	.LBB12_19
	b	.LBB12_18
.LBB12_18:
	ldur	x8, [x29, #-24]
	ldr	x0, [sp, #40]
	ldur	x1, [x29, #-32]
	blr	x8
	b	.LBB12_19
.LBB12_19:
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	.LBB12_25
.LBB12_20:                              //   in Loop: Header=BB12_7 Depth=1
	bl	verification_ignore
	b	.LBB12_21
.LBB12_21:                              //   in Loop: Header=BB12_7 Depth=1
	b	.LBB12_22
.LBB12_22:                              //   in Loop: Header=BB12_7 Depth=1
	b	.LBB12_24
.LBB12_23:                              //   in Loop: Header=BB12_7 Depth=1
	bl	verification_ignore
	b	.LBB12_24
.LBB12_24:                              //   in Loop: Header=BB12_7 Depth=1
	b	.LBB12_7
.LBB12_25:
	ldur	x0, [x29, #-8]
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]             // 16-byte Folded Reload
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end12:
	.size	vqueue_ub_deq, .Lfunc_end12-vqueue_ub_deq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_enq
	.type	vqueue_ub_enq,@function
vqueue_ub_enq:                          // @vqueue_ub_enq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	strb	wzr, [sp, #23]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB13_2
	b	.LBB13_1
.LBB13_1:
	b	.LBB13_3
.LBB13_2:
	adrp	x0, .L.str.20
	add	x0, x0, :lo12:.L.str.20
	adrp	x1, .L.str.21
	add	x1, x1, :lo12:.L.str.21
	mov	w2, #112                        // =0x70
	adrp	x3, .L__PRETTY_FUNCTION__.vqueue_ub_enq
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vqueue_ub_enq
	bl	__assert_fail
.LBB13_3:
	ldur	x8, [x29, #-16]
	cbz	x8, .LBB13_5
	b	.LBB13_4
.LBB13_4:
	b	.LBB13_6
.LBB13_5:
	adrp	x0, .L.str.25
	add	x0, x0, :lo12:.L.str.25
	adrp	x1, .L.str.21
	add	x1, x1, :lo12:.L.str.21
	mov	w2, #113                        // =0x71
	adrp	x3, .L__PRETTY_FUNCTION__.vqueue_ub_enq
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vqueue_ub_enq
	bl	__assert_fail
.LBB13_6:
	ldur	x8, [x29, #-24]
	cbz	x8, .LBB13_8
	b	.LBB13_7
.LBB13_7:
	b	.LBB13_9
.LBB13_8:
	adrp	x0, .L.str.26
	add	x0, x0, :lo12:.L.str.26
	adrp	x1, .L.str.21
	add	x1, x1, :lo12:.L.str.21
	mov	w2, #114                        // =0x72
	adrp	x3, .L__PRETTY_FUNCTION__.vqueue_ub_enq
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vqueue_ub_enq
	bl	__assert_fail
.LBB13_9:
	ldur	x8, [x29, #-24]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	mov	x1, xzr
	bl	vatomicptr_write_rlx
	b	.LBB13_10
.LBB13_10:                              // =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #24]
	ldr	x8, [sp, #32]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	bl	vatomicptr_read
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	subs	x8, x8, x0
	b.ne	.LBB13_18
	b	.LBB13_11
.LBB13_11:                              //   in Loop: Header=BB13_10 Depth=1
	ldr	x8, [sp, #24]
	cbnz	x8, .LBB13_16
	b	.LBB13_12
.LBB13_12:                              //   in Loop: Header=BB13_10 Depth=1
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	ldr	x1, [sp, #24]
	ldur	x2, [x29, #-16]
	bl	vatomicptr_cmpxchg
	ldr	x8, [sp, #24]
	subs	x8, x0, x8
	b.ne	.LBB13_14
	b	.LBB13_13
.LBB13_13:
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	ldr	x1, [sp, #32]
	ldur	x2, [x29, #-16]
	bl	vatomicptr_cmpxchg
	ldr	x8, [sp, #32]
	subs	x8, x0, x8
	cset	w8, eq
	strb	w8, [sp, #23]
	ldrb	w8, [sp, #23]
	and	w0, w8, #0x1
	bl	verification_assume
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB13_14:                              //   in Loop: Header=BB13_10 Depth=1
	.cfi_restore_state
	bl	verification_ignore
	b	.LBB13_15
.LBB13_15:                              //   in Loop: Header=BB13_10 Depth=1
	b	.LBB13_17
.LBB13_16:                              //   in Loop: Header=BB13_10 Depth=1
	bl	verification_ignore
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #24]
	bl	vatomicptr_cmpxchg
	b	.LBB13_17
.LBB13_17:                              //   in Loop: Header=BB13_10 Depth=1
	b	.LBB13_19
.LBB13_18:                              //   in Loop: Header=BB13_10 Depth=1
	bl	verification_ignore
	b	.LBB13_19
.LBB13_19:                              //   in Loop: Header=BB13_10 Depth=1
	b	.LBB13_10
.Lfunc_end13:
	.size	vqueue_ub_enq, .Lfunc_end13-vqueue_ub_enq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_exit
	.type	vebr_exit,@function
vebr_exit:                              // @vebr_exit
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	cbz	x8, .LBB14_2
	b	.LBB14_1
.LBB14_1:
	b	.LBB14_3
.LBB14_2:
	adrp	x0, .L.str.17
	add	x0, x0, :lo12:.L.str.17
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #209                        // =0xd1
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_exit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_exit
	bl	__assert_fail
.LBB14_3:
	ldr	x8, [sp]
	ldr	w8, [x8, #24]
	cbz	w8, .LBB14_5
	b	.LBB14_4
.LBB14_4:
	b	.LBB14_6
.LBB14_5:
	adrp	x0, .L.str.27
	add	x0, x0, :lo12:.L.str.27
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #210                        // =0xd2
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_exit
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_exit
	bl	__assert_fail
.LBB14_6:
	ldr	x8, [sp]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.ne	.LBB14_8
	b	.LBB14_7
.LBB14_7:
	ldr	x8, [sp]
	add	x0, x8, #16
	mov	x1, xzr
	bl	vatomic64_write_rel
	b	.LBB14_8
.LBB14_8:
	ldr	x9, [sp]
	ldr	w8, [x9, #24]
	subs	w8, w8, #1
	str	w8, [x9, #24]
	b	.LBB14_9
.LBB14_9:
	b	.LBB14_10
.LBB14_10:
	b	.LBB14_11
.LBB14_11:
	b	.LBB14_12
.LBB14_12:
	b	.LBB14_13
.LBB14_13:
	b	.LBB14_14
.LBB14_14:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end14:
	.size	vebr_exit, .Lfunc_end14-vebr_exit
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_deregister
	.type	vebr_deregister,@function
vebr_deregister:                        // @vebr_deregister
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB15_2
	b	.LBB15_1
.LBB15_1:
	b	.LBB15_3
.LBB15_2:
	adrp	x0, .L.str.16
	add	x0, x0, :lo12:.L.str.16
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #162                        // =0xa2
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_deregister
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_deregister
	bl	__assert_fail
.LBB15_3:
	ldr	x8, [sp]
	cbz	x8, .LBB15_5
	b	.LBB15_4
.LBB15_4:
	b	.LBB15_6
.LBB15_5:
	adrp	x0, .L.str.17
	add	x0, x0, :lo12:.L.str.17
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #163                        // =0xa3
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_deregister
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_deregister
	bl	__assert_fail
.LBB15_6:
	ldr	x8, [sp]
	add	x0, x8, #16
	bl	vatomic64_read_rlx
	cbnz	x0, .LBB15_8
	b	.LBB15_7
.LBB15_7:
	b	.LBB15_9
.LBB15_8:
	adrp	x0, .L.str.28
	add	x0, x0, :lo12:.L.str.28
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #165                        // =0xa5
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_deregister
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_deregister
	bl	__assert_fail
.LBB15_9:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	ldr	x8, [sp, #8]
	add	x0, x8, #56
	ldr	x1, [sp]
	bl	dbl_list_rem
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #80]
	ldr	x9, [sp, #8]
	ldr	x0, [x9, #88]
	blr	x8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end15:
	.size	vebr_deregister, .Lfunc_end15-vebr_deregister
	.cfi_endproc
                                        // -- End function
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #192
	.cfi_def_cfa_offset 192
	stp	x29, x30, [sp, #176]            // 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	wzr, [sp, #44]
	mov	x1, xzr
	str	xzr, [sp, #32]
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_init
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbnz	w8, .LBB16_2
	b	.LBB16_1
.LBB16_1:
	b	.LBB16_3
.LBB16_2:
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	adrp	x1, .L.str.4
	add	x1, x1, :lo12:.L.str.4
	mov	w2, #113                        // =0x71
	adrp	x3, .L__PRETTY_FUNCTION__.main
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.main
	bl	__assert_fail
.LBB16_3:
	adrp	x8, :got:g_lock_lib
	ldr	x8, [x8, :got_lo12:g_lock_lib]
	ldr	q0, [x8]
	add	x1, sp, #48
	str	q0, [sp, #48]
	ldr	x8, [x8, #16]
	str	x8, [sp, #64]
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	bl	vebr_init
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	bl	vqueue_ub_init
	str	xzr, [sp, #16]
	b	.LBB16_4
.LBB16_4:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #12
	b.hs	.LBB16_7
	b	.LBB16_5
.LBB16_5:                               //   in Loop: Header=BB16_4 Depth=1
	ldr	x9, [sp, #16]
	add	x8, sp, #72
	add	x0, x8, x9, lsl #3
	ldr	x3, [sp, #16]
	mov	x1, xzr
	adrp	x2, :got:run
	ldr	x2, [x2, :got_lo12:run]
	bl	pthread_create
	b	.LBB16_6
.LBB16_6:                               //   in Loop: Header=BB16_4 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB16_4
.LBB16_7:
	mov	x8, #1                          // =0x1
	str	x8, [sp, #8]
	b	.LBB16_8
.LBB16_8:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	subs	x8, x8, #12
	b.hs	.LBB16_11
	b	.LBB16_9
.LBB16_9:                               //   in Loop: Header=BB16_8 Depth=1
	ldr	x9, [sp, #8]
	add	x8, sp, #72
	ldr	x0, [x8, x9, lsl #3]
	mov	x1, xzr
	bl	pthread_join
	b	.LBB16_10
.LBB16_10:                              //   in Loop: Header=BB16_8 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB16_8
.LBB16_11:
	adrp	x0, :got:g_stop
	ldr	x0, [x0, :got_lo12:g_stop]
	mov	w1, #1                          // =0x1
	bl	vatomic8_write
	ldr	x0, [sp, #72]
	mov	x1, xzr
	bl	pthread_join
	b	.LBB16_12
.LBB16_12:                              // =>This Inner Loop Header: Depth=1
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:destroy_cb
	ldr	x1, [x1, :got_lo12:destroy_cb]
	mov	x2, xzr
	bl	vqueue_ub_deq
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbz	x8, .LBB16_14
	b	.LBB16_13
.LBB16_13:                              //   in Loop: Header=BB16_12 Depth=1
	ldr	x0, [sp, #32]
	bl	free
	b	.LBB16_12
.LBB16_14:
	adrp	x0, :got:g_queue
	ldr	x0, [x0, :got_lo12:g_queue]
	adrp	x1, :got:destroy_cb
	ldr	x1, [x1, :got_lo12:destroy_cb]
	mov	x2, xzr
	bl	vqueue_ub_destroy
	adrp	x0, :got:g_vebr
	ldr	x0, [x0, :got_lo12:g_vebr]
	bl	vebr_destroy
	adrp	x0, :got:g_lock
	ldr	x0, [x0, :got_lo12:g_lock]
	bl	pthread_mutex_destroy
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbnz	w8, .LBB16_16
	b	.LBB16_15
.LBB16_15:
	b	.LBB16_17
.LBB16_16:
	adrp	x0, .L.str.3
	add	x0, x0, :lo12:.L.str.3
	adrp	x1, .L.str.4
	add	x1, x1, :lo12:.L.str.4
	mov	w2, #139                        // =0x8b
	adrp	x3, .L__PRETTY_FUNCTION__.main
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.main
	bl	__assert_fail
.LBB16_17:
	ldur	x9, [x29, #-8]
	adrp	x8, :got:__stack_chk_guard
	ldr	x8, [x8, :got_lo12:__stack_chk_guard]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	.LBB16_19
	b	.LBB16_18
.LBB16_18:
	bl	__stack_chk_fail
.LBB16_19:
	mov	w0, wzr
	.cfi_def_cfa wsp, 192
	ldp	x29, x30, [sp, #176]            // 16-byte Folded Reload
	add	sp, sp, #192
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end16:
	.size	main, .Lfunc_end16-main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_init
	.type	vebr_init,@function
vebr_init:                              // @vebr_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp]                        // 8-byte Folded Spill
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB17_2
	b	.LBB17_1
.LBB17_1:
	b	.LBB17_3
.LBB17_2:
	adrp	x0, .L.str.16
	add	x0, x0, :lo12:.L.str.16
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #94                         // =0x5e
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_init
	bl	__assert_fail
.LBB17_3:
	ldur	x8, [x29, #-8]
	add	x0, x8, #56
	bl	dbl_list_init
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #56]
	cbnz	x8, .LBB17_5
	b	.LBB17_4
.LBB17_4:
	b	.LBB17_6
.LBB17_5:
	adrp	x0, .L.str.33
	add	x0, x0, :lo12:.L.str.33
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #96                         // =0x60
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_init
	bl	__assert_fail
.LBB17_6:
	str	xzr, [sp, #8]
	b	.LBB17_7
.LBB17_7:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	subs	x8, x8, #3
	b.hs	.LBB17_10
	b	.LBB17_8
.LBB17_8:                               //   in Loop: Header=BB17_7 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #8
	ldr	x9, [sp, #8]
	add	x0, x8, x9, lsl #4
	bl	smr_nodes_list_init
	b	.LBB17_9
.LBB17_9:                               //   in Loop: Header=BB17_7 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	.LBB17_7
.LBB17_10:
	ldur	x0, [x29, #-8]
	mov	x1, #1                          // =0x1
	bl	vatomic64_write
	ldr	x0, [sp]                        // 8-byte Folded Reload
	bl	smr_lock_lib_is_set
	tbz	w0, #0, .LBB17_12
	b	.LBB17_11
.LBB17_11:
	b	.LBB17_13
.LBB17_12:
	adrp	x0, .L.str.34
	add	x0, x0, :lo12:.L.str.34
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #102                        // =0x66
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_init
	bl	__assert_fail
.LBB17_13:
	ldr	x8, [sp]                        // 8-byte Folded Reload
	ldur	x9, [x29, #-8]
	ldr	q0, [x8]
	stur	q0, [x9, #72]
	ldr	x8, [x8, #16]
	str	x8, [x9, #88]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end17:
	.size	vebr_init, .Lfunc_end17-vebr_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_init
	.type	vqueue_ub_init,@function
vqueue_ub_init:                         // @vqueue_ub_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB18_2
	b	.LBB18_1
.LBB18_1:
	b	.LBB18_3
.LBB18_2:
	adrp	x0, .L.str.20
	add	x0, x0, :lo12:.L.str.20
	adrp	x1, .L.str.21
	add	x1, x1, :lo12:.L.str.21
	mov	w2, #62                         // =0x3e
	adrp	x3, .L__PRETTY_FUNCTION__.vqueue_ub_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vqueue_ub_init
	bl	__assert_fail
.LBB18_3:
	ldr	x8, [sp, #8]
	mov	x1, xzr
	str	xzr, [x8, #16]
	ldr	x8, [sp, #8]
	add	x0, x8, #24
	bl	vatomicptr_write_rlx
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #8]
	add	x1, x8, #16
	bl	vatomicptr_write_rlx
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	ldr	x8, [sp, #8]
	add	x1, x8, #16
	bl	vatomicptr_write_rlx
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end18:
	.size	vqueue_ub_init, .Lfunc_end18-vqueue_ub_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic8_write
	.type	vatomic8_write,@function
vatomic8_write:                         // @vatomic8_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strb	w1, [sp, #7]
	//APP
	//NO_APP
	ldr	x9, [sp, #8]
	ldrb	w8, [sp, #7]
	strb	w8, [sp, #6]
	ldrb	w8, [sp, #6]
	stlrb	w8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end19:
	.size	vatomic8_write, .Lfunc_end19-vatomic8_write
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vqueue_ub_destroy
	.type	vqueue_ub_destroy,@function
vqueue_ub_destroy:                      // @vqueue_ub_destroy
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
	ldur	x0, [x29, #-8]
	bl	vatomicptr_read
	str	x0, [sp, #16]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	b	.LBB20_1
.LBB20_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	cbz	x8, .LBB20_5
	b	.LBB20_2
.LBB20_2:                               //   in Loop: Header=BB20_1 Depth=1
	ldr	x8, [sp, #16]
	add	x0, x8, #8
	bl	vatomicptr_read
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-8]
	add	x9, x9, #16
	subs	x8, x8, x9
	b.eq	.LBB20_4
	b	.LBB20_3
.LBB20_3:                               //   in Loop: Header=BB20_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	blr	x8
	b	.LBB20_4
.LBB20_4:                               //   in Loop: Header=BB20_1 Depth=1
	ldr	x8, [sp, #8]
	str	x8, [sp, #16]
	b	.LBB20_1
.LBB20_5:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end20:
	.size	vqueue_ub_destroy, .Lfunc_end20-vqueue_ub_destroy
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vebr_destroy
	.type	vebr_destroy,@function
vebr_destroy:                           // @vebr_destroy
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	xzr, [sp, #16]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB21_2
	b	.LBB21_1
.LBB21_1:
	b	.LBB21_3
.LBB21_2:
	adrp	x0, .L.str.16
	add	x0, x0, :lo12:.L.str.16
	adrp	x1, .L.str.6
	add	x1, x1, :lo12:.L.str.6
	mov	w2, #122                        // =0x7a
	adrp	x3, .L__PRETTY_FUNCTION__.vebr_destroy
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.vebr_destroy
	bl	__assert_fail
.LBB21_3:
	str	xzr, [sp, #16]
	b	.LBB21_4
.LBB21_4:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #3
	b.hs	.LBB21_7
	b	.LBB21_5
.LBB21_5:                               //   in Loop: Header=BB21_4 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #8
	ldr	x9, [sp, #16]
	add	x0, x8, x9, lsl #4
	bl	smr_nodes_list_get_and_empty
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	smr_nodes_list_destroy
	b	.LBB21_6
.LBB21_6:                               //   in Loop: Header=BB21_4 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB21_4
.LBB21_7:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end21:
	.size	vebr_destroy, .Lfunc_end21-vebr_destroy
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic_fence
	.type	vatomic_fence,@function
vatomic_fence:                          // @vatomic_fence
	.cfi_startproc
// %bb.0:
	//APP
	//NO_APP
	dmb	ish
	//APP
	//NO_APP
	ret
.Lfunc_end22:
	.size	vatomic_fence, .Lfunc_end22-vatomic_fence
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_read
	.type	vatomic64_read,@function
vatomic64_read:                         // @vatomic64_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	//APP
	//NO_APP
	ldr	x8, [sp, #24]
	ldar	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [sp, #16]
	//APP
	//NO_APP
	ldr	x0, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end23:
	.size	vatomic64_read, .Lfunc_end23-vatomic64_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_add
	.type	smr_nodes_list_add,@function
smr_nodes_list_add:                     // @smr_nodes_list_add
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB24_2
	b	.LBB24_1
.LBB24_1:
	b	.LBB24_3
.LBB24_2:
	adrp	x0, .L.str.7
	add	x0, x0, :lo12:.L.str.7
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #110                        // =0x6e
	adrp	x3, .L__PRETTY_FUNCTION__.smr_nodes_list_add
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.smr_nodes_list_add
	bl	__assert_fail
.LBB24_3:
	ldr	x8, [sp, #16]
	cbz	x8, .LBB24_5
	b	.LBB24_4
.LBB24_4:
	b	.LBB24_6
.LBB24_5:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #111                        // =0x6f
	adrp	x3, .L__PRETTY_FUNCTION__.smr_nodes_list_add
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.smr_nodes_list_add
	bl	__assert_fail
.LBB24_6:
	ldr	x8, [sp, #8]
	cbz	x8, .LBB24_8
	b	.LBB24_7
.LBB24_7:
	b	.LBB24_9
.LBB24_8:
	adrp	x0, .L.str.10
	add	x0, x0, :lo12:.L.str.10
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #112                        // =0x70
	adrp	x3, .L__PRETTY_FUNCTION__.smr_nodes_list_add
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.smr_nodes_list_add
	bl	__assert_fail
.LBB24_9:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9, #16]
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	str	x8, [x9, #24]
	ldr	x8, [sp, #16]
                                        // kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #16]
	bl	_smr_nodes_list_connect
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	bl	vatomic64_inc_rlx
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end24:
	.size	smr_nodes_list_add, .Lfunc_end24-smr_nodes_list_add
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _smr_nodes_list_connect
	.type	_smr_nodes_list_connect,@function
_smr_nodes_list_connect:                // @_smr_nodes_list_connect
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB25_2
	b	.LBB25_1
.LBB25_1:
	b	.LBB25_3
.LBB25_2:
	adrp	x0, .L.str.7
	add	x0, x0, :lo12:.L.str.7
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #78                         // =0x4e
	adrp	x3, .L__PRETTY_FUNCTION__._smr_nodes_list_connect
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__._smr_nodes_list_connect
	bl	__assert_fail
.LBB25_3:
	ldur	x8, [x29, #-16]
	cbz	x8, .LBB25_5
	b	.LBB25_4
.LBB25_4:
	b	.LBB25_6
.LBB25_5:
	adrp	x0, .L.str.11
	add	x0, x0, :lo12:.L.str.11
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #79                         // =0x4f
	adrp	x3, .L__PRETTY_FUNCTION__._smr_nodes_list_connect
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__._smr_nodes_list_connect
	bl	__assert_fail
.LBB25_6:
	ldr	x8, [sp, #24]
	cbz	x8, .LBB25_8
	b	.LBB25_7
.LBB25_7:
	b	.LBB25_9
.LBB25_8:
	adrp	x0, .L.str.12
	add	x0, x0, :lo12:.L.str.12
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #80                         // =0x50
	adrp	x3, .L__PRETTY_FUNCTION__._smr_nodes_list_connect
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__._smr_nodes_list_connect
	bl	__assert_fail
.LBB25_9:
	ldur	x0, [x29, #-8]
	bl	vatomicptr_read
	str	x0, [sp, #16]
	b	.LBB25_10
.LBB25_10:                              // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	ldur	x2, [x29, #-16]
	bl	vatomicptr_cmpxchg_rel
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	cset	w0, eq
	bl	verification_assume
	b	.LBB25_11
.LBB25_11:                              //   in Loop: Header=BB25_10 Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	.LBB25_10
	b	.LBB25_12
.LBB25_12:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end25:
	.size	_smr_nodes_list_connect, .Lfunc_end25-_smr_nodes_list_connect
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_inc_rlx
	.type	vatomic64_inc_rlx,@function
vatomic64_inc_rlx:                      // @vatomic64_inc_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	vatomic64_get_inc_rlx
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end26:
	.size	vatomic64_inc_rlx, .Lfunc_end26-vatomic64_inc_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_read
	.type	vatomicptr_read,@function
vatomicptr_read:                        // @vatomicptr_read
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	//APP
	//NO_APP
	ldr	x8, [sp, #24]
	ldar	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [sp, #16]
	//APP
	//NO_APP
	ldr	x0, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end27:
	.size	vatomicptr_read, .Lfunc_end27-vatomicptr_read
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_cmpxchg_rel
	.type	vatomicptr_cmpxchg_rel,@function
vatomicptr_cmpxchg_rel:                 // @vatomicptr_cmpxchg_rel
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #56]
	str	x1, [sp, #48]
	str	x2, [sp, #40]
	ldr	x8, [sp, #48]
	str	x8, [sp, #32]
	//APP
	//NO_APP
	ldr	x11, [sp, #56]
	ldr	x8, [sp, #40]
	str	x8, [sp, #24]
	ldr	x9, [sp, #32]
	ldr	x12, [sp, #24]
.LBB28_1:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x8, [x11]
	cmp	x8, x9
	b.ne	.LBB28_3
// %bb.2:                               //   in Loop: Header=BB28_1 Depth=1
	stlxr	w10, x12, [x11]
	cbnz	w10, .LBB28_1
.LBB28_3:
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	subs	x10, x8, x9
	cset	w10, eq
	str	w10, [sp, #16]                  // 4-byte Folded Spill
	subs	x8, x8, x9
	b.eq	.LBB28_5
	b	.LBB28_4
.LBB28_4:
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #32]
	b	.LBB28_5
.LBB28_5:
	ldr	w8, [sp, #16]                   // 4-byte Folded Reload
	strb	w8, [sp, #23]
	//APP
	//NO_APP
	ldr	x0, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end28:
	.size	vatomicptr_cmpxchg_rel, .Lfunc_end28-vatomicptr_cmpxchg_rel
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function verification_assume
	.type	verification_assume,@function
verification_assume:                    // @verification_assume
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	b	.LBB29_1
.LBB29_1:
	b	.LBB29_2
.LBB29_2:
	b	.LBB29_3
.LBB29_3:
	b	.LBB29_4
.LBB29_4:
	b	.LBB29_5
.LBB29_5:
	b	.LBB29_6
.LBB29_6:
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end29:
	.size	verification_assume, .Lfunc_end29-verification_assume
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_get_inc_rlx
	.type	vatomic64_get_inc_rlx,@function
vatomic64_get_inc_rlx:                  // @vatomic64_get_inc_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, #1                          // =0x1
	bl	vatomic64_get_add_rlx
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end30:
	.size	vatomic64_get_inc_rlx, .Lfunc_end30-vatomic64_get_inc_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_get_add_rlx
	.type	vatomic64_get_add_rlx,@function
vatomic64_get_add_rlx:                  // @vatomic64_get_add_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	str	x0, [sp, #72]
	str	x1, [sp, #64]
	//APP
	//NO_APP
	ldr	x8, [sp, #72]
	str	x8, [sp, #16]                   // 8-byte Folded Spill
	ldr	x9, [sp, #64]
	str	x9, [sp, #48]
	ldr	x9, [sp, #48]
	str	x9, [sp, #24]                   // 8-byte Folded Spill
	ldr	x8, [x8]
	str	x8, [sp, #32]                   // 8-byte Folded Spill
	b	.LBB31_1
.LBB31_1:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB31_2 Depth 2
	ldr	x8, [sp, #32]                   // 8-byte Folded Reload
	ldr	x11, [sp, #16]                  // 8-byte Folded Reload
	ldr	x9, [sp, #24]                   // 8-byte Folded Reload
	add	x12, x8, x9
.LBB31_2:                               //   Parent Loop BB31_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x9, [x11]
	cmp	x9, x8
	b.ne	.LBB31_4
// %bb.3:                               //   in Loop: Header=BB31_2 Depth=2
	stlxr	w10, x12, [x11]
	cbnz	w10, .LBB31_2
.LBB31_4:                               //   in Loop: Header=BB31_1 Depth=1
	str	x9, [sp, #8]                    // 8-byte Folded Spill
	subs	x8, x9, x8
	cset	w8, eq
	str	x9, [sp, #32]                   // 8-byte Folded Spill
	tbz	w8, #0, .LBB31_1
	b	.LBB31_5
.LBB31_5:
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	str	x8, [sp, #56]
	//APP
	//NO_APP
	ldr	x0, [sp, #56]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end31:
	.size	vatomic64_get_add_rlx, .Lfunc_end31-vatomic64_get_add_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_get_and_empty
	.type	smr_nodes_list_get_and_empty,@function
smr_nodes_list_get_and_empty:           // @smr_nodes_list_get_and_empty
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	vatomicptr_xchg_acq
	str	x0, [sp]
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	mov	x1, xzr
	bl	vatomic64_write_rlx
	ldr	x0, [sp]
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end32:
	.size	smr_nodes_list_get_and_empty, .Lfunc_end32-smr_nodes_list_get_and_empty
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function _vebr_sync_epochs
	.type	_vebr_sync_epochs,@function
_vebr_sync_epochs:                      // @_vebr_sync_epochs
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	sturb	w2, [x29, #-17]
                                        // kill: def $x8 killed $xzr
	stur	xzr, [x29, #-32]
	stur	xzr, [x29, #-40]
	str	xzr, [sp, #48]
	mov	x8, #-1                         // =0xffffffffffffffff
	str	x8, [sp, #40]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-8]
	ldr	x0, [x9, #88]
	blr	x8
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #56]
	stur	x8, [x29, #-32]
	b	.LBB33_1
.LBB33_1:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB33_3 Depth 2
	ldur	x8, [x29, #-32]
	cbz	x8, .LBB33_19
	b	.LBB33_2
.LBB33_2:                               //   in Loop: Header=BB33_1 Depth=1
	ldur	x8, [x29, #-32]
	stur	x8, [x29, #-40]
	b	.LBB33_3
.LBB33_3:                               //   Parent Loop BB33_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldur	x8, [x29, #-40]
	add	x0, x8, #16
	bl	vatomic64_read
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, .LBB33_5
	b	.LBB33_4
.LBB33_4:                               //   in Loop: Header=BB33_1 Depth=1
	b	.LBB33_17
.LBB33_5:                               //   in Loop: Header=BB33_3 Depth=2
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-16]
	subs	x8, x8, x9
	b.lo	.LBB33_10
	b	.LBB33_6
.LBB33_6:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #40]
	str	x8, [sp, #32]
	ldr	x8, [sp, #48]
	str	x8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	.LBB33_8
	b	.LBB33_7
.LBB33_7:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #32]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	b	.LBB33_9
.LBB33_8:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	b	.LBB33_9
.LBB33_9:                               //   in Loop: Header=BB33_1 Depth=1
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	str	x8, [sp, #40]
	b	.LBB33_17
.LBB33_10:                              //   in Loop: Header=BB33_3 Depth=2
	ldurb	w8, [x29, #-17]
	tbnz	w8, #0, .LBB33_12
	b	.LBB33_11
.LBB33_11:
	ldr	x8, [sp, #48]
	str	x8, [sp, #40]
	b	.LBB33_20
.LBB33_12:                              //   in Loop: Header=BB33_3 Depth=2
	bl	verification_ignore
	b	.LBB33_13
.LBB33_13:                              //   in Loop: Header=BB33_3 Depth=2
	b	.LBB33_14
.LBB33_14:                              //   in Loop: Header=BB33_3 Depth=2
	b	.LBB33_15
.LBB33_15:                              //   in Loop: Header=BB33_3 Depth=2
	b	.LBB33_16
.LBB33_16:                              //   in Loop: Header=BB33_3 Depth=2
	mov	w8, #1                          // =0x1
	tbnz	w8, #0, .LBB33_3
	b	.LBB33_17
.LBB33_17:                              //   in Loop: Header=BB33_1 Depth=1
	b	.LBB33_18
.LBB33_18:                              //   in Loop: Header=BB33_1 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	stur	x8, [x29, #-32]
	b	.LBB33_1
.LBB33_19:
	b	.LBB33_20
.LBB33_20:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #80]
	ldur	x9, [x29, #-8]
	ldr	x0, [x9, #88]
	blr	x8
	ldr	x8, [sp, #40]
	adds	x8, x8, #1
	b.ne	.LBB33_22
	b	.LBB33_21
.LBB33_21:
	mov	x8, xzr
	str	x8, [sp]                        // 8-byte Folded Spill
	b	.LBB33_23
.LBB33_22:
	ldr	x8, [sp, #40]
	str	x8, [sp]                        // 8-byte Folded Spill
	b	.LBB33_23
.LBB33_23:
	ldr	x0, [sp]                        // 8-byte Folded Reload
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]             // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end33:
	.size	_vebr_sync_epochs, .Lfunc_end33-_vebr_sync_epochs
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_cmpxchg
	.type	vatomic64_cmpxchg,@function
vatomic64_cmpxchg:                      // @vatomic64_cmpxchg
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #56]
	str	x1, [sp, #48]
	str	x2, [sp, #40]
	ldr	x8, [sp, #48]
	str	x8, [sp, #32]
	//APP
	//NO_APP
	ldr	x11, [sp, #56]
	ldr	x8, [sp, #40]
	str	x8, [sp, #24]
	ldr	x9, [sp, #32]
	ldr	x12, [sp, #24]
.LBB34_1:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x8, [x11]
	cmp	x8, x9
	b.ne	.LBB34_3
// %bb.2:                               //   in Loop: Header=BB34_1 Depth=1
	stlxr	w10, x12, [x11]
	cbnz	w10, .LBB34_1
.LBB34_3:
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	subs	x10, x8, x9
	cset	w10, eq
	str	w10, [sp, #16]                  // 4-byte Folded Spill
	subs	x8, x8, x9
	b.eq	.LBB34_5
	b	.LBB34_4
.LBB34_4:
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #32]
	b	.LBB34_5
.LBB34_5:
	ldr	w8, [sp, #16]                   // 4-byte Folded Reload
	strb	w8, [sp, #23]
	//APP
	//NO_APP
	ldr	x0, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end34:
	.size	vatomic64_cmpxchg, .Lfunc_end34-vatomic64_cmpxchg
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_destroy
	.type	smr_nodes_list_destroy,@function
smr_nodes_list_destroy:                 // @smr_nodes_list_destroy
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #8]
                                        // kill: def $x8 killed $xzr
	str	xzr, [sp]
	b	.LBB35_1
.LBB35_1:                               // =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	cbz	x8, .LBB35_6
	b	.LBB35_2
.LBB35_2:                               //   in Loop: Header=BB35_1 Depth=1
	ldr	x8, [sp, #8]
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp]
	ldr	x8, [x8, #16]
	cbz	x8, .LBB35_4
	b	.LBB35_3
.LBB35_3:                               //   in Loop: Header=BB35_1 Depth=1
	b	.LBB35_5
.LBB35_4:
	adrp	x0, .L.str.15
	add	x0, x0, :lo12:.L.str.15
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #197                        // =0xc5
	adrp	x3, .L__PRETTY_FUNCTION__.smr_nodes_list_destroy
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.smr_nodes_list_destroy
	bl	__assert_fail
.LBB35_5:                               //   in Loop: Header=BB35_1 Depth=1
	ldr	x8, [sp]
	ldr	x8, [x8, #16]
	ldr	x0, [sp]
	ldr	x9, [sp]
	ldr	x1, [x9, #24]
	blr	x8
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	.LBB35_1
.LBB35_6:
	ldr	x0, [sp, #16]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end35:
	.size	smr_nodes_list_destroy, .Lfunc_end35-smr_nodes_list_destroy
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_xchg_acq
	.type	vatomicptr_xchg_acq,@function
vatomicptr_xchg_acq:                    // @vatomicptr_xchg_acq
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	str	x0, [sp, #72]
	str	x1, [sp, #64]
	//APP
	//NO_APP
	ldr	x8, [sp, #72]
	str	x8, [sp, #16]                   // 8-byte Folded Spill
	ldr	x9, [sp, #64]
	str	x9, [sp, #48]
	ldr	x9, [sp, #48]
	str	x9, [sp, #24]                   // 8-byte Folded Spill
	ldr	x8, [x8]
	str	x8, [sp, #32]                   // 8-byte Folded Spill
	b	.LBB36_1
.LBB36_1:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB36_2 Depth 2
	ldr	x8, [sp, #32]                   // 8-byte Folded Reload
	ldr	x11, [sp, #16]                  // 8-byte Folded Reload
	ldr	x12, [sp, #24]                  // 8-byte Folded Reload
.LBB36_2:                               //   Parent Loop BB36_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldaxr	x9, [x11]
	cmp	x9, x8
	b.ne	.LBB36_4
// %bb.3:                               //   in Loop: Header=BB36_2 Depth=2
	stlxr	w10, x12, [x11]
	cbnz	w10, .LBB36_2
.LBB36_4:                               //   in Loop: Header=BB36_1 Depth=1
	str	x9, [sp, #8]                    // 8-byte Folded Spill
	subs	x8, x9, x8
	cset	w8, eq
	str	x9, [sp, #32]                   // 8-byte Folded Spill
	tbz	w8, #0, .LBB36_1
	b	.LBB36_5
.LBB36_5:
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	str	x8, [sp, #56]
	//APP
	//NO_APP
	ldr	x0, [sp, #56]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end36:
	.size	vatomicptr_xchg_acq, .Lfunc_end36-vatomicptr_xchg_acq
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_write_rlx
	.type	vatomic64_write_rlx,@function
vatomic64_write_rlx:                    // @vatomic64_write_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	//APP
	//NO_APP
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end37:
	.size	vatomic64_write_rlx, .Lfunc_end37-vatomic64_write_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function verification_ignore
	.type	verification_ignore,@function
verification_ignore:                    // @verification_ignore
	.cfi_startproc
// %bb.0:
	ret
.Lfunc_end38:
	.size	verification_ignore, .Lfunc_end38-verification_ignore
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_init
	.type	vatomic64_init,@function
vatomic64_init:                         // @vatomic64_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	vatomic64_write
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end39:
	.size	vatomic64_init, .Lfunc_end39-vatomic64_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function dbl_list_add
	.type	dbl_list_add,@function
dbl_list_add:                           // @dbl_list_add
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB40_2
	b	.LBB40_1
.LBB40_1:
	b	.LBB40_3
.LBB40_2:
	adrp	x0, .L.str.18
	add	x0, x0, :lo12:.L.str.18
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #40                         // =0x28
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_add
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_add
	bl	__assert_fail
.LBB40_3:
	ldr	x8, [sp]
	cbz	x8, .LBB40_5
	b	.LBB40_4
.LBB40_4:
	b	.LBB40_6
.LBB40_5:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #41                         // =0x29
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_add
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_add
	bl	__assert_fail
.LBB40_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbz	x8, .LBB40_8
	b	.LBB40_7
.LBB40_7:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	str	x8, [x9, #8]
	b	.LBB40_8
.LBB40_8:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x8, [sp]
                                        // kill: def $x9 killed $xzr
	str	xzr, [x8, #8]
	ldr	x9, [sp, #8]
	ldr	x8, [x9, #8]
	add	x8, x8, #1
	str	x8, [x9, #8]
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end40:
	.size	dbl_list_add, .Lfunc_end40-dbl_list_add
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_write
	.type	vatomic64_write,@function
vatomic64_write:                        // @vatomic64_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	//APP
	//NO_APP
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	stlr	x8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end41:
	.size	vatomic64_write, .Lfunc_end41-vatomic64_write
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_write_rel
	.type	vatomic64_write_rel,@function
vatomic64_write_rel:                    // @vatomic64_write_rel
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	//APP
	//NO_APP
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	stlr	x8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end42:
	.size	vatomic64_write_rel, .Lfunc_end42-vatomic64_write_rel
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_cmpxchg
	.type	vatomicptr_cmpxchg,@function
vatomicptr_cmpxchg:                     // @vatomicptr_cmpxchg
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #56]
	str	x1, [sp, #48]
	str	x2, [sp, #40]
	ldr	x8, [sp, #48]
	str	x8, [sp, #32]
	//APP
	//NO_APP
	ldr	x11, [sp, #56]
	ldr	x8, [sp, #40]
	str	x8, [sp, #24]
	ldr	x9, [sp, #32]
	ldr	x12, [sp, #24]
.LBB43_1:                               // =>This Inner Loop Header: Depth=1
	ldaxr	x8, [x11]
	cmp	x8, x9
	b.ne	.LBB43_3
// %bb.2:                               //   in Loop: Header=BB43_1 Depth=1
	stlxr	w10, x12, [x11]
	cbnz	w10, .LBB43_1
.LBB43_3:
	str	x8, [sp, #8]                    // 8-byte Folded Spill
	subs	x10, x8, x9
	cset	w10, eq
	str	w10, [sp, #16]                  // 4-byte Folded Spill
	subs	x8, x8, x9
	b.eq	.LBB43_5
	b	.LBB43_4
.LBB43_4:
	ldr	x8, [sp, #8]                    // 8-byte Folded Reload
	str	x8, [sp, #32]
	b	.LBB43_5
.LBB43_5:
	ldr	w8, [sp, #16]                   // 4-byte Folded Reload
	strb	w8, [sp, #23]
	//APP
	//NO_APP
	ldr	x0, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end43:
	.size	vatomicptr_cmpxchg, .Lfunc_end43-vatomicptr_cmpxchg
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_write_rlx
	.type	vatomicptr_write_rlx,@function
vatomicptr_write_rlx:                   // @vatomicptr_write_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	//APP
	//NO_APP
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end44:
	.size	vatomicptr_write_rlx, .Lfunc_end44-vatomicptr_write_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomic64_read_rlx
	.type	vatomic64_read_rlx,@function
vatomic64_read_rlx:                     // @vatomic64_read_rlx
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	//APP
	//NO_APP
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	str	x8, [sp, #16]
	//APP
	//NO_APP
	ldr	x0, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end45:
	.size	vatomic64_read_rlx, .Lfunc_end45-vatomic64_read_rlx
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function dbl_list_rem
	.type	dbl_list_rem,@function
dbl_list_rem:                           // @dbl_list_rem
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbz	x8, .LBB46_2
	b	.LBB46_1
.LBB46_1:
	b	.LBB46_3
.LBB46_2:
	adrp	x0, .L.str.18
	add	x0, x0, :lo12:.L.str.18
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #55                         // =0x37
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_rem
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_rem
	bl	__assert_fail
.LBB46_3:
	ldr	x8, [sp, #16]
	cbz	x8, .LBB46_5
	b	.LBB46_4
.LBB46_4:
	b	.LBB46_6
.LBB46_5:
	adrp	x0, .L.str.9
	add	x0, x0, :lo12:.L.str.9
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #56                         // =0x38
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_rem
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_rem
	bl	__assert_fail
.LBB46_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	str	x8, [sp]
	ldr	x8, [sp]
	cbz	x8, .LBB46_14
	b	.LBB46_7
.LBB46_7:
	ldr	x8, [sp]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	.LBB46_9
	b	.LBB46_8
.LBB46_8:
	b	.LBB46_10
.LBB46_9:
	adrp	x0, .L.str.29
	add	x0, x0, :lo12:.L.str.29
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #62                         // =0x3e
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_rem
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_rem
	bl	__assert_fail
.LBB46_10:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.eq	.LBB46_12
	b	.LBB46_11
.LBB46_11:
	b	.LBB46_13
.LBB46_12:
	adrp	x0, .L.str.30
	add	x0, x0, :lo12:.L.str.30
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #63                         // =0x3f
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_rem
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_rem
	bl	__assert_fail
.LBB46_13:
	ldr	x8, [sp, #8]
	ldr	x9, [sp]
	str	x8, [x9]
	b	.LBB46_18
.LBB46_14:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	.LBB46_16
	b	.LBB46_15
.LBB46_15:
	b	.LBB46_17
.LBB46_16:
	adrp	x0, .L.str.31
	add	x0, x0, :lo12:.L.str.31
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #66                         // =0x42
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_rem
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_rem
	bl	__assert_fail
.LBB46_17:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-8]
	str	x8, [x9]
	b	.LBB46_18
.LBB46_18:
	ldr	x8, [sp, #8]
	cbz	x8, .LBB46_23
	b	.LBB46_19
.LBB46_19:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	.LBB46_21
	b	.LBB46_20
.LBB46_20:
	b	.LBB46_22
.LBB46_21:
	adrp	x0, .L.str.32
	add	x0, x0, :lo12:.L.str.32
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #71                         // =0x47
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_rem
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_rem
	bl	__assert_fail
.LBB46_22:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9, #8]
	b	.LBB46_23
.LBB46_23:
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	subs	x8, x8, #1
	str	x8, [x9, #8]
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end46:
	.size	dbl_list_rem, .Lfunc_end46-dbl_list_rem
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function dbl_list_init
	.type	dbl_list_init,@function
dbl_list_init:                          // @dbl_list_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB47_2
	b	.LBB47_1
.LBB47_1:
	b	.LBB47_3
.LBB47_2:
	adrp	x0, .L.str.18
	add	x0, x0, :lo12:.L.str.18
	adrp	x1, .L.str.19
	add	x1, x1, :lo12:.L.str.19
	mov	w2, #32                         // =0x20
	adrp	x3, .L__PRETTY_FUNCTION__.dbl_list_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.dbl_list_init
	bl	__assert_fail
.LBB47_3:
	ldr	x8, [sp, #8]
                                        // kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	xzr, [x8, #8]
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end47:
	.size	dbl_list_init, .Lfunc_end47-dbl_list_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_nodes_list_init
	.type	smr_nodes_list_init,@function
smr_nodes_list_init:                    // @smr_nodes_list_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, .LBB48_2
	b	.LBB48_1
.LBB48_1:
	b	.LBB48_3
.LBB48_2:
	adrp	x0, .L.str.7
	add	x0, x0, :lo12:.L.str.7
	adrp	x1, .L.str.8
	add	x1, x1, :lo12:.L.str.8
	mov	w2, #34                         // =0x22
	adrp	x3, .L__PRETTY_FUNCTION__.smr_nodes_list_init
	add	x3, x3, :lo12:.L__PRETTY_FUNCTION__.smr_nodes_list_init
	bl	__assert_fail
.LBB48_3:
	ldr	x0, [sp, #8]
	mov	x1, xzr
	bl	vatomicptr_init
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	mov	x1, xzr
	bl	vatomic64_init
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end48:
	.size	smr_nodes_list_init, .Lfunc_end48-smr_nodes_list_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function smr_lock_lib_is_set
	.type	smr_lock_lib_is_set,@function
smr_lock_lib_is_set:                    // @smr_lock_lib_is_set
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, .LBB49_2
	b	.LBB49_1
.LBB49_1:
	mov	w8, wzr
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	.LBB49_7
.LBB49_2:
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbnz	x8, .LBB49_4
	b	.LBB49_3
.LBB49_3:
	mov	w8, wzr
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	.LBB49_7
.LBB49_4:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	cbnz	x8, .LBB49_6
	b	.LBB49_5
.LBB49_5:
	mov	w8, wzr
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	.LBB49_7
.LBB49_6:
	mov	w8, #1                          // =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	.LBB49_7
.LBB49_7:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end49:
	.size	smr_lock_lib_is_set, .Lfunc_end49-smr_lock_lib_is_set
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_init
	.type	vatomicptr_init,@function
vatomicptr_init:                        // @vatomicptr_init
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	vatomicptr_write
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end50:
	.size	vatomicptr_init, .Lfunc_end50-vatomicptr_init
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function vatomicptr_write
	.type	vatomicptr_write,@function
vatomicptr_write:                       // @vatomicptr_write
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	//APP
	//NO_APP
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	stlr	x8, [x9]
	//APP
	//NO_APP
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end51:
	.size	vatomicptr_write, .Lfunc_end51-vatomicptr_write
	.cfi_endproc
                                        // -- End function
	.type	g_lock,@object                  // @g_lock
	.bss
	.globl	g_lock
	.p2align	3, 0x0
g_lock:
	.zero	48
	.size	g_lock, 48

	.type	g_lock_lib,@object              // @g_lock_lib
	.data
	.globl	g_lock_lib
	.p2align	3, 0x0
g_lock_lib:
	.xword	lock_acq
	.xword	lock_rel
	.xword	g_lock
	.size	g_lock_lib, 24

	.type	g_vebr,@object                  // @g_vebr
	.bss
	.globl	g_vebr
	.p2align	7, 0x0
g_vebr:
	.zero	128
	.size	g_vebr, 128

	.type	g_stop,@object                  // @g_stop
	.globl	g_stop
g_stop:
	.zero	1
	.size	g_stop, 1

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu node(s) were reclaimed\n"
	.size	.L.str, 28

	.type	g_queue,@object                 // @g_queue
	.bss
	.globl	g_queue
	.p2align	3, 0x0
g_queue:
	.zero	64
	.size	g_queue, 64

	.type	.L.str.1,@object                // @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"[T%zu] enq %zu\n"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"[T%zu] deq %zu\n"
	.size	.L.str.2, 16

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"ret == 0"
	.size	.L.str.3, 9

	.type	.L.str.4,@object                // @.str.4
.L.str.4:
	.asciz	"C:/rc1111/src/libvsync/examples/eg_vebr.c"
	.size	.L.str.4, 42

	.type	.L__PRETTY_FUNCTION__.main,@object // @__PRETTY_FUNCTION__.main
.L__PRETTY_FUNCTION__.main:
	.asciz	"int main(void)"
	.size	.L__PRETTY_FUNCTION__.main, 15

	.type	.L__PRETTY_FUNCTION__.lock_acq,@object // @__PRETTY_FUNCTION__.lock_acq
.L__PRETTY_FUNCTION__.lock_acq:
	.asciz	"void lock_acq(void *)"
	.size	.L__PRETTY_FUNCTION__.lock_acq, 22

	.type	.L__PRETTY_FUNCTION__.lock_rel,@object // @__PRETTY_FUNCTION__.lock_rel
.L__PRETTY_FUNCTION__.lock_rel:
	.asciz	"void lock_rel(void *)"
	.size	.L__PRETTY_FUNCTION__.lock_rel, 22

	.type	.L.str.5,@object                // @.str.5
.L.str.5:
	.asciz	"idx <= (vuint64_t)3"
	.size	.L.str.5, 20

	.type	.L.str.6,@object                // @.str.6
.L.str.6:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/smr/ebr.h"
	.size	.L.str.6, 47

	.type	.L__PRETTY_FUNCTION__.vebr_retire,@object // @__PRETTY_FUNCTION__.vebr_retire
.L__PRETTY_FUNCTION__.vebr_retire:
	.asciz	"void vebr_retire(vebr_t *, vebr_thread_t *, smr_node_t *, smr_node_destroy_fun, void *)"
	.size	.L__PRETTY_FUNCTION__.vebr_retire, 88

	.type	.L.str.7,@object                // @.str.7
.L.str.7:
	.asciz	"lst"
	.size	.L.str.7, 4

	.type	.L.str.8,@object                // @.str.8
.L.str.8:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/smr/internal/smr_nodes_list.h"
	.size	.L.str.8, 67

	.type	.L__PRETTY_FUNCTION__.smr_nodes_list_add,@object // @__PRETTY_FUNCTION__.smr_nodes_list_add
.L__PRETTY_FUNCTION__.smr_nodes_list_add:
	.asciz	"void smr_nodes_list_add(smr_nodes_list_t *, smr_node_t *, smr_node_destroy_fun, void *)"
	.size	.L__PRETTY_FUNCTION__.smr_nodes_list_add, 88

	.type	.L.str.9,@object                // @.str.9
.L.str.9:
	.asciz	"node"
	.size	.L.str.9, 5

	.type	.L.str.10,@object               // @.str.10
.L.str.10:
	.asciz	"destroy_fun"
	.size	.L.str.10, 12

	.type	.L__PRETTY_FUNCTION__._smr_nodes_list_connect,@object // @__PRETTY_FUNCTION__._smr_nodes_list_connect
.L__PRETTY_FUNCTION__._smr_nodes_list_connect:
	.asciz	"void _smr_nodes_list_connect(smr_nodes_list_t *, smr_node_core_t *, smr_node_core_t *)"
	.size	.L__PRETTY_FUNCTION__._smr_nodes_list_connect, 87

	.type	.L.str.11,@object               // @.str.11
.L.str.11:
	.asciz	"head"
	.size	.L.str.11, 5

	.type	.L.str.12,@object               // @.str.12
.L.str.12:
	.asciz	"tail"
	.size	.L.str.12, 5

	.type	.L.str.13,@object               // @.str.13
.L.str.13:
	.asciz	"lcl_epoch == 0 || lcl_epoch >= glb_epoch"
	.size	.L.str.13, 41

	.type	.L__PRETTY_FUNCTION__.vebr_recycle,@object // @__PRETTY_FUNCTION__.vebr_recycle
.L__PRETTY_FUNCTION__.vebr_recycle:
	.asciz	"vsize_t vebr_recycle(vebr_t *)"
	.size	.L__PRETTY_FUNCTION__.vebr_recycle, 31

	.type	.L.str.14,@object               // @.str.14
.L.str.14:
	.asciz	"ret_epoch >= glb_epoch"
	.size	.L.str.14, 23

	.type	.L.str.15,@object               // @.str.15
.L.str.15:
	.asciz	"freed_node->destroy_fun"
	.size	.L.str.15, 24

	.type	.L__PRETTY_FUNCTION__.smr_nodes_list_destroy,@object // @__PRETTY_FUNCTION__.smr_nodes_list_destroy
.L__PRETTY_FUNCTION__.smr_nodes_list_destroy:
	.asciz	"vsize_t smr_nodes_list_destroy(smr_node_t *)"
	.size	.L__PRETTY_FUNCTION__.smr_nodes_list_destroy, 45

	.type	.L.str.16,@object               // @.str.16
.L.str.16:
	.asciz	"ebr"
	.size	.L.str.16, 4

	.type	.L__PRETTY_FUNCTION__.vebr_register,@object // @__PRETTY_FUNCTION__.vebr_register
.L__PRETTY_FUNCTION__.vebr_register:
	.asciz	"void vebr_register(vebr_t *, vebr_thread_t *)"
	.size	.L__PRETTY_FUNCTION__.vebr_register, 46

	.type	.L.str.17,@object               // @.str.17
.L.str.17:
	.asciz	"ebr_thrd"
	.size	.L.str.17, 9

	.type	.L.str.18,@object               // @.str.18
.L.str.18:
	.asciz	"list"
	.size	.L.str.18, 5

	.type	.L.str.19,@object               // @.str.19
.L.str.19:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/smr/internal/dbl_list.h"
	.size	.L.str.19, 61

	.type	.L__PRETTY_FUNCTION__.dbl_list_add,@object // @__PRETTY_FUNCTION__.dbl_list_add
.L__PRETTY_FUNCTION__.dbl_list_add:
	.asciz	"void dbl_list_add(dbl_list_t *, dbl_list_node_t *)"
	.size	.L__PRETTY_FUNCTION__.dbl_list_add, 51

	.type	.L__PRETTY_FUNCTION__.vebr_enter,@object // @__PRETTY_FUNCTION__.vebr_enter
.L__PRETTY_FUNCTION__.vebr_enter:
	.asciz	"void vebr_enter(vebr_t *, vebr_thread_t *)"
	.size	.L__PRETTY_FUNCTION__.vebr_enter, 43

	.type	.L.str.20,@object               // @.str.20
.L.str.20:
	.asciz	"q"
	.size	.L.str.20, 2

	.type	.L.str.21,@object               // @.str.21
.L.str.21:
	.asciz	"C:/rc1111/src/libvsync/include/vsync/queue/unbounded_queue_lf.h"
	.size	.L.str.21, 64

	.type	.L__PRETTY_FUNCTION__.vqueue_ub_deq,@object // @__PRETTY_FUNCTION__.vqueue_ub_deq
.L__PRETTY_FUNCTION__.vqueue_ub_deq:
	.asciz	"void *vqueue_ub_deq(vqueue_ub_t *, vqueue_ub_node_handler_t, void *)"
	.size	.L__PRETTY_FUNCTION__.vqueue_ub_deq, 69

	.type	.L.str.22,@object               // @.str.22
.L.str.22:
	.asciz	"retire"
	.size	.L.str.22, 7

	.type	.L.str.23,@object               // @.str.23
.L.str.23:
	.asciz	"next is not expected to be NULL, since the queue is not empty"
	.size	.L.str.23, 62

	.type	.L.str.24,@object               // @.str.24
.L.str.24:
	.asciz	"next && \"next is not expected to be NULL, since the queue is \" \"not empty\""
	.size	.L.str.24, 75

	.type	.L__PRETTY_FUNCTION__.vqueue_ub_enq,@object // @__PRETTY_FUNCTION__.vqueue_ub_enq
.L__PRETTY_FUNCTION__.vqueue_ub_enq:
	.asciz	"void vqueue_ub_enq(vqueue_ub_t *, vqueue_ub_node_t *, void *)"
	.size	.L__PRETTY_FUNCTION__.vqueue_ub_enq, 62

	.type	.L.str.25,@object               // @.str.25
.L.str.25:
	.asciz	"qnode"
	.size	.L.str.25, 6

	.type	.L.str.26,@object               // @.str.26
.L.str.26:
	.asciz	"data"
	.size	.L.str.26, 5

	.type	.L__PRETTY_FUNCTION__.vebr_exit,@object // @__PRETTY_FUNCTION__.vebr_exit
.L__PRETTY_FUNCTION__.vebr_exit:
	.asciz	"void vebr_exit(vebr_t *, vebr_thread_t *)"
	.size	.L__PRETTY_FUNCTION__.vebr_exit, 42

	.type	.L.str.27,@object               // @.str.27
.L.str.27:
	.asciz	"ebr_thrd->enter_count"
	.size	.L.str.27, 22

	.type	.L__PRETTY_FUNCTION__.vebr_deregister,@object // @__PRETTY_FUNCTION__.vebr_deregister
.L__PRETTY_FUNCTION__.vebr_deregister:
	.asciz	"void vebr_deregister(vebr_t *, vebr_thread_t *)"
	.size	.L__PRETTY_FUNCTION__.vebr_deregister, 48

	.type	.L.str.28,@object               // @.str.28
.L.str.28:
	.asciz	"vatomic64_read_rlx(&ebr_thrd->epoch_local) == 0"
	.size	.L.str.28, 48

	.type	.L__PRETTY_FUNCTION__.dbl_list_rem,@object // @__PRETTY_FUNCTION__.dbl_list_rem
.L__PRETTY_FUNCTION__.dbl_list_rem:
	.asciz	"void dbl_list_rem(dbl_list_t *, dbl_list_node_t *)"
	.size	.L__PRETTY_FUNCTION__.dbl_list_rem, 51

	.type	.L.str.29,@object               // @.str.29
.L.str.29:
	.asciz	"prev->next == node"
	.size	.L.str.29, 19

	.type	.L.str.30,@object               // @.str.30
.L.str.30:
	.asciz	"list->head != node"
	.size	.L.str.30, 19

	.type	.L.str.31,@object               // @.str.31
.L.str.31:
	.asciz	"list->head == node"
	.size	.L.str.31, 19

	.type	.L.str.32,@object               // @.str.32
.L.str.32:
	.asciz	"succ->prev == node"
	.size	.L.str.32, 19

	.type	.L__PRETTY_FUNCTION__.vebr_init,@object // @__PRETTY_FUNCTION__.vebr_init
.L__PRETTY_FUNCTION__.vebr_init:
	.asciz	"void vebr_init(vebr_t *, smr_lock_lib_t)"
	.size	.L__PRETTY_FUNCTION__.vebr_init, 41

	.type	.L.str.33,@object               // @.str.33
.L.str.33:
	.asciz	"ebr->threads.head == ((void*)0)"
	.size	.L.str.33, 32

	.type	.L.str.34,@object               // @.str.34
.L.str.34:
	.asciz	"smr_lock_lib_is_set(&lock_lib)"
	.size	.L.str.34, 31

	.type	.L__PRETTY_FUNCTION__.dbl_list_init,@object // @__PRETTY_FUNCTION__.dbl_list_init
.L__PRETTY_FUNCTION__.dbl_list_init:
	.asciz	"void dbl_list_init(dbl_list_t *)"
	.size	.L__PRETTY_FUNCTION__.dbl_list_init, 33

	.type	.L__PRETTY_FUNCTION__.smr_nodes_list_init,@object // @__PRETTY_FUNCTION__.smr_nodes_list_init
.L__PRETTY_FUNCTION__.smr_nodes_list_init:
	.asciz	"void smr_nodes_list_init(smr_nodes_list_t *)"
	.size	.L__PRETTY_FUNCTION__.smr_nodes_list_init, 45

	.type	.L__PRETTY_FUNCTION__.vqueue_ub_init,@object // @__PRETTY_FUNCTION__.vqueue_ub_init
.L__PRETTY_FUNCTION__.vqueue_ub_init:
	.asciz	"void vqueue_ub_init(vqueue_ub_t *)"
	.size	.L__PRETTY_FUNCTION__.vqueue_ub_init, 35

	.type	.L__PRETTY_FUNCTION__.vebr_destroy,@object // @__PRETTY_FUNCTION__.vebr_destroy
.L__PRETTY_FUNCTION__.vebr_destroy:
	.asciz	"void vebr_destroy(vebr_t *)"
	.size	.L__PRETTY_FUNCTION__.vebr_destroy, 28

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym lock_acq
	.addrsig_sym lock_rel
	.addrsig_sym free_cb
	.addrsig_sym free
	.addrsig_sym retire_cb
	.addrsig_sym vebr_retire
	.addrsig_sym destroy_cb
	.addrsig_sym reclaim
	.addrsig_sym vatomic8_read
	.addrsig_sym vebr_recycle
	.addrsig_sym printf
	.addrsig_sym run
	.addrsig_sym vebr_register
	.addrsig_sym vebr_enter
	.addrsig_sym vqueue_ub_deq
	.addrsig_sym malloc
	.addrsig_sym vqueue_ub_enq
	.addrsig_sym vebr_exit
	.addrsig_sym vebr_deregister
	.addrsig_sym pthread_mutex_init
	.addrsig_sym __assert_fail
	.addrsig_sym vebr_init
	.addrsig_sym vqueue_ub_init
	.addrsig_sym pthread_create
	.addrsig_sym pthread_join
	.addrsig_sym vatomic8_write
	.addrsig_sym vqueue_ub_destroy
	.addrsig_sym vebr_destroy
	.addrsig_sym pthread_mutex_destroy
	.addrsig_sym pthread_mutex_lock
	.addrsig_sym pthread_mutex_unlock
	.addrsig_sym vatomic_fence
	.addrsig_sym vatomic64_read
	.addrsig_sym smr_nodes_list_add
	.addrsig_sym _smr_nodes_list_connect
	.addrsig_sym vatomic64_inc_rlx
	.addrsig_sym vatomicptr_read
	.addrsig_sym vatomicptr_cmpxchg_rel
	.addrsig_sym verification_assume
	.addrsig_sym vatomic64_get_inc_rlx
	.addrsig_sym vatomic64_get_add_rlx
	.addrsig_sym smr_nodes_list_get_and_empty
	.addrsig_sym _vebr_sync_epochs
	.addrsig_sym vatomic64_cmpxchg
	.addrsig_sym smr_nodes_list_destroy
	.addrsig_sym vatomicptr_xchg_acq
	.addrsig_sym vatomic64_write_rlx
	.addrsig_sym verification_ignore
	.addrsig_sym vatomic64_init
	.addrsig_sym dbl_list_add
	.addrsig_sym vatomic64_write
	.addrsig_sym vatomic64_write_rel
	.addrsig_sym vatomicptr_cmpxchg
	.addrsig_sym vatomicptr_write_rlx
	.addrsig_sym vatomic64_read_rlx
	.addrsig_sym dbl_list_rem
	.addrsig_sym dbl_list_init
	.addrsig_sym smr_nodes_list_init
	.addrsig_sym smr_lock_lib_is_set
	.addrsig_sym vatomicptr_init
	.addrsig_sym vatomicptr_write
	.addrsig_sym g_lock
	.addrsig_sym g_lock_lib
	.addrsig_sym g_vebr
	.addrsig_sym g_stop
	.addrsig_sym g_queue
