	.file	"eg_bitmap.c"
	.text
	.globl	reader                          // -- Begin function reader
	.p2align	2
	.type	reader,@function
reader:                                 // @reader
	.cfi_startproc
// %bb.0:
	str	x30, [sp, #-48]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -48
	adrp	x21, :got:g_bitmap
	mov	w22, #1                         // =0x1
	adrp	x19, .L.str
	add	x19, x19, :lo12:.L.str
	ldr	x21, [x21, :got_lo12:g_bitmap]
.LBB0_1:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_3 Depth 2
                                        //     Child Loop BB0_5 Depth 2
	ldr	x9, [x21]
	mov	x8, xzr
	mov	x20, xzr
	add	x10, x9, #16
	//APP
	ldar	x11, [x10]
	//NO_APP
	add	x10, x9, #24
	cbnz	x11, .LBB0_5
.LBB0_2:                                //   in Loop: Header=BB0_1 Depth=1
	ldr	x12, [x9]
	add	x13, x10, x8, lsl #3
.LBB0_3:                                //   Parent Loop BB0_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	add	x8, x8, #1
	cmp	x8, x12
	b.hs	.LBB0_7
// %bb.4:                               //   in Loop: Header=BB0_3 Depth=2
	//APP
	ldar	x11, [x13]
	//NO_APP
	add	x13, x13, #8
	cbz	x11, .LBB0_3
.LBB0_5:                                //   Parent Loop BB0_1 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	rbit	x12, x11
	ldr	x14, [x9, #8]
	clz	x12, x12
	orr	x13, x12, x8, lsl #6
	cmp	x13, x14
	b.hs	.LBB0_7
// %bb.6:                               //   in Loop: Header=BB0_5 Depth=2
	lsl	x12, x22, x12
	add	x20, x20, #1
	bic	x11, x11, x12
	cbz	x11, .LBB0_2
	b	.LBB0_5
.LBB0_7:                                //   in Loop: Header=BB0_1 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	w2, #693                        // =0x2b5
	bl	printf
	cmp	x20, #693
	b.lo	.LBB0_1
// %bb.8:
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldr	x30, [sp], #48                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	ret
.Lfunc_end0:
	.size	reader, .Lfunc_end0-reader
	.cfi_endproc
                                        // -- End function
	.globl	writer                          // -- Begin function writer
	.p2align	2
	.type	writer,@function
writer:                                 // @writer
	.cfi_startproc
// %bb.0:
	adrp	x8, :got:g_bitmap
	ubfiz	x9, x0, #3, #58
	mov	x11, #-1                        // =0xffffffffffffffff
	ldr	x8, [x8, :got_lo12:g_bitmap]
	ldr	x10, [x8]
	add	x10, x10, x9
	add	x10, x10, #16
	//APP
	prfm	pstl1strm, [x10]
.Ltmp0:
	ldaxr	x12, [x10]
	orr	x13, x12, x11
	stlxr	w14, x13, [x10]
	cbnz	w14, .Ltmp0

	//NO_APP
	ldr	x10, [x8]
	add	x10, x10, x9
	add	x10, x10, #16
	//APP
	ldar	x11, [x10]
	//NO_APP
	ldr	x10, [x8]
	mov	x11, #-2                        // =0xfffffffffffffffe
	add	x10, x10, x9
	add	x10, x10, #16
	//APP
	prfm	pstl1strm, [x10]
.Ltmp1:
	ldaxr	x12, [x10]
	and	x13, x12, x11
	stlxr	w14, x13, [x10]
	cbnz	w14, .Ltmp1

	//NO_APP
	ldr	x10, [x8]
	add	x10, x10, x9
	add	x10, x10, #16
	//APP
	ldar	x11, [x10]
	//NO_APP
	ldr	x10, [x8]
	mov	w11, #1                         // =0x1
	add	x10, x10, x9
	add	x10, x10, #16
	//APP
	prfm	pstl1strm, [x10]
.Ltmp2:
	ldaxr	x12, [x10]
	orr	x13, x12, x11
	stlxr	w14, x13, [x10]
	cbnz	w14, .Ltmp2

	//NO_APP
	ldr	x8, [x8]
	add	x8, x8, x9
	add	x8, x8, #16
	//APP
	ldar	x9, [x8]
	//NO_APP
	ret
.Lfunc_end1:
	.size	writer, .Lfunc_end1-writer
	.cfi_endproc
                                        // -- End function
	.globl	run                             // -- Begin function run
	.p2align	2
	.type	run,@function
run:                                    // @run
	.cfi_startproc
// %bb.0:
	str	x30, [sp, #-16]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -16
	cmp	x0, #11
	b.eq	.LBB2_2
// %bb.1:
	bl	writer
	b	.LBB2_3
.LBB2_2:
	bl	reader
.LBB2_3:
	mov	x0, xzr
	ldr	x30, [sp], #16                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	ret
.Lfunc_end2:
	.size	run, .Lfunc_end2-run
	.cfi_endproc
                                        // -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          // -- Begin function main
.LCPI3_0:
	.xword	11                              // 0xb
	.xword	704                             // 0x2c0
	.text
	.globl	main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	str	x30, [sp, #96]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -48
	mov	w0, #104                        // =0x68
	bl	malloc
	adrp	x9, .LCPI3_0
	adrp	x22, :got:g_bitmap
	mov	x8, xzr
	ldr	x22, [x22, :got_lo12:g_bitmap]
	ldr	q0, [x9, :lo12:.LCPI3_0]
	mov	x9, x0
	mov	x10, xzr
	str	x0, [x22]
	str	q0, [x9], #16
.LBB3_1:                                // =>This Inner Loop Header: Depth=1
	//APP
	stlr	x8, [x9]
	//NO_APP
	add	x10, x10, #1
	add	x9, x9, #8
	ldr	x11, [x0]
	cmp	x10, x11
	b.lo	.LBB3_1
// %bb.2:
	adrp	x20, :got:run
	mov	x19, xzr
	mov	x21, sp
	ldr	x20, [x20, :got_lo12:run]
.LBB3_3:                                // =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, xzr
	mov	x2, x20
	mov	x3, x19
	bl	pthread_create
	add	x19, x19, #1
	add	x21, x21, #8
	cmp	x19, #12
	b.ne	.LBB3_3
// %bb.4:
	mov	x19, xzr
	mov	x20, sp
.LBB3_5:                                // =>This Inner Loop Header: Depth=1
	ldr	x0, [x20, x19]
	mov	x1, xzr
	bl	pthread_join
	add	x19, x19, #8
	cmp	x19, #96
	b.ne	.LBB3_5
// %bb.6:
	ldr	x0, [x22]
	bl	free
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	mov	w0, wzr
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldr	x30, [sp, #96]                  // 8-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc
                                        // -- End function
	.type	g_bitmap,@object                // @g_bitmap
	.bss
	.globl	g_bitmap
	.p2align	3, 0x0
g_bitmap:
	.xword	0
	.size	g_bitmap, 8

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"%zu bits were raised, expected %zu\n"
	.size	.L.str, 36

	.ident	"clang version 20.1.2 (https://github.com/ziglang/zig-bootstrap 7ef74e656cf8ddbd6bf891a8475892aa1afa6891)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym run
