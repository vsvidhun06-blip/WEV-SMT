# Compiler differential: libvsync composed-cancellation ASSERT sites (prespecified 2026-11-11T01:37:18Z, before any run)

Inputs: authentic, unmodified upstream libvsync v4.3.0 files `examples/eg_bitmap.c`,
`examples/eg_unbounded_queue_lf_recycle.c` and `examples/eg_vebr.c` (source tree `C:\rc1111\src\libvsync`, provenance in
`provenance/corpora.tsv`). Compiler: zig 0.15.2 = clang 20.1.2 (`python -m ziglang cc`); `-fno-sanitize=all` always.
No GCC is installed. A GCC aarch64 cross toolchain is attempted separately; see COMPILER-RESULTS.md.

Grid: target {aarch64-linux-gnu, x86_64-linux-gnu} × atomics {BUILTINS (-DVATOMIC_BUILTINS, as screened),
DEFAULT (upstream default: custom arm64 asm on aarch64)} × asserts {on, -DNDEBUG} × opt {O0, O1, O2, O3, Os}.
Each cell emits LLVM IR (-S -emit-llvm) and assembly (-S).

Measurement (automatic, `check.py`): for each site, is a call to `__assert_fail` whose file argument ends in the
site's header and whose line argument equals the site's line still present in the optimized IR?
- Target sites (Stage-A FAKE-COMPOSED K): bitmap.h:164, bitmap.h:303, ebr.h:248, atomicptr_stamped.h:86, :87.
- Control sites (non-tautological asserts in the same functions): bitmap.h:159, 161, 298, 300; atomicptr_stamped.h:… as
  found; ebr.h:… as found. These must remain at every level (if the compiler cannot prove them).

Predictions, written before running:
- P1: at O0 every site is present (no optimization).
- P2: BUILTINS at O1, O2, O3 and Os: bitmap.h:164 and :303 are absent, because `((old|m)&m)==m` and
  `((old&~m)&m)==0` fold. ebr.h:248 is absent (`(e%3)<=3` folds). atomicptr_stamped.h:86/87 are absent where the
  getter is inlined into the cmpxchg caller.
- P3: control sites are present at every level.
- P4: DEFAULT on aarch64: the bitmap sites depend on whether the asm returns the new value or the old value (with the
  OR done in C). That is undetermined before running, so it is reported as observed.
- P5: with -DNDEBUG no site is present at any level (ASSERT expands to nothing).
