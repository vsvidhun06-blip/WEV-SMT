# Scientific verdict: real-world significance investigation (FSEN 2027 #41)

Paper: "Read-Restricted Dependency Summaries Do Not Compose Exactly" (V. Vijayakumar Suja).

The baseline manuscript (`recovery-20261109T232448/paper/wev-smt-fsen27.tex`, sha256 prefix `b555e516`) was
read, never edited. All results of this pass are in `realcode-20261110T235600/`. Key numbers are re-derived from
the raw files by `tools/verify_deliverables_v3.py`: 43 of 43 claims PASS, including a check that the deliverable
text states the verified values (`outputs/verify-deliverables-v3-20261111T123819Z/report.txt`; history in
`CHECKPOINT.md`, R11). The first version found an arithmetic slip in the census total (stated 124,956; actual
124,756), which is corrected here.

## Outcome category

**C (edge-only real-world evidence) + B (modest stronger theory). For the outcome-level question the result is D
(negative).** It is not A.

- **Not A.** No authentic program in the screened corpora has a composed cancellation that changes a weak-memory
  verdict. The 8 distinct source corpora contain 52 unique composed cancellations (FAKE-COMPOSED), all in 5 of
  them: libvsync 45, ck 4, liburcu 1, radix-tree harness 1, vma harness 1. 0 pass Stage D
  (`CANDIDATE-INVENTORY.csv`).
- **C.** Composed cancellations do occur in authentic, unmodified concurrent code. Clang 20.1.2 was run on the 6
  Stage-C-passing sites in libvsync and liburcu. At -O1, -O2, -O3 and -Os, on aarch64 and x86-64, it removes every
  cancelled instance at all 6. At `atomicptr_stamped.h:87`, an instance of the same source line on a different
  pointer (one the screen does not class as fake) survives. The replays are fidelity-checked. Mode-B summaries
  therefore over-approximate what reaches compiled code in real programs.
- **B.** A mechanised taint-linear exactness theorem (`tl_exact`, 31 facts, no oracles) strictly generalises the
  paper's SRI exactness result. Three necessity theorems match the three cancellation mechanisms. It passes a
  prespecified consistency test on 124,756 joined real pairs (86,856 without the duplicate builds; 0 violations).
- **D.** In the paper's own fragment (data dependencies into marked stores) there are **0 composed cancellations
  among 501 real-code sites** (SLI view; 497 REAL, 3 FAKE-LOCAL, 1 undecided). All 52 composed cancellations are
  control (50) or address (2) dependencies. All are range restrictions or path infeasibility; **none is a
  correlation** (0 of 282 pairs). The 7 that reach Stage D are verdict-irrelevant for structural reasons: a seq_cst
  source (5), a REAL dependency of the same load dominating (1), or a stale test-harness duplicate (1).

## The eight questions

**1. Is there a genuine real-world outcome-level witness?** No.
- Screened (v9, both views): ck 0.7.2, libvsync v4.3.0, liburcu v0.15.7 (two configurations), mimalloc v3.6.1,
  the GenMC v0.20.0 tests, the Dat3M 4.4.1 benchmarks, and two Linux 7.3 user-space harnesses (radix-tree in two
  configurations, vma). That is 7,406 SLI and 2,530 SL sites over the 8 distinct sources.
- A source-level screen of all of Linux 7.3 found 573 load→marked-store pairs, all REAL.
- Not screened (memory or setup): nidhugg tests (built), DPDK, the LLVM/GCC test suites, the vma K2 configuration,
  and the bpf ringbuf (libelf missing).

The answer covers the screened corpora only. It is not a prevalence estimate.

**2. Is it unknown or non-obvious?** The phenomenon is known.
- The kernel's RCU documentation warns that `x-(uintptr_t)x` lets the compiler break an rcu_dereference
  dependency (`Documentation/RCU/rcu_dereference.rst:68-72`).
- LKMM's explanation.txt discusses "purely syntactic" dependencies (`r1*0`).
- GenMC's test suite contains a fake-dependency litmus test (`1 + (r0 ^ r0)`).

New and non-obvious:
- the measured shape: real composed cancellations are defensive range checks and post-condition asserts in
  helpers, not correlations, and none is a data dependency into a marked store;
- two specific harmless instances not documented elsewhere to our knowledge: the liburcu shrink-path
  `if (!x)` after `max(x, 1)`, and the Linux vma test-harness duplicate whose `bool`-vs-flags mismatch makes a
  limit check dead.

**3. Is the practical-significance objection materially answered?** No. It is sharpened, not answered. Edge
level: the paper's inexactness is real in compiled real code. Outcome level: the evidence now supports the
skeptic, with a denominator (0/501 data sites; 0/52 verdict-relevant) instead of the manuscript's current "absence
of test cases".

**4. Is it independently supported?**
- Edge evidence: yes.
  - A production compiler (clang 20.1.2, with fidelity-checked replays of the exact build flags) removes the
    cancelled dependencies and keeps the REAL dominating branches.
  - The memory caveat for the three memory-opaque sites was cleared mechanically (constant with every opaque
    node unshared).
  - Two independently implemented classifiers agree on every pair: the self-composition screen and the forward
    taint census.
- Not supported independently:
  - No herd7 or Dat3M run. Dat3M was not built with 0.26 GB free RAM, and herd7 is absent.
  - No GCC.
  - No assembly-level check of the real sites.
  - The verdict-irrelevance arguments (seq_cst source, dominated control) are proof sketches.
- No candidate reached Stage E, so the missing model checker does not affect the negative answer. It would matter
  only for a positive claim.

**5. Is there a stronger scientific contribution?** Yes, modestly (B).
- T1 (`theory/tl/PwT_TaintLinear.thy`): exactness of the closure for every target that never becomes TU. It covers
  any number of untainted side inputs and a final uniformly non-constant step. It re-derives the paper's
  `vdep_exact_sri` as a corollary, and has necessity theorems for correlation, range restriction and side-input
  annihilation.
- The census tests T1's prediction on real code (PASS). It also shows that T1's reach is limited by control flow,
  not by cancellations: 85.7% of pooled SLI pairs leave the fragment for structural reasons, and 97.7% of those
  leave through a loop or a control merge.
- O1 in `THEOREM-OPPORTUNITIES.md` is not mechanised. It would turn the negative empirical result into a formal
  scoping theorem: composition matters only for a relaxed source with an undominated data dependency.

**6. Would a skeptical reviewer be justified in retaining Weak Reject?** Yes.
- The reviewer's central concern, significance on real programs, is now backed by evidence against outcome-level
  significance in the paper's own fragment.
- T1 is a sound but incremental generalisation.
- What this pass can change is credibility. A manuscript that reports the measured, mostly negative real-code
  result and the stronger theorem is more defensible. A reviewer could reasonably move a point for honesty and
  rigour, but nothing here obliges them to.

**7. What exact result should enter the manuscript?** Proposed text, **not applied**. The paper had no page slack
in earlier passes, so each addition needs an equal cut.

(a) In "Implementation and evaluation" (around lines 701–704), replace the text from "The populations are
constructed, and the real corpus contains no chain-form cancellation" through "not evidence of rarity." with:
```latex
The populations are constructed. Under a protocol fixed before the search (amendments recorded in the
artifact), a screen of eight upstream concurrent code bases (Concurrency Kit, libvsync, liburcu,
mimalloc, the GenMC and Dat3M test suites, and two Linux~7.3 user-space test harnesses; 7,406
load-to-sink sites after inlining) finds 52 composed cancellations that the Boolean closure keeps, all
in control (50) or address (2) dependencies and none among the 501 data dependencies into a marked
store. At \texttt{-O1} to \texttt{-O3} and \texttt{-Os}, clang~20.1.2 removes every cancelled instance
at the six such sites it was run on. None of the 52 changes a verdict: 45 involve only thread-local
accesses or a dead path; in the other seven the source access is \texttt{seq\_cst}, a real dependency
on the same load dominates, or the code is a single-threaded test-harness copy. The practical
relevance of composition loss for verdicts is therefore not demonstrated.
```
The text is about 5 lines longer than what it replaces. The earlier two-source search
(§\ref{sec:prototype}) remains described in its own section.
(b) Optional, theory. After the SRI exactness statement, add a proposition: "If no step reads two tainted
registers and no non-injective step feeds another, the closure is exact (Isabelle `tl_exact`); each condition is
necessary (`tl_needs_linear`, `tl_needs_full`, `tl_needs_uniform`)", with one sentence on the census check
(0 violations on 86,856 distinct real pairs).

(c) Optional, precision. The "-O1 to -O3" statements (lines 68, 595, 924, 1131–1144) hold at genuine levels, and
the IR is identical across levels for these programs (`COMPILER-RESULTS.md` §1). No change is required. If the
artifact documents the zig toolchain, it should say that `zig cc` maps -O1..-O3 to `-DNDEBUG -O2`.

**8. What is the single best next action?** An author decision on the framing. Adopt the measured-scope framing:
apply text (a), with (b) if space allows, and remove any wording that implies verdict-level practical relevance.
This answers the reviewer's question with evidence instead of more searching. If the author prefers to keep
searching, the most informative remaining experiment is the v9 screen of the unscreened corpora (nidhugg, DPDK,
LLVM/GCC tests) on a machine with at least 8 GB of free RAM. Given 0/501 data-sink cancellations, the expected
yield of an outcome-level witness is low.

## Caveats on denominators

- Site counts are per corpus with shared headers counted once per corpus.
- The two duplicate builds (liburcu-vol, radix-K2) are excluded from pooled numbers.
- The sample is purposive (libraries, verifier tests, kernel test harnesses), so no prevalence claim is made.
- LARGE/UNKNOWN sites are undecided, not REAL: 239 SLI sites across the 8 corpora, 218 of them in the radix-tree
  harness (libvsync 18, liburcu 3).
