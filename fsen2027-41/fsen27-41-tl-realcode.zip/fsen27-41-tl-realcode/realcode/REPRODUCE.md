# Reproducing the real-world significance investigation

The commands below are the ones that produced the results in this directory. They were recovered from the run
scripts, the tool headers, the log files and the session transcript; none is reconstructed from memory. All
outputs go into fresh, timestamped directories, and every tool refuses to overwrite an existing output.

```sh
R='C:/Users/Vidhu/wev-fsen27-41/realcode-20261110T235600'   # research directory (deliverables, tools, results)
PY='C:/rc1111/venv/Scripts/python.exe'                        # always run with -I
B='C:/rc1111/build'; S='C:/rc1111/src'                         # bitcode, screens, census runs; upstream sources
```

## 0. Environment

| item | value | record |
|---|---|---|
| OS / shells | Windows 11 Home 10.0.26200; Git Bash for the `.sh` scripts | — |
| Python | 3.11.9 venv `C:\rc1111\venv` | `ENV-VERSIONS-20261111.txt` |
| LLVM (in process) | llvmlite 0.50.0 = LLVM 22.1.0 | same |
| C compiler | ziglang 0.15.2 = bundled clang 20.1.2 (`python -m ziglang clang`) | same |
| SMT | z3-solver 5.0.0.0 | same |
| Isabelle | Isabelle2024 at `C:\Users\Vidhu\AppData\Local\Isabelle\Isabelle2024` (not on PATH) | `theory/logs/` |
| tool hashes | sha256 of every tool | `TOOLS-USED-20261111.sha256`, `TOOLS-FINAL-20261111.sha256` |

**Memory.** Free RAM was 0.2–0.4 GB for most of the pass. Everything ran in the foreground, one job batch at a
time, with resource guards (`--mem-mb`, `--min-free-mb`, `--timeout`). MEMOUT and TIMEOUT jobs are reported in
each `summary.txt`. They are never retried silently, and they are excluded from all denominators. With 8 GB or
more free, `--jobs` can be raised.

**Not available, so not reproducible here:** herd7, Dat3M (not built), GCC as a compiler (only its test suite was
fetched), and hardware runs.

## 1. Baseline integrity (read-only)

- Manuscript `C:/Users/Vidhu/wev-fsen27-41/recovery-20261109T232448/paper/wev-smt-fsen27.tex`: sha256 prefix
  `b555e516`.
- Protocol `protocol/PROTOCOL.md`: sha256 prefix `bd907b34` (`protocol/PROTOCOL.sha256`). Amendments are in
  `protocol/AMENDMENTS.md`.

Both are checked by step 11 (claims O5, O6).

## 2. Corpora and bitcode

```sh
WORK=/c/rc1111 R="$R" bash "$R/tools/fetch_corpora.sh"     # -> logs/fetch_corpora.log, provenance/corpora.tsv
```

Bitcode is built with `tools/build_corpus.py` (`--name --out --list [--flags] [--jobs] [--timeout]`). File lists
are in `search/lists/`, and configuration headers in `inputs/config/`. The exact per-corpus flags are in
`tools/run_v9_A.sh`, `tools/run_v9_B.sh` and `tools/run_liburcu_vol.sh`. The liburcu-vol bitcode comes from the
last of these; its v6 screen there is superseded.

## 3. Stage A: v9 screen (views SL and SLI) and aggregation

```sh
bash "$R/tools/run_v9_A.sh"   # ck, libvsync, liburcu, liburcu-vol, mimalloc, dat3m, genmc; then nidhugg build + screen
bash "$R/tools/run_v9_B.sh"   # kernel harnesses radix K1/K2, vma K1/K2; bpf; dpdk; p4
# each screen: "$PY" -I "$R/tools/screen_corpus_v2.py" --tool "$R/tools/irscreen_v9.py" --corpus C --bcdir BC \
#              --out "$B/C-screen-v9-<ts>" --jobs 4 [--timeout 1200]
"$PY" -I "$R/tools/aggregate_v2.py" --out "$R/search/stageA/<label>-<ts>" --label <label> <SCREEN_DIR>
```

Not every part of these scripts completed. The screened builds are the 10 directories
`search/stageA/*-v9-*/`. Each `summary.txt` header gives the screen directory, the tool sha256 and the job exits.
nidhugg (built) and vma K2 were not screened (memory). The DPDK v9 rebuild and the p4 screens were not run. bpf
failed at setup (`libelf.h` not found). See `REAL-CODE-SEARCH.md` §1, CHECKPOINT S5/R1 and Amendment 9.

## 4. Source-level screen of Linux 7.3 (P1a) and the kernel-doc examples (P5)

```sh
K=/c/rc1111/src/linux-x; L="$R/search/lists/p1a-linux.txt"
(cd "$K" && find linux-7.3 -type f \( -name '*.c' -o -name '*.h' \) | LC_ALL=C sort) > "$L"   # only if absent
OUT="$B/p1a-linux-src-<ts>"; mkdir "$OUT"
"$PY" -I "$R/tools/srcscreen.py" --root "$K" --list "$L" --out "$OUT/rows.csv" --jobs 8 > "$R/logs/p1a-linux.log" 2>&1
```

The original ran in the background with `nohup`. Its controls are `inputs/controls/CTRL-src.c` (15/15 PASS). For
P5, the input bitcode and the tool used for the v9 rescreen are recorded in
`outputs/p5-kerneldocs-v9-20261111T013554Z/commands.txt`.

## 5. Taint-linear census (Amendments 8–9)

```sh
"$PY" -I "$R/tools/plan_tl_batches.py" <corpus> <BCDIR> <SCREEN_DIR> [--sl-only] [--budget 300]  # -> search/tl-batches/
bash "$R/tools/run_tl_batch.sh" "$R/search/tl-batches/<corpus>-bNN-<views>.txt"   # one at a time, foreground
#   = screen_corpus_v2.py --tool tlcensus_v1.py --jobs 1 --timeout 500 --mem-mb 1200 --min-free-mb 200
J="$R/search/tlcensus-join-<ts>"
"$PY" -I "$R/tools/tlcensus_join_v2.py" --census <CENSUS_DIR> [<CENSUS_DIR> ...] --screen <SCREEN_DIR> \
      --out "$J/<corpus>" --label <corpus>-tl
"$PY" -I "$R/tools/census_report_v1.py" "$J"                  # -> $J/CENSUS-REPORT.md (8 distinct corpora)
"$PY" -I "$R/tools/pool_tl_origins_v1.py" "$J" <NEW>/POOLED.txt   # all 10 builds, duplicates included
```

- Each corpus's exact census directories and screen directory are in the header of
  `search/tlcensus-join-20261111T114530Z/<corpus>/summary.txt`.
- The batch history, including the killed probes, is in `logs/run_tl_batches.log`.
- The CENSUS-REPORT addendum is hand-written prose; its numbers are checked by step 11 (C6).
- `pool_tl_origins_v1.py` is the inline command that wrote POOLED.txt, saved verbatim except for its output path.
  It regenerates POOLED.txt byte-identically (`outputs/pooled-regen-20261111T124136Z`).

## 6. Stages B–D inventory

```sh
"$PY" -I "$R/tools/build_inventory_v3.py" <NEW.csv>   # current CANDIDATE-INVENTORY.csv (sha256 prefix 01c7d7a2)
```

The B–D triage is manual. Each judgement is encoded as data inside the script, with its evidence. v1 and v2 of the
inventory are kept in `search/`.

## 7. Memory-caveat probes (PROTOCOL §3.1)

```sh
"$PY" -I "$R/tools/opaque_probe_v1.py" "$B/liburcu-bc-20261111T002731Z/bc/rculfhash_c__eac827279d.bc" \
      SLI cds_lfht_resize 2154 635 'rculfhash.c:2128'
M="$B/libvsync-bc-20261111T002529Z/bc/eg_unbounded_queue_lf_recycle_c__e5ad02353e.bc"
"$PY" -I "$R/tools/opaque_probe_v1.py" "$M" SLI run 294 86 'unbounded_queue_lf_recycle.h'
"$PY" -I "$R/tools/opaque_probe_v1.py" "$M" SLI run 294 87 'unbounded_queue_lf_recycle.h'
```

Output is in `outputs/opaque-probe-20261111T122327Z/`. A watchdog aborts any probe above 900 MB RSS.

## 8. Compiler differentials (clang 20.1.2)

```sh
# libvsync v2: the scripts write only inside their own directory, so copy them to a fresh one and run them in order
N="$R/outputs/compdiff-libvsync-v2-<ts>"; mkdir "$N"
cp "$R/outputs/compdiff-libvsync-v2-20261111T014632Z/"{PLAN.md,replay.py,check.py,xref.py} "$N/"
"$PY" -I "$N/replay.py" && "$PY" -I "$N/check.py" && "$PY" -I "$N/xref.py"
# liburcu rculfhash v2, two targets
"$PY" -I "$R/tools/compdiff_rculfhash_v2.py" aarch64-linux-gnu
"$PY" -I "$R/tools/compdiff_rculfhash_v2.py" x86_64-linux-gnu
```

## 9. Genuine-level re-runs of the manuscript's compiler claims (§6)

```sh
"$PY" -I "$R/tools/family_true_levels.py"      # 17-program family -> outputs/family-true-levels-<ts>
D='C:/Users/Vidhu/wev-fsen27-41/recovery-20261109T232448/recovery/compiler'
"$PY" -I "$R/tools/srcdir_true_levels.py" "$D/src" "$D/out" recovery-compiler-true-levels
```

## 10. Isabelle: the taint-linear theory

```sh
"/c/Users/Vidhu/AppData/Local/Isabelle/Isabelle2024/contrib/cygwin/bin/bash.exe" --login -c \
  'cd "$(cygpath -u "C:/Users/Vidhu/wev-fsen27-41/realcode-20261110T235600/theory")" && \
   /cygdrive/c/Users/Vidhu/AppData/Local/Isabelle/Isabelle2024/bin/isabelle build -c -v -o timeout=600 \
   -d base-isabelle-copy -d addon-formal-copy -d tl WEV_SMT_TL'
```

Expected: BUILD_EXIT=0. `TL_Check` reports "oracles over 31 theorems: none" (`theory/tl/CHECK-RESULT.txt`). The
build uses copies of the base and add-on theories (`COPIES.sha256`); the originals are not touched.

## 11. Verification of every key number and of the deliverable text

```sh
O="$R/outputs/verify-deliverables-v3-<ts>"; mkdir "$O"
"$PY" -I "$R/tools/verify_deliverables_v3.py" > "$O/report.txt"; echo "exit $?"   # expected: 43/43 PASS, exit 0
```

The verifier re-derives each number from the raw files (claim groups A: Stage A and coverage; B: funnel;
C: census; K: compiler; O: other; T: text consistency). It reads nothing it computed itself. Earlier runs are kept:
v1 found an arithmetic slip in the census total; v2 had a verifier parsing defect (CHECKPOINT R11).

## Gotchas that change results

1. **`zig cc` -O mapping.** `zig cc -O1`, `-O2` and `-O3` all run clang with `-DNDEBUG -O2`.
   - To compile at a real level, capture zig's clang argv with `ZIG_VERBOSE_CC=1`, adding a unique `-D` define,
     because a cache hit prints nothing.
   - Replay that argv with `python -m ziglang clang`, varying only `-O<n>` (and `-DNDEBUG` where intended).
   - The fidelity check must compare like with like: a replayed `-DNDEBUG -O2` against `zig cc -O2`.
2. **Sanitizers.**
   - The new differentials (libvsync v2, rculfhash v2) pass `-fno-sanitize=all`.
   - The genuine-level re-runs (step 9) deliberately replay the recovery sweep's own flags, for fidelity, and do not
     pass it.
   - Checked on every IR file of all five output directories: 500 `.ll` files, 0 containing `ubsan`. No cell
     contains sanitizer instrumentation.
   - When adding compiles, pass `-fno-sanitize=all`, or check the IR the same way.
3. **Git Bash heredocs mangle backslashes**, even quoted ones. Build backslashes in Python with `chr(92)`, or write
   the script to a file first.
4. **-O0 memory orders.** At -O0, a non-constant memory-order argument (e.g. liburcu's `cmm_to_c11(mo)`) is
   lowered to monotonic, acquire and seq_cst variants of the same load. The program's actual order must be read
   from the source.
5. **Duplicate builds.** liburcu-vol and p1b-radix-K2 re-screen the same sources. They are excluded from every
   pooled number in the deliverables. `POOLED.txt` includes them; `CENSUS-REPORT.md` does not.
