# Compiler results (FSEN 2027 #41, real-code pass)

All compiles use clang 20.1.2 as bundled with zig 0.15.2 (`python -m ziglang`, venv `C:\rc1111\venv`). Versions are in
`ENV-VERSIONS-20261111.txt` and tool hashes in `TOOLS-USED-20261111.sha256`. GCC is not available on this machine:
no gcc on PATH and no WSL distribution (CHECKPOINT S0). Every compile passes `-fno-sanitize=all`.

## 0. Two facts about the toolchain that change how earlier results read

**(a) zig cc does not run the requested optimisation level.** `zig cc` maps `-O1`, `-O2` and `-O3` all to clang
`-DNDEBUG -O2`, and `-Os` to `-DNDEBUG -Os`. At `-O0` it adds `-fsanitize=undefined`, which we override. This was
found when the first libvsync grid came out confounded (`outputs/compdiff-libvsync-20261111T013718Z/CONFOUNDED-READ-FIRST.md`).

The fix used everywhere afterwards:
1. Capture zig's own clang argv with `ZIG_VERBOSE_CC=1`. A unique `-D` define is needed when zig would serve the
   compile from its cache and print nothing.
2. Replay it with the raw driver (`python -m ziglang clang`), dropping `-O2`, `-DNDEBUG` and the output flags, and
   adding the requested `-O<n>`.
3. Fidelity check: a replay of `-DNDEBUG -O2` (or `-O2`, for NDEBUG-free sources) must be byte-identical to
   `zig cc -O2` output, modulo module ids.

**(b) The earlier "LLVM actual" harness was not `opt`.** The recovery pass's `llvm_actual.py` ran InstCombine
in-process through llvmlite 0.50.0, which is **LLVM 22.1.0**. The constructed family was compiled by clang 20.1.2,
a **different LLVM version**. So "InstCombine of LLVM 22.1" and "clang 20.1.2 -O1..-O3" are two different
compilers. The manuscript names both versions correctly (lines 503, 511, 595, 1114).

## 1. The recovery pass's compiler claims at genuine optimisation levels (mandate §6)

The recovery pass's `recovery/compiler/sweep.py` (sha `90831df3…`) used `zig cc` at -O0..-O3. Its -O1, -O2 and -O3
IR is byte-identical for all 136 comparisons over the family outputs, so its three level columns were one compile.

| re-run (fresh dirs) | sources | fidelity vs recovery -O2 | genuine -O1 == -O2 == -O3 IR | verdicts |
|---|---|---|---|---|
| `outputs/family-true-levels-20261111T115507Z` (tools/family_true_levels.py) | 17 family programs × 4 targets | 68/68 IDENTICAL | 68/68 | unchanged: 13 cancelling patterns store a value independent of the load; sq-minus and the 3 controls keep the dependency |
| `outputs/recovery-compiler-true-levels-20261111T121424Z` (tools/srcdir_true_levels.py) | lb_mem_cancel, lb_mem_cancel_plain, tdouble_lb, tplus_lb, upstream_ids × 4 targets | 20/20 IDENTICAL | 20/20 | LB-mem-cancel: both relaxed loads kept at every level and target; with z non-atomic, the constant 1 is stored at -O1/-O2/-O3 on all 4 targets |

The IR decision functions are copied verbatim from sweep.py. The level flag is effective: -O0 gives allocas and
`optnone`, -O1 does not. The first family attempt (`…115312Z`) omitted sweep.py's
`-g0 -fno-asynchronous-unwind-tables` and reached 0/68 fidelity; it is kept with NOT-USED.txt.

**Consequence for the manuscript.** Every "-O1 to -O3" statement (lines 68, 595, 924–925, 1129–1144) is reproduced
at genuine levels. The wording can stay. If precision is wanted, add "(genuine -O1, -O2 and -O3 produce identical IR
for these programs)" and drop the implication that three independent compiles agreed.

## 2. Real code: libvsync (authentic, unmodified, v4.3.0)

`outputs/compdiff-libvsync-v2-20261111T014632Z` (PLAN.md written before the runs; RESULTS.md):
- 252 compiles, all exit 0. Grid: x86_64 and aarch64 × BUILTINS and DEFAULT atomics × O0/O1/O2/O3/Os, each with and
  without NDEBUG.
- Fidelity 12/12 IDENTICAL.

Target sites (the 5 FAKE-COMPOSED library sites; all control sinks into assert branches):

| site | source | O0 | O1 / O2 / O3 / Os, all 4 columns |
|---|---|---|---|
| bitmap.h:164 | `val = or_get(&maps[idx], mask); ASSERT((val & mask) == mask)` | present | **removed** (siblings :158/:159/:161 survive) |
| bitmap.h:303 | `val = and_get(&maps[idx], ~mask); ASSERT((val & mask) == 0)` | present | **removed** (siblings :297/:298/:300 survive) |
| ebr.h:248 | `idx = epoch % 3; ASSERT(idx <= 3)` | present | **removed** |
| atomicptr_stamped.h:86 | `ASSERT(IS_ALIGNED(e_v))`, e_v = GET_ADDRESS(·) = x & -128 | present | **removed** |
| atomicptr_stamped.h:87 | `ASSERT(IS_ALIGNED(v))` | present | removed in every GET_ADDRESS (FAKE-COMPOSED) context; one instance on a pool/qnode pointer survives |

Controls: 35 control sites vanish at -O1 and above.
- 33 have no marked-load pair, so they are not dependency sites. They are non-null and arithmetic facts,
  store-to-load forwarding, and a dominating equivalent check.
- 2 are dependency sites that the screen classes REAL (smr_nodes_list.h:78/110, `ASSERT(lst)` with
  `lst = &retired_lst[epoch % 3]`). LLVM folds them because an inbounds GEP from a global is non-null, while the BV
  model lets `base + 24*idx` wrap.

So the screen under-approximates what clang cancels. Under NDEBUG, 0/60 cells contain `__assert_fail`.

## 3. Real code: liburcu rculfhash.c (authentic, unmodified, v0.15.7)

Runs:
- v2, both targets: `outputs/compdiff-rculfhash-v2-aarch64-20261111T121754Z` and `…-x86_64-20261111T121757Z`
  (tools/compdiff_rculfhash_v2.py).
- v1, x86_64 only, kept: `outputs/compdiff-rculfhash-20261111T114915Z`.
- The first v2 runs, `…121722Z` and `…121727Z`, are NOT USED. Their regex skipped `distinct` DILocations, and their
  fidelity check was ill-posed.

Replay fidelity (`-DNDEBUG -O2` vs `zig cc -O2`) is IDENTICAL on both targets. Results are the same on both targets:

| level | helper `cds_lfht_get_count_order_ulong` | fake branch (`if (!x)`, line 635, inlined at :2128) | REAL-classed sibling (line 635 at :2112) | dominating REAL branches :2155 / :2157 |
|---|---|---|---|---|
| O0 | 11 calls (not inlined) | present (inside the called helper) | present (call) | present |
| O1, O2, O3, Os | inlined (0 calls) | **absent** | **absent** | present |

The :2112 sibling is classed REAL by the site-local screen. clang removes it by a path-sensitive fold: the dominating
`old_size < new_size` implies `new_size != 0`.

## 4. What the compiler evidence shows, and what it does not

**Shows (category C, edge level).** A production compiler removes, at -O1, -O2, -O3 and -Os on both
targets (-Oz was not run), exactly the composed cancellations that Stage A found in authentic, unmodified concurrent code. These are 6
of the 7 Stage-C-passing sites; the seventh is a kernel harness artefact and was not compiled. The six come from
two independently developed libraries: five libvsync assert post-conditions and one liburcu range helper. After
optimisation, these load→branch dependencies no longer exist in the compiled code, although the per-instruction
closure (mode B) keeps them. This is direct, independent (non-WEV-SMT) evidence that mode-B summaries
over-approximate what reaches compiled code in real programs.

**Does not show a verdict change.**
- libvsync: every source access is seq_cst, so later accesses are ordered without any dependency.
- liburcu: the fake branch is dominated by REAL branches on the same value, and those survive compilation. No
  ordering is lost.
- All 52 FAKE-COMPOSED sites are control or address sinks. None is in the paper's data-dependency fragment.

**Limitations.**
- One compiler family (clang 20.1.2).
- No GCC.
- No assembly-level analysis for the real-code sites. The family's AArch64 asm checks are from the recovery pass.
- The libvsync assert sinks vanish entirely under NDEBUG, so in release builds the dependency does not exist at the
  source level either.
