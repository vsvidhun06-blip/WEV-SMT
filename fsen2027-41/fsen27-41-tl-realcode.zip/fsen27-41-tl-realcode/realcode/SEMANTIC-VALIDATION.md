# Semantic validation (12 items per witness)

**Status.** No candidate reached Stage D, so this file validates no outcome-level witness. It validates the 7
real-code sites that pass Stages A–C (primary reading), grouped as W1–W5. It shows, item by item, why each is an
edge-level cancellation with no verdict consequence.

**Notation.**
- L: the marked load (or RMW old value).
- S: the sink.
- Mode B: the closure of exact per-instruction summaries, which keeps L→S.
- Mode C: composition, which removes L→S.

Unless stated, the source is the unmodified upstream file at the commit in `provenance/corpora.tsv`. Nothing here is
an author-written wrapper presented as upstream.

## §5 baseline: what the constructed family needs, and what real code has

The 14 cancelling programs of the recovery family (constructed, NOT real code) give a verdict difference under
`acyclic(sdep ∪ rf)`, and on Arm for the 13 that clang compiles to a constant store. Each such program meets all of
these conditions:

| # | necessary condition (from the family) | why it is necessary |
|---|---|---|
| N1 | the source L is relaxed (no acquire/seq_cst, no fence after it) | otherwise po-later accesses are ordered without any dependency |
| N2 | the sink is a data dependency into a marked store (D) | the paper's fragment and the LB ordering the family uses |
| N3 | the cancellation spans ≥ 2 instructions and the closure keeps it (FAKE-COMPOSED) | single-instruction cancellations are already removed by the closure |
| N4 | no REAL dependency of the same L orders the same later write | a dominating REAL dependency already orders it |
| N5 | an rf cycle can close through the sink (LB shape across threads) | otherwise no consistency check depends on the edge |

The 52 real FAKE-COMPOSED sites against these conditions:

| condition | sites meeting it | sites failing it |
|---|---|---|
| N2 data sink | **0** | 52 (50 control, 2 address) |
| N1 relaxed source | 13: rculfhash (relaxed), radix and vma (volatile), and 10 unit-test sites (`monotonic` loads in the `_rel`/`_rlx` max_get variants, on stack objects) | 19 seq_cst or acquire. A further 20 unit-test sites take a `cmpxchg` old value whose order is that of the max_get variant; all 40 unit-test sites already fail Stage B |
| N3 | 52 by construction | — |
| N4 | radix (vacuous), vma | rculfhash (dominated) |
| N5 | none found | all: no second thread writes what S controls and feeds back into L in the same pattern; single-threaded unit tests (40), harness (1) |

No real site meets N1 ∧ N2, the minimum for the family's mechanism. The family therefore remains a constructed
diagnostic baseline. It is never evidence about real code, and it is not counted (PROTOCOL §5).

---

## W1 — liburcu `rculfhash.c`: shrink-path `if (!x)` (K05) — the strongest edge witness

1. **Source.** liburcu v0.15.7, commit `bbc6bc94901aebe6380e4e798858b995a8d3fd5d`, `src/rculfhash.c` (unmodified).
   Same site in the volatile-dereference build.
2. **Fragment + context.** `_do_cds_lfht_resize` (called with `resize_mutex` held, from the resize worker
   `do_resize_cb` and from `cds_lfht_resize`):
   ```c
   old_size = ht->size;
   new_size = uatomic_load(&ht->resize_target);              /* L, :2154 */
   if (old_size < new_size) _do_cds_lfht_grow(...);          /* REAL branch b1, :2155 */
   else if (old_size > new_size)                              /* REAL branch b2, :2157 */
       _do_cds_lfht_shrink(ht, old_size, new_size);           /* :2158 */
   /* inlined: new_size = max(new_size, MIN_TABLE_SIZE);  (MIN_TABLE_SIZE = 1UL << 0)   :2126
               new_order = cds_lfht_get_count_order_ulong(new_size);                     :2128
                  -> if (!x) return -1;   (S, :635)                                            */
   ```
3. **Operations and orders.** L is `uatomic_load(&ht->resize_target)`, which is
   `uatomic_load_mo(addr, CMM_RELAXED)` (`include/urcu/uatomic/api.h:29-30`), and
   `CMM_RELAXED == __ATOMIC_RELAXED` (static asserts in `uatomic.h`). So the access is relaxed. The -O0 bitcode the
   screen reads contains monotonic, acquire and seq_cst variants of this load, because the order argument comes from
   the unfolded `static inline cmm_to_c11()`. At -O1 and above only the relaxed load remains. The concurrent
   writers of `resize_target` are:
   - `_uatomic_xchg_monotonic_increase` (:2169);
   - `uatomic_store` in `resize_target_update_count` (:2178);
   - `uatomic_cmpxchg` (:2269);
   - initialisation (:1701).

   The loop orders `resize_initiated` against the reload of `resize_target` with `cmm_smp_mb()` (:2161), a full
   barrier, not a dependency.
4. **Syntactic dependency.** L → (`?:` of `max`, a gated phi) → `icmp eq x, 0` → `br` (S). The screen records a
   def-use path of 3 instructions in the SLI view.
5. **Site-local closure (mode B).** Each step is individually non-constant in its tainted input. `max(v, 1)` varies
   with v, and `v' == 0` varies with v'. So the closure keeps L→S. This is the screen's FAKE-COMPOSED.
6. **Composed semantic dependency (mode C).** None. For every v, `max(v, 1) ≥ 1`, so `!max(v, 1)` is false. The
   writers clamp too: every store is `max(count, MIN_TABLE_SIZE)`. The mechanism is range restriction, the `maskP`
   class of the theory (TN then a further test).

   *Memory caveat (PROTOCOL §3.1).* The screen flags this slice memory-opaque. Its opaque nodes are the field address
   and the two sibling -O0 variants of the same load (see item 3). The caveat is cleared mechanically: with every
   opaque application unshared between the two copies, the sink is still constant (Z3 UNSAT;
   `tools/opaque_probe_v1.py`, `outputs/opaque-probe-20261111T122327Z/rculfhash-cds_lfht_resize.txt`).
7. **rf / justification.** L may read any of the writes in item 3. The value is ≥ 1 in every case, so the fake
   branch is constant whichever write is read.
8. **Candidate execution graph.** For the edge to matter there must be a cycle L →dep→ W_R →rf→ R_U →(ordered)→
   W_U(resize_target) →rf→ L, where W_R is a write of the resize path after the fake branch. Every event po-after
   the fake branch is also po-after b2 (:2157), and b2 depends REALly on L. So L →ctrl→ W_R holds in **both** modes.
9. **Verdict per model.** The same in mode B and mode C for every candidate execution:
   - Arm / LKMM-style ctrl (`[R];dep;[branch];po`): the ordered pairs from L are unchanged.
   - RC11: dependencies are irrelevant.
   - The paper's `acyclic(sdep ∪ rf)`: control sinks are outside the data fragment; if sdep included control, the
     domination argument applies.
10. **Independent reference.** clang 20.1.2 at -O1/-O2/-O3/-Os on both aarch64 and x86_64 (replay fidelity
    IDENTICAL) removes the fake branch and keeps b1 and b2
    (`outputs/compdiff-rculfhash-v2-{aarch64-20261111T121754Z,x86_64-20261111T121757Z}`). This is LLVM's own
    analysis, independent of WEV-SMT. No herd7/Dat3M run: Dat3M was not built (memory), and the verdict identity
    follows from the domination argument without one.
11. **Why it matters.** It is the clearest authentic example of a composed (multi-instruction, across an inlined
    helper) cancellation that a per-instruction closure keeps and a production compiler removes, with a relaxed
    source. It shows mode-B over-approximation in real compiled code. It also shows why such cancellations tend to
    be harmless: defensive range checks in helpers are dominated by the caller's own REAL tests.
12. **Assumptions / limitations.**
    - Domination is argued from the source and the IR, not checked at the asm level.
    - The verdict argument is a proof sketch, not mechanised.
    - The concurrency context (worker vs updaters) is from source reading; no harness was executed.

## W2 — libvsync `bitmap.h:164` / `:303` (K08, K09) — the family's `or-and` shape in real code

1. **Source.** libvsync v4.3.0, commit `b8f1dd529029409ab4f17ab62de3610fba5c5f74`, `include/vsync/bitmap/bitmap.h`
   (unmodified).
2. **Fragment.**
   - `vbitmap_set_bit`: `val = vatomic64_or_get(&bitmap->maps[idx], mask); ASSERT((val & mask) == mask);` (:163–164).
   - `vbitmap_clr_bit`: `val = vatomic64_and_get(&maps[idx], ~mask); ASSERT((val & mask) == 0UL);` (:302–303).
   - Context: shared bitmap words; multi-threaded test `test/bitmap/test_mt_bitmap.c` (`launch_threads(N, run)`).
3. **Operations.** `vatomic64_or_get` / `and_get` are seq_cst RMWs (IR `atomicrmw or|and … seq_cst`). In C,
   `or_get = get_or(a, v) | v` (vatomic fallback.h:1361), so the cancellation is visible above the atomics backend.
4. **Syntactic dependency.** The RMW old value → `or` (or `and ~mask`) → `and mask` → `icmp` → `br` (assert).
5. **Closure.** Each of `|`, `&`, `==` is non-constant in its input, so mode B keeps the edge.
6. **Composed.** `((old | m) & m) == m` and `((old & ~m) & m) == 0` are constant true. The mechanism is range
   restriction (the family's `or-and`: `t = r|1; s = t&1`).
7. **rf.** The RMW reads any write to `maps[idx]`. The assert result is the same whichever it reads.
8. **Graph.** Any cycle through the RMW is already ordered by the seq_cst RMW (acquire part).
9. **Verdicts.** Identical in modes B and C under:
   - AArch64: LDADDAL / LDAXR-STLXR give `[A];po ⊆ bob`;
   - x86-TSO;
   - RC11.

   The sink is an assert branch that does not exist under NDEBUG.
10. **Independent reference.** clang removes both branches at -O1/-O2/-O3/-Os on x86_64 and aarch64 with both
    atomics implementations. Same-function siblings (:158/:159/:161, :297/:298/:300) survive
    (`outputs/compdiff-libvsync-v2-20261111T014632Z/RESULTS.md`).
11. **Why it matters.** It is the family's pattern occurring naturally (tautological post-condition asserts on RMW
    results), and it is removed by the compiler exactly as the family predicts.
12. **Limitations.** The seq_cst source makes the dependency verdict-irrelevant, and the sink is debug-only.

## W3 — libvsync `ebr.h:248` (K10)

1. **Source.** libvsync v4.3.0, `include/vsync/smr/ebr.h`.
2. **Fragment.** `epoch = vatomic64_read(&ebr->epoch_global); idx = V_EBR_GET_EPOCH_IDX(epoch) /* epoch % 3 */;
   ASSERT(idx <= V_EBR_EPOCH_COUNT /* 3 */); smr_nodes_list_add(&ebr->retired_lst[idx], …)`. Context: the global
   `g_vebr` (`retire_cb`).
3. **Operations.** L is a seq_cst load.
4. **Syntactic dependency.** L → `urem 3` → `icmp ule 3` → `br`.
5. **Closure.** Mode B keeps the edge.
6. **Composed.** `epoch % 3 ≤ 3` is constant true (range restriction).
7. **rf.** Any write to `epoch_global`.
8. **Graph.** The only downstream shared store, `&retired_lst[idx]`, keeps a REAL address dependency on L.
9. **Verdicts.** Identical in modes B and C, because the source is seq_cst and the REAL address dependency remains.
10. **Independent reference.** clang removes the branch at -O1 and above (v2 differential).
11. **Why it matters.** It is an edge example of range restriction (modulo then bound check).
12. **Limitations.** As for W2.

## W4 — libvsync `atomicptr_stamped.h:86/87` (K06, K07)

1. **Source.** libvsync v4.3.0, `include/vsync/atomic/atomicptr_stamped.h`.
2. **Fragment.** `vatomicptr_stamped_cmpxchg`: `ASSERT(V_ATOMICPTR_STAMPED_IS_ALIGNED(e_v)); ASSERT(…IS_ALIGNED(v))`
   (:86/:87). Inlined into callers (`unbounded_queue_lf_recycle`, test `run`), where `e_v` and `v` come from
   `V_ATOMICPTR_STAMPED_GET_ADDRESS` (`and` with -128) of a seq_cst-loaded stamped pointer (global `g_queue`).
3. **Operations.** The load is seq_cst.
4. **Syntactic dependency.** Schematically L → `and -128` → `and 127` → `icmp eq 0` → `br`. The screen records
   paths of 7 (:86) and 13 (:87) instructions, through pointer-chasing loads of `node->next`.
5. **Closure.** Mode B keeps the edge.
6. **Composed.** `(x & -128) & 127 == 0` is constant true, a mask-then-test composition created by inlining. The
   slices are flagged memory-opaque (the `node->next` loads). The caveat is cleared mechanically: every pair stays
   constant with all opaque applications unshared (`outputs/opaque-probe-20261111T122327Z/libvsync-stamped-{86,87}-run.txt`).
7. **rf.** Any write to the stamped word.
8. **Graph.** Ordered by the seq_cst source.
9. **Verdicts.** Identical in modes B and C.
10. **Independent reference.**
    - :86 is removed at -O1 and above.
    - :87 is removed in every GET_ADDRESS context. One instance on a pool/qnode pointer, which is not a
      FAKE-COMPOSED context, survives.
11. **Why it matters.** It is a composition across a macro/helper boundary.
12. **Limitations.** As for W2.

## W5 — linux-7.3 VMA userspace test harness `dup.h:1532` (K-vma) — harness artefact, side observation

1. **Source.** linux-7.3 tarball sha256 `87363c24…`. The site is in `mm/vma.c:3219` (kernel code) compiled
   against `tools/testing/vma/include/dup.h` (the harness's duplicate of kernel inlines).
2. **Fragment.** `mlock_future_ok(mm, vma_test(vma, VMA_LOCKED_BIT), grow << PAGE_SHIFT)` is called with a
   `bool`. The **harness duplicate** is `mlock_future_ok(mm, vm_flags_t vm_flags, bytes)`, containing
   `if (!(vm_flags & VM_LOCKED) || capable(CAP_IPC_LOCK))`. The kernel's own definition (`mm/mmap.c:231`) takes
   `bool is_vma_locked`.
3. **Operations.** L is a volatile load of the flags word in `_test_bit` (`tools/include/asm-generic/bitops/non-atomic.h:112`).
4. **Syntactic dependency.** Schematically L → `lshr nr` → `and 1` → (bool conversions) → `and 0x2000` →
   `icmp eq 0` → `br` (the `||` short-circuit, column 30). The screen records a path of 6 instructions; the slice is
   not memory-opaque.
5. **Closure.** Mode B keeps the edge.
6. **Composed.** A 0/1 value masked with bit 13 is 0, so the branch is constant. This is range restriction across
   inlined helpers.
7. **rf.** Not applicable in the harness: no other thread.
8. **Graph.** None: the harness is single-threaded (0 files in `tools/testing/vma` use pthread).
9. **Verdicts.** No concurrent context exists. In the kernel itself there is no cancellation, because the
   signature is `bool`.
10. **Independent reference.** The kernel source (`mm/mmap.c:231`) shows the current signature. The harness's
    `capable()` stub returns true (`stubs.h:343`), so the duplicate's result is constant-true anyway.
11. **Why it matters.** Not for weak memory. It is a latent inconsistency between the harness duplicate and the
    kernel (type confusion bool vs flags word). It would silently disable the mlock-limit path if the harness
    stub ever returned false. Recorded as a side observation; nothing was reported upstream.
12. **Limitations.** Not checked against later upstream commits. The `CHECKPOINT` entry S5 first attributed the
    site to the `capable()` stub; R6 corrects this.
