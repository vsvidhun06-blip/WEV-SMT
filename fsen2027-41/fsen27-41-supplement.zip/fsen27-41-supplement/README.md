# FSEN 2027 #41 — supplement (witness search, store forwarding, argument-to-return comparison, LLVM re-run)

This archive is **separate from, and does not change,** the two validated archives of the paper's artifact
(the corrected base artifact and `fsen27-41-addon`). Nothing here enters the paper's totals (corpus 2,396
eligible / 2,380 analysed, population 256, rings 3,656, memory-hop set).

| Directory | What | Evidence class |
|---|---|---|
| `witness/` | Pre-registered search for an upstream computation where mode B keeps and mode C removes a load-to-store dependency. `PROTOCOL.md` (fixed before fetching), `sources.txt` (pins), `SCREENING.md` (counts, candidate table, closest examples), scripts and recorded outputs | upstream tests (S1 LKMM litmus files run directly; S2 LLVM tests screened); no constructed harness was needed because nothing was eligible |
| `forwarding/` | LB-mem-cancel and two constructed transforms (read-after-write elimination; then fold and reorder). `FORWARDING.md` gives the access semantics, the preconditions of each step and the verdicts | constructed tests, tool runs; legality from the cited literature (`references/`) |
| `argform/` | **Post-review, exploratory** (not part of the prespecified search): the referee's four LLVM i32 argument-to-return functions, verbatim (`cases/`), constructed `Load; P; Store` wrappers (`inputs/`), modes A/B/C, reference, independent IR-level check, regression test; `ARGFORM.md`, `FORWARDING-CITATION.md` (the bridge from POPL'15 Thm. 10 to the 2011 model), `RECONCILIATION.md` (35,946 vs 35,953 functions) | upstream functions (verbatim) + constructed wrappers; tool runs |
| `llvm/` | `llvm_knownbits.py` (hand-written i32 IR; InstCombine alone, and NewGVN then InstCombine) with the original and the re-run output, byte-identical | tool run (llvmlite 0.50.0, LLVM 22.1.0) |

## Check
```
PKGROOT=<extracted base artifact> ADDON=<extracted fsen27-41-addon> WORK=<scratch> bash check_supplement.sh
```
Expected: `SUPPLEMENT RESULT: PASS`. Needs the base artifact's Java/Z3 environment (as for the add-on) and Python
with the `z3-solver` package. `FULL=1` additionally fetches both pinned sources (network), re-extracts S1, re-runs
modes A/B/C on all 4,505 S1 files (about an hour on the author's machine) and the S2 screen, and compares
byte-for-byte with `recorded/`. The LLVM script needs llvmlite 0.50.0 and is not run by the checker
(`python -I llvm/llvm_knownbits.py > out; diff out llvm/llvm_knownbits.out`).

## Results in one line each
- Witness search: 0 eligible of 4,505 S1 files and 1,767 S2 files; no edge, tool-answer or verdict change.
- Forwarding: LB-mem-cancel C=F; after the RaW elimination (sound for these all-relaxed programs in the 2011 model, via the monotone Naive model; `argform/FORWARDING-CITATION.md`) C=A, A=B=F;
  after fold and reorder, all modes A. Not applicable to the test as written in LKMM (volatile; `dep;rfi`).
- Argument-to-return (post-review, 4 referee-chosen i32 functions): B keeps and C removes the disputed edge in 4 of 4;
  the reference and an independent IR-level check confirm the absence; analysis edges only (no compiler run at the
  time; the recovery pass then ran InstCombine on them, see below).
- LLVM: InstCombine alone leaves the 2x+2 comparison; NewGVN then InstCombine rewrites it to u+1.

## Recovery pass (2026-11-09/10): `recovery/`
Constructed programs and compiler runs. Outside the prespecified search and every historical total. Cited by the
paper's §5 paragraph "Compiled code" and App. D.

| Directory | What |
|---|---|
| `recovery/family/` | 17 constructed LB patterns (14 cancelling, 3 dependent controls), generated as LKMM litmus and as C11 relaxed atomics (`gen_family.py`), with modes A/B/C, the reference and `check_family.py` (claims C1–C6) |
| `recovery/compiler/` | `sweep.py`: clang 20.1.2 (zig 0.15.2) at -O0..-O3 for AArch64, x86-64, RISC-V and Arm32. It traces store←load dataflow in the IR and in the AArch64 asm. `src/` holds LB-mem-cancel (relaxed and plain `z`), T+-LB, its control, and the four upstream identities wrapped in relaxed loads |
| `recovery/armcheck/` | Independent Arm-model verdict from the AArch64 -O1..-O3 asm: its own parser, `ob = rfe ∪ dob ∪ bob` on the LB candidate |
| `recovery/variants/` | 7 falsification variants: renamed registers and locations, other constants, swapped operands, mixed threads, 3-thread rings |
| `recovery/llvm/` | `llvm_actual.py`: InstCombine (LLVM 22.1.0 via llvmlite 0.50.0; not the `opt` binary) on the four referee functions and on apint-sub @test19, each alone and in its whole upstream test file |
| `recovery/formal/` | `WEV_SMT_Rec` (Isabelle2024; corollary-level): prog_dep and esdep are invariant under value-preserving rewrites, while vdep and sites⁺ are not |

Run: `PKGROOT=… ADDON=… WORK=… [ZIGPY=<python with ziglang==0.15.2>] [LLVMPY=<python with llvmlite==0.50.0>]
[LLVM_SRC=<llvm-project at llvmorg-22.1.0>] [ISABELLE_HOME=…] bash recovery/run_recovery.sh <out>`.
`check_supplement.sh` calls it in its default stage. Without the optional tools it compares against the recorded
outputs only, and says so.

Results:
- Modes A/B forbid all 14 cancelling programs; mode C and the reference admit them. Clang -O1..-O3 compiles 13 of
  them to a constant store on all four targets, so the Arm model allows their outcome (two independent checks).
  `((r·r−r)&1)+1` and the 3 controls keep the dependence.
- LB-mem-cancel: clang keeps both relaxed loads at every level (no store-to-load forwarding). A plain `z` is
  forwarded.
- InstCombine removes the disputed argument in all four referee functions. This is edge-level only.
- **Not done:** GCC (unavailable), hardware runs, herd7, other compiler versions.
