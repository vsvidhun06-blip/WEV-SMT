#!/usr/bin/env bash
# FSEN 2027 #41 supplement check. Everything here is outside the paper's historical totals (corpus 2,396/2,380,
# population 256, rings 3,656): an upstream witness search and a constructed store-forwarding experiment.
#
# Default (offline, ~2 min): verify hashes; recompute the S1/S2 summaries and the Z3 checks from the recorded
# outputs; re-run the forwarding experiment with the pinned corrected-v1 classes and check its verdicts;
# re-run the post-review argument-to-return comparison (argform/: modes A/B/C, reference, IR-level check,
# regression test); re-run the recovery pass (recovery/: family modes A/B/C, reference, claim checker,
# corruption test; with ZIGPY / LLVMPY+LLVM_SRC also the clang sweep and the InstCombine run).
# FULL=1 additionally fetches both pinned sources, re-extracts S1, re-runs mode A/B/C on all 4,505 S1 files
# (about an hour) and the S2 screen, re-extracts the argform cases and recounts functions, and compares with the
# recorded outputs.
#
# Usage: PKGROOT=<extracted base artifact> ADDON=<extracted fsen27-41-addon> WORK=<scratch> [FULL=1] bash check_supplement.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKGROOT:?}"; : "${ADDON:?}"; : "${WORK:?}"
PY="${PYTHON:-python}"
mkdir -p "$WORK"; FAILS=0
step() { echo; echo "== $*"; }
ok()   { echo "PASS $*"; }
bad()  { echo "FAIL $*"; FAILS=$((FAILS+1)); }
same() { diff -q --strip-trailing-cr "$1" "$2" > /dev/null; }   # line-ending-insensitive comparison

step "hashes"
( cd "$HERE" && sha256sum -c --quiet SHA256SUMS ) && ok "SHA256SUMS" || bad "SHA256SUMS"

step "S1 summary recomputed from recorded prototype outputs"
"$PY" -I "$HERE/witness/s1/s1_analyse.py" "$HERE/witness/s1/recorded/s1-out" "$HERE/witness/s1/recorded/s1-manifest.tsv" \
  "$WORK/s1-cands.tsv" "$WORK/s1-summary.txt"
same "$WORK/s1-summary.txt" "$HERE/witness/s1/recorded/s1-summary.txt" && ok "s1-summary" || bad "s1-summary"
grep -q '^eligible (edge with composed expression of >=2 operators) 0 files, 0 edges$' "$WORK/s1-summary.txt" && ok "S1 eligible = 0" || bad "S1 eligible"
grep -q '^edges where B keeps and C removes 0$' "$WORK/s1-summary.txt" && ok "S1 B-keeps/C-removes = 0" || bad "S1 B/C edges"
grep -q '^files where verdict B != C 0$' "$WORK/s1-summary.txt" && ok "S1 verdict B != C = 0" || bad "S1 verdicts"

step "Z3 checks (closest S1 example; the single S2 screen hit)"
"$PY" -I "$HERE/witness/s1/s1_jo_oota4_z3.py" "$WORK/s1-jo-oota4.out"
same "$WORK/s1-jo-oota4.out" "$HERE/witness/s1/recorded/s1-jo-oota4.out" && ok "C-JO-OOTA-4 varies in both loads" || bad "C-JO-OOTA-4"
"$PY" -I "$HERE/witness/s2/s2_z3_check.py" "$WORK/s2-z3.out"
grep -q 'store value varies with loads (16-bit, wrap-around, no undef): sat' "$WORK/s2-z3.out" && ok "S2 hit is not a wrap-around identity" || bad "S2 z3"

step "forwarding experiment (constructed; pinned corrected-v1 classes)"
if PKGROOT="$PKGROOT" ADDON="$ADDON" WORK="$WORK/fw" bash "$HERE/forwarding/run_forwarding.sh" "$WORK/forwarding"; then
  ok "forwarding verdicts"; else bad "forwarding verdicts"; fi

step "post-review argument-to-return comparison (exploratory; 4 LLVM i32 functions; outside every total)"
if PKGROOT="$PKGROOT" ADDON="$ADDON" WORK="$WORK/af" bash "$HERE/argform/run_argform.sh" "$WORK/argform"; then
  ok "argform verdicts and regression test"; else bad "argform"; fi

step "recovery pass: compiled-code family, compiler sweep, InstCombine (constructed; outside every total but Sec. 5 'Compiled code')"
if PKGROOT="$PKGROOT" ADDON="$ADDON" WORK="$WORK/rec" bash "$HERE/recovery/run_recovery.sh" "$WORK/recovery"; then
  ok "recovery family checks"; else bad "recovery"; fi

if [ "${FULL:-0}" = 1 ]; then
  step "FULL: fetch pinned sources"
  bash "$HERE/witness/fetch_sources.sh" "$WORK/src"
  step "FULL: S1 extraction"
  "$PY" -I "$HERE/witness/s1/s1_extract.py" "$WORK/src/s1-litmus" 2f1be9ed9ae46f182ec50d0762b84451c91b41ac \
    "$PKGROOT/corpus/litmus" "$WORK/s1"
  for f in s1-manifest.tsv s1-list.txt s1-excluded-historical.tsv; do
    same "$WORK/s1/$f" "$HERE/witness/s1/recorded/$f" && ok "$f" || bad "$f"; done
  step "FULL: S1 text screen and prototype run"
  "$PY" -I "$HERE/witness/s1/s1_textscreen.py" "$WORK/s1/flat" "$WORK/s1/s1-list.txt" "$WORK/s1/s1-manifest.tsv" "$WORK/s1-text.tsv"
  same "$WORK/s1-text.tsv" "$HERE/witness/s1/recorded/s1-text.tsv" && ok "s1-text.tsv" || bad "s1-text.tsv"
  mkdir -p "$WORK/s1-out"
  PKGROOT="$PKGROOT" WORK="$WORK/s1w" bash "$ADDON/impl/run_composed.sh" "$WORK/s1-out" "$WORK/s1/s1-list.txt" "$WORK/s1/flat" > "$WORK/s1-run.log" 2>&1
  for f in files.csv edges.csv; do
    same "$WORK/s1-out/$f" "$HERE/witness/s1/recorded/s1-out/$f" && ok "S1 $f" || bad "S1 $f"; done
  step "FULL: S2 screen"
  "$PY" -I "$HERE/witness/s2/s2_screen.py" "$WORK/src/s2-llvm/llvm/test/Transforms/InstCombine" "$WORK/s2-screen.tsv"
  same "$WORK/s2-screen.tsv" "$HERE/witness/s2/recorded/s2-screen.tsv" && ok "s2-screen.tsv" || bad "s2-screen.tsv"
  step "FULL: argform cases re-extracted from the pinned LLVM; function-count reconciliation; referee script"
  "$PY" -I "$HERE/argform/extract_cases.py" "$WORK/src/s2-llvm" "$WORK/af-cases" > "$WORK/af-extract.out"
  same "$WORK/af-extract.out" "$HERE/argform/recorded/extract_cases.out" && ok "extract_cases.out" || bad "extract_cases.out"
  for c in add-test26 xor-test19 add-test35 xor-test4 apint-sub-test19; do
    cmp -s "$WORK/af-cases/$c/upstream.ll" "$HERE/argform/cases/$c/upstream.ll" && ok "$c upstream.ll byte-identical" || bad "$c upstream.ll"; done
  IC="$WORK/src/s2-llvm/llvm/test/Transforms/InstCombine"
  "$PY" -I "$HERE/argform/reconcile_counts.py" "$IC" > "$WORK/af-rc.out"
  same "$WORK/af-rc.out" "$HERE/argform/recorded/reconcile_counts.out" && ok "reconcile_counts.out" || bad "reconcile_counts.out"
  "$PY" -I "$HERE/argform/reconcile_detail.py" "$IC" > "$WORK/af-rd.out"
  same "$WORK/af-rd.out" "$HERE/argform/recorded/reconcile_detail.out" && ok "reconcile_detail.out" || bad "reconcile_detail.out"
  "$PY" -I "$HERE/argform/referee/llvm_argform.py" "$IC" > "$WORK/af-referee.out"
  same "$WORK/af-referee.out" "$HERE/argform/referee/llvm_argform.out" && ok "referee llvm_argform.out (35,953)" || bad "referee llvm_argform.out"
fi

echo; [ "$FAILS" = 0 ] && echo "SUPPLEMENT RESULT: PASS" || echo "SUPPLEMENT RESULT: FAIL ($FAILS)"
exit "$FAILS"
