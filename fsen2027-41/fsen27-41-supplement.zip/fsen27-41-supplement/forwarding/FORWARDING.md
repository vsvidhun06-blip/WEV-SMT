# Store-to-load forwarding on LB-mem-cancel (2026-11-09)

Referee observation (R2): LB-mem-cancel's outcome is produced by (1) forwarding the store of z to its reload,
(2) simplifying (r+1)−r to 1, (3) reordering the constant store before the load of y.

## The test (constructed; ours)
```
P0: r0 = READ_ONCE(*y); t0 = r0 + 1; WRITE_ONCE(*z, t0); u0 = READ_ONCE(*z); s0 = u0 - r0; WRITE_ONCE(*x, s0);
P1: r1 = READ_ONCE(*x); WRITE_ONCE(*y, r1);
exists (0:r0=1 /\ 1:r1=1)      initial state: all 0
```

## Access semantics and the preconditions of each step

| Step | As LKMM (`READ_ONCE`/`WRITE_ONCE` as written) | As C11 `memory_order_relaxed` atomics |
|---|---|---|
| (1) replace `u0 = READ_ONCE(*z)` by `u0 = t0` (read-after-write elimination; the load immediately follows the store to the same location) | **Not a legal compiler step**: `READ_ONCE`/`WRITE_ONCE` are volatile accesses, which the compiler must perform as written. LKMM itself orders the chain: `to-r = (addr;[R]) \| (dep;[Marked];rfi)` (linux `tools/memory-model/linux-kernel.cat`, line 84 at v6.12), so `ld y →data st z →rfi ld z` is ppo and the cycle is forbidden; Arm orders `(addr\|data);rfi` likewise | **Sound**, by Vafeiadis et al., POPL 2015, Thm. 10 (RaW-Adjacent) plus a bridge: Thm. 10 is stated for *monotone* models (Def. 3), which the 2011 model (ConsRFna, SCorig, RSorig, STorig) is not; but for an all-relaxed program whose initial writes happen-before every access, ConsRFna and the SC axioms are vacuous, so its executions equal those of the monotone (Naive, SCnew, RSorig, STorig), to which Thm. 10 applies (relaxed read, STorig). Thm. 10 also covers (Arf, SCnew, RSorig, STorig) directly. Adjacency: nothing lies between the store and the reload in P0. Argument: `../argform/FORWARDING-CITATION.md` |
| (2) `s0 = (r0+1) − r0` → `1` | register arithmetic, valid (wrap-around identity) | same |
| (3) move `WRITE_ONCE(*x, 1)` above `WRITE_ONCE(*z, ·)` and `READ_ONCE(*y)` | not reached | W;W to different locations: valid. R_rlx(y);W_rlx(x) → W;R: valid for Naive (Table 1, Thm. 6 with monotonicity), hence, by the bridge, for the 2011 model on this program; **invalid** in the models that forbid (hb ∪ rf) cycles (Arf, Arfna) — Vafeiadis et al., Table 1 and reorderability condition (5) |

So the transformation chain is justified under one specified model: C11 relaxed atomics with the 2011
semantics, via the bridge to the monotone (Naive, SCnew, RSorig, STorig) (an earlier version of this note cited
Thm. 10 for the 2011 model directly; that was imprecise, see `../argform/FORWARDING-CITATION.md`). Under that model the original outcome is allowed anyway (C11 2011 does not exclude load buffering).
It is not justified for the test as written under LKMM.

## Runs (pinned corrected-v1 classes; commands in `run_forwarding.sh`; outputs in `recorded/`)

| File | Label | A | B | C | NODEP | Coh (RA) | RC11 | x-store label (mode C) |
|---|---|---|---|---|---|---|---|---|
| `LB-mem-cancel.litmus` (byte-identical to the add-on's `inputs/memhop/`) | constructed | F | F | **F** | A | A | F | `(L_u) − (L_r)` VARIES |
| `LB-mem-cancel-raw.litmus` (after step 1) | constructed | F | F | **A** | A | A | F | `((L_r)+1) − (L_r)` CONST |
| `LB-mem-cancel-raw-reord.litmus` (after steps 2–3) | constructed | A | A | A | A | A | A | (store of 1, no edge) |

(Coh and RC11 columns from `run_probe.sh`, which runs modes A/B; the two agree on every model.)

## Narrow explanation
- Step 1 turns LB-mem-cancel into the T+-LB shape: the reload's fresh symbol L_u is replaced by its definition
  L_r+1, so the store's composed label becomes constant and mode C's sdep loses the y→x edge.
- Hence for C11 relaxed atomics the per-thread composed-label criterion is **not invariant under a sound
  read-after-write elimination**: it forbids a program whose soundly transformed version it admits. Modes A/B
  forbid both; only the last program (after a reordering that is itself invalid in po∪rf-acyclic models) is
  admitted by every mode and by RC11.
- Under LKMM the forwarding claim does not apply: the compiler step is unavailable and LKMM's own `to-r`
  orders the dependency through `rfi`, as Arm hardware does.

Not shown: that any production compiler performs step 1 on relaxed atomics (no compiler was executed), or a
Promising run (the Promising verdict remains a hand derivation, App. B).
