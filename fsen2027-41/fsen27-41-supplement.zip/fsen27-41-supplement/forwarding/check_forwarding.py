"""Check the forwarding experiment's outputs against the expected verdicts (constructed tests; not part of any
population, corpus or ring total).  Event ids are normalised (R<digits> -> R) because they are run-global.
Usage: python -I check_forwarding.py <files.csv> <edges.csv> <probe.txt>   exit 0 = all expected, 1 = mismatch"""
import csv, re, sys
fcsv, ecsv, probe = sys.argv[1:4]
EXP_FILES = {  # file: (support, A, B, C, NODEP)
    'LB-mem-cancel.litmus':            ('SUPPORTED', 'F', 'F', 'F', 'A'),
    'LB-mem-cancel-raw.litmus':        ('SUPPORTED', 'F', 'F', 'A', 'A'),
    'LB-mem-cancel-raw-reord.litmus':  ('SUPPORTED', 'A', 'A', 'A', 'A'),
}
EXP_EDGES = {  # file: sorted (loc, B-local semantic, composed, normalised expression)
    'LB-mem-cancel.litmus': sorted([('z', 'true', 'VARIES', '((R) + 1)'), ('x', 'true', 'VARIES', '((R) - (R))'),
                                    ('x', 'true', 'VARIES', '((R) - (R))'), ('y', 'true', 'VARIES', '(R)')]),
    'LB-mem-cancel-raw.litmus': sorted([('z', 'true', 'VARIES', '((R) + 1)'), ('x', 'true', 'CONST', '((((R) + 1)) - (R))'),
                                        ('y', 'true', 'VARIES', '(R)')]),
    'LB-mem-cancel-raw-reord.litmus': sorted([('z', 'true', 'VARIES', '((R) + 1)'), ('y', 'true', 'VARIES', '(R)')]),
}
EXP_PROBE = {  # file: per mode A/B: SC TSO PSO RA WEAKEST RC11
    'LB-mem-cancel.litmus':           'SC=F TSO=F PSO=F RA=A WEAKEST=F RC11=F',
    'LB-mem-cancel-raw.litmus':       'SC=F TSO=F PSO=F RA=A WEAKEST=F RC11=F',
    'LB-mem-cancel-raw-reord.litmus': 'SC=A TSO=A PSO=A RA=A WEAKEST=A RC11=A',
}
bad = []
files = {r['file']: r for r in csv.DictReader(open(fcsv, encoding='utf-8'))}
for f, e in EXP_FILES.items():
    r = files.get(f)
    got = (r['support'], r['weakest_A'], r['weakest_B'], r['weakest_C'], r['weakest_NODEP']) if r else None
    print(f'{f:32s} support/A/B/C/NODEP expected {"/".join(e)} got {"/".join(got) if got else "MISSING"}')
    if got != e: bad.append(f + ' verdicts')
edges = {}
for r in csv.DictReader(open(ecsv, encoding='utf-8')):
    edges.setdefault(r['file'], []).append((r['write_loc'], r['local_B_semantic'], r['composed'],
                                           re.sub(r'R\d+', 'R', r['composed_expr'])))
for f, e in EXP_EDGES.items():
    got = sorted(edges.get(f, []))
    print(f'{f:32s} edges {"OK" if got == e else "MISMATCH"}: {got}')
    if got != e: bad.append(f + ' edges')
cur = None; seen = {}
for line in open(probe, encoding='utf-8'):
    t = line.strip()
    if t.endswith('.litmus'): cur = t; continue
    m = re.match(r'([AB]) \(.*?\)\s+WF-only=\S+\s+(SC=\S+ TSO=\S+ PSO=\S+ RA=\S+ WEAKEST=\S+ RC11=\S+)', t)
    if m and cur: seen[(cur, m.group(1))] = m.group(2)
for f, e in EXP_PROBE.items():
    for mode in 'AB':
        g = seen.get((f, mode))
        print(f'{f:32s} probe mode {mode}: expected {e} got {g}')
        if g != e: bad.append(f'{f} probe {mode}')
print('RESULT', 'PASS' if not bad else 'FAIL ' + '; '.join(bad))
sys.exit(1 if bad else 0)
