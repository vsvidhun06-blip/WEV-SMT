#!/usr/bin/env bash
# Re-run the store-forwarding experiment (LB-mem-cancel and two constructed transforms) with the pinned
# corrected-v1 classes, through the add-on's own drivers, and check the verdicts.
# Usage: PKGROOT=<extracted base artifact> ADDON=<extracted add-on> WORK=<scratch> bash run_forwarding.sh <outdir>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKGROOT:?set PKGROOT to the extracted base artifact root}"
: "${ADDON:?set ADDON to the extracted add-on root (fsen27-41-addon)}"
: "${WORK:?set WORK to a scratch dir}"
OUT="$1"; mkdir -p "$OUT/composed" "$WORK"
PY="${PYTHON:-python}"
# the original test must be byte-identical to the add-on's memory-hop input
cmp "$HERE/inputs/LB-mem-cancel.litmus" "$ADDON/inputs/memhop/LB-mem-cancel.litmus"
ls "$HERE/inputs" | grep '\.litmus$' | sort > "$OUT/list.txt"
PKGROOT="$PKGROOT" WORK="$WORK/c" bash "$ADDON/impl/run_composed.sh" "$OUT/composed" "$OUT/list.txt" "$HERE/inputs" > "$OUT/composed.log" 2>&1
PKGROOT="$PKGROOT" WORK="$WORK/p" bash "$ADDON/impl/run_probe.sh" "$HERE/inputs/LB-mem-cancel.litmus" \
  "$HERE/inputs/LB-mem-cancel-raw.litmus" "$HERE/inputs/LB-mem-cancel-raw-reord.litmus" > "$OUT/probe.txt" 2>&1
"$PY" -I "$HERE/check_forwarding.py" "$OUT/composed/files.csv" "$OUT/composed/edges.csv" "$OUT/probe.txt" | tee "$OUT/check.txt"
