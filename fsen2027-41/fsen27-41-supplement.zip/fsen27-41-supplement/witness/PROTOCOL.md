# Witness search protocol (fixed before screening; 2026-11-09)

**Question.** Does an existing program contain a multi-instruction computation in which mode B keeps a
load-to-store dependency, mode C removes it, and the difference matters to an observable analysis result?

## Sources (two, fixed now)
| Id | Source | Kind | Pinned revision | Why relevant |
|---|---|---|---|---|
| S1 | `github.com/paulmckrcu/litmus` (Paul McKenney's LKMM litmus collection), all `*.litmus` files | upstream regression and exploration tests for concurrent systems code (Linux kernel memory model) | `master` HEAD at fetch time; the commit hash is recorded in `sources.txt` before screening | LKMM tests deliberately probe dependency ordering (data/addr/ctrl, `READ_ONCE`/`WRITE_ONCE`), including dependency-breaking computations; written in the C litmus dialect the prototype parses |
| S2 | `github.com/llvm/llvm-project`, `llvm/test/Transforms/InstCombine/**/*.ll` | upstream compiler regression tests | tag `llvmorg-22.1.0` | InstCombine tests check value propagation and algebraic folding across several instructions; a test whose expected output no longer uses a loaded value shows the compiler removing a load-to-store dependence |

**Not sources.** Our own examples and their derivatives: Tables 1 and 3, the population, the rings, LB-mem-cancel.
Also excluded is the historical corpus already analysed: the 2,396 herd7 and Dat3M files. Any S1 file that is
byte-identical to a historical-corpus file, or identical after whitespace normalisation, is excluded and logged.
Application code is screened in neither source. Prior application-code gates (liburcu 0.15.7, an LLVM -O2 pilot)
are reported as history, not re-screened.

## Eligibility
S1 (litmus, run directly):
1. Parses, and mode C supports it (data edges only; no branch, RMW, address edge or unsupported construct). The
   prototype's own support manifest decides this.
2. At least one load-to-store data path through **two or more** assignments (multi-instruction): the composed
   expression has more operators than any single instruction on the path. Decided from the source text by a
   script, then confirmed by hand.

S2 (IR, needs translation):
1. A function in the input IR with a `load` whose value reaches a `store` operand through **two or more**
   arithmetic or logic instructions (no phi, select, call or memory operation on the path).
2. The test's CHECK lines for that function keep a `store` but show the stored value no longer depending on the
   load: the load is deleted, or the stored operand is a constant or derived only from other values. Decided by a
   script over the input and CHECK lines, then confirmed by hand.
3. The path's operations are in the paper's grammar (+ − ∗ ⊕ & |, ∼, comparisons with zext). Each width, nsw/nuw
   flag and poison/undef assumption is recorded. A fold that relies on poison semantics (nsw/nuw, exact) does
   **not** carry over to the paper's wrap-around semantics and makes the candidate ineligible for "B keeps, C
   removes" unless the fold also holds for wrap-around.

## Procedure for each eligible candidate
- Record the upstream URL, revision, path, lines and the code's original purpose.
- Identify the load, intermediate definitions and store; width, signedness, overflow and path conditions.
- Translate into the paper's fragment (S2: an LKMM C litmus file with `READ_ONCE`/`WRITE_ONCE` at the load and
  store, other values as initial registers or further loads). State every assumption the translation adds.
- Run modes A/B/C (prototype, pinned corrected-v1 classes) and the independent reference on the same file.
  Independently check (Z3 at the source width and at 32 bits) whether changing the load can change the store.
- Report separately: (i) recorded edge change, (ii) tool answer change (Boolean "is this edge semantic"),
  (iii) allowed/forbidden outcome change.
  - On an S1 file, (iii) is a real-test verdict under the encoder's LKMM-like model.
  - For S2, (iii) requires a constructed LB harness around the upstream fragment, and is labelled constructed.

## Stopping condition
Each source is screened once, completely, at its pinned revision. All eligible candidates are run (if more than
30 S2 candidates pass the script, the first 30 in path order are examined by hand and the rest are listed). No
source, directory or eligibility rule is added after results are seen. If nothing qualifies, report the numbers
screened and eligible and why the closest candidates failed.

## Labels used in reporting
- **upstream test**: S1 or S2 file as published.
- **upstream fragment**: the load-to-store computation extracted from an S2 function.
- **constructed harness**: our LB wrapper.
- **real-program verdict change**: reserved for a verdict established on the original upstream program under
  justified semantics.
