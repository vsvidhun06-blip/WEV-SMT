"""Independent Z3 check of the single S2 screen hit (and-or-icmps.ll, simplify_before_foldAndOfICmps, lines 365-403):
is the stored value %C18 = icmp ule i1 %C10, %C7 constant when the loads are ordinary free values (wrap-around,
no undef)?  Loads: %L7 = load A8, %L2 = load G4, %L = load G4 (same address, so L2 = L when no store intervenes)."""
from z3 import BitVec, BitVecVal, UDiv, ULT, ULE, UGT, If, Solver, sat, BoolVal, Not
import sys
out = open(sys.argv[1], 'w', encoding='utf-8', newline='\n')
L7, L = BitVec('L7', 16), BitVec('L', 16)
L2 = L  # same address, no intervening store
B11 = UDiv(L7, BitVecVal(0xFFFF, 16))
C10 = UGT(L, B11)
B20 = L7 & L2
C7 = B20 < 0  # signed slt 0
C18 = If(C10, 1, 0) <= If(C7, 1, 0)  # icmp ule on i1 = implication C10 -> C7
for want in (True, False):
    s = Solver(); s.add(C18 == BoolVal(want))
    r = s.check(); out.write(f'C18 can be {want}: {r}' + (f'  model {s.model()}' if r == sat else '') + '\n')
# does the store depend on a load?  exists two load values giving different C18
s = Solver(); L7b, Lb = BitVec('L7b', 16), BitVec('Lb', 16)
C10b = UGT(Lb, UDiv(L7b, BitVecVal(0xFFFF, 16))); C7b = (L7b & Lb) < 0
s.add(Not((If(C10, 1, 0) <= If(C7, 1, 0)) == (If(C10b, 1, 0) <= If(C7b, 1, 0))))
out.write(f'store value varies with loads (16-bit, wrap-around, no undef): {s.check()}\n')
out.write('Conclusion: the CHECK line "store i1 true" is not a wrap-around identity; it relies on the loads from the\n'
          'uninitialised alloca %A8 being undef/poison. Protocol criterion 3 makes the candidate ineligible.\n')
