"""S2 screen (protocol PROTOCOL.md): InstCombine IR tests at llvmorg-22.1.0.
For every function in the input IR: find load results that reach a store's value operand through >= 2
instructions, all of them pure arithmetic/logic/cast/compare (no phi, select, call or memory op on the path).
Then look at the CHECK lines for that function: keep the candidate if the expected output still has a store but
no load, or every expected store stores a literal constant.
Usage: python -I s2_screen.py <InstCombine dir> <out tsv>"""
import os, re, sys
root, out = sys.argv[1:3]
PURE = {'add', 'sub', 'mul', 'xor', 'and', 'or', 'shl', 'lshr', 'ashr', 'icmp', 'zext', 'sext', 'trunc',
        'udiv', 'sdiv', 'urem', 'srem', 'freeze'}
GRAMMAR = {'add', 'sub', 'mul', 'xor', 'and', 'or', 'icmp', 'zext'}
FN = re.compile(r'^define\b[^@]*@("?[\w.$-]+"?)\s*\(.*?\{\s*$(.*?)^\}', re.S | re.M)
DEF = re.compile(r'^\s*(%[\w.$-]+)\s*=\s*(\w+)\b(.*)$')
STORE = re.compile(r'^\s*store\s+(?:volatile\s+|atomic\s+)*(\S+)\s+([^,]+),')
CHK = re.compile(r'^;\s*([A-Z][A-Z0-9_-]*?)(-LABEL|-NEXT|-SAME|-NOT|-DAG)?:\s?(.*)$')

def operands(rest):
    return re.findall(r'%[\w.$-]+', rest)

rows = []
nfiles = nfn = nfn_ls = 0
for dp, _, fs in os.walk(root):
    for f in sorted(fs):
        if not f.endswith('.ll'):
            continue
        p = os.path.join(dp, f); rel = os.path.relpath(p, root).replace('\\', '/')
        text = open(p, encoding='utf-8', errors='replace').read()
        nfiles += 1
        # CHECK blocks keyed by function name
        chk = {}; cur = None
        for line in text.splitlines():
            m = CHK.match(line)
            if not m or m.group(1) in ('RUN', 'NOTE'):
                continue
            body = m.group(3)
            if m.group(2) == '-LABEL' or body.startswith('define '):
                g = re.search(r'@("?[\w.$-]+"?)', body)
                cur = g.group(1) if g else None
                chk.setdefault(cur, [])
                continue
            if cur is not None:
                chk[cur].append(body)
        for fm in FN.finditer(text):
            name, body = fm.group(1), fm.group(2)
            nfn += 1
            defs = {}; loads = {}; stores = []
            for i, line in enumerate(body.splitlines()):
                d = DEF.match(line)
                if d:
                    v, op, rest = d.groups()
                    defs[v] = (op, operands(rest))
                    if op == 'load':
                        loads[v] = line.strip()
                s = STORE.match(line)
                if s:
                    stores.append((s.group(2).strip(), line.strip()))
            if not loads or not stores:
                continue
            nfn_ls += 1
            for val, sline in stores:
                # longest pure path from a load to val
                def paths(v, depth=0):
                    if v in loads:
                        return [[v]]
                    if depth > 40 or v not in defs or defs[v][0] not in PURE:
                        return []
                    res = []
                    for o in defs[v][1]:
                        for pth in paths(o, depth + 1):
                            res.append(pth + [v])
                    return res
                for pth in paths(val):
                    n_inst = len(pth) - 1
                    if n_inst < 2:
                        continue
                    ops = [defs[v][0] for v in pth[1:]]
                    c = chk.get(name) or chk.get(name.strip('"')) or []
                    cstores = [l for l in c if re.match(r'\s*store\b', l)]
                    cloads = [l for l in c if re.search(r'=\s*load\b', l)]
                    const_only = cstores and all(re.match(r'\s*store\s+\S+\s+(-?\d+|true|false|zeroinitializer|poison|undef),', l) for l in cstores)
                    # protocol criterion 2, third case: expected stores whose values reach no expected load
                    cn = [re.sub(r'\[\[(\w+)(?::[^\]]*)?\]\]', r'%\1', l) for l in c]
                    cdefs = {}; cld = set(); cst = []
                    for l in cn:
                        d = DEF.match(l)
                        if d:
                            cdefs[d.group(1)] = (d.group(2), operands(d.group(3)))
                            if d.group(2) == 'load': cld.add(d.group(1))
                        s2 = STORE.match(l)
                        if s2: cst.append(s2.group(2).strip())
                    def reaches(v, seen=()):
                        if v in cld: return True
                        if v in seen or v not in cdefs: return False
                        return any(reaches(o, seen + (v,)) for o in cdefs[v][1])
                    indep = bool(cst) and not any(reaches(v) for v in cst)
                    hit = bool(cstores) and (not cloads or const_only or indep)
                    rows.append((rel, name, pth[0], val, n_inst, '|'.join(ops),
                                 'yes' if set(ops) <= GRAMMAR else 'no',
                                 'yes' if c else 'no', 'HIT' if hit else '-', ' ;; '.join(cstores)[:200]))
with open(out, 'w', encoding='utf-8', newline='\n') as fo:
    fo.write('file\tfunction\tload\tstored\tn_inst\tops\tin_grammar\thas_checks\tscreen\tcheck_stores\n')
    for r in rows:
        fo.write('\t'.join(map(str, r)) + '\n')
hits = [r for r in rows if r[8] == 'HIT']
print(f'files {nfiles}, functions {nfn}, functions with load and store {nfn_ls}, '
      f'load->store pure paths with >=2 instructions {len(rows)}, screen hits {len(hits)} '
      f'(in grammar: {sum(1 for r in hits if r[6] == "yes")}), distinct functions hit {len({(r[0], r[1]) for r in hits})}')
