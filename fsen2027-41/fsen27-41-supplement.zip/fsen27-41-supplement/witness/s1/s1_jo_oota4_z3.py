"""Closest S1 example (hand analysis; the prototype rejects the file).
paulmckrcu/litmus @2f1be9ed, manual/oota/C-JO-OOTA-4.litmus, P0 (P1 symmetric):
  r1 = READ_ONCE(*x); smp_rmb(); r2 = *b; r3 = r1 == 0; WRITE_ONCE(*a, (r3 + 1) & r2);
Composed label of the store to a: ((L1 == 0) + 1) & L2.  Question: non-constant in L1 (with L2 free)?
in L2?  Same answer at 32 and 64 bits?  Usage: python -I s1_jo_oota4_z3.py <out>"""
import sys
from z3 import BitVec, BitVecVal, If, Solver, Not
out = open(sys.argv[1], 'w', encoding='utf-8', newline='\n')
for w in (32, 64):
    L1, L1b, L2, L2b = (BitVec(n, w) for n in ('L1', 'L1b', 'L2', 'L2b'))
    f = lambda a, b: (If(a == 0, BitVecVal(1, w), BitVecVal(0, w)) + 1) & b
    s = Solver(); s.add(Not(f(L1, L2) == f(L1b, L2)))
    r1 = s.check(); m1 = s.model() if str(r1) == 'sat' else None
    s = Solver(); s.add(Not(f(L1, L2) == f(L1, L2b)))
    r2 = s.check()
    out.write(f'{w}-bit: varies in L1 (L2 fixed): {r1} {m1}; varies in L2 (L1 fixed): {r2}\n')
out.write('Both edges are semantic, so modes B and C agree (both keep): not a B-keeps/C-removes witness.\n')
