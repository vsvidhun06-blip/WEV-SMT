"""S1 extraction and historical-corpus exclusion (protocol PROTOCOL.md).
Reads every *.litmus blob of the pinned commit straight from git (the collection has case-colliding names,
so the working tree on a case-insensitive file system is incomplete), writes them under collision-free
names s1_NNNNN.litmus in path order, then excludes files byte-identical, or identical after removing all
whitespace, to a file of the historical corpus.
Usage: python -I s1_extract.py <repo at pinned commit> <commit> <historical corpus root> <outdir>
Writes <outdir>/flat/, s1-manifest.tsv (flat, upstream path, sha256), s1-list.txt, s1-excluded-historical.tsv"""
import hashlib, os, re, subprocess, sys
repo, commit, hist, od = sys.argv[1:5]
os.makedirs(od + '/flat', exist_ok=True)
paths = subprocess.run(['git', '-C', repo, 'ls-tree', '-r', commit, '--name-only'], capture_output=True,
                       check=True, text=True, encoding='utf-8').stdout.split('\n')
paths = [p for p in paths if p.endswith('.litmus')]
def norm(b): return re.sub(rb'\s+', b'', b)
H, N = set(), set()
for dp, _, fs in os.walk(hist):
    for f in fs:
        if f.endswith('.litmus'):
            b = open(os.path.join(dp, f), 'rb').read()
            H.add(hashlib.sha256(b).hexdigest()); N.add(hashlib.sha256(norm(b)).hexdigest())
man, keep, exc = [], [], []
for i, p in enumerate(paths):
    b = subprocess.run(['git', '-C', repo, 'show', f'{commit}:{p}'], capture_output=True, check=True).stdout
    name = f's1_{i:05d}.litmus'
    open(f'{od}/flat/{name}', 'wb').write(b)
    h = hashlib.sha256(b).hexdigest(); man.append((name, p, h))
    if h in H: exc.append((name, p, 'byte-identical to historical corpus'))
    elif hashlib.sha256(norm(b)).hexdigest() in N: exc.append((name, p, 'identical to historical corpus after whitespace removal'))
    else: keep.append(name)
with open(f'{od}/s1-manifest.tsv', 'w', encoding='utf-8', newline='\n') as f:
    for m in man: f.write('\t'.join(m) + '\n')
open(f'{od}/s1-list.txt', 'w', newline='\n').write('\n'.join(keep) + '\n')
with open(f'{od}/s1-excluded-historical.tsv', 'w', encoding='utf-8', newline='\n') as f:
    for e in exc: f.write('\t'.join(e) + '\n')
print(f'historical files {len(H)}; S1 litmus files {len(man)}; kept {len(keep)}; excluded {len(exc)}')
