"""S1 analysis per PROTOCOL.md. Inputs: run_composed.sh outputs (files.csv, edges.csv), the manifest
(flat name -> upstream path), the flat file dir. Output: summary + candidate TSV.
Eligibility: (1) SUPPORTED by mode C; (2) a load->store data edge whose composed expression has >= 2 operators
(at least two assignments on the path), confirmed by hand afterwards.
Outcome columns: B keeps & C removes (local_B_semantic true, composed CONST); verdict B vs C.
Usage: python -I s1_analyse.py <outdir> <manifest.tsv> <out.tsv> <summary.txt>"""
import csv, re, sys
od, man, out, summ = sys.argv[1:5]
path = {}
for l in open(man, encoding='utf-8'):
    n, p, h = l.rstrip('\n').split('\t'); path[n] = p
files = list(csv.DictReader(open(od + '/files.csv', encoding='utf-8')))
edges = list(csv.DictReader(open(od + '/edges.csv', encoding='utf-8')))
OPS = re.compile(r'(?<![A-Za-z0-9_])([-+*^&|~]|<<|>>|==|!=|<=|>=|<|>)')
def nops(e):
    return len(OPS.findall(re.sub(r'R\d+', 'R', e)))
sup = [f for f in files if f['support'] == 'SUPPORTED']
reasons = {}
for f in files:
    if f['support'] != 'SUPPORTED':
        k = (f['reason'] or f['support']).split(':')[0][:60]; reasons[k] = reasons.get(k, 0) + 1
byfile = {}
for e in edges: byfile.setdefault(e['file'], []).append(e)
with_edges = [f for f in sup if byfile.get(f['file'])]
elig = []; rows = []
for f in sup:
    for e in byfile.get(f['file'], []):
        k = nops(e['composed_expr'])
        bkeep_cconst = e['local_B_semantic'] == 'true' and e['composed'] == 'CONST'
        if k >= 2 or bkeep_cconst:
            rows.append((f['file'], path[f['file']], e['read_id'], e['write_id'], e['write_loc'], k,
                         e['local_A_semantic'], e['local_B_semantic'], e['composed'], e['composed_expr'],
                         f['weakest_A'], f['weakest_B'], f['weakest_C'], f['weakest_NODEP']))
        if k >= 2: elig.append(f['file'])
elig = sorted(set(elig))
disagree_edge = [r for r in rows if r[7] == 'true' and r[8] == 'CONST']
disagree_verdict = [f for f in sup if f['weakest_B'] != f['weakest_C']]
fakeA = sum(int(f['edges_fake_A'] or 0) for f in sup); fakeB = sum(int(f['edges_fake_B'] or 0) for f in sup)
fakeC = sum(int(f['edges_fake_C'] or 0) for f in sup)
with open(out, 'w', encoding='utf-8', newline='\n') as fo:
    fo.write('flat\tupstream_path\tread\twrite\tloc\tops\tA_sem\tB_sem\tC\texpr\tvA\tvB\tvC\tvNODEP\n')
    for r in rows: fo.write('\t'.join(map(str, r)) + '\n')
with open(summ, 'w', encoding='utf-8', newline='\n') as fo:
    fo.write(f'files run {len(files)}; SUPPORTED by mode C {len(sup)}; unsupported {len(files)-len(sup)}\n')
    for k, v in sorted(reasons.items(), key=lambda x: -x[1]): fo.write(f'  unsupported reason {v:5d}  {k}\n')
    fo.write(f'supported files with >=1 load->store data edge {len(with_edges)}; edges {sum(len(byfile[f["file"]]) for f in with_edges)}\n')
    fo.write(f'eligible (edge with composed expression of >=2 operators) {len(elig)} files, {sum(1 for r in rows if r[5]>=2)} edges\n')
    fo.write(f'edges where B keeps and C removes {len(disagree_edge)}\n')
    fo.write(f'files where verdict B != C {len(disagree_verdict)}\n')
    fo.write(f'fake edges A/B/C {fakeA}/{fakeB}/{fakeC}\n')
    ve = {}
    for f in sup: ve[(f['weakest_A'], f['weakest_B'], f['weakest_C'], f['weakest_NODEP'])] = ve.get((f['weakest_A'], f['weakest_B'], f['weakest_C'], f['weakest_NODEP']), 0) + 1
    for k, v in sorted(ve.items()): fo.write(f'  verdict A/B/C/NODEP {"/".join(k)}: {v}\n')
    fo.write('composed-expression shapes on eligible edges:\n')
    sh = {}
    for r in rows:
        if r[5] >= 2:
            s = re.sub(r'R\d+', 'R', r[9]); sh[s] = sh.get(s, 0) + 1
    for k, v in sorted(sh.items(), key=lambda x: -x[1]): fo.write(f'  {v:5d}  {k}\n')
