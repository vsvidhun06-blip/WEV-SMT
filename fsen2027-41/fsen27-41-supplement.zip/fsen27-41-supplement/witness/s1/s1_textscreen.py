"""Parser-independent text screen of S1 (all 4,505 non-historical files): find load->store data paths through
>= 2 assignments (load into r, at least one further register assignment, then a store whose value uses it).
This guards against the prototype's parse errors hiding candidates.  Heuristic; hits are inspected by hand.
Usage: python -I s1_textscreen.py <flatdir> <list> <manifest> <out.tsv>"""
import re, sys
flat, lst, man, out = sys.argv[1:5]
path = {l.split('\t')[0]: l.split('\t')[1] for l in open(man, encoding='utf-8')}
LOAD = re.compile(r'(READ_ONCE|smp_load_acquire|rcu_dereference\w*|atomic\w*_read\w*|srcu_dereference\w*|xchg\w*|cmpxchg\w*|atomic\w*_(?:add|sub|inc|dec|fetch)\w*)\s*\(')
STORE = re.compile(r'(WRITE_ONCE|smp_store_release|rcu_assign_pointer|atomic\w*_set\w*)\s*\(\s*([^,]+),\s*(.*)\)\s*;')
ASSIGN = re.compile(r'^\s*(?:[A-Za-z_][\w\s\*]*?\s)?\**\s*([A-Za-z_]\w*)\s*=\s*(.*?);\s*$')
IDENT = re.compile(r'[A-Za-z_]\w*')
rows = []; n = 0
for name in open(lst).read().split():
    n += 1
    text = open(flat + '/' + name, encoding='utf-8', errors='replace').read()
    text = re.sub(r'\(\*.*?\*\)', '', text, flags=re.S)
    for pm in re.finditer(r'\bP(\d+)\s*\([^)]*\)\s*\{(.*?)\n\}', text, re.S):
        depth = {}  # register -> number of assignments from a load
        for line in pm.group(2).split('\n'):
            a = ASSIGN.match(line)
            s = STORE.search(line)
            if s:
                ids = set(IDENT.findall(s.group(3)))
                d = max([depth.get(i, 0) for i in ids] + [0])
                if d >= 1:
                    rows.append((name, path[name], 'P' + pm.group(1), d, line.strip()))
                continue
            if a:
                lhs, rhs = a.group(1), a.group(2)
                if LOAD.search(rhs):
                    depth[lhs] = 1
                else:
                    ids = set(IDENT.findall(rhs)) - {lhs}
                    d = max([depth.get(i, 0) for i in ids] + [0])
                    depth[lhs] = d + 1 if d >= 1 else 0
with open(out, 'w', encoding='utf-8', newline='\n') as fo:
    fo.write('flat\tupstream\tthread\tassignments\tstore\n')
    for r in rows: fo.write('\t'.join(map(str, r)) + '\n')
d1 = {r[0] for r in rows}; d2 = {r[0] for r in rows if r[3] >= 2}
print(f'files {n}; files with a load->store data path {len(d1)}; with >=2 assignments {len(d2)}')
