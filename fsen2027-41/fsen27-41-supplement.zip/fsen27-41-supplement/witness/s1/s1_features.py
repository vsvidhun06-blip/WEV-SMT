"""Tally constructs in S1 files rejected (PARSE_ERROR) vs supported, to explain the rejections.
Usage: python -I s1_features.py <flatdir> <files.csv> <out.txt>"""
import csv, re, sys
flat, fcsv, out = sys.argv[1:4]
F = {
 'if/else (control)': r'\bif\s*\(',
 'spin_lock/unlock or mutex': r'\b(spin_|mutex_|raw_spin_)\w*\(',
 'RMW (xchg/cmpxchg/atomic_*)': r'\b(xchg|cmpxchg|atomic\w*)\w*\s*\(',
 'RCU / SRCU primitives': r'\b(rcu_|srcu_|synchronize_|call_rcu)\w*\(',
 'smp_load_acquire / smp_store_release': r'\bsmp_(load_acquire|store_release)\(',
 'plain access *p': r'=\s*\*\w+\s*;|^\s*\*\w+\s*=',
 'exists with disjunction or negation': r'exists[^\n]*(\\/|~)',
 'filter / locations clause': r'^\s*(filter|locations)\b',
 'spin / loop (while, for)': r'\b(while|for)\s*\(',
}
rows = list(csv.DictReader(open(fcsv, encoding='utf-8')))
cnt = {k: [0, 0] for k in F}; tot = [0, 0]
none_rej = []
for r in rows:
    t = open(flat + '/' + r['file'], encoding='utf-8', errors='replace').read()
    t = re.sub(r'\(\*.*?\*\)', '', t, flags=re.S)
    i = 0 if r['support'] == 'SUPPORTED' else 1
    tot[i] += 1; hit = False
    for k, pat in F.items():
        if re.search(pat, t, re.M):
            cnt[k][i] += 1; hit = True
    if i == 1 and not hit: none_rej.append(r['file'])
with open(out, 'w', encoding='utf-8', newline='\n') as fo:
    fo.write(f'supported {tot[0]}, rejected {tot[1]}\nconstruct\tsupported_files\trejected_files\n')
    for k, (a, b) in cnt.items(): fo.write(f'{k}\t{a}\t{b}\n')
    fo.write(f'rejected files with none of these constructs: {len(none_rej)} (first: {none_rej[:8]})\n')
