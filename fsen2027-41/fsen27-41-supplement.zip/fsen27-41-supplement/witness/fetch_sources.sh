#!/usr/bin/env bash
# Fetch the two pinned sources (network). Not needed for the default check, only for FULL=1.
# Usage: bash fetch_sources.sh <dir>
set -euo pipefail
D="$1"; mkdir -p "$D"
S1_COMMIT=2f1be9ed9ae46f182ec50d0762b84451c91b41ac
S2_TAG=llvmorg-22.1.0
S2_COMMIT=4434dabb69916856b824f68a64b029c67175e532
[ -d "$D/s1-litmus" ] || git clone -q https://github.com/paulmckrcu/litmus.git "$D/s1-litmus" 2>/dev/null || true
git -C "$D/s1-litmus" cat-file -e "$S1_COMMIT^{commit}"
[ -d "$D/s2-llvm" ] || git clone -q --depth 1 --branch "$S2_TAG" --filter=blob:none --sparse \
  https://github.com/llvm/llvm-project.git "$D/s2-llvm"
git -C "$D/s2-llvm" sparse-checkout set llvm/test/Transforms/InstCombine
[ "$(git -C "$D/s2-llvm" rev-parse HEAD)" = "$S2_COMMIT" ] || { echo "S2 commit mismatch" >&2; exit 2; }
echo "S1 $S1_COMMIT available; S2 $S2_COMMIT checked out"
