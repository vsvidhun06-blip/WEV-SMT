# Witness search: screening record (2026-11-09)

Protocol: `PROTOCOL.md` (written and saved before either source was fetched). Pins: `sources.txt`.
Labels: **upstream test** (file as published), **upstream fragment** (computation extracted from it),
**constructed** (ours). No result below is a "real-program verdict change".

## Counts

| Stage | S1: `paulmckrcu/litmus` @ `2f1be9ed` (LKMM litmus tests) | S2: `llvm-project` @ `llvmorg-22.1.0` (`4434dabb`), InstCombine tests |
|---|---|---|
| Files in source | 5,571 `*.litmus` | 1,767 `*.ll` (35,946 functions) |
| Excluded as historical-corpus duplicates | 1,066 (byte-identical or whitespace-identical to one of 12,268 corpus files) | n/a (no overlap with the litmus corpus) |
| Screened | 4,505 | 1,767 |
| Criterion 1 (multi-instruction load-to-store data path) | Prototype: 1,898 supported by mode C; 2 have any load-to-store data edge (both plain copies `WRITE_ONCE(*z, r1)`); 0 have a path through two or more assignments. Text screen (parser-independent): 33 files with a load-to-store data path, 1 through two or more assignments | 344 functions with a load and a store; 59 load-to-store paths through two or more pure instructions, in 18 functions |
| Criterion 2 (S2: expected output drops the dependence) | n/a | 1 function (`and-or-icmps.ll`, `@simplify_before_foldAndOfICmps`) |
| Criterion 3 (S2: fold valid under wrap-around, ops in grammar) | n/a | 0 (the fold relies on undef loads from an uninitialised `alloca`) |
| **Eligible** | **0** | **0** |
| Edge changes B to C / tool-answer changes / verdict changes | 0 / 0 / 0 (all 1,898 supported files: A = B = C; 1,892 allowed, 6 forbidden, all by every mode and by NODEP) | none run (no eligible candidate; no harness constructed) |

Mode C rejections in S1 (2,607, all `PARSE_ERROR` in the prototype's manifest). Constructs present, by the
feature tally in `s1/recorded/s1-features.txt` (a file can have several): RCU/SRCU primitives 1,046,
`if` 785, locks 224, plain `*p` accesses 202, RMW 32,
disjunctive/negated `exists` 34, `filter`/`locations` 41, none of these 318 (e.g. pointer-valued initial state
`x2=y2`). `smp_load_acquire`/`smp_store_release` occur in 1,112 rejected and 1,869 supported files, so they are
not themselves a rejection cause. The rejected files are not eligible under the protocol, which lets the prototype's support manifest
decide; the parser-independent text screen was added so that a rejected file with a qualifying path would
still be named. It found one, below.

## Candidate table (every file or function that passed any criterion, with outcome)

| # | Source, path, lines | Provenance | Load → definitions → store | Width / sign / overflow / path cond. | Outcome and reason |
|---|---|---|---|---|---|
| 1 | S1 `manual/oota/C-JO-OOTA-4.litmus`, P0 (and P1, symmetric). Purpose (file comment): an OOTA test LKMM forbids ("which might be a surprise"), from an LKML thread | upstream test | `r1 = READ_ONCE(*x)`; `smp_rmb()`; `r2 = *b` (plain load); `r3 = r1 == 0`; `WRITE_ONCE(*a, (r3 + 1) & r2)` | `int` (32-bit signed); no overflow possible (`r3+1 ∈ {1,2}`); straight-line | **Not eligible**: the prototype rejects the file (`PARSE_ERROR`; the manifest gives no finer reason, and three progressively simplified copies, with the plain loads made `READ_ONCE`, the `int` declarations and then the fences removed, are still rejected, so the cause was not narrowed; workspace `witness/probe-jo/`). Hand + Z3 (32 and 64 bit, `s1-jo-oota4.out`): the store's label `((L1==0)+1) & L2` varies in L1 with L2 fixed and in L2 with L1 fixed. Both edges are semantic, so B and C would agree: not a B-keeps/C-removes case |
| 2 | S2 `and-or-icmps.ll` lines 365–403, `@simplify_before_foldAndOfICmps`. Purpose: fuzzer-derived regression test (no crash, simplification before `foldAndOfICmps`) | upstream test | `%L7 = load %A8`, `%L = load %G4`, `%L2 = load %G4` → `%B11 = udiv %L7, -1`, `%C10 = icmp ugt %L, %B11`, `%B20 = and %L7, %L2`, `%C7 = icmp slt %B20, 0`, `%C18 = icmp ule i1 %C10, %C7` → `store i1 %C18, ptr %p`; expected output `store i1 true` | i16 loads, i1 store; `%A8` is an uninitialised `alloca`, so every load reads undef | **Not eligible** (criterion 3): Z3 (`s2-z3.out`) gives `C18 = true` at `L7 = L = 0xFFFF` and `false` at `L7 = 0x7FFE, L = 0x7FFF`, so the fold is not a wrap-around identity; it uses undef. 6 of its 9 paths also use `udiv`/`sdiv`/`srem` (outside the grammar). The other expected store (`%B33`) is removed as a dead store, not by a value fold |
| 3–9 | S2: `and-or-icmps.ll @simplify_before_foldAndOfICmps2`, `debugloc-bswap.ll @inflate`, `icmp-mul-zext.ll @PR33765`, `pr32686.ll @tinkywinky`, `shift.ll @ashr_out_of_range`, `@ashr_out_of_range_1`, `zext-or-icmp.ll @PR51762` | upstream tests | load reaches store through ≥ 2 pure instructions | various (i16–i177) | **Fail criterion 2**: the expected output still stores a value computed from the load (closest: `tinkywinky`, i8 load → `icmp`/`xor`/`zext`/`or` → i32 store, which InstCombine rewrites but keeps load-dependent) |
| 10–18 | S2: `2011-05-28-swapmulsub.ll @foo1/@foo2/@foo3`, `2012-05-28-select-hang.ll @func`, `2013-03-05-Combine-BitcastTy-Into-Alloca.ll @function`, `all-bits-shift.ll @main`, `known-bits.ll @pr97330`; no CHECK lines for the function: `2007-06-06-AshrSignBit.ll`, `bittest.ll`, `crash.ll @test13` | upstream tests | load reaches store through ≥ 2 pure instructions | various | **Fail criterion 2**: no expected store remains (stores to non-escaping allocas are removed together with their reloads, e.g. `swapmulsub`; the value still depends on the function argument), or the function has no CHECK lines |
| — | S1: 32 other files with a single-assignment load-to-store data path (`s1/recorded/s1-text.tsv`), e.g. `C-LB+mb+data`, `C-seqctr` (`r1 + 1`), `C-JanStancek-rwsem` (`r0 + 1`) | upstream tests | one assignment | — | **Fail criterion 1** (not multi-instruction); 30 of the 32 are also rejected by mode C |

## Closest examples and why they failed
- **C-JO-OOTA-4** is the only upstream computation in either source with a two-assignment load-to-store path in
  straight-line code. It is genuinely dependent on both loads, so no summary choice changes its edges.
- **`@simplify_before_foldAndOfICmps`** is the only expected output that drops a multi-instruction
  load-to-store dependence; it does so by exploiting undef, which the paper's semantics (every load returns
  some 32-bit value) does not have.

## Strongest result established
A negative one: in the two pinned sources, fixed in advance, no eligible computation exists on which mode B
keeps and mode C removes a load-to-store dependency, so no edge, tool answer or verdict changes. The sample was
not broadened after the result.
