"""Compile the constructed C11 relaxed-atomic sources with clang (zig cc) at -O0..-O3 for several targets and decide,
mechanically, for every relaxed atomic store in every function:
  * IR level (LLVM IR from the same invocation with -emit-llvm): which `load atomic` values the stored value
    syntactically depends on (transitive SSA def-use, through any instruction);
  * how many `load atomic` instructions each function still contains (detects reload elimination);
  * AArch64 asm level (aarch64 target only): for straight-line code, which ldr destination registers the str source
    register depends on (register dataflow over the instruction text; an unrecognised instruction is reported).
Prints one row per (source, target, level, function, store). No claim about legality is made from this output.
Usage: python -I sweep.py <python exe with ziglang> <src dir> <out dir>
"""
import os, re, subprocess, sys
py, srcd, outd = sys.argv[1:4]
os.makedirs(outd, exist_ok=True)
TARGETS = ['aarch64-linux-gnu', 'x86_64-linux-gnu', 'riscv64-linux-gnu', 'arm-linux-gnueabihf']
LEVELS = ['-O0', '-O1', '-O2', '-O3']


def cc(args):
    p = subprocess.run([py, '-m', 'ziglang', 'cc'] + args, capture_output=True, text=True)
    if p.returncode:
        raise SystemExit('cc failed: %s\n%s' % (' '.join(args), p.stderr[-2000:]))


def ir_funcs(text):
    out = {}
    for m in re.finditer(r'^define [^@]*@(\w+)\(.*?\{\n(.*?)^\}', text, re.S | re.M):
        out[m.group(1)] = [l.strip() for l in m.group(2).splitlines() if l.strip() and not l.strip().startswith('#dbg')]
    return out


def ir_deps(lines):
    """For each `store atomic`, the set of `load atomic` SSA names its value transitively uses."""
    defs, loads, rows = {}, [], []
    for l in lines:
        m = re.match(r'(%[\w.]+) = (.*)', l)
        if m:
            defs[m.group(1)] = m.group(2)
            if m.group(2).startswith('load atomic'):
                loads.append(m.group(1))

    def uses(v, seen):
        if v in seen or v not in defs:
            return set()
        seen.add(v)
        rhs = defs[v]
        if rhs.startswith('load atomic'):
            return {v}
        acc = set()
        for u in re.findall(r'%[\w.]+', re.sub(r'!\w+ !\d+', '', rhs)):
            acc |= uses(u, seen)
        return acc
    for l in lines:
        m = re.match(r'store atomic \w+ ([^,]+), ptr (@\w+|%[\w.]+)', l)
        if m:
            val, ptr = m.group(1).strip(), m.group(2)
            rows.append((ptr, val, sorted(uses(val, set())) if val.startswith('%') else []))
    return loads, rows


ALU = re.compile(r'(add|sub|eor|orr|and|mvn|neg|mov|lsl|lsr|asr|mul|orn|eon|bic)\s+(w\d+|x\d+),\s*(.*)')


def a64_funcs(text):
    out, cur = {}, None
    for l in text.splitlines():
        m = re.match(r'^(\w+):\s*(//.*)?$', l)
        if m and not l.startswith('.'):
            cur = m.group(1); out[cur] = []; continue
        s = re.sub(r'//.*', '', l).strip()
        if cur and s and not s.startswith('.') and not s.endswith(':'):
            out[cur].append(s)
    return out


def reg(r):
    return 'r' + r[1:] if re.match(r'[wx]\d+$', r) else r


def a64_deps(ins):
    """Register dataflow: taint[r] = set of ldr indices whose loaded value flows into r (value loads only, i.e.
    ldr whose base register was not itself produced by an adrp/:got: load chain)."""
    taint, addr, rows, unknown, k = {}, set(), [], [], 0
    for s in ins:
        if s.startswith('adrp'):
            addr.add(reg(s.split()[1].rstrip(','))); continue
        m = re.match(r'ldr\s+(w\d+|x\d+),\s*\[(x\d+)(?:,\s*:got_lo12:\w+)?\]', s)
        if m:
            d, b = reg(m.group(1)), reg(m.group(2))
            if ':got_lo12:' in s or b in addr:
                if ':got_lo12:' in s:
                    addr.add(d); taint.pop(d, None); continue
            k += 1; taint[d] = {k}; addr.discard(d); continue
        m = re.match(r'str\s+(w\d+|x\d+|wzr|xzr),\s*\[(x\d+)\]', s)
        if m:
            rows.append(('str', sorted(taint.get(reg(m.group(1)), set())))); continue
        m = ALU.match(s)
        if m:
            d = reg(m.group(2))
            srcs = [reg(x) for x in re.findall(r'\b[wx]\d+\b', m.group(3))]
            t = set()
            for x in srcs:
                t |= taint.get(x, set())
            taint[d] = t; addr.discard(d); continue
        if s.startswith('ret') or s.startswith('stp') or s.startswith('ldp') or s.startswith('dmb'):
            continue
        unknown.append(s)
    return k, rows, unknown


print('%-22s %-20s %-4s %-12s %-30s %s' % ('source', 'target', 'lvl', 'function', 'IR: store <- atomic loads', 'notes'))
for src in sorted(f for f in os.listdir(srcd) if f.endswith('.c')):
    for tgt in TARGETS:
        for lv in LEVELS:
            base = os.path.join(outd, '%s.%s%s' % (src[:-2], tgt.split('-')[0], lv))
            common = ['-target', tgt, lv, '-g0', '-fno-asynchronous-unwind-tables']
            cc(common + ['-S', '-emit-llvm', '-o', base + '.ll', os.path.join(srcd, src)])
            cc(common + ['-S', '-o', base + '.s', os.path.join(srcd, src)])
            fs = ir_funcs(open(base + '.ll', encoding='utf-8').read())
            a64 = a64_funcs(open(base + '.s', encoding='utf-8').read()) if tgt.startswith('aarch64') else {}
            for fn, lines in fs.items():
                loads, rows = ir_deps(lines)
                note = 'atomic loads=%d' % len(loads)
                if fn in a64 and lv != '-O0':
                    k, arows, unk = a64_deps(a64[fn])
                    note += ' | a64 ldr=%d str<-ldr%s' % (k, [r[1] for r in arows])
                    if unk:
                        note += ' unrecognised:%s' % unk[:3]
                for ptr, val, deps in rows:
                    print('%-22s %-20s %-4s %-12s %-30s %s' % (src, tgt, lv, fn, '%s:=%s <- %s' % (ptr, val, deps or '-'), note))
