/* The four upstream InstCombine identities with every argument a relaxed load (constructed wrappers, C form).
   test26: (a+b)-b ; xor19: (a^b)^a ; test35: (~a)+a ; xor4: a^(~a). Disputed loads: b, a, a, a. */
#include <stdatomic.h>
atomic_uint a, b, x;
void w_test26(void){ unsigned A=atomic_load_explicit(&a,memory_order_relaxed), B=atomic_load_explicit(&b,memory_order_relaxed);
  unsigned C=A+B; unsigned D=C-B; atomic_store_explicit(&x,D,memory_order_relaxed); }
void w_xor19(void){ unsigned A=atomic_load_explicit(&a,memory_order_relaxed), B=atomic_load_explicit(&b,memory_order_relaxed);
  unsigned C=A^B; unsigned D=C^A; atomic_store_explicit(&x,D,memory_order_relaxed); }
void w_test35(void){ unsigned A=atomic_load_explicit(&a,memory_order_relaxed);
  unsigned N=A^0xFFFFFFFFu; unsigned D=N+A; atomic_store_explicit(&x,D,memory_order_relaxed); }
void w_xor4(void){ unsigned A=atomic_load_explicit(&a,memory_order_relaxed);
  unsigned N=0xFFFFFFFFu^A; unsigned D=A^N; atomic_store_explicit(&x,D,memory_order_relaxed); }
