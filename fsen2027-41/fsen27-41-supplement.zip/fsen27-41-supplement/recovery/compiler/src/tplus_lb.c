/* T+-LB (Table 3, LB-chain-cancel) as C11 relaxed atomics. Constructed. Each thread: r <- y; t := r+1;
   s := t-r; x := s (thread 1 with x,y swapped). Unsigned: wrap-around, no UB. Outcome of interest r0=r1=1. */
#include <stdatomic.h>
atomic_uint x, y;
unsigned r0, r1;
void thread0(void) {
  unsigned r = atomic_load_explicit(&y, memory_order_relaxed);
  unsigned t = r + 1u;
  unsigned s = t - r;
  atomic_store_explicit(&x, s, memory_order_relaxed);
  r0 = r;
}
void thread1(void) {
  unsigned r = atomic_load_explicit(&x, memory_order_relaxed);
  unsigned t = r + 1u;
  unsigned s = t - r;
  atomic_store_explicit(&y, s, memory_order_relaxed);
  r1 = r;
}
