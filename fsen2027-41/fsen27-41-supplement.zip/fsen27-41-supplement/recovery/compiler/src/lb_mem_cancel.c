/* LB-mem-cancel as C11 relaxed atomics. Constructed. Thread 0: r <- y; z := r+1; u <- z; x := u-r.
   Question: does the compiler replace the relaxed reload of z by the stored value (store-to-load forwarding)? */
#include <stdatomic.h>
atomic_uint x, y, z;
unsigned r0, r1;
void thread0(void) {
  unsigned r = atomic_load_explicit(&y, memory_order_relaxed);
  atomic_store_explicit(&z, r + 1u, memory_order_relaxed);
  unsigned u = atomic_load_explicit(&z, memory_order_relaxed);
  atomic_store_explicit(&x, u - r, memory_order_relaxed);
  r0 = r;
}
void thread1(void) {
  unsigned r = atomic_load_explicit(&x, memory_order_relaxed);
  atomic_store_explicit(&y, r, memory_order_relaxed);
  r1 = r;
}
