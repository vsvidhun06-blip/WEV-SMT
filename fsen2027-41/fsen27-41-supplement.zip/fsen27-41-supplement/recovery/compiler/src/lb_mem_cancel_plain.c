/* Control: the same thread 0 with the location z non-atomic (plain unsigned), everything else relaxed. */
#include <stdatomic.h>
atomic_uint x, y; unsigned z;
unsigned r0;
void thread0(void) {
  unsigned r = atomic_load_explicit(&y, memory_order_relaxed);
  z = r + 1u;
  unsigned u = z;
  atomic_store_explicit(&x, u - r, memory_order_relaxed);
  r0 = r;
}
