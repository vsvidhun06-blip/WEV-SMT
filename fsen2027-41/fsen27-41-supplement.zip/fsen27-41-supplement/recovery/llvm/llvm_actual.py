"""Actually execute LLVM's InstCombine on the post-review argument-to-return cases (recovery pass).

Driver: llvmlite's new-pass-manager binding (FunctionPassManager + InstCombinePass) of the bundled LLVM library.
This is the InstCombine pass of the reported LLVM version, executed in-process; it is NOT the `opt` binary, and
the pipeline is the single pass the tests' RUN line names (`-passes=instcombine`).
Two inputs per case: (I) the function alone, extracted verbatim (comment lines dropped); (W) the whole upstream
test file, as the RUN line feeds it, then the function is looked up.
For each case it prints the input body, the optimised body, the returned operand, which arguments the optimised
function still references, the CHECK lines, and a strict comparison of the optimised `ret` with the CHECK-NEXT
`ret` line (FileCheck variables [[X:%.*]] matched as a %name, literal text otherwise).
Usage: python -I llvm_actual.py <llvm-project checkout> <cases dir>
"""
import os, re, sys
import llvmlite, llvmlite.binding as llvm

src, cases = sys.argv[1], sys.argv[2]
CASES = [('add-test26', 'add.ll', 'test26', '%B'), ('xor-test19', 'xor.ll', 'test19', '%A'),
         ('add-test35', 'add.ll', 'test35', '%a'), ('xor-test4', 'xor.ll', 'test4', '%A'),
         ('apint-sub-test19', 'apint-sub.ll', 'test19', '%Y')]
llvm.initialize_native_target(); llvm.initialize_native_asmprinter()
tm = llvm.Target.from_default_triple().create_target_machine()


def instcombine(ir_text):
    mod = llvm.parse_assembly(ir_text); mod.verify()
    pb = llvm.create_pass_builder(tm, llvm.create_pipeline_tuning_options())
    fpm = llvm.create_new_function_pass_manager()
    fpm.add_instruction_combine_pass()
    for f in mod.functions:
        if not f.is_declaration:
            fpm.run(f, pb)
    mod.verify()
    return mod


def body(fn_text):
    return [l.rstrip() for l in fn_text.splitlines() if l.strip() and not l.lstrip().startswith(';')]


def check_ret(ret_line, check_lines):
    want = [c for c in check_lines if re.match(r';\s*CHECK-NEXT:\s*ret\b', c)]
    if not want:
        return 'no CHECK-NEXT ret line'
    pat = re.sub(r'^;\s*CHECK-NEXT:\s*', '', want[-1]).strip()
    rx = ''
    for tok in re.split(r'(\[\[[A-Za-z0-9_]+(?::[^\]]*)?\]\])', pat):
        rx += r'%[-\w.$]+' if tok.startswith('[[') else re.escape(tok)
    rx = re.sub(r'(\\ )+', r'\\s+', rx)
    return 'MATCH %r' % pat if re.fullmatch(rx, ret_line.strip()) else 'MISMATCH %r' % pat


print('llvmlite', llvmlite.__version__, 'LLVM', '.'.join(map(str, llvm.llvm_version_info)))
print('pipeline: FunctionPassManager[InstCombinePass] (llvmlite new-PM binding); triple', llvm.get_default_triple())
for cid, fn, name, disputed in CASES:
    up = open(os.path.join(cases, cid, 'upstream.ll'), encoding='utf-8').read()
    fsrc = up[up.index('define '):]
    checks = [l.strip() for l in fsrc.splitlines() if 'CHECK' in l]
    whole = open(os.path.join(src, 'llvm', 'test', 'Transforms', 'InstCombine', fn), encoding='utf-8').read()
    print('\n=== %s  (%s @%s; disputed argument %s)' % (cid, fn, name, disputed))
    print('  input body:'); [print('    ' + l) for l in body(fsrc)]
    print('  CHECK lines:'); [print('    ' + c) for c in checks]
    for label, text in (('I function alone', '\n'.join(body(fsrc)) + '\n'), ('W whole upstream file', whole)):
        try:
            mod = instcombine(text)
        except Exception as e:
            print('  [%s] could not run: %s' % (label, str(e).splitlines()[0][:160])); continue
        out = body(str(mod.get_function(name)))
        ret = [l for l in out if l.strip().startswith('ret ')][0]
        hdr = out[0]; args = re.findall(r'%[-\w.$]+', hdr[hdr.index('('):])
        used = [a for a in args if any(re.search(re.escape(a) + r'\b', l) for l in out[1:])]
        print('  [%s] optimised body:' % label); [print('    ' + l) for l in out]
        print('  [%s] returned: %s | arguments still referenced: %s | disputed %s referenced: %s | CHECK: %s' % (
            label, ret.strip(), used or 'none', disputed, disputed in used, check_ret(ret, checks)))
