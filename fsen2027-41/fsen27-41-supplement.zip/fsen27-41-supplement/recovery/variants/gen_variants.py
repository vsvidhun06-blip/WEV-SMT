"""Falsification variants of the compiled-code family (recovery pass; constructed). Rename locations and registers,
change the constant, swap operand order, mix patterns across threads, and extend to 3-thread rings.
Each thread: q <- READ(rd); temporaries; WRITE(wr, out). Expressions use R for the loaded register; every other
alphabetic token is a per-thread temporary. Usage: python -I gen_variants.py <outdir>"""
import os, re, sys
out = sys.argv[1]; os.makedirs(out + '/litmus', exist_ok=True); os.makedirs(out + '/c', exist_ok=True)
def ren(e, i):
    return ' '.join(('q%d' % i) if t == 'R' else (t + str(i)) if t.isalpha() else t for t in e.split())
def cren(e):
    return ' '.join('q' if t == 'R' else (t + 'u') if t.lstrip('-').isdigit() else t for t in e.split())
def lit(name, c, th):
    locs = sorted({t[0] for t in th} | {t[1] for t in th}); body = []
    for i, (rd, wr, steps) in enumerate(th):
        L = ['  q%d = READ_ONCE(*%s);' % (i, rd)] + ['  %s%d = %s;' % (d, i, ren(e, i)) for d, e in steps] + ['  WRITE_ONCE(*%s, out%d);' % (wr, i)]
        body.append('P%d(%s) {\n%s\n}\n' % (i, ', '.join('int *' + l for l in locs), '\n'.join(L)))
    ex = ' /\ '.join('%d:q%d=%d' % (i, i, c) for i in range(len(th)))
    return 'C VAR-%s\n(* recovery-pass falsification variant; constructed *)\n{ }\n\n%s\nexists (%s)\n' % (name, '\n'.join(body), ex)
def cf(name, c, th):
    locs = sorted({t[0] for t in th} | {t[1] for t in th}); fs = []
    for i, (rd, wr, steps) in enumerate(th):
        L = ['  unsigned q = atomic_load_explicit(&%s, memory_order_relaxed);' % rd] + ['  unsigned %s = %s;' % (d, cren(e)) for d, e in steps] + \
            ['  atomic_store_explicit(&%s, out, memory_order_relaxed);' % wr, '  g%d = q;' % i]
        fs.append('void thread%d(void) {\n%s\n}\n' % (i, '\n'.join(L)))
    return '/* VAR-%s: outcome all reads = %d */\n#include <stdatomic.h>\natomic_uint %s;\nunsigned %s;\n%s' % (name, c, ', '.join(locs), ', '.join('g%d' % i for i in range(len(th))), '\n'.join(fs))
AS = lambda k: [('k', 'R + %d' % k), ('out', 'k - R')]
SQ = [('k', 'R * R'), ('m', 'k - R'), ('n', 'm & 1'), ('out', 'n + 1')]
V = {
 'addsub-c7-renamed': (7, [('flag', 'data', AS(7)), ('data', 'flag', AS(7))]),
 'addsub-swapped-ops': (1, [('b', 'a', [('k', '1 + R'), ('out', 'k - R')]), ('a', 'b', [('k', '1 + R'), ('out', 'k - R')])]),
 'xorpair-c1000': (1000, [('y', 'x', [('k', 'R ^ 1000'), ('out', 'R ^ k')]), ('x', 'y', [('k', 'R ^ 1000'), ('out', 'R ^ k')])]),
 'mulmask-mixed': (1, [('y', 'x', [('k', 'R * 2'), ('m', 'k & 1'), ('out', 'm + 1')]), ('x', 'y', AS(1))]),
 'addsub-ring3': (1, [('z', 'x', AS(1)), ('x', 'y', AS(1)), ('y', 'z', AS(1))]),
 'sqminus-ring3': (1, [('z', 'x', SQ), ('x', 'y', SQ), ('y', 'z', SQ)]),
 'half-real': (1, [('y', 'x', AS(1)), ('x', 'y', [('k', 'R + R'), ('out', 'k - R')])]),
}
for n, (c, th) in V.items():
    open(out + '/litmus/VAR-%s.litmus' % n, 'w', newline='\n').write(lit(n, c, th))
    open(out + '/c/VAR-%s.c' % n, 'w', newline='\n').write(cf(n, c, th))
print(len(V), 'variants')
