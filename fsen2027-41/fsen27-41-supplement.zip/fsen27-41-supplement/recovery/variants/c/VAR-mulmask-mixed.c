/* VAR-mulmask-mixed: outcome all reads = 1 */
#include <stdatomic.h>
atomic_uint x, y;
unsigned g0, g1;
void thread0(void) {
  unsigned q = atomic_load_explicit(&y, memory_order_relaxed);
  unsigned k = q * 2u;
  unsigned m = k & 1u;
  unsigned out = m + 1u;
  atomic_store_explicit(&x, out, memory_order_relaxed);
  g0 = q;
}

void thread1(void) {
  unsigned q = atomic_load_explicit(&x, memory_order_relaxed);
  unsigned k = q + 1u;
  unsigned out = k - q;
  atomic_store_explicit(&y, out, memory_order_relaxed);
  g1 = q;
}
