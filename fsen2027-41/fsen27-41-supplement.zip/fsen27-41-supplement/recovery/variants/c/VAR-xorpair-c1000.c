/* VAR-xorpair-c1000: outcome all reads = 1000 */
#include <stdatomic.h>
atomic_uint x, y;
unsigned g0, g1;
void thread0(void) {
  unsigned q = atomic_load_explicit(&y, memory_order_relaxed);
  unsigned k = q ^ 1000u;
  unsigned out = q ^ k;
  atomic_store_explicit(&x, out, memory_order_relaxed);
  g0 = q;
}

void thread1(void) {
  unsigned q = atomic_load_explicit(&x, memory_order_relaxed);
  unsigned k = q ^ 1000u;
  unsigned out = q ^ k;
  atomic_store_explicit(&y, out, memory_order_relaxed);
  g1 = q;
}
