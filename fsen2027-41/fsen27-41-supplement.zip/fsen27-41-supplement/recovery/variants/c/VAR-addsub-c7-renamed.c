/* VAR-addsub-c7-renamed: outcome all reads = 7 */
#include <stdatomic.h>
atomic_uint data, flag;
unsigned g0, g1;
void thread0(void) {
  unsigned q = atomic_load_explicit(&flag, memory_order_relaxed);
  unsigned k = q + 7u;
  unsigned out = k - q;
  atomic_store_explicit(&data, out, memory_order_relaxed);
  g0 = q;
}

void thread1(void) {
  unsigned q = atomic_load_explicit(&data, memory_order_relaxed);
  unsigned k = q + 7u;
  unsigned out = k - q;
  atomic_store_explicit(&flag, out, memory_order_relaxed);
  g1 = q;
}
