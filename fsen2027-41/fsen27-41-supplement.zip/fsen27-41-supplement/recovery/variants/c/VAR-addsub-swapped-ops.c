/* VAR-addsub-swapped-ops: outcome all reads = 1 */
#include <stdatomic.h>
atomic_uint a, b;
unsigned g0, g1;
void thread0(void) {
  unsigned q = atomic_load_explicit(&b, memory_order_relaxed);
  unsigned k = 1u + q;
  unsigned out = k - q;
  atomic_store_explicit(&a, out, memory_order_relaxed);
  g0 = q;
}

void thread1(void) {
  unsigned q = atomic_load_explicit(&a, memory_order_relaxed);
  unsigned k = 1u + q;
  unsigned out = k - q;
  atomic_store_explicit(&b, out, memory_order_relaxed);
  g1 = q;
}
