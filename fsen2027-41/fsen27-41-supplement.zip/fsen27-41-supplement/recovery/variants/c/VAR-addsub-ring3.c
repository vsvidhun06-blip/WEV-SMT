/* VAR-addsub-ring3: outcome all reads = 1 */
#include <stdatomic.h>
atomic_uint x, y, z;
unsigned g0, g1, g2;
void thread0(void) {
  unsigned q = atomic_load_explicit(&z, memory_order_relaxed);
  unsigned k = q + 1u;
  unsigned out = k - q;
  atomic_store_explicit(&x, out, memory_order_relaxed);
  g0 = q;
}

void thread1(void) {
  unsigned q = atomic_load_explicit(&x, memory_order_relaxed);
  unsigned k = q + 1u;
  unsigned out = k - q;
  atomic_store_explicit(&y, out, memory_order_relaxed);
  g1 = q;
}

void thread2(void) {
  unsigned q = atomic_load_explicit(&y, memory_order_relaxed);
  unsigned k = q + 1u;
  unsigned out = k - q;
  atomic_store_explicit(&z, out, memory_order_relaxed);
  g2 = q;
}
