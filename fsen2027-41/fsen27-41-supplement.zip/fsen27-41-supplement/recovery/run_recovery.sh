#!/usr/bin/env bash
# Recovery pass (2026-11-09/10): compiled-code family, compiler sweep, InstCombine execution. Outside every paper total
# except the 'Compiled code' paragraph (Sec. 5) and App. D items that cite it.
# Steps:
#  1 regenerate the 17 family inputs from gen_family.py and require byte-identity with the shipped litmus/ and c/;
#  2 modes A/B/C (pinned corrected-v1 classes via the add-on driver) + the add-on's independent reference on them;
#    compare with recorded/;
#  3 [ZIGPY set] clang 20.1.2 (zig 0.15.2) sweep over family/c and compiler/src, -O0..-O3, 4 targets; compare;
#  3b [ZIGPY set] armcheck.py (independent Arm-model verdict from the AArch64 -O1..-O3 asm); compare;
#  4 check_family.py on the fresh outputs (sweep: fresh if step 3 ran, else recorded, and said so);
#  5 corruption test: four corrupted copies of the outputs must make check_family.py FAIL;
#  6 [LLVMPY and LLVM_SRC set] InstCombine (LLVM 22.1.0 via llvmlite 0.50.0) on the five argform functions; compare.
# Usage: PKGROOT=<base artifact> ADDON=<add-on root> WORK=<scratch> [ZIGPY=<python with ziglang==0.15.2>]
#        [LLVMPY=<python with llvmlite==0.50.0>] [LLVM_SRC=<llvm-project at llvmorg-22.1.0>] bash run_recovery.sh <outdir>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKGROOT:?}"; : "${ADDON:?}"; : "${WORK:?}"
OUT="$1"; mkdir -p "$OUT" "$WORK"; PY="${PYTHON:-python}"; rc=0
same() { diff -q --strip-trailing-cr "$1" "$2" > /dev/null; }
pass() { echo "PASS $*"; }; fail() { echo "FAIL $*"; rc=1; }
F="$HERE/family"
# 1
( cd "$OUT" && "$PY" -I "$F/gen_family.py" gen > /dev/null )
diff -r -q --strip-trailing-cr "$OUT/gen/litmus" "$F/litmus" > /dev/null && diff -r -q --strip-trailing-cr "$OUT/gen/c" "$F/c" > /dev/null \
  && same "$OUT/gen/family.tsv" "$F/family.tsv" && pass "family inputs regenerate byte-identically" || fail "family inputs differ"
# 2
PKGROOT="$PKGROOT" WORK="$WORK/c" bash "$ADDON/impl/run_composed.sh" "$OUT/composed" "$F/list.txt" "$F/litmus" > "$OUT/composed.log" 2>&1
"$PY" -I "$ADDON/refcheck/refcheck.py" "$OUT/composed" "$F/litmus" "$F/list.txt" "$OUT/ref" > "$OUT/ref.log" 2>&1
for p in "composed/files.csv files.csv" "composed/edges.csv edges.csv" "ref/ref-pairs.csv ref-pairs.csv" "ref/ref-files.csv ref-files.csv"; do
  set -- $p; same "$OUT/$1" "$F/recorded/$2" && pass "$2 identical to recorded" || fail "$2 differs from recorded"; done
# 3
SWEEP="$F/recorded/sweep.out"
if [ -n "${ZIGPY:-}" ]; then
  "$ZIGPY" -I "$HERE/compiler/sweep.py" "$ZIGPY" "$F/c" "$WORK/cc-family" > "$OUT/sweep-family.out"
  "$ZIGPY" -I "$HERE/compiler/sweep.py" "$ZIGPY" "$HERE/compiler/src" "$WORK/cc-src" > "$OUT/sweep-src.out"
  same "$OUT/sweep-family.out" "$F/recorded/sweep.out" && pass "family clang sweep identical to recorded" || fail "family clang sweep differs"
  same "$OUT/sweep-src.out" "$HERE/compiler/recorded/sweep.out" && pass "compiler/src clang sweep identical to recorded" || fail "compiler/src sweep differs"
  SWEEP="$OUT/sweep-family.out"
  # 3b independent Arm-model check (armcheck.py: own asm parser; ob = rfe U dob U bob on the LB candidate)
  for g in "family cc-family" "src cc-src"; do set -- $g
    "$PY" -I "$HERE/armcheck/armcheck.py" $(ls "$WORK/$2"/*.aarch64-O[123].s | sort) > "$OUT/armcheck-$1.out"
    same "$OUT/armcheck-$1.out" "$HERE/armcheck/recorded/armcheck-$1.out" && pass "armcheck $1 identical to recorded" || fail "armcheck $1 differs"; done
else echo "SKIP clang sweep and armcheck (ZIGPY unset); step 4 uses the RECORDED sweep"; fi
# 4
"$PY" -I "$F/check_family.py" "$F/family.tsv" "$OUT/composed/files.csv" "$OUT/ref/ref-pairs.csv" "$SWEEP" > "$OUT/check_family.out" || rc=1
tail -1 "$OUT/check_family.out"
# 5
T="$OUT/corrupt"; mkdir -p "$T"; n=0
corrupt() { # name, file-to-corrupt (files|ref|sweep), python expression on text
  cp "$OUT/composed/files.csv" "$T/files.csv"; cp "$OUT/ref/ref-pairs.csv" "$T/ref.csv"; cp "$SWEEP" "$T/sweep.out"
  "$PY" -I -c "import sys;p=sys.argv[1];s=open(p).read();s2=$3;assert s2!=s;open(p,'w').write(s2)" "$T/$2"
  if "$PY" -I "$F/check_family.py" "$F/family.tsv" "$T/files.csv" "$T/ref.csv" "$T/sweep.out" > "$T/$1.txt" 2>&1; then
    fail "corruption '$1' not detected"; else n=$((n+1)); fi; }
corrupt c-admits-control files.csv "s.replace('FAM-real-double.litmus,SUPPORTED,,2,0,R,F,F,F','FAM-real-double.litmus,SUPPORTED,,2,0,R,F,F,A')"
corrupt b-admits-cancel files.csv "s.replace('FAM-add-sub.litmus,SUPPORTED,,2,0,R,F,F,A','FAM-add-sub.litmus,SUPPORTED,,2,0,R,F,A,A')"
corrupt ref-disagrees ref.csv "s.replace(',AGREE',',DISAGREE',1)"
corrupt clang-keeps-addsub sweep.out "s.replace('@x:=1 <- -   ','@x:=%1 <- [%1]',1)"
[ "$n" = 4 ] && pass "corruption test: 4 of 4 corrupted copies rejected" || fail "corruption test: $n of 4 rejected"
# 5b falsification variants: regenerate, tool + reference, (ZIGPY) clang sweep; compare with recorded
VD="$HERE/variants"
( cd "$OUT" && "$PY" -I "$VD/gen_variants.py" vgen > /dev/null )
diff -r -q --strip-trailing-cr "$OUT/vgen/litmus" "$VD/litmus" > /dev/null && diff -r -q --strip-trailing-cr "$OUT/vgen/c" "$VD/c" > /dev/null   && pass "variant inputs regenerate byte-identically" || fail "variant inputs differ"
PKGROOT="$PKGROOT" WORK="$WORK/v" bash "$ADDON/impl/run_composed.sh" "$OUT/vcomposed" "$VD/list.txt" "$VD/litmus" > "$OUT/vcomposed.log" 2>&1
"$PY" -I "$ADDON/refcheck/refcheck.py" "$OUT/vcomposed" "$VD/litmus" "$VD/list.txt" "$OUT/vref" > "$OUT/vref.log" 2>&1
for p in "vcomposed/files.csv files.csv" "vcomposed/edges.csv edges.csv" "vref/ref-pairs.csv ref-pairs.csv" "vref/ref-files.csv ref-files.csv"; do
  set -- $p; same "$OUT/$1" "$VD/recorded/$2" && pass "variants $2 identical to recorded" || fail "variants $2 differs"; done
if [ -n "${ZIGPY:-}" ]; then
  "$ZIGPY" -I "$HERE/compiler/sweep.py" "$ZIGPY" "$VD/c" "$WORK/cc-var" > "$OUT/sweep-var.out"
  same "$OUT/sweep-var.out" "$VD/recorded/sweep.out" && pass "variants clang sweep identical to recorded" || fail "variants sweep differs"
  "$PY" -I "$HERE/armcheck/armcheck.py" $(ls "$WORK/cc-var"/*.aarch64-O[123].s | sort) > "$OUT/armcheck-var.out"
  same "$OUT/armcheck-var.out" "$HERE/armcheck/recorded/armcheck-var.out" && pass "armcheck variants identical to recorded" || fail "armcheck variants differs"
fi
# 6
if [ -n "${LLVMPY:-}" ] && [ -n "${LLVM_SRC:-}" ]; then
  "$LLVMPY" -I "$HERE/llvm/llvm_actual.py" "$LLVM_SRC" "$HERE/../argform/cases" > "$OUT/llvm_actual.out" 2>&1
  same "$OUT/llvm_actual.out" "$HERE/llvm/recorded/llvm_actual.out" && pass "InstCombine run identical to recorded" || fail "InstCombine output differs"
else echo "SKIP InstCombine run (LLVMPY or LLVM_SRC unset)"; fi
# 7 [ISABELLE_HOME set] build WEV_SMT_Rec (formal/; corollary-level) against the base and add-on sessions
if [ -n "${ISABELLE_HOME:-}" ]; then
  conv() { printf '%s' "$1" | sed -E 's#^/([a-zA-Z])/#/cygdrive/\1/#'; }
  FD="$OUT/formal"; rm -rf "$FD"; cp -r "$HERE/formal" "$FD"; rm -rf "$FD/recorded"
  if MSYS2_ENV_CONV_EXCL=USER_HOME "$ISABELLE_HOME/contrib/cygwin/bin/bash.exe" --login -c \
       "cd $(conv "$FD") && $(conv "$ISABELLE_HOME")/bin/isabelle build -c -o timeout=480 -d $(conv "$PKGROOT/isabelle") -d $(conv "$ADDON/formal") -d . WEV_SMT_Rec" > "$OUT/isabelle.log" 2>&1 \
     && same "$FD/REC-CHECK-RESULT.txt" "$HERE/formal/recorded/REC-CHECK-RESULT.txt" \
     && ! grep -n -E '^[[:space:]]*(sorry|oops|axiomatization)\b|by[[:space:]]+sorry' "$FD"/*.thy; then
    pass "Isabelle WEV_SMT_Rec builds; no oracles; no sorry"; else fail "Isabelle WEV_SMT_Rec"; fi
else echo "SKIP Isabelle (ISABELLE_HOME unset)"; fi
[ $rc = 0 ] && echo "RECOVERY RESULT: PASS" || echo "RECOVERY RESULT: FAIL"
exit $rc
