"""Independent Arm-verdict check for the compiled LB programs (resumed recovery pass, 2026-11-10).

Written separately from compiler/sweep.py (different parser, different dependency computation). For each AArch64
assembly file it:
  1. parses thread0..threadN, resolving each address register to a global through adrp/ldr-:got: pairs;
  2. computes, per instruction, the set of shared-location loads its value depends on (data) and that its address
     depends on (addr), and records any branch (ctrl), barrier, acquire or release instruction;
  3. builds the LB candidate execution (each thread's shared read reads-from the other thread's shared write) and
     checks acyclicity of ob = rfe U dob U bob as in the Arm architecture model (armv8.cat; Alglave et al. 2021):
     dob here = addr U data U ctrl;[W] from the read to the write; bob = any dmb/dsb or acquire/release in between.
Verdict ALLOWED iff ob is acyclic on that candidate. Only the shared locations (x, y, and z/w where present) count;
the plain result variables r0/r1/r2 are excluded. Usage: python -I armcheck.py <asm>... > out
"""
import re, sys

SHARED = {'x', 'y', 'z', 'w', 'v'}
BRANCH = re.compile(r'^(b\.\w+|cbz|cbnz|tbz|tbnz|br|blr|bl)$')
ORDER = re.compile(r'^(dmb|dsb|isb|ldar\w*|ldapr\w*|stlr\w*|ldaxr\w*|stlxr\w*|ldxr\w*|stxr\w*|cas\w*|swp\w*|ldadd\w*)$')


def reg(r):
    r = r.strip()
    m = re.fullmatch(r'[wx](\d+|zr)', r)
    return ('r' + m.group(1)) if m else None


def threads(text):
    out, cur = {}, None
    for line in text.splitlines():
        m = re.match(r'^(thread\d+):', line)
        if m:
            cur = m.group(1); out[cur] = []; continue
        if cur is None:
            continue
        s = line.split('//')[0].strip()
        if not s or s.startswith('.'):
            continue
        if re.match(r'^\.?L\w*:', s):
            continue
        out[cur].append(s)
        if s == 'ret':
            cur = None
    return out


def analyse(ins):
    sym = {}            # register -> global symbol whose address it holds
    taint = {}          # register -> set of shared-load event ids its value depends on
    events, ctrl, order_seen = [], set(), []
    for k, s in enumerate(ins):
        op, _, rest = s.partition(' ' if ' ' in s else '\t')
        op = s.split()[0]; args = s[len(op):].strip()
        ops = [a.strip() for a in re.split(r',(?![^\[]*\])', args)] if args else []
        if ORDER.match(op):
            order_seen.append((k, op))
        if BRANCH.match(op):
            ctrl |= set().union(*[taint.get(reg(a), set()) for a in ops if reg(a)]) if ops else set()
            order_seen.append((k, 'branch:' + op))
            continue
        if op == 'adrp':
            m = re.search(r':got:(\w+)', ops[1]) or re.fullmatch(r'(\w+)', ops[1])
            sym[reg(ops[0])] = ('got', m.group(1)); taint[reg(ops[0])] = set(); continue
        if op in ('ldr', 'str') and len(ops) == 2:
            m = re.fullmatch(r'\[(\w+)(?:,\s*(.+))?\]', ops[1])
            base, off = reg(m.group(1)), (m.group(2) or '')
            if op == 'ldr' and ':got_lo12:' in off:      # address of a global: constant GOT entry
                sym[reg(ops[0])] = ('addr', off.split(':got_lo12:')[1]); taint[reg(ops[0])] = set(); continue
            b = sym.get(base)
            loc = b[1] if b and b[0] == 'addr' else None
            addr_dep = set(taint.get(base, set()))
            if op == 'ldr':
                eid = len(events)
                events.append(('R', loc, set(), addr_dep, k))
                taint[reg(ops[0])] = {eid} if loc in SHARED else set()
                sym.pop(reg(ops[0]), None)
            else:
                events.append(('W', loc, set(taint.get(reg(ops[0]), set())), addr_dep, k))
            continue
        if op == 'ret':
            continue
        # generic ALU: dst := f(sources)
        if ops and reg(ops[0]):
            src = set()
            for a in ops[1:]:
                for r in re.findall(r'\b[wx]\d+\b', a):
                    src |= taint.get(reg(r), set())
            taint[reg(ops[0])] = src
            sym.pop(reg(ops[0]), None)
    return events, ctrl, order_seen


def verdict(path):
    th = threads(open(path, encoding='utf-8').read())
    per = {}
    for name, ins in sorted(th.items()):
        ev, ctrl, order = analyse(ins)
        sh = [e for e in ev if e[1] in SHARED]
        reads = [i for i, e in enumerate(ev) if e[0] == 'R' and e[1] in SHARED]
        writes = [i for i, e in enumerate(ev) if e[0] == 'W' and e[1] in SHARED]
        per[name] = (ev, ctrl, order, reads, writes)
    # LB candidate: a read of a location written by ANOTHER thread reads from that thread (rfe); a read of a
    # location only this thread writes reads from the po-latest earlier write (rfi). The cycle needs, in every
    # thread, an ob path from an rfe-read to a write some other thread reads. Intra-thread ob here:
    # dob = addr U data U ctrl;[W] U (addr U data);rfi ; bob = any ordering instruction between the two events.
    locs_r = {n: {per[n][0][i][1] for i in per[n][3]} for n in per}
    locs_w = {n: {per[n][0][i][1] for i in per[n][4]} for n in per}
    edge = {}
    for name, (ev, ctrl, order, reads, writes) in per.items():
        others_w = set().union(*[locs_w[m] for m in per if m != name]) if len(per) > 1 else set()
        others_r = set().union(*[locs_r[m] for m in per if m != name]) if len(per) > 1 else set()
        ext_r = [r for r in reads if ev[r][1] in others_w]
        ext_w = [w for w in writes if ev[w][1] in others_r]
        succ = {i: set() for i in range(len(ev))}
        for j, e in enumerate(ev):
            for i in e[2] | e[3]:
                succ[i].add(j)                                   # data / addr
            if e[0] == 'W':
                succ.update({i: succ[i] | {j} for i in ctrl if ev[i][4] < e[4]})   # ctrl;[W]
            if e[0] == 'R' and e[1] not in others_w:             # internal read: rfi from po-latest write
                prior = [k for k, f in enumerate(ev) if f[0] == 'W' and f[1] == e[1] and f[4] < e[4]]
                if prior:
                    wsrc = prior[-1]
                    for i in ev[wsrc][2] | ev[wsrc][3]:
                        succ[i].add(j)                           # (addr|data);rfi
        for a in range(len(ev)):
            for b in range(len(ev)):
                if ev[a][0] == 'R' and ev[a][4] < ev[b][4] and any(ev[a][4] < k < ev[b][4] for k, _ in order):
                    succ[a].add(b)                               # bob (conservative: any ordering insn)
        def reach(s):
            seen, st = set(), [s]
            while st:
                u = st.pop()
                for v in succ[u]:
                    if v not in seen:
                        seen.add(v); st.append(v)
            return seen
        edge[name] = any(w in reach(r) for r in ext_r for w in ext_w)
    allowed = not all(edge.values())     # the LB cycle needs an ob edge in every thread (rfe supplies the rest)
    shape = {n: [(e[0], e[1]) for e in per[n][0] if e[1] in SHARED] for n in per}
    return allowed, edge, shape, {n: per[n][2] for n in per}


if __name__ == '__main__':
    print('file\tverdict\tintra_thread_ob_edge\tshared_events\tordering_insns')
    for p in sys.argv[1:]:
        a, e, sh, o = verdict(p)
        print('%s\t%s\t%s\t%s\t%s' % (p.replace('\\', '/').split('/')[-1], 'ALLOWED' if a else 'FORBIDDEN',
              ','.join('%s=%d' % (k, v) for k, v in sorted(e.items())),
              ';'.join('%s:%s' % (k, ' '.join(t + (l or '?') for t, l in v)) for k, v in sorted(sh.items())),
              sum(len(v) for v in o.values())))
