(* Recovery pass (resumed 2026-11-10). No axioms, no sorry, no oracles beyond the HOL kernel (checked by Rec_Check).

   COROLLARY-LEVEL, stated as such. Program-level dependence (prog_dep) and event-level semantic dependence
   (esdep, Thm. 7 of the paper) are invariant under every rewrite that preserves the relevant values -- in
   particular under any register-level fold a compiler may perform (e.g. InstCombine's (x+1)-x ~> 1). Both
   chaining relations built from EXACT per-instruction non-constancy -- the version-aware closure vdep (Cousot's
   ordered composition) and the flow-insensitive closure trancl(sites) -- are not: on the cancellation program
   and its fold, which compute the same value, they relate x to y before the fold and not after.

   This formalises why a criterion using composed labels gives the same verdict before and after such a fold,
   and a criterion using either closure need not. It adds no new information-theoretic content beyond Thm. 3
   (exact codes refine the denotation). *)
theory PwT_Invariance
  imports WEV_SMT_Rev.PwT_Versioned WEV_SMT_PwT.PwT_EventBridge
begin

section \<open>Program level\<close>

lemma prog_dep_invariant:
  assumes "\<And>s. run P s y = run P' s y"
  shows "prog_dep P x y \<longleftrightarrow> prog_dep P' x y"
  using assms by (simp add: prog_dep_def)

definition foldP :: "reg \<Rightarrow> reg \<Rightarrow> reg \<Rightarrow> prog" where
  "foldP x t y = [(t, EBin OAdd (EReg x) (ENum 1)), (y, ENum 1)]"

lemma foldP_run: "run (foldP x t y) s y = 1"
  by (simp add: foldP_def)

lemma cancel_fold_same_value:
  assumes "x \<noteq> t" shows "run (cancelP x t y) s y = run (foldP x t y) s y"
  using cancelP_run[OF assms] foldP_run by simp

lemma nc_sub_right:
  assumes xt: "x \<noteq> t" shows "non_constant (EBin OSub (EReg t) (EReg x)) x"
  unfolding non_constant_def
proof (intro exI)
  show "eval (EBin OSub (EReg t) (EReg x)) ((\<lambda>_. 0)(x := 0)) \<noteq>
        eval (EBin OSub (EReg t) (EReg x)) ((\<lambda>_. 0)(x := 1))"
    using xt by simp
qed

lemma vdep_cancelP:
  assumes xt: "x \<noteq> t" shows "x \<in> vdep (cancelP x t y) y"
proof -
  have inner: "vdep [(y, EBin OSub (EReg t) (EReg x))] y = {r. non_constant (EBin OSub (EReg t) (EReg x)) r}"
    by simp
  have w: "x \<in> vdep [(y, EBin OSub (EReg t) (EReg x))] y"
    using inner nc_sub_right[OF xt] by simp
  have step: "x \<in> (if x = t then {r. non_constant (EBin OAdd (EReg x) (ENum 1)) r} else {x})"
    using xt by simp
  have "vdep (cancelP x t y) y =
        (\<Union>w \<in> vdep [(y, EBin OSub (EReg t) (EReg x))] y.
           if w = t then {r. non_constant (EBin OAdd (EReg x) (ENum 1)) r} else {w})"
    by (simp only: cancelP_def vdep.simps(2))
  with w step show ?thesis by blast
qed

lemma nc_num_empty: "{r. non_constant (ENum w) r} = {}"
  by (simp add: non_constant_def)

lemma vdep_foldP: "x \<notin> vdep (foldP x t y) y"
proof -
  have a: "vdep [(y, ENum 1)] y = {}"
    unfolding vdep.simps nc_num_empty by simp
  have b: "vdep (foldP x t y) y =
           (\<Union>w \<in> vdep [(y, ENum 1)] y. if w = t then {r. non_constant (EBin OAdd (EReg x) (ENum 1)) r} else {w})"
    by (simp only: foldP_def vdep.simps(2))
  from a b show ?thesis by simp
qed

lemma sites_foldP: "sites (foldP x t y) \<subseteq> {(x, t)}"
  by (auto simp: sites_def foldP_def dest!: non_constant_imp_read)

lemma trancl_foldP:
  assumes ty: "t \<noteq> y" shows "(x, y) \<notin> trancl (sites (foldP x t y))"
proof
  assume "(x, y) \<in> trancl (sites (foldP x t y))"
  then obtain c where "(c, y) \<in> sites (foldP x t y)"
    by (cases rule: tranclE) blast+
  with sites_foldP have "y = t" by blast
  with ty show False by simp
qed

theorem closures_not_invariant:
  assumes xt: "x \<noteq> t" and ty: "t \<noteq> y"
  shows "(\<forall>s. run (cancelP x t y) s y = run (foldP x t y) s y)
       \<and> \<not> prog_dep (cancelP x t y) x y \<and> \<not> prog_dep (foldP x t y) x y
       \<and> x \<in> vdep (cancelP x t y) y \<and> x \<notin> vdep (foldP x t y) y
       \<and> (x, y) \<in> trancl (sites (cancelP x t y)) \<and> (x, y) \<notin> trancl (sites (foldP x t y))"
proof (intro conjI allI)
  fix s show "run (cancelP x t y) s y = run (foldP x t y) s y" by (rule cancel_fold_same_value[OF xt])
next
  show "\<not> prog_dep (cancelP x t y) x y" by (rule cancelP_no_prog_dep[OF xt])
next
  show "\<not> prog_dep (foldP x t y) x y" by (simp add: prog_dep_def foldP_run)
next
  show "x \<in> vdep (cancelP x t y) y" by (rule vdep_cancelP[OF xt])
next
  show "x \<notin> vdep (foldP x t y) y" by (rule vdep_foldP)
next
  show "(x, y) \<in> trancl (sites (cancelP x t y))" by (rule cancelP_sites_chain[OF xt ty])
next
  show "(x, y) \<notin> trancl (sites (foldP x t y))" by (rule trancl_foldP[OF ty])
qed

corollary closures_not_invariant_ex:
  "\<exists>P P' x y. (\<forall>s. run P s y = run P' s y) \<and> \<not> prog_dep P x y \<and> \<not> prog_dep P' x y
             \<and> x \<in> vdep P y \<and> x \<notin> vdep P' y"
proof -
  have "''x'' \<noteq> ''t''" "''t'' \<noteq> ''y''" by simp_all
  from closures_not_invariant[OF this] show ?thesis by blast
qed

section \<open>Event level (threads with loads and stores)\<close>

fun same_kind :: "tinstr \<Rightarrow> tinstr \<Rightarrow> bool" where
  "same_kind (Load _) (Load _) = True"
| "same_kind (Asgn _ _) (Asgn _ _) = True"
| "same_kind (Store _) (Store _) = True"
| "same_kind _ _ = False"

definition store_equiv :: "thread \<Rightarrow> thread \<Rightarrow> bool" where
  "store_equiv T T' \<longleftrightarrow> length T = length T' \<and> (\<forall>i < length T. same_kind (T ! i) (T' ! i)) \<and>
     (\<forall>j L s. is_store T j \<longrightarrow> store_val T j L s = store_val T' j L s)"

lemma same_kind_load: "same_kind a b \<Longrightarrow> (\<exists>r. a = Load r) \<longleftrightarrow> (\<exists>r. b = Load r)"
  by (cases a; cases b) auto

lemma same_kind_store: "same_kind a b \<Longrightarrow> (\<exists>r. a = Store r) \<longleftrightarrow> (\<exists>r. b = Store r)"
  by (cases a; cases b) auto

lemma store_equiv_is_load:
  assumes "store_equiv T T'" shows "is_load T i \<longleftrightarrow> is_load T' i"
proof -
  from assms have len: "length T = length T'"
    and k: "\<And>i. i < length T \<Longrightarrow> same_kind (T ! i) (T' ! i)" by (auto simp: store_equiv_def)
  show ?thesis
  proof (cases "i < length T")
    case True
    then show ?thesis using same_kind_load[OF k[OF True]] len by (simp add: is_load_def)
  next
    case False
    then show ?thesis using len by (simp add: is_load_def)
  qed
qed

lemma store_equiv_is_store:
  assumes "store_equiv T T'" shows "is_store T j \<longleftrightarrow> is_store T' j"
proof -
  from assms have len: "length T = length T'"
    and k: "\<And>i. i < length T \<Longrightarrow> same_kind (T ! i) (T' ! i)" by (auto simp: store_equiv_def)
  show ?thesis
  proof (cases "j < length T")
    case True
    then show ?thesis using same_kind_store[OF k[OF True]] len by (simp add: is_store_def)
  next
    case False
    then show ?thesis using len by (simp add: is_store_def)
  qed
qed

lemma store_equiv_legal:
  assumes "store_equiv T T'" shows "legal_pair T i j \<longleftrightarrow> legal_pair T' i j"
  using store_equiv_is_load[OF assms] store_equiv_is_store[OF assms] by (simp add: legal_pair_def)

theorem esdep_store_equiv:
  assumes eq: "store_equiv T T'" shows "esdep T i j \<longleftrightarrow> esdep T' i j"
proof (cases "legal_pair T i j")
  case True
  then have st: "is_store T j" by (simp add: legal_pair_def)
  have sv: "\<And>L s. store_val T j L s = store_val T' j L s"
    using eq st by (simp add: store_equiv_def)
  show ?thesis using True store_equiv_legal[OF eq] sv by (simp add: esdep_def)
next
  case False
  then show ?thesis using store_equiv_legal[OF eq] by (simp add: esdep_def)
qed

text \<open>The witness: T+ (one thread of LB-chain-cancel) and the thread clang emits after folding it.\<close>

definition Tplus :: thread where
  "Tplus = [Load ''r'', Asgn ''t'' (EBin OAdd (EReg ''r'') (ENum 1)),
            Asgn ''s'' (EBin OSub (EReg ''t'') (EReg ''r'')), Store ''s'']"

definition Tfold :: thread where
  "Tfold = [Load ''r'', Asgn ''t'' (EBin OAdd (EReg ''r'') (ENum 1)), Asgn ''s'' (ENum 1), Store ''s'']"

lemma length_T: "length Tplus = 4" "length Tfold = 4"
  by (simp_all add: Tplus_def Tfold_def)

lemma idx4: "(i::nat) < 4 \<Longrightarrow> i = 0 \<or> i = 1 \<or> i = 2 \<or> i = 3"
  by arith

lemma is_store_Tplus: "is_store Tplus j \<longleftrightarrow> j = 3"
proof
  assume "is_store Tplus j"
  then have j4: "j < 4" and st: "\<exists>r. Tplus ! j = Store r" by (simp_all add: is_store_def length_T)
  from j4 have "j = 0 \<or> j = 1 \<or> j = 2 \<or> j = 3" by (rule idx4)
  then show "j = 3" using st by (elim disjE) (simp_all add: Tplus_def)
next
  assume "j = 3" then show "is_store Tplus j" by (simp add: is_store_def Tplus_def)
qed

lemma store_val_Tplus: "store_val Tplus 3 L s = 1"
  by (simp add: store_val_def Tplus_def)

lemma store_val_Tfold: "store_val Tfold 3 L s = 1"
  by (simp add: store_val_def Tfold_def)

theorem tplus_fold_store_equiv: "store_equiv Tplus Tfold"
proof -
  have k: "same_kind (Tplus ! i) (Tfold ! i)" if "i < length Tplus" for i
    using idx4[of i] that by (auto simp: length_T Tplus_def Tfold_def)
  have v: "store_val Tplus j L s = store_val Tfold j L s" if "is_store Tplus j" for j L s
    using that is_store_Tplus store_val_Tplus store_val_Tfold by simp
  show ?thesis unfolding store_equiv_def using k v length_T by simp
qed

theorem tplus_fold_no_esdep: "\<not> esdep Tplus 0 3" "\<not> esdep Tfold 0 3"
  by (simp_all add: esdep_def store_val_Tplus store_val_Tfold)

end
