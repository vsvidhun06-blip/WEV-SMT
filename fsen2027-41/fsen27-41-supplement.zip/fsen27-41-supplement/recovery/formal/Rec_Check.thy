(* Oracle check for the recovery-pass facts (resumed 2026-11-10). *)
theory Rec_Check
  imports PwT_Invariance
begin
ML \<open>
  val thms = [@{thm prog_dep_invariant}, @{thm closures_not_invariant}, @{thm closures_not_invariant_ex},
              @{thm esdep_store_equiv}, @{thm tplus_fold_store_equiv}, @{thm tplus_fold_no_esdep(1)},
              @{thm tplus_fold_no_esdep(2)}];
  val ors = Thm_Deps.all_oracles thms;
  val out = Path.append (Resources.master_directory @{theory}) (Path.basic "REC-CHECK-RESULT.txt");
  val _ = File.write out ("oracles over " ^ string_of_int (length thms) ^ " theorems: " ^
            (if null ors then "none" else commas (map (#1 o #1) ors)) ^ "\n");
  val _ = if null ors then () else error "oracle found";
\<close>
end
