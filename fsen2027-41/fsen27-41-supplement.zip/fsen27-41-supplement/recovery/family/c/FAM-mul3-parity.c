/* FAM-mul3-parity: recovery-pass constructed family; outcome r0=r1=1. */
#include <stdatomic.h>
atomic_uint x, y;
unsigned r0, r1;
void thread0(void) {
  unsigned r = atomic_load_explicit(&y, memory_order_relaxed);
  unsigned t = r * 3u;
  unsigned u = t ^ r;
  unsigned v = u & 1u;
  unsigned s = v + 1u;
  atomic_store_explicit(&x, s, memory_order_relaxed);
  r0 = r;
}

void thread1(void) {
  unsigned r = atomic_load_explicit(&x, memory_order_relaxed);
  unsigned t = r * 3u;
  unsigned u = t ^ r;
  unsigned v = u & 1u;
  unsigned s = v + 1u;
  atomic_store_explicit(&y, s, memory_order_relaxed);
  r1 = r;
}
