"""Join mode verdicts (composed/files.csv), the reference (ref/ref-pairs.csv), and the clang sweep (sweep.out) for
the constructed family, and add an Arm-architecture verdict for the compiled AArch64 code.

Arm verdict (transcribed fragment, NOT herd7): for these two-thread programs whose compiled threads are each
`ldr` (relaxed load, plain LDR) then `str` (relaxed store, plain STR), with no barrier, acquire or release, the
candidate realising r0=r1=c has rf edges that are external (rfe), and the only po edges that the Arm external
ordering `ob` can contain are dependency edges (dob: addr/data/ctrl). So the cycle
ld y -po-> st x -rfe-> ld x -po-> st y -rfe-> ld y is in ob, and the outcome is forbidden, iff BOTH threads' str
depends on their ldr. Otherwise the candidate is ob-acyclic and the outcome is architecturally allowed, provided
the compiled store writes c (it does when the store is the constant c). This is the standard LB result for
AArch64 (LB allowed, LB+datas forbidden); the dependency facts are taken from the asm register dataflow.
Usage: python -I join.py
"""
import csv, collections, re
fam = {r['name']: r for r in csv.DictReader(open('family.tsv'), delimiter='\t')}
modes = {r['file'][4:-7]: r for r in csv.DictReader(open('composed/files.csv'))}
ref = collections.defaultdict(list)
for r in csv.DictReader(open('ref/ref-pairs.csv')):
    ref[r['file'][4:-7]].append(r)
cc = collections.defaultdict(dict)
for l in open('sweep.out'):
    if l.startswith('source'):
        continue
    p = l.split()
    name, tgt, lv, fn = p[0][4:-2], p[1].split('-')[0], p[2], p[3]
    dep = '<- -' not in l
    m = re.search(r'atomic loads=(\d+)', l)
    a64 = re.search(r"str<-ldr(\[.*?\]\])", l)
    cc[(name, lv)].setdefault(tgt, {})[fn] = (dep, int(m.group(1)), a64.group(1) if a64 else None,
                                                re.search(r'store atomic|:=(\S+)', l) and p[4].split(':=')[1].split()[0])
print('%-13s %-6s | A B C | ref(C) | clang -O1/-O2/-O3, 4 targets: stored value depends on load? | AArch64 -O2 str value | Arm verdict of compiled code (-O2)' % ('pattern', 'class'))
rows = []
for name in fam:
    m = modes[name]
    refv = sorted({r['ref32'] + ('' if r['agree'] == 'AGREE' else '!DISAGREE') for r in ref[name]})
    lvl = []
    for lv in ('-O1', '-O2', '-O3'):
        deps = {(t, f): v[0] for t, fs in cc[(name, lv)].items() for f, v in fs.items()}
        vals = set(deps.values())
        lvl.append('dep' if vals == {True} else 'NO-dep' if vals == {False} else 'mixed')
    a = cc[(name, '-O2')]['aarch64']
    both_dep = a['thread0'][0] and a['thread1'][0]
    stored = a['thread0'][3]
    asm = '%s|%s' % (a['thread0'][2], a['thread1'][2])
    arm = 'F (both data-dependent)' if both_dep else ('A (no dob edge; stores %s)' % stored)
    print('%-13s %-6s | %s %s %s | %-6s | %-28s | %-6s | %s' % (name, fam[name]['class'], m['weakest_A'], m['weakest_B'],
          m['weakest_C'], ','.join(refv), '/'.join(lvl), stored, arm + '  asm str<-ldr ' + asm))
    rows.append((name, fam[name]['class'], m['weakest_A'], m['weakest_B'], m['weakest_C'], '/'.join(lvl), stored, arm[0]))
with open('family-results.tsv', 'w', newline='\n') as o:
    o.write('pattern\tclass\tA\tB\tC\tclang_O1_O2_O3\taarch64_O2_stored\tarm_verdict_compiled\n')
    for r in rows:
        o.write('\t'.join(r) + '\n')
