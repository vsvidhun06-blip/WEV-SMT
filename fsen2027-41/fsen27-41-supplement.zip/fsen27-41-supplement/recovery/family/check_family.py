"""Assert the compiled-code claims of the recovery pass from the run outputs (not from recorded expectations of
the outputs). Exit 0 iff every claim holds; prints one PASS/FAIL line per claim.
Claims (paper, Sec. 5 'Compiled code' and App. D):
  C1 14 cancelling + 3 dependent patterns; Z3 (independent of the tool) finds every cancelling store constant and
     every control store non-constant.                                     [checked here with z3 over family.tsv]
  C2 every pattern is SUPPORTED and well-formed-reachable; modes A and B forbid all 17; NODEP admits all 17
     (so A/B's F is cause (D)); mode C admits the 14 cancelling and forbids the 3 controls.
  C3 the reference agrees with mode C on every load-store pair.
  C4 clang -O1..-O3, all 4 targets: the stored value is independent of the load for exactly 13 cancelling
     patterns (all except sq-minus) and depends on it for sq-minus and the 3 controls; consistent across levels/targets.
  C5 AArch64 -O2 asm register dataflow agrees with the IR verdict for every pattern (str of the shared store
     taint-free iff IR says independent).
  C6 composed labels forbid no outcome of a compiled program the Arm rule allows: for every pattern with
     C = F, both compiled AArch64 threads are data-dependent.
Usage: python -I check_family.py <family.tsv> <files.csv> <ref-pairs.csv> <sweep.out>
"""
import csv, re, sys, collections
import z3
fam_p, files_p, ref_p, sweep_p = sys.argv[1:5]
ok = True


def claim(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + (': ' + detail if detail else ''))
    ok = ok and bool(cond)


fam = list(csv.DictReader(open(fam_p), delimiter='\t'))
cancel = [r['name'] for r in fam if r['class'] == 'cancel']
real = [r['name'] for r in fam if r['class'] == 'real']
const = {}
for r in fam:
    x = z3.BitVec('r', 32); env = {'r': x}
    for st in r['steps'].split('; '):
        d, e = [q.strip() for q in st.split('=', 1)]
        env[d] = eval(e, {}, dict(env))
    s = z3.Solver(); y = z3.BitVec('y', 32)
    s.add(env['s'] != z3.substitute(env['s'], (x, y)))
    const[r['name']] = s.check() == z3.unsat
claim('C1 family size 14+3', len(cancel) == 14 and len(real) == 3, '%d cancelling, %d dependent' % (len(cancel), len(real)))
claim('C1 z3: cancelling constant, controls not', all(const[n] for n in cancel) and not any(const[n] for n in real))

files = {r['file'][4:-7]: r for r in csv.DictReader(open(files_p))}
claim('C2 all supported and reachable', all(files[n]['support'] == 'SUPPORTED' and files[n]['wf'] == 'R' for n in cancel + real))
claim('C2 A and B forbid all 17', all(files[n]['weakest_A'] == 'F' and files[n]['weakest_B'] == 'F' for n in cancel + real))
claim('C2 NODEP admits all 17 (cause D)', all(files[n]['weakest_NODEP'] == 'A' for n in cancel + real))
claim('C2 C admits cancelling, forbids controls', all(files[n]['weakest_C'] == 'A' for n in cancel) and all(files[n]['weakest_C'] == 'F' for n in real))

ref = list(csv.DictReader(open(ref_p)))
claim('C3 reference agrees on every pair', len(ref) == 2 * 17 and all(r['agree'] == 'AGREE' for r in ref), '%d pairs' % len(ref))

dep = collections.defaultdict(set); asm = {}
for l in open(sweep_p):
    if l.startswith('source'):
        continue
    p = l.split(); name, tgt, lv, fn = p[0][4:-2], p[1].split('-')[0], p[2], p[3]
    if lv == '-O0':
        continue
    dep[name].add('<- -' not in l)
    m = re.search(r"str<-ldr(\[.*?\]\])", l)
    if tgt == 'aarch64' and lv == '-O2' and m:
        asm[(name, fn)] = eval(m.group(1))
indep = sorted(n for n in dep if dep[n] == {False}); mixed = sorted(n for n in dep if len(dep[n]) > 1)
claim('C4 no level/target disagreement', not mixed, str(mixed))
claim('C4 clang removes the dependence in exactly 13 cancelling patterns',
      set(indep) == set(cancel) - {'sq-minus'}, 'independent: %d %s' % (len(indep), sorted(set(cancel) - set(indep))))
claim('C4 clang keeps it in sq-minus and the controls', all(dep[n] == {True} for n in real + ['sq-minus']))
# C5: the first str of each thread function is the shared atomic store (the second is r0/r1 := r)
c5 = all((asm[(n, f)][0] == []) == (n in indep) for n in cancel + real for f in ('thread0', 'thread1'))
claim('C5 AArch64 asm dataflow agrees with IR', c5)
c6 = all(asm[(n, 'thread0')][0] and asm[(n, 'thread1')][0] for n in cancel + real if files[n]['weakest_C'] == 'F')
claim('C6 C=F only where both compiled threads are data-dependent (Arm forbids)', c6)
print('FAMILY RESULT: ' + ('PASS' if ok else 'FAIL'))
sys.exit(0 if ok else 1)
