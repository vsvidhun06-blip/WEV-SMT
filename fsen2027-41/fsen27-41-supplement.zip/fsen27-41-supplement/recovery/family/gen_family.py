"""Generate the constructed 'compiled-composition' LB family (recovery pass; constructed, NOT upstream code).

Every test is LB: thread 0 reads y and stores f(r) to x; thread 1 reads x and stores f(r) to y; outcome
r0 = r1 = c, where c is the value f stores when f is constant (c != 0, so the outcome cannot be produced by the
initial values). f is a chain of >= 2 instructions in the paper's grammar (+ - * ^ & |; ~e written e ^ -1),
32-bit wrap-around. Each pattern is emitted twice from ONE definition: an LKMM C-litmus file (READ_ONCE/WRITE_ONCE)
for modes A/B/C, and a C11 file (atomic_uint, memory_order_relaxed, unsigned arithmetic) for clang.
Classes: 'cancel' (f constant: composed label constant), 'real' (f non-constant: genuine dependency; controls).
Usage: python -I gen_family.py <outdir>
"""
import os, sys
out = sys.argv[1]
os.makedirs(os.path.join(out, 'litmus'), exist_ok=True); os.makedirs(os.path.join(out, 'c'), exist_ok=True)

# name, class, constant c (outcome value), steps (each 'dst = expr' over r, earlier temporaries, decimal literals)
FAMILY = [
    ('add-sub',      'cancel', 1, ['t = r + 1', 's = t - r']),
    ('xor-pair',     'cancel', 5, ['t = r ^ 5', 's = t ^ r']),
    ('or-and',       'cancel', 1, ['t = r | 1', 's = t & 1']),
    ('mul-mask',     'cancel', 1, ['t = r * 2', 'u = t & 1', 's = u + 1']),
    ('not-add',      'cancel', 1, ['t = r ^ -1', 'u = t + r', 's = u + 2']),
    ('three-step',   'cancel', 1, ['t = r + r', 'u = t - r', 'v = u - r', 's = v + 1']),
    ('two-temps',    'cancel', 1, ['t = r * 3', 'u = r * 2', 'v = t - u', 'w = v - r', 's = w + 1']),
    ('and-or-mask',  'cancel', 1, ['t = r & 255', 'u = r & -256', 'v = t | u', 'w = v - r', 's = w + 1']),
    ('succ-xor-bit', 'cancel', 1, ['t = r + 1', 'u = t ^ r', 's = u & 1']),
    ('odd-square',   'cancel', 1, ['t = r | 1', 'u = t * t', 's = u & 1']),
    ('sq-minus',     'cancel', 1, ['t = r * r', 'u = t - r', 'v = u & 1', 's = v + 1']),
    ('mul3-parity',  'cancel', 1, ['t = r * 3', 'u = t ^ r', 'v = u & 1', 's = v + 1']),
    ('sq-bit1',      'cancel', 1, ['t = r * r', 'u = t & 2', 's = u + 1']),
    ('carry-parity', 'cancel', 1, ['t = r + r', 'u = t + r', 'v = u ^ r', 'w = v & 1', 's = w + 1']),
    ('real-double',  'real',   1, ['t = r + r', 's = t - r']),
    ('real-xor',     'real',   1, ['t = r ^ 5', 'u = t ^ 4', 's = u ^ 1']),
    ('real-mask',    'real',   1, ['t = r | 2', 's = t & 1']),
]


def lit_expr(e, tid):
    # rename variables per thread: r -> r<tid>, temporaries t -> t<tid> etc.
    toks = e.split()
    return ' '.join(t + str(tid) if t.isalpha() else t for t in toks)


def litmus(name, c, steps):
    th = []
    for tid, (rd, wr) in enumerate((('y', 'x'), ('x', 'y'))):
        body = ['  r%d = READ_ONCE(*%s);' % (tid, rd)]
        for s in steps:
            d, e = [p.strip() for p in s.split('=', 1)]
            body.append('  %s%d = %s;' % (d, tid, lit_expr(e, tid)))
        body.append('  WRITE_ONCE(*%s, s%d);' % (wr, tid))
        th.append('P%d(int *x, int *y) {\n%s\n}\n' % (tid, '\n'.join(body)))
    return ('C FAM-%s\n(* Recovery-pass constructed family (2026-11-09); NOT upstream code. *)\n{ }\n\n%s\n'
            'exists (0:r0=%d /\\ 1:r1=%d)\n' % (name, '\n'.join(th), c, c))


def cfile(name, c, steps):
    fs = []
    for tid, (rd, wr) in enumerate((('y', 'x'), ('x', 'y'))):
        body = ['  unsigned r = atomic_load_explicit(&%s, memory_order_relaxed);' % rd]
        for s in steps:
            d, e = [p.strip() for p in s.split('=', 1)]
            e = ' '.join(t + 'u' if t.lstrip('-').isdigit() else t for t in e.split())
            body.append('  unsigned %s = %s;' % (d, e))
        body.append('  atomic_store_explicit(&%s, s, memory_order_relaxed);' % wr)
        body.append('  r%d = r;' % tid)
        fs.append('void thread%d(void) {\n%s\n}\n' % (tid, '\n'.join(body)))
    return ('/* FAM-%s: recovery-pass constructed family; outcome r0=r1=%d. */\n#include <stdatomic.h>\n'
            'atomic_uint x, y;\nunsigned r0, r1;\n%s' % (name, c, '\n'.join(fs)))


with open(os.path.join(out, 'family.tsv'), 'w', newline='\n') as m:
    m.write('name\tclass\tc\tsteps\n')
    for name, cls, c, steps in FAMILY:
        open(os.path.join(out, 'litmus', 'FAM-%s.litmus' % name), 'w', newline='\n').write(litmus(name, c, steps))
        open(os.path.join(out, 'c', 'FAM-%s.c' % name), 'w', newline='\n').write(cfile(name, c, steps))
        m.write('%s\t%s\t%d\t%s\n' % (name, cls, c, '; '.join(steps)))
print(len(FAMILY), 'patterns')
