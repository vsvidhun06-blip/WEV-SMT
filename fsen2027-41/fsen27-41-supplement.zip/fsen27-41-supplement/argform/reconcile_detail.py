"""Detail for reconcile_counts.py.
(1) For each define line missed by the prespecified screen's FN regex, print the FN match that swallowed it
    (its start line and define line), i.e. the function whose header did not end in '{' at end of line.
(2) Replay the exploratory script's scanner (a define line opens a body; the body ends at the next line starting
    with '}') and print every define line it never visits (swallowed inside another body).
Usage: python -I reconcile_detail.py <InstCombine dir>
"""
import os, re, sys
root = sys.argv[1]
FN = re.compile(r'^define\b[^@]*@("?[\w.$-]+"?)\s*\(.*?\{\s*$(.*?)^\}', re.S | re.M)
DEF = re.compile(r'^define\b.*@([\w.$-]+)\s*\(')
for dp, _, fs in sorted(os.walk(root)):
    for fn in sorted(fs):
        if not fn.endswith('.ll'):
            continue
        p = os.path.join(dp, fn); rel = os.path.relpath(p, root).replace(os.sep, '/')
        text = open(p, encoding='utf-8', errors='replace').read(); lines = text.split('\n')
        spans = [(text.count('\n', 0, m.start()) + 1, text.count('\n', 0, m.end()) + 1) for m in FN.finditer(text)]
        starts = {s for s, _ in spans}
        for i, l in enumerate(lines, 1):
            if DEF.match(l) and i not in starts:
                host = [s for s, e in spans if s < i <= e]
                h = host[0] if host else None
                print('FN-merged %s:%d  swallowed by match starting at line %s: %s' % (
                    rel, i, h, lines[h - 1][:110] if h else '-'))
        # exploratory scanner replay
        i, visited = 0, set()
        while i < len(lines):
            if not DEF.match(lines[i]):
                i += 1; continue
            visited.add(i + 1); i += 1
            while i < len(lines) and not lines[i].startswith('}'):
                i += 1
        for j, l in enumerate(lines, 1):
            if DEF.match(l) and j not in visited:
                print('SCAN-swallowed %s:%d  %s' % (rel, j, l[:110]))
