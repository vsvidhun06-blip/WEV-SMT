# Function counts: prespecified screen 35,946 vs post-review script 35,953

Source: LLVM `llvmorg-22.1.0` (commit 4434dabb), `llvm/test/Transforms/InstCombine`, 1,767 `.ll` files.
Scripts: `reconcile_counts.py`, `reconcile_detail.py` (outputs `reconcile_counts.out`, `reconcile_detail.out`).

| Counting rule | Count |
|---|---|
| Every line matching `^define\b.*@name\s*\(` (one per textual definition) | **35,954** |
| Prespecified screen `s2_screen.py`: regex `^define…\{\s*$ (body) ^\}` (header must end in `{`; body ends at the first unindented `}`) | **35,946** (= 35,954 − 8) |
| Referee's exploratory `llvm_argform.py`: a `define` line opens a body that runs to the next line starting with `}` | **35,953** (= 35,954 − 1) |

## The 8 definitions the screen does not count separately
Six follow a header with text after `{`, so the regex's `\{\s*$` fails at that header and the match runs on,
absorbing the next function:

| Header defeating the regex | Function absorbed |
|---|---|
| `call.ll:68 define void @test3a(i8, ...) {unreachable }` | `call.ll:73 @test3` |
| `create-class-from-logic-fcmp.ll:1139 … @olt_infinity_and_finite(half %x) #0 { ; bustttedddd` | `:1151 @olt_infinity_or_ord` |
| `create-class-from-logic-fcmp.ll:1711 … @fabs_ueq_neginfinity_and_olt_smallest_normal … #0 { ; WRONG` | `:1723 @fabs_one_neginfinity_and_uge_smallest_normal` |
| `memmove.ll:29 define i32 @test3(ptr %target) { ; arg: ptr> [#uses=1]` | `memmove.ll:47 @test4` |
| `vec_demanded_elts.ll:612 … @gep_all_lanes_undef(…) {;` | `:625 @gep_demanded_lane_undef` |
| `vec_demanded_elts-inseltpoison.ll:609 … @gep_all_lanes_undef(…) {;` | `:622 @gep_demanded_lane_undef` |

Two are the last function of their file and close with an indented `  }`, so `^\}` never matches and the
function is not counted at all: `icmp-abs.ll:210 @icmp_sge_abs_mismatched_op`,
`select-of-symmetric-selects.ll:111 @select_of_symmetric_selects_vector3`.

## The 1 definition the exploratory script does not count
`call.ll:68 @test3a` is a one-line function (`{unreachable }`). Its scanner treats the next lines up to the next
`}` as its body, which is the whole of `call.ll:73 @test3`; `@test3` is never visited.

## Effect on reported numbers
None of the 8 functions contains a `load` or `store` (checked), so the screen's eligibility counts
(344 functions with a load and a store; 59 paths in 18 functions; 0 eligible) are unaffected.
The difference is a counting rule, fully attributed to the 9 sites above; no rate is computed from either
total. In the paper the total function count is not used as a denominator.
