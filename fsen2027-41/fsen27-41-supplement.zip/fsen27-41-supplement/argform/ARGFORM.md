# Post-review argument-to-return comparison (2026-11-09)

**Status: exploratory, added after review.** It is not part of the prespecified load-to-store search
(`../witness/PROTOCOL.md`), does not change that search's counts (S1 4,505 files / S2 1,767 files, 0 eligible), and
enters no paper total. The four functions were chosen by the referee (cold review 3), not by us, and all four are
reported; none was substituted.

## Why argument-to-return is in scope
Thm. 7(b) of the paper embeds a straight-line computation P as `Load a; P; Store b`: esdep holds between that load
and store iff prog_dep(P, a, b). An LLVM function whose arguments are i32 values and whose returned value is computed
by add/sub/xor is such a P with its arguments as initial registers. The wrappers in `inputs/` are this embedding,
**constructed by us**: each argument becomes an independent `READ_ONCE`, each instruction one assignment, the
returned value one `WRITE_ONCE`. They are not upstream tests.

## Cases (pinned `llvmorg-22.1.0`, commit `4434dabb`; verbatim function + CHECK lines in `cases/*/upstream.ll`)
| Case | IR (width i32; no nsw/nuw; no undef/poison) | Disputed argument | Other argument | Expected compiler output (CHECK) |
|---|---|---|---|---|
| `add.ll:769-776 @test26` | `%C = add %A,%B; %D = sub %C,%B; ret %D` | `%B` | `%A` (ret = A) | `ret i32 [[A]]` |
| `xor.ll:174-181 @test19` | `%C = xor %A,%B; %D = xor %C,%A; ret %D` | `%A` | `%B` (ret = B) | `ret i32 [[B]]` |
| `add.ll:919-926 @test35` | `%tmpnot = xor %a,-1; %tmp2 = add %tmpnot,%a; ret %tmp2` | `%a` | — (ret = −1) | `ret i32 -1` |
| `xor.ll:43-50 @test4` | `%NotA = xor -1,%A; %B = xor %A,%NotA; ret %B` | `%A` | — (ret = −1) | `ret i32 -1` |

Excluded from the 32-bit results: `apint-sub.ll:164-171 @test19` (i39; `(X−Y)+Y`). It is extracted and checked for
the record (Y CONST, X VARIES at 39 bits) only.

## Results
| Case | Mode B on disputed edge | Mode C on disputed edge | Independent IR check (disputed) | Other edge (C / IR) |
|---|---|---|---|---|
| add @test26 | kept | removed (CONST) | CONST (Z3 unsat; w8 exhaustive; 200k random) | VARIES / VARIES |
| xor @test19 | kept | removed (CONST) | CONST (Z3 unsat; w8 exhaustive; 200k random) | VARIES / VARIES |
| add @test35 | kept | removed (CONST) | CONST (Z3 unsat; exhaustive over all 2^32) | — |
| xor @test4 | kept | removed (CONST) | CONST (Z3 unsat; exhaustive over all 2^32) | — |

4 of 4: mode B (Boolean closure with exact local oracle) keeps the edge from the disputed argument's load to the
store, and mode C (composed labels) removes it; the add-on reference (`refcheck.py`) agrees on every pair; the IR-level
check `ir_check.py` (own parser and evaluator over the upstream text; shares no code with the prototype, the
reference or `semcheck.py`) finds the returned value constant in the disputed argument and non-constant in the other.
`semcheck.py` proves three of the four CONST verdicts by normalisation and corroborates @test35 by width-8 exhaustion
and a 32-bit search (`recorded/semcheck.out`). Modes A and B report no fake edge; mode C reports one per file. Every
wrapper's whole-program verdict is A in every mode (single thread; no cycle), so no weak-memory outcome differs.

## What is and is not shown
- Shown: an **analysis-edge difference** between B and C on four upstream i32 functions, with the absence of the
  dependence confirmed independently. The CHECK lines are read only as the test's expected compiler output; they
  agree with the computed denotations.
- Not shown: no compiler was executed (the CHECK lines were not regenerated); no weak-memory outcome changes; the
  four functions are referee-selected, so no rate or prevalence is implied.

## Regression test
`check_argform.py` requires the disputed edge to be kept by B and removed by C, the other edge to vary, the reference
and IR check to agree, and a mutant (`mutant/`, `d0 = c0 − r0`) to flip both edges. `test_check_argform.py` corrupts
copies of the fresh outputs (disputed edge C→VARIES, B→false, other edge →CONST, edge deleted, reference flipped, IR
verdict flipped, mutant unflipped, file unsupported) and requires each to fail and the genuine outputs to pass.

## Function counts
The prespecified screen counted 35,946 functions, the referee's script 35,953; `RECONCILIATION.md` attributes the
difference to 9 named definition sites (counting rules only; none of them has a load or store). No rate uses either
total.

## Run
`PKGROOT=… ADDON=… WORK=… bash run_argform.sh <outdir>` (≈1 min; numpy is optional and only adds the 2^32 exhaustion).
`FULL=1 bash ../check_supplement.sh` also re-extracts the cases from the fetched LLVM and recounts functions.
