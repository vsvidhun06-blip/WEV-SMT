; upstream test, extracted verbatim (not modified)
; repository: github.com/llvm/llvm-project  tag: llvmorg-22.1.0  commit: 4434dabb69916856b824f68a64b029c67175e532
; path: llvm/test/Transforms/InstCombine/apint-sub.ll  lines 164-171  function @test19
; sha256 of the whole upstream file: ce1b24b47e83485081f3cd373cb23b932d23459455f209d9a29ea7b93b51d6c0
; in the 32-bit results: no (i39; recorded only)
;   ; RUN: opt < %s -passes=instcombine -S | FileCheck %s

define i39 @test19(i39 %X, i39 %Y) {
; CHECK-LABEL: @test19(
; CHECK-NEXT:    ret i39 [[X:%.*]]
;
  %Z = sub i39 %X, %Y
  %Q = add i39 %Z, %Y
  ret i39 %Q
}
