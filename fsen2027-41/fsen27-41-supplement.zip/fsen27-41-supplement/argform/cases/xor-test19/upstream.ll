; upstream test, extracted verbatim (not modified)
; repository: github.com/llvm/llvm-project  tag: llvmorg-22.1.0  commit: 4434dabb69916856b824f68a64b029c67175e532
; path: llvm/test/Transforms/InstCombine/xor.ll  lines 174-181  function @test19
; sha256 of the whole upstream file: abb6407221fd11a5af4077cd90da7fb1edcd79bcbfdc90038b546accda5e3dc4
; in the 32-bit results: yes
;   ; RUN: opt < %s -passes=instcombine -S | FileCheck %s

define i32 @test19(i32 %A, i32 %B) {
; CHECK-LABEL: @test19(
; CHECK-NEXT:    ret i32 [[B:%.*]]
;
  %C = xor i32 %A, %B
  %D = xor i32 %C, %A
  ret i32 %D
}
