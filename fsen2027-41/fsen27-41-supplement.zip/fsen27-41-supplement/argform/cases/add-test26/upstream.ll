; upstream test, extracted verbatim (not modified)
; repository: github.com/llvm/llvm-project  tag: llvmorg-22.1.0  commit: 4434dabb69916856b824f68a64b029c67175e532
; path: llvm/test/Transforms/InstCombine/add.ll  lines 769-776  function @test26
; sha256 of the whole upstream file: 2d650095e14c85bb9561d9b29e461456bb1f2de6931f55dec1c9d179ac5edeec
; in the 32-bit results: yes
;   ; RUN: opt < %s -passes=instcombine -S | FileCheck %s
;   ; RUN: opt < %s -passes=instcombine -use-constant-int-for-fixed-length-splat -S | FileCheck %s

define i32 @test26(i32 %A, i32 %B) {
; CHECK-LABEL: @test26(
; CHECK-NEXT:    ret i32 [[A:%.*]]
;
  %C = add i32 %A, %B
  %D = sub i32 %C, %B
  ret i32 %D
}
