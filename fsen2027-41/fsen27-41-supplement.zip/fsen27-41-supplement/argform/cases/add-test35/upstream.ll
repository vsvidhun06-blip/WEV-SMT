; upstream test, extracted verbatim (not modified)
; repository: github.com/llvm/llvm-project  tag: llvmorg-22.1.0  commit: 4434dabb69916856b824f68a64b029c67175e532
; path: llvm/test/Transforms/InstCombine/add.ll  lines 919-926  function @test35
; sha256 of the whole upstream file: 2d650095e14c85bb9561d9b29e461456bb1f2de6931f55dec1c9d179ac5edeec
; in the 32-bit results: yes
;   ; RUN: opt < %s -passes=instcombine -S | FileCheck %s
;   ; RUN: opt < %s -passes=instcombine -use-constant-int-for-fixed-length-splat -S | FileCheck %s

define i32 @test35(i32 %a) {
; CHECK-LABEL: @test35(
; CHECK-NEXT:    ret i32 -1
;
  %tmpnot = xor i32 %a, -1
  %tmp2 = add i32 %tmpnot, %a
  ret i32 %tmp2
}
