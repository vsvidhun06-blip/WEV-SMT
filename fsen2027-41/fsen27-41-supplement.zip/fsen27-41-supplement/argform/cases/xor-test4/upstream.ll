; upstream test, extracted verbatim (not modified)
; repository: github.com/llvm/llvm-project  tag: llvmorg-22.1.0  commit: 4434dabb69916856b824f68a64b029c67175e532
; path: llvm/test/Transforms/InstCombine/xor.ll  lines 43-50  function @test4
; sha256 of the whole upstream file: abb6407221fd11a5af4077cd90da7fb1edcd79bcbfdc90038b546accda5e3dc4
; in the 32-bit results: yes
;   ; RUN: opt < %s -passes=instcombine -S | FileCheck %s

define i32 @test4(i32 %A) {
; CHECK-LABEL: @test4(
; CHECK-NEXT:    ret i32 -1
;
  %NotA = xor i32 -1, %A
  %B = xor i32 %A, %NotA
  ret i32 %B
}
