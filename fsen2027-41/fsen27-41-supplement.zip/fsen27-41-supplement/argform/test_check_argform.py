"""Regression test of the argument-to-return check: corrupt copies of the fresh outputs and require each
corruption to make check_argform.py fail; the genuine outputs must pass.
Usage: python -I test_check_argform.py <check_argform.py> <expected.tsv> <files.csv> <edges.csv> <ref-pairs.csv>
                                       <ir_check.out> <mutant edges.csv> <scratch dir>
"""
import csv, os, subprocess, sys
chk, exp, files, edges, refp, irp, mut, tmp = sys.argv[1:9]
os.makedirs(tmp, exist_ok=True)
PY = sys.executable


def run(e=exp, f=files, ed=edges, r=refp, i=irp, m=mut):
    """Return code of the checker. A crash (traceback, no RESULT line) counts as an error, not as a detected
    corruption, so a broken checker cannot make the corruption cases pass."""
    p = subprocess.run([PY, '-I', chk, e, f, ed, r, i, '--mutant', m], capture_output=True, text=True)
    if 'RESULT ' not in p.stdout or 'Traceback' in p.stderr:
        raise SystemExit('checker crashed:\n' + p.stdout[-800:] + p.stderr[-1500:])
    return p.returncode


def rewrite_csv(src, name, fn):
    rows = list(csv.DictReader(open(src, encoding='utf-8')))
    hdr = list(rows[0].keys())
    fn(rows)
    p = os.path.join(tmp, name)
    with open(p, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=hdr, lineterminator='\n'); w.writeheader(); w.writerows(rows)
    return p


def flip(rows, file, col, frm, to, which=None):
    hits = [r for r in rows if r['file'] == file and r[col] == frm]
    if which is not None:
        hits = [hits[which]]
    for r in hits:
        r[col] = to


cases = []
cases.append(('genuine outputs pass', run() == 0))
cases.append(('disputed edge add-test26: C CONST->VARIES fails', run(ed=rewrite_csv(
    edges, 'e1.csv', lambda rs: flip(rs, 'add-test26.litmus', 'composed', 'CONST', 'VARIES'))) != 0))
cases.append(('disputed edge xor-test4: B true->false fails', run(ed=rewrite_csv(
    edges, 'e2.csv', lambda rs: flip(rs, 'xor-test4.litmus', 'local_B_semantic', 'true', 'false'))) != 0))
cases.append(('other edge xor-test19: C VARIES->CONST fails', run(ed=rewrite_csv(
    edges, 'e3.csv', lambda rs: flip(rs, 'xor-test19.litmus', 'composed', 'VARIES', 'CONST'))) != 0))
cases.append(('disputed edge add-test35 deleted fails', run(ed=rewrite_csv(
    edges, 'e4.csv', lambda rs: rs.remove([r for r in rs if r['file'] == 'add-test35.litmus'][0]))) != 0))
cases.append(('reference disputed add-test26 CONST->VARIES fails', run(r=rewrite_csv(
    refp, 'r1.csv', lambda rs: flip(rs, 'add-test26.litmus', 'ref32', 'CONST', 'VARIES'))) != 0))
ir_bad = os.path.join(tmp, 'ir_bad.out')
txt = open(irp, encoding='utf-8').read()
open(ir_bad, 'w', encoding='utf-8', newline='\n').write(txt.replace('   %a   CONST', '   %a   VARIES', 1))
cases.append(('IR check add-test35 %a CONST->VARIES fails', run(i=ir_bad) != 0))
cases.append(('mutant not flipped fails', run(m=rewrite_csv(
    mut, 'm1.csv', lambda rs: [r.__setitem__('composed', 'CONST') for r in rs])) != 0))
cases.append(('file support removed fails', run(f=rewrite_csv(
    files, 'f1.csv', lambda rs: flip(rs, 'xor-test19.litmus', 'support', 'SUPPORTED', 'PARSE_ERROR'))) != 0))
bad = 0
for name, good in cases:
    print(('PASS ' if good else 'FAIL ') + name)
    bad += 0 if good else 1
print('%d failure(s) in %d cases' % (bad, len(cases)))
sys.exit(bad)
