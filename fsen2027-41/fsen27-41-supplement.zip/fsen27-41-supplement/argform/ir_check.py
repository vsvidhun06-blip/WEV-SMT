"""Independent IR-level dependence check for the argument-to-return cases.

Reads cases/<id>/upstream.ll (verbatim upstream function), parses the function body ITSELF (it shares no code with
the Java prototype's expression builder, the Python reference refcheck.py, or the add-on validator semcheck.py),
and decides, for every argument, whether the returned value is non-constant in that argument with all other
arguments free -- prog_dep(P, arg, ret) of the paper, with arguments as initial registers.

Semantics assumed (and checked where checkable):
  * integer width taken from the IR type (i32 here); add/sub/xor wrap modulo 2^w (LLVM semantics WITHOUT nsw/nuw;
    any nsw/nuw/exact flag is reported and makes the case ineligible for wrap-around translation);
  * arguments are concrete w-bit values (not undef/poison); any `undef` or `poison` token in the body is reported
    and makes the case ineligible.
Evidence, kept separate by direction:
  VARIES : a concrete witness found by pure-Python search and re-evaluated in pure Python (no solver).
  CONST  : (1) Z3 unsatisfiability of f(..a1..) != f(..a2..) over a term built by THIS script (Z3 is the same solver
           product the prototype uses; the term builder is independent); (2) for single-argument functions,
           exhaustive evaluation over all 2^w values with numpy (a complete proof without a solver); (3) for
           multi-argument functions, exhaustive evaluation at width 8 (all argument values) plus 200,000 random
           32-bit trials (corroboration only).
Also prints the expression of the returned value (as text) for inspection.
Usage: python -I ir_check.py <case dir> [<case dir> ...]
"""
import random, re, sys
import z3
try:
    import numpy as np
except ImportError:
    np = None

DEFN = re.compile(r'^define\s+i(\d+)\s+@([\w.$-]+)\((.*)\)\s*\{\s*$')
ARG = re.compile(r'^\s*i(\d+)\s+(%[\w.$-]+)\s*$')
INS = re.compile(r'^\s*(%[\w.$-]+)\s*=\s*(add|sub|xor)((?:\s+(?:nsw|nuw|exact|disjoint))*)\s+i(\d+)\s+(\S+)\s*,\s*(\S+)\s*$')
RET = re.compile(r'^\s*ret\s+i(\d+)\s+(\S+)\s*$')


def parse(path):
    lines = open(path, encoding='utf-8').read().split('\n')
    d = [i for i, l in enumerate(lines) if l.startswith('define ')]
    assert len(d) == 1, path
    m = DEFN.match(lines[d[0]]); assert m, lines[d[0]]
    w, name = int(m.group(1)), m.group(2)
    args = []
    for a in m.group(3).split(','):
        am = ARG.match(a); assert am and int(am.group(1)) == w, a
        args.append(am.group(2))
    body, notes, ret = [], [], None
    for l in lines[d[0] + 1:]:
        if l.startswith('}'):
            break
        if l.lstrip().startswith(';') or not l.strip():
            continue
        if re.search(r'\b(undef|poison)\b', l):
            notes.append('undef/poison token: ' + l.strip())
        im = INS.match(l)
        if im:
            res, op, flags, iw, x, y = im.groups()
            assert int(iw) == w, l
            if flags.strip():
                notes.append('flag(s) %s on %s' % (flags.strip(), res))
            body.append((res, op, x, y)); continue
        rm = RET.match(l)
        if rm:
            assert int(rm.group(1)) == w; ret = rm.group(2); continue
        raise SystemExit('unsupported instruction in %s: %s' % (path, l.strip()))
    return name, w, args, body, ret, notes


def operand(tok, env, mk_const):
    if tok.startswith('%'):
        return env[tok]
    return mk_const(int(tok))


def build(body, ret, env, mk_const, ops):
    env = dict(env)
    for res, op, x, y in body:
        env[res] = ops[op](operand(x, env, mk_const), operand(y, env, mk_const))
    return operand(ret, env, mk_const)


def text_expr(body, ret, args):
    env = {a: a.lstrip('%') for a in args}
    sym = {'add': '+', 'sub': '-', 'xor': '^'}
    return build(body, ret, env, lambda n: str(n), {k: (lambda s: lambda p, q: '(%s %s %s)' % (p, s, q))(v)
                                                    for k, v in sym.items()})


def py_eval(body, ret, vals, w):
    M = (1 << w) - 1
    ops = {'add': lambda p, q: (p + q) & M, 'sub': lambda p, q: (p - q) & M, 'xor': lambda p, q: (p ^ q) & M}
    return build(body, ret, vals, lambda n: n & M, ops)


def decide(path):
    name, w, args, body, ret, notes = parse(path)
    print('== %s  @%s  i%d  args %s' % (path, name, w, ' '.join(args)))
    print('   returned value:', text_expr(body, ret, args))
    print('   flags/undef/poison:', '; '.join(notes) if notes else 'none')
    M = (1 << w) - 1
    rng = random.Random(0xA11F)
    res = {}
    for a in args:
        others = [o for o in args if o != a]
        # VARIES witness (pure Python)
        wit = None
        cands = [0, 1, 2, M, M - 1, 1 << (w - 1)] + [rng.getrandbits(w) for _ in range(2000)]
        for t in range(4000):
            env = {o: rng.choice(cands) for o in others}
            v1, v2 = rng.choice(cands), rng.choice(cands)
            r1 = py_eval(body, ret, dict(env, **{a: v1}), w); r2 = py_eval(body, ret, dict(env, **{a: v2}), w)
            if r1 != r2:
                wit = (env, v1, v2, r1, r2); break
        if wit:
            env, v1, v2, r1, r2 = wit
            assert py_eval(body, ret, dict(env, **{a: v1}), w) != py_eval(body, ret, dict(env, **{a: v2}), w)
            res[a] = 'VARIES'
            print('   %-4s VARIES  witness others=%s  %s=%d -> %d, %s=%d -> %d (pure Python)' % (
                a, env, a, v1, r1, a, v2, r2))
            continue
        # CONST: Z3 over a term built here
        zs = {o: z3.BitVec(o.lstrip('%'), w) for o in others}
        a1, a2 = z3.BitVec('a1', w), z3.BitVec('a2', w)
        zops = {'add': lambda p, q: p + q, 'sub': lambda p, q: p - q, 'xor': lambda p, q: p ^ q}
        mk = lambda n: z3.BitVecVal(n & M, w)
        f1 = build(body, ret, dict(zs, **{a: a1}), mk, zops)
        f2 = build(body, ret, dict(zs, **{a: a2}), mk, zops)
        s = z3.Solver(); s.add(f1 != f2); zr = s.check()
        ev = ['z3: %s' % zr]
        if not others and np is not None and w == 32:
            const = None; ok = True
            for k in range(64):
                x = np.arange(k << 26, (k + 1) << 26, dtype=np.uint64).astype(np.uint32)
                env = {a: x}
                npops = {'add': lambda p, q: (p + q).astype(np.uint32), 'sub': lambda p, q: (p - q).astype(np.uint32),
                         'xor': lambda p, q: (p ^ q).astype(np.uint32)}
                y = build(body, ret, env, lambda n: np.uint32(n & M), npops)
                y = np.broadcast_to(np.asarray(y, dtype=np.uint32), x.shape)
                lo, hi = int(y.min()), int(y.max())
                if const is None: const = lo
                if lo != hi or lo != const:
                    ok = False; break
            ev.append('exhaustive 2^32 (numpy): %s' % ('constant %d' % const if ok else 'VARIES'))
        elif others:
            M8 = 0xFF; ok8 = True
            for vo in range(256):
                outs = set(py_eval(body, ret, {a: v, others[0]: vo} if len(others) == 1 else None, 8)
                           for v in range(256)) if len(others) == 1 else None
                if outs is None:
                    break
                if len(outs) != 1:
                    ok8 = False; break
            trials_ok = True
            for t in range(200000):
                env = {o: rng.getrandbits(w) for o in others}
                if py_eval(body, ret, dict(env, **{a: rng.getrandbits(w)}), w) != py_eval(
                        body, ret, dict(env, **{a: rng.getrandbits(w)}), w):
                    trials_ok = False; break
            ev.append('width-8 exhaustive: %s' % ('constant' if ok8 else 'VARIES'))
            ev.append('200000 random 32-bit trials: %s' % ('no variation' if trials_ok else 'VARIES'))
        verdict = 'CONST' if zr == z3.unsat and all('VARIES' not in e for e in ev) else 'UNDECIDED'
        res[a] = verdict
        print('   %-4s %s  %s' % (a, verdict, '; '.join(ev)))
    return name, w, notes, res


if __name__ == '__main__':
    for p in sys.argv[1:]:
        decide(p)
