# Forwarding citation: what POPL 2015 proves, and the bridge to the 2011 model

Source: Vafeiadis, Balabonski, Chakraborty, Morisset, Zappa Nardelli, *Common compiler optimisations are invalid in
the C11 memory model and what we can do about it*, POPL 2015 (local copy SHA-256 `01578d58…2f71`; see
`references/REFERENCES.md`). Page numbers are those of that PDF.

## Defect in the previous wording
The paper said the reload elimination is "sound in the 2011 C11 model [Thm. 10]". Thm. 10 (RaW-Adjacent, p. 11)
is stated **for a monotone memory model M**. Def. 3 (p. 8): M is monotone iff M ≠ (ConsRFna,_,_,_) and
M ≠ (_,SCorig,_,_). The 2011 standard is (ConsRFna, SCorig, RSorig, STorig) (p. 7), so it is **not** monotone and
Thm. 10 does not apply to it as stated. Table 1 (p. 9) likewise lists reorderings for monotone models only
(entries Naive/Arf/Arfna). The phrase "reachable by compilation" also overstated: no compiler was run.

## Bridge (our argument; restricted to the programs used here)
Class P: every access is `memory_order_relaxed` (no non-atomic, acquire, release or SC accesses, no fences), and the
initial writes happen-before every access via `asw` (thread creation), as in the litmus convention.
1. ConsRFna (Fig. 5) constrains rf(b)=a only when a or b is non-atomic. In P the only non-atomic writes are the
   initial ones, and they happen-before every access; so ConsRFna holds in every candidate execution of a P
   program. Dropping it (the "Naive" choice, §4.1) changes no consistent execution of a P program.
2. SCorig / SCnew (§4.2) and the SC-order axioms constrain SC actions only; P has none, so both are vacuous and
   agree on P.
3. Hence for P programs, Consistent under (ConsRFna, SCorig, RSorig, STorig) = Consistent under the monotone model
   M* = (Naive, SCnew, RSorig, STorig), with the same observations.
4. Every program in the chain (LB-mem-cancel, after step 1, after steps 2–3) is in P when read as C11 relaxed
   atomics. So a step sound for M* on these programs is sound for the 2011 model on them.

## The three steps, separately
| Step | Memory events | Licence |
|---|---|---|
| (1) reload `u←z`, immediately after `z:=r+1`, replaced by `u:=r+1` (read-after-write elimination) | removes one relaxed read | Thm. 10 for M*: Adj(a,b) holds (nothing between store and reload); Y = rlx, so the clause "M = (_,_,STorig,_)" is needed; M* has STorig (the paper prints the ST component in the third tuple position; in its tuple order (ConsRF, SC, RS, ST) it is the fourth — a positional slip, the intent is unambiguous). Via the bridge: 2011 model on these programs. Thm. 10 also applies directly to (Arf, SCnew, RSorig, STorig), so step 1 is sound there too. |
| (2) `(r+1)−r` → `1` | none (register arithmetic) | wrap-around identity, read with unsigned 32-bit values (signed overflow would be UB in C) |
| (3) store `x:=1` moved above the store to z and the load of y | reorders W;W (different locations) and R(y);W(x) | Table 1 with Thm. 6 (parallelisation) and Thm. 3 (monotonicity, linearisation): valid for Naive, hence for M* and, by the bridge, for the 2011 model on these programs; R;W → W;R is **invalid** for Arf and Arfna (reorderability condition (5)) |

So in a model that forbids hb ∪ rf cycles (Arf), step 1 is still sound and step 3 is not; the end-to-end chain
needs a Naive-like model, which is the 2011 model on class P. In the 2011 model the original LB-mem-cancel outcome is
already allowed (load buffering is not excluded), so the chain shows a property of the criterion, not a new
behaviour of C11.

## What was executed
WEV-SMT modes A/B/C, sdep = ∅ and RC11 on the three programs (supplement `forwarding/`). No compiler was executed;
whether any production compiler performs step 1 on relaxed atomics is not claimed. Mode C forbids the outcome
before step 1 (label L_u − L_r varies) and admits it after step 1 (label (L_r+1) − L_r constant).

## LKMM is separate
As written (`READ_ONCE`/`WRITE_ONCE`), the accesses are volatile and step 1 is not a compiler step; LKMM orders
`dep;[Marked];rfi` in `to-r` ⊆ ppo, so the chain does not apply. The relaxed-atomic reading above is a different
program.
