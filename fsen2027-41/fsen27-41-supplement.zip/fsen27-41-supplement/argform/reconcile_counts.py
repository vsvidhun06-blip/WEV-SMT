"""Reconcile the function counts of the prespecified S2 screen (35,946) and the post-review exploratory script
(35,953) over the same pinned InstCombine directory.
Rule A (s2_screen.py, FN):   ^define\b[^@]*@("?[\w.$-]+"?)\s*\(.*?\{\s*$ ... ^\}   (multiline, DOTALL)
Rule B (llvm_argform.py, DEF): a line matching ^define\b.*@([\w.$-]+)\s*\(  (one per define line)
Prints both totals and every function counted by one rule and not the other, with file, line and the define line.
Usage: python -I reconcile_counts.py <InstCombine dir>
"""
import os, re, sys
root = sys.argv[1]
FN = re.compile(r'^define\b[^@]*@("?[\w.$-]+"?)\s*\(.*?\{\s*$(.*?)^\}', re.S | re.M)
DEF = re.compile(r'^define\b.*@([\w.$-]+)\s*\(')
ta = tb = 0
onlyA, onlyB = [], []
for dp, _, fs in sorted(os.walk(root)):
    for fn in sorted(fs):
        if not fn.endswith('.ll'):
            continue
        p = os.path.join(dp, fn); rel = os.path.relpath(p, root).replace(os.sep, '/')
        text = open(p, encoding='utf-8', errors='replace').read()
        A = set()
        for m in FN.finditer(text):
            A.add(text.count('\n', 0, m.start()) + 1)
        B = set()
        for i, l in enumerate(text.split('\n'), 1):
            if DEF.match(l):
                B.add(i)
        ta += len(A); tb += len(B)
        lines = text.split('\n')
        for ln in sorted(A - B): onlyA.append((rel, ln, lines[ln - 1][:150]))
        for ln in sorted(B - A): onlyB.append((rel, ln, lines[ln - 1][:150]))
print('rule A (prespecified screen) functions:', ta)
print('rule B (exploratory script) define lines:', tb)
print('difference B - A:', tb - ta)
print('counted by A only: %d' % len(onlyA))
for r in onlyA: print('  A-only %s:%d  %s' % r)
print('counted by B only: %d' % len(onlyB))
for r in onlyB: print('  B-only %s:%d  %s' % r)
