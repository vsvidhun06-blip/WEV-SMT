#!/usr/bin/env bash
# Post-review argument-to-return comparison (exploratory; outside the prespecified search and every paper total).
# Re-runs, from the files in this directory:
#   modes A/B/C (pinned corrected-v1 classes, add-on driver) on the 4 constructed wrappers and on the regression mutant;
#   the add-on's independent reference (refcheck.py) and solver-free validator (semcheck.py);
#   the IR-level check (ir_check.py) on the verbatim upstream functions;
#   check_argform.py (expected verdicts) and test_check_argform.py (corruption regression test);
# and compares the prototype and reference outputs byte-for-byte with recorded/.
# Usage: PKGROOT=<extracted base artifact> ADDON=<extracted add-on> WORK=<scratch> bash run_argform.sh <outdir>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKGROOT:?set PKGROOT to the extracted base artifact root}"
: "${ADDON:?set ADDON to the extracted add-on root (fsen27-41-addon)}"
: "${WORK:?set WORK to a scratch dir}"
OUT="$1"; mkdir -p "$OUT" "$WORK"
PY="${PYTHON:-python}"
same() { diff -q --strip-trailing-cr "$1" "$2" > /dev/null; }
rc=0
ls "$HERE/inputs" | grep '\.litmus$' | sort > "$OUT/list.txt"
echo add-test26-mut.litmus > "$OUT/mutant-list.txt"
PKGROOT="$PKGROOT" WORK="$WORK/c" bash "$ADDON/impl/run_composed.sh" "$OUT/composed" "$OUT/list.txt" "$HERE/inputs" > "$OUT/composed.log" 2>&1
PKGROOT="$PKGROOT" WORK="$WORK/m" bash "$ADDON/impl/run_composed.sh" "$OUT/mutant" "$OUT/mutant-list.txt" "$HERE/mutant" > "$OUT/mutant.log" 2>&1
"$PY" -I "$ADDON/refcheck/refcheck.py" "$OUT/composed" "$HERE/inputs" "$OUT/list.txt" "$OUT/ref" > "$OUT/ref.log" 2>&1
( cd "$HERE" && "$PY" -I ir_check.py cases/add-test26/upstream.ll cases/xor-test19/upstream.ll cases/add-test35/upstream.ll \
    cases/xor-test4/upstream.ll cases/apint-sub-test19/upstream.ll ) > "$OUT/ir_check.out"
{ for e in "(((R6) + (R8)) - (R8))|R8" "(((R16) ^ -1) + (R16))|R16" "(((R26) ^ (R28)) ^ (R26))|R26" "((R36) ^ (-1 ^ (R36)))|R36" \
           "((R0 + R1) - R1)|R1" "((R0 ^ -1) + R0)|R0" "((R0 ^ R1) ^ R0)|R0" "(R0 ^ (-1 ^ R0))|R0"; do
    x=${e%|*}; t=${e#*|}; printf '%-34s %-4s ' "$x" "$t"; "$PY" -I "$ADDON/scripts/semcheck.py" "$x" "$t" CONST; done; } > "$OUT/semcheck.out"
for p in "composed/files.csv files.csv" "composed/edges.csv edges.csv" "mutant/edges.csv mutant-edges.csv" \
         "ref/ref-pairs.csv ref-pairs.csv" "ref/ref-files.csv ref-files.csv" "ir_check.out ir_check.out" "semcheck.out semcheck.out"; do
  set -- $p
  if same "$OUT/$1" "$HERE/recorded/$2"; then echo "PASS $2 identical to recorded"; else echo "FAIL $2 differs from recorded"; rc=1; fi
done
"$PY" -I "$HERE/check_argform.py" "$HERE/expected.tsv" "$OUT/composed/files.csv" "$OUT/composed/edges.csv" \
  "$OUT/ref/ref-pairs.csv" "$OUT/ir_check.out" --mutant "$OUT/mutant/edges.csv" > "$OUT/check.txt" || rc=1
tail -2 "$OUT/check.txt"
"$PY" -I "$HERE/test_check_argform.py" "$HERE/check_argform.py" "$HERE/expected.tsv" "$OUT/composed/files.csv" \
  "$OUT/composed/edges.csv" "$OUT/ref/ref-pairs.csv" "$OUT/ir_check.out" "$OUT/mutant/edges.csv" "$OUT/tct" > "$OUT/test_check.txt" || rc=1
tail -1 "$OUT/test_check.txt"
same "$OUT/check.txt" "$HERE/recorded/check.txt" && echo "PASS check.txt identical to recorded" || { echo "FAIL check.txt differs"; rc=1; }
same "$OUT/test_check.txt" "$HERE/recorded/test_check.txt" && echo "PASS test_check.txt identical to recorded" || { echo "FAIL test_check.txt differs"; rc=1; }
[ $rc = 0 ] && echo "ARGFORM RESULT: PASS" || echo "ARGFORM RESULT: FAIL"
exit $rc
