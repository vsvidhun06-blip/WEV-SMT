"""Check the post-review argument-to-return comparison against expected.tsv.

For each case it requires, from FRESH outputs:
  prototype (edges.csv)  : the disputed load->store edge exists, mode B keeps it (local_B_semantic=true),
                           mode C removes it (composed=CONST); the other argument's edge, if any, is VARIES;
                           files.csv: SUPPORTED, edges_fake_B=0, edges_fake_C=1;
  reference (ref-pairs)  : the disputed pair is CONST at 32 bits and AGREEs with the prototype; other pair VARIES;
  IR check (ir_check.out): the disputed upstream argument is CONST, the other argument (if any) VARIES.
Optionally (--mutant <edges.csv>) it also requires the regression mutant's edges to be flipped (load 0 CONST,
load 1 VARIES), which shows that the verdict follows the program text, not the expected table.
Load order is the rank of read_id within a file (= refcheck's load_ord).
Prints PASS/FAIL per check and "RESULT PASS"/"RESULT FAIL (n)"; exit status = number of failures.
Usage: python -I check_argform.py <expected.tsv> <files.csv> <edges.csv> <ref-pairs.csv> <ir_check.out> [--mutant <edges.csv>]
"""
import csv, re, sys
args = sys.argv[1:]
mut = None
if '--mutant' in args:
    i = args.index('--mutant'); mut = args[i + 1]; del args[i:i + 2]
exp_p, files_p, edges_p, ref_p, ir_p = args
fails = 0


def ok(c, msg):
    global fails
    print(('PASS ' if c else 'FAIL ') + msg)
    if not c:
        fails += 1


exp = list(csv.DictReader(open(exp_p, encoding='utf-8'), delimiter='\t'))
files = {r['file']: r for r in csv.DictReader(open(files_p, encoding='utf-8'))}
edges = {}
for r in csv.DictReader(open(edges_p, encoding='utf-8')):
    edges.setdefault(r['file'], []).append(r)
ref = {}
for r in csv.DictReader(open(ref_p, encoding='utf-8')):
    ref[(r['file'], int(r['load_ord']))] = r
ir = {}
cur = None
for l in open(ir_p, encoding='utf-8'):
    m = re.match(r'== cases/([\w.-]+)/upstream\.ll', l.strip())
    if m:
        cur = m.group(1); continue
    m = re.match(r'\s+(%[\w.$-]+)\s+(VARIES|CONST|UNDECIDED)\b', l)
    if m and cur:
        ir[(cur, m.group(1))] = m.group(2)
ok(len(exp) == 4, 'expected table has the 4 i32 cases (found %d)' % len(exp))
for e in exp:
    f, cid = e['litmus'], e['case']
    fr = files.get(f)
    ok(fr is not None and fr['support'] == 'SUPPORTED', '%s supported by mode C' % cid)
    if fr:
        ok(fr['edges_fake_B'] == '0' and fr['edges_fake_C'] == '1',
           '%s fake edges B=%s C=%s (expected 0 and 1)' % (cid, fr['edges_fake_B'], fr['edges_fake_C']))
    es = sorted(edges.get(f, []), key=lambda r: int(r['read_id']))
    rank = {rid: k for k, rid in enumerate(sorted({int(x['read_id']) for x in es}))}
    by = {rank[int(r['read_id'])]: r for r in es}
    d = by.get(int(e['disputed_load_ord']))
    ok(d is not None, '%s disputed edge (load %s -> store) recorded' % (cid, e['disputed_load_ord']))
    if d:
        ok(d['local_B_semantic'] == e['expect_B_disputed'],
           '%s mode B on disputed edge: %s (expected %s)' % (cid, d['local_B_semantic'], e['expect_B_disputed']))
        ok(d['composed'] == e['expect_C_disputed'],
           '%s mode C on disputed edge: %s (expected %s)' % (cid, d['composed'], e['expect_C_disputed']))
    if e['other_load_ord'] != '-':
        o = by.get(int(e['other_load_ord']))
        ok(o is not None and o['composed'] == e['expect_C_other'],
           '%s mode C on the other edge: %s (expected %s)' % (cid, o and o['composed'], e['expect_C_other']))
        ro = ref.get((f, int(e['other_load_ord'])))
        ok(ro is not None and ro['ref32'] == 'VARIES', '%s reference on the other edge: VARIES' % cid)
    rd = ref.get((f, int(e['disputed_load_ord'])))
    ok(rd is not None and rd['ref32'] == e['expect_ref_disputed'] and rd['agree'] == 'AGREE',
       '%s reference on disputed edge: %s / %s' % (cid, rd and rd['ref32'], rd and rd['agree']))
    v = ir.get((cid, e['upstream_arg']))
    ok(v == e['expect_ir_disputed'], '%s IR-level check on %s: %s (expected %s)' % (cid, e['upstream_arg'], v,
                                                                                    e['expect_ir_disputed']))
    others = [k for k in ir if k[0] == cid and k[1] != e['upstream_arg']]
    for k in others:
        ok(ir[k] == 'VARIES', '%s IR-level check on %s: %s (expected VARIES)' % (cid, k[1], ir[k]))
n = sum(1 for e in exp
        if any(r['composed'] == 'CONST' and r['local_B_semantic'] == 'true' for r in edges.get(e['litmus'], [])))
print('cases where B keeps and C removes the disputed edge: %d of %d' % (n, len(exp)))
if mut:
    ms = sorted(csv.DictReader(open(mut, encoding='utf-8')), key=lambda r: int(r['read_id']))
    ok(len(ms) == 2 and ms[0]['composed'] == 'CONST' and ms[1]['composed'] == 'VARIES',
       'mutant (d0 = c0 - r0): mode C flips both edges (load a CONST, load b VARIES): %s' %
       ','.join(r['composed'] for r in ms))
print('RESULT PASS' if fails == 0 else 'RESULT FAIL (%d)' % fails)
sys.exit(fails)
