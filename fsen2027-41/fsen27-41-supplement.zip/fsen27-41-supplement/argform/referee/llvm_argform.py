"""Reviewer check (not part of the manuscript's protocol): in the pinned InstCombine tests, how many test functions
exercise a register-level cancellation in argument/return form (no load/store), i.e. the shape the paper's LLVM
inclusion rule (load reaching store) cannot see?

Heuristic, deliberately narrow and conservative:
  a function body contains   %A = add|sub|xor  <ty> %X, ...   and later   %B = sub|add|xor <ty> %A, %X   (or with
  the operands of the second instruction swapped), i.e. a two-instruction chain t := X op Y; s := t op' X, and the
  function has no load/store; the CHECK lines for that function do not mention the add/sub/xor chain's result
  reaching `ret` through the same two instructions (we only count; we do not prove a fold).
Prints counts of functions matching the input shape, and of those, how many have CHECK lines that `ret` a value
that is not computed by a sub/add/xor of the chain (a strong sign that the cancellation was folded).
Usage: python -I llvm_argform.py <InstCombine test dir>
"""
import os, re, sys
root = sys.argv[1]
DEF = re.compile(r'^define\b.*@([\w.$-]+)\s*\(')
INS = re.compile(r'^\s*(%[\w.]+)\s*=\s*(add|sub|xor)\b(?:\s+(?:nsw|nuw|disjoint))*\s+(i\d+)\s+(%[\w.]+|-?\d+)\s*,\s*(%[\w.]+|-?\d+)')
CHK = re.compile(r';\s*CHECK(?:-NEXT|-LABEL)?:\s*(.*)')
files = funcs = shape = shape_noms = folded = 0
examples = []
for dp, _, fs in os.walk(root):
    for fn in fs:
        if not fn.endswith('.ll'):
            continue
        files += 1
        lines = open(os.path.join(dp, fn), encoding='utf-8', errors='replace').read().split('\n')
        # CHECK blocks keyed by function name
        checks, cur = {}, None
        for l in lines:
            m = CHK.match(l)
            if m:
                body = m.group(1)
                d = re.search(r'@([\w.$-]+)\s*\(', body) if re.match(r';\s*CHECK-LABEL', l.strip()) else None
                if d: cur = d.group(1); checks[cur] = []
                elif cur: checks[cur].append(body)
        i = 0
        while i < len(lines):
            m = DEF.match(lines[i])
            if not m:
                i += 1; continue
            name = m.group(1); body = []
            i += 1
            while i < len(lines) and not lines[i].startswith('}'):
                if not lines[i].lstrip().startswith(';'):
                    body.append(lines[i])
                i += 1
            funcs += 1
            mem = any(re.search(r'\b(load|store|call|atomicrmw|cmpxchg)\b', b) for b in body)
            defs = {}
            hit = None
            for b in body:
                mm = INS.match(b)
                if not mm: continue
                res, op, ty, a1, a2 = mm.groups()
                for (pres, (pop, pty, pa1, pa2)) in defs.items():
                    if res == pres or pty != ty: continue
                    if pres in (a1, a2):
                        other = a2 if a1 == pres else a1
                        if other in (pa1, pa2) and other.startswith('%'):
                            hit = (pres, pop, pa1, pa2, res, op, a1, a2)
                defs[res] = (op, ty, a1, a2)
            if hit:
                shape += 1
                if not mem:
                    shape_noms += 1
                    ck = checks.get(name, [])
                    ops_in_ck = sum(1 for c in ck if re.search(r'=\s*(add|sub|xor)\b', c))
                    if ck and ops_in_ck == 0 and any(c.strip().startswith('ret') for c in ck):
                        folded += 1
                        if True:
                            examples.append('%s @%s: %s = %s %s,%s ; %s = %s %s,%s  ->  CHECK %s' % (
                                os.path.relpath(os.path.join(dp, fn), root), name, hit[0], hit[1], hit[2], hit[3],
                                hit[4], hit[5], hit[6], hit[7], ' | '.join(c.strip() for c in ck if c.strip())[:90]))
print('files', files, 'functions', funcs)
print('functions with a two-instruction add/sub/xor chain sharing an operand (t := X op Y; s := t op X):', shape)
print('  of these, with no load/store/call (argument/return form):', shape_noms)
print('  of these, whose CHECK lines contain no add/sub/xor and end in ret (chain folded away):', folded)
for e in examples: print('  e.g.', e)
