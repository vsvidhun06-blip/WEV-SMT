"""Extract the post-review argument-to-return cases verbatim from the pinned InstCombine tests.

For each case writes cases/<id>/upstream.ll: a provenance header (repository, tag, commit, path, line range, SHA-256
of the whole upstream file, RUN lines) followed by the function's lines exactly as published (define line, CHECK
lines, body, closing brace). The four i32 cases are the referee's; apint-sub.ll @test19 (i39) is extracted for the
record and kept outside the 32-bit results.
Usage: python -I extract_cases.py <llvm-project checkout at llvmorg-22.1.0> <outdir>
"""
import hashlib, os, re, sys
src, out = sys.argv[1], sys.argv[2]
TAG, COMMIT = 'llvmorg-22.1.0', '4434dabb69916856b824f68a64b029c67175e532'
CASES = [  # id, file, function, in 32-bit results?
    ('add-test26', 'add.ll', 'test26', True),
    ('xor-test19', 'xor.ll', 'test19', True),
    ('add-test35', 'add.ll', 'test35', True),
    ('xor-test4', 'xor.ll', 'test4', True),
    ('apint-sub-test19', 'apint-sub.ll', 'test19', False),
]
base = os.path.join(src, 'llvm', 'test', 'Transforms', 'InstCombine')
for cid, fn, name, in32 in CASES:
    path = os.path.join(base, fn)
    raw = open(path, 'rb').read()
    lines = raw.decode('utf-8').split('\n')
    starts = [i for i, l in enumerate(lines) if re.match(r'^define\b[^@]*@%s\(' % re.escape(name), l)]
    assert len(starts) == 1, (fn, name, starts)
    s = starts[0]; e = s
    while not lines[e].startswith('}'):
        e += 1
    run = [l for l in lines[:20] if l.startswith('; RUN:')]
    os.makedirs(os.path.join(out, cid), exist_ok=True)
    hdr = ['; upstream test, extracted verbatim (not modified)',
           '; repository: github.com/llvm/llvm-project  tag: %s  commit: %s' % (TAG, COMMIT),
           '; path: llvm/test/Transforms/InstCombine/%s  lines %d-%d  function @%s' % (fn, s + 1, e + 1, name),
           '; sha256 of the whole upstream file: %s' % hashlib.sha256(raw).hexdigest(),
           '; in the 32-bit results: %s' % ('yes' if in32 else 'no (i39; recorded only)')]
    hdr += [';   ' + r for r in run]
    with open(os.path.join(out, cid, 'upstream.ll'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(hdr) + '\n\n' + '\n'.join(lines[s:e + 1]) + '\n')
    print('%-18s %s:%d-%d sha256=%s' % (cid, fn, s + 1, e + 1, hashlib.sha256(raw).hexdigest()[:16]))
