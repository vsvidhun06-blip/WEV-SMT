# Bundled dependencies (added in corrected-v1, 2026-10-19)

| Path | Content |
|---|---|
| `m2/` | Maven-layout copies of every runtime jar pinned in `impl/DEPENDENCIES.txt`, the Z3 4.13.0 natives (Windows x64 `.dll`, Linux x64 `.so`), the JUnit console launcher 1.11.3, the declaring POMs, and the source jars of the two LGPL components |
| `NATIVES.txt` | the Z3 natives per platform, with their SHA-256 and the names the JavaSMT loader expects |
| `DEPENDENCY-MANIFEST.txt` | SHA-256 of every file in `m2/` (`cd deps && sha256sum -c DEPENDENCY-MANIFEST.txt`) |
| `DEPENDENCIES.csv` | per file: coordinates, SHA-256, official origin URL, declared licence, licence text, role |
| `licenses/` | the licence texts referenced by `DEPENDENCIES.csv` and `THIRD-PARTY-NOTICES.md` |

**How the bundle is used.**
- `reproduce/common.sh` and `reproduce/javaenv.py` use `M2_REPO=deps/m2` unless `M2_REPO` is set.
- Every jar and native is SHA-256-checked against `impl/DEPENDENCIES.txt` or `NATIVES.txt` before use, so a different `M2_REPO` (for example `~/.m2/repository`) must hold byte-identical files.

**Origin and integrity.**
- Downloaded from Maven Central (`https://repo1.maven.org/maven2/`) on 2026-10-19.
- Each file was verified against its Maven `.sha1`.
- The pinned runtime jars and the Windows natives are byte-identical to the SHA-256 pins recorded for the submitted build in `impl/DEPENDENCIES.txt`.
- The Linux natives (`libz3-x64.so` `d4375c04…`, `libz3java-x64.so` `05e9dbf0…`) are the Linux classifier artifacts of the same `org.sosy-lab:javasmt-solver-z3:4.13.0` release. The submitted build's results were produced on Windows; the Linux natives were added for portability (tested: `VERIFICATION-SUMMARY.md`).

**Not needed at run time:** the `smtinterpol` and `princess` solvers. They are on the pinned classpath because JavaSMT declares them, but the tool uses Z3 only.

**Platforms:** Windows x64 and Linux x64. macOS and ARM are not supported (no natives bundled).
