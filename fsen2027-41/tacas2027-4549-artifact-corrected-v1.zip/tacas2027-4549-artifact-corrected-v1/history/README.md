# History

`package-20261012/` holds **verbatim** copies of every file of the 2026-10-12 package that the corrected-v1 package modified or moved. Its `SHA256SUMS` is the 2026-10-12 package's own manifest, unchanged (SHA-256 `89f41d1f5a26325d7d0e34a0e381634a767d90f8d37295741e21b806170644a1`).

Every 2026-10-12 file is therefore either:
- byte-identical at its original path in this package;
- preserved here; or
- one of the two files whose local path was redacted (`ANONYMIZATION.md`). Their original hashes remain listed in `package-20261012/SHA256SUMS`.

Stage 0 checks the current `SHA256SUMS`. To check the unchanged files against the 2026-10-12 manifest, run this from the package root:

```
awk 'NR==FNR { c[$0]; next } !(substr($0, 67) in c)' history/package-20261012/CHANGED-PATHS.txt history/package-20261012/SHA256SUMS | sha256sum -c --quiet
```

`CHANGED-PATHS.txt` lists the 2026-10-12 paths that changed (`CHANGES-v1.md` gives the details).

The 2026-10-12 paper copies (`paper/wev-smt.pdf` and `paper/wev-smt.tex`) are the 36-page **pre-submission** version. They are kept here for traceability. They are **not** the submitted paper; that is `../paper/submitted/`.
