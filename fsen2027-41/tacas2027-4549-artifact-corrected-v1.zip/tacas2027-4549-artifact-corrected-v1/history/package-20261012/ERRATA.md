# Errata (package copies only; originals unchanged)

## E1. Unit labels in the chain-composition accounting

Four distinct units occur. Earlier summaries sometimes conflated them.

| Unit | Count | Normalisation key |
|---|---|---|
| threads (generated litmus files) | 256 | one per file |
| distinct programs | 236 | registers renamed by first appearance; constants and locations kept |
| distinct shapes | 168 | as above, with every constant also abstracted |
| (load, store) pairs | 317 | one per load of a thread against its single store |
| distinct program/load pairs | 291 | program key + load index |
| distinct shape/load pairs | 213 | shape key + load index |

Corrections in `chain-composition/REPORT.md` (package copy):
- **Duplicated-instances sentence.** "INJ L=1 has 7 unique programs over 16 pairs" now
  reads "12 threads, 5 distinct programs and 7 distinct program/load pairs over 16 pairs".
- **Uniqueness line.** Now also states the 236 programs and 168 shapes.

In the generated `chain-composition/results/tables.md`, the "uniq" columns and the
"N shapes" in the disagreement list count **(program, load)** and **(shape, load)**
pairs. That file is a deterministic output and is left byte-identical. For the
disagreement lists the two readings coincide numerically:
- A: 108 programs = 108 program/load pairs; 77 shapes = 77 shape/load pairs;
- B: 72 = 72; 53 = 53.

A development summary once referred to "291 unique programs"; the correct unit is
**program/load pairs**. The paper uses the correct units (§6.2: "317 load–store pairs, 213
distinct up to register renaming and constants"; App. A.6: 236 programs, 168 shapes, 291
and 213 pairs).

## E2. Hard-benchmark enumeration (paper App. A.6, *Enumeration*)

The paper describes the atoms `{r, ~r}`, the constants `{0,1,2,3,7,255}` and the operators
`{+,-,*,&,^}`. The recorded candidate list and its 13,880 intermediate forms imply a further
restriction: three-operator forms use only the leaves `{r, ~r, 0, 1}` and the operators
`{&, *, ^}`, and every form must mention the register. See `hardbench/README.md`.

The paper's own note already allows for this: it calls 13,880 a figure reported from that
run, smaller than a direct product count. This note makes the rule explicit. It changes no
reported number.

## E3. Scalability ratio orientation (paper App. A.6, *Scalability*)

The reported range "between 0.80 and 1.70 through n = 12" is the ratio
**LBChain / LBFakeChain** of WEAKEST full-execution times. The inverse orientation gives
0.59–1.25. `reproduce/05_claims.py` checks the stated orientation.

## Symbolic value-consistency correction

The current paper table uses 1,288 value-consistent instances. The other 2,368
all-ones queries fail value consistency and are not dependency-discrimination
positives. Historical wired rows remain unmodified for traceability.
The grounded-half result (385 expressions, 770 instances) is unchanged.

## Semantic-scope closeout (2026-10-10)

The paper now states relational encoding adequacy for the supplied relation C;
it does not claim the prototype closure equals composed dependence in general.
JF equals RF in the encoder and the proof. Exactness is scoped to straight-line
load/assignment/store threads; guarded register writes have no label semantics
in the application. The defined dependency-cycle criterion is not an independently
validated out-of-thin-air predicate. All 110 positive benchmark expressions satisfy
e(0)=e(1)=1; each can write 1 after reading initial 0. Benchmark counts and code
are unchanged. No Promising-model or compilation validation is claimed.


## Post-blind-review scope correction (2026-10-11)

MutationCorpusRun uses wired folded values, not symbolic value propagation.
Replacing r XOR r with r AND r changes the source expression from 0 to r.
The preserved five ALLOWED/FORBIDDEN changes are historical wired candidate
diagnostics, not source-program verdicts, value-preserving transformations,
or isolated evidence of dependency-strengthening soundness. The original CSV
and report are retained unchanged as records; their causal descriptions must
be read with this correction. The separate six-file edge-relabelling ablation
is unaffected. No experiment was rerun for this wording correction.

The folding benchmark is limited to the authored implementation and constructed
population. No dominance over arbitrary idiom recognizers or cheap analyses is
claimed. The chain population has 256 threads including 14 controls.
Activity restrictions must remain candidate-well-formed; the oracle detector
and address extensions retain their stated proof boundaries. Core theorems,
code, bibliography and raw results are unchanged.


## Minor-review closeout (2026-10-11)

The paper clarifies file/program units, audit populations, exclusion accounting, model naming and check-case terminology. The synthesis description is limited to its finite decision-table population. REVERSION-RECORD.json archives historical prose provenance for the 293-divergence replay; it is not raw replay output or a reproducer. Source, theories and raw evaluation data are unchanged.
