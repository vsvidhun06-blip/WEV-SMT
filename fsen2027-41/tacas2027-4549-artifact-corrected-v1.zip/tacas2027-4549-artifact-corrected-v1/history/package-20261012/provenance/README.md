# Eligibility provenance tools (recovered, unmodified)

These are the exact scripts that produced the frozen 12,324-file population and the
2,396-file eligible manifest (`corpus/manifests/`, SHA-256 pin `ae011be3...`), together
with the correction summariser behind Table 2's partition. They were recovered from the
audit workspaces and copied byte-for-byte. None was edited, renamed or reconstructed.
Reproduction stage `reproduce/07_provenance.py` re-runs each one into `$WORK` and compares
the output with the recorded file.

## Scripts and their recorded use

| file | sha256 (prefix) | origin (audit workspace) | recorded use |
|---|---|---|---|
| `gates/Extract.java` | `119d9f43` | `2026-10-09-imm-repair/tools/` | parser dump `src12324/corpus/{events,edges}.csv` |
| `gates/OutcomeDump.java` | `f00b1ebd` | `2026-10-09-alias-repair/tools/` | outcome dump `src12324/outcomes.csv` |
| `gates/gate.py` | `a0d42329` | `2026-10-09-imm-repair/tools/` | **extraction gate**: produced `src12324/corpus-gate.csv` (output name `<prefix>-gate.csv`) |
| `gates/gate2.py` | `91b7f67e` | `2026-10-09-alias-repair/tools/` | library imported by `outcome_gate.py`. It differs from `gate.py` in one line (`run_thread` also returns its register maps). Its own `main` no longer runs (it unpacks the old return shape), so it is **not** the extraction gate |
| `gates/outcome_gate.py` | `49369cf6` | `2026-10-09-alias-repair/tools/` | **outcome-binding gate**: produced `src12324/outcome-gate.csv`, stdout = `outcome-gate.txt` |
| `eligibility/eligibility.py` | `b64ecec0` | `2026-10-09-provenance/tools/` | status contract → `per-test-status.csv` |
| `eligibility/freeze.py` | `472c10b4` | `2026-10-09-provenance/tools/` | frozen population, eligible manifest, hashes, pin |
| `correction/summarize_correction.py` | `0919027a` | `wev-paper-repair-20261010/` | Table 2 partition check → `repair/benchmark-correction.json`, `repair/symbolic-value-consistent.csv` |

Provenance evidence for the attribution, with no invented history:
- The alias-repair report states the extraction gate was the "unchanged `gate.py`".
- File timestamps put both gates (18:47 and 18:50) before the `src12324` outputs (19:18).
- Every recorded output above is reproduced **byte-for-byte** by stage 07 from these files.
- No shell log of the original invocations survives. The commands below are the scripts'
  own documented usage lines, which is what stage 07 runs.

## Commands (as stage 07 runs them; all outputs under `$WORK/provenance`)

```
python -I -X utf8 gates/gate.py  recorded/src12324/corpus/events.csv recorded/src12324/corpus/edges.csv <corpus/litmus/> $WORK/A/corpus
python -I -X utf8 gates/outcome_gate.py recorded/src12324/outcomes.csv <corpus/litmus/> $WORK/B/outcome-gate.csv  > $WORK/B/outcome-gate.txt
python -I -X utf8 eligibility/eligibility.py $WORK/C/prov <corpus/litmus/>          # on a WORK copy of recorded/
python -I -X utf8 eligibility/freeze.py      $WORK/C/prov <corpus/litmus/> $WORK/C/imm-repair
java -cp <impl/classes + pinned deps> Extract     recorded/src12324/list.txt <corpus/litmus/> $WORK/D/corpus   # --with-java
java -cp <impl/classes + pinned deps> OutcomeDump recorded/src12324/list.txt <corpus/litmus/> $WORK/D/outcomes.csv
python -I summarize_correction.py   # run from a WORK copy next to repair/symbolic-ring-audit.csv (it writes beside itself)
```

`eligibility.py` and `freeze.py` write into their first argument, so stage 07 always runs
them on a copy. The packaged `recorded/` tree and `corpus/manifests/` are never written.

## Exact versus sampled

| check | exact | sampled |
|---|---|---|
| extraction gate (`gate.py`) | event kinds, locations and data pairs per thread; folded constants | write-value expressions compared on 40 valuations per write (fixed seed) |
| outcome gate (`outcome_gate.py`) | the parse of the exists clause; rejection rules | atom classification (PIN / CONST / COMPUTED) on 160 random plus forced valuations (fixed seed). AArch64 width (upper-zero) confirmation is therefore sampled |
| `eligibility.py`, `freeze.py` | deterministic set logic over the gate outputs | none |
| `summarize_correction.py` | concrete BV32 evaluation of e(0)=1 and of e(1)=1 ⇔ SAT; constancy is the QF_BV oracle column | none |
| `address-check/` (new) | every register-indexed offset, by z3 over 64-bit semantics | none |

Both gates share the encoder's base-location abstraction. They check structure and values
*given* that each access resolves to its base location. The fidelity of that abstraction
for register-indexed accesses is established separately and exactly in `address-check/`.

## Inputs that stage 07 consumes but does not regenerate

- `recorded/manifests/manifest-paper-12324.csv`: the population manifest from the
  provenance replay (`provenance.py`, not packaged here). Its membership is the paper's
  12,324 files, all shipped under `corpus/litmus/`.
- `recorded/wiring/stderr.txt`: stderr of the wired corpus run. It sets the
  `wired_fallback` flag (3 files) and is not regenerated.
- `recorded/imm-repair/impact/newly-parsing-not-gated.txt`: the list behind the
  `new258` flag.

The parser dumps (`events.csv`, `edges.csv`, `outcomes.csv`) are regenerated by
`--with-java` and match byte-for-byte with the pinned classes.
