# Results: authoritative, carried, superseded

## `authoritative/`: the repaired results the paper reports

These were produced with the pinned implementation (`impl/`) on the frozen manifests, after
three repairs:
- AArch64 `#` immediates;
- X/W register outcome binding;
- TSO/PSO preserved program order.

**`ppo-repair/`** holds the final six-model run:
- `six-model/repaired-symbolic.csv`: 2,396 × 6, source of every symbolic verdict claim;
- `six-model/repaired-wired-847.csv`: the 847-file diagnostic;
- `herd7-x86-results.csv`: TSO 101/101;
- the verdicts changed by the PPO repair.

The repair changed only TSO and PSO formulas. The SC, RA, WEAKEST and RC11 formulas are
byte-identical across all 2,396 files, so the audits below, run just before it, carry over.

**`rerun-2026-10-09/`** holds the frozen re-run:
- dependency and discriminator audits (`sdep/`, `mutation-*`, `pairs-corpus.csv` with the
  374 pairs, `pwt-*`, `qfbv-*`, `layer2-audit.csv`, `detector-quality/`,
  `detector-oracle-audit.csv`);
- Table 2 (`generated-hard-pairs.csv`, byte-identical to the shipped table) and the
  matched-pair folding table;
- the published examples (`examples-results.json`);
- the herd7 SC comparison (`herd7-frozen-results.csv`; SC unaffected by the PPO repair);
- `final-analysis.txt`.

`final-analysis.txt` was written before the PPO repair. Its TSO and PSO counts are therefore
superseded by `ppo-repair/`. Everything else in it stands.

## `carried/`: earlier runs on unchanged inputs, cited as such by the paper

| Files | Content |
|---|---|
| `nthread-grounded-admission.csv` | grounded-LB admission up to eight threads |
| `scalability-consistency.csv` | parametric scalability sweep |
| `dat3m-comparison-v2.csv` | Dat3M timings and the wired 31/41 |
| `dat3m-lkmm-*` | Dat3M v4.4.1 / LKMM over Table 2's instances |
| `generated-pairs*.csv` | matched-pair ring sweep |
| `classifier-defect-records/` | the pre-fix defect measurement (218/8448); a recorded experiment, not re-derivable from the fixed tree |

These exercise only WEAKEST or external tools, on inputs the repairs did not change. They
are not re-run by the package checks.

## `superseded/`: kept for traceability only, never cited as a result

`pre-ppo-repair-six-model/` holds the six-model run before the TSO/PSO
preserved-program-order repair. For example, its TSO SAT count is 743, against 563 after
the repair.

The repository's older corpus tables, from a build that encoded neither fences nor RMW
atomicity, are not packaged (see `../LIMITATIONS.md`).
