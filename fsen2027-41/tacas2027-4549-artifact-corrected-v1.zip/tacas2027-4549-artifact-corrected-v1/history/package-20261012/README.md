# Artifact: *The Limits of Instruction-Local Dependency Summaries, with an Application to Thin-Air Reads*

This package lets a researcher check the paper's claims without access to the development
history. It contains:
- the Isabelle/HOL development;
- the exact source snapshot and compiled classes of the evaluated implementation;
- the frozen corpus with hashes;
- the generators, drivers and adapters;
- the authoritative outputs;
- the paper.

Everything here is a copy; the reproduction scripts write only to a separate work
directory.

**2026-10-12 refresh** (see `CHANGES-20261012.md`). This package supersedes the 2026-10-11
package for the 36-page manuscript. It adds the manuscript source and PDF (`paper/README.md`)
and the four evidence files that App. A.10 cites (`evidence/README.md`). No experiment was
re-run, and no result, script, implementation, theory or corpus file changed.

## Quick start

```
export WORK=/path/to/scratch          # outside this directory
export M2_REPO=$HOME/.m2/repository   # holds the pinned jars of impl/DEPENDENCIES.txt
export ISABELLE_HOME=/path/to/Isabelle2024
bash reproduce/run_all.sh             # runtime varies; SKIP_ISABELLE=1 / SKIP_JAVA=1 to skip stages
```

| Stage | Script | Checks | Needs |
|---|---|---|---|
| 0 | `00_manifest.sh` | every file matches `SHA256SUMS` | bash, sha256sum |
| 1 | `01_isabelle.sh` | sessions `WEV_SMT` and `WEV_SMT_PwT` build (`-c`, clean); no `sorry`/`oops` outside comments | Isabelle2024 |
| 2 | `02_generators.sh` | hard-benchmark candidate list (reconstructed generator) and chain-composition inputs regenerate **byte-identically** | Python 3 |
| 3 | `03_chain.sh` | chain validation and summary reproduce (byte-identical, except the z3-chosen witness values, each of which must be execution-confirmed); re-classification with the pinned classes matches except the timing column | Python 3 + `z3-solver`; JDK 21 |
| 4 | `04_impl_smoke.sh` | snapshot and class pins; fresh build reproduces the pinned classes; all corpus hashes; historical wired benchmark re-run byte-identical; 30-file six-model subset reproduces the authoritative verdicts | JDK 21, pinned jars |
| 5 | `05_claims.py` | every empirical claim (31) resolves to a packaged file, and its figure is **recomputed** from the rows | Python 3 |
| 7 | `07_provenance.py` | recovered extraction/outcome gates, `eligibility.py` and `freeze.py` regenerate the gate outputs, per-test statuses, frozen population and eligible manifest (pin `ae011be3…`) **byte-identically**; `summarize_correction.py` regenerates Table 2's partition; the exact address-index check and its 18 controls reproduce. `--with-java` also regenerates the parser dumps byte-identically | Python 3 + `z3-solver`; JDK 21 and pinned jars for `--with-java` |

Toolchain used for the recorded results:
- OpenJDK 21.0.10;
- Z3 4.13.0 via JavaSMT 5.0.1;
- Isabelle2024;
- Python 3.11 with z3-solver;
- herd7 7.58 (for the herd7 comparison only; not needed by the checks).

On Windows, run under Git Bash. Java paths are converted with `cygpath`, and Isabelle is
driven through its bundled Cygwin.

## Layout

| Path | Contents |
|---|---|
| `paper/wev-smt.pdf` | current manuscript (36 pp.; source `paper/wev-smt.tex`, provenance `paper/README.md`) |
| `evidence/` | the run logs `pwt.log` and `oracle-audit.log`, and the verdict transcriptions `source-paper-results.csv` and `jmm-results.csv`, cited by App. A.10 (see `evidence/README.md`) |
| `isabelle/` | `ROOT` and all theories (two sessions) |
| `impl/snapshot/` | `pom.xml` and `src/` of the **evaluated implementation** |
| `impl/classes/` | its compiled classes |
| `impl/PIN.txt` | per-file hashes, aggregates, jar and native hashes, toolchain |
| `impl/DEPENDENCIES.txt` | runtime classpath in pinned order, SHA-256 per jar, Z3 natives |
| `impl/deps/` | the project's own model jar (`visualising-weakest-executions`), not available from Maven Central |
| `corpus/litmus/` | all **12,324** sampled litmus files (herdtools7 4,324 + Dat3M 8,000), each matching its recorded hash, with the upstream licences |
| `corpus/manifests/` | frozen population (status per file); eligible manifest (2,396; SHA-256 `ae011be3…`); per-file hashes; the 847-file wired subset |
| `inputs/examples/` | published example programs (Weakestmo, PwT/leaky-semicolon, JMM, paper, diag) |
| `drivers/` | the repaired drivers that produced the authoritative results (see "Full reruns") |
| `hardbench/` | the recorded candidate list and the **reconstructed** enumerate/filter step (see `hardbench/README.md`) |
| `chain-composition/` | design, freeze record, generator, hand cases, adapter, validation, summary, results, report |
| `synthesis/claimD/` | the unrestricted-abstraction synthesis (App. A.7) and its outputs |
| `results/` | `authoritative/`, `carried/` and `superseded/` outputs (see `results/README.md`) |
| `reproduce/` | the checks above |
| `provenance/` | the recovered, unmodified eligibility tools (gates, `eligibility.py`, `freeze.py`, `summarize_correction.py`) and their recorded inputs/outputs (see `provenance/README.md`) |
| `address-check/` | the exact register-indexed offset check, its controls and recorded results (see `address-check/README.md`) |

## The evaluated implementation is identified by hashes, not by a revision

The evaluated tree was an **uncommitted working tree**. No repository revision identifies
it, and a repository HEAD alone does **not**. It is identified by:
- snapshot aggregate `04d5604b133bc7d7…` (SHA-256 over the per-file sums in `impl/PIN.txt`);
- compiled-classes aggregate `86f068947142ad3e…`;
- the jar and native hashes in `impl/PIN.txt`.

Stage 4 recompiles the snapshot and checks that it reproduces the pinned classes.

## Full reruns (not part of the checks)

The authoritative corpus results took about 10 minutes per mode on the recorded machine.

**Six-model symbolic run** over the 2,396 eligible files, from `drivers/ppo-repair/remeasure.sh`:

```
java -Djava.library.path=<natives> -cp impl/classes:<deps> wev.smt.cli.CorpusValidation \
     corpus/litmus <out> manifest=corpus/manifests/frozen-eligible-hashes.csv \
     mode=symbolic csv=repaired-symbolic.csv perFileSec=30 budgetMin=600 maxEvents=64
```

For the 847-file wired diagnostic, use `mode=wired` with
`manifest=corpus/manifests/wired-847-hashes.csv`.

**Other drivers.**
- `drivers/final-rerun/rerun.sh` produced the dependency audits, the 374-pair comparison
  (`drivers/coherence/CoherencePairs.java`), the published examples and Table 2.
- `run_herd7_frozen.sh` produced the herd7 comparison.
- `final_analysis.py` produced the summary in `results/authoritative/rerun-2026-10-09/final-analysis.txt`.

The scripts' absolute paths were replaced by placeholders (`<AUDIT_ROOT>`, `<IMPL_ROOT>`,
`<M2_REPO>`), so set them before running. Verdict columns are deterministic; `solve_ms`,
`C_ms`, `*_time_ms` and similar columns are timing-dependent.

## Reproducibility status

**PARTIAL. What reproduces from this package alone:**
- the Isabelle sessions;
- the inputs, regenerated byte-identically;
- the chain experiment;
- Table 2, re-run byte-identically;
- the six-model verdicts on the checked subset;
- every claim figure recomputed from packaged rows;
- the eligibility chain, from parser dumps through the gates to the frozen eligible
  manifest, byte-identically (stage 7);
- the exact address-offset check.

**What does not** (see `LIMITATIONS.md`):
- The original hard-benchmark enumerate/filter script is lost. The packaged generator is a
  labelled **reconstruction**; it reproduces the recorded input and the 13,880 count exactly.
- Some results are **carried from an earlier run**:
  - the n-thread admission check;
  - the scalability sweep;
  - the Dat3M timings;
  - the Dat3M/LKMM comparison;
  - the matched-pair sweep;
  - the synthesis.

  They are packaged, but this package does not re-run them.
- The pre-fix classifier-defect measurement (218/8448) is a **recorded experiment**, not
  re-derivable from the fixed tree.
- Third-party jars must be supplied from Maven (pinned by hash), and the herd7 binary from
  upstream.

See also:
- `ERRATA.md`
- `LIMITATIONS.md`
- `ANONYMIZATION.md`
- `results/README.md`
- `hardbench/README.md`
- `chain-composition/REPORT.md`

## Symbolic-benchmark correction and external tool check

Read repair/README.md. The paper copy includes the corrected value-consistent table.
Stage 4 retains the old wired output solely as a historical regression check.
Stage 5 checks the current table against repair/symbolic-ring-audit.csv.
Run python reproduce/06_repair.py separately to regenerate that symbolic audit
(allow up to 30 minutes; no fixed-runtime guarantee). LLVM DFSan reproduction is
optional and requires the stated existing Linux compiler/runtime. No downloads
are performed. Previous setup and carried-result limitations remain.

A quick correction smoke test is: python reproduce/06_repair.py <package-dir> --smoke
It checks one constant, one value-consistent varying and one value-inconsistent expression
at both ring sizes, without claiming a full benchmark rerun.

## Semantic-scope closeout (2026-10-10)

The paper now states relational encoding adequacy for the supplied relation C;
it does not claim the prototype closure equals composed dependence in general.
JF equals RF in the encoder and the proof. Exactness is scoped to straight-line
load/assignment/store threads; guarded register writes have no label semantics
in the application. The defined dependency-cycle criterion is not an independently
validated out-of-thin-air predicate. All 110 positive benchmark expressions satisfy
e(0)=e(1)=1; each can write 1 after reading initial 0. Benchmark counts and code
are unchanged. No Promising-model or compilation validation is claimed.


## Post-blind-review scope correction (2026-10-11)

MutationCorpusRun uses wired folded values, not symbolic value propagation.
Replacing r XOR r with r AND r changes the source expression from 0 to r.
The preserved five ALLOWED/FORBIDDEN changes are historical wired candidate
diagnostics, not source-program verdicts, value-preserving transformations,
or isolated evidence of dependency-strengthening soundness. The original CSV
and report are retained unchanged as records; their causal descriptions must
be read with this correction. The separate six-file edge-relabelling ablation
is unaffected. No experiment was rerun for this wording correction.

The folding benchmark is limited to the authored implementation and constructed
population. No dominance over arbitrary idiom recognizers or cheap analyses is
claimed. The chain population has 256 threads including 14 controls.
Activity restrictions must remain candidate-well-formed; the oracle detector
and address extensions retain their stated proof boundaries. Core theorems,
code, bibliography and raw results are unchanged.


## Minor-review closeout (2026-10-11)

The paper clarifies file/program units, audit populations, exclusion accounting, model naming and check-case terminology. The synthesis description is limited to its finite decision-table population. REVERSION-RECORD.json archives historical prose provenance for the 293-divergence replay; it is not raw replay output or a reproducer. Source, theories and raw evaluation data are unchanged.

## Address and provenance closeout (2026-10-11)

This closeout adds evidence and tooling only. Implementation, theories, classifiers,
consistency rules, corpus and every earlier result are unchanged.

- **Address offsets.** The encoder resolves register-indexed accesses to their base
  location. `address-check/` proves exactly, with z3 over 64-bit AArch64 semantics, that
  all 202 such accesses in the 133 eligible files that have them have a zero effective
  offset: 202 VERIFIED_ZERO, 0 nonzero, 0 unresolved. Base-location addressing is
  therefore faithful on the eligible population. This is a population-wide check; the
  LB+addrs hand check is one instance of it.
- **Recovered tools.** The scripts behind the eligible manifest and Table 2's partition
  are packaged unmodified in `provenance/`, with their recorded inputs. Stage 7 regenerates
  every recorded output byte-identically.
  - The extraction gate is `gate.py`.
  - `gate2.py` is a one-line variant that only `outcome_gate.py` imports.
- **Sampled versus exact.**
  - The extraction gate compares write values on 40 sampled valuations.
  - The outcome gate classifies atoms on 160 random and forced valuations, so its AArch64
    width confirmation is sampling-based evidence, not proof.
  - Structure, locations, data pairs and the address offsets are checked exactly.
- **Manifest file.** `SHA256SUMS` now uses LF line endings. The earlier package's CRLF
  manifest made `sha256sum -c` in stage 0 fail under Git Bash.
- **Paper.** `paper/` holds the current source, the bibliography and a locally built PDF.
  The Overleaf-built PDF still needs to be synchronised with this copy.
