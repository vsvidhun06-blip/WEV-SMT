#!/usr/bin/env python3
from pathlib import Path
import os,sys,csv,json,hashlib,subprocess,shutil,argparse
ap=argparse.ArgumentParser();ap.add_argument('package',nargs='?',default=str(Path(__file__).resolve().parent.parent));ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
P=Path(args.package).resolve()
W=Path(os.environ.get('WORK',str(P.parent/'_repair-repro-work'))).resolve()
assert W!=P and P not in W.parents,'WORK must be outside the package'
W.mkdir(parents=True,exist_ok=True)
M=Path(os.environ.get('M2_REPO',str(Path.home()/'.m2/repository')))
sep=';' if os.name=='nt' else ':'
cp=[str(P/'impl/classes')]; N=W/'native';N.mkdir(exist_ok=True)
for line in (P/'impl/DEPENDENCIES.txt').read_text().splitlines():
 if not line or line.startswith('#'):continue
 if line.startswith('NATIVE'):
  _,h,rel,name=line.split();f=M/rel
  assert hashlib.sha256(f.read_bytes()).hexdigest()==h
  shutil.copy2(f,N/name)
 else:
  h,rel=line.split();f=M/rel
  if rel.startswith('com/weakest/'):f=P/'impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar'
  assert hashlib.sha256(f.read_bytes()).hexdigest()==h
  cp.append(str(f))
C=W/'classes';C.mkdir(exist_ok=True)
subprocess.run([os.environ.get('JAVAC','javac'),'-proc:none','-encoding','UTF-8','-cp',sep.join(cp),'-d',str(C),str(P/'repair/SymbolicRingAudit.java')],check=True)
output=W/('symbolic-ring-smoke.csv' if args.smoke else 'symbolic-ring-audit.csv')
candidate=P/'hardbench/generated-hard-candidates.json'
expect=list(csv.DictReader((P/'repair/symbolic-ring-audit.csv').open(newline='',encoding='utf-8')))
if args.smoke:
    chosen=[]
    for const,base in [('true','SAT'),('false','SAT'),('false','UNSAT')]:
        chosen.append(next(r['expr'] for r in expect if r['oracle_constant']==const and r['value_consistency']==base))
    candidate=W/'smoke-candidates.json';candidate.write_text(json.dumps(chosen),encoding='utf-8')
    expect=[r for e in chosen for r in expect if r['expr']==e]

subprocess.run([os.environ.get('JAVA','java'),'-Djava.library.path='+str(N),'-cp',sep.join([str(C)]+cp),'SymbolicRingAudit',
str(candidate),str(output)],check=True,timeout=1800)
got=list(csv.DictReader(output.open(newline='',encoding='utf-8')))
assert got==expect,'Symbolic verdicts differ from the recorded audit'
print('PASS:',len(got),'symbolic ring rows match exactly')
