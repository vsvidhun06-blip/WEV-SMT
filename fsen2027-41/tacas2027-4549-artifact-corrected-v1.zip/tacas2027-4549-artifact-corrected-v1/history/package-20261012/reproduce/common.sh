#!/usr/bin/env bash
# Shared environment for the reproduction scripts. Source it; do not run it.
#
# Inputs (environment variables):
#   M2_REPO   Maven-layout directory holding the pinned jars of impl/DEPENDENCIES.txt
#             (default: $HOME/.m2/repository). The project's own model jar is shipped in
#             impl/deps/ and is used from there.
#   WORK      scratch directory for all outputs (default: ./_repro-work next to the package).
#             Nothing under the package directory is modified.
#   PYTHON    Python 3 with the z3-solver module (default: python3, else python).
#   JAVA, JAVAC  JDK 21 tools (default: java, javac on PATH).
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
M2_REPO="${M2_REPO:-$HOME/.m2/repository}"
WORK="${WORK:-$PKG/../_repro-work}"
mkdir -p "$WORK"
WORK="$(cd "$WORK" && pwd)"
JAVA="${JAVA:-java}"; JAVAC="${JAVAC:-javac}"
if [ -z "${PYTHON:-}" ]; then
  if command -v python3 >/dev/null 2>&1 && python3 -c 'import sys' >/dev/null 2>&1; then PYTHON=python3; else PYTHON=python; fi
fi
PY="$PYTHON -I -B"

# Path conversion for native Windows JVMs under Git Bash / Cygwin.
if command -v cygpath >/dev/null 2>&1; then
  w() { cygpath -w "$1"; }; SEP=';'
else
  w() { printf '%s' "$1"; }; SEP=':'
fi

sha() { sha256sum "$1" | cut -c1-64; }

# Build the runtime classpath from impl/DEPENDENCIES.txt, verifying every jar's SHA-256,
# and stage the Z3 natives into $WORK/native (hash-verified).
setup_java_env() {
  local cp="" line h rel name
  mkdir -p "$WORK/native"
  while IFS= read -r line; do
    case "$line" in
      '#'*|'') continue ;;
      NATIVE*)
        read -r _ h rel name <<<"$line"
        [ -f "$M2_REPO/$rel" ] || { echo "MISSING native: \$M2_REPO/$rel" >&2; return 1; }
        [ "$(sha "$M2_REPO/$rel")" = "$h" ] || { echo "HASH MISMATCH: $rel" >&2; return 1; }
        cp "$M2_REPO/$rel" "$WORK/native/$name" ;;
      *)
        read -r h rel <<<"$line"
        local f="$M2_REPO/$rel"
        case "$rel" in com/weakest/visualising-weakest-executions/*)
          f="$PKG/impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar" ;; esac
        [ -f "$f" ] || { echo "MISSING jar: $rel" >&2; return 1; }
        [ "$(sha "$f")" = "$h" ] || { echo "HASH MISMATCH: $rel" >&2; return 1; }
        cp="${cp:+$cp$SEP}$(w "$f")" ;;
    esac
  done < "$PKG/impl/DEPENDENCIES.txt"
  DEPS_CP="$cp"
  NATIVE_DIR="$(w "$WORK/native")"
  export DEPS_CP NATIVE_DIR
}

classes_hash() { ( cd "$1" && find . -name '*.class' | LC_ALL=C sort | xargs sha256sum | sha256sum | cut -c1-64 ); }
PIN_CLASSES=86f068947142ad3e44a80ca77447744858a29190703d2d8c76f22aafabd6bced
PIN_SNAPSHOT=04d5604b133bc7d7a3b329843a7be9c6070e44f2d7e917b3b0075340f7f827e2
PIN_MANIFEST=ae011be3422cacff9d08a742650906c846f4a22590bffc06885d86ff59fa4036

pass() { echo "PASS  $*"; }
fail() { echo "FAIL  $*"; FAILS=$(( ${FAILS:-0} + 1 )); }
