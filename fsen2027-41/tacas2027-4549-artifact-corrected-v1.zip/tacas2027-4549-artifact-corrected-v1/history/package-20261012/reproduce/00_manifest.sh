#!/usr/bin/env bash
# 0. Package integrity: every file listed in SHA256SUMS is present and unmodified.
source "$(dirname "$0")/common.sh"
( cd "$PKG" && sha256sum -c --quiet SHA256SUMS ) > "$WORK/manifest-check.log" 2>&1 \
  && pass "all $(grep -c . "$PKG/SHA256SUMS") files match SHA256SUMS" \
  || { fail "SHA256SUMS mismatches (see $WORK/manifest-check.log)"; head "$WORK/manifest-check.log"; }
exit "${FAILS:-0}"
