#!/usr/bin/env bash
# 4. Evaluation smoke tests against the PINNED implementation and manifests.
#   - snapshot sources hash to the pin; a fresh javac build reproduces the pinned classes;
#   - frozen manifests and every packaged corpus file match their recorded hashes;
#   - the historical wired hard-expression benchmark re-runs byte-identically (no timing column);
#   - a fixed 30-file subset of the six-model symbolic run reproduces the authoritative
#     verdicts (solve_ms is timing-dependent and ignored).
# Requires JDK 21, Python 3, and the pinned jars (M2_REPO). Full corpus reruns are not
# part of this check (see README, "Full reruns").
source "$(dirname "$0")/common.sh"
setup_java_env
S="$WORK/smoke"; rm -rf "$S"; mkdir -p "$S"

# snapshot and build pins
( cd "$PKG/impl/snapshot" && sed -n '6,72p' "$PKG/impl/PIN.txt" | sha256sum -c --quiet ) \
  && pass "snapshot files match impl/PIN.txt" || fail "snapshot files vs PIN"
[ "$(sed -n '6,72p' "$PKG/impl/PIN.txt" | sha256sum | cut -c1-64)" = "$PIN_SNAPSHOT" ] \
  && pass "snapshot aggregate 04d5604b..." || fail "snapshot aggregate"
( cd "$PKG/impl/snapshot" && find src/main/java -name '*.java' | LC_ALL=C sort ) > "$S/sources.txt"
( cd "$PKG/impl/snapshot" && "$JAVAC" -nowarn -encoding UTF-8 -d "$(w "$S/classes")" -cp "$DEPS_CP" @"$(w "$S/sources.txt")" ) 2> "$S/javac.log"
[ "$(classes_hash "$S/classes")" = "$PIN_CLASSES" ] \
  && pass "fresh build of snapshot reproduces pinned classes 86f06894..." \
  || fail "fresh build classes hash $(classes_hash "$S/classes") (pinned impl/classes used below)"
CPX="$(w "$PKG/impl/classes")$SEP$DEPS_CP"
J=("$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$CPX")

# manifests and corpus files
M="$PKG/corpus/manifests"
[ "$(sha "$M/frozen-eligible-manifest.csv")" = "$PIN_MANIFEST" ] && pass "eligible manifest ae011be3..." || fail "eligible manifest hash"
$PY - "$PKG" <<'EOF' && pass "all 12,324 corpus files match frozen hashes" || fail "corpus file hashes"
import csv, hashlib, sys
P = sys.argv[1]
rows = list(csv.DictReader(open(P + '/corpus/manifests/frozen-population-12324.csv', newline='', encoding='utf-8')))
bad = [r['path'] for r in rows if hashlib.sha256(open(P + '/corpus/litmus/' + r['path'], 'rb').read()).hexdigest() != r['sha256']]
assert len(rows) == 12324 and not bad, (len(rows), bad[:3])
EOF

# historical wired hard-expression benchmark
"${J[@]}" wev.smt.cli.HardExprBenchRun "$(w "$PKG/hardbench/generated-hard-candidates.json")" "$(w "$S/generated-hard-pairs.csv")" 2 3 > "$S/hardbench.log" 2>&1
cmp -s "$S/generated-hard-pairs.csv" "$PKG/results/authoritative/rerun-2026-10-09/generated-hard-pairs.csv" \
  && pass "hard benchmark re-run byte-identical (3,656 instances)" || fail "hard benchmark output differs"

# six-model symbolic subset
$PY - "$PKG" "$S" <<'EOF'
import csv, sys
P, S = sys.argv[1], sys.argv[2]
rows = list(csv.DictReader(open(P + '/corpus/manifests/frozen-eligible-hashes.csv', newline='', encoding='utf-8')))
disc = {'Dat3M/litmus/AARCH64/SYS/LB+data+dataap.litmus', 'Dat3M/litmus/AARCH64/SYS/LB+dataaps.litmus',
        'Dat3M/litmus/AARCH64/TUTO/LB+addrs.litmus', 'Dat3M/litmus/AARCH64/TUTO/LB+datas.litmus',
        'Dat3M/litmus/PPC/DETOUR0236.litmus',
        'herdtools7/catalogue/herding-cats/ppc/tests/illustrative/LB+datas.litmus'}
pick = [r for i, r in enumerate(rows) if r['path'] in disc or i % 100 == 0]
w = csv.DictWriter(open(S + '/subset-hashes.csv', 'w', newline='', encoding='utf-8'), fieldnames=list(rows[0]))
w.writeheader(); w.writerows(pick)
print(len(pick), 'subset files')
EOF
"${J[@]}" wev.smt.cli.CorpusValidation "$(w "$PKG/corpus/litmus")" "$(w "$S/six")" \
  manifest="$(w "$S/subset-hashes.csv")" mode=symbolic csv=subset-symbolic.csv perFileSec=30 budgetMin=60 maxEvents=64 > "$S/six.log" 2>&1
$PY - "$PKG" "$S" <<'EOF' && pass "six-model subset reproduces authoritative verdicts" || fail "six-model subset"
import csv, sys
P, S = sys.argv[1], sys.argv[2]
key = lambda r: (r['file'], r['model'])
auth = {key(r): (r['result'], r['verdict']) for r in csv.DictReader(open(
    P + '/results/authoritative/ppo-repair/six-model/repaired-symbolic.csv', newline='', encoding='utf-8'))}
new = list(csv.DictReader(open(S + '/six/subset-symbolic.csv', newline='', encoding='utf-8')))
diff = [(key(r), (r['result'], r['verdict']), auth.get(key(r))) for r in new if auth.get(key(r)) != (r['result'], r['verdict'])]
print(len(new), 'rows,', len({r['file'] for r in new}), 'files,', len(diff), 'differences')
for d in diff[:10]: print('  ', d)
assert new and not diff
EOF
exit "${FAILS:-0}"
