#!/usr/bin/env python3
"""7. Re-run the recovered eligibility/correction tools and the address-index check.

Every output goes to WORK (outside the package); nothing in the package is written.
Each regenerated file is compared with its recorded counterpart; a mismatch is reported,
never substituted. See provenance/README.md for what each tool is and how it was used.

Stages (all read-only on the package):
  A  gate.py         extraction gate over the recorded parser dump  -> corpus-gate.csv
                     (gate2.py differs by one line and is only imported by outcome_gate.py)
  B  outcome_gate.py outcome-binding gate over the recorded outcome dump -> outcome-gate.csv/.txt
  C  eligibility.py + freeze.py on a WORK copy of the recorded inputs -> per-test-status,
     frozen population, eligible manifest (+ its SHA-256 pin ae011be3...)
  D  (optional, needs JDK + M2_REPO) Extract.java / OutcomeDump.java against the pinned
     classes -> events.csv, edges.csv, outcomes.csv (regenerates the dumps A-C consume)
  E  summarize_correction.py on repair/symbolic-ring-audit.csv -> benchmark-correction.json
  F  address_index_check.py on the frozen eligible manifest, and its synthetic controls

Usage: python 07_provenance.py [<package-dir>] [--with-java]
Environment: WORK (default: ../_repro-work next to the package), M2_REPO, JAVAC, JAVA.
"""
import csv
import filecmp
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

args = [a for a in sys.argv[1:] if not a.startswith('--')]
WITH_JAVA = '--with-java' in sys.argv
P = Path(args[0]).resolve() if args else Path(__file__).resolve().parent.parent
W = Path(os.environ.get('WORK', str(P.parent / '_repro-work'))).resolve() / 'provenance'
assert W != P and P not in W.parents, 'WORK must be outside the package'
if W.exists():
    shutil.rmtree(W)
W.mkdir(parents=True)
PV = P / 'provenance'
REC = PV / 'recorded'
ROOT = str(P / 'corpus' / 'litmus') + os.sep
PY = [sys.executable, '-I', '-B', '-X', 'utf8']
fails = []


def same(a, b, label):
    ok = filecmp.cmp(a, b, shallow=False)
    print(('PASS ' if ok else 'FAIL ') + label + (': identical to recorded' if ok else ': DIFFERS from recorded %s' % b))
    if not ok:
        fails.append(label)
    return ok


def run(cmd, out=None, cwd=None):
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, cwd=cwd, encoding='utf-8')
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
        raise SystemExit('command failed: %s' % cmd)
    if out:
        Path(out).write_text(r.stdout, encoding='utf-8')
    return r.stdout


# A. extraction gate
(W / 'A').mkdir()
run(PY + [PV / 'gates/gate.py', REC / 'src12324/corpus/events.csv', REC / 'src12324/corpus/edges.csv',
          ROOT, W / 'A/corpus'])
same(W / 'A/corpus-gate.csv', REC / 'src12324/corpus-gate.csv', 'A gate.py corpus-gate.csv')

# B. outcome-binding gate
(W / 'B').mkdir()
run(PY + [PV / 'gates/outcome_gate.py', REC / 'src12324/outcomes.csv', ROOT, W / 'B/outcome-gate.csv'],
    out=W / 'B/outcome-gate.txt')
same(W / 'B/outcome-gate.csv', REC / 'src12324/outcome-gate.csv', 'B outcome_gate outcome-gate.csv')
same(W / 'B/outcome-gate.txt', REC / 'src12324/outcome-gate.txt', 'B outcome_gate stdout (outcome-gate.txt)')

# C. eligibility + freeze on a WORK copy of the recorded inputs
C = W / 'C/prov'
shutil.copytree(REC / 'src12324', C / 'src12324')
shutil.copytree(REC / 'manifests', C / 'manifests')
shutil.copytree(REC / 'wiring', C / 'wiring')
shutil.copytree(REC / 'imm-repair', W / 'C/imm-repair')
run(PY + [PV / 'eligibility/eligibility.py', C, ROOT], out=W / 'C/eligibility.txt')
same(C / 'per-test-status.csv', REC / 'per-test-status.csv', 'C eligibility per-test-status.csv')
run(PY + [PV / 'eligibility/freeze.py', C, ROOT, W / 'C/imm-repair'], out=W / 'C/freeze.txt')
for f in ('frozen-population-12324.csv', 'frozen-eligible-manifest.csv', 'frozen-eligible-hashes.csv',
          'frozen-eligible-manifest.sha256'):
    same(C / f, REC / 'frozen' / f, 'C freeze ' + f)
    same(C / f, P / 'corpus/manifests' / f, 'C freeze %s vs corpus/manifests' % f)
pin = hashlib.sha256((C / 'frozen-eligible-manifest.csv').read_bytes()).hexdigest()
print(('PASS ' if pin.startswith('ae011be3') else 'FAIL ') + 'C eligible-manifest pin ' + pin)
if not pin.startswith('ae011be3'):
    fails.append('C pin')

# D. optional: regenerate the parser dumps with the pinned classes
if WITH_JAVA:
    M = Path(os.environ.get('M2_REPO', str(Path.home() / '.m2/repository')))
    sep = ';' if os.name == 'nt' else ':'
    cp = [str(P / 'impl/classes')]
    N = W / 'D/native'
    N.mkdir(parents=True)
    for line in (P / 'impl/DEPENDENCIES.txt').read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        if line.startswith('NATIVE'):
            _, h, rel, name = line.split()
            f = M / rel
            assert hashlib.sha256(f.read_bytes()).hexdigest() == h, rel
            shutil.copy2(f, N / name)
        else:
            h, rel = line.split()
            f = M / rel
            if rel.startswith('com/weakest/'):
                f = P / 'impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar'
            assert hashlib.sha256(f.read_bytes()).hexdigest() == h, rel
            cp.append(str(f))
    cls = W / 'D/classes'
    cls.mkdir()
    run([os.environ.get('JAVAC', 'javac'), '-proc:none', '-encoding', 'UTF-8', '-cp', sep.join(cp), '-d', cls,
         PV / 'gates/Extract.java', PV / 'gates/OutcomeDump.java'])
    jcp = sep.join([str(cls)] + cp)
    java = [os.environ.get('JAVA', 'java'), '-Djava.library.path=' + str(N), '-cp', jcp]
    run(java + ['Extract', REC / 'src12324/list.txt', ROOT, W / 'D/corpus'])
    run(java + ['OutcomeDump', REC / 'src12324/list.txt', ROOT, W / 'D/outcomes.csv'])
    same(W / 'D/corpus/events.csv', REC / 'src12324/corpus/events.csv', 'D Extract events.csv')
    same(W / 'D/corpus/edges.csv', REC / 'src12324/corpus/edges.csv', 'D Extract edges.csv')
    same(W / 'D/outcomes.csv', REC / 'src12324/outcomes.csv', 'D OutcomeDump outcomes.csv')
else:
    print('SKIP D (pass --with-java to regenerate the parser dumps)')

# E. benchmark-correction summary (the script writes next to itself, so run a WORK copy)
E = W / 'E'
E.mkdir()
shutil.copy2(PV / 'correction/summarize_correction.py', E)
shutil.copy2(P / 'repair/symbolic-ring-audit.csv', E)
run(PY + [E / 'summarize_correction.py'], out=E / 'stdout.txt')
got = json.loads((E / 'benchmark-correction.json').read_text())
want = json.loads((P / 'repair/benchmark-correction.json').read_text())
ok = got == want
print(('PASS ' if ok else 'FAIL ') + 'E summarize_correction benchmark-correction.json (JSON-equal to repair/)')
if not ok:
    fails.append('E json')
same(E / 'symbolic-value-consistent.csv', P / 'repair/symbolic-value-consistent.csv',
     'E summarize_correction symbolic-value-consistent.csv')

# F. address-index check + controls
F = W / 'F'
run(PY + [P / 'address-check/make_controls.py', F / 'controls'])
r = subprocess.run(PY + [str(P / 'address-check/address_index_check.py'), str(F / 'controls'), str(F / 'controls/out')],
                   capture_output=True, text=True)
exp = {x['file']: x['expected'] for x in csv.DictReader(open(F / 'controls/expected.csv', encoding='utf-8'))}
got = {x['file']: x['status'] for x in csv.DictReader(open(F / 'controls/out/address-index-classification.csv', encoding='utf-8'))}
bad = [f for f in exp if exp[f] != got.get(f)]
print(('PASS ' if not bad else 'FAIL ') + 'F controls %d/%d match expected' % (len(exp) - len(bad), len(exp)))
if bad:
    fails.append('F controls')
r = subprocess.run(PY + [str(P / 'address-check/address_index_check.py'), str(P), str(F / 'corpus')],
                   capture_output=True, text=True)
print('  ' + r.stdout.strip())
if r.returncode != 0:
    fails.append('F corpus: demonstrated nonzero offset')
for f in ('address-index-classification.csv', 'address-index-traces.txt', 'address-index-summary.json'):
    same(F / 'corpus' / f, P / 'address-check/recorded' / f, 'F address check ' + f)

print('SUMMARY: %d failed check(s)%s' % (len(fails), (': ' + ', '.join(fails)) if fails else ''))
sys.exit(len(fails))
