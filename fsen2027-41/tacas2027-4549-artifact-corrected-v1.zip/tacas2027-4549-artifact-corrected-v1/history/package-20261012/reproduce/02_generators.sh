#!/usr/bin/env bash
# 2. Generators reproduce the recorded inputs (deterministic; no solver, no timing).
source "$(dirname "$0")/common.sh"
G="$WORK/generators"; rm -rf "$G"; mkdir -p "$G"

# (a) hard benchmark: RECONSTRUCTED enumerate/filter step vs the recorded candidate file
$PY "$PKG/hardbench/reconstructed/enumerate_candidates_RECONSTRUCTED.py" "$G/candidates.json" 2> "$G/enumerate.log"
cat "$G/enumerate.log"
grep -q 'intermediate forms: 13880  retained: 1828' "$G/enumerate.log" \
  && pass "hard benchmark: 13,880 intermediate forms, 1,828 retained" || fail "hard benchmark counts"
cmp -s "$G/candidates.json" "$PKG/hardbench/generated-hard-candidates.json" \
  && pass "hard benchmark: reconstructed candidates byte-identical to recorded input" \
  || fail "hard benchmark: candidates differ from recorded input"

# (b) chain-composition population and hand-validation cases
C="$PKG/chain-composition"
$PY "$C/gen.py" "$C/design.json" "$G/chain" > "$G/chain-gen.log"
$PY "$C/hand_cases.py" "$G/chain-validation" > "$G/chain-hand.log"
cat "$G/chain-gen.log" "$G/chain-hand.log"
for f in manifest.json queries.tsv; do
  cmp -s "$G/chain/$f" "$C/results/generated/$f" && pass "chain: $f identical" || fail "chain: $f differs"
done
diff -rq "$G/chain/inputs" "$C/results/generated/inputs" >/dev/null \
  && pass "chain: 256 generated litmus inputs identical" || fail "chain: inputs differ"
for f in hand.json queries.tsv; do
  cmp -s "$G/chain-validation/$f" "$C/results/validation/$f" && pass "chain hand cases: $f identical" || fail "chain hand cases: $f differs"
done
diff -rq "$G/chain-validation/inputs" "$C/results/validation/inputs" >/dev/null \
  && pass "chain hand cases: inputs identical" || fail "chain hand cases: inputs differ"
( cd "$G/chain" && sha256sum manifest.json queries.tsv inputs/*.litmus ) | sed 's/ \*/  /' > "$G/sums.txt"
sed 's/ \*/  /' "$C/results/generated-SHA256SUMS" | diff -q - "$G/sums.txt" >/dev/null \
  && pass "chain: matches recorded generated-SHA256SUMS" || fail "chain: generated-SHA256SUMS mismatch"
exit "${FAILS:-0}"
