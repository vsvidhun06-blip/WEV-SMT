#!/usr/bin/env bash
# 1. Build both Isabelle sessions from a copy of isabelle/ and check for proof holes.
# Requires ISABELLE_HOME = an Isabelle2024 installation. On Windows the POSIX launcher is
# run through Isabelle's bundled Cygwin bash (contrib/cygwin/bin/bash.exe).
source "$(dirname "$0")/common.sh"
: "${ISABELLE_HOME:?set ISABELLE_HOME to an Isabelle2024 installation}"
D="$WORK/isabelle"; rm -rf "$D"; cp -r "$PKG/isabelle" "$D"

$PY "$PKG/reproduce/check_holes.py" "$D"/*.thy "$D"/pwt/*.thy \
  && pass "no 'sorry' or 'oops' outside comments in any theory" || fail "proof holes (listed above)"
# Isabelle's default quick_and_dirty=false additionally makes any 'sorry' a build error.

CYG="$ISABELLE_HOME/contrib/cygwin/bin/bash.exe"
if [ -x "$CYG" ] && command -v cygpath >/dev/null 2>&1; then
  IH="$(cygpath -m "$ISABELLE_HOME")"; DD="$(cygpath -m "$D")"
  "$CYG" --login -c "cd \"\$(cygpath -u '$DD')\" && \"\$(cygpath -u '$IH')/bin/isabelle\" build -c -v -o timeout=600 -d . WEV_SMT WEV_SMT_PwT" \
    > "$WORK/isabelle-build.log" 2>&1 && rc=0 || rc=$?
else
  ( cd "$D" && "$ISABELLE_HOME/bin/isabelle" build -c -v -o timeout=600 -d . WEV_SMT WEV_SMT_PwT ) \
    > "$WORK/isabelle-build.log" 2>&1 && rc=0 || rc=$?
fi
tail -5 "$WORK/isabelle-build.log"
[ "$rc" = 0 ] && pass "isabelle build WEV_SMT WEV_SMT_PwT (exit 0)" || fail "isabelle build exit $rc (see $WORK/isabelle-build.log)"
exit "${FAILS:-0}"
