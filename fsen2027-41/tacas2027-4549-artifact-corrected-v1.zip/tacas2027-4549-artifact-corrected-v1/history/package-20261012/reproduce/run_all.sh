#!/usr/bin/env bash
# Run every reproduction check in order and summarise. Each stage is also runnable alone.
#   ISABELLE_HOME=<Isabelle2024>  M2_REPO=<maven repo>  WORK=<scratch dir>  bash reproduce/run_all.sh
# Set SKIP_ISABELLE=1 or SKIP_JAVA=1 to skip the stages that need those toolchains.
HERE="$(cd "$(dirname "$0")" && pwd)"
source "$HERE/common.sh"
set +e
declare -A RC
stage() { echo; echo "===== $1"; bash "$HERE/$2"; RC[$1]=$?; }
stage "0 manifest"   00_manifest.sh
if [ "${SKIP_ISABELLE:-0}" = 1 ]; then RC["1 isabelle"]=skipped; else stage "1 isabelle" 01_isabelle.sh; fi
stage "2 generators" 02_generators.sh
stage "3 chain"      03_chain.sh
if [ "${SKIP_JAVA:-0}" = 1 ]; then RC["4 impl smoke"]=skipped; else stage "4 impl smoke" 04_impl_smoke.sh; fi
echo; echo "===== 5 claims"; WORK="$WORK" $PY "$HERE/05_claims.py" "$PKG" | tail -1; RC["5 claims"]=${PIPESTATUS[0]}
echo; echo "===== 7 provenance"; JAVA_FLAG=; [ "${SKIP_JAVA:-0}" = 1 ] || JAVA_FLAG=--with-java
WORK="$WORK" $PY "$HERE/07_provenance.py" "$PKG" $JAVA_FLAG | tail -1; RC["7 provenance"]=${PIPESTATUS[0]}
echo; echo "===== SUMMARY (0 = all checks passed; n = number of failed checks)"
for k in "0 manifest" "1 isabelle" "2 generators" "3 chain" "4 impl smoke" "5 claims" "7 provenance"; do echo "  $k: ${RC[$k]}"; done
