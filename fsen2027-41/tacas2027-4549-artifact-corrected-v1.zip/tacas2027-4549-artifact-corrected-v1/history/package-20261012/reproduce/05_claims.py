"""5. Every empirical claim of the paper resolves to a packaged artifact.

For each claim this script opens the packaged file(s) and RECOMPUTES the figure the paper
states; it never trusts a pre-computed summary when the underlying rows are packaged.
Categories: AUTH = authoritative repaired run; CARRIED = earlier run on unchanged inputs,
cited as such by the paper; RECORD = recorded experiment the paper says is not
re-derivable; RECON = reconstructed generator; CHAIN = chain-composition experiment.
Usage: python 05_claims.py [<package-dir>]   (writes CLAIMS-CHECK.txt to $WORK if set)
"""
import collections
import csv
import json
import os
import re
import statistics
import sys
from pathlib import Path

P = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
AU = P / 'results/authoritative/rerun-2026-10-09'
PR = P / 'results/authoritative/ppo-repair'
CA = P / 'results/carried'
C = collections.Counter
rows_out, fails = [], 0


def rd(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def claim(cid, where, cat, path, statement, expected, compute):
    global fails
    files = [path] if isinstance(path, (str, Path)) else path
    missing = [str(f) for f in files if not (P / f).exists()]
    try:
        got = None if missing else compute()
        ok = not missing and got == expected
    except Exception as ex:  # noqa: BLE001
        got, ok = f'ERROR {ex!r}', False
    fails += not ok
    rows_out.append((('PASS' if ok else 'FAIL'), cid, where, cat, statement,
                     ' + '.join(str(f) for f in files), repr(expected) if ok else f'expected {expected!r} got {got!r}'))


pop = rd(P / 'corpus/manifests/frozen-population-12324.csv')
el = [r for r in pop if r['status'] == 'ELIGIBLE']
sym = rd(PR / 'six-model/repaired-symbolic.csv')
V = {(r['file'], r['model']): r['verdict'] for r in sym}
files = sorted({r['file'] for r in sym})
MODELS = ['SC', 'TSO', 'PSO', 'RA', 'WEAKEST', 'RC11']

claim('P1', '§6.1', 'AUTH', 'corpus/manifests/frozen-population-12324.csv',
      'sample 12,324 = herd7 4,324 + Dat3M 8,000', (12324, 4324, 8000),
      lambda: (len(pop), sum(r['path'].startswith('herdtools7/') for r in pop), sum(r['path'].startswith('Dat3M/') for r in pop)))
claim('P2', '§6.1', 'AUTH', 'corpus/manifests/frozen-population-12324.csv',
      'eligible 2,396; excluded 9,744 unsupported / 173 known mis-encoded / 11 unchecked',
      {'ELIGIBLE': 2396, 'EXPLICITLY-UNSUPPORTED': 9744, 'KNOWN-INCORRECT': 173, 'UNCHECKED': 11},
      lambda: dict(C(r['status'] for r in pop)))
claim('P3', '§6.1', 'AUTH', 'corpus/manifests/frozen-population-12324.csv',
      'eligible: 2,312 distinct programs; AArch64 1,058, C 633, PPC 603, x86 102',
      (2312, {'ARM': 1058, 'C': 633, 'PPC': 603, 'X86': 102}),
      lambda: (len({r['norm_sha256'] for r in el}), dict(C(r['arch'] for r in el))))
claim('P4', 'App. A.6', 'AUTH', ['corpus/manifests/frozen-eligible-manifest.csv', 'corpus/manifests/frozen-eligible-manifest.sha256'],
      'eligible manifest SHA-256 ae011be3...', 'ae011be3',
      lambda: __import__('hashlib').sha256((P / 'corpus/manifests/frozen-eligible-manifest.csv').read_bytes()).hexdigest()[:8])
claim('E1', '§6.4', 'AUTH', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv',
      'symbolic ALLOWED/FORBIDDEN: SC 36/2360, TSO 563/1833, PSO 1170/1226, RA 2089/307, WEAKEST 2356/40, RC11 2169/227',
      {'SC': (36, 2360), 'TSO': (563, 1833), 'PSO': (1170, 1226), 'RA': (2089, 307), 'WEAKEST': (2356, 40), 'RC11': (2169, 227)},
      lambda: {m: (sum(V[(f, m)] == 'ALLOWED' for f in files), sum(V[(f, m)] == 'FORBIDDEN' for f in files)) for m in MODELS})
claim('E2', '§6.4', 'AUTH', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv',
      'seven derivable implications: 0 violations on 2,396 files', 0,
      lambda: sum(V[(f, a)] == 'ALLOWED' and V[(f, b)] == 'FORBIDDEN' for f in files for a, b in
                  [('SC', 'TSO'), ('SC', 'PSO'), ('SC', 'RA'), ('SC', 'WEAKEST'), ('SC', 'RC11'), ('RC11', 'WEAKEST'), ('PSO', 'RA')]))
claim('E3', '§6.4', 'AUTH', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv',
      '187 files WEAKEST-ALLOWED but RC11-FORBIDDEN, none in reverse', (187, 0),
      lambda: (sum(V[(f, 'WEAKEST')] == 'ALLOWED' and V[(f, 'RC11')] == 'FORBIDDEN' for f in files),
               sum(V[(f, 'RC11')] == 'ALLOWED' and V[(f, 'WEAKEST')] == 'FORBIDDEN' for f in files)))


def wired_diff():
    W = {(r['file'], r['model']): r['verdict'] for r in rd(PR / 'six-model/repaired-wired-847.csv')}
    wf = sorted({k[0] for k in W})
    return len(wf), {m: sum(W[(f, m)] != V[(f, m)] for f in wf) for m in MODELS}, \
        {(W[k], V[k]) for k in W if W[k] != V[k]}


claim('E4', 'App. A.6', 'AUTH', ['results/authoritative/ppo-repair/six-model/repaired-wired-847.csv', 'corpus/manifests/wired-847-hashes.csv'],
      'wired mode on 847 files differs: SC 0, TSO 1, PSO 16, RA 44, WEAKEST 44, RC11 31; always wired FORBIDDEN vs symbolic ALLOWED',
      (847, {'SC': 0, 'TSO': 1, 'PSO': 16, 'RA': 44, 'WEAKEST': 44, 'RC11': 31}, {('FORBIDDEN', 'ALLOWED')}), wired_diff)


def herd_sc():
    h = {r['relpath']: r for r in rd(AU / 'herd7-frozen-results.csv')}
    comp = [f for f in files if h[f]['herd_sc'] in ('ALLOWED', 'FORBIDDEN')]
    arch = {r['file']: r['arch'] for r in sym}
    return len(comp), sum(h[f]['herd_sc'] == V[(f, 'SC')] for f in comp), dict(C(arch[f] for f in comp))


claim('E5', '§6.4', 'AUTH', ['results/authoritative/rerun-2026-10-09/herd7-frozen-results.csv', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv'],
      'herd7 7.58 sc.cat agrees on all 1,772 compared files (AArch64 1,050, PPC 603, x86 101, C 18)',
      (1772, 1772, {'ARM': 1050, 'PPC': 603, 'X86': 101, 'C': 18}), herd_sc)
claim('E6', '§6.4', 'AUTH', ['results/authoritative/ppo-repair/herd7-x86-results.csv', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv'],
      'x86tso.cat agrees on 101/101 x86 files (one herd7 error)', (101, 101, 1),
      lambda: (lambda h: (len([r for r in h if r['herd_tso'] in ('ALLOWED', 'FORBIDDEN')]),
                          sum(r['herd_tso'] == V[(r['relpath'], 'TSO')] for r in h if r['herd_tso'] in ('ALLOWED', 'FORBIDDEN')),
                          sum(r['herd_tso'] not in ('ALLOWED', 'FORBIDDEN') for r in h)))(rd(PR / 'herd7-x86-results.csv')))
sd = rd(AU / 'sdep/sdep-discriminating-all-fake-tests.csv') if (AU / 'sdep/sdep-discriminating-all-fake-tests.csv').exists() else []
claim('D1', '§6.1', 'AUTH', 'results/authoritative/rerun-2026-10-09/sdep/sdep-discriminating-all-fake-tests.csv',
      '6 of 370 fake-carrying eligible files discriminate', (370, 6),
      lambda: (len(sd), sum(r['discriminating'] == 'true' for r in sd)))
claim('D2', 'App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/sdep/sdep-discriminating-all-fake-tests.csv',
      'fake edges: address 197 in 128 files, data 368 in 285, control 0', (197, 128, 368, 285, 0),
      lambda: (sum(int(r['addr_fake']) for r in sd), sum(int(r['addr_fake']) > 0 for r in sd),
               sum(int(r['data_fake']) for r in sd), sum(int(r['data_fake']) > 0 for r in sd), sum(int(r['ctrl_fake']) for r in sd)))
claim('D3', 'App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/mutation-corpus-results.csv',
      'historical wired mutation diagnostic: 370 pairs, 5 ALLOWED/FORBIDDEN changes', (370, 5),
      lambda: (lambda m: (len(m), sum(r['discriminating'] == 'yes' for r in m)))(rd(AU / 'mutation-corpus-results.csv')))


def pairs374():
    pr = [r for r in rd(AU / 'pairs-corpus.csv') if r['cat_S']]
    shapes = {re.sub(r'R\d+', 'R', re.sub(r'\s+', '', r['composed_expr'])) for r in pr}
    return len(pr), len({r['test'] for r in pr}), dict(C(r['cat_S'] for r in pr)), dict(C(r['cat_O'] for r in pr)), len(shapes)


claim('A1', '§5.1, App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/pairs-corpus.csv',
      'closure vs composed: 374 data pairs in 290 files, 368 agree FAKE, 6 agree REAL (both configurations), 4 shapes',
      (374, 290, {'agree-FAKE': 368, 'agree-REAL': 6}, {'agree-FAKE': 368, 'agree-REAL': 6}, 4), pairs374)
claim('A2', '§5.2', 'AUTH', 'results/authoritative/rerun-2026-10-09/final-analysis.txt',
      'oracle-consistency audit: 12,067 pairs, 990 conservative, 0 unsound', ('12067', '990', '0'),
      lambda: re.search(r'total audited\s*:\s*(\d+).*?CONSERVATIVE \(sound\)\s*:\s*(\d+).*?UNSOUND \(defect\)\s*:\s*(\d+)',
                        (AU / 'final-analysis.txt').read_text(encoding='utf-8'), re.S).groups())
claim('A3', '§4.4', 'AUTH', 'results/authoritative/rerun-2026-10-09/pwt-equivalence-sweep.csv',
      'PwT per-site correspondence: 58/58 on the branch-free corpus sweep', (58, 58),
      lambda: (lambda p: (len(p), sum(r['agree'] == 'true' for r in p)))(rd(AU / 'pwt-equivalence-sweep.csv')))
claim('A4', 'App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/qfbv-detector-results.csv',
      'QF_BV detector: 0 verdict changes over 2,396 files', (2396, 0),
      lambda: (lambda q: (len(q), sum(r['changed'] == 'true' for r in q)))(rd(AU / 'qfbv-detector-results.csv')))
claim('A5', 'App. A.6', 'RECORD', ['results/carried/classifier-defect-records/ENGINEERING-SUMMARY.md', 'results/carried/classifier-defect-records/FIX.patch.md'],
      'classifier defect: 218/8448 unsound before the fix (recorded experiment; not re-derivable from the fixed tree)', True,
      lambda: '218 / 8448' in (CA / 'classifier-defect-records/ENGINEERING-SUMMARY.md').read_text(encoding='utf-8'))
hb = rd(AU / 'generated-hard-pairs.csv')


def hard():
    current = rd(P / 'repair/symbolic-ring-audit.csv')
    comparable = [r for r in current if r['value_consistency'] == 'SAT']
    def cnt(col):
        tp = sum(r[col] == 'FORBIDDEN' and r['oracle_constant'] == 'false' for r in comparable)
        tn = sum(r[col] == 'ALLOWED' and r['oracle_constant'] == 'true' for r in comparable)
        fp = sum(r[col] == 'FORBIDDEN' and r['oracle_constant'] == 'true' for r in comparable)
        fn = sum(r[col] == 'ALLOWED' and r['oracle_constant'] == 'false' for r in comparable)
        return tp, tn, fp, fn
    return len(comparable), len({r['expr'] for r in comparable}), cnt('weakest'), cnt('folding'), cnt('syntactic')

claim('H1', 'Table 2', 'AUTH', 'repair/symbolic-ring-audit.csv',
      '1,288 value-consistent rings of 644 expressions; exact 220/1068/0/0, folding 220/298/770/0, all-deps 220/0/1068/0 (TP/TN/FP/FN)',
      (1288, 644, (220,1068,0,0), (220,298,770,0), (220,0,1068,0)), hard)
claim('H2', '§6.3', 'AUTH', 'results/authoritative/rerun-2026-10-09/generated-hard-pairs.csv',
      'folding errors: 385 distinct expressions over 158 operator shapes; 149 right; 534 grounded classes; 383 shapes overall',
      (385, 158, 149, 534, 383),
      lambda: (lambda fp, gr: (len(fp), len({r['shape'] for r in hb if r['expr'] in fp}), len(gr - fp), len(gr),
                               len({r['shape'] for r in hb})))(
          {r['expr'] for r in hb if r['required'] == 'ALLOWED' and r['folding'] == 'FORBIDDEN'},
          {r['expr'] for r in hb if r['required'] == 'ALLOWED'}))
claim('H3', 'App. A.6', 'RECON', ['hardbench/reconstructed/enumerate_candidates_RECONSTRUCTED.py', 'hardbench/generated-hard-candidates.json'],
      'candidate list: 1,828 expressions (13,880 intermediate forms: run reproduce/02_generators.sh)', 1828,
      lambda: len(json.loads((P / 'hardbench/generated-hard-candidates.json').read_text())))
lk = rd(CA / 'dat3m-lkmm-hardbench.csv')
gr = rd(CA / 'dat3m-lkmm-grounded-rings.csv')
claim('H4', '§6.3, App. A.6', 'CARRIED', ['results/carried/dat3m-lkmm-hardbench.csv', 'results/carried/dat3m-lkmm-grounded-rings.csv'],
      'Dat3M v4.4.1 LKMM: 1,350 instances, matches all-dependencies on 1,350/1,350; forbids all 390 grounded rings (195 expressions)',
      (1350, 1350, 390, 390, 195),
      lambda: (len(lk), sum(r['agreement'] == 'true' for r in lk), len(gr),
               sum(r['dat3m_verdict'] == 'FORBIDDEN' for r in gr), len({r['expression_id'] for r in gr})))
ex = json.loads((AU / 'examples-results.json').read_text(encoding='utf-8'))
claim('X1', '§6.4', 'AUTH', 'results/authoritative/rerun-2026-10-09/examples-results.json',
      'published examples 31/34 symbolic (Weakestmo 8/8, PwT 5/6, JMM 18/20); Dat3M 35/41 symbolic, 31/41 wired',
      (31, 34, 18, 20, 35, 31, 41),
      lambda: (ex['published34']['symbolic_agreement'], ex['published34']['total'], ex['jmm20']['symbolic_agreement'],
               ex['jmm20']['total'], ex['dat3m41']['symbolic_agreement'], ex['dat3m41']['wired_agreement'], ex['dat3m41']['total']))
dc = rd(CA / 'dat3m-comparison-v2.csv')
claim('X2', '§6.4', 'CARRIED', 'results/carried/dat3m-comparison-v2.csv',
      'Dat3M timing: median 10 ms (WEAKEST) against 516 ms (BMC) on 41 tests', (41, 10, 516),
      lambda: (len(dc), round(statistics.median(float(r['wev_time_ms']) for r in dc)),
               round(statistics.median(float(r['dat3m_time_ms']) for r in dc))))
gp = rd(CA / 'generated-pairs-folding.csv')
claim('X3', 'App. A.6', 'CARRIED', ['results/carried/generated-pairs.csv', 'results/carried/generated-pairs-folding.csv'],
      'matched-pair sweep: 1,600 rings, 1,440 valid, 1,015 discriminating; folding agrees with WEAKEST on all 1,440 valid',
      (1600, 1440, 1015, 1440),
      lambda: (len(gp), sum(r['valid'] == 'true' for r in gp), sum(r['discriminating'] == 'true' for r in gp),
               sum(r['valid'] == 'true' and r['folding_baseline'] == r['weakest'] for r in gp)))
nt = rd(CA / 'nthread-grounded-admission.csv')
claim('X4', '§4.4', 'CARRIED', 'results/carried/nthread-grounded-admission.csv',
      'grounded-LB admission (Prop. 3(b)) SMT-verified up to eight threads', (8, {'ALLOWED'}),
      lambda: (max(int(r['n']) for r in nt), {r['verdict'] for r in nt}))


def scal():
    s = rd(CA / 'scalability-consistency.csv')
    t = {(r['family'], int(r['n'])): float(r['fullexec_ms']) for r in s if r['model'] == 'WEAKEST'}
    # ratio LBChain / LBFakeChain (real over fake) of the WEAKEST full-execution time
    rs = [t[('LBChain', n)] / t[('LBFakeChain', n)] for n in range(2, 13) if ('LBChain', n) in t and ('LBFakeChain', n) in t]
    return round(min(rs), 2), round(max(rs), 2)


claim('X5', 'App. A.6', 'CARRIED', 'results/carried/scalability-consistency.csv',
      'LBChain vs LBFakeChain WEAKEST time ratios between 0.80 and 1.70 through n=12', (0.80, 1.70), scal)
cf = rd(P / 'chain-composition/results/pairs-final.csv')


def chain():
    fake = [r for r in cf if r['C'] == 'FAKE']
    by = lambda v: [r for r in fake if r['variant'] == v]
    miss = lambda rs, c: sum(r['cat_' + c] == 'closureREAL/composedFAKE' for r in rs)
    return (len({r['id'] for r in cf}), len(cf), sum(r['C'] == 'REAL' for r in cf), len(fake),
            len(by('direct')), len(by('chain')), len(by('control')),
            miss(by('direct'), 'A'), miss(by('direct'), 'B'), miss(by('chain'), 'A'), miss(by('chain'), 'B'),
            miss(by('control'), 'A'), miss(by('control'), 'B'),
            sum(r['cat_A'] == 'closureFAKE/composedREAL' or r['cat_B'] == 'closureFAKE/composedREAL' for r in cf),
            len({(r['norm_shape'], r['k']) for r in cf}))


claim('C1', '§6.2 Table 1, App. A.6', 'CHAIN', 'chain-composition/results/pairs-final.csv',
      'chain: 256 threads, 317 pairs (171 real; fake 66 single-instruction, 72 chain, 8 control); fakes missed '
      'A/B: single 36/0, chain 72/72, control 1/1; 0 fake-where-real; 213 distinct shape/load pairs',
      (256, 317, 171, 146, 66, 72, 8, 36, 0, 72, 72, 1, 1, 0, 213), chain)
claim('C2', 'App. A.6', 'CHAIN', 'chain-composition/results/generated/manifest.json',
      'chain accounting: 236 distinct programs, 168 distinct shapes, 291 distinct program/load pairs', (236, 168, 291),
      lambda: (lambda m: (len({i['norm_program'] for i in m}), len({i['norm_shape'] for i in m}),
                          len({(r['norm_program'], r['k']) for r in cf})))(
          json.loads((P / 'chain-composition/results/generated/manifest.json').read_text())))
claim('S1', 'App. A.7', 'CARRIED', ['synthesis/claimD/claimD-synthesis.json', 'synthesis/claimD/claimD_synth.py'],
      'unrestricted-abstraction synthesis outputs present', True,
      lambda: bool(json.loads((P / 'synthesis/claimD/claimD-synthesis.json').read_text())))
THY = ['Detector', 'Soundness', 'pwt/PwT_Model', 'pwt/PwT_R4b', 'pwt/PwT_Program', 'pwt/PwT_Granularity',
       'pwt/PwT_ReadRestricted', 'pwt/PwT_Capacity', 'pwt/PwT_EventBridge', 'pwt/PwT_Control']
claim('I1', '§5.3, App. A.1', 'AUTH', ['isabelle/ROOT'] + [f'isabelle/{t}.thy' for t in THY],
      'every theory of the mechanization map is packaged; build checked by 01_isabelle.sh', True, lambda: True)

out = ['status  id   where             cat      statement  |  artifact  |  value']
out += ['  '.join(r[:4]) + f"  {r[4]}\n        -> {r[5]}\n        -> {r[6]}" for r in rows_out]
out.append(f"\n{len(rows_out) - fails}/{len(rows_out)} claims resolved and recomputed; {fails} failed")
text = '\n'.join(out)
print(text)
if os.environ.get('WORK'):
    Path(os.environ['WORK'], 'CLAIMS-CHECK.txt').write_text(text + '\n', encoding='utf-8')
sys.exit(1 if fails else 0)
