# Paper files

| File | SHA-256 | Provenance |
|---|---|---|
| `wev-smt.pdf` | `b8c8fb3428664bd70b0e9455856594aab963720c47223fc7ae8b56d507338f0b` | the manuscript PDF supplied for submission, copied byte-for-byte; 36 pages; built 2026-10-12 13:00:17 UTC by pdfTeX 1.40.27 (TeX Live 2025) |
| `wev-smt.tex` | `b058459964cca2a6a11ca8d1a7cedf18f0074b8a16b0cc7b0f9134865a0e8f58` | the manuscript source at the time of packaging |
| `refs.bib` | `f25ce89898ddb32890b3cd6f136133eaea3a42f4b83d7525f6f3ed1d40f7b447` | the bibliography (unchanged from the 2026-10-11 package) |

**The source corresponds to the PDF.** The source was rebuilt in a clean directory with
`llncs`, `splncs04` and the sequence pdflatex, bibtex, pdflatex, pdflatex, using pdfTeX
1.40.27 from MiKTeX 25.12. The rebuilt PDF has 36 pages and 40 bibliography entries, with no
undefined citations or references and no overfull boxes. Its extracted text equals the
supplied PDF's on every page, and its rendering is pixel-identical at 72 and 150 dpi.

The supplied PDF's bytes differ from the rebuild's only in build metadata (dates and engine
banner).

**Layout:**
- main body pp. 1–18;
- Appendix A pp. 19–33, with A.10 on pp. 31–33;
- Data Availability Statement p. 33;
- References pp. 33–36.

**Previous paper.** The 2026-10-11 package shipped a 34-page version: tex `e1a4958d…`, pdf
`02835018…`. The current source changes the following:
- adds App. A.10 "Evidence traceability notes" (with Table 4);
- adds cross-references to A.10 from §§4.4, 5.2, 6.1, 6.3 and 6.4;
- clarifies the mechanized `Soundness` theorem versus Prop. 3(a), and the
  (A2)/(A3) consistency wording;
- in App. A.6, defines "operator shape" and "grounded ring";
- renames the Table 2 column "correct" to "agree" and rewords its caption (the 2,368
  value-inconsistent outcomes are still stated in §6.3 and App. A.6);
- makes minor wording changes in §1 and §6.

No previously reported figure changes. A.10 adds traceability counts:
- 60 distinct classifier decisions;
- 34 example files that are 28 distinct programs;
- the per-test Table 4.
