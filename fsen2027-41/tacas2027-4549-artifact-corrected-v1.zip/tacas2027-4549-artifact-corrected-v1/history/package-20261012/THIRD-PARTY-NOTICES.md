# Third-party material

**Original material.** `LICENSE` covers the original code and data of this artifact:
- the implementation snapshot and classes;
- the Isabelle theories;
- the drivers, generators, chain-composition experiment and synthesis scripts;
- the result files;
- the documentation.

**Redistributed under the upstream terms, with notices kept verbatim:**
- `corpus/litmus/Dat3M/**`: Dat3M / Dartagnan litmus tests. MIT-style licence; see
  `corpus/litmus/Dat3M/LICENCE`.
- `corpus/litmus/herdtools7/**`: herdtools7 litmus tests. CeCILL-B; some catalogue
  subdirectories carry joint copyright with Arm Ltd. See
  `corpus/litmus/herdtools7/LICENSE.txt`.
- `inputs/examples/**`: example programs transcribed from the cited publications
  (Weakestmo, PwT / "The Leaky Semicolon", the Java Memory Model causality tests). They are
  used for comparison as in the paper.

**Not redistributed; pinned by SHA-256 in `impl/DEPENDENCIES.txt`:**
- JavaSMT, Z3 and its natives;
- Guava, SMTInterpol, Princess and Scala;
- the other Maven dependencies;
- herd7 and Dat3M binaries.
