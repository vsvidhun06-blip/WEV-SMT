# Anonymization record

Changes were applied to **package copies only**. No identity is reproduced here.

| Category | Files | Replacements | Replacement text |
|---|---|---|---|
| absolute paths into the local Maven repository | 1 (`impl/PIN.txt`) | 27 | `<M2_REPO>` |
| absolute paths into the measurement work area | 8 (`drivers/ppo-repair/remeasure.sh`, four `*.config.txt` run records, `impl/PIN.txt`; since 2026-10-12 also `evidence/logs/pwt.log` (2) and `evidence/logs/oracle-audit.log` (1)) | 13 | `<AUDIT_ROOT>` |
| absolute paths into the implementation checkout | 1 (`impl/PIN.txt`) | 2 | `<IMPL_ROOT>` |
| version-control commit identifiers of the development repository | 2 (`impl/PIN.txt`, `chain-composition/results/build-provenance.txt`) | 2 | `<redacted-commit>` |

`impl/PIN.txt` is counted in each category in which it had replacements.

## Checked and found clean

- **Personal names, account names, e-mail addresses, affiliations.** No occurrence remains
  in any text file, binary, class file or jar. This was checked by a case-insensitive scan of
  every packaged file, binaries included. The upstream litmus files were scanned too.
- **Repository links.** No URL of the development repository appears.
- **Paper PDF.** The author, title, subject and keywords metadata are empty, and there are
  no embedded paths. The producer and creation date are the TeX engine defaults.
- **Licence.** The packaged `LICENSE` names "The WEV-SMT Authors" only. Upstream licences
  and copyright notices (herdtools7, Dat3M) are preserved verbatim.

## Effect on hashes

- **`impl/PIN.txt` no longer hashes as recorded.** The aggregates it states are unaffected,
  because they are computed over the snapshot lines and the class files, which were not edited.
- **The `*.config.txt` run records** differ from the originals only in the placeholder paths.

## Residual risk (not changed, because changing it would invalidate pinned hashes)

**Code and package names.** The Java packages (`wev.smt`, `com.weakest`), the Maven
coordinates and the tool name "WEV-SMT" are compiled into the pinned classes and jars.
They coincide with the name of a public development repository. Renaming them would break
the hash pins that identify the evaluated implementation. Whether to rename for review is a
decision for the authors.
