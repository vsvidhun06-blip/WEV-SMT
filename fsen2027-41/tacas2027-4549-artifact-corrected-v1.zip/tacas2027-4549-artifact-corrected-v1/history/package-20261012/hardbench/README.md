# Hard-expression benchmark inputs (Table 2)

| File | Status |
|---|---|
| `generated-hard-candidates.json` | **original recorded input**: 1,828 expressions (SHA-256 `096470c8…`) |
| `reconstructed/enumerate_candidates_RECONSTRUCTED.py` | **reconstructed** enumerate/filter step; not the original script |

**The original generator is lost.** The enumerate-and-filter step that produced the
candidate list was run outside the development tree, and it is absent from every local
source we searched:
- the implementation tree;
- the audit directories;
- the session scratch areas;
- the archives.

**How the reconstruction was made.** It was written afterwards from two sources: the rules
stated in the paper (App. A.6, *Enumeration*) and the structure of the recorded file.

**Why it is accepted.** It reproduces the recorded file byte-for-byte (order, CRLF line
endings and the absent final newline included), and the recorded intermediate population
of **13,880** forms. `reproduce/02_generators.sh` checks both.

## Generation and filtering rules (as reconstructed)

**Form.** Parenthesis-free infix expressions, evaluated with C precedence (`*` > `+ -` > `&` > `^`, left-associative) in 32-bit wrap-around arithmetic.

**Two binary operators.**
- Leaves: `r, ~r, 0, 1, 2, 3, 7, 255`.
- Operators: `+ - * & ^`.

**Three binary operators.**
- Leaves: `r, ~r, 0, 1`.
- Operators: `& * ^`, in that order.

**Enumeration order.**
- All two-operator forms come first.
- Leaves vary in product order, first leaf slowest.
- Within each leaf tuple, operators vary in product order.

**Intermediate population.** Forms mentioning the register: 7,400 + 6,480 = **13,880**.

**Retention.** Keep a form iff its value at `r = 0` is `1`, which gives **1,828**. This is a
wiring requirement and consults no classifier.

**Determinism.** Generation is fully deterministic. Table 2 itself is deterministic as well:
its CSV has no timing column, and stage 4 re-runs it byte-identically.

**Correction to the paper's wording.** The paper's description lists the bitwise-or exclusion
and the atoms. The reconstruction makes one further restriction explicit: the three-operator
forms use only the leaves `r, ~r, 0, 1` and the operators `& * ^`. That restriction is what
reconciles the paper's "13,880" with a direct product count over the full atom set.
