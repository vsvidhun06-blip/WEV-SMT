# Artifact: *The Limits of Instruction-Local Dependency Summaries, with an Application to Thin-Air Reads*

TACAS 2027 submission #4549. Artifact package **corrected-v1**, 2026-10-19.

> **CORRECTION NOTICE: read `CORRECTION-NOTICE.md` first.**
> - After submission, an implementation defect was found in the encoder's well-formedness constraints (finding F-01). It made **12 of 14,376 corpus verdicts wrong**: 3 files × PSO/RA/WEAKEST/RC11, all FORBIDDEN where ALLOWED is correct.
> - Four model totals printed in §6.4 of the submitted paper are therefore wrong:

> | | PSO | RA | WEAKEST | RC11 |
> |---|---|---|---|---|
> | submitted | 1,170 / 1,226 | 2,089 / 307 | 2,356 / 40 | 2,169 / 227 |
> | corrected | 1,173 / 1,223 | 2,092 / 304 | 2,359 / 37 | 2,172 / 224 |
>
> - SC, TSO, the implications, the 187/0 split, the six discriminators, the chain experiment and Table 2 are verified unchanged.
> - The notice also corrects the interpretation of several other results:
>   - the LB-real transcription;
>   - the value-driven published-example agreements;
>   - the earlier sweep's value consistency;
>   - wired versus symbolic modes;
>   - Proposition 1's scope;
>   - the claim-checker coverage.
> - This package keeps the **submitted** implementation and results unchanged, and adds the **corrected** implementation and results beside them (`VERSION-MAP.md`).
> - The submitted paper is unchanged. A proposed correction is included, labelled NOT SUBMITTED.

## What is here

This package lets a researcher check the paper's claims without access to the development history. It contains:
- the Isabelle/HOL development;
- the exact source snapshot and compiled classes of the **submitted** implementation, identified by hashes;
- the **corrected v1** implementation, with its own pins;
- all third-party jars and the Z3 natives for Windows and Linux;
- the frozen corpus with hashes;
- the generators, drivers and adapters;
- the authoritative and corrected outputs;
- the audit and correction records;
- the submitted paper and a proposed correction.

Everything is a copy. The reproduction scripts write only to an external `WORK` directory and refuse a `WORK` inside the package.

| Path | Contents |
|---|---|
| `CORRECTION-NOTICE.md` | the corrections, with evidence pointers (**read first**) |
| `VERSION-MAP.md` | submitted versus corrected: implementations, results, and which command runs which |
| `INSTALL.md`, `INSTALL-LINUX.md` | requirements and installation (Linux, Windows, container) |
| `VERIFICATION-SUMMARY.md` | what was run on this package, with statuses and measured runtimes |
| `paper/submitted/` | the **exact submitted PDF** (37 pp.), its source and bibliography |
| `paper/proposed-correction-NOT-SUBMITTED/` | proposed patch and a stamped build. **Not** the paper under review |
| `impl/` | the **submitted** build: `snapshot/`, `classes/`, `PIN.txt`, `DEPENDENCIES.txt`, `deps/` (model jar, its source and provenance) |
| `impl-corrected-v1/` | the **corrected** build: `snapshot/`, `classes/`, `PIN.txt`, `CORRECTION.diff`, `README.md` |
| `deps/` | bundled Maven artifacts, the Z3 natives (Windows and Linux x64), licences and manifests |
| `isabelle/` | `ROOT` and all theories (two sessions); identical for both builds |
| `corpus/litmus/`, `corpus/manifests/` | the **12,324** sampled litmus files (herdtools7 4,324 + Dat3M 8,000) with upstream licences; the frozen population, the eligible manifest (2,396; `ae011be3…`) and the 847-file wired subset |
| `inputs/examples/` | published example programs (unchanged) |
| `inputs/diagnostic-added-2026-10/` | `LB-copy.litmus`, a **labelled diagnostic input** added in 2026-10 (not original evidence) |
| `results/` | `authoritative/`, `carried/`, `superseded/` (submitted build, unchanged) and `corrected-v1/` (see `results/README.md`) |
| `correction-record/` | curated evidence of the 2026-10-17 audit and the 2026-10-18 investigation (probes, counterexamples, reference checker, verdict diffs) |
| `drivers/`, `hardbench/`, `chain-composition/`, `synthesis/`, `repair/`, `provenance/`, `address-check/`, `evidence/` | as in the 2026-10-12 package (see their READMEs) |
| `reproduce/` | the checks (below) |
| `tools/` | `setup-linux-toolchain.sh` and `docker/Dockerfile` |
| `history/package-20261012/` | verbatim copies of every 2026-10-12 file this package modified, plus that package's `SHA256SUMS` |
| `CHANGES-v1.md` | every difference from the 2026-10-12 package |
| `ERRATA.md`, `LIMITATIONS.md`, `ANONYMIZATION.md`, `LICENSE`, `THIRD-PARTY-NOTICES.md` | as named |

## Quick start

**Linux x86_64 (tested on Ubuntu 24.04 under WSL2; see `INSTALL-LINUX.md`):**
```
bash tools/setup-linux-toolchain.sh ~/wev-tools          # JDK 21, Isabelle2024, z3-solver; hash-pinned, no sudo
export PATH=~/wev-tools/jdk-21.0.10+7/bin:$PATH PYTHON=~/wev-tools/pyenv/bin/python ISABELLE_HOME=~/wev-tools/Isabelle2024
export WORK=~/wev-work                                   # must be OUTSIDE this directory
bash reproduce/run_all.sh; echo "exit status: $?"        # 0 = no stage failed
```

**Windows x64 (Git Bash; tested on Windows 11):** see `INSTALL.md`. Use the same command with `PYTHON=python` and `ISABELLE_HOME` set to an Isabelle2024 installation.

**Early light review (smoke test):** run `SKIP_ISABELLE=1 bash reproduce/run_all.sh`. It runs every stage except the Isabelle build, with stage 6 in smoke mode and stage 10 in rows mode.

**Measured wall-clock times** (`VERIFICATION-SUMMARY.md`):
- default run, Isabelle included: about 9 minutes (Linux) to 15 minutes (Windows);
- `RUN_FULL=1` (adds both full Table 2 audits and the full six-model reruns of both builds): 26 minutes (Linux) to 42 minutes (Windows).

## Reproduction stages (`reproduce/`)

`run_all.sh` runs them in order and prints a summary. Each stage is **PASS**, **PARTIAL** (some checks skipped; not a pass), **SKIPPED** (not a pass) or **FAIL**.
- The exit status is non-zero if any stage failed.
- `REQUIRE_ALL=1` also fails on skipped checks.
- Logs go to `$WORK/logs/`.

| Stage | Script | Build | Checks |
|---|---|---|---|
| 0 | `00_manifest.sh` | — | every file matches `SHA256SUMS` |
| 1 | `01_isabelle.sh` | — | both Isabelle sessions build clean; no `sorry`/`oops`. Isabelle's user directory is isolated in `$WORK` |
| 2 | `02_generators.sh` | — | the hard-benchmark candidate list (reconstructed generator) and the chain inputs regenerate byte-identically |
| 3 / 3c | `03_chain.sh` | submitted / corrected | chain experiment: deterministic outputs byte-identical; witness values compared modulo z3's choice, each execution-confirmed |
| 4 | `04_impl_smoke.sh` | submitted | snapshot and class pins; a fresh build reproduces `86f06894…`; all corpus hashes; historical wired benchmark byte-identical; 30-file six-model subset |
| 5 | `05_claims.py` | both | part 1: the paper's 31 claims vs submitted rows (26 recomputed, 3 summary-matched, 2 presence-only); part 2: corrected-v1 figures recomputed from corrected rows |
| 6 / 6c | `06_repair.py --impl …` | submitted / corrected | Table 2 symbolic ring audit: smoke (6 rows) by default, full (3,656 rows) with `RUN_FULL=1` |
| 7 | `07_provenance.py` | submitted (parser) | eligibility gates, eligible manifest, Table 2 partition, address-offset check, parser dumps |
| 8 | `08_corrected_build.sh` | corrected vs submitted | corrected pins; a fresh build reproduces `abf33814…`; the change is confined to 2 sources and 3 classes; F-01 probes under both builds; corrected 30-file subset; model-jar source correspondence |
| 9 | `09_unit_tests.sh` | both | submitted 123/123; corrected 140/140; the new regression tests fail on the submitted build in exactly the 7 defect-specific tests |
| 10 | `10_results.py [--rerun]` | both | submitted versus corrected six-model results: exactly 12 cells; totals; SC/TSO, implications, 187/0, herd7 rows (not re-run), wired table, discriminators, Table 2. `--rerun` re-runs both builds on the full population |
| 11 | `11_reference.sh` | both | separate relational reference checker (shares the parser, Z3 value reasoning and transcribed model rules) = corrected verdicts on all 14,376 cells |

Toolchain used for the recorded and corrected results:
- OpenJDK 21.0.10 (Temurin);
- Z3 4.13.0 via JavaSMT 5.0.1;
- Isabelle2024;
- Python 3.11 with z3-solver 5.0.0.0 (Windows 11);
- for the Linux test: Python 3.12, the same JDK and z3-solver versions, Ubuntu 24.04 (WSL2);
- herd7 7.58, for the recorded herd7 comparison only. It is **not** re-run by the package.

## Reproducibility status: PARTIAL (unchanged in scope from the 2026-10-12 package)

**Reproduces from this package alone:**
- the Isabelle sessions;
- the inputs, byte-identically;
- the chain experiment;
- Table 2 (both builds);
- the six-model verdicts of both builds, on the 30-file subsets or, with `RUN_FULL=1`, on all 2,396 files;
- the claim figures;
- the eligibility chain;
- the address-offset check;
- the unit and regression tests;
- the reference-checker comparison.

**Does not reproduce** (see `LIMITATIONS.md`):
- the lost original hard-benchmark generator (a labelled reconstruction reproduces its output exactly);
- carried results (n-thread admission, scalability, Dat3M timings and LKMM comparison, matched-pair sweep, synthesis);
- the pre-fix classifier-defect measurement (a recorded experiment);
- herd7, Dat3M and DFSan runs, which are external tools whose outputs are checked as recorded rows only.

**The evaluated (submitted) tree is identified by hashes, not by a revision.** It was an uncommitted working tree. It is identified by snapshot aggregate `04d5604b133bc7d7…`, classes aggregate `86f068947142ad3e…`, and the jar and native hashes in `impl/PIN.txt`. The corrected tree is identified by `impl-corrected-v1/PIN.txt`.

## Full reruns

The authoritative corpus results took about 7 to 8 minutes per symbolic run and about 2 minutes per wired run on the recorded machine. `python reproduce/10_results.py <pkg> --rerun` re-runs both builds with the authoritative settings (`perFileSec=30 budgetMin=600 maxEvents=64`) and compares the verdicts.

**Other drivers** (paths are placeholders such as `<AUDIT_ROOT>`, `<IMPL_ROOT>`, `<M2_REPO>`, `$OPAM_ROOT`; set them before running):
- `drivers/final-rerun/rerun.sh` produced the dependency audits, the 374-pair comparison, the published examples and the historical wired hard-benchmark table.
- `run_herd7_frozen.sh` produced the herd7 comparison.
- `final_analysis.py` produced `results/authoritative/rerun-2026-10-09/final-analysis.txt`.

Run the drivers, `synthesis/claimD/*.py` and `repair/validate_dfsan.py` **on a copy** of the package: some write next to themselves (audit finding F-17).

Verdict columns are deterministic. `solve_ms`, `C_ms`, `query_ms`, `*_time_ms` and similar columns are timing-dependent.

## TACAS 2027 artifact requirements (as checked on 2026-10-19)

**Confirmed for 2027** (etaps.org/2027 TACAS page and ETAPS 2027 joint call):
- Artifact evaluation is **voluntary for research and case-study papers**, after acceptance. The deadline is 11 Jan 2027 and notification is 11 Feb 2027.
- It is **mandatory for tool and tool-demonstration papers**: deadline 29 Oct 2026, outcome considered in the acceptance decision.
- AE chairs: Mirco Giacobbe and Bettina Könighofer.
- The detailed 2027 artifact instructions (VM image, submission system, form fields) were **not yet published**. "For specific instructions regarding artifacts, see the web pages of the individual conferences."

**Older-year guidance, not confirmed for 2027:**
- TACAS 2025 used an Ubuntu 22.04 VM with OpenJDK 8 (submission via EasyChair, artifact abstract).
- TACAS 2026 used an Ubuntu 25.04 VM (amd64/arm64) with `default-jdk`, submission via HotCRP, and Docker as an alternative.
- Both years required a `LICENSE` and a `README` with smoke-test instructions, and asked for a permanent DOI (e.g. Zenodo) for the Available badge.

**What this package does regardless of the VM:**
- It does not rely on the VM's JDK. Its classes target Java 21, and `tools/setup-linux-toolchain.sh` installs Temurin 21 in user space.
- It bundles all Maven dependencies, the Linux natives and the licences.

## Known documentation discrepancies (pinned or recorded files left unedited)

These files are part of pinned hashes or recorded evidence. They were **not edited**; their correct reading is given here.
- `isabelle/ROOT` L33–34 and `isabelle/pwt/PwT_R4b.thy` L8–10, L32–36 speak of "per-site equivalence" and "the universal-v check the paper attributes to R4b". The paper uses the observation-anchored transcription. The program-level PwT correspondence is an **inclusion**, not an equality. The theories also cite files that are not packaged.
- `impl/snapshot/.../EventStructureEncoder.java` `relaxedPoConstraints` Javadoc claims that dropping cross-location W→W and W→R edges "does not weaken any model". The kept R→W and R→R edges re-imposed the dropped order (C-1). The corrected snapshot's Javadoc is rewritten.
- `MinimalWitnessExtractor` (submitted) says the two encoders "relax identically". They did not: the extractor kept fence edges. Corrected in `impl-corrected-v1`.
- `LitmusParser.java` L136 ("`sdep_impl = sdep_true` exactly"), `SYMBOLIC_RF_DESIGN.md` L3 ("design only, not implemented"; it is implemented), `SmtBackend.java` (an empty class whose Javadoc claims lifecycle ownership), `PwtEquivalenceSweep` ("exactly PwT's criterion"), `RaFormalAtlasRun` ("chain closes"; the RA⇒WEAKEST rung fails by design), `LitmusCorpus.loadFrom`, and `DetectorOracleAuditTest` ("2972-test corpus", `eval/run_all.py`) are stale or over-strong comments. They are identical in both snapshots, to keep the corrected change minimal.
- `results/authoritative/rerun-2026-10-09/qfbv-summary.md` L3, L11, L31 ("exact", "ground truth"): QfbvDetectorRun is structurally blind via the `!mentionsReg` short-circuit. `sdep-fake-summary.md` L3 ("2 998 tests") describes an older corpus; the run covers 370 fake-carrying files of the 2,396.
- `final-analysis.txt` L75 "fake 0, semantic 0" should read 565 and 6: `final_analysis.py` reads the wrong columns.
- `examples-results.json` contains blocks carried from 2026-08-06 (2,972-file corpus).
- `results/carried/dat3m-lkmm-README.md` L5–7 gives a 1,350/1,350 headline, superseded in the paper by the 438-instance subset.
- `results/carried/generated-pairs-summary.md` lacks the value-consistency caveat: 425/1,440 and 385/1,015 (C-5).
- `chain-composition/REPORT.md` L227 says "byte-identical": that holds for deterministic outputs only (C-8).
- `inputs/examples/jmm/TC18.litmus` has a comment citing absent `eval/*.md` files.
- `hardbench/reconstructed/…RECONSTRUCTED.py` cites `check_reconstruction.py`, which is not packaged; stage 2 performs both of its checks.
- Some `reproduce/05_claims.py` location labels (C1/C2 "App. A.6", S1 "App. A.7") were stale in the 2026-10-12 checker. They are corrected here to A.8 and A.9.

## Earlier notes, verbatim from the 2026-10-12 README

Paths in these notes refer to the 2026-10-12 layout. Under the corrected-v1 layout, run `python reproduce/06_repair.py <package-dir> --impl submitted --smoke`.

## Symbolic-benchmark correction and external tool check

Read repair/README.md. The paper copy includes the corrected value-consistent table.
Stage 4 retains the old wired output solely as a historical regression check.
Stage 5 checks the current table against repair/symbolic-ring-audit.csv.
Run python reproduce/06_repair.py separately to regenerate that symbolic audit
(allow up to 30 minutes; no fixed-runtime guarantee). LLVM DFSan reproduction is
optional and requires the stated existing Linux compiler/runtime. No downloads
are performed. Previous setup and carried-result limitations remain.

A quick correction smoke test is: python reproduce/06_repair.py <package-dir> --smoke
It checks one constant, one value-consistent varying and one value-inconsistent expression
at both ring sizes, without claiming a full benchmark rerun.

## Semantic-scope closeout (2026-10-10)

The paper now states relational encoding adequacy for the supplied relation C;
it does not claim the prototype closure equals composed dependence in general.
JF equals RF in the encoder and the proof. Exactness is scoped to straight-line
load/assignment/store threads; guarded register writes have no label semantics
in the application. The defined dependency-cycle criterion is not an independently
validated out-of-thin-air predicate. All 110 positive benchmark expressions satisfy
e(0)=e(1)=1; each can write 1 after reading initial 0. Benchmark counts and code
are unchanged. No Promising-model or compilation validation is claimed.


## Post-blind-review scope correction (2026-10-11)

MutationCorpusRun uses wired folded values, not symbolic value propagation.
Replacing r XOR r with r AND r changes the source expression from 0 to r.
The preserved five ALLOWED/FORBIDDEN changes are historical wired candidate
diagnostics, not source-program verdicts, value-preserving transformations,
or isolated evidence of dependency-strengthening soundness. The original CSV
and report are retained unchanged as records; their causal descriptions must
be read with this correction. The separate six-file edge-relabelling ablation
is unaffected. No experiment was rerun for this wording correction.

The folding benchmark is limited to the authored implementation and constructed
population. No dominance over arbitrary idiom recognizers or cheap analyses is
claimed. The chain population has 256 threads including 14 controls.
Activity restrictions must remain candidate-well-formed; the oracle detector
and address extensions retain their stated proof boundaries. Core theorems,
code, bibliography and raw results are unchanged.


## Minor-review closeout (2026-10-11)

The paper clarifies file/program units, audit populations, exclusion accounting, model naming and check-case terminology. The synthesis description is limited to its finite decision-table population. REVERSION-RECORD.json archives historical prose provenance for the 293-divergence replay; it is not raw replay output or a reproducer. Source, theories and raw evaluation data are unchanged.

## Address and provenance closeout (2026-10-11)

This closeout adds evidence and tooling only. Implementation, theories, classifiers,
consistency rules, corpus and every earlier result are unchanged.

- **Address offsets.** The encoder resolves register-indexed accesses to their base
  location. `address-check/` proves exactly, with z3 over 64-bit AArch64 semantics, that
  all 202 such accesses in the 133 eligible files that have them have a zero effective
  offset: 202 VERIFIED_ZERO, 0 nonzero, 0 unresolved. Base-location addressing is
  therefore faithful on the eligible population. This is a population-wide check; the
  LB+addrs hand check is one instance of it.
- **Recovered tools.** The scripts behind the eligible manifest and Table 2's partition
  are packaged unmodified in `provenance/`, with their recorded inputs. Stage 7 regenerates
  every recorded output byte-identically.
  - The extraction gate is `gate.py`.
  - `gate2.py` is a one-line variant that only `outcome_gate.py` imports.
- **Sampled versus exact.**
  - The extraction gate compares write values on 40 sampled valuations.
  - The outcome gate classifies atoms on 160 random and forced valuations, so its AArch64
    width confirmation is sampling-based evidence, not proof.
  - Structure, locations, data pairs and the address offsets are checked exactly.
- **Manifest file.** `SHA256SUMS` now uses LF line endings. The earlier package's CRLF
  manifest made `sha256sum -c` in stage 0 fail under Git Bash.
- **Paper.** `paper/` holds the current source, the bibliography and a locally built PDF.
  The Overleaf-built PDF still needs to be synchronised with this copy.
