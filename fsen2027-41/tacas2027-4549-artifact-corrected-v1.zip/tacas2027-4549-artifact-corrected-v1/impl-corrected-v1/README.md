# `impl-corrected-v1/`: the CORRECTED v1 build (2026-10-19). NOT the submitted build

| File | Content |
|---|---|
| `snapshot/` | `impl/snapshot/` with `CORRECTION.diff` applied |
| `classes/` | 166 class files compiled from `snapshot/src/main/java` (`javac -nowarn -encoding UTF-8`, JDK 21.0.10). They are byte-identical to `impl/classes/` except `wev/smt/EventStructureEncoder.class`, `wev/smt/MinimalWitnessExtractor.class` and `wev/smt/MinimalWitnessExtractor$1.class` |
| `PIN.txt` | per-file hashes, snapshot aggregate `1f5d7d56…`, classes aggregate `abf33814…` |
| `CORRECTION.diff` | `diff -ruN impl/snapshot impl-corrected-v1/snapshot` |

Runtime jars and natives are the same as for the submitted build: `impl/DEPENDENCIES.txt` and `deps/NATIVES.txt`.

## The change

**Main sources.** `EventStructureEncoder.relaxedPoConstraints` keeps a program-order edge in the global witness order `pos` only when both events access the same location; the new helper `sameLocation` decides this. `MinimalWitnessExtractor.gatedWellFormedness` applies the same filter, which also drops its former fence edges. Comments in both files are rewritten to describe the corrected behaviour.

**Tests.** Two test classes are added:
- `src/test/java/wev/smt/WellFormednessAdequacyTest.java` (12 tests):
  - CX-1 `2+2W+rfis`: well-formedness alone; consistency alone; fixed-candidate verdicts; the wired query;
  - preservation: plain 2+2W, SB, same-location co versus po, co antisymmetry, one value-matching rf source;
  - gated well-formedness and the witness search.
- `src/test/java/wev/smt/cli/F01CorpusRegressionTest.java` (5 tests):
  - the 3 affected corpus files, hash-checked, using the symbolic path of `CorpusValidation`;
  - controls: LB-real as packaged (FORBIDDEN under all six) and the LB-copy diagnostic (RA A, WEAKEST F).

**Unchanged.** Every other file is byte-identical to `impl/snapshot/`, including `LitmusParser`, `AxiomaticConsistency` and every driver. The model jar and all dependencies are also identical.

**Equivalence check.** The investigation's scratch correction (`correction-record/investigation-2026-10-18/src/corrected.diff`) applies the same filter with different comments. Its full-population verdicts equal this build's on all 14,376 cells (checked 2026-10-19).

Rationale and scope: `../CORRECTION-NOTICE.md` C-1. Results: `../results/corrected-v1/`. Checks: stages 8–11.
