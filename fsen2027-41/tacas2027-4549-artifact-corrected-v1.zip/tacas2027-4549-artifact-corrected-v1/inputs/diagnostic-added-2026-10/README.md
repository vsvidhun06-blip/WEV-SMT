# Diagnostic input added in 2026-10. NOT original evidence

`LB-copy.litmus` was written on 2026-10-18 by the correctness investigation. Its header comment says so. It encodes the program drawn in the paper's Fig. 1: each store writes the loaded value itself (`W x = r0`, `W y = r1`).

The packaged `../examples/paper/LB-real.litmus`, which the paper cites, stores `r0 + 1` instead, so its outcome is value-unreachable (`CORRECTION-NOTICE.md` C-3). That file is unchanged.

Symbolic verdicts, the same under both builds and the reference checker:

| SC | TSO | PSO | RA | WEAKEST | RC11 |
|---|---|---|---|---|---|
| F | F | F | **A** | **F** | F |

`F01CorpusRegressionTest.lbCopyDiagnosticSeparatesRaFromWeakest` asserts this (stage 9).
