# Results: authoritative, carried, superseded, corrected-v1

> **corrected-v1 package (2026-10-19).** `authoritative/`, `carried/` and `superseded/` are
> unchanged; they are the results of the SUBMITTED build (`impl/`) that the submitted manuscript
> reports, including the 12 erroneous cells of `CORRECTION-NOTICE.md` C-1 in
> `authoritative/ppo-repair/six-model/repaired-symbolic.csv`. The corrected build's results are
> in `corrected-v1/` (see the last section). The 2026-10-12 version of this file is in
> `history/package-20261012/results/README.md`.

## `authoritative/`: the repaired results the paper reports (SUBMITTED build)

These were produced with the pinned implementation (`impl/`) on the frozen manifests, after
three repairs:
- AArch64 `#` immediates;
- X/W register outcome binding;
- TSO/PSO preserved program order.

**`ppo-repair/`** holds the final six-model run:
- `six-model/repaired-symbolic.csv`: 2,396 × 6, source of every symbolic verdict claim;
- `six-model/repaired-wired-847.csv`: the 847-file diagnostic;
- `herd7-x86-results.csv`: TSO 101/101;
- the verdicts changed by the PPO repair.

The repair changed only TSO and PSO formulas. The SC, RA, WEAKEST and RC11 formulas are
byte-identical across all 2,396 files, so the audits below, run just before it, carry over.

**`rerun-2026-10-09/`** holds the frozen re-run:
- dependency and discriminator audits (`sdep/`, `mutation-*`, `pairs-corpus.csv` with the
  374 pairs, `pwt-*`, `qfbv-*`, `layer2-audit.csv`, `detector-quality/`,
  `detector-oracle-audit.csv`);
- `generated-hard-pairs.csv`: the **historical wired** hard-benchmark table (stage 4
  regression check; the paper calls it "historical wired evidence", tex L1576-1581). It is
  **not** Table 2. Table 2 of the submitted paper is the symbolic value-consistent audit
  `repair/symbolic-ring-audit.csv` (1,288 value-consistent instances; stage 6 regenerates it,
  stage 5 claim H1 recomputes it). The matched-pair folding table is also here;
- the published examples (`examples-results.json`);
- the herd7 SC comparison (`herd7-frozen-results.csv`; SC unaffected by the PPO repair);
- `final-analysis.txt`.

`final-analysis.txt` was written before the PPO repair. Its TSO and PSO counts are therefore
superseded by `ppo-repair/`. Everything else in it stands.

## `carried/`: earlier runs on unchanged inputs, cited as such by the paper

| Files | Content |
|---|---|
| `nthread-grounded-admission.csv` | grounded-LB admission up to eight threads |
| `scalability-consistency.csv` | parametric scalability sweep |
| `dat3m-comparison-v2.csv` | Dat3M timings and the wired 31/41 |
| `dat3m-lkmm-*` | Dat3M v4.4.1 / LKMM over Table 2's instances |
| `generated-pairs*.csv` | matched-pair ring sweep |
| `classifier-defect-records/` | the pre-fix defect measurement (218/8448); a recorded experiment, not re-derivable from the fixed tree |

These exercise only WEAKEST or external tools, on inputs the repairs did not change. They
are not re-run by the package checks.

## `superseded/`: kept for traceability only, never cited as a result

`pre-ppo-repair-six-model/` holds the six-model run before the TSO/PSO
preserved-program-order repair. For example, its TSO SAT count is 743, against 563 after
the repair.

The repository's older corpus tables, from a build that encoded neither fences nor RMW
atomicity, are not packaged (see `../LIMITATIONS.md`).

## `corrected-v1/`: results of the CORRECTED v1 build (2026-10-19), NOT in the submitted paper

| Path | Content |
|---|---|
| `six-model/corrected-symbolic.csv` (+ `.config.txt`, `.encoding-gaps.csv`, `.run.log`) | 2,396 × 6 symbolic verdicts, corrected build, settings identical to `authoritative/ppo-repair/` (`perFileSec=30 budgetMin=600 maxEvents=64`); 463 s on the recorded machine |
| `six-model/corrected-wired-847.csv` (+ …) | the 847-file wired diagnostic, corrected build (identical verdicts to the submitted build) |
| `rerun-submitted-2026-10-19/` | the SUBMITTED build re-run on 2026-10-19 with identical settings: 0 cells differ from `authoritative/` (reproduction evidence; not a new result) |
| `ablation/` | wired discriminator ablation re-run with the corrected build: CSV byte-identical to `authoritative/rerun-2026-10-09/sdep/` |
| `ring-audit/symbolic-ring-audit-corrected.csv` | Table 2 ring audit (stage 6 `--impl corrected`): byte-identical to `repair/symbolic-ring-audit.csv` |
| `reference/reference-verdicts.csv` | separate relational reference checker (stage 11; shares the parser, Z3 value reasoning and transcribed model rules with the implementation); also models ANY (values only), COH (shared base only), WEAKEST_ALL |

Run records (start, end, wall clock) are the `*.run.log` and `*.config.txt` files; absolute
paths there are replaced by `<PKG>` (package root) and `<OUTER>` (the build workspace).
Comparisons: `reproduce/10_results.py` (rows; `--rerun` re-runs both builds) and
`reproduce/05_claims.py` part 2.
