# Mutation-generated discriminating corpus (T2.1)

Mechanically derived fake→real dependency pairs from the wild corpus. For each fake-carrying test (all `r^r` self-XOR), the fake self-cancelling instruction is turned into a genuine self-identity one — **program structure and every folded value untouched, only fake→real**:

- PPC / RISC-V: `xor rd,rn,rn` → `and rd,rn,rn`
- AArch64: `EOR Wd,Wn,Wn` → `AND Wd,Wn,Wn`

`rn^rn = 0` (fake) and `rn&rn = rn` (real) both fold to 0 when the loaded value is modelled as 0, so the mutant reproduces the original's stored values exactly — the wired candidate stays aligned with the `exists` outcome and the only change is that the dependency becomes semantic. A literal `reg+1` mutation was rejected: it changes the stored value, de-aligns the candidate (no write of the required value ⇒ reads default to init), and spuriously flips otherwise-discriminating mutants to ALLOWED.

Both original and mutant are parsed with the exact **QF_BV constancy oracle** (`QfbvConstancyOracle`) installed as the detector, so fakeness (original: `semantic_edges=0`) and realness (mutant: `semantic_edges>0`) are decided by the solver, not by hand. A pair is **discriminating** iff the original is `ALLOWED` (grounded LB) and the mutant is `FORBIDDEN` (real thin-air).

Source: `out\sdep\sdep-discriminating-all-fake-tests.csv` over `eval\corpus`.

## Totals

| | |
|---|---|
| Fake-carrying tests (pairs generated) | 370 |
| Successfully mutated + solved | 370 |
| No self-XOR mutation site | 0 |
| Parse errors (orig or mutant) | 0 |
| **Discriminating pairs (fake=ALLOWED, real=FORBIDDEN)** | **5** |

## By architecture

| arch | pairs | discriminating |
|---|---|---|
| ARM | 210 | 4 |
| PPC | 160 | 1 |

## Discriminating pairs

| test | arch | orig→mut expression |
|---|---|---|
| `Dat3M/litmus/AARCH64/SYS/LB+data+dataap.litmus` | ARM | `EOR W2,W0,W0` → `and W2,W0,W0` |
| `Dat3M/litmus/AARCH64/SYS/LB+dataaps.litmus` | ARM | `EOR W2,W0,W0` → `and W2,W0,W0` |
| `Dat3M/litmus/AARCH64/TUTO/LB+addrs.litmus` | ARM | `EOR W2,W0,W0` → `and W2,W0,W0` |
| `Dat3M/litmus/AARCH64/TUTO/LB+datas.litmus` | ARM | `EOR W2,W0,W0` → `and W2,W0,W0` |
| `herdtools7/catalogue/herding-cats/ppc/tests/illustrative/LB+datas.litmus` | PPC | `xor r3,r1,r1` → `and r3,r1,r1` |

## For the paper (§6.3)

To put WEAKEST's semantic-dependency sensitivity on a mechanically-derived footing rather than the two hand-picked discriminating tests (`LB+datas`, `DETOUR0236`), we generate a paired corpus by mutation. Starting from the 370 fake-dependency-carrying tests in the wild herd7/Dat3M corpus (every one an `r^r` self-XOR idiom, confirmed fake by a QF_BV constancy oracle), we turn each fake self-cancelling instruction into a genuine self-identity dependency (`r^r → r&r`), which leaves every constant-folded value — and hence the wired candidate — identical while flipping the dependency from fake to real. Running WEAKEST on each original/mutant pair yields 5 discriminating pair(s) where the fake original is grounded (ALLOWED) and the real mutant is thin-air (FORBIDDEN) (4 ARM, 1 PPC). Because the mutation is purely syntactic with the solver as ground truth, this raises the discriminating-test count from 2 to 5, confirming that the corpus's fake→real separation is driven by genuine value dependence rather than syntactic form.

_No `.tex` files were modified; nothing was committed._
