#!/usr/bin/env bash
# Chain-composition experiment driver. Each stage is separately rerunnable:
#   bash run.sh generate | freeze | compile | classify | validate | summarize | all
# Compiled classes and intermediates go to $CHAIN_BUILD (outside the repository);
# generated inputs and results go to eval/chain-composition/results/.
# Windows (Git Bash) classpath separator ';' is assumed, as in the repository's cp.txt.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="$(cd "$HERE/../.." && pwd)"
BUILD="${CHAIN_BUILD:?set CHAIN_BUILD to a directory outside the repository}"
RES="$HERE/results"
PY="python -I -B"   # -B: no __pycache__ in the repository
JARS="$(tr -d '\r\n' < "$REPO/cp.txt")"
TIMEOUT="${CHAIN_TIMEOUT:-60}"
BW="$(cygpath -w "$BUILD")"      # Windows form for java/javac classpaths
RW="$(cygpath -w "$REPO")"

generate() {
  rm -rf "$RES/generated"; mkdir -p "$RES/generated"
  $PY "$HERE/gen.py" "$HERE/design.json" "$RES/generated"
  ( cd "$RES/generated" && sha256sum manifest.json queries.tsv inputs/*.litmus ) > "$RES/generated-SHA256SUMS"
  rm -rf "$RES/validation"; mkdir -p "$RES/validation"
  $PY "$HERE/hand_cases.py" "$RES/validation"
}

compile() {
  rm -rf "$BUILD/main-classes" "$BUILD/adapter-classes"; mkdir -p "$BUILD/main-classes" "$BUILD/adapter-classes"
  ( cd "$REPO" && find src/main/java -name '*.java' | sort ) > "$BUILD/sources.txt"
  ( cd "$REPO" && javac -nowarn -encoding UTF-8 -d "$BUILD/main-classes" -cp "$JARS" @"$BUILD/sources.txt" )
  javac -encoding UTF-8 -d "$BUILD/adapter-classes" -cp "$BW\main-classes;$JARS" "$HERE/adapter/ChainCompositionRun.java"
  {
    echo "date: $(date -u +%FT%TZ)"
    echo "java: $(java -version 2>&1 | head -1)"
    echo "repo HEAD (working tree may differ): $(cd "$REPO" && git rev-parse HEAD)"
    echo "source files: $(wc -l < "$BUILD/sources.txt")"
    echo "source sha256 (sorted per-file sums): $(cd "$REPO" && xargs sha256sum < "$BUILD/sources.txt" | sha256sum | cut -c1-64)"
    echo "LitmusParser.java sha256: $(sha256sum "$REPO/src/main/java/wev/smt/parse/LitmusParser.java" | cut -c1-64)"
    echo "QfbvConstancyOracle.java sha256: $(sha256sum "$REPO/src/main/java/wev/smt/QfbvConstancyOracle.java" | cut -c1-64)"
    echo "main classes sha256: $(cd "$BUILD/main-classes" && find . -name '*.class' | sort | xargs sha256sum | sha256sum | cut -c1-64)"
    echo "adapter source sha256: $(sha256sum "$HERE/adapter/ChainCompositionRun.java" | cut -c1-64)"
    echo "classpath jars sha256: $(tr ';' '\n' < "$REPO/cp.txt" | tr -d '\r' | grep . | xargs -d '\n' sha256sum | sha256sum | cut -c1-64)"
    echo "z3 native: $(sha256sum "$REPO/target/native/"*.dll | cut -c1-16 | tr '\n' ' ')"
  } > "$RES/build-provenance.txt"
}

classify() {
  mkdir -p "$RES/raw"
  java -Djava.library.path="$RW\target\native" -cp "$BW\adapter-classes;$BW\main-classes;$JARS" \
       ChainCompositionRun "$RES/generated" "$RES/raw" "$TIMEOUT"
  java -Djava.library.path="$RW\target\native" -cp "$BW\adapter-classes;$BW\main-classes;$JARS" \
       ChainCompositionRun "$RES/validation" "$RES/validation/raw" "$TIMEOUT"
}

freeze() {
  ( cd "$HERE" && sha256sum DESIGN.md design.json gen.py hand_cases.py adapter/ChainCompositionRun.java \
      validate.py summarize.py run.sh results/generated/manifest.json results/generated/queries.tsv \
      results/validation/hand.json
    echo "frozen-at: $(date -u +%FT%TZ) (before classify)" ) > "$HERE/FREEZE.txt"
}

validate() {
  $PY "$HERE/validate.py" "$RES"
}

summarize() {
  $PY "$HERE/summarize.py" "$RES"
}

case "${1:-all}" in
  generate) generate ;; freeze) freeze ;; compile) compile ;; classify) classify ;;
  validate) validate ;; summarize) summarize ;;
  all) generate; compile; classify; validate; summarize ;;   # freeze is run once, by hand
  *) echo "unknown stage $1" >&2; exit 2 ;;
esac
