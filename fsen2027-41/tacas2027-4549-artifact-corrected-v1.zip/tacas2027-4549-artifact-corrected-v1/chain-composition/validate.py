"""Independent validation and final per-pair classification.

Independent of both the shipped Java code and gen.py's composer:
  * a separate concrete interpreter executes each thread instruction by instruction;
  * a separate string parser reads the shipped writeValueExprs string (R<readId> symbols)
    and the hand-written composed strings;
  * Python z3 (an encoding written here, not the shipped QfbvConstancyOracle) decides
    dependence, and every REAL verdict is confirmed by two concrete executions.

Usage: python validate.py <results-dir>
Reads  generated/manifest.json, raw/pairs-raw.csv, validation/{hand.json,raw/pairs-raw.csv}
Writes pairs-final.csv, threads-validation.csv, hand-validation.csv, validation-summary.txt,
       and STOP-repro.txt if a confirmed closure-FAKE / composed-REAL pair exists.
"""
import csv
import json
import random
import re
import sys
from collections import Counter
from pathlib import Path

import z3

M32 = 0xFFFFFFFF
EDGE = [0, 1, 2, 3, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF, 0xFFFFFFFE, 0x55555555, 0xAAAAAAAA]


# ── independent concrete interpreter over the instruction AST ─────────────────────
def cval(e, env):
    t = e[0]
    if t == 'c':
        return e[1] & M32
    if t in ('v', 's'):
        return env[e[1]]
    if t == 'u':
        x = cval(e[2], env)
        return (~x & M32) if e[1] == '~' else (-x & M32)
    a, b = cval(e[2], env), cval(e[3], env)
    o = e[1]
    r = a + b if o == '+' else a - b if o == '-' else a * b if o == '*' else \
        a & b if o == '&' else a | b if o == '|' else a ^ b
    return r & M32


def execute(instrs, loadvals):
    env, k, out = {}, 0, None
    for ins in instrs:
        if ins[0] == 'load':
            env[ins[1]] = loadvals[k] & M32
            k += 1
        elif ins[0] == 'assign':
            env[ins[1]] = cval(ins[2], env)
        else:
            out = env[ins[2]]
    return out


# ── independent string parser (oracle precedence: | < ^ < & < +- < * < unary) ───────
TOK = re.compile(r"\s*(\d+|[A-Za-z_]\w*|[()+\-*&|^~])")


def parse_str(s):
    toks, pos = [], 0
    s = s.strip()
    while pos < len(s):
        m = TOK.match(s, pos)
        if not m:
            raise ValueError(f"bad char at {pos} in {s!r}")
        toks.append(m.group(1))
        pos = m.end()
    i = 0

    def peek():
        return toks[i] if i < len(toks) else None

    def take():
        nonlocal i
        i += 1
        return toks[i - 1]

    def level(ops, nxt):
        def f():
            v = nxt()
            while peek() in ops:
                op = take()
                v = ('b', op, v, nxt())
            return v
        return f

    def unary():
        if peek() in ('~', '-'):
            op = take()
            return ('u', op, unary())
        if peek() == '(':
            take()
            v = p_or()
            assert take() == ')'
            return v
        t = take()
        if t.isdigit():
            return ('c', int(t) & M32)
        return ('s', t)
    p_mul = level(('*',), unary)
    p_add = level(('+', '-'), p_mul)
    p_and = level(('&',), p_add)
    p_xor = level(('^',), p_and)
    p_or = level(('|',), p_xor)
    v = p_or()
    if i != len(toks):
        raise ValueError(f"trailing tokens in {s!r}")
    return v


def syms(e, acc=None):
    acc = set() if acc is None else acc
    if e[0] == 's':
        acc.add(e[1])
    elif e[0] == 'u':
        syms(e[2], acc)
    elif e[0] == 'b':
        syms(e[2], acc)
        syms(e[3], acc)
    return acc


def rename(e, m):
    t = e[0]
    if t == 's':
        return ('s', m.get(e[1], e[1]))
    if t == 'c':
        return e
    if t == 'u':
        return ('u', e[1], rename(e[2], m))
    return ('b', e[1], rename(e[2], m), rename(e[3], m))


# ── z3 encoding (written here) ───────────────────────────────────────────────────
def zt(e, env):
    t = e[0]
    if t == 'c':
        return z3.BitVecVal(e[1], 32)
    if t == 's':
        return env[e[1]]
    if t == 'u':
        x = zt(e[2], env)
        return ~x if e[1] == '~' else -x
    a, b = zt(e[2], env), zt(e[3], env)
    return {'+': a + b, '-': a - b, '*': a * b, '&': a & b, '|': a | b, '^': a ^ b}[e[1]]


def z3_dep(expr, target, symbols):
    """('REAL', (val1, val2)) with two valuations differing only in target, or ('FAKE', None)."""
    shared = {s: z3.BitVec('v_' + s, 32) for s in symbols if s != target}
    e1 = dict(shared, **{target: z3.BitVec('t1', 32)})
    e2 = dict(shared, **{target: z3.BitVec('t2', 32)})
    sv = z3.Solver()
    sv.set('timeout', 60000)
    sv.add(zt(expr, e1) != zt(expr, e2))
    r = sv.check()
    if r == z3.unsat:
        return 'FAKE', None
    if r != z3.sat:
        return 'Z3-UNKNOWN', None
    m = sv.model()
    v1 = {s: m.eval(e1[s], model_completion=True).as_long() for s in e1}
    v2 = {s: m.eval(e2[s], model_completion=True).as_long() for s in e2}
    return 'REAL', (v1, v2)


def z3_equiv(a, b):
    env = {s: z3.BitVec('v_' + s, 32) for s in syms(a) | syms(b)}
    sv = z3.Solver()
    sv.set('timeout', 60000)
    sv.add(zt(a, env) != zt(b, env))
    return sv.check() == z3.unsat


def to_tuple(x):
    return tuple(to_tuple(y) for y in x) if isinstance(x, list) else x


def rd(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def closure(flag):
    return {'REAL': 'REAL', 'BOTH': 'REAL', 'FAKE': 'FAKE', 'ABSENT': 'FAKE'}.get(flag, 'ERROR')


def thread_checks(it, rows, rng):
    """Parse fidelity, execution-vs-composition and shipped-composition checks."""
    instrs = to_tuple(it['instrs'])
    comp = to_tuple(it['composed_ast'])
    loads = it['loads']
    issues = []
    r0 = rows[0]
    if r0['status'] != 'ok':
        issues.append('parse:' + r0['status'])
        return issues, None
    if int(r0['n_reads']) != len(loads):
        issues.append(f"read-count {r0['n_reads']}!={len(loads)}")
    for r in rows:
        ld = loads[int(r['k'])]
        if r['read_loc'] != ld['loc'] or r['read_reg'] != ld['reg']:
            issues.append(f"read-{r['k']} {r['read_loc']}/{r['read_reg']} != {ld['loc']}/{ld['reg']}")
    store_reg = [i for i in instrs if i[0] == 'store'][0][2]
    if r0['n_writes'] != '1' or r0['store_loc'] != 'y' or r0['raw_store'] != store_reg:
        issues.append(f"store {r0['n_writes']}/{r0['store_loc']}/{r0['raw_store']}")
    vals = [[rng.choice(EDGE) if rng.random() < 0.3 else rng.getrandbits(32) for _ in loads]
            for _ in range(256)]
    for v in vals:
        if execute(instrs, v) != cval(comp, {f"L{k}": x for k, x in enumerate(v)}):
            issues.append('exec!=composed')
            break
    shipped = None
    try:
        shipped = parse_str(r0['shipped_composed'])
        ren = {f"R{r['read_id']}": f"L{r['k']}" for r in rows}
        foreign = syms(shipped) - set(ren)
        if foreign:
            issues.append(f"shipped-composed foreign symbols {sorted(foreign)}")
        else:
            shipped = rename(shipped, ren)
            if not z3_equiv(shipped, comp):
                issues.append('shipped-composed != composed')
    except Exception as ex:  # noqa: BLE001
        issues.append(f"shipped-composed unparseable: {ex}")
    return issues, shipped


def main():
    res = Path(sys.argv[1])
    rng = random.Random(20261010)
    manifest = json.loads((res / 'generated' / 'manifest.json').read_text())
    raw = rd(res / 'raw' / 'pairs-raw.csv')
    by = {}
    for r in raw:
        by.setdefault(r['id'], []).append(r)
    out, tv, stops = [], [], []
    for it in manifest:
        rows = sorted(by.get(it['id'], []), key=lambda r: int(r['k']))
        if len(rows) != len(it['loads']):
            issues, _ = [f"adapter rows {len(rows)}"], None
        else:
            issues, _ = thread_checks(it, rows, rng)
        tv.append({'id': it['id'], 'issues': ';'.join(issues) or 'ok'})
        instrs = to_tuple(it['instrs'])
        comp = to_tuple(it['composed_ast'])
        symbols = {f"L{k}" for k in range(len(it['loads']))}
        for r in rows:
            k = int(r['k'])
            tgt = f"L{k}"
            zd, wit = z3_dep(comp, tgt, symbols)
            confirmed = ''
            if zd == 'REAL':
                v1 = [wit[0][f"L{j}"] for j in range(len(it['loads']))]
                v2 = [wit[1][f"L{j}"] for j in range(len(it['loads']))]
                o1, o2 = execute(instrs, v1), execute(instrs, v2)
                confirmed = f"exec {v1}->{o1} vs {v2}->{o2}" if o1 != o2 else 'WITNESS-FAILED'
            cmap = {'VARIES': 'REAL', 'CONST': 'FAKE'}
            c = cmap.get(r['C'], r['C'])
            cship = cmap.get(r['Cship'], r['Cship'])
            exp = it['expect'][tgt]
            pair_issues = list(issues)
            if c not in ('REAL', 'FAKE'):
                pair_issues.append(f"C:{c}")
            elif c != zd:
                pair_issues.append(f"oracle {c} != z3 {zd}")
            if confirmed == 'WITNESS-FAILED':
                pair_issues.append('witness failed')
            if not issues and cship != c:
                pair_issues.append(f"Cship {cship} != C {c}")
            a, b = closure(r['A']), closure(r['B'])

            def cat(x):
                if pair_issues:
                    return 'error:' + pair_issues[0].split(' ')[0]
                if x == 'ERROR':
                    return 'error:closure'
                if x == c:
                    return 'agree-' + c
                return f"closure{x}/composed{c}"
            ca, cb = cat(a), cat(b)
            for cfg, cc in (('A', ca), ('B', cb)):
                if cc == 'closureFAKE/composedREAL' and confirmed.startswith('exec'):
                    stops.append((it, r, cfg, confirmed))
            out.append({
                'id': it['id'], 'family': it['family'], 'template': it['template'], 'L': it['L'],
                'draw': it['draw'], 'variant': it['variant'], 'assignments': it['assignments'],
                'k': k, 'norm_program': it['norm_program'], 'norm_shape': it['norm_shape'],
                'composed': it['composed'], 'shipped_composed': r['shipped_composed'],
                'A_raw': r['A'], 'B_raw': r['B'], 'A': a, 'B': b, 'C': c, 'z3': zd,
                'expected': exp, 'expected_ok': exp == zd, 'witness': confirmed,
                'cat_A': ca, 'cat_B': cb, 'issues': ';'.join(pair_issues),
            })
    with open(res / 'pairs-final.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    with open(res / 'threads-validation.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['id', 'issues'])
        w.writeheader()
        w.writerows(tv)

    # ── hand cases ──
    hrows = []
    hdir = res / 'validation'
    if (hdir / 'hand.json').exists():
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from gen import compose  # the composer under test
        hraw = {}
        for r in rd(hdir / 'raw' / 'pairs-raw.csv'):
            hraw.setdefault(r['id'], []).append(r)
        for h in json.loads((hdir / 'hand.json').read_text()):
            instrs = to_tuple(h['instrs'])
            hand = parse_str(h['hand_composed'])
            gen_comp, loads = compose(instrs)
            rows = sorted(hraw[h['id']], key=lambda r: int(r['k']))
            vals = [h['valuation'][f"L{k}"] for k in range(len(loads))]
            sh_ok = 'n/a'
            try:
                sh = rename(parse_str(rows[0]['shipped_composed']),
                            {f"R{r['read_id']}": f"L{r['k']}" for r in rows})
                sh_ok = z3_equiv(sh, hand)
            except Exception as ex:  # noqa: BLE001
                sh_ok = f"ERR {ex}"
            for r in rows:
                tgt = f"L{r['k']}"
                zd, _ = z3_dep(hand, tgt, {f"L{k}" for k in range(len(loads))})
                hrows.append({
                    'family': h['family'], 'id': h['id'], 'k': r['k'], 'status': r['status'],
                    'parse_reads_ok': int(r['n_reads']) == len(loads) and r['read_reg'] == loads[int(r['k'])][1],
                    'gen_composer_equiv_hand': z3_equiv(gen_comp, hand),
                    'exec_eq_hand_value': execute(instrs, vals) == h['hand_value'],
                    'hand_string_eq_hand_value': cval(hand, h['valuation']) == h['hand_value'],
                    'shipped_composed_equiv_hand': sh_ok,
                    'oracle_on_hand': {'VARIES': 'REAL', 'CONST': 'FAKE'}.get(r['C'], r['C']),
                    'z3_on_hand': zd, 'expected': h['expect'][tgt],
                    'A': closure(r['A']), 'B': closure(r['B']),
                })
        with open(res / 'hand-validation.csv', 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(hrows[0]))
            w.writeheader()
            w.writerows(hrows)

    lines = [f"threads {len(manifest)}  pairs {len(out)}",
             f"thread validation issues: {Counter(t['issues'] for t in tv if t['issues'] != 'ok')}",
             f"pairs with issues: {sum(1 for o in out if o['issues'])}",
             f"expected (template) vs z3: {Counter(o['expected_ok'] for o in out)}",
             f"REAL witnesses confirmed by execution: "
             f"{sum(1 for o in out if o['witness'].startswith('exec'))}/{sum(1 for o in out if o['z3'] == 'REAL')}",
             f"cat_A {dict(Counter(o['cat_A'] for o in out))}",
             f"cat_B {dict(Counter(o['cat_B'] for o in out))}"]
    if hrows:
        checks = ['parse_reads_ok', 'gen_composer_equiv_hand', 'exec_eq_hand_value',
                  'hand_string_eq_hand_value', 'shipped_composed_equiv_hand']
        lines.append(f"hand cases {len({h['id'] for h in hrows})} pairs {len(hrows)} families "
                     f"{sorted({h['family'] for h in hrows})}")
        for c in checks:
            lines.append(f"  hand {c}: {Counter(str(h[c]) for h in hrows)}")
        lines.append(f"  hand oracle==expected: {Counter(h['oracle_on_hand'] == h['expected'] for h in hrows)}"
                     f"  z3==expected: {Counter(h['z3_on_hand'] == h['expected'] for h in hrows)}")
    if stops:
        it, r, cfg, conf = min(stops, key=lambda s: (s[0]['assignments'], s[0]['id']))
        rep = [f"STOP: confirmed closure-FAKE / composed-REAL ({len(stops)} pair-configs)",
               f"minimal: {it['id']} load k={r['k']} config {cfg}",
               f"composed: {it['composed']}", f"witness: {conf}",
               (res / 'generated' / it['file']).read_text()]
        (res / 'STOP-repro.txt').write_text('\n'.join(rep), newline='\n')
        lines.append(rep[0] + ' -> STOP-repro.txt')
    else:
        lines.append('STOP condition: none (no confirmed closure-FAKE / composed-REAL)')
    (res / 'validation-summary.txt').write_text('\n'.join(lines) + '\n', newline='\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
