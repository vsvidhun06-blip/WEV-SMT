"""Generate the frozen chain-composition population from design.json.

Every thread is built as a typed AST (instructions over expression trees), never by string
surgery. Composition runs over the AST: each load event gets a fresh input symbol L<k>, each
assignment substitutes the current symbolic bindings, and the final store's composed
expression is printed once. Concrete execution (validate.py) and composition are separate
code paths.

Usage: python gen.py <design.json> <out-dir>
Writes <out-dir>/inputs/*.litmus, <out-dir>/manifest.json, <out-dir>/queries.tsv.
"""
import hashlib
import json
import random
import sys
from pathlib import Path

M32 = 0xFFFFFFFF

# ── expression AST ─────────────────────────────────────────────────────────────
# ('c', n) constant | ('v', name) register | ('s', name) input symbol
# ('b', op, a, b) binary | ('u', op, a) unary ('~' or '-')
C = lambda n: ('c', n)
V = lambda r: ('v', r)


def B(op, a, b):
    return ('b', op, a, b)


def U(op, a):
    return ('u', op, a)


PREC = {'|': 1, '^': 2, '&': 3, '+': 4, '-': 4, '*': 5}


def show(e, parent=0, right=False):
    """C-precedence printer with minimal parentheses (also the oracle's precedence)."""
    t = e[0]
    if t == 'c':
        return str(e[1])
    if t in ('v', 's'):
        return e[1]
    if t == 'u':
        inner = show(e[2], 6)
        if e[2][0] == 'u':
            inner = f"({inner})"                 # never print "--x" / "~-x" token runs
        s = e[1] + inner
        return f"({s})" if parent and e[1] == '-' else s   # binary operand "-x" -> "(-x)"
    op, p = e[1], PREC[e[1]]
    s = f"{show(e[2], p, False)} {op} {show(e[3], p, True)}"
    if p < parent or (right and p == parent):
        s = f"({s})"
    return s


def ev(e, env):
    """BV32 evaluation of an expression AST; env maps register/symbol names to ints."""
    t = e[0]
    if t == 'c':
        return e[1] & M32
    if t in ('v', 's'):
        return env[e[1]] & M32
    if t == 'u':
        x = ev(e[2], env)
        return (~x) & M32 if e[1] == '~' else (-x) & M32
    a, b = ev(e[2], env), ev(e[3], env)
    return {'+': a + b, '-': a - b, '*': a * b, '&': a & b, '|': a | b, '^': a ^ b}[e[1]] & M32


def subst(e, env):
    t = e[0]
    if t == 'c' or t == 's':
        return e
    if t == 'v':
        if e[1] not in env:
            raise ValueError(f"register {e[1]} used before definition")
        return env[e[1]]
    if t == 'u':
        return ('u', e[1], subst(e[2], env))
    return ('b', e[1], subst(e[2], env), subst(e[3], env))


# ── instructions ─────────────────────────────────────────────────────────────────
# ('load', reg, loc) | ('assign', reg, expr) | ('store', loc, reg)

def compose(instrs):
    """Symbolic execution: returns (composed store AST, [(k, reg, loc)] loads)."""
    env, loads, store = {}, [], None
    for ins in instrs:
        if ins[0] == 'load':
            sym = f"L{len(loads)}"
            loads.append((len(loads), ins[1], ins[2]))
            env[ins[1]] = ('s', sym)
        elif ins[0] == 'assign':
            env[ins[1]] = subst(ins[2], env)
        else:
            assert store is None, "one store per thread"
            store = subst(V(ins[2]), env)
    assert store is not None
    return store, loads


def direct_of(instrs):
    """Direct-site counterpart: same loads, one assignment carrying the composed
    expression over the load registers (requires distinct load registers)."""
    store, loads = compose(instrs)
    regs = [r for _, r, _ in loads]
    assert len(set(regs)) == len(regs), "direct counterpart needs distinct load registers"
    back = {f"L{k}": V(r) for k, r, _ in loads}

    def unsym(e):
        t = e[0]
        if t == 's':
            return back[e[1]]
        if t in ('c', 'v'):
            return e
        if t == 'u':
            return ('u', e[1], unsym(e[2]))
        return ('b', e[1], unsym(e[2]), unsym(e[3]))
    out = [i for i in instrs if i[0] == 'load']
    out.append(('assign', 's', unsym(store)))
    out.append(('store', 'y', 's'))
    return out


def litmus(name, instrs):
    locs = []
    for i in instrs:
        loc = i[2] if i[0] == 'load' else (i[1] if i[0] == 'store' else None)
        if loc and loc not in locs:
            locs.append(loc)
    lines = [f"C {name}", "{ }", "", f"P0({', '.join('int *' + l for l in locs)}) {{"]
    for i in instrs:
        if i[0] == 'load':
            lines.append(f"  {i[1]} = READ_ONCE(*{i[2]});")
        elif i[0] == 'assign':
            lines.append(f"  {i[1]} = {show(i[2])};")
        else:
            lines.append(f"  WRITE_ONCE(*{i[1]}, {i[2]});")
    lines += ["}", "", "exists (y=0)", ""]
    return "\n".join(lines)


def normalize(instrs, abstract_constants):
    """Alpha-rename registers by first appearance; optionally abstract constants."""
    names = {}

    def nm(r):
        names.setdefault(r, f"q{len(names)}")
        return names[r]

    def ne(e):
        t = e[0]
        if t == 'c':
            return ('c', 'K' if abstract_constants else e[1])
        if t == 'v':
            return ('v', nm(e[1]))
        if t == 'u':
            return ('u', e[1], ne(e[2]))
        return ('b', e[1], ne(e[2]), ne(e[3]))
    out = []
    for i in instrs:
        if i[0] == 'load':
            out.append(('load', nm(i[1]), i[2]))
        elif i[0] == 'assign':
            e = ne(i[2])
            out.append(('assign', nm(i[1]), e))
        else:
            out.append(('store', i[1], nm(i[2])))
    return hashlib.sha256(json.dumps(out).encode()).hexdigest()[:16]


# ── templates ─────────────────────────────────────────────────────────────────────

class Gen:
    def __init__(self, design):
        self.d = design
        self.P = design['pools']
        self.rng = random.Random(design['seed'])

    def pick(self, pool):
        return self.rng.choice(self.P[pool])

    def inj_step(self, x):
        kind = self.rng.choice(self.d['injective_steps'])
        if kind == 'add K':
            return B('+', x, C(self.pick('ADD')))
        if kind == 'sub K':
            return B('-', x, C(self.pick('ADD')))
        if kind == 'xor K':
            return B('^', x, C(self.pick('XOR')))
        if kind == 'mul ODD':
            return B('*', x, C(self.pick('ODD')))
        if kind == 'not':
            return U('~', x)
        return U('-', x)

    def chain(self, start_reg, n, step, prefix='t'):
        """n assignments t1..tn, t1 = step(start), t_i = step(t_{i-1}); returns (instrs, last)."""
        out, cur = [], start_reg
        for i in range(1, n + 1):
            r = f"{prefix}{i}"
            out.append(('assign', r, step(V(cur))))
            cur = r
        return out, cur

    def masks(self, n, retain):
        """n non-zero 16-bit masks whose running AND is non-zero before the last one;
        the last clears it (retain=False) or keeps >=1 bit (retain=True)."""
        bits = self.P['MASK_BITS']
        while True:
            full = self.rng.getrandbits(bits)
            if bin(full).count('1') >= n + 2:
                break
        assert n >= 2
        cum, ms = full, [full]
        for _ in range(n - 2):
            set_bits = [b for b in range(bits) if cum >> b & 1]
            drop = self.rng.choice(set_bits)
            extra = self.rng.getrandbits(bits) & ~cum & ((1 << bits) - 1)
            m = (cum & ~(1 << drop)) | extra
            if (cum & m) == 0:
                m |= 1 << [b for b in set_bits if b != drop][0]
            ms.append(m)
            cum &= m
        outside = ((1 << bits) - 1) & ~cum
        last = self.rng.getrandbits(bits) & outside or (outside & -outside)
        if retain:
            set_bits = [b for b in range(bits) if cum >> b & 1]
            last |= 1 << self.rng.choice(set_bits)
        ms.append(last)
        run = 0xFFFF
        for m in ms[:-1]:
            run &= m
            assert run != 0
        assert ((run & ms[-1]) != 0) == retain and all(m != 0 for m in ms)
        return ms

    def build(self, tpl, L, draw):
        if tpl == 'CAN-ADD':
            body = [('load', 'r0', 'x0'), ('assign', 't1', B('+', V('r0'), C(self.pick('ADD'))))]
            more, last = self.chain('t1', L - 1, lambda x: B(self.rng.choice('+-'), x, C(self.pick('ADD'))), 'u')
            body += more + [('assign', 's', B('-', V(last), V('r0'))), ('store', 'y', 's')]
            return body
        if tpl == 'CAN-XOR':
            body = [('load', 'r0', 'x0'), ('assign', 't1', B('^', V('r0'), C(self.pick('XOR'))))]
            more, last = self.chain('t1', L - 1, lambda x: B('^', x, C(self.pick('XOR'))), 'u')
            body += more + [('assign', 's', B('^', V(last), V('r0'))), ('store', 'y', 's')]
            return body
        if tpl == 'CAN-COPY':
            more, last = self.chain('r0', L, lambda x: x)
            op = '^' if draw == 0 else '-'
            return [('load', 'r0', 'x0')] + more + [('assign', 's', B(op, V(last), V('r0'))), ('store', 'y', 's')]
        if tpl == 'CAN-DUP':
            steps = [self.inj_step(('s', 'HOLE')) for _ in range(L)]

            def plug(tmpl, x):
                t = tmpl[0]
                if t == 's':
                    return x
                if t == 'c':
                    return tmpl
                if t == 'u':
                    return ('u', tmpl[1], plug(tmpl[2], x))
                return ('b', tmpl[1], plug(tmpl[2], x), plug(tmpl[3], x))
            it = iter(steps)
            a, la = self.chain('r0', L, lambda x: plug(next(it), x), 'a')
            it = iter(steps)
            b, lb = self.chain('r0', L, lambda x: plug(next(it), x), 'b')
            op = '-' if draw == 0 else '^'
            return [('load', 'r0', 'x0')] + a + b + [('assign', 's', B(op, V(la), V(lb))), ('store', 'y', 's')]
        if tpl == 'CAN-2IN':
            body = [('load', 'r0', 'x0'), ('load', 'r1', 'x1'), ('assign', 't1', B('+', V('r0'), V('r1')))]
            more, last = self.chain('t1', L - 1, lambda x: B(self.rng.choice('+-'), x, C(self.pick('ADD'))), 'u')
            return body + more + [('assign', 's', B('-', V(last), V('r0'))), ('store', 'y', 's')]
        if tpl == 'CAN-RELOAD':
            body = [('load', 'r0', 'x0'), ('assign', 't1', B('+', V('r0'), C(self.pick('ADD'))))]
            more, last = self.chain('t1', L - 1, lambda x: B(self.rng.choice('+-'), x, C(self.pick('ADD'))), 'u')
            return body + more + [('load', 'r0', 'x0'), ('assign', 's', B('-', V(last), V('r0'))), ('store', 'y', 's')]
        if tpl in ('MSK-DISJ', 'MSK-RETAIN'):
            ms = iter(self.masks(L, tpl == 'MSK-RETAIN'))
            more, last = self.chain('r0', L, lambda x: B('&', x, C(next(ms))))
            return [('load', 'r0', 'x0')] + more + [('store', 'y', last)]
        if tpl == 'MSK-MUL':
            k = self.pick('POW2_EXP')
            p = 1 << k
            body = [('load', 'r0', 'x0'), ('assign', 't1', B('*', V('r0'), C(p)))]

            def low_preserving(x):
                kind = self.rng.choice(['add', 'xor', 'mul'])
                if kind == 'mul':
                    return B('*', x, C(self.pick('ODD')))
                c = p * self.rng.randint(1, 50)
                return B('+' if kind == 'add' else '^', x, C(c))
            more, last = self.chain('t1', L - 1, low_preserving, 'u')
            mask = self.rng.randint(1, p - 1) if draw == 0 else (p | self.rng.randint(0, p - 1))
            return body + more + [('assign', 's', B('&', V(last), C(mask))), ('store', 'y', 's')]
        if tpl == 'MSK-INREG':
            ms = self.masks(L, draw % 2 == 1)
            it = iter(ms[:-1])
            more, last = self.chain('r0', L - 1, lambda x: B('&', x, C(next(it))))
            return ([('load', 'r0', 'x0'), ('assign', 'k', C(ms[-1]))] + more
                    + [('assign', 's', B('&', V(last), V('k'))), ('store', 'y', 's')])
        if tpl == 'MSK-2IN':
            ms = self.masks(L, False)
            it = iter(ms[:-1])
            more, last = self.chain('r0', L - 1, lambda x: B('&', x, C(next(it))))
            m3 = ms[-1] | self.rng.getrandbits(self.P['MASK_BITS'])
            return ([('load', 'r0', 'x0'), ('load', 'r1', 'x1')] + more
                    + [('assign', 'v1', B('&', V('r1'), C(m3))),
                       ('assign', 'w', B('|', V(last), V('v1'))),
                       ('assign', 's', B('&', V('w'), C(ms[-1]))), ('store', 'y', 's')])
        if tpl == 'INJ-MIX':
            more, last = self.chain('r0', L, self.inj_step)
            return [('load', 'r0', 'x0')] + more + [('store', 'y', last)]
        if tpl == 'INJ-2IN':
            op = '^' if draw == 0 else '+'
            body = [('load', 'r0', 'x0'), ('load', 'r1', 'x1'), ('assign', 't1', B(op, V('r0'), V('r1')))]
            more, last = self.chain('t1', L - 1, self.inj_step, 'u')
            return body + more + [('store', 'y', last)]
        raise ValueError(tpl)


def controls():
    r0 = V('r0')
    ld = [('load', 'r0', 'x0')]
    return {
        'CTRL-STORE-LOAD':     (ld + [('store', 'y', 'r0')], {'L0': 'REAL'}),
        'CTRL-COPY':           (ld + [('assign', 's', r0), ('store', 'y', 's')], {'L0': 'REAL'}),
        'CTRL-PLUS1':          (ld + [('assign', 's', B('+', r0, C(1))), ('store', 'y', 's')], {'L0': 'REAL'}),
        'CTRL-SELFXOR':        (ld + [('assign', 's', B('^', r0, r0)), ('store', 'y', 's')], {'L0': 'FAKE'}),
        'CTRL-SELFXOR1':       (ld + [('assign', 's', B('^', B('^', r0, r0), C(1))), ('store', 'y', 's')], {'L0': 'FAKE'}),
        'CTRL-MUL0':           (ld + [('assign', 's', B('*', r0, C(0))), ('store', 'y', 's')], {'L0': 'FAKE'}),
        'CTRL-AND0':           (ld + [('assign', 's', B('&', r0, C(0))), ('store', 'y', 's')], {'L0': 'FAKE'}),
        'CTRL-OVERWRITE':      (ld + [('assign', 't', B('+', r0, C(5))), ('assign', 't', C(7)), ('store', 'y', 't')], {'L0': 'FAKE'}),
        'CTRL-OVERWRITE-LOAD': (ld + [('assign', 'r0', C(9)), ('store', 'y', 'r0')], {'L0': 'FAKE'}),
        'CTRL-RELOAD':         (ld + [('load', 'r0', 'x0'), ('store', 'y', 'r0')], {'L0': 'FAKE', 'L1': 'REAL'}),
        'CTRL-RELOAD-USE':     (ld + [('assign', 's', B('+', r0, C(1))), ('load', 'r0', 'x0'),
                                      ('assign', 't', B('-', V('s'), r0)), ('store', 'y', 't')], {'L0': 'REAL', 'L1': 'REAL'}),
        'CTRL-2IN':            ([('load', 'r0', 'x0'), ('load', 'r1', 'x1'), ('assign', 's', B('+', r0, V('r1'))),
                                 ('store', 'y', 's')], {'L0': 'REAL', 'L1': 'REAL'}),
        'CTRL-CONSTREG':       (ld + [('assign', 'k', C(3)), ('assign', 's', B('*', r0, V('k'))), ('store', 'y', 's')], {'L0': 'REAL'}),
        'CTRL-CONSTREG-ZERO':  (ld + [('assign', 'k', C(0)), ('assign', 's', B('*', r0, V('k'))), ('store', 'y', 's')], {'L0': 'FAKE'}),
    }


def expected_for(tpl, spec, draw, nloads):
    e = spec['expect']
    if tpl == 'MSK-MUL':
        e = e['draw0'] if draw == 0 else e['draw1']
    elif tpl == 'MSK-INREG':
        e = e['odd draw'] if draw % 2 else e['even draw']
    assert len(e) == nloads, (tpl, e, nloads)
    return e


def main():
    design_path, out = Path(sys.argv[1]), Path(sys.argv[2])
    design = json.loads(design_path.read_text())
    g = Gen(design)
    (out / 'inputs').mkdir(parents=True, exist_ok=True)
    items = []

    def emit(iid, family, tpl, L, draw, variant, instrs, expect):
        comp, loads = compose(instrs)
        assert len(loads) == len(expect)
        items.append({
            'id': iid, 'family': family, 'template': tpl, 'L': L, 'draw': draw, 'variant': variant,
            'assignments': sum(1 for i in instrs if i[0] == 'assign'),
            'file': f"inputs/{iid}.litmus", 'instrs': instrs,
            'loads': [{'k': k, 'reg': r, 'loc': l} for k, r, l in loads],
            'composed': show(comp), 'composed_ast': comp, 'expect': expect,
            'norm_program': normalize(instrs, False), 'norm_shape': normalize(instrs, True),
        })
        (out / 'inputs' / f"{iid}.litmus").write_text(litmus(f"CC-{iid}", instrs), newline='\n')

    for tpl, spec in design['templates'].items():
        if spec.get('fixed_list'):
            continue
        for L in spec['lengths']:
            for draw in range(spec['draws']):
                instrs = g.build(tpl, L, draw)
                exp = expected_for(tpl, spec, draw, sum(1 for i in instrs if i[0] == 'load'))
                base = f"{tpl}-L{L}-d{draw}"
                emit(base + '-chain', spec['family'], tpl, L, draw, 'chain', instrs, exp)
                if spec['direct']:
                    emit(base + '-direct', spec['family'], tpl, L, draw, 'direct', direct_of(instrs), exp)
    for name, (instrs, exp) in controls().items():
        emit(name, 'control', name, 0, 0, 'control', instrs, exp)

    assert len(items) <= design['max_threads'], len(items)
    (out / 'manifest.json').write_text(json.dumps(items, indent=1), newline='\n')
    with open(out / 'queries.tsv', 'w', newline='\n') as f:
        for it in items:
            for ld in it['loads']:
                f.write(f"{it['id']}\t{it['file']}\t{ld['k']}\t{it['composed']}\n")
    print(f"generated {len(items)} threads, "
          f"{sum(len(i['loads']) for i in items)} (load, store) pairs")


if __name__ == '__main__':
    main()
