"""Comparison tables and representative traces from pairs-final.csv.

Usage: python summarize.py <results-dir>   -> tables.md, traces.md
The trace selection below is fixed in advance (one or two instances per template).
"""
import csv
import sys
from collections import Counter, defaultdict
from pathlib import Path

TRACE_IDS = [
    'CAN-ADD-L2-d0-chain', 'CAN-ADD-L2-d0-direct', 'CAN-XOR-L2-d0-chain', 'CAN-COPY-L1-d0-chain',
    'CAN-DUP-L2-d0-chain', 'CAN-2IN-L1-d0-chain', 'CAN-RELOAD-L2-d0-chain',
    'MSK-DISJ-L2-d0-chain', 'MSK-DISJ-L2-d0-direct', 'MSK-RETAIN-L2-d0-chain',
    'MSK-MUL-L1-d0-chain', 'MSK-INREG-L2-d0-chain', 'MSK-2IN-L2-d0-chain',
    'INJ-MIX-L4-d0-chain', 'INJ-2IN-L2-d0-chain', 'CTRL-CONSTREG-ZERO', 'CTRL-RELOAD',
]
CATS = ['agree-REAL', 'agree-FAKE', 'closureREAL/composedFAKE', 'closureFAKE/composedREAL']


def rd(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def table(rows, key, title):
    g = defaultdict(list)
    for r in rows:
        g[key(r)].append(r)
    hdr = ['group', 'threads', 'pairs', 'uniq prog/input', 'uniq shape/input', 'C REAL', 'C FAKE',
           'A agree', 'A R/F', 'A F/R', 'B agree', 'B R/F', 'B F/R', 'errors']
    out = [f"### {title}", '', '| ' + ' | '.join(hdr) + ' |', '|' + '---|' * len(hdr)]

    def line(name, rs):
        ca, cb = Counter(r['cat_A'] for r in rs), Counter(r['cat_B'] for r in rs)
        err = sum(1 for r in rs if r['cat_A'].startswith('error') or r['cat_B'].startswith('error'))
        ok = [r for r in rs if not r['cat_A'].startswith('error')]
        return '| ' + ' | '.join(str(x) for x in [
            name, len({r['id'] for r in rs}), len(rs),
            len({(r['norm_program'], r['k']) for r in rs}), len({(r['norm_shape'], r['k']) for r in rs}),
            sum(r['C'] == 'REAL' for r in ok), sum(r['C'] == 'FAKE' for r in ok),
            ca['agree-REAL'] + ca['agree-FAKE'], ca['closureREAL/composedFAKE'], ca['closureFAKE/composedREAL'],
            cb['agree-REAL'] + cb['agree-FAKE'], cb['closureREAL/composedFAKE'], cb['closureFAKE/composedREAL'],
            err]) + ' |'
    for k in sorted(g, key=lambda x: tuple(str(y).zfill(3) for y in x) if isinstance(x, tuple) else str(x)):
        out.append(line(' / '.join(map(str, k)) if isinstance(k, tuple) else str(k), g[k]))
    out.append(line('**total**', rows))
    return out + ['']


def main():
    res = Path(sys.argv[1])
    rows = rd(res / 'pairs-final.csv')
    md = ['# Chain-composition results', '',
          'R/F = closure REAL / composed FAKE (precision loss); F/R = closure FAKE / composed REAL '
          '(soundness failure). A = shipped folding classifier + closure; B = exact oracle per '
          'instruction + same closure; C = exact oracle on the composed store expression. '
          '"uniq" columns count distinct (normalized program, load) pairs; template instances are '
          'the "pairs" column.', '']
    md += table(rows, lambda r: (r['family'], int(r['L'])), 'By family and template length L')
    md += table(rows, lambda r: (r['family'], r['variant']), 'By family and variant (chain vs direct)')
    md += table(rows, lambda r: (r['template'] if r['family'] != 'control' else 'CTRL', r['variant']),
                'By template and variant')
    md += table(rows, lambda r: (r['family'], int(r['assignments'])), 'By family and number of assignments')
    # disagreement shapes
    md += ['### Distinct shapes behind each disagreement class', '']
    for cfg in ('A', 'B'):
        for c in CATS[2:]:
            sel = [r for r in rows if r['cat_' + cfg] == c]
            md.append(f"- {cfg} {c}: {len(sel)} pairs, {len({(r['norm_program'], r['k']) for r in sel})} "
                      f"unique program/input, {len({(r['norm_shape'], r['k']) for r in sel})} shapes; "
                      f"templates {dict(Counter(r['template'] for r in sel))}")
    md += ['', '### Errors, unsupported, timeouts', '',
           f"- {dict(Counter(r['issues'] for r in rows if r['issues']))}" if any(r['issues'] for r in rows)
           else '- none', '']
    (res / 'tables.md').write_text('\n'.join(md), newline='\n')

    tr = rd(res / 'raw' / 'trace.csv')
    byid = defaultdict(list)
    for t in tr:
        byid[t['id']].append(t)
    pairs = defaultdict(list)
    for r in rows:
        pairs[r['id']].append(r)
    gen = res / 'generated' / 'inputs'
    out = ['# Representative traces', '',
           'Per instruction: the shipped `classify(expr, reg)` decision under A (folding) and B '
           '(oracle per instruction), then the pair verdicts. Selection fixed before the run.', '']
    for i in TRACE_IDS:
        if i not in pairs:
            continue
        body = (gen / f"{i}.litmus").read_text().split('{', 2)[2].split('}')[0].strip()
        out += [f"## {i}", '', '```c', body, '```', '']
        out.append('| cfg | instr | expr | reg | real | pattern |')
        out.append('|---|---|---|---|---|---|')
        for t in byid[i]:
            out.append(f"| {t['config']} | {t['instr']} | `{t['expr']}` | {t['reg']} | {t['real']} | {t['pattern']} |")
        out.append('')
        for r in pairs[i]:
            out.append(f"- L{r['k']}: composed `{r['composed']}` (shipped `{r['shipped_composed']}`); "
                       f"A={r['A_raw']} B={r['B_raw']} C={r['C']} z3={r['z3']} expected={r['expected']} "
                       f"-> A {r['cat_A']}, B {r['cat_B']}")
            if r['witness']:
                out.append(f"  - witness: {r['witness']}")
        out.append('')
    (res / 'traces.md').write_text('\n'.join(out), newline='\n')
    print((res / 'tables.md').read_text())


if __name__ == '__main__':
    main()
