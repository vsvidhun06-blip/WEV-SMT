# Chain-composition experiment: frozen design

Frozen on 2026-10-10, before any classification was run. The machine-readable parameters
are in `design.json`. Population hashes are in `FREEZE.txt`, written by `run.sh freeze` after
generation and before `run.sh classify`.

**What this is.** A constructed mechanism experiment. It measures the precision gap that the
instruction-summary results describe: dependence on the composed store expression versus
the shipped instruction-local classifier and its register-chain closure. It is **not**
prevalence evidence.

- The threads are generated from fixed templates.
- No instance was chosen after seeing a classifier verdict.
- No frequency or confidence-interval claim follows from it.

## Programs

One C-litmus thread per program, run through the shipped `LitmusParser` unmodified. The
thread has three parts:

1. **Loads.** `rK = READ_ONCE(*xJ)`. Each load event gets a fresh input symbol `L<k>`, in
   program order. Reloading a register creates a new symbol, so SSA identity is preserved.
2. **Assignments.** `t = e`, where `e` is from the BV32 grammar:
   - binary `+ - * & | ^`;
   - unary `~ -`;
   - decimal literals ≤ 65535.

   There are no pointers, branches, RMWs, shifts, casts, calls or hex literals.
3. **Store.** Exactly one final plain store, `WRITE_ONCE(*y, reg)`.

**Register rules:**
- Every register is defined before it is used.
- No register is initialised in the litmus header.
- Every fixed constant is either a literal or a preceding assignment (`k = 12`).

So the free-input dependence query and the implementation's treatment of unwritten
registers (pinned to 0) never diverge on these inputs.

**Generation.** Threads are built as typed ASTs (`gen.py`). They are printed with minimal
C-precedence parentheses; this precedence is also the oracle's. A unary minus used as a
binary operand is printed as `(-x)`.

**Composition.** It runs on the AST: each assignment substitutes the current bindings, and
each load binds a fresh symbol.

**Direct-site counterpart.** The same loads, one assignment carrying the whole composed
expression over the load registers, then the store.

## Templates (L = template length parameter)

All constants are drawn from fixed pools with the frozen seed `20261010`, in template order.

### Cancellation (expected composed FAKE in the cancelled input)

| Template | Thread | Expected |
|---|---|---|
| CAN-ADD | `t1=r0+K; u_i=u_{i-1}±K (L-1 steps); s=u-r0` | L0 FAKE |
| CAN-XOR | `t1=r0^K; u_i=u_{i-1}^K (L-1); s=u^r0` | L0 FAKE |
| CAN-COPY | `t_i=t_{i-1}` copies (L); `s=t^r0` (d0) or `s=t-r0` (d1) | L0 FAKE |
| CAN-DUP | two identical L-step injective chains from r0; `s=a-b` (d0) or `a^b` (d1) | L0 FAKE |
| CAN-2IN | loads r0, r1; `t1=r0+r1`; ±K steps; `s=u-r0` | L0 FAKE, L1 REAL |
| CAN-RELOAD | as CAN-ADD, but r0 is **reloaded** before `s=u-r0` (chain only) | L0 REAL, L1 REAL |

### Masking

| Template | Thread | Expected |
|---|---|---|
| MSK-DISJ | L successive `&M` masks, running AND non-zero until the last, which clears it | L0 FAKE |
| MSK-RETAIN | same, but the last mask keeps at least one bit | L0 REAL |
| MSK-MUL | `t1=r0*2^j`; L-1 low-bit-preserving steps (`+c·2^j`, `^c·2^j`, `*odd`); `s=u&M`; d0: `M<2^j` | d0 L0 FAKE, d1 (`M∋2^j`) L0 REAL |
| MSK-INREG | as MSK-DISJ/RETAIN, final mask held in a register set by a preceding assignment (chain only) | even draws L0 FAKE; odd L0 REAL |
| MSK-2IN | masks on r0 disjoint from final M; `v=r1&M3` (`M3⊇M`); `s=(u\|v)&M` | L0 FAKE, L1 REAL |

### Injective pipelines (expected REAL)

| Template | Thread | Expected |
|---|---|---|
| INJ-MIX | L steps from {`+K`, `-K`, `^K`, `*odd`, `~`, unary `-`} | L0 REAL |
| INJ-2IN | `t1=r0^r1` (d0) or `r0+r1` (d1); L-1 injective steps | L0 REAL, L1 REAL |

### Controls (fixed list, 14)

- Direct store of a load.
- Copy.
- `r0+1`.
- `r0^r0`.
- `r0^r0^1`.
- `r0*0`.
- `r0&0`.
- Overwrite of a derived register by a constant.
- Overwrite of the load register.
- Reload with only the second load used.
- Reload with both loads used.
- Two independent inputs.
- A constant register `k=3` multiplying.
- A constant register `k=0` multiplying (expected FAKE).

### Lengths, draws and counts

- Lengths are those in `design.json`. Each (template, L, draw) gives one chain instance,
  plus a direct counterpart where `direct` is set.
- 256 threads and 317 (load, store) pairs; the cap is 300 threads.
- Unique normalized programs (alpha-renamed registers) and unique shapes (constants also
  abstracted) are reported separately from template instances.

The expectations above are hand-derived from each template's algebra:
- cancellation: `x+K-x`, `x^K^x`, `f(x)-f(x)`;
- masking: an AND of masks is 0 iff the masks are disjoint; `x·2^j` has its low `j` bits
  zero;
- injectivity: each step is a bijection on BV32 in the carried register.

## Comparisons, per (load k, store) pair

| | Local decision | Composition |
|---|---|---|
| **A** | shipped `classify()`: idiom folding plus linear cancellation (`CONSTANCY_ORACLE = null`) | shipped chain closure (AND along a chain, OR across sources) |
| **B** | shipped QF_BV oracle, per instruction, other registers free (`CONSTANCY_ORACLE` installed) | same shipped closure |
| **C** | none | shipped QF_BV oracle on the generator's composed store expression, target `L<k>` |

- **A and B** are read off the shipped `DependencyInfo` DATA edge (store, read): REAL or BOTH
  count as REAL; FAKE or ABSENT count as FAKE. The adapter (`adapter/ChainCompositionRun.java`)
  calls the implementation through its public API only.
- **Cship** is the oracle on the shipped `writeValueExprs` string. It is a consistency check
  only.

## Validation (`validate.py`, independent of the Java code and of the composer)

1. **Parse fidelity.** The shipped parse has the intended read count and order, each read's
   location and register, one store to `y`, and the raw store register.
2. **Concrete execution.** A separate interpreter runs the instructions over 256 valuations,
   30% of them drawn from edge values. Results are compared with the composed expression.
3. **Shipped composition.** The shipped `writeValueExprs` string, parsed by a separate
   parser with `R<id>` renamed to `L<k>`, must be z3-equivalent to the composed expression.
4. **Independent dependence.** Python z3, with an encoding written in `validate.py`, decides
   each pair.
   - REAL verdicts need a witness: two concrete executions that differ only in `L<k>` and
     give different stores.
   - The oracle's C must equal the z3 verdict.
   - The template expectation is compared with z3.
5. **Hand cases** (`hand_cases.py`, 10 cases covering every family plus a control). For
   each, the composed expression, one concrete store value and the per-load verdicts are
   written by hand, and checked against:
   - the generator's composer;
   - concrete execution;
   - the shipped composition;
   - the oracle;
   - z3.

## Categories and reporting

- **Per pair and configuration X ∈ {A, B}:** agree-REAL, agree-FAKE,
  closureREAL/composedFAKE (precision loss), closureFAKE/composedREAL (soundness failure).
- **Error classes** are reported explicitly and never counted as agreement or REAL: parse,
  extraction or composition mismatch, unsupported, timeout (60 s per parse or query), and
  oracle/z3 disagreement.
- **Tables** are broken down by family × template length and by variant.

**Stop rule.** If any closureFAKE/composedREAL pair is confirmed by an execution witness,
`validate.py` writes `results/STOP-repro.txt` with the smallest such thread. The experiment
then stops, and no shipped code is changed.
