# Chain-composition experiment: report

2026-10-10. A constructed mechanism experiment, **not prevalence evidence**.

- **Changed:** only new files in `eval/chain-composition/`.
- **Unchanged:** the paper, the bibliography, Isabelle, the shipped code and existing results.
- **Git:** no git state was changed and GitHub was not accessed.
- **Build location:** compiled classes are outside the repository (`$CHAIN_BUILD`).

## 0. Entry check (existing `CoherencePairs` adapter and `pairs-corpus.csv`)

Source of the existing comparison:
- **Adapter:** `wev-smt-audit/2026-10-09-coherence-check/adapter/CoherencePairs.java`.
- **Data:** `2026-10-09-final-rerun/mirror/out/pairs-corpus.csv` (SHA-256 `ebcfe81b…`).

| Question | Finding |
|---|---|
| How are pairs enumerated? | For every non-init plain write `c` of every input, the reads in S(c) ∪ O(c) ∪ vars(composed(c)). These are the shipped DATA edges under both configurations, plus every read mentioned in the front end's `writeValueExprs` string. |
| Are omitted shipped edges included? | Yes. A read in the composed string with no shipped edge gets closure `ABSENT` and its own category. On this corpus none occurs: all 374 rows are plain agree-FAKE or agree-REAL. |
| Is the population filtered to fake-carrying tests or sites? | No. All 2,396 eligible files were run (the file set equals the frozen eligible set). 2,106 files yield no pair; 290 yield 374 pairs. There are no control edges, and no pair is an RMW. |
| What do REAL and FAKE mean? | `S`/`O` is the shipped edge's `isSemantic()` with no oracle (S) or with the QF_BV oracle installed (O). `C` is the QF_BV oracle on the front end's composed string for `R<readId>`: VARIES is REAL, CONST is FAKE. |
| 374 = 368 + 6? | Yes. 368 agree-FAKE plus 6 agree-REAL, identically under S and O. 0 disagreements, 0 unsupported, 0 errors. |
| Does the manuscript match? | Yes; no material discrepancy. App. A.5 states the population, both configurations, and that the composed object is the implementation's composition. |

Two points to flag (neither is a mismatch):
- **Shape concentration.** 368 of the 374 pairs are a single normalised shape,
  `((R^R)+1)`, the false-dependency idiom. The 6 REAL pairs are 3 direct copies, 2 two-read
  XORs and 1 `R|1`. "All 374 data pairs" is accurate but covers 4 shapes.
- **Composed object.** The main-text phrase "composed-label dependence" rests on the front
  end's `writeValueExprs`, not on the mechanised λ. The appendix says this; the main text
  does not.

## 1. Frozen design

- **Where:** `DESIGN.md` and `design.json`, with hashes in `FREEZE.txt`. These were written
  after generation and **before** compilation or classification.
- **Generator:** `gen.py` builds typed ASTs, uses fresh `L<k>` symbols per load event, and
  composes over the AST.
- **Population:** 14 templates, seed `20261010`, cap 300. That gives 256 threads and 317
  (load, store) pairs.
- **Uniqueness:** 236 distinct programs and 168 distinct shapes; 291 distinct normalised
  (program, load) pairs and 213 distinct (shape, load) pairs. [Package addition; see
  ERRATA.md.]
- **Amendments after the freeze**, both recorded in `FREEZE.txt`; neither touches the design,
  generator, adapter or analysis:
  - `run.sh` passes Windows-form classpaths;
  - `run.sh` calls `python -B`.

**Comparisons.**
- **A:** shipped folding `classify()` plus the shipped chain closure (`CONSTANCY_ORACLE = null`).
- **B:** shipped QF_BV oracle per instruction (other registers free) plus the same closure.
- **C:** shipped QF_BV oracle on the generator's composed store expression.

The adapter, `adapter/ChainCompositionRun.java`, calls the unmodified shipped classes through
their public API. The compiled main classes hash to `86f06894…`, which is the
compiled-classes hash the paper pins for the evaluated tree (`results/build-provenance.txt`).

## 2. Validation (`results/validation-summary.txt`, `threads-validation.csv`, `hand-validation.csv`)

- **Parse fidelity.** All 256 threads match the intended read count and order, the location
  and register of each read, one store to `y`, and the raw store register.
- **Concrete execution versus composition.** A separate interpreter ran 256 valuations per
  thread (30% edge values). There were 0 mismatches.
- **Shipped `writeValueExprs`.** The string, read by a separate parser with `R<id>` renamed
  to `L<k>`, is z3-equivalent to the composed expression on all 256 threads. The composition
  defects known from earlier audits (hex literals, PPC `mr`/`neg` lowering, `#` stripping) are
  outside this C-only, decimal-literal population.
- **Independent dependence.** Python z3, with an encoding written in `validate.py`, agrees with
  the shipped oracle C on 317/317 pairs.
  - The template's hand-derived expectation matches z3 on 317/317.
  - All 171 REAL verdicts have an execution witness: two runs that differ only in that load
    and store different values.
- **Hand cases.** 10 cases, 12 pairs, covering all four families. Every check passes:
  - read parsing;
  - generator composer ≡ hand-written expression;
  - concrete execution = hand-computed value;
  - hand string = hand value;
  - shipped composition ≡ hand expression;
  - oracle = expectation;
  - z3 = expectation.
- **Errors, unsupported cases, timeouts:** none.
- **Stop rule:** not triggered. There is no closure-FAKE/composed-REAL pair under A or B.

## 3. Results (`results/tables.md`)

Composed analysis (C): 171 REAL, 146 FAKE.

| Composed-FAKE pairs (146) | Pairs | A misses (closure REAL) | B misses (closure REAL) |
|---|---|---|---|
| Single instruction (direct counterparts) | 66 | 36 (CAN-XOR 10, CAN-DUP 8, MSK-DISJ 8, MSK-2IN 6, MSK-MUL 4) | **0** |
| Chain (same algebra, across assignments) | 72 | **72** | **72** |
| Controls | 8 | 1 (`k=0; s=r0*k`) | 1 (same) |

| Composed-REAL pairs (171) | A agree | B agree |
|---|---|---|
| All, including injective pipelines up to 8 steps, reload identity, retained masks and 2-input threads | 171 | 171 |

**Totals.**
- **A:** 208 agree, 109 closureREAL/composedFAKE (108 unique program/input, 77 shapes),
  0 closureFAKE/composedREAL.
- **B:** 244 agree, 73 closureREAL/composedFAKE (72 unique program/input, 53 shapes),
  0 closureFAKE/composedREAL.

**By chain length.** Every chain-form FAKE pair is lost at every length, from L=1 (the bare
two-instruction witnesses) to L=6. The loss is not a long-chain effect. For example, in the
cancellation family, B misses 10 of 28 pairs at each of L=1–4 and 8 of 24 at L=6 (the
chain-form FAKE pairs); its direct counterparts are all recovered. The full breakdown by
family × L, by template × variant, and by assignment count is in `tables.md`.

## 4. Representative traces (`results/traces.md`; selection fixed before the run)

**CAN-ADD-L2 chain.** Thread `t1=r0+100; u1=t1+100; s=u1-r0`.
- Every local decision is REAL under A and B.
- The closure is REAL, while the composed expression `L0+100+100-L0` is CONST.

**MSK-DISJ-L2 chain.** Thread `t1=r0&6020; t2=t1&43106`.
- Both masks are locally REAL.
- The composed expression `L0&6020&43106` is 0.

**MSK-INREG-L2 / CTRL-CONSTREG-ZERO.**
- The final mask, or the zero multiplier, is held in a register set by a preceding constant
  assignment.
- The local query treats that register as free (B reports `QFBV_VARIES` on `k`), so even the
  single-instruction `s=r0*k` with `k=0` is closure-REAL.

**CAN-RELOAD-L2 chain.** Thread `t1=r0+3; u1=t1+7; r0=load(x0); s=u1-r0`.
- The shipped parse keeps the two loads distinct (`R0`, `R2`).
- The composed expression `L0+3+7-L1` is REAL in both loads, and A, B and C agree. A
  name-based composer would wrongly cancel it.

## 5. Connection to the paper

**Existing witnesses.** The §3.2 cancellation witness `t:=x+1; y:=t−x` is the CAN-ADD L=1
chain shape (`r0+K; s=t1−r0`). The masking witness `t:=x&1; y:=t&2` is the MSK-DISJ L=2 chain
shape. Both are closure-REAL/composed-FAKE under A *and* B. `k=0; s=r0*k` instantiates the
mechanism behind §3.2's `s←0; store(x, r*s+1)`: an instruction-local query cannot see a
register's known constant.

**Exact local classification still loses precision.** Making every local decision exact (B)
recovers all 66 single-instruction FAKE pairs and **none** of the 72 chain-form ones. The
precision that remains after exact local decisions is lost entirely in composition. This is
the separation Thms. 1–2 describe for read-restricted per-instruction summaries. It is a
constructed instance, not a new result.

**Injective pipelines remain exact.** All 80 injective-pipeline pairs (L up to 8, including
two-input heads) agree under A and B. This is consistent with `pipeline_exact`: each step is
injective in the carried register.

**Beyond Table 2 (single-site hard bench).** Table 2 measures local decision imprecision only,
folding versus oracle on one expression. Here the direct counterparts reproduce that kind of
gap: A misses 36, B misses 0. The chain variants add the other component: the *same* algebra
spread across assignments defeats an exact local oracle too. This separates
local-decision imprecision (36 pairs) from composition imprecision (72 pairs) on one
template population.

## 6. Limitations

- **Constructed population.** Templates and constants are fixed, and counts reflect the
  design, not any frequency. No population confidence intervals and no claim about naturally
  occurring code.
- **No verdicts.** This measures dependence edges only; candidate verdicts were not computed
  in this session.
- **Narrow fragment.** C front end only, one thread, one store, BV32 `+ - * & | ^ ~ -` with
  decimal literals ≤65535. No branches, control edges, addresses, RMW, shifts or assembly
  lowering, so the known PPC/AArch64 lowering defects are not exercised.
- **Same solver underneath.** C uses the same shipped oracle code as B. Independence comes
  from a separate Python z3 encoding plus execution witnesses, but both run on Z3. FAKE
  verdicts (UNSAT) are not independently witnessed by execution.
- **A depends on text form.** A's results are textual-idiom dependent: the direct
  counterparts use minimal C-precedence parentheses, and another printing could change
  which single-instruction FAKEs folding catches.
- **Duplicated instances.** Some template instances coincide: CAN-COPY direct collapses to 2
  programs, and the injective family at L=1 has 12 threads, 5 distinct programs and 7
  distinct program/load pairs over 16 pairs. Unique counts are reported separately.
  [Package erratum: the original read "7 unique programs"; see ERRATA.md.]
- **Uncommitted shipped code.** The shipped code is the uncommitted working tree. Its
  compiled-classes hash matches the paper's pin, but no git revision identifies it.

## 7. Proposed manuscript text (not applied)

> **Chain composition (App. A.5; constructed, not prevalence evidence).** On 256 generated
> straight-line threads (317 load–store pairs, 213 distinct shape/input pairs) drawn from
> fixed cancellation, masking and injective-pipeline templates, the shipped closure never
> drops a dependency the composed store expression carries, under either local decision
> procedure. With the exact QF\_BV oracle deciding each instruction, it recovers all 66
> composed-fake pairs written as one instruction but none of the 72 written as a chain,
> including instances of both §3.2 witnesses; folding alone also misses 36 of the 66. All
> 171 composed-real pairs, injective pipelines of up to eight steps among them, agree.

## 8. Files created (all new, under `eval/chain-composition/`)

**Design and freeze:**
- `DESIGN.md`
- `design.json`
- `FREEZE.txt`

**Code:**
- `gen.py`
- `hand_cases.py`
- `adapter/ChainCompositionRun.java`
- `validate.py`
- `summarize.py`
- `run.sh`

**Results (`results/`):**
- `generated/` — 256 `.litmus` inputs, `manifest.json`, `queries.tsv`.
- `generated-SHA256SUMS`.
- `validation/` — 10 hand inputs, `hand.json`, `queries.tsv`, `raw/`.
- `raw/` — `pairs-raw.csv`, `trace.csv`, `events.csv`.
- `pairs-final.csv`, `threads-validation.csv`, `hand-validation.csv`.
- `validation-summary.txt`, `tables.md`, `traces.md`, `build-provenance.txt`.

**Report:** `REPORT.md` (this file).

## 9. Reproduction

```
export CHAIN_BUILD=<directory outside the repository>
bash eval/chain-composition/run.sh generate    # deterministic; manifest sha256 cd2d153f…
bash eval/chain-composition/run.sh compile     # main classes sha256 86f06894…
bash eval/chain-composition/run.sh classify    # ~10 s
bash eval/chain-composition/run.sh validate
bash eval/chain-composition/run.sh summarize
```

Regenerating, re-validating and re-summarising reproduced `manifest.json`, the inputs,
`pairs-final.csv` and `tables.md` byte-identically.
