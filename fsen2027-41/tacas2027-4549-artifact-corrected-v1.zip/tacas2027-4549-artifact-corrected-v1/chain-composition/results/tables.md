# Chain-composition results

R/F = closure REAL / composed FAKE (precision loss); F/R = closure FAKE / composed REAL (soundness failure). A = shipped folding classifier + closure; B = exact oracle per instruction + same closure; C = exact oracle on the composed store expression. "uniq" columns count distinct (normalized program, load) pairs; template instances are the "pairs" column.

### By family and template length L

| group | threads | pairs | uniq prog/input | uniq shape/input | C REAL | C FAKE | A agree | A R/F | A F/R | B agree | B R/F | B F/R | errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cancellation / 1 | 22 | 28 | 24 | 18 | 8 | 20 | 14 | 14 | 0 | 18 | 10 | 0 | 0 |
| cancellation / 2 | 22 | 28 | 28 | 22 | 8 | 20 | 14 | 14 | 0 | 18 | 10 | 0 | 0 |
| cancellation / 3 | 22 | 28 | 28 | 24 | 8 | 20 | 14 | 14 | 0 | 18 | 10 | 0 | 0 |
| cancellation / 4 | 22 | 28 | 28 | 24 | 8 | 20 | 14 | 14 | 0 | 18 | 10 | 0 | 0 |
| cancellation / 6 | 18 | 24 | 24 | 20 | 8 | 16 | 14 | 10 | 0 | 16 | 8 | 0 | 0 |
| control / 0 | 14 | 17 | 17 | 16 | 9 | 8 | 16 | 1 | 0 | 16 | 1 | 0 | 0 |
| injective / 1 | 12 | 16 | 7 | 7 | 16 | 0 | 16 | 0 | 0 | 16 | 0 | 0 | 0 |
| injective / 2 | 12 | 16 | 16 | 14 | 16 | 0 | 16 | 0 | 0 | 16 | 0 | 0 | 0 |
| injective / 3 | 8 | 8 | 8 | 8 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| injective / 4 | 12 | 16 | 16 | 16 | 16 | 0 | 16 | 0 | 0 | 16 | 0 | 0 | 0 |
| injective / 6 | 12 | 16 | 16 | 16 | 16 | 0 | 16 | 0 | 0 | 16 | 0 | 0 | 0 |
| injective / 8 | 8 | 8 | 8 | 8 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| masking / 1 | 4 | 4 | 4 | 2 | 2 | 2 | 2 | 2 | 0 | 3 | 1 | 0 | 0 |
| masking / 2 | 20 | 24 | 24 | 9 | 12 | 12 | 12 | 12 | 0 | 17 | 7 | 0 | 0 |
| masking / 3 | 20 | 24 | 24 | 11 | 12 | 12 | 12 | 12 | 0 | 17 | 7 | 0 | 0 |
| masking / 4 | 20 | 24 | 24 | 11 | 12 | 12 | 12 | 12 | 0 | 17 | 7 | 0 | 0 |
| masking / 6 | 8 | 8 | 8 | 2 | 4 | 4 | 4 | 4 | 0 | 6 | 2 | 0 | 0 |
| **total** | 256 | 317 | 291 | 213 | 171 | 146 | 208 | 109 | 0 | 244 | 73 | 0 | 0 |

### By family and variant (chain vs direct)

| group | threads | pairs | uniq prog/input | uniq shape/input | C REAL | C FAKE | A agree | A R/F | A F/R | B agree | B R/F | B F/R | errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cancellation / chain | 58 | 78 | 76 | 62 | 30 | 48 | 30 | 48 | 0 | 30 | 48 | 0 | 0 |
| cancellation / direct | 48 | 58 | 48 | 38 | 10 | 48 | 40 | 18 | 0 | 58 | 0 | 0 | 0 |
| control / control | 14 | 17 | 17 | 16 | 9 | 8 | 16 | 1 | 0 | 16 | 1 | 0 | 0 |
| injective / chain | 32 | 40 | 39 | 38 | 40 | 0 | 40 | 0 | 0 | 40 | 0 | 0 | 0 |
| injective / direct | 32 | 40 | 39 | 38 | 40 | 0 | 40 | 0 | 0 | 40 | 0 | 0 | 0 |
| masking / chain | 42 | 48 | 48 | 19 | 24 | 24 | 24 | 24 | 0 | 24 | 24 | 0 | 0 |
| masking / direct | 30 | 36 | 36 | 16 | 18 | 18 | 18 | 18 | 0 | 36 | 0 | 0 | 0 |
| **total** | 256 | 317 | 291 | 213 | 171 | 146 | 208 | 109 | 0 | 244 | 73 | 0 | 0 |

### By template and variant

| group | threads | pairs | uniq prog/input | uniq shape/input | C REAL | C FAKE | A agree | A R/F | A F/R | B agree | B R/F | B F/R | errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CAN-2IN / chain | 10 | 20 | 18 | 16 | 10 | 10 | 10 | 10 | 0 | 10 | 10 | 0 | 0 |
| CAN-2IN / direct | 10 | 20 | 18 | 16 | 10 | 10 | 20 | 0 | 0 | 20 | 0 | 0 | 0 |
| CAN-ADD / chain | 10 | 10 | 10 | 7 | 0 | 10 | 0 | 10 | 0 | 0 | 10 | 0 | 0 |
| CAN-ADD / direct | 10 | 10 | 10 | 7 | 0 | 10 | 10 | 0 | 0 | 10 | 0 | 0 | 0 |
| CAN-COPY / chain | 10 | 10 | 10 | 10 | 0 | 10 | 0 | 10 | 0 | 0 | 10 | 0 | 0 |
| CAN-COPY / direct | 10 | 10 | 2 | 2 | 0 | 10 | 10 | 0 | 0 | 10 | 0 | 0 | 0 |
| CAN-DUP / chain | 8 | 8 | 8 | 8 | 0 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 |
| CAN-DUP / direct | 8 | 8 | 8 | 8 | 0 | 8 | 0 | 8 | 0 | 8 | 0 | 0 | 0 |
| CAN-RELOAD / chain | 10 | 20 | 20 | 16 | 20 | 0 | 20 | 0 | 0 | 20 | 0 | 0 | 0 |
| CAN-XOR / chain | 10 | 10 | 10 | 5 | 0 | 10 | 0 | 10 | 0 | 0 | 10 | 0 | 0 |
| CAN-XOR / direct | 10 | 10 | 10 | 5 | 0 | 10 | 0 | 10 | 0 | 10 | 0 | 0 | 0 |
| CTRL / control | 14 | 17 | 17 | 16 | 9 | 8 | 16 | 1 | 0 | 16 | 1 | 0 | 0 |
| INJ-2IN / chain | 8 | 16 | 16 | 16 | 16 | 0 | 16 | 0 | 0 | 16 | 0 | 0 | 0 |
| INJ-2IN / direct | 8 | 16 | 16 | 16 | 16 | 0 | 16 | 0 | 0 | 16 | 0 | 0 | 0 |
| INJ-MIX / chain | 24 | 24 | 23 | 22 | 24 | 0 | 24 | 0 | 0 | 24 | 0 | 0 | 0 |
| INJ-MIX / direct | 24 | 24 | 23 | 22 | 24 | 0 | 24 | 0 | 0 | 24 | 0 | 0 | 0 |
| MSK-2IN / chain | 6 | 12 | 12 | 6 | 6 | 6 | 6 | 6 | 0 | 6 | 6 | 0 | 0 |
| MSK-2IN / direct | 6 | 12 | 12 | 6 | 6 | 6 | 6 | 6 | 0 | 12 | 0 | 0 | 0 |
| MSK-DISJ / chain | 8 | 8 | 8 | 4 | 0 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 |
| MSK-DISJ / direct | 8 | 8 | 8 | 4 | 0 | 8 | 0 | 8 | 0 | 8 | 0 | 0 | 0 |
| MSK-INREG / chain | 12 | 12 | 12 | 3 | 6 | 6 | 6 | 6 | 0 | 6 | 6 | 0 | 0 |
| MSK-MUL / chain | 8 | 8 | 8 | 6 | 4 | 4 | 4 | 4 | 0 | 4 | 4 | 0 | 0 |
| MSK-MUL / direct | 8 | 8 | 8 | 6 | 4 | 4 | 4 | 4 | 0 | 8 | 0 | 0 | 0 |
| MSK-RETAIN / chain | 8 | 8 | 8 | 4 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| MSK-RETAIN / direct | 8 | 8 | 8 | 4 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| **total** | 256 | 317 | 291 | 213 | 171 | 146 | 208 | 109 | 0 | 244 | 73 | 0 | 0 |

### By family and number of assignments

| group | threads | pairs | uniq prog/input | uniq shape/input | C REAL | C FAKE | A agree | A R/F | A F/R | B agree | B R/F | B F/R | errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cancellation / 1 | 48 | 58 | 48 | 38 | 10 | 48 | 40 | 18 | 0 | 58 | 0 | 0 | 0 |
| cancellation / 2 | 10 | 14 | 12 | 8 | 6 | 8 | 6 | 8 | 0 | 6 | 8 | 0 | 0 |
| cancellation / 3 | 12 | 16 | 16 | 13 | 6 | 10 | 6 | 10 | 0 | 6 | 10 | 0 | 0 |
| cancellation / 4 | 10 | 14 | 14 | 11 | 6 | 8 | 6 | 8 | 0 | 6 | 8 | 0 | 0 |
| cancellation / 5 | 12 | 16 | 16 | 14 | 6 | 10 | 6 | 10 | 0 | 6 | 10 | 0 | 0 |
| cancellation / 7 | 12 | 16 | 16 | 14 | 6 | 10 | 6 | 10 | 0 | 6 | 10 | 0 | 0 |
| cancellation / 9 | 2 | 2 | 2 | 2 | 0 | 2 | 0 | 2 | 0 | 0 | 2 | 0 | 0 |
| control / 0 | 2 | 3 | 3 | 3 | 2 | 1 | 3 | 0 | 0 | 3 | 0 | 0 | 0 |
| control / 1 | 8 | 9 | 9 | 9 | 4 | 5 | 9 | 0 | 0 | 9 | 0 | 0 | 0 |
| control / 2 | 4 | 5 | 5 | 4 | 3 | 2 | 4 | 1 | 0 | 4 | 1 | 0 | 0 |
| injective / 1 | 38 | 48 | 39 | 38 | 48 | 0 | 48 | 0 | 0 | 48 | 0 | 0 | 0 |
| injective / 2 | 6 | 8 | 8 | 7 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| injective / 3 | 4 | 4 | 4 | 4 | 4 | 0 | 4 | 0 | 0 | 4 | 0 | 0 | 0 |
| injective / 4 | 6 | 8 | 8 | 8 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| injective / 6 | 6 | 8 | 8 | 8 | 8 | 0 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| injective / 8 | 4 | 4 | 4 | 4 | 4 | 0 | 4 | 0 | 0 | 4 | 0 | 0 | 0 |
| masking / 1 | 30 | 36 | 36 | 16 | 18 | 18 | 18 | 18 | 0 | 36 | 0 | 0 | 0 |
| masking / 2 | 6 | 6 | 6 | 2 | 3 | 3 | 3 | 3 | 0 | 3 | 3 | 0 | 0 |
| masking / 3 | 10 | 10 | 10 | 3 | 5 | 5 | 5 | 5 | 0 | 5 | 5 | 0 | 0 |
| masking / 4 | 12 | 14 | 14 | 6 | 7 | 7 | 7 | 7 | 0 | 7 | 7 | 0 | 0 |
| masking / 5 | 8 | 10 | 10 | 5 | 5 | 5 | 5 | 5 | 0 | 5 | 5 | 0 | 0 |
| masking / 6 | 6 | 8 | 8 | 3 | 4 | 4 | 4 | 4 | 0 | 4 | 4 | 0 | 0 |
| **total** | 256 | 317 | 291 | 213 | 171 | 146 | 208 | 109 | 0 | 244 | 73 | 0 | 0 |

### Distinct shapes behind each disagreement class

- A closureREAL/composedFAKE: 109 pairs, 108 unique program/input, 77 shapes; templates {'CAN-ADD': 10, 'CAN-XOR': 20, 'CAN-COPY': 10, 'CAN-DUP': 16, 'CAN-2IN': 10, 'MSK-DISJ': 16, 'MSK-MUL': 8, 'MSK-INREG': 6, 'MSK-2IN': 12, 'CTRL-CONSTREG-ZERO': 1}
- A closureFAKE/composedREAL: 0 pairs, 0 unique program/input, 0 shapes; templates {}
- B closureREAL/composedFAKE: 73 pairs, 72 unique program/input, 53 shapes; templates {'CAN-ADD': 10, 'CAN-XOR': 10, 'CAN-COPY': 10, 'CAN-DUP': 8, 'CAN-2IN': 10, 'MSK-DISJ': 8, 'MSK-MUL': 4, 'MSK-INREG': 6, 'MSK-2IN': 6, 'CTRL-CONSTREG-ZERO': 1}
- B closureFAKE/composedREAL: 0 pairs, 0 unique program/input, 0 shapes; templates {}

### Errors, unsupported, timeouts

- none
