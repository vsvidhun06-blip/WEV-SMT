# Representative traces

Per instruction: the shipped `classify(expr, reg)` decision under A (folding) and B (oracle per instruction), then the pair verdicts. Selection fixed before the run.

## CAN-ADD-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0 + 100;
  u1 = t1 + 100;
  s = u1 - r0;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 + 100` | r0 | true | REAL |
| A | 2 | `t1 + 100` | t1 | true | REAL |
| A | 3 | `u1 - r0` | u1 | true | REAL |
| A | 3 | `u1 - r0` | r0 | true | REAL |
| A | 4 | `s` | s | true | REAL |
| B | 1 | `r0 + 100` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 + 100` | t1 | true | QFBV_VARIES |
| B | 3 | `u1 - r0` | u1 | true | QFBV_VARIES |
| B | 3 | `u1 - r0` | r0 | true | QFBV_VARIES |
| B | 4 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 + 100 + 100 - L0` (shipped `((((R0) + 100) + 100) - (R0))`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## CAN-ADD-L2-d0-direct

```c
r0 = READ_ONCE(*x0);
  s = r0 + 100 + 100 - r0;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 + 100 + 100 - r0` | r0 | false | LINEAR_CANCEL |
| A | 2 | `s` | s | true | REAL |
| B | 1 | `r0 + 100 + 100 - r0` | r0 | false | QFBV_CONST |
| B | 2 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 + 100 + 100 - L0` (shipped `((R0) + 100 + 100 - (R0))`); A=FAKE B=FAKE C=FAKE z3=FAKE expected=FAKE -> A agree-FAKE, B agree-FAKE

## CAN-XOR-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0 ^ 1;
  u1 = t1 ^ 12;
  s = u1 ^ r0;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 ^ 1` | r0 | true | REAL |
| A | 2 | `t1 ^ 12` | t1 | true | REAL |
| A | 3 | `u1 ^ r0` | u1 | true | REAL |
| A | 3 | `u1 ^ r0` | r0 | true | REAL |
| A | 4 | `s` | s | true | REAL |
| B | 1 | `r0 ^ 1` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 ^ 12` | t1 | true | QFBV_VARIES |
| B | 3 | `u1 ^ r0` | u1 | true | QFBV_VARIES |
| B | 3 | `u1 ^ r0` | r0 | true | QFBV_VARIES |
| B | 4 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 ^ 1 ^ 12 ^ L0` (shipped `((((R0) ^ 1) ^ 12) ^ (R0))`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## CAN-COPY-L1-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0;
  s = t1 ^ r0;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0` | r0 | true | REAL |
| A | 2 | `t1 ^ r0` | t1 | true | REAL |
| A | 2 | `t1 ^ r0` | r0 | true | REAL |
| A | 3 | `s` | s | true | REAL |
| B | 1 | `r0` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 ^ r0` | t1 | true | QFBV_VARIES |
| B | 2 | `t1 ^ r0` | r0 | true | QFBV_VARIES |
| B | 3 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 ^ L0` (shipped `(((R0)) ^ (R0))`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## CAN-DUP-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  a1 = r0 ^ 1;
  a2 = a1 + 12;
  b1 = r0 ^ 1;
  b2 = b1 + 12;
  s = a2 - b2;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 ^ 1` | r0 | true | REAL |
| A | 2 | `a1 + 12` | a1 | true | REAL |
| A | 3 | `r0 ^ 1` | r0 | true | REAL |
| A | 4 | `b1 + 12` | b1 | true | REAL |
| A | 5 | `a2 - b2` | a2 | true | REAL |
| A | 5 | `a2 - b2` | b2 | true | REAL |
| A | 6 | `s` | s | true | REAL |
| B | 1 | `r0 ^ 1` | r0 | true | QFBV_VARIES |
| B | 2 | `a1 + 12` | a1 | true | QFBV_VARIES |
| B | 3 | `r0 ^ 1` | r0 | true | QFBV_VARIES |
| B | 4 | `b1 + 12` | b1 | true | QFBV_VARIES |
| B | 5 | `a2 - b2` | a2 | true | QFBV_VARIES |
| B | 5 | `a2 - b2` | b2 | true | QFBV_VARIES |
| B | 6 | `s` | s | true | QFBV_VARIES |

- L0: composed `(L0 ^ 1) + 12 - ((L0 ^ 1) + 12)` (shipped `((((R0) ^ 1) + 12) - (((R0) ^ 1) + 12))`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## CAN-2IN-L1-d0-chain

```c
r0 = READ_ONCE(*x0);
  r1 = READ_ONCE(*x1);
  t1 = r0 + r1;
  s = t1 - r0;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 2 | `r0 + r1` | r0 | true | REAL |
| A | 2 | `r0 + r1` | r1 | true | REAL |
| A | 3 | `t1 - r0` | t1 | true | REAL |
| A | 3 | `t1 - r0` | r0 | true | REAL |
| A | 4 | `s` | s | true | REAL |
| B | 2 | `r0 + r1` | r0 | true | QFBV_VARIES |
| B | 2 | `r0 + r1` | r1 | true | QFBV_VARIES |
| B | 3 | `t1 - r0` | t1 | true | QFBV_VARIES |
| B | 3 | `t1 - r0` | r0 | true | QFBV_VARIES |
| B | 4 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 + L1 - L0` (shipped `(((R0) + (R2)) - (R0))`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE
- L1: composed `L0 + L1 - L0` (shipped `(((R0) + (R2)) - (R0))`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [0, 4294967295]->4294967295 vs [0, 0]->0

## CAN-RELOAD-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0 + 3;
  u1 = t1 + 7;
  r0 = READ_ONCE(*x0);
  s = u1 - r0;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 + 3` | r0 | true | REAL |
| A | 2 | `t1 + 7` | t1 | true | REAL |
| A | 4 | `u1 - r0` | u1 | true | REAL |
| A | 4 | `u1 - r0` | r0 | true | REAL |
| A | 5 | `s` | s | true | REAL |
| B | 1 | `r0 + 3` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 + 7` | t1 | true | QFBV_VARIES |
| B | 4 | `u1 - r0` | u1 | true | QFBV_VARIES |
| B | 4 | `u1 - r0` | r0 | true | QFBV_VARIES |
| B | 5 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 + 3 + 7 - L1` (shipped `((((R0) + 3) + 7) - (R2))`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [4294967295, 0]->9 vs [0, 0]->10
- L1: composed `L0 + 3 + 7 - L1` (shipped `((((R0) + 3) + 7) - (R2))`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [0, 4294967295]->11 vs [0, 0]->10

## MSK-DISJ-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0 & 6020;
  t2 = t1 & 43106;
  WRITE_ONCE(*y, t2);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 & 6020` | r0 | true | REAL |
| A | 2 | `t1 & 43106` | t1 | true | REAL |
| A | 3 | `t2` | t2 | true | REAL |
| B | 1 | `r0 & 6020` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 & 43106` | t1 | true | QFBV_VARIES |
| B | 3 | `t2` | t2 | true | QFBV_VARIES |

- L0: composed `L0 & 6020 & 43106` (shipped `(((R0) & 6020) & 43106)`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## MSK-DISJ-L2-d0-direct

```c
r0 = READ_ONCE(*x0);
  s = r0 & 6020 & 43106;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 & 6020 & 43106` | r0 | true | REAL |
| A | 2 | `s` | s | true | REAL |
| B | 1 | `r0 & 6020 & 43106` | r0 | false | QFBV_CONST |
| B | 2 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 & 6020 & 43106` (shipped `((R0) & 6020 & 43106)`); A=REAL B=FAKE C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B agree-FAKE

## MSK-RETAIN-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0 & 15380;
  t2 = t1 & 49287;
  WRITE_ONCE(*y, t2);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 & 15380` | r0 | true | REAL |
| A | 2 | `t1 & 49287` | t1 | true | REAL |
| A | 3 | `t2` | t2 | true | REAL |
| B | 1 | `r0 & 15380` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 & 49287` | t1 | true | QFBV_VARIES |
| B | 3 | `t2` | t2 | true | QFBV_VARIES |

- L0: composed `L0 & 15380 & 49287` (shipped `(((R0) & 15380) & 49287)`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [4]->4 vs [0]->0

## MSK-MUL-L1-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0 * 8;
  s = t1 & 2;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 * 8` | r0 | true | REAL |
| A | 2 | `t1 & 2` | t1 | true | REAL |
| A | 3 | `s` | s | true | REAL |
| B | 1 | `r0 * 8` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 & 2` | t1 | true | QFBV_VARIES |
| B | 3 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 * 8 & 2` (shipped `(((R0) * 8) & 2)`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## MSK-INREG-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  k = 680;
  t1 = r0 & 16403;
  s = t1 & k;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 2 | `r0 & 16403` | r0 | true | REAL |
| A | 3 | `t1 & k` | t1 | true | REAL |
| A | 3 | `t1 & k` | k | true | REAL |
| A | 4 | `s` | s | true | REAL |
| B | 2 | `r0 & 16403` | r0 | true | QFBV_VARIES |
| B | 3 | `t1 & k` | t1 | true | QFBV_VARIES |
| B | 3 | `t1 & k` | k | true | QFBV_VARIES |
| B | 4 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 & 16403 & 680` (shipped `(((R0) & 16403) & (680))`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## MSK-2IN-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  r1 = READ_ONCE(*x1);
  t1 = r0 & 14383;
  v1 = r1 & 58070;
  w = t1 | v1;
  s = w & 17104;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 2 | `r0 & 14383` | r0 | true | REAL |
| A | 3 | `r1 & 58070` | r1 | true | REAL |
| A | 4 | `t1 | v1` | t1 | true | REAL |
| A | 4 | `t1 | v1` | v1 | true | REAL |
| A | 5 | `w & 17104` | w | true | REAL |
| A | 6 | `s` | s | true | REAL |
| B | 2 | `r0 & 14383` | r0 | true | QFBV_VARIES |
| B | 3 | `r1 & 58070` | r1 | true | QFBV_VARIES |
| B | 4 | `t1 | v1` | t1 | true | QFBV_VARIES |
| B | 4 | `t1 | v1` | v1 | true | QFBV_VARIES |
| B | 5 | `w & 17104` | w | true | QFBV_VARIES |
| B | 6 | `s` | s | true | QFBV_VARIES |

- L0: composed `(L0 & 14383 | L1 & 58070) & 17104` (shipped `((((R0) & 14383) | ((R2) & 58070)) & 17104)`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE
- L1: composed `(L0 & 14383 | L1 & 58070) & 17104` (shipped `((((R0) & 14383) | ((R2) & 58070)) & 17104)`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [0, 16976]->16976 vs [0, 128]->128

## INJ-MIX-L4-d0-chain

```c
r0 = READ_ONCE(*x0);
  t1 = r0 ^ 5;
  t2 = t1 + 100;
  t3 = t2 - 12;
  t4 = t3 - 1;
  WRITE_ONCE(*y, t4);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 1 | `r0 ^ 5` | r0 | true | REAL |
| A | 2 | `t1 + 100` | t1 | true | REAL |
| A | 3 | `t2 - 12` | t2 | true | REAL |
| A | 4 | `t3 - 1` | t3 | true | REAL |
| A | 5 | `t4` | t4 | true | REAL |
| B | 1 | `r0 ^ 5` | r0 | true | QFBV_VARIES |
| B | 2 | `t1 + 100` | t1 | true | QFBV_VARIES |
| B | 3 | `t2 - 12` | t2 | true | QFBV_VARIES |
| B | 4 | `t3 - 1` | t3 | true | QFBV_VARIES |
| B | 5 | `t4` | t4 | true | QFBV_VARIES |

- L0: composed `(L0 ^ 5) + 100 - 12 - 1` (shipped `(((((R0) ^ 5) + 100) - 12) - 1)`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [4294965247]->4294965329 vs [2048]->2140

## INJ-2IN-L2-d0-chain

```c
r0 = READ_ONCE(*x0);
  r1 = READ_ONCE(*x1);
  t1 = r0 ^ r1;
  u1 = t1 - 7;
  WRITE_ONCE(*y, u1);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 2 | `r0 ^ r1` | r0 | true | REAL |
| A | 2 | `r0 ^ r1` | r1 | true | REAL |
| A | 3 | `t1 - 7` | t1 | true | REAL |
| A | 4 | `u1` | u1 | true | REAL |
| B | 2 | `r0 ^ r1` | r0 | true | QFBV_VARIES |
| B | 2 | `r0 ^ r1` | r1 | true | QFBV_VARIES |
| B | 3 | `t1 - 7` | t1 | true | QFBV_VARIES |
| B | 4 | `u1` | u1 | true | QFBV_VARIES |

- L0: composed `(L0 ^ L1) - 7` (shipped `(((R0) ^ (R2)) - 7)`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [4294705151, 4294705151]->4294967289 vs [262144, 4294705151]->4294967288
- L1: composed `(L0 ^ L1) - 7` (shipped `(((R0) ^ (R2)) - 7)`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [4294705151, 4294705151]->4294967289 vs [4294705151, 262144]->4294967288

## CTRL-CONSTREG-ZERO

```c
r0 = READ_ONCE(*x0);
  k = 0;
  s = r0 * k;
  WRITE_ONCE(*y, s);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 2 | `r0 * k` | r0 | true | REAL |
| A | 2 | `r0 * k` | k | true | REAL |
| A | 3 | `s` | s | true | REAL |
| B | 2 | `r0 * k` | r0 | true | QFBV_VARIES |
| B | 2 | `r0 * k` | k | true | QFBV_VARIES |
| B | 3 | `s` | s | true | QFBV_VARIES |

- L0: composed `L0 * 0` (shipped `((R0) * (0))`); A=REAL B=REAL C=FAKE z3=FAKE expected=FAKE -> A closureREAL/composedFAKE, B closureREAL/composedFAKE

## CTRL-RELOAD

```c
r0 = READ_ONCE(*x0);
  r0 = READ_ONCE(*x0);
  WRITE_ONCE(*y, r0);
```

| cfg | instr | expr | reg | real | pattern |
|---|---|---|---|---|---|
| A | 2 | `r0` | r0 | true | REAL |
| B | 2 | `r0` | r0 | true | QFBV_VARIES |

- L0: composed `L1` (shipped `(R2)`); A=ABSENT B=ABSENT C=FAKE z3=FAKE expected=FAKE -> A agree-FAKE, B agree-FAKE
- L1: composed `L1` (shipped `(R2)`); A=REAL B=REAL C=REAL z3=REAL expected=REAL -> A agree-REAL, B agree-REAL
  - witness: exec [0, 4294967295]->4294967295 vs [0, 0]->0
