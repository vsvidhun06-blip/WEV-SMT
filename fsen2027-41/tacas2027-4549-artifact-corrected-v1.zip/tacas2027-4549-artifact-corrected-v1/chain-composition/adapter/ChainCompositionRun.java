import com.weakest.model.Event;
import com.weakest.model.ReadEvent;
import com.weakest.model.WriteEvent;

import wev.smt.DependencyInfo;
import wev.smt.DependencyInfo.DepKind;
import wev.smt.DependencyInfo.KindedEdge;
import wev.smt.QfbvConstancyOracle;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;

import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;

/**
 * Chain-composition measurement adapter (eval/chain-composition). Uses the shipped parser,
 * classifier, closure and QF_BV oracle unmodified, through public API only.
 *
 * For every generated thread and every load k in it, against the thread's single store:
 *   A = shipped closure, CONSTANCY_ORACLE = null (idiom folding + linear cancellation)
 *   B = shipped closure, CONSTANCY_ORACLE = QF_BV oracle (exact per instruction, other
 *       registers free)
 *   C = QF_BV oracle on the generator's independently composed store expression, target L<k>
 *   Cship = QF_BV oracle on the shipped writeValueExprs string, target R<readId> (cross-check)
 * A/B report the shipped DATA edge for (store, read): REAL, FAKE, BOTH or ABSENT.
 *
 * Args: <root containing queries.tsv and inputs/> <out dir> [timeout seconds, default 60]
 */
public final class ChainCompositionRun {

    record Query(String id, String file, int k, String composed) { }
    record Parsed(LitmusCase lc, String status, List<LitmusParser.DepDecision> trace) { }

    static ExecutorService exec = Executors.newSingleThreadExecutor();
    static int timeoutSec = 60;

    public static void main(String[] a) throws Exception {
        Path root = Path.of(a[0]);
        Path out = Path.of(a[1]);
        if (a.length > 2) timeoutSec = Integer.parseInt(a[2]);
        Files.createDirectories(out);
        Map<String, List<Query>> byId = new LinkedHashMap<>();
        for (String line : Files.readAllLines(root.resolve("queries.tsv"))) {
            if (line.isBlank()) continue;
            String[] f = line.split("\t", -1);
            byId.computeIfAbsent(f[0], x -> new ArrayList<>())
                .add(new Query(f[0], f[1], Integer.parseInt(f[2]), f[3]));
        }
        QfbvConstancyOracle installed = new QfbvConstancyOracle();
        QfbvConstancyOracle composedOracle = new QfbvConstancyOracle();
        try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(out.resolve("pairs-raw.csv")));
             PrintWriter tw = new PrintWriter(Files.newBufferedWriter(out.resolve("trace.csv")));
             PrintWriter ew = new PrintWriter(Files.newBufferedWriter(out.resolve("events.csv")))) {
            pw.println("id,k,read_id,read_loc,read_reg,n_reads,n_writes,store_loc,raw_store,shipped_composed,"
                    + "A,B,C,C_reason,C_ms,Cship,Cship_reason,status");
            tw.println("id,config,instr,expr,reg,real,pattern,producers");
            ew.println("id,config,event_id,thread,kind,loc,detail");
            for (var en : byId.entrySet()) {
                String id = en.getKey();
                String src = Files.readString(root.resolve(en.getValue().get(0).file()));
                Parsed pA = parse(src, id, null);
                Parsed pB = parse(src, id, installed);
                if (pB.status().equals("TIMEOUT")) installed = new QfbvConstancyOracle();
                for (var p : List.of(Map.entry("A", pA), Map.entry("B", pB))) {
                    for (var d : p.getValue().trace())
                        tw.println(String.join(",", q(id), p.getKey(), String.valueOf(d.instrIndex()),
                                q(d.expr()), q(d.reg()), String.valueOf(d.real()), q(d.pattern()),
                                q(d.producerReadIds().toString())));
                    if (p.getValue().lc() != null)
                        for (Event e : p.getValue().lc().es().getEvents())
                            ew.println(String.join(",", q(id), p.getKey(), String.valueOf(e.getId()),
                                    String.valueOf(e.getThreadId()), e.getClass().getSimpleName(),
                                    q(e.getVariable()),
                                    q(e instanceof ReadEvent r ? r.getLocalVar()
                                      : e instanceof WriteEvent w ? w.getValueExpression() : "")));
                }
                String status = pA.status().equals("ok") && pB.status().equals("ok")
                        ? "ok" : "A:" + pA.status() + ";B:" + pB.status();
                List<ReadEvent> reads = new ArrayList<>();
                List<WriteEvent> writes = new ArrayList<>();
                if (pA.lc() != null) {
                    for (Event e : pA.lc().es().getEvents()) {
                        if (e.getThreadId() != 1) continue;
                        if (e instanceof ReadEvent r) reads.add(r);
                        else if (e instanceof WriteEvent w) writes.add(w);
                    }
                    reads.sort(Comparator.comparingInt(Event::getId));
                    if (pB.lc() != null && !pA.lc().es().getEvents().toString()
                            .equals(pB.lc().es().getEvents().toString())) status = "EVENT-MISMATCH";
                }
                WriteEvent store = writes.size() == 1 ? writes.get(0) : null;
                if (pA.lc() != null && store == null) status = "STORE-COUNT-" + writes.size();
                String shipped = store == null ? "" : pA.lc().writeValueExprs().get(store.getId());
                for (Query qy : en.getValue()) {
                    ReadEvent r = qy.k() < reads.size() ? reads.get(qy.k()) : null;
                    String st = status;
                    if (pA.lc() != null && reads.size() != en.getValue().size()) st = "READ-COUNT-" + reads.size();
                    String fa = flag(pA, store, r), fb = flag(pB, store, r);
                    long t0 = System.nanoTime();
                    String[] c = constancy(composedOracle, qy.composed(), "L" + qy.k());
                    long ms = (System.nanoTime() - t0) / 1_000_000;
                    if (c[0].equals("TIMEOUT")) composedOracle = new QfbvConstancyOracle();
                    String[] cs = (r == null || shipped == null || shipped.isEmpty())
                            ? new String[]{"N/A", ""} : constancy(composedOracle, shipped, "R" + r.getId());
                    if (cs[0].equals("TIMEOUT")) composedOracle = new QfbvConstancyOracle();
                    pw.println(String.join(",", q(id), String.valueOf(qy.k()),
                            r == null ? "" : String.valueOf(r.getId()), r == null ? "" : q(r.getVariable()),
                            r == null ? "" : q(r.getLocalVar()), String.valueOf(reads.size()),
                            String.valueOf(writes.size()), store == null ? "" : q(store.getVariable()),
                            store == null ? "" : q(store.getValueExpression()), q(shipped),
                            fa, fb, c[0], q(c[1]), String.valueOf(ms), cs[0], q(cs[1]), q(st)));
                }
                pw.flush();
            }
        } finally {
            exec.shutdownNow();
        }
        System.err.println("done: " + byId.size() + " threads");
        System.exit(0);
    }

    static Parsed parse(String src, String id, LitmusParser.ConstancyOracle oracle) {
        List<LitmusParser.DepDecision> trace = Collections.synchronizedList(new ArrayList<>());
        Future<LitmusCase> f = exec.submit(() -> {
            try {
                LitmusParser.CONSTANCY_ORACLE = oracle;
                LitmusParser.DEP_TRACE = trace::add;
                Event.resetCounter();
                return LitmusParser.parse(src, id);
            } finally {
                LitmusParser.CONSTANCY_ORACLE = null;
                LitmusParser.DEP_TRACE = null;
            }
        });
        try {
            return new Parsed(f.get(timeoutSec, TimeUnit.SECONDS), "ok", trace);
        } catch (TimeoutException te) {
            f.cancel(true);
            exec.shutdownNow();
            exec = Executors.newSingleThreadExecutor();
            return new Parsed(null, "TIMEOUT", trace);
        } catch (ExecutionException ee) {
            Throwable c = ee.getCause();
            return new Parsed(null, "PARSE-FAIL:" + c.getClass().getSimpleName() + ":"
                    + String.valueOf(c.getMessage()).replace('\n', ' '), trace);
        } catch (InterruptedException ie) {
            throw new RuntimeException(ie);
        }
    }

    /** {CONST|VARIES|UNSUPPORTED|ERROR|TIMEOUT, reason}. */
    static String[] constancy(QfbvConstancyOracle o, String expr, String target) {
        Future<Boolean> f = exec.submit(() -> o.isConstant(expr, target));
        try {
            Boolean k = f.get(timeoutSec, TimeUnit.SECONDS);
            if (k == null) {
                String why = o.undecidedReasons().get(expr.replaceAll("\\s+", ""));
                return new String[]{why != null && why.startsWith("solver") ? "ERROR" : "UNSUPPORTED",
                        why == null ? "" : why};
            }
            if (!k && !expr.matches(".*(?<![A-Za-z0-9_])" + target + "(?![A-Za-z0-9_]).*"))
                return new String[]{"ERROR", "target absent but oracle says varies"};
            return new String[]{k ? "CONST" : "VARIES", ""};
        } catch (TimeoutException te) {
            f.cancel(true);
            exec.shutdownNow();
            exec = Executors.newSingleThreadExecutor();
            return new String[]{"TIMEOUT", timeoutSec + "s"};
        } catch (ExecutionException ee) {
            return new String[]{"ERROR", "exception " + ee.getCause()};
        } catch (InterruptedException ie) {
            throw new RuntimeException(ie);
        }
    }

    /** Shipped DATA-edge flag for (store, read) in one parse. */
    static String flag(Parsed p, WriteEvent store, ReadEvent read) {
        if (p.lc() == null || store == null || read == null) return "N/A";
        String f = "ABSENT";
        DependencyInfo d = p.lc().deps();
        for (KindedEdge k : d.allEdges()) {
            if (k.kind() != DepKind.DATA) continue;
            // event ids are reset per parse, so match on id (A and B event lists are compared)
            if (k.edge().consumer().getId() != store.getId() || k.edge().producer().getId() != read.getId()) continue;
            String g = k.edge().isSemantic() ? "REAL" : "FAKE";
            f = f.equals("ABSENT") || f.equals(g) ? g : "BOTH";
        }
        return f;
    }

    static String q(String s) { return '"' + (s == null ? "" : s.replace("\"", "\"\"")) + '"'; }
}
