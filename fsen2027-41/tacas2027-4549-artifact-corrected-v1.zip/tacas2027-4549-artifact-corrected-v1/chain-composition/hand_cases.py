"""Hand-derived validation cases (not part of the measured population).

Each case gives a thread as a typed AST and, written out by hand, the composed store
expression over load symbols L<k>, one concrete valuation with its hand-computed store
value, and the expected per-load dependence. validate.py checks the generator's composer,
concrete execution, the shipped writeValueExprs string and the oracle against these.

Usage: python hand_cases.py <out-dir>   (writes inputs/, queries.tsv, hand.json)
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen import B, C, U, V, litmus  # noqa: E402  (AST constructors and printer only)

L = lambda r, x: ('load', r, x)
A = lambda r, e: ('assign', r, e)
S = lambda r: ('store', 'y', r)

CASES = [
    # family, id, instrs, hand composed, valuation, hand value, expectation
    ('cancellation', 'H-CAN-ADD',
     [L('r0', 'x0'), A('t1', B('+', V('r0'), C(5))), A('u2', B('-', V('t1'), C(3))),
      A('s', B('-', V('u2'), V('r0'))), S('s')],
     'L0 + 5 - 3 - L0', {'L0': 10}, 2, {'L0': 'FAKE'}),
    ('cancellation', 'H-CAN-XOR-COPY',
     [L('r0', 'x0'), A('t1', V('r0')), A('t2', B('^', V('t1'), C(12))),
      A('s', B('^', V('t2'), V('r0'))), S('s')],
     'L0 ^ 12 ^ L0', {'L0': 7}, 12, {'L0': 'FAKE'}),
    ('cancellation', 'H-CAN-RELOAD',
     [L('r0', 'x0'), A('t1', B('+', V('r0'), C(1))), L('r0', 'x0'),
      A('s', B('-', V('t1'), V('r0'))), S('s')],
     'L0 + 1 - L1', {'L0': 10, 'L1': 4}, 7, {'L0': 'REAL', 'L1': 'REAL'}),
    ('cancellation', 'H-CAN-2IN',
     [L('r0', 'x0'), L('r1', 'x1'), A('t1', B('+', V('r0'), V('r1'))),
      A('s', B('-', V('t1'), V('r0'))), S('s')],
     'L0 + L1 - L0', {'L0': 9, 'L1': 4}, 4, {'L0': 'FAKE', 'L1': 'REAL'}),
    ('masking', 'H-MSK-DISJ',
     [L('r0', 'x0'), A('t1', B('&', V('r0'), C(12))), A('t2', B('&', V('t1'), C(3))), S('t2')],
     'L0 & 12 & 3', {'L0': 15}, 0, {'L0': 'FAKE'}),
    ('masking', 'H-MSK-RETAIN',
     [L('r0', 'x0'), A('t1', B('&', V('r0'), C(12))), A('t2', B('&', V('t1'), C(6))), S('t2')],
     'L0 & 12 & 6', {'L0': 15}, 4, {'L0': 'REAL'}),
    ('masking', 'H-MSK-MUL',
     [L('r0', 'x0'), A('t1', B('*', V('r0'), C(8))), A('s', B('&', V('t1'), C(7))), S('s')],
     'L0 * 8 & 7', {'L0': 13}, 0, {'L0': 'FAKE'}),
    ('masking', 'H-MSK-INREG',
     [L('r0', 'x0'), A('k', C(12)), A('t1', B('&', V('r0'), C(3))),
      A('s', B('&', V('t1'), V('k'))), S('s')],
     'L0 & 3 & 12', {'L0': 255}, 0, {'L0': 'FAKE'}),
    ('injective', 'H-INJ-PIPE',
     [L('r0', 'x0'), A('t1', B('*', V('r0'), C(3))), A('t2', B('^', V('t1'), C(255))),
      A('t3', U('-', V('t2'))), A('t4', U('~', V('t3'))), S('t4')],
     '~(-(L0 * 3 ^ 255))', {'L0': 2}, 248, {'L0': 'REAL'}),
    ('control', 'H-CTRL-OVERWRITE',
     [L('r0', 'x0'), A('t', B('+', V('r0'), C(5))), A('t', C(7)), S('t')],
     '7', {'L0': 123}, 7, {'L0': 'FAKE'}),
]
# Hand arithmetic for the non-obvious values:
#   H-CAN-RELOAD 10+1-4 = 7;  H-MSK-RETAIN 15&12 = 12, 12&6 = 4;
#   H-INJ-PIPE 2*3 = 6, 6^255 = 249, -249, ~(-249) = 249-1 = 248.


def main():
    out = Path(sys.argv[1])
    (out / 'inputs').mkdir(parents=True, exist_ok=True)
    rows = []
    with open(out / 'queries.tsv', 'w', newline='\n') as q:
        for fam, cid, instrs, comp, val, value, exp in CASES:
            (out / 'inputs' / f"{cid}.litmus").write_text(litmus(f"CC-{cid}", instrs), newline='\n')
            for k in range(len(exp)):
                q.write(f"{cid}\tinputs/{cid}.litmus\t{k}\t{comp}\n")
            rows.append({'family': fam, 'id': cid, 'instrs': instrs, 'hand_composed': comp,
                         'valuation': val, 'hand_value': value, 'expect': exp})
    (out / 'hand.json').write_text(json.dumps(rows, indent=1), newline='\n')
    print(f"{len(rows)} hand cases")


if __name__ == '__main__':
    main()
