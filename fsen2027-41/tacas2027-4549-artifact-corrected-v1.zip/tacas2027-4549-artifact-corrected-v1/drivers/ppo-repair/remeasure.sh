#!/usr/bin/env bash
# Targeted remeasurement after the ppo repair. Writes only under the session directory.
# Usage: remeasure.sh <session_dir_win> <final_rerun_dir_win> <repo_win>
set -u
D="$1"; FR="$2"; R="$3"
CORPUS="<AUDIT_ROOT>/2026-10-09-imm-repair/corpus-copy"
HASHES="<AUDIT_ROOT>/2026-10-09-provenance/frozen-eligible-hashes.csv"
CPX="$(cat "$R/target/cp.txt")"
NAT="$R/target/native"
mkdir -p "$D/out" "$D/logs"
stamp() { date '+%Y-%m-%dT%H:%M:%S'; }
step() { local name="$1"; shift; ( echo "start $(stamp)"; "$@"; echo "exit $? $(stamp)" ) > "$D/logs/$name.log" 2>&1; }
JO=(java "-Djava.library.path=$NAT" -cp "$D/tools/rel-old;$FR/classes;$CPX")
JN=(java "-Djava.library.path=$NAT" -cp "$D/tools/rel-new;$D/classes;$CPX")
JR=(java "-Djava.library.path=$NAT" -cp "$D/classes;$CPX")

step rel-bounded-old "${JO[@]}" wev.smt.cli.RelCheck bounded "$D/out/rel-bounded-old.csv" 4 20261009 &
step rel-bounded-new "${JN[@]}" wev.smt.cli.RelCheck bounded "$D/out/rel-bounded-new.csv" 4 20261009 &
( step rel-corpus-old "${JO[@]}" wev.smt.cli.RelCheck corpus "$CORPUS" "$HASHES" "$D/out/rel-corpus-old.csv"
  step fhash-old "${JO[@]}" wev.smt.cli.FormulaHash "$CORPUS" "$HASHES" "$D/out/formula-hash-old.csv" ) &
( step rel-corpus-new "${JN[@]}" wev.smt.cli.RelCheck corpus "$CORPUS" "$HASHES" "$D/out/rel-corpus-new.csv"
  step fhash-new "${JN[@]}" wev.smt.cli.FormulaHash "$CORPUS" "$HASHES" "$D/out/formula-hash-new.csv" ) &
# frozen rerun with the repaired classes (the driver evaluates all six models per file)
step six-symbolic "${JR[@]}" wev.smt.cli.CorpusValidation "$CORPUS" "$D/out/six-model" \
     manifest="$HASHES" mode=symbolic csv=repaired-symbolic.csv perFileSec=30 budgetMin=600 maxEvents=64 &
step six-wired-847 "${JR[@]}" wev.smt.cli.CorpusValidation "$CORPUS" "$D/out/six-model" \
     manifest="$D/wired-847-hashes.csv" mode=wired csv=repaired-wired-847.csv perFileSec=30 budgetMin=600 maxEvents=64 &
wait
echo "ALL DONE $(stamp)" > "$D/logs/DONE"
