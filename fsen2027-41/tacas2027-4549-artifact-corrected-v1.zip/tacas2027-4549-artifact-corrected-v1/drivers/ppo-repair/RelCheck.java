package wev.smt.cli;

import com.weakest.model.Event;
import com.weakest.model.EventStructure;
import com.weakest.model.FenceEvent;
import com.weakest.model.FenceEvent.FenceKind;
import com.weakest.model.MemoryOrder;
import com.weakest.model.RMWEvent;
import com.weakest.model.ReadEvent;
import com.weakest.model.WriteEvent;
import org.sosy_lab.common.ShutdownNotifier;
import org.sosy_lab.common.configuration.Configuration;
import org.sosy_lab.common.log.BasicLogManager;
import org.sosy_lab.java_smt.SolverContextFactory;
import org.sosy_lab.java_smt.api.BooleanFormula;
import org.sosy_lab.java_smt.api.BooleanFormulaManager;
import org.sosy_lab.java_smt.api.IntegerFormulaManager;
import org.sosy_lab.java_smt.api.NumeralFormula.IntegerFormula;
import org.sosy_lab.java_smt.api.ProverEnvironment;
import org.sosy_lab.java_smt.api.SolverContext;
import wev.smt.AxiomaticConsistency;
import wev.smt.EventStructureEncoder;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;

import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

/**
 * Relation-level check of the per-model program-order layer (external audit tool).
 *
 * EXPECTED: an independent constructor over each thread's linearised program order. It
 * filters every ordered access pair (i < j) by the repository's stated per-model rule,
 * then takes the transitive closure:
 *   SC, RC11      all pairs
 *   TSO           drop W→R (W = store or RMW, R = plain load), unless restored
 *   PSO, PSOCANON drop W→R and W→W, unless restored
 *   restored      either endpoint is a full-fence RMW, or a fence strictly between them
 *                 orders the direction: FULL always, ACQ if a reads (load/RMW),
 *                 REL if b writes (store/RMW), ACQ_REL either way.
 * ENCODED: the closure the solver actually enforces. The model formula is asserted with
 * every rf and co variable false, so only unconditional program-order edges remain, and
 * a pair (a, b) is encoded iff layer(a) < layer(b) is entailed.
 *
 * Usage:
 *   corpus  <root> <manifest.csv> <out.csv>     hash-verified frozen inputs
 *   bounded <out.csv> <maxLen> <seed>           exhaustive and sampled sequences
 */
public final class RelCheck {

    static final String[] MODELS = {"SC", "TSO", "PSO", "PSOCANON", "RC11"};
    static final String[] TAGS = {"sc", "tso", "pso", "psocanon", "rc11"};

    public static void main(String[] a) throws Exception {
        Configuration cfg = Configuration.defaultConfiguration();
        try (PrintWriter w = new PrintWriter(Files.newBufferedWriter(Path.of(a[0].equals("corpus") ? a[3] : a[1])))) {
            w.println("case,model,status,access_pairs,expected,encoded,match,missing,extra,encoded_closure");
            if (a[0].equals("corpus")) {
                List<CorpusValidation.ManifestEntry> entries = CorpusValidation.loadManifest(Path.of(a[1]), Path.of(a[2]));
                for (CorpusValidation.ManifestEntry e : entries) {
                    Event.resetCounter();
                    LitmusCase lc;
                    try {
                        lc = LitmusParser.parse(e.content(), e.path());
                    } catch (Exception ex) {
                        w.println(e.path() + ",*,PARSE-FAIL,0,0,0,false,,,");
                        continue;
                    }
                    try (SolverContext ctx = newCtx(cfg)) {
                        check(ctx, e.path(), lc.es(), w, lc);
                    }
                }
            } else {
                int maxLen = Integer.parseInt(a[2]);
                Random rnd = new Random(Long.parseLong(a[3]));
                List<List<String>> seqs = new ArrayList<>();
                enumerate(new ArrayList<>(), maxLen, ALPHABET, seqs);
                List<List<List<String>>> cases = new ArrayList<>();
                for (List<String> s : seqs) cases.add(List.of(s));
                String[] longAlpha = {"Rx", "Ry", "Wx", "Wy", "F.FULL", "F.REL", "F.ACQ", "Uf"};
                for (int k = 0; k < 2000; k++) {                 // longer single threads
                    cases.add(List.of(randomSeq(rnd, 5 + rnd.nextInt(3), longAlpha)));
                }
                for (int k = 0; k < 2000; k++) {                 // multi-thread
                    int nt = 2 + rnd.nextInt(2);
                    List<List<String>> th = new ArrayList<>();
                    for (int t = 0; t < nt; t++) th.add(randomSeq(rnd, 1 + rnd.nextInt(5), ALPHABET));
                    cases.add(th);
                }
                try (SolverContext ctx = newCtx(cfg)) {
                    int n = 0;
                    for (List<List<String>> c : cases) {
                        Event.resetCounter();
                        check(ctx, String.join("|", c.stream().map(s -> String.join(";", s)).toList()), build(c), w, null);
                        if (++n % 2000 == 0) System.out.println("..." + n + "/" + cases.size());
                    }
                }
            }
        }
        System.out.println("done");
    }

    static SolverContext newCtx(Configuration cfg) throws Exception {
        return SolverContextFactory.createSolverContext(cfg, BasicLogManager.create(cfg),
                ShutdownNotifier.createDummy(), SolverContextFactory.Solvers.Z3);
    }

    // ── independent expected relation ──────────────────────────────────────

    /** Per thread, the events in program order; null if po is not a per-thread chain. */
    static Map<Integer, List<Event>> chains(EventStructure es) {
        Map<Integer, List<Integer>> po = es.getProgramOrder();
        Map<Integer, Integer> pred = new HashMap<>();
        for (Map.Entry<Integer, List<Integer>> en : po.entrySet()) {
            if (en.getValue().size() > 1) return null;
            for (Integer s : en.getValue()) {
                if (pred.put(s, en.getKey()) != null) return null;
                if (es.getEventById(s).getThreadId() != es.getEventById(en.getKey()).getThreadId()) return null;
            }
        }
        Map<Integer, List<Event>> out = new LinkedHashMap<>();
        int covered = 0, threadEvents = 0;
        for (Event e : es.getEvents()) {
            if (e.getThreadId() == 0) continue;
            threadEvents++;
            if (pred.containsKey(e.getId())) continue;          // not a chain head
            List<Event> chain = new ArrayList<>();
            Integer cur = e.getId();
            while (cur != null) {
                chain.add(es.getEventById(cur));
                List<Integer> nx = po.getOrDefault(cur, List.of());
                cur = nx.isEmpty() ? null : nx.get(0);
            }
            covered += chain.size();
            out.computeIfAbsent(e.getThreadId(), k -> new ArrayList<>()).addAll(chain);
        }
        for (List<Event> c : out.values()) {                       // one chain per thread
            long heads = c.stream().filter(x -> !pred.containsKey(x.getId())).count();
            if (heads != 1) return null;
        }
        return covered == threadEvents ? out : null;
    }

    static boolean access(Event e) { return e instanceof ReadEvent || e instanceof WriteEvent; }
    static boolean writes(Event e) { return e instanceof WriteEvent; }            // store or RMW
    static boolean reads(Event e) { return e instanceof ReadEvent || e instanceof RMWEvent; }
    static boolean fullRmw(Event e) { return e instanceof RMWEvent u && u.isFullFence(); }

    static boolean relaxed(String m, Event a, Event b) {
        boolean wr = writes(a) && b instanceof ReadEvent;
        boolean ww = writes(a) && writes(b);
        return switch (m) {
            case "TSO" -> wr;
            case "PSO", "PSOCANON" -> wr || ww;
            default -> false;
        };
    }

    static boolean restored(Event a, Event b, List<Event> between) {
        if (fullRmw(a) || fullRmw(b)) return true;
        for (Event f : between) {
            if (!(f instanceof FenceEvent fe)) continue;
            FenceKind k = fe.getKind();
            if (k == FenceKind.FULL) return true;
            if ((k == FenceKind.ACQ || k == FenceKind.ACQ_REL) && reads(a)) return true;
            if ((k == FenceKind.REL || k == FenceKind.ACQ_REL) && writes(b)) return true;
        }
        return false;
    }

    /** Expected closure, as pairs of event ids. */
    static Set<String> expected(String m, Map<Integer, List<Event>> ch) {
        Set<String> out = new TreeSet<>();
        for (List<Event> c : ch.values()) {
            List<Integer> idx = new ArrayList<>();
            for (int i = 0; i < c.size(); i++) if (access(c.get(i))) idx.add(i);
            int n = idx.size();
            boolean[][] r = new boolean[n][n];
            for (int p = 0; p < n; p++) {
                for (int q = p + 1; q < n; q++) {
                    Event x = c.get(idx.get(p)), y = c.get(idx.get(q));
                    r[p][q] = !relaxed(m, x, y) || restored(x, y, c.subList(idx.get(p) + 1, idx.get(q)));
                }
            }
            for (int k = 0; k < n; k++)
                for (int p = 0; p < n; p++)
                    for (int q = 0; q < n; q++)
                        if (r[p][k] && r[k][q]) r[p][q] = true;
            for (int p = 0; p < n; p++)
                for (int q = p + 1; q < n; q++)
                    if (r[p][q]) out.add(c.get(idx.get(p)).getId() + ">" + c.get(idx.get(q)).getId());
        }
        return out;
    }

    // ── encoded relation (solver entailment) ───────────────────────────────

    static void check(SolverContext ctx, String name, EventStructure es, PrintWriter w, LitmusCase lc) throws Exception {
        Map<Integer, List<Event>> ch = chains(es);
        if (ch == null) {
            w.println(q(name) + ",*,NONLINEAR-PO,0,0,0,false,,,");
            return;
        }
        EventStructureEncoder enc = lc == null ? new EventStructureEncoder(ctx, es)
                : new EventStructureEncoder(ctx, es, lc.deps());
        BooleanFormulaManager bmgr = ctx.getFormulaManager().getBooleanFormulaManager();
        IntegerFormulaManager imgr = ctx.getFormulaManager().getIntegerFormulaManager();
        int accessPairs = 0;
        for (List<Event> c : ch.values()) {
            long n = c.stream().filter(RelCheck::access).count();
            accessPairs += (int) (n * (n - 1) / 2);
        }
        for (int mi = 0; mi < MODELS.length; mi++) {
            String m = MODELS[mi];
            AxiomaticConsistency ax = new AxiomaticConsistency(enc);
            BooleanFormula f = switch (m) {
                case "SC" -> ax.consistencySC();
                case "TSO" -> ax.consistencyTSO();
                case "PSO" -> ax.consistencyPSO();
                case "PSOCANON" -> ax.consistencyPSOCanonical();
                default -> ax.consistencyRC11();
            };
            Set<String> vars = ctx.getFormulaManager().extractVariables(f).keySet();
            String prefix = "layer_" + TAGS[mi] + "1_e";
            Set<String> enc_ = new TreeSet<>();
            String status = "OK";
            try (ProverEnvironment p = ctx.newProverEnvironment()) {
                p.addConstraint(f);
                for (BooleanFormula v : enc.getRfVars().values()) p.addConstraint(bmgr.not(v));
                for (BooleanFormula v : enc.getCoVars().values()) p.addConstraint(bmgr.not(v));
                if (p.isUnsat()) {
                    status = "BASE-UNSAT";
                } else {
                    for (List<Event> c : ch.values()) {
                        List<Event> acc = c.stream().filter(RelCheck::access).toList();
                        for (int i = 0; i < acc.size(); i++) {
                            for (int j = i + 1; j < acc.size(); j++) {
                                String na = prefix + acc.get(i).getId(), nb = prefix + acc.get(j).getId();
                                if (!vars.contains(na) || !vars.contains(nb)) { status = "LAYER-NAME-MISSING"; continue; }
                                IntegerFormula la = imgr.makeVariable(na), lb = imgr.makeVariable(nb);
                                p.push();
                                p.addConstraint(bmgr.not(imgr.lessThan(la, lb)));
                                if (p.isUnsat()) enc_.add(acc.get(i).getId() + ">" + acc.get(j).getId());
                                p.pop();
                            }
                        }
                    }
                }
            }
            Set<String> exp = expected(m, ch);
            Set<String> missing = new TreeSet<>(exp); missing.removeAll(enc_);
            Set<String> extra = new TreeSet<>(enc_); extra.removeAll(exp);
            w.println(String.join(",", q(name), m, status, Integer.toString(accessPairs),
                    Integer.toString(exp.size()), Integer.toString(enc_.size()),
                    Boolean.toString(status.equals("OK") && missing.isEmpty() && extra.isEmpty()),
                    String.join(" ", missing), String.join(" ", extra), String.join(" ", enc_)));
        }
    }

    static String q(String s) { return '"' + s.replace("\"", "'") + '"'; }

    // ── bounded structures ─────────────────────────────────────────────────

    static final String[] ALPHABET = {"Rx", "Ry", "Wx", "Wy", "Uf", "Un", "F.FULL", "F.ACQ", "F.REL", "F.ACQ_REL"};

    static void enumerate(List<String> pre, int max, String[] alpha, List<List<String>> out) {
        if (!pre.isEmpty()) out.add(new ArrayList<>(pre));
        if (pre.size() == max) return;
        for (String s : alpha) {
            pre.add(s);
            enumerate(pre, max, alpha, out);
            pre.remove(pre.size() - 1);
        }
    }

    static List<String> randomSeq(Random r, int len, String[] alpha) {
        List<String> s = new ArrayList<>();
        for (int i = 0; i < len; i++) s.add(alpha[r.nextInt(alpha.length)]);
        return s;
    }

    /** Threads 1..n from symbol sequences; Uf/Un are full-fence / non-fence RMWs on z. */
    static EventStructure build(List<List<String>> threads) {
        MemoryOrder rlx = MemoryOrder.RELAXED;
        EventStructure es = new EventStructure();
        Map<String, WriteEvent> init = new LinkedHashMap<>();
        for (String loc : List.of("x", "y", "z")) {
            WriteEvent iw = new WriteEvent(0, loc, rlx, 0, "0");
            init.put(loc, iw);
            es.addEvent(iw);
            es.addCoherenceOrder(loc, iw);
        }
        int t = 0;
        for (List<String> th : threads) {
            t++;
            Event prev = null;
            for (String s : th) {
                Event e;
                if (s.startsWith("F.")) {
                    e = new FenceEvent(t, FenceKind.valueOf(s.substring(2)));
                } else if (s.startsWith("U")) {
                    e = new RMWEvent(t, "z", rlx, 0, 1, s.equals("Uf"));
                } else if (s.startsWith("R")) {
                    e = new ReadEvent(t, s.substring(1), rlx, "r" + t);
                } else {
                    e = new WriteEvent(t, s.substring(1), rlx, 1, "1");
                }
                es.addEvent(e);
                if (e instanceof WriteEvent we) es.addCoherenceOrder(we.getVariable(), we);
                if (e instanceof ReadEvent re) es.addReadsFrom(re, init.get(re.getVariable()));
                if (prev != null) es.addProgramOrder(prev, e);
                prev = e;
            }
        }
        return es;
    }
}
