package wev.smt.cli;

import com.weakest.model.Event;
import org.sosy_lab.common.ShutdownNotifier;
import org.sosy_lab.common.configuration.Configuration;
import org.sosy_lab.common.log.BasicLogManager;
import org.sosy_lab.java_smt.SolverContextFactory;
import org.sosy_lab.java_smt.api.BooleanFormula;
import org.sosy_lab.java_smt.api.SolverContext;
import wev.smt.AxiomaticConsistency;
import wev.smt.EventStructureEncoder;
import wev.smt.MemoryModel;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;

import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * SHA-256 of the SMT-LIB dump of each model's consistency formula (symbolic mode, as in
 * the frozen run) and of the shared well-formedness formula, per hash-verified input.
 * Comparing two builds shows which models' generated formulas changed.
 * Args: root manifest.csv out.csv
 */
public final class FormulaHash {
    public static void main(String[] a) throws Exception {
        List<CorpusValidation.ManifestEntry> entries = CorpusValidation.loadManifest(Path.of(a[0]), Path.of(a[1]));
        Configuration cfg = Configuration.defaultConfiguration();
        try (PrintWriter w = new PrintWriter(Files.newBufferedWriter(Path.of(a[2])))) {
            w.println("file,part,sha256");
            for (CorpusValidation.ManifestEntry e : entries) {
                Event.resetCounter();
                LitmusCase lc = LitmusParser.parse(e.content(), e.path());
                try (SolverContext ctx = SolverContextFactory.createSolverContext(cfg, BasicLogManager.create(cfg),
                        ShutdownNotifier.createDummy(), SolverContextFactory.Solvers.Z3)) {
                    EventStructureEncoder enc = new EventStructureEncoder(ctx, lc.es(), lc.deps());
                    enc.enableSymbolic(lc.writeValueExprs(), lc.existsReadValues(), lc.existsMemFinal());
                    AxiomaticConsistency ax = new AxiomaticConsistency(enc);
                    w.println(e.path() + ",WF," + hash(ctx, enc.encodeWellFormedness()));
                    for (MemoryModel m : MemoryModel.values()) {
                        w.println(e.path() + "," + m.name() + "," + hash(ctx, switch (m) {
                            case SC -> ax.consistencySC();
                            case TSO -> ax.consistencyTSO();
                            case PSO -> ax.consistencyPSO();
                            case RA -> ax.consistencyRA();
                            case WEAKEST -> ax.consistencyWEAKEST();
                            case RC11 -> ax.consistencyRC11();
                        }));
                    }
                }
            }
        }
        System.out.println("done " + entries.size());
    }

    static String hash(SolverContext ctx, BooleanFormula f) {
        String dump = ctx.getFormulaManager().dumpFormula(f).toString();
        return CorpusValidation.sha256(dump.getBytes(StandardCharsets.UTF_8));
    }
}
