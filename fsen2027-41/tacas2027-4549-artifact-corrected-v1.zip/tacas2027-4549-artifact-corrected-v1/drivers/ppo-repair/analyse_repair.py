"""Analysis of the ppo repair remeasurement (read-only over saved outputs).

Usage: python -I -X utf8 analyse_repair.py <session_dir> <final_rerun_dir> <provenance_dir>
"""
import collections
import csv
import os
import sys

D, FR, P = sys.argv[1:4]
O = os.path.join(D, 'out')
MODELS = ['SC', 'TSO', 'PSO', 'RA', 'WEAKEST', 'RC11']
RESULTS = ['SAT', 'UNSAT', 'UNKNOWN', 'TIMEOUT', 'ERROR', 'UNSUPPORTED']
IMPL = [('SC', 'TSO'), ('SC', 'PSO'), ('SC', 'RA'), ('SC', 'WEAKEST'), ('SC', 'RC11'),
        ('RC11', 'WEAKEST'), ('PSO', 'RA')]


def rd(p):
    with open(p, encoding='utf-8') as f:
        return list(csv.DictReader(f))


def wr(name, header, rows):
    with open(os.path.join(D, name), 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


frozen = {r['path']: r for r in rd(os.path.join(P, 'frozen-eligible-hashes.csv'))}
files = list(frozen)
w847 = [f for f, r in frozen.items() if r['mem_atoms'] != 'True' and r['wired_fallback'] != 'True']

print('== A. bounded relation check (expected = independent constructor; encoded = solver closure)')
for v in ('old', 'new'):
    rows = rd(os.path.join(O, 'rel-bounded-%s.csv' % v))
    cases = len({r['case'] for r in rows})
    print('  %s: %d cases, %d rows' % (v, cases, len(rows)))
    for m in ('SC', 'TSO', 'PSO', 'PSOCANON', 'RC11'):
        mr = [r for r in rows if r['model'] == m]
        st = collections.Counter(r['status'] for r in mr)
        bad = [r for r in mr if r['match'] != 'true']
        print('     %-8s match %d/%d  status %s  with-missing %d  with-extra %d' % (
            m, len(mr) - len(bad), len(mr), dict(st), sum(1 for r in bad if r['missing']), sum(1 for r in bad if r['extra'])))

print('\n== B. frozen-population relation check')
rel = {}
for v in ('old', 'new'):
    rows = rd(os.path.join(O, 'rel-corpus-%s.csv' % v))
    rel[v] = {(r['case'], r['model']): r for r in rows}
    st = collections.Counter((r['model'], r['status']) for r in rows)
    print('  %s rows %d; statuses %s' % (v, len(rows), dict(st)))
    for m in ('SC', 'TSO', 'PSO', 'PSOCANON', 'RC11'):
        mr = [r for r in rows if r['model'] == m]
        print('     %-8s matches expected %d/%d' % (m, sum(1 for r in mr if r['match'] == 'true'), len(mr)))
rel_changed = {}
for m in ('SC', 'TSO', 'PSO', 'PSOCANON', 'RC11'):
    ch = [f for f in files if rel['old'][(f, m)]['encoded_closure'] != rel['new'][(f, m)]['encoded_closure']]
    grow = all(set(rel['old'][(f, m)]['encoded_closure'].split()) <= set(rel['new'][(f, m)]['encoded_closure'].split()) for f in ch)
    added = sum(len(set(rel['new'][(f, m)]['encoded_closure'].split()) - set(rel['old'][(f, m)]['encoded_closure'].split())) for f in ch)
    rel_changed[m] = set(ch)
    print('  relation changed %-8s %4d tests (old ⊆ new in all: %s; pairs added %d)' % (m, len(ch), grow, added))
exp = {r['path']: r for r in rd(os.path.join(FR, 'ppo-chain-exposed.csv'))}
for m, col in (('TSO', 'tso_exposed'), ('PSO', 'pso_exposed')):
    s = {f for f in files if exp[f][col] == 'True'}
    print('  %s: static exposed set %d vs relation-changed %d; static-only %d, relation-only %d' % (
        m, len(s), len(rel_changed[m]), len(s - rel_changed[m]), len(rel_changed[m] - s)))
wr('relation-changed-tests.csv', ['file', 'arch', 'tso_relation_changed', 'pso_relation_changed', 'psocanon_relation_changed'],
   [(f, frozen[f]['arch'], f in rel_changed['TSO'], f in rel_changed['PSO'], f in rel_changed['PSOCANON'])
    for f in files if f in rel_changed['TSO'] | rel_changed['PSO'] | rel_changed['PSOCANON']])

print('\n== C. generated-formula identity (SMT-LIB dump hashes, symbolic mode)')
fh = {v: {(r['file'], r['part']): r['sha256'] for r in rd(os.path.join(O, 'formula-hash-%s.csv' % v))} for v in ('old', 'new')}
for part in ['WF'] + MODELS:
    n = sum(1 for f in files if (f, part) in fh['old'])
    d = sum(1 for f in files if fh['old'].get((f, part)) != fh['new'].get((f, part)))
    print('  %-8s formulas differing %4d / %d' % (part, d, n))

print('\n== D. six-model accounting, symbolic, all 2,396 (old = pinned frozen run, new = repaired)')
old = {(r['file'], r['model']): r for r in rd(os.path.join(FR, 'mirror', 'out', 'five-model', 'frozen-symbolic.csv'))}
new = {(r['file'], r['model']): r for r in rd(os.path.join(O, 'six-model', 'repaired-symbolic.csv'))}
assert len(new) == len(files) * 6 and all((f, m) in new for f in files for m in MODELS)
print('  repaired rows %d, sha256 mismatches %d' % (len(new), sum(1 for r in new.values() if r['sha256'] != frozen[r['file']]['sha256'])))
print('  %-8s %-34s %-34s %s' % ('model', 'old', 'new', 'changed verdicts'))
changes = []
for m in MODELS:
    co = collections.Counter(old[(f, m)]['result'] for f in files)
    cn = collections.Counter(new[(f, m)]['result'] for f in files)
    ch = [f for f in files if old[(f, m)]['result'] != new[(f, m)]['result']]
    dirs = collections.Counter(old[(f, m)]['result'] + '->' + new[(f, m)]['result'] for f in ch)
    fmt = lambda c: ' '.join('%s %d' % (r, c[r]) for r in RESULTS if c[r])
    print('  %-8s %-34s %-34s %d %s' % (m, fmt(co), fmt(cn), len(ch), dict(dirs)))
    for f in ch:
        changes.append((f, frozen[f]['arch'], m, old[(f, m)]['verdict'], new[(f, m)]['verdict'],
                        f in rel_changed.get(m, set())))
    if m in ('TSO', 'PSO'):
        print('     relation changed %d; of those verdict changed %d, unchanged %d; verdict changes without relation change %d' % (
            len(rel_changed[m]), sum(1 for f in ch if f in rel_changed[m]), len(rel_changed[m] - set(ch)),
            sum(1 for f in ch if f not in rel_changed[m])))
        print('     by arch:', dict(collections.Counter(frozen[f]['arch'] for f in ch)))
wr('changed-verdicts.csv', ['file', 'arch', 'model', 'old_verdict', 'new_verdict', 'relation_changed'], changes)

print('\n== E. justified implications on the repaired results (violation = A SAT & B UNSAT)')
wired = {(r['file'], r['model']): r for r in rd(os.path.join(O, 'six-model', 'repaired-wired-847.csv'))}
for lab, K, pop in (('symbolic 2,396', new, files), ('wired 847 (diagnostic)', wired, w847)):
    tot = 0
    for a, b in IMPL:
        v = [f for f in pop if K[(f, a)]['result'] == 'SAT' and K[(f, b)]['result'] == 'UNSAT']
        und = sum(1 for f in pop if K[(f, a)]['result'] not in ('SAT', 'UNSAT') or K[(f, b)]['result'] not in ('SAT', 'UNSAT'))
        tot += len(v)
        print('  %-24s %-14s violations %d undecided %d %s' % (lab, a + '=>' + b, len(v), und, v[:3]))
    print('  %-24s total violations %d' % (lab, tot))

print('\n== F. wired diagnostics on the 847 (old pinned wired run vs repaired wired run)')
oldw = {(r['file'], r['model']): r for r in rd(os.path.join(FR, 'mirror', 'out', 'five-model', 'frozen-wired.csv'))}
print('  repaired wired rows %d (expected %d)' % (len(wired), len(w847) * 6))
for m in MODELS:
    ch = [f for f in w847 if oldw[(f, m)]['result'] != wired[(f, m)]['result']]
    print('  %-8s results %s  changed vs pinned wired %d %s' % (
        m, dict(collections.Counter(wired[(f, m)]['result'] for f in w847)), len(ch),
        dict(collections.Counter(oldw[(f, m)]['result'] + '->' + wired[(f, m)]['result'] for f in ch))))

print('\n== G. wired-vs-symbolic accounting (reconciliation)')
srr = {r['test']: r for r in rd(os.path.join(FR, 'mirror', 'out', 'symbolic-rf-results.csv'))}
for lab, S, W, pop in (('pinned run, 847', old, oldw, w847), ('pinned run, 2,396', old, oldw, files),
                       ('repaired, 847', new, wired, w847)):
    row = {}
    for m in MODELS:
        ch = [f for f in pop if S[(f, m)]['verdict'] != W[(f, m)]['verdict']]
        d = collections.Counter(W[(f, m)]['verdict'][:1] + '>' + S[(f, m)]['verdict'][:1] for f in ch)
        row[m] = '%d (%s)' % (len(ch), ', '.join('%s %d' % kv for kv in sorted(d.items())))
    print('  %-18s %s' % (lab, row))
ch = [f for f in files if srr[f]['wired_verdict'] != srr[f]['symbolic_verdict']]
in847 = [f for f in ch if f in set(w847)]
print('  SymbolicRfRun WEAKEST (pinned), 2,396: %d changed; %d of them in the 847, %d with memory atoms or init fallback' % (
    len(ch), len(in847), len(ch) - len(in847)))

print('\n== H. herd7 x86 (pinned 7.58 + model closure) vs repaired symbolic')
herd = {r['relpath']: r for r in rd(os.path.join(D, 'herd7-x86-results.csv'))}
for m, col in (('SC', 'herd_sc'), ('TSO', 'herd_tso')):
    for lab, S in (('old', old), ('new', new)):
        comp = [f for f in herd if herd[f][col] in ('ALLOWED', 'FORBIDDEN') and S[(f, m)]['result'] in ('SAT', 'UNSAT')]
        dis = [(f, herd[f][col], S[(f, m)]['verdict']) for f in comp if herd[f][col] != S[(f, m)]['verdict']]
        excl = len(herd) - len(comp)
        print('  %-3s %s: agree %d / %d (excluded %d) disagreements %s' % (m, lab, len(comp) - len(dis), len(comp), excl, dis))
        if lab == 'new':
            wr('herd7-x86-%s-disagreements-repaired.csv' % m, ['file', 'herd7', 'wev_symbolic'], dis)
