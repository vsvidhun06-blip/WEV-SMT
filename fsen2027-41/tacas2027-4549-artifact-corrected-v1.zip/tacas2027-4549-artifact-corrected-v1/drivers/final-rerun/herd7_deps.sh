#!/bin/bash
# Recursive include closure of the herd7 cat models used, with hashes (read-only).
H=~/.opam/4.14.2/share/herdtools7/herd
declare -A seen
queue=(sc.cat x86tso.cat stdlib.cat)
while [ ${#queue[@]} -gt 0 ]; do
  f=${queue[0]}; queue=("${queue[@]:1}")
  [ -n "${seen[$f]:-}" ] && continue
  seen[$f]=1
  if [ ! -f "$H/$f" ]; then echo "MISSING $f"; continue; fi
  sha256sum "$H/$f"
  for inc in $(grep -o 'include "[^"]*"' "$H/$f" | sed 's/include "\(.*\)"/\1/'); do queue+=("$inc"); done
done
echo "herd7 binary: $(sha256sum ~/.opam/4.14.2/bin/herd7)"
echo "herd7 -version: $(~/.opam/4.14.2/bin/herd7 -version 2>&1 | head -1)"
