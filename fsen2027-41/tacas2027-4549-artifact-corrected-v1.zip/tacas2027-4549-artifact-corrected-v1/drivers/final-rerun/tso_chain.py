"""Tests exposed to the consecutive-hop ppo defect (TSO / PSO), from the extraction dump.

addPo emits a model's po edges only between consecutive accesses (fences crossed); a relaxed
hop (TSO: W→R; PSO: W→R or W→W) is dropped, so an ordered pair (TSO: any pair except W→R;
PSO: pairs starting with R) whose consecutive chain contains a dropped hop loses its po edge.
Same-location pairs stay ordered by per-location coherence and are ignored. A hop that
crosses any fence is treated as restored (so the count can under-report weak-fence cases).

Usage: python -I -X utf8 tso_chain.py <events.csv> <frozen-eligible-hashes.csv> <session_dir>
"""
import collections
import csv
import os
import sys

ev_path, frozen_path, D = sys.argv[1:4]
frozen = {r['path']: r for r in csv.DictReader(open(frozen_path, encoding='utf-8'))}
threads = collections.defaultdict(lambda: collections.defaultdict(list))
for r in csv.DictReader(open(ev_path, encoding='utf-8')):
    if r['test'] in frozen and r['status'] == 'ok':
        threads[r['test']][int(r['thread'])].append((int(r['ord']), r['kind'], r['loc']))


def affected(seq, relaxed, ordered):
    acc, fence_before = [], False
    for _, k, loc in sorted(seq):
        if k == 'F':
            fence_before = True
            continue
        acc.append((k, loc, fence_before))
        fence_before = False
    n = len(acc)
    for i in range(n):
        for j in range(i + 1, n):
            ki, li, _ = acc[i]
            kj, lj, _ = acc[j]
            if li == lj or not ordered(ki, kj):
                continue
            for h in range(i, j):
                a, b = acc[h], acc[h + 1]
                if relaxed(a[0], b[0]) and not b[2]:
                    return True
    return False


TSO = (lambda a, b: a == 'W' and b == 'R', lambda a, b: not (a == 'W' and b == 'R'))
PSO = (lambda a, b: a == 'W' and b in ('R', 'W'), lambda a, b: a == 'R')
res = {}
for t in frozen:
    th = threads.get(t, {})
    res[t] = (any(affected(s, *TSO) for s in th.values()), any(affected(s, *PSO) for s in th.values()))
tso = {t for t, v in res.items() if v[0]}
pso = {t for t, v in res.items() if v[1]}
print('frozen tests %d: TSO-exposed %d, PSO-exposed %d' % (len(frozen), len(tso), len(pso)))
print('  TSO-exposed by arch', dict(collections.Counter(frozen[t]['arch'] for t in tso)))
dis = [r['file'] for r in csv.DictReader(open(os.path.join(D, 'herd7-TSO-disagreements.csv'), encoding='utf-8'))]
print('  herd7 TSO disagreements covered by the TSO-exposed set: %d/%d' % (sum(t in tso for t in dis), len(dis)))
with open(os.path.join(D, 'ppo-chain-exposed.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['path', 'tso_exposed', 'pso_exposed'])
    for t in sorted(frozen):
        w.writerow([t, res[t][0], res[t][1]])
