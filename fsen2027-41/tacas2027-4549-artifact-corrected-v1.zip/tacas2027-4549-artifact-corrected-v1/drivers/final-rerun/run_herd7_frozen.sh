#!/bin/bash
# herd7 comparison run on the frozen eligible population. Same command, per-file timeout and
# Observation→verdict rule as ~/run_herd7.sh (which writes into the repository and is not
# used). Pinned binary and model directory; writes only to the given output file.
# Usage: run_herd7_frozen.sh <list rel,arch> <corpus-root> <out.csv>
LIST="$1"; CORPUS="$2"; OUT="$3"
# corrected-v1 (2026-10-19): the recorded local opam root is replaced by $OPAM_ROOT (see ANONYMIZATION.md).
OPAM_ROOT="${OPAM_ROOT:?set OPAM_ROOT to the opam root holding switch 4.14.2 with herdtools7 7.58}"
HERD=$OPAM_ROOT/4.14.2/bin/herd7
LIB=$OPAM_ROOT/4.14.2/share/herdtools7/herd
cd /tmp || exit 2                      # no stray .cat files in the working directory
echo "relpath,arch,herd_sc,herd_tso,sc_observation,tso_observation" > "$OUT"
run() {  # $1=model $2=file -> "VERDICT|observation-line"
  local out rc obs
  out=$(timeout 25 "$HERD" -I "$LIB" -model "$1" "$2" 2>/dev/null)
  rc=$?
  if [ $rc -eq 124 ]; then echo "TIMEOUT|"; return; fi
  obs=$(echo "$out" | grep -m1 '^Observation')
  case "$(echo "$obs" | awk '{print $3}')" in
    Never) echo "FORBIDDEN|$obs";;
    Sometimes|Always) echo "ALLOWED|$obs";;
    *) echo "ERROR|$(echo "$out" | head -1 | tr ',' ';')";;
  esac
}
n=0
while IFS=, read -r rel arch; do
  [ -z "$rel" ] && continue
  n=$((n+1))
  full="$CORPUS/$rel"
  if [ ! -f "$full" ]; then echo "$rel,$arch,MISSING,,," >> "$OUT"; continue; fi
  sc=$(run sc.cat "$full")
  if [ "$arch" = "X86" ]; then tso=$(run x86tso.cat "$full"); else tso="|"; fi
  echo "$rel,$arch,${sc%%|*},${tso%%|*},\"${sc#*|}\",\"${tso#*|}\"" >> "$OUT"
done < "$LIST"
echo "DONE $n"
