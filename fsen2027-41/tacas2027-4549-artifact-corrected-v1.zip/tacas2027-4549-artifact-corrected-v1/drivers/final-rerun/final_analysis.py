"""Final frozen-population analysis (read-only over the mirror outputs).

Usage: python -I -X utf8 final_analysis.py <session_dir> <prov_dir> <repo_eval_dir>
"""
import collections
import csv
import filecmp
import json
import os
import re
import sys

D, P, E = sys.argv[1:4]
M = os.path.join(D, 'mirror')
O = os.path.join(M, 'out')
MODELS = ['SC', 'TSO', 'PSO', 'RA', 'WEAKEST', 'RC11']
RESULTS = ['SAT', 'UNSAT', 'UNKNOWN', 'TIMEOUT', 'ERROR', 'UNSUPPORTED']
IMPL = [('SC', 'TSO'), ('SC', 'PSO'), ('SC', 'RA'), ('SC', 'WEAKEST'), ('SC', 'RC11'),
        ('RC11', 'WEAKEST'), ('PSO', 'RA')]


def rd(p):
    with open(p, encoding='utf-8') as f:
        return list(csv.DictReader(f))


frozen = {r['path']: r for r in rd(os.path.join(P, 'frozen-eligible-hashes.csv'))}
pop = {r['path']: r for r in rd(os.path.join(P, 'frozen-population-12324.csv'))}
files = list(frozen)
wired_ok = {f for f, r in frozen.items() if r['mem_atoms'] != 'True' and r['wired_fallback'] != 'True'}
out = {}

print('== 1. six-model accounting (rows must be %d x %d = %d)' % (len(files), len(MODELS), len(files) * len(MODELS)))
runs = {}
for mode in ('symbolic', 'wired'):
    rows = rd(os.path.join(O, 'five-model', 'frozen-%s.csv' % mode))
    key = {(r['file'], r['model']): r for r in rows}
    assert len(key) == len(rows), 'duplicate rows'
    missing = [(f, m) for f in files for m in MODELS if (f, m) not in key]
    extra = [k for k in key if k[0] not in frozen]
    runs[mode] = key
    print('  %-8s rows %d, missing %d, extra %d, sha256 mismatches %d' % (
        mode, len(rows), len(missing), len(extra), sum(1 for r in rows if r['sha256'] != frozen[r['file']]['sha256'])))
    for m in MODELS:
        c = collections.Counter(key[(f, m)]['result'] for f in files)
        print('     %-8s %s' % (m, '  '.join('%s %d' % (r, c[r]) for r in RESULTS)))
    gaps = rd(os.path.join(O, 'five-model', 'frozen-%s.csv.encoding-gaps.csv' % mode))
    print('     encoding-gap sidecar rows: %d' % len(gaps))
S, W = runs['symbolic'], runs['wired']
definite = lambda r: r['result'] in ('SAT', 'UNSAT')

print('\n== 2. justified implications (A-consistent => B-consistent), violations = A SAT & B UNSAT')
for lab, K, pop_ in (('symbolic, all 2,396', S, files), ('wired, 847 wired-answerable (diagnostic)', W, sorted(wired_ok))):
    tot = 0
    for a, b in IMPL:
        v = [f for f in pop_ if K[(f, a)]['result'] == 'SAT' and K[(f, b)]['result'] == 'UNSAT']
        undec = sum(1 for f in pop_ if not (definite(K[(f, a)]) and definite(K[(f, b)])))
        tot += len(v)
        print('  %-42s %-15s violations %d (undecided pairs %d) %s' % (lab, a + '=>' + b, len(v), undec, v[:3]))
    out['violations_' + lab.split(',')[0]] = tot

print('\n== 3. WEAKEST parity with SymbolicRfRun')
srr = {r['test']: r for r in rd(os.path.join(O, 'symbolic-rf-results.csv'))}
ps = sum(1 for f in files if srr[f]['symbolic_verdict'] == S[(f, 'WEAKEST')]['verdict'])
pw = sum(1 for f in files if srr[f]['wired_verdict'] == W[(f, 'WEAKEST')]['verdict'])
print('  symbolic %d/%d   wired %d/%d   (SymbolicRfRun rows %d)' % (ps, len(files), pw, len(files), len(srr)))
for f in files:
    if srr[f]['symbolic_verdict'] != S[(f, 'WEAKEST')]['verdict']:
        print('   DIFF', f, srr[f]['symbolic_verdict'], S[(f, 'WEAKEST')]['verdict'])

print('\n== 4. wired vs symbolic (diagnostic; only the 847 wired-answerable tests are comparable)')
for lab, pop_ in (('847 wired-answerable', sorted(wired_ok)), ('all 2,396 (not comparable: memory atoms/fallback)', files)):
    d = {m: sum(1 for f in pop_ if S[(f, m)]['verdict'] != W[(f, m)]['verdict']) for m in MODELS}
    print('  %-50s differing verdicts per model %s' % (lab, d))

print('\n== 5. herd7 (pinned 7.58; sc.cat all tests, x86tso.cat x86) vs WEV symbolic')
herd = {r['relpath']: r for r in rd(os.path.join(D, 'herd7-frozen-results.csv'))}
print('  herd7 rows %d of %d; herd SC results %s' % (len(herd), len(files), dict(collections.Counter(r['herd_sc'] for r in herd.values()))))
suite = lambda f: f.split('/')[0]
for model, hcol, sel in (('SC', 'herd_sc', lambda f: True), ('TSO', 'herd_tso', lambda f: frozen[f]['arch'] == 'X86')):
    tab = collections.defaultdict(lambda: [0, 0, 0, 0])   # agree, disagree, herd-excluded, wev-excluded
    dis = []
    for f in files:
        if not sel(f):
            continue
        g = (frozen[f]['arch'], suite(f))
        h = herd.get(f, {}).get(hcol, 'MISSING')
        w = S[(f, model)]
        if h not in ('ALLOWED', 'FORBIDDEN'):
            tab[g][2] += 1
            continue
        if not definite(w):
            tab[g][3] += 1
            continue
        if h == w['verdict']:
            tab[g][0] += 1
        else:
            tab[g][1] += 1
            dis.append((f, h, w['verdict']))
    tot = [sum(v[i] for v in tab.values()) for i in range(4)]
    print('  %s: agree %d / compared %d; herd7 not definite %d; WEV not definite %d' % (model, tot[0], tot[0] + tot[1], tot[2], tot[3]))
    for g, v in sorted(tab.items()):
        print('     %-6s %-11s agree %4d  disagree %3d  herd-excluded %3d  wev-excluded %d' % (g[0], g[1], *v))
    out['herd_' + model] = (tot, dis)
    with open(os.path.join(D, 'herd7-%s-disagreements.csv' % model), 'w', newline='', encoding='utf-8') as fh:
        w_ = csv.writer(fh)
        w_.writerow(['file', 'herd7', 'wev_symbolic'])
        w_.writerows(dis)

print('\n== 6. discriminators (fake-edge ablation on the frozen population)')
sd = rd(os.path.join(O, 'sdep', 'sdep-discriminating-all-fake-tests.csv'))
print('  fake-carrying %d (by arch %s); fake edges data %d addr %d ctrl %d' % (
    len(sd), dict(collections.Counter(r['arch'] for r in sd)), sum(int(r['data_fake']) for r in sd),
    sum(int(r['addr_fake']) for r in sd), sum(int(r['ctrl_fake']) for r in sd)))
disc = [r for r in sd if r['discriminating'] == 'true']
print('  discriminating %d:' % len(disc))
for r in disc:
    print('     %-70s kinds=%-6s none=%s all=%s current=%s norm=%s' % (r['file'], r['fake_kinds'], r['verdict_none'],
          r['verdict_all_deps_semantic'], r['verdict_current'], pop[r['file']]['norm_sha256'][:10]))
mut = open(os.path.join(O, 'mutation-summary.md'), encoding='utf-8').read() if os.path.exists(os.path.join(O, 'mutation-summary.md')) else ''
m_ = re.search(r'pairs=(\d+) mutated=(\d+) DISCRIMINATING=(\d+)', open(os.path.join(M, 'logs', 'mutation.log'), encoding='utf-8', errors='replace').read())
print('  mutation sweep:', m_.group(0) if m_ else 'see logs/mutation.log')

print('\n== 7. closure vs composed (data pairs)')
pairs = [r for r in rd(os.path.join(O, 'pairs-corpus.csv')) if r['write_id']]
print('  pairs %d in %d tests; cat_S %s; cat_O %s' % (len(pairs), len({r['test'] for r in pairs}),
      dict(collections.Counter(r['cat_S'] for r in pairs)), dict(collections.Counter(r['cat_O'] for r in pairs))))

print('\n== 8. detector / dependency audits on the frozen population')
pw_ = rd(os.path.join(O, 'pwt-equivalence-sweep.csv'))
print('  PwT sweep rows %d, agree %d' % (len(pw_), sum(1 for r in pw_ if r.get('agree') == 'true')))
q = rd(os.path.join(O, 'qfbv-detector-results.csv'))
print('  QF_BV detector rows %d, changed %d' % (len(q), sum(1 for r in q if r.get('changed') == 'true')))
print('  Layer-2 sites %d' % len(rd(os.path.join(O, 'layer2-audit.csv'))))
dq = os.path.join(O, 'detector-quality', 'detector-quality-report.csv')
if os.path.exists(dq):
    rows = rd(dq)
    print('  detector-quality edges %d (fake %d, semantic %d)' % (len(rows),
          sum(1 for r in rows if r.get('is_semantic', r.get('semantic', '')) in ('false', 'False')),
          sum(1 for r in rows if r.get('is_semantic', r.get('semantic', '')) in ('true', 'True'))))
log = open(os.path.join(M, 'logs', 'oracle-audit.log'), encoding='utf-8', errors='replace').read()
print('  oracle audit:', ' | '.join(l.strip() for l in log.splitlines() if re.search(r'(?i)unsound|conservative|audited|exit', l))[:400])

print('\n== 9. C-only suites and published examples')
for name in ('generated-hard-pairs.csv', 'generated-pairs-folding.csv'):
    p = os.path.join(O, name)
    print('  %-28s identical to shipped: %s' % (name, os.path.exists(p) and filecmp.cmp(p, os.path.join(E, name), shallow=False)))
res = json.load(open(os.path.join(M, 'eval', 'results.json'), encoding='utf-8'))
for k in ('examples', 'published34', 'jmm20', 'dat3m41'):
    print('  %-12s %s' % (k, {kk: vv for kk, vv in res.get(k, {}).items() if not isinstance(vv, (list, dict)) and kk not in ('ran_at', 'source')}))
