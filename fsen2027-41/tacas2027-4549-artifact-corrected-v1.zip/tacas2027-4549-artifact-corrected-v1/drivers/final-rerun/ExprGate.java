package wev.smt.cli;

import com.weakest.model.Event;
import com.weakest.model.EventType;
import com.weakest.model.WriteEvent;
import org.sosy_lab.common.ShutdownNotifier;
import org.sosy_lab.common.configuration.Configuration;
import org.sosy_lab.common.log.BasicLogManager;
import org.sosy_lab.java_smt.SolverContextFactory;
import org.sosy_lab.java_smt.api.SolverContext;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;

import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Pre-run expression gate (external audit tool; no solving). For every manifest entry
 * (hash-verified by CorpusValidation.loadManifest): parse, then apply the driver's
 * symbolicEncodingGaps, and count what was checked.
 * Output: test,status,writes_checked,init_writes,composed_exprs,pins,mem_finals,gaps
 * Args: root manifest.csv out.csv
 */
public final class ExprGate {
    public static void main(String[] a) throws Exception {
        Path root = Path.of(a[0]);
        List<CorpusValidation.ManifestEntry> entries = CorpusValidation.loadManifest(root, Path.of(a[1]));
        Configuration cfg = Configuration.defaultConfiguration();
        int clean = 0, gapped = 0, failed = 0;
        try (SolverContext ctx = SolverContextFactory.createSolverContext(cfg, BasicLogManager.create(cfg),
                ShutdownNotifier.createDummy(), SolverContextFactory.Solvers.Z3);
             PrintWriter w = new PrintWriter(Files.newBufferedWriter(Path.of(a[2])))) {
            w.println("test,status,writes_checked,init_writes,composed_exprs,pins,mem_finals,gaps");
            for (CorpusValidation.ManifestEntry e : entries) {
                LitmusCase lc;
                try {
                    Event.resetCounter();
                    lc = LitmusParser.parse(e.content(), e.path());
                } catch (RuntimeException ex) {
                    w.println(e.path() + ",PARSE-FAIL,0,0,0,0,0," + ex.getClass().getSimpleName());
                    failed++;
                    continue;
                }
                int writes = 0, inits = 0, composed = 0;
                for (Event ev : lc.es().getEvents()) {
                    if (!(ev instanceof WriteEvent || ev.getType() == EventType.INIT)) continue;
                    writes++;
                    if (ev.getThreadId() == 0) inits++;
                    String x = lc.writeValueExprs().get(ev.getId());
                    if (x != null && x.contains("R")) composed++;
                }
                List<String> gaps = CorpusValidation.symbolicEncodingGaps(lc, ctx);
                if (gaps.isEmpty()) clean++; else gapped++;
                w.println(String.join(",", e.path(), gaps.isEmpty() ? "COMPLETE" : "GAPS",
                        Integer.toString(writes), Integer.toString(inits), Integer.toString(composed),
                        Integer.toString(lc.existsReadValues().size()), Integer.toString(lc.existsMemFinal().size()),
                        '"' + String.join(" | ", gaps).replace("\"", "'") + '"'));
            }
        }
        System.out.printf("entries %d: complete %d, with gaps %d, parse failures %d%n", entries.size(), clean, gapped, failed);
    }
}
