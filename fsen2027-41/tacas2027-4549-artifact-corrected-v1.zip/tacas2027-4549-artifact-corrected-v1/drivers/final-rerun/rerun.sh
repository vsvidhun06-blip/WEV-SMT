#!/usr/bin/env bash
# Frozen-population rerun (symbolic-driver report §8). Run from the mirror root; every output
# goes to out/ or logs/ inside the mirror. Never touches the repository.
set -u
M="$1"; ADAPTER_SRC="$2"
cd "$M" || exit 2
mkdir -p out logs
CP="target/classes;$(cat target/cp.txt)"
J=(java "-Djava.library.path=target/native" -cp "$CP")
stamp() { date '+%Y-%m-%dT%H:%M:%S'; }
step() { local name="$1"; shift; ( echo "start $(stamp)"; "$@"; echo "exit $? $(stamp)" ) > "logs/$name.log" 2>&1; }

# 1-2. five models (six implemented): symbolic headline, wired diagnostic
step five-symbolic "${J[@]}" wev.smt.cli.CorpusValidation eval/corpus out/five-model \
     manifest=frozen-eligible-hashes.csv mode=symbolic csv=frozen-symbolic.csv perFileSec=30 budgetMin=600 maxEvents=64 &
step five-wired "${J[@]}" wev.smt.cli.CorpusValidation eval/corpus out/five-model \
     manifest=frozen-eligible-hashes.csv mode=wired csv=frozen-wired.csv perFileSec=30 budgetMin=600 maxEvents=64 &
# 3. established WEAKEST driver (wired + symbolic) for parity
step srr "${J[@]}" wev.smt.cli.SymbolicRfRun corpus frozen-eligible-manifest.csv eval/corpus out/symbolic-rf-results.csv &
# 4. semantic-vs-syntactic ablation, then mutation sweep on its output
( step sdep "${J[@]}" wev.smt.ablation.SdepFakeDiscriminatingRun manifest=frozen-eligible-manifest.csv \
       corpusRoot=eval/corpus out=out/sdep timeoutSec=30 maxEvents=64
  step mutation "${J[@]}" wev.smt.cli.MutationCorpusRun out/sdep/sdep-discriminating-all-fake-tests.csv eval/corpus \
       out/mutation-corpus-results.csv out/mutation-summary.md ) &
# 5. detector / dependency audits on the frozen population
( step pwt "${J[@]}" wev.smt.cli.PwtEquivalenceSweep frozen-eligible-manifest.csv eval/corpus out/pwt-equivalence-sweep.csv
  step qfbv "${J[@]}" wev.smt.cli.QfbvDetectorRun frozen-eligible-manifest.csv eval/corpus out/qfbv-detector-results.csv out/qfbv-summary.md
  step layer2 "${J[@]}" wev.smt.cli.Layer2AuditRun frozen-eligible-manifest.csv eval/corpus out/layer2-audit.csv
  mkdir -p out/detector-quality
  step detector-quality "${J[@]}" wev.smt.cli.DetectorQualitySweep frozen-eligible-manifest.csv eval/corpus out/detector-quality
  step oracle-audit "${J[@]}" wev.smt.cli.DetectorOracleAudit frozen-eligible-manifest.csv eval/corpus out/detector-oracle-audit.csv --limit 12000 ) &
# 6. closure vs composed (external adapter, compiled against the pinned classes)
( mkdir -p out/adapter && javac -proc:none -nowarn -d out/adapter -cp "$CP" "$ADAPTER_SRC" \
  && step coherence java "-Djava.library.path=target/native" -cp "out/adapter;$CP" CoherencePairs corpus out/pairs-corpus.csv frozen-eligible-manifest.csv eval/corpus ) &
# 7. C-only generators (byte-identity with shipped)
( step hardbench "${J[@]}" wev.smt.cli.HardExprBenchRun eval/generated-hard-candidates.json out/generated-hard-pairs.csv 2 3
  step pairs "${J[@]}" wev.smt.cli.GeneratedPairsRun out/generated-pairs-folding.csv out/generated 2 6 ) &
# 8. published examples (run_all example steps; writes only inside the mirror's eval/)
step examples python eval/run_all.py --no-build --only examples dat3m41 jmm20 published34 &
wait
echo "ALL DONE $(stamp)" > logs/DONE
