import com.weakest.model.Event;
import com.weakest.model.RMWEvent;
import com.weakest.model.ReadEvent;
import com.weakest.model.WriteEvent;

import wev.smt.DependencyInfo;
import wev.smt.DependencyInfo.DepKind;
import wev.smt.DependencyInfo.KindedEdge;
import wev.smt.QfbvConstancyOracle;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;

import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * EXTERNAL measurement adapter (lives outside the repository; uses only public API of the
 * shipped classes plus reflection to call HardExprBenchRun's package-private generator).
 *
 * For every non-init program write c of every input and every read p in
 *   S(c) ∪ O(c) ∪ vars(composed(c))
 * it records:
 *   S  = shipped default closure (CONSTANCY_ORACLE = null: idiom folding + linear cancel)
 *   O  = same local closure with the QF_BV oracle installed (paper's WEAKEST/sdep_impl config)
 *   C  = exact QF_BV oracle on the composed expression writeValueExprs(c), target R<p>
 *
 * Args: mode(corpus|examples|hard|files) out.csv [list args...]
 */
public final class CoherencePairs {

    static final Pattern RVAR = Pattern.compile("(?<![A-Za-z0-9_])R(\\d+)(?![A-Za-z0-9_])");
    static final Pattern IDENT = Pattern.compile("[A-Za-z_]\\w*");

    record Input(String suite, String id, String src, String extra) { }

    public static void main(String[] a) throws Exception {
        String mode = a[0];
        Path out = Path.of(a[1]);
        List<Input> inputs = new ArrayList<>();
        switch (mode) {
            case "corpus" -> {               // a[2]=manifest a[3]=root
                for (String line : Files.readAllLines(Path.of(a[2]))) {
                    String t = line.strip(); if (t.isEmpty()) continue;
                    String rel = t.contains(",") ? t.substring(0, t.indexOf(',')) : t;
                    inputs.add(new Input("corpus", rel, Files.readString(Path.of(a[3]).resolve(rel)), ""));
                }
            }
            case "files" -> {                // a[2]=suite a[3..]=files
                for (int i = 3; i < a.length; i++)
                    inputs.add(new Input(a[2], a[i].replace('\\', '/'), Files.readString(Path.of(a[i])), ""));
            }
            case "hard" -> {                 // a[2]=candidates.json
                Class<?> h = Class.forName("wev.smt.cli.HardExprBenchRun");
                Method lit = h.getDeclaredMethod("litmus", String.class, int.class, String.class);
                lit.setAccessible(true);
                String s = Files.readString(Path.of(a[2]));
                Matcher m = Pattern.compile("\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(s);
                while (m.find()) {
                    String e = m.group(1).replace("\\\"", "\"");
                    for (int n = 2; n <= 3; n++) {
                        String name = "HARD-n" + n + "-" + Integer.toHexString(e.hashCode());
                        inputs.add(new Input("hard", name, (String) lit.invoke(null, name, n, e),
                                e + "|n=" + n));
                    }
                }
            }
            default -> throw new IllegalArgumentException(mode);
        }

        try (QfbvConstancyOracle installed = new QfbvConstancyOracle();
             QfbvConstancyOracle composedOracle = new QfbvConstancyOracle();
             PrintWriter w = new PrintWriter(Files.newBufferedWriter(out))) {
            w.println("suite,test,extra,arch,test_has_ctrl,test_status,write_id,write_thread,write_ord,"
                    + "is_rmw,read_id,read_thread,read_ord,raw_store_expr,composed_expr,occurrence,"
                    + "S,O,C,C_reason,cat_S,cat_O,query_ms");
            int done = 0;
            for (Input in : inputs) {
                if (++done % 250 == 0) System.err.println("  " + done + "/" + inputs.size());
                runOne(in, installed, composedOracle, w);
            }
        }
    }

    static String q(String s) { return '"' + (s == null ? "" : s.replace("\"", "\"\"")) + '"'; }

    static void runOne(Input in, QfbvConstancyOracle installed, QfbvConstancyOracle co, PrintWriter w) {
        LitmusCase lcS, lcO;
        try {
            LitmusParser.CONSTANCY_ORACLE = null;
            Event.resetCounter();
            lcS = LitmusParser.parse(in.src(), in.id());
            LitmusParser.CONSTANCY_ORACLE = installed;
            Event.resetCounter();
            lcO = LitmusParser.parse(in.src(), in.id());
        } catch (Exception e) {
            w.println(String.join(",", q(in.suite()), q(in.id()), q(in.extra()), "", "", q("PARSE-FAIL:" + e.getClass().getSimpleName()),
                    "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""));
            return;
        } finally {
            LitmusParser.CONSTANCY_ORACLE = null;
        }
        // identity sanity: event lists and composed expressions must coincide across the two parses
        String status = "ok";
        if (!lcS.es().getEvents().toString().equals(lcO.es().getEvents().toString())) status = "EVENT-MISMATCH";
        if (!lcS.writeValueExprs().equals(lcO.writeValueExprs())) status = "EXPR-MISMATCH";

        boolean hasCtrl = lcS.deps().allEdges().stream().anyMatch(k -> k.kind() == DepKind.CTRL);
        Map<Integer, Map<Integer, String>> sFlags = dataFlags(lcS.deps());
        Map<Integer, Map<Integer, String>> oFlags = dataFlags(lcO.deps());

        Map<Integer, Event> byId = new HashMap<>();
        Map<Integer, Integer> ord = new HashMap<>();
        Map<Integer, Integer> perThread = new HashMap<>();
        for (Event e : lcS.es().getEvents()) {
            byId.put(e.getId(), e);
            int k = perThread.merge(e.getThreadId(), 1, Integer::sum);
            ord.put(e.getId(), k - 1);
        }

        boolean anyRow = false;
        for (Event e : lcS.es().getEvents()) {
            if (!(e instanceof WriteEvent || e instanceof RMWEvent) || e.getThreadId() == 0) continue;
            int wid = e.getId();
            boolean rmw = e instanceof RMWEvent;
            String composed = lcS.writeValueExprs().get(wid);
            String raw = (e instanceof WriteEvent we) ? we.getValueExpression() : "";
            TreeSet<Integer> reads = new TreeSet<>();
            reads.addAll(sFlags.getOrDefault(wid, Map.of()).keySet());
            reads.addAll(oFlags.getOrDefault(wid, Map.of()).keySet());
            Set<Integer> mentioned = new TreeSet<>();
            if (composed != null) {
                Matcher m = RVAR.matcher(composed);
                while (m.find()) mentioned.add(Integer.parseInt(m.group(1)));
            }
            reads.addAll(mentioned);
            Map<Integer, String> occ = occurrence(raw, composed);
            for (int rid : reads) {
                anyRow = true;
                String s = sFlags.getOrDefault(wid, Map.of()).getOrDefault(rid, "ABSENT");
                String o = oFlags.getOrDefault(wid, Map.of()).getOrDefault(rid, "ABSENT");
                String c, reason = "";
                long t0 = System.nanoTime();
                if (composed == null) { c = "ERROR"; reason = "no composed expr"; }
                else if (!byId.containsKey(rid) || !(byId.get(rid) instanceof ReadEvent)) { c = "ERROR"; reason = "R" + rid + " not a read event"; }
                else if (!mentioned.contains(rid)) { c = "CONST"; reason = "variable absent from composed expr"; }
                else {
                    Boolean k;
                    try { k = co.isConstant(composed, "R" + rid); }
                    catch (RuntimeException ex) { k = null; reason = "exception " + ex; }
                    if (k == null) {
                        c = "UNSUPPORTED";
                        String why = co.undecidedReasons().get(composed.replaceAll("\\s+", ""));
                        reason = why == null ? reason : why;
                        if (why != null && why.startsWith("solver")) c = "ERROR";
                    } else c = k ? "CONST" : "VARIES";
                }
                long ms = (System.nanoTime() - t0) / 1_000_000;
                Event re = byId.get(rid);
                w.println(String.join(",", q(in.suite()), q(in.id()), q(in.extra()), String.valueOf(lcS.arch()),
                        String.valueOf(hasCtrl), q(status), String.valueOf(wid), String.valueOf(e.getThreadId()),
                        String.valueOf(ord.get(wid)), String.valueOf(rmw), String.valueOf(rid),
                        re == null ? "" : String.valueOf(re.getThreadId()), re == null ? "" : String.valueOf(ord.get(rid)),
                        q(raw), q(composed), occ.getOrDefault(rid, "NONE"), s, o, c, q(reason),
                        cat(s, c, rmw), cat(o, c, rmw), String.valueOf(ms)));
            }
        }
        if (!anyRow) {
            w.println(String.join(",", q(in.suite()), q(in.id()), q(in.extra()), String.valueOf(lcS.arch()),
                    String.valueOf(hasCtrl), q(status + ";NO-PAIRS"), "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""));
        }
    }

    static String cat(String closure, String c, boolean rmw) {
        if (rmw) return "rmw-out-of-scope";
        if (c.equals("UNSUPPORTED")) return "unsupported";
        if (c.equals("TIMEOUT")) return "timeout";
        if (c.equals("ERROR")) return "extraction-error";
        boolean cr = c.equals("VARIES");
        boolean xr = closure.equals("REAL") || closure.equals("BOTH");
        if (xr && cr) return "agree-REAL";
        if (!xr && !cr) return closure.equals("ABSENT") ? "agree-FAKE(absent)" : "agree-FAKE";
        if (xr) return "closureREAL/composedFAKE";
        return closure.equals("ABSENT") ? "closureFAKE/composedREAL(absent)" : "closureFAKE/composedREAL";
    }

    /** DATA edges only: write id -> read id -> REAL/FAKE/BOTH. */
    static Map<Integer, Map<Integer, String>> dataFlags(DependencyInfo d) {
        Map<Integer, Map<Integer, String>> m = new HashMap<>();
        for (KindedEdge k : d.allEdges()) {
            if (k.kind() != DepKind.DATA) continue;
            String f = k.edge().isSemantic() ? "REAL" : "FAKE";
            m.computeIfAbsent(k.edge().consumer().getId(), x -> new HashMap<>())
             .merge(k.edge().producer().getId(), f, (x, y) -> x.equals(y) ? x : "BOTH");
        }
        return m;
    }

    /**
     * Re-align the composed string with the raw store expression (substituteSymbolic
     * replaces each identifier by "(sym)" or "0") and report, per read, whether it reaches
     * the store directly (some identifier's symbol is exactly R<id>), only through an
     * intermediate assignment (inside a larger symbol), or both.
     */
    static Map<Integer, String> occurrence(String raw, String composed) {
        Map<Integer, String> res = new HashMap<>();
        if (raw == null || composed == null) return res;
        String r = raw.strip(), c = composed.strip();
        Matcher m = IDENT.matcher(r);
        int ri = 0, ci = 0;
        try {
            while (m.find()) {
                String lit = r.substring(ri, m.start());
                if (!c.startsWith(lit, ci)) return mark(res, composed, "ALIGN-FAIL");
                ci += lit.length();
                ri = m.end();
                if (c.charAt(ci) == '(') {
                    int depth = 0, j = ci;
                    for (; j < c.length(); j++) {
                        if (c.charAt(j) == '(') depth++;
                        else if (c.charAt(j) == ')' && --depth == 0) break;
                    }
                    String sym = c.substring(ci + 1, j);
                    ci = j + 1;
                    Matcher rv = RVAR.matcher(sym);
                    boolean exact = sym.matches("R\\d+");
                    while (rv.find()) {
                        int id = Integer.parseInt(rv.group(1));
                        String kind = exact ? "DIRECT" : "CHAIN";
                        res.merge(id, kind, (x, y) -> x.equals(y) ? x : "MIXED");
                    }
                } else if (c.charAt(ci) == '0') {
                    ci += 1;
                } else return mark(res, composed, "ALIGN-FAIL");
            }
            if (!c.substring(ci).equals(r.substring(ri))) return mark(res, composed, "ALIGN-FAIL");
        } catch (RuntimeException ex) {
            return mark(res, composed, "ALIGN-FAIL");
        }
        return res;
    }

    static Map<Integer, String> mark(Map<Integer, String> res, String composed, String tag) {
        Matcher rv = RVAR.matcher(composed);
        while (rv.find()) res.put(Integer.parseInt(rv.group(1)), tag);
        return res;
    }
}
