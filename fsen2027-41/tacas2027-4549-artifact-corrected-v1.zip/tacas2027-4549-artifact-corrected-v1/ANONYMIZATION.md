# Anonymization record

Changes were applied to **package copies only**. No identity is reproduced here.

| Category | Files | Replacements | Replacement text |
|---|---|---|---|
| absolute paths into the local Maven repository | 1 (`impl/PIN.txt`) | 27 | `<M2_REPO>` |
| absolute paths into the measurement work area | 8 (`drivers/ppo-repair/remeasure.sh`, four `*.config.txt` run records, `impl/PIN.txt`; since 2026-10-12 also `evidence/logs/pwt.log` (2) and `evidence/logs/oracle-audit.log` (1)) | 13 | `<AUDIT_ROOT>` |
| absolute paths into the implementation checkout | 1 (`impl/PIN.txt`) | 2 | `<IMPL_ROOT>` |
| version-control commit identifiers of the development repository | 2 (`impl/PIN.txt`, `chain-composition/results/build-provenance.txt`) | 2 | `<redacted-commit>` |

`impl/PIN.txt` is counted in each category in which it had replacements.

## Checked and found clean

- **Personal names, account names, e-mail addresses, affiliations.** No occurrence remains
  in any text file, binary, class file or jar. This was checked by a case-insensitive scan of
  every packaged file, binaries included. The upstream litmus files were scanned too.
- **Repository links.** No URL of the development repository appears.
- **Paper PDF.** The author, title, subject and keywords metadata are empty, and there are
  no embedded paths. The producer and creation date are the TeX engine defaults.
- **Licence.** The packaged `LICENSE` names "The WEV-SMT Authors" only. Upstream licences
  and copyright notices (herdtools7, Dat3M) are preserved verbatim.

## Effect on hashes

- **`impl/PIN.txt` no longer hashes as recorded.** The aggregates it states are unaffected,
  because they are computed over the snapshot lines and the class files, which were not edited.
- **The `*.config.txt` run records** differ from the originals only in the placeholder paths.

## Residual risk (not changed, because changing it would invalidate pinned hashes)

**Code and package names.** The Java packages (`wev.smt`, `com.weakest`), the Maven
coordinates and the tool name "WEV-SMT" are compiled into the pinned classes and jars.
They coincide with the name of a public development repository. Renaming them would break
the hash pins that identify the evaluated implementation. Whether to rename for review is a
decision for the authors.

## corrected-v1 update (2026-10-19)

**Correction to the record above.** The 2026-10-12 statement that all such paths were replaced
was inaccurate (audit F-09): two files still contained a local Linux home path to the opam root,
`drivers/final-rerun/run_herd7_frozen.sh` (L7-8) and
`results/authoritative/rerun-2026-10-09/herd7-model-closure.txt` (14 lines).

| File | Change in this package | Original |
|---|---|---|
| `drivers/final-rerun/run_herd7_frozen.sh` | the hard-coded opam root replaced by `$OPAM_ROOT` (required variable; 3 lines) | SHA-256 in `history/package-20261012/SHA256SUMS` |
| `results/authoritative/rerun-2026-10-09/herd7-model-closure.txt` | `<home>/.opam` replaced by `<OPAM_ROOT>` on 14 lines; the SHA-256 values in the file are of file contents and stay valid | SHA-256 in `history/package-20261012/SHA256SUMS` |

These two files are the only modified 2026-10-12 files **not** preserved verbatim under
`history/` (doing so would re-ship the path); their original hashes remain verifiable from
`history/package-20261012/SHA256SUMS` by anyone holding the 2026-10-12 package.

**New material.** Evidence copied from the 2026-10 audit and investigation
(`correction-record/`) and the 2026-10-19 run records (`results/corrected-v1/`) had local
absolute paths replaced by `<HOME>`, `<LINUX_HOME>`, `<PKG>` (package root) or `<OUTER>` (the
build workspace); every replacement is listed in `correction-record/PATH-SUBSTITUTIONS.csv`.
Third-party POMs in `deps/m2/` are unmodified and contain their upstream maintainers' contact
details. TACAS artifact evaluation does not require anonymity; the double-blind manuscript
(`paper/`) is unchanged and still anonymous. Whether to de-anonymise the artifact on acceptance
(author names in `LICENSE`, a DOI record) is an author decision.

