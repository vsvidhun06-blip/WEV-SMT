# Errata (package copies only; originals unchanged)

> corrected-v1 (2026-10-19): entries **E4-E11** below were added after the audit of 2026-10-17
> and the correctness investigation of 2026-10-18. E4 is an implementation defect that changes
> four totals of the submitted paper; the corrected implementation and results are shipped
> separately (`impl-corrected-v1/`, `results/corrected-v1/`). Full statement and evidence:
> `CORRECTION-NOTICE.md`. Entries E1-E3 and the notes below them are unchanged from the
> 2026-10-12 package, except that E1's appendix reference is now A.8 (the submitted numbering).

## E1. Unit labels in the chain-composition accounting

Four distinct units occur. Earlier summaries sometimes conflated them.

| Unit | Count | Normalisation key |
|---|---|---|
| threads (generated litmus files) | 256 | one per file |
| distinct programs | 236 | registers renamed by first appearance; constants and locations kept |
| distinct shapes | 168 | as above, with every constant also abstracted |
| (load, store) pairs | 317 | one per load of a thread against its single store |
| distinct program/load pairs | 291 | program key + load index |
| distinct shape/load pairs | 213 | shape key + load index |

Corrections in `chain-composition/REPORT.md` (package copy):
- **Duplicated-instances sentence.** "INJ L=1 has 7 unique programs over 16 pairs" now
  reads "12 threads, 5 distinct programs and 7 distinct program/load pairs over 16 pairs".
- **Uniqueness line.** Now also states the 236 programs and 168 shapes.

In the generated `chain-composition/results/tables.md`, the "uniq" columns and the
"N shapes" in the disagreement list count **(program, load)** and **(shape, load)**
pairs. That file is a deterministic output and is left byte-identical. For the
disagreement lists the two readings coincide numerically:
- A: 108 programs = 108 program/load pairs; 77 shapes = 77 shape/load pairs;
- B: 72 = 72; 53 = 53.

A development summary once referred to "291 unique programs"; the correct unit is
**program/load pairs**. The paper uses the correct units (§6.2: "317 load–store pairs, 213
distinct up to register renaming and constants"; App. A.8 [A.6 in the 2026-10-12 text]: 236 programs, 168 shapes, 291
and 213 pairs).

## E2. Hard-benchmark enumeration (paper App. A.6, *Enumeration*)

The paper describes the atoms `{r, ~r}`, the constants `{0,1,2,3,7,255}` and the operators
`{+,-,*,&,^}`. The recorded candidate list and its 13,880 intermediate forms imply a further
restriction: three-operator forms use only the leaves `{r, ~r, 0, 1}` and the operators
`{&, *, ^}`, and every form must mention the register. See `hardbench/README.md`.

The paper's own note already allows for this: it calls 13,880 a figure reported from that
run, smaller than a direct product count. This note makes the rule explicit. It changes no
reported number.

## E3. Scalability ratio orientation (paper App. A.6, *Scalability*)

The reported range "between 0.80 and 1.70 through n = 12" is the ratio
**LBChain / LBFakeChain** of WEAKEST full-execution times. The inverse orientation gives
0.59–1.25. `reproduce/05_claims.py` checks the stated orientation.

## Symbolic value-consistency correction

The current paper table uses 1,288 value-consistent instances. The other 2,368
all-ones queries fail value consistency and are not dependency-discrimination
positives. Historical wired rows remain unmodified for traceability.
The grounded-half result (385 expressions, 770 instances) is unchanged.

## Semantic-scope closeout (2026-10-10)

The paper now states relational encoding adequacy for the supplied relation C;
it does not claim the prototype closure equals composed dependence in general.
JF equals RF in the encoder and the proof. Exactness is scoped to straight-line
load/assignment/store threads; guarded register writes have no label semantics
in the application. The defined dependency-cycle criterion is not an independently
validated out-of-thin-air predicate. All 110 positive benchmark expressions satisfy
e(0)=e(1)=1; each can write 1 after reading initial 0. Benchmark counts and code
are unchanged. No Promising-model or compilation validation is claimed.


## Post-blind-review scope correction (2026-10-11)

MutationCorpusRun uses wired folded values, not symbolic value propagation.
Replacing r XOR r with r AND r changes the source expression from 0 to r.
The preserved five ALLOWED/FORBIDDEN changes are historical wired candidate
diagnostics, not source-program verdicts, value-preserving transformations,
or isolated evidence of dependency-strengthening soundness. The original CSV
and report are retained unchanged as records; their causal descriptions must
be read with this correction. The separate six-file edge-relabelling ablation
is unaffected. No experiment was rerun for this wording correction.

The folding benchmark is limited to the authored implementation and constructed
population. No dominance over arbitrary idiom recognizers or cheap analyses is
claimed. The chain population has 256 threads including 14 controls.
Activity restrictions must remain candidate-well-formed; the oracle detector
and address extensions retain their stated proof boundaries. Core theorems,
code, bibliography and raw results are unchanged.


## Minor-review closeout (2026-10-11)

The paper clarifies file/program units, audit populations, exclusion accounting, model naming and check-case terminology. The synthesis description is limited to its finite decision-table population. REVERSION-RECORD.json archives historical prose provenance for the 293-divergence replay; it is not raw replay output or a reproducer. Source, theories and raw evaluation data are unchanged.


## E4. Well-formedness over-constraint in the encoder (F-01): four totals change

The submitted build's well-formedness constraints kept cross-location R→W/R→R program-order
edges in a single global witness order from which co is read; `W x; R x; W y` thereby
re-imposed a W→W order no PSO/RA/WEAKEST/RC11 axiom requires. Exactly 12 of 14,376 verdicts
are wrong (FORBIDDEN instead of ALLOWED): `Dat3M/litmus/PPC/2+2W+rfi-datas`,
`Dat3M/litmus/X86/m55ii`, `Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009`, each
under PSO, RA, WEAKEST and RC11. Paper §6.4 (p. 16, L960-962) reads PSO 1,170/1,226,
RA 2,089/307, WEAKEST 2,356/40, RC11 2,169/227; corrected: **PSO 1,173/1,223, RA 2,092/304,
WEAKEST 2,359/37, RC11 2,172/224**. SC, TSO, the implications, 187/0, the six discriminators,
the wired table, the chain experiment and Table 2 are unchanged (verified). Repair:
`impl-corrected-v1/CORRECTION.diff`. The submitted results file is kept unchanged.

## E5. Proposition 1 scope (p. 8 / p. 25)

Prop. 1 is correct for the consistency conjunct. The sentence "Prop. 1 holds of the emitted
formula as it stands" (L1513-1514) and caveat (iv) (L490-492) overstate it: the solved query
also contains the well-formedness conjunct, for which the submitted build fails the "if"
direction (E4). Proposed repair: Lemma "Well-formedness adequacy" (proposed patch).

## E6. LB-real: transcription versus figure (p. 9 Fig. 1; p. 20 (A3))

`inputs/examples/paper/LB-real.litmus` stores `r0 + 1`; the figure's program stores the copy
`r0`. With `r+1` the outcome is value-unreachable: symbolic FORBIDDEN under all six models,
RA included. The file is unchanged; the labelled diagnostic
`inputs/diagnostic-added-2026-10/LB-copy.litmus` gives RA ALLOWED / WEAKEST FORBIDDEN
(symbolic), as the figure states.

## E7. Published-example agreements (p. 16, L948-954)

31/34 reproduces, but 15 of the 34 tests are value-unreachable as transcribed, including all
14 FORBIDDEN data-dependency agreements and TC04; fake dependencies decide only LBfd and LBxor.
TC07 belongs to the control collision group; TC02 parses identically to paper/LB-real.

## E8. Earlier matched-pair sweep (p. 27, L1582-1586)

The 1,600-ring sweep is wired; only 425 of the 1,440 valid and 385 of the 1,015
discriminating rings are value-consistent (`results/carried/generated-pairs*.csv`, recount
`correction-record/investigation-2026-10-18/runs/sweep/`).

## E9. Wired-mode description and wired drivers (p. 8, L465-470)

Wired mode pins co to the loader's order and lets rf range over value-matching writes (the
paper says the reverse). The discriminator ablation, the RC11 matched pair, the App. A.4
witnesses and the n-thread controls are wired; a symbolic re-solve of the ablation gives the
same six files.

## E10. Scalability n-set (p. 16, L970)

The sweep covers n in {2,3,4,5,6,8,10,12,16}, not {2,3,4,6,8,12,16}.

## E11. "Byte-identical" reruns and the claim checker (p. 30 L1765; p. 33 L1910-1912)

Only deterministic outputs rerun byte-identically; z3 witness values may differ. The claim
checker's 31 checks are 26 computed from packaged data, 3 matched against recorded summaries
(A2, X1, A5) and 2 presence-only (S1, I1); none re-runs a solver, and E1 passed on rows that
contain E4's error. Also in `final-analysis.txt` §8 "fake 0, semantic 0" should read 565 and 6
(a column-name bug in `final_analysis.py`).

