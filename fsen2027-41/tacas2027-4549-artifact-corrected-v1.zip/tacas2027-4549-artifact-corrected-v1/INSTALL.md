# Installation

The artifact needs four things, and nothing else. It bundles every Java dependency and the Z3 natives (`deps/`).

| Tool | Version used | Needed by | Bundled? |
|---|---|---|---|
| bash + coreutils (`sha256sum`, `cmp`, `diff`, `find`, `tar`) | Git Bash 2.x (Windows), GNU coreutils (Linux) | all stages | no (standard) |
| JDK **21** (`java`, `javac`) | Eclipse Temurin 21.0.10+7 | stages 3, 4, 6–11 | no (installer below) |
| Python **3.8+** with `z3-solver` **5.0.0.0** | Python 3.11.9 (Windows), 3.12.3 (Linux) | stages 2, 3, 5, 7, 10, 11 | no (installer below) |
| Isabelle**2024** | Isabelle2024 | stage 1 only | no (installer below) |

**Hardware used:** an x86_64 machine with 8 GB RAM is enough (the WSL test VM had 7 GB). Disk: about 190 MB for the extracted package (66 MB ZIP), about 1.5 GB for the toolchain (Isabelle is about 1 GB) and up to 300 MB for `WORK`.

**Network:** needed only to download the toolchain. The checks run offline.

## Linux x86_64

See `INSTALL-LINUX.md`. One script installs everything in user space, hash-pinned:

```
bash tools/setup-linux-toolchain.sh ~/wev-tools
```

## Windows x64 (Git Bash)

1. Install Git for Windows (Git Bash), a JDK 21 (e.g. Temurin 21.0.10+7 MSI), Python 3.8+ and Isabelle2024 (the Windows installer from isabelle.in.tum.de).
2. Install the Python package: `python -m pip install z3-solver==5.0.0.0`. The recorded environment had z3-solver 5.0.0.0, and `z3.get_version_string()` returns 5.0.0, matching the `"z3": "5.0.0"` in `address-check/recorded/address-index-summary.json`.
3. Run in Git Bash, from the package root:
   ```
   export WORK=/c/wev-work                       # outside the package
   export PYTHON=python
   export ISABELLE_HOME=/c/path/to/Isabelle2024  # contains contrib/cygwin/bin/bash.exe
   bash reproduce/run_all.sh; echo "exit status: $?"
   ```

**Windows notes.**
- **Extract to a short path** such as `C:\wev\`. The deepest path in the archive has 183 characters (a Maven-layout jar under `deps/m2/`). Extracting under a long directory can exceed Windows' 260-character `MAX_PATH` limit, and extraction then fails. This was observed when extracting under an 80-character directory. Alternatively, enable Windows long-path support.
- Java paths are converted with `cygpath`.
- Isabelle runs through its bundled Cygwin. Its user directory is isolated in `$WORK/isabelle-user`, and `USER_HOME` is converted inside Cygwin.
- Do **not** pass a Windows-style `USER_HOME` from Git Bash: MSYS rewrites it.

## Choosing what to run

| Command | What runs | Measured time |
|---|---|---|
| `SKIP_ISABELLE=1 bash reproduce/run_all.sh` | smoke test / early light review: every stage except Isabelle; 6/6c smoke; 10 rows mode | see `VERIFICATION-SUMMARY.md` |
| `bash reproduce/run_all.sh` | + both Isabelle sessions | + under 1 minute (default run: about 9 min Linux, 15 min Windows) |
| `RUN_FULL=1 bash reproduce/run_all.sh` | + full Table 2 audit (both builds) and full six-model reruns of both builds | total 26 min (Linux) to 42 min (Windows) |
| `REQUIRE_ALL=1 …` | additionally fail if any check was skipped | — |

**Exit status:**
- `0`: no stage failed. The summary still lists any SKIPPED or PARTIAL stages; those checks did **not** run.
- non-zero: at least one stage failed.
- `2`: an unsafe `WORK` was refused.

Every stage can also run alone, for example `WORK=… bash reproduce/08_corrected_build.sh`.

## Using your own Maven repository

The bundled `deps/m2` is the default. To use another Maven-layout repository, set `M2_REPO`. Every jar and native is still checked against the pinned SHA-256s, so it must hold byte-identical files.
