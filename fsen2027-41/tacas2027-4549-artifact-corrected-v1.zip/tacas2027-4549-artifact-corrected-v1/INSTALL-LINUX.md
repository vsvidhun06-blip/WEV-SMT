# Linux installation and reproduction (x86_64)

**Tested route.**
- Ubuntu 24.04.1 LTS under WSL2 (kernel 6.6, x86_64), with user-space toolchains installed by `tools/setup-linux-toolchain.sh`.
- No `sudo` and no system-wide installation.
- Every package stage was run from a **fresh extraction of the final ZIP**. Results are in `VERIFICATION-SUMMARY.md`.
- Not tested: other distributions, a native (non-WSL) Linux machine, the TACAS 2027 VM (its image is unpublished), and ARM.

## Requirements

- Linux x86_64 with `bash`, GNU coreutils, `curl`, `tar`, `find`, `diff` and `cmp`.
- `python3` ≥ 3.8 with the `venv` module (Debian/Ubuntu package `python3-venv`), used only to create the isolated environment.
- glibc ≥ 2.27, required by the z3-solver wheel.
- `fontconfig` and at least one font (Debian/Ubuntu: `fontconfig fonts-dejavu-core`), needed by Isabelle even in headless builds. Without them stage 1 fails with "Fontconfig head is null" (observed in the minimal container).
- About 1.5 GB of disk for the toolchain, plus the package and `WORK`.

## 1. Toolchain (one command, user space, hash-pinned)

```
bash tools/setup-linux-toolchain.sh ~/wev-tools          # SKIP_ISABELLE=1 to omit Isabelle (~0.7 GB)
```

| Component | Version | Official source | SHA-256 | Licence / redistribution |
|---|---|---|---|---|
| Eclipse Temurin JDK | 21.0.10+7, Linux x64 | `https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.10%2B7/OpenJDK21U-jdk_x64_linux_hotspot_21.0.10_7.tar.gz` | `ea3b9bd464d6dd253e9a7accf59f7ccd2a36e4aa69640b7251e3370caef896a4` (equals Adoptium's published `.sha256.txt`) | GPLv2 + Classpath Exception; not bundled (size) |
| Isabelle | 2024, Linux bundle | `https://isabelle.in.tum.de/website-Isabelle2024/dist/Isabelle2024_linux.tar.gz` | `603aaaf8abea36597af3b0651d2c162a86c0a0dd4420766f47e5724039639267` | Isabelle distribution terms (BSD-style plus bundled components); not bundled (size) |
| z3-solver (Python) | 5.0.0.0, `manylinux_2_27_x86_64` wheel | `https://files.pythonhosted.org/packages/py3/z/z3-solver/z3_solver-5.0.0.0-py3-none-manylinux_2_27_x86_64.whl` | `5571949b47abee67935aeb05db9e48af14ed96ceda18f6ff8b75eb3901bb9c54` (equals the PyPI JSON digest) | MIT; not bundled |

**Version evidence.**
- *z3-solver 5.0.0.0.* On the Windows machine that produced the recorded results, the installed distribution `z3-solver` is version 5.0.0.0 (pip metadata). `z3.get_version_string()` there returns `5.0.0`, which matches `"z3": "5.0.0"` in `address-check/recorded/address-index-summary.json`. The pin comes from that installed metadata, not from the version string.
- *JDK 21.0.10+7.* This is the version recorded in `impl/PIN.txt`.

The Java dependencies (JavaSMT, Z3 4.13.0 jar and **Linux natives** `libz3.so`/`libz3java.so`) are bundled in `deps/` and need no installation.

The script prints the variables to export:
```
export PATH=~/wev-tools/jdk-21.0.10+7/bin:$PATH
export PYTHON=~/wev-tools/pyenv/bin/python
export ISABELLE_HOME=~/wev-tools/Isabelle2024
```

## 2. Run

```
export WORK=~/wev-work                 # outside the package; refused if inside it, "/", $HOME, or an ancestor of it
bash reproduce/run_all.sh; echo "exit status: $?"
```

Variants:
- `SKIP_ISABELLE=1` (smoke test);
- `RUN_FULL=1` (adds the full Table 2 audit and full six-model reruns of both builds);
- `REQUIRE_ALL=1` (skipped checks count as failures).

Stage-by-stage runtimes measured on this route are in `VERIFICATION-SUMMARY.md`.

## Manual installation (without the script)

- **JDK.** Unpack the JDK tarball anywhere and put its `bin/` first on `PATH`.
- **Isabelle.** Unpack Isabelle and set `ISABELLE_HOME`.
- **Python.** Install the wheel into a virtual environment, for example `python3 -m venv ~/venv && ~/venv/bin/pip install z3-solver==5.0.0.0`, and set `PYTHON=~/venv/bin/python`.
  - The scripts run Python with `-I` (isolated mode), which ignores `PYTHONPATH` and user site-packages. `z3` must therefore be installed in the interpreter's own site-packages, such as a venv.

## Container route

**Files.** `tools/docker/Dockerfile` (Ubuntu 24.04 base) runs the same setup script and then `reproduce/run_all.sh`. The build and run commands are in the file's header.

**Status: TESTED** on 2026-10-19 with Docker Desktop 28.5.1 (Linux engine, WSL2 backend), base `ubuntu:24.04@sha256:68ee2200…`, image about 3.5 GB.
- `docker build` succeeded.
- A `docker run` of the default `run_all.sh` passed all 14 stages, with exit 0 (`VERIFICATION-SUMMARY.md`).
- The first container test failed stage 1 because the image lacked fontconfig and fonts; this was fixed in the Dockerfile.
- `RUN_FULL=1` was not run in the container; it was run natively on Linux and Windows.

**Recommendation for the TACAS VM.** Do not rely on the VM's own JDK unless it is version 21 or later; the classes target Java 21. Use the setup script, which needs only `curl`, `tar` and `python3-venv`.
