# Verification summary (packaging, 2026-10-19)

This file records what was run on this package before the final seal, with the outcomes, including failures and how each was resolved.

Every run below used a **fresh extraction of a sealed candidate ZIP**, with `WORK` outside the package. The final archive's own confirmation runs, which report its SHA-256, are in `VERIFICATION-REPORT.md`. That report accompanies the archive and is not inside it, because it reports the archive's hash.

**Candidates.**

| Candidate | What changed |
|---|---|
| rc1 | — |
| rc2 | WORK-guard fix; pinned Docker base |
| rc3 | line-ending-aware comparisons; measured runtimes in the docs |
| final | Docker fonts; install notes; this file |

Between rc1 and final only those files changed: the reproduction scripts `common.sh`, `03_chain.sh` and `07_provenance.py`, and documentation. Expensive checks that passed earlier were not repeated unless a later change could affect them.

## Clean-extraction runs of `reproduce/run_all.sh`

| Candidate / platform | Mode | Result | Wall clock |
|---|---|---|---|
| rc1 / Windows 11 x64, Git Bash, Temurin 21.0.10, Python 3.11.9 + z3-solver 5.0.0.0, Isabelle2024 | `RUN_FULL=1` | **14/14 stages PASS, exit 0** | 2,545 s |
| rc2 / Ubuntu 24.04.1 (WSL2), toolchain from `tools/setup-linux-toolchain.sh`: Temurin 21.0.10+7, Python 3.12.3 + z3-solver 5.0.0.0, Isabelle2024 | `RUN_FULL=1` | 11/14 PASS, **3 FAIL, exit 1** (see below) | 1,542 s |
| rc3 / same Linux | default | **14/14 PASS, exit 0** | 455 s |
| rc3 / Docker 28.5.1, image from `tools/docker/Dockerfile` | default | 13/14 PASS, **stage 1 FAIL, exit 1** (see below) | 453 s |
| rc3 + Docker fix / Docker | stage 1 alone | PASS (both sessions Finished) | 25 s |

**The rc2 Linux failures, and how they were resolved.**
- Stages 3/3c (4 checks) and 7 (8 checks) compared regenerated files byte-for-byte with recorded files. The recorded files were produced on Windows, where Java `println` and Python text mode write CRLF.
- All 12 regenerated Linux files were confirmed **identical except for line endings**: 0 CR characters against N, with identical content after CR removal.
- From rc3 on, those comparisons accept exactly that case and say so explicitly on the PASS line ("identical modulo line endings (CRLF vs LF only)"). Windows comparisons remain byte-exact.

**The Docker failure, and how it was resolved.** Isabelle needs fontconfig and a font ("Fontconfig head is null"). The Dockerfile now installs `fontconfig fonts-dejavu-core`, and `INSTALL-LINUX.md` lists the requirement.

## Key results (identical on Windows and Linux)

| Check | Outcome |
|---|---|
| Stage 0 | every file matches `SHA256SUMS` (14,929 files) |
| Isabelle (stage 1) | WEV_SMT and WEV_SMT_PwT build clean; no `sorry`/`oops`; the user directory is isolated in `WORK` |
| Submitted build pins (stage 4) | a fresh `javac` build reproduces `86f06894…` on **both** Windows and Linux; all 12,324 corpus hashes; historical wired table byte-identical; 30-file subset |
| Corrected build (stage 8) | pins `1f5d7d56…` / `abf33814…`; a fresh build reproduces them on both platforms; the change is confined to 2 sources and 3 class files; F-01 probes: submitted `FFFFFF`, corrected `FFAAAA` on 2+2W+rfis; corrected 33-file subset; model jar: 19/19 classes recompile from `impl/deps/model-source` |
| Unit and regression tests (stage 9) | submitted 123/123; corrected 140/140; the 17 regression tests on the submitted build fail in exactly the 7 defect-specific tests and pass the other 10 |
| Six-model results (stage 10, full rerun on Windows rc1 and Linux rc2) | submitted rerun = authoritative on 14,376/14,376 cells; corrected rerun = `results/corrected-v1` on 14,376/14,376 cells. Submitted vs corrected: **exactly 12 cells**, 3 files × PSO/RA/WEAKEST/RC11, all FORBIDDEN→ALLOWED. Totals as in `CORRECTION-NOTICE.md`. SC/TSO identical; implications 0; 187/0; wired 847 table identical; wired ablation CSV byte-identical under both builds (6/370); recorded herd7 rows 1,772/1,772 and 101/101 (herd7 not re-run). Symbolic reruns: 217 s / 209 s (Windows) |
| Table 2 (stage 6 full, both builds) | 3,656 rows byte-identical to `repair/symbolic-ring-audit.csv`. Solver run 544 s / 540 s (Windows) and 341 s / 299 s (Linux) |
| Reference checker (stage 11) | re-run equals the packaged reference output; = corrected on 14,376/14,376 cells; differs from submitted in exactly the 12 cells. 111 s (Windows), 92 s (Linux) |
| Claims (stage 5) | part 1: 31/31 claims agree with submitted rows (26 recomputed, 3 summary, 2 presence); part 2: 10/10 corrected figures |
| Chain (stages 3/3c) | both builds: deterministic outputs identical (modulo line endings on Linux), 171 real pairs execution-confirmed, no closure-FAKE/composed-REAL |
| Provenance (stage 7) | gates, eligibility, freeze (manifest `ae011be3…`), Table 2 partition, address check 202/202, controls 18/18, parser dumps |

## Failure-handling tests of `run_all.sh` (disposable copies of rc1)

| Test | Expected | Observed |
|---|---|---|
| `SKIP_ISABELLE=1 SKIP_JAVA=1` | exit 0; skipped stages SKIPPED or PARTIAL, never PASS | exit 0; 7 SKIPPED, 3 PARTIAL, 4 PASS; "RESULT: no failures, but 10 stage(s) SKIPPED or PARTIAL -- those checks did NOT run" |
| same with `REQUIRE_ALL=1` | non-zero | exit 1 |
| one corpus byte appended | stage 0 FAIL, non-zero | stage 0 FAIL; stage 7 FAIL as well (the gates see the changed file); exit 1 |
| stage 2 replaced by `exit 0` | FAIL ("nothing was checked") | FAIL, "exit 0 but no PASS line" |
| stage 5 raises an exception inside the `tee` pipeline | FAIL via `PIPESTATUS` | FAIL, exit 1 |
| `WORK` = package, inside package, package parent, `/`, `$HOME` | refused, exit 2, nothing created | all refused with exit 2. rc1 created the in-package directory before refusing; **fixed in rc2** (`realpath -m`, create only after the checks) and re-tested: nothing created |
| standalone `00_manifest.sh` on the corrupted copy | non-zero | exit 1 |

The 2026-10-12 `run_all.sh` always exited 0 (audit F-03).

## Other observations

- **Timing-dependent unit test.** `CorpusValidationManifestTest#exhaustedBudgetYieldsTimeoutRowsForEveryEntryAndModel` is pre-existing and identical in both snapshots. It failed once during a development run while the machine was heavily loaded, and failed 0/15 times when run alone. Stage 9 re-runs it once if it is the only failure, and reports that on a NOTE line. No retry was needed in the runs above.
- **Windows path length.** The deepest archive path has 183 characters. Extracting under an 80-character directory failed on Windows (`MAX_PATH`); extract to a short path (`INSTALL.md`).
- **Cross-platform hashing.** Git Bash's `sha256sum` emits binary-mode lines (`*`), on which the class-aggregate pins depend. The scripts now force `-b`. The 2026-10-12 stage 4 would have failed on Linux for this reason.

## Not run

- herd7 7.58, Dat3M v4.4.1 and DFSan (external tools; recorded rows only).
- The carried experiments.
- `RUN_FULL=1` inside Docker.
- The TACAS 2027 VM: unpublished.
- macOS and ARM.
