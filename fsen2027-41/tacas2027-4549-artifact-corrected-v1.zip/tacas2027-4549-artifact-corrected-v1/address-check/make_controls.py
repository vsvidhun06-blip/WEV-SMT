#!/usr/bin/env python3
"""Build a synthetic control root (same layout as the artifact) with known expected
classifications, to show the checker detects nonzero, load-dependent and unsupported
cases and handles extension/scaling/copy/overwrite/reload exactly.
Usage: python -I make_controls.py <control_root>   (writes expected.csv there)"""
import csv, os, sys
R = sys.argv[1]
C = {
 'init-nonzero':   ('{0:X1=x; 0:X3=4;}', ['STR W0,[X1,X3]'], 'DEMONSTRATED_NONZERO'),
 'load-index':     ('{0:X1=x; 0:X4=y;}', ['LDR W2,[X1]', 'STR W0,[X4,W2,SXTW]'], 'UNRESOLVED'),
 'eor-then-add':   ('{0:X1=x; 0:X4=y;}', ['LDR W0,[X1]', 'EOR W2,W0,W0', 'ADD W2,W2,#1', 'STR W0,[X4,W2,SXTW]'], 'DEMONSTRATED_NONZERO'),
 'overwrite-copy': ('{0:X1=x; 0:X4=y;}', ['LDR W0,[X1]', 'EOR W2,W0,W0', 'MOV W2,W0', 'STR W0,[X4,W2,SXTW]'], 'UNRESOLVED'),
 'reload':         ('{0:X1=x; 0:X4=y;}', ['LDR W0,[X1]', 'EOR W2,W0,W0', 'LDR W2,[X1]', 'STR W0,[X4,W2,SXTW]'], 'UNRESOLVED'),
 'sxtw-low-zero':  ('{0:X1=x; 0:X2=0x100000000;}', ['STR W0,[X1,W2,SXTW]'], 'VERIFIED_ZERO'),
 'x-index-high':   ('{0:X1=x; 0:X2=0x100000000;}', ['STR W0,[X1,X2]'], 'DEMONSTRATED_NONZERO'),
 'lsl-wraps-zero': ('{0:X1=x; 0:X2=0x2000000000000000;}', ['STR W0,[X1,X2,LSL #3]'], 'VERIFIED_ZERO'),
 'lsl-nonzero':    ('{0:X1=x; 0:X2=1;}', ['STR W0,[X1,X2,LSL #3]'], 'DEMONSTRATED_NONZERO'),
 'uxtw-neg':       ('{0:X1=x; 0:W2=-1;}', ['STR W0,[X1,W2,UXTW]'], 'DEMONSTRATED_NONZERO'),
 'address-index':  ('{0:X1=x; 0:X2=y;}', ['STR W0,[X1,X2]'], 'UNRESOLVED'),
 'unsupported':    ('{0:X1=x;}', ['CMP W0,#1', 'STR W0,[X1,W2,SXTW]'], 'UNRESOLVED'),
 'two-loads-eor':  ('{0:X1=x; 0:X4=y;}', ['LDR W0,[X1]', 'LDR W5,[X1]', 'EOR W2,W0,W5', 'STR W0,[X4,W2,SXTW]'], 'UNRESOLVED'),
 'shifted-eor':    ('{0:X1=x; 0:X4=y;}', ['LDR W0,[X1]', 'EOR W2,W0,W0,LSL #1', 'STR W0,[X4,W2,SXTW]'], 'UNRESOLVED'),
 'x-eor-of-wload': ('{0:X1=x; 0:X4=y;}', ['LDR W0,[X1]', 'EOR X2,X0,X0', 'STR W0,[X4,X2]'], 'VERIFIED_ZERO'),
 'copy-of-zero':   ('{0:X1=x; 0:X4=y;}', ['LDR W0,[X1]', 'EOR W2,W0,W0', 'MOV W5,W2', 'STR W0,[X4,W5,SXTW]'], 'VERIFIED_ZERO'),
 'zr-index':       ('{0:X1=x;}', ['STR W0,[X1,WZR,UXTW]'], 'VERIFIED_ZERO'),
 'never-written':  ('{0:X1=x;}', ['STR W0,[X1,W9,SXTW]'], 'VERIFIED_ZERO'),
}
os.makedirs(os.path.join(R, 'corpus/manifests'), exist_ok=True)
os.makedirs(os.path.join(R, 'corpus/litmus/ctrl'), exist_ok=True)
paths = []
for name, (init, ins, _) in C.items():
    p = 'ctrl/%s.litmus' % name
    body = 'AArch64 %s\n%s\n P0 ;\n' % (name, init) + ''.join(' %s ;\n' % i for i in ins) + 'exists (0:X0=0)\n'
    open(os.path.join(R, 'corpus/litmus', p), 'w').write(body)
    paths.append(p)
with open(os.path.join(R, 'corpus/manifests/frozen-population-12324.csv'), 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['path', 'arch']); [w.writerow([p, 'ARM']) for p in paths]
open(os.path.join(R, 'corpus/manifests/frozen-eligible-manifest.csv'), 'w').write('\n'.join(paths) + '\n')
with open(os.path.join(R, 'expected.csv'), 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['file', 'expected']); [w.writerow(['ctrl/%s.litmus' % n, e]) for n, (_, _, e) in C.items()]
