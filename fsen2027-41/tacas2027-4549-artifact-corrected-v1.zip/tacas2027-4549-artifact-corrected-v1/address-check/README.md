# Register-indexed address offsets: exact zero check (new, 2026-10-11)

The encoder resolves every register-indexed access `[Xb, Rm{, ext{ #s}}]` to the location
bound to its base register. The model is therefore faithful only where the effective
offset is identically zero. Neither gate checks this, because both share the abstraction.
This bounded check does, from the original litmus source.

**Scope.** The checker covers every eligible file (frozen manifest, all architectures)
whose program body contains a bracketed memory operand with two or more identifiers. That
is the syntactic test the front end uses to record an index register. Result:
**133 files, 202 accesses, all AArch64**: `[Xn,Wn,SXTW]` ×199, `[Xn,Wn,UXTW]` ×2,
`[Xn,Xn,LSL #n]` ×1. No x86, PPC or C file in the eligible set has an indexed operand.

**Method.** `address_index_check.py` has its own init parser and its own straight-line
64-bit symbolic executor per thread, built on z3 bit-vectors:
- Initialisers: `Wn=v` zero-extends; `Xn=v` and typed values sign-extend; never-written
  registers are 0.
- Register views: W writes zero-extend; W reads take the low 32 bits.
- Loads: each load yields a fresh, unconstrained symbol. This over-approximates every
  loaded value.
- Data operations: MOV, ADD, SUB, EOR, AND, ORR, MVN and NEG, with register or immediate
  operands and LSL/LSR/ASR/SXTW/UXTW/SXTX/UXTX modifiers.
- Writeback: pre-index and post-index writeback make the base register opaque.
- Address registers are opaque and never assumed zero.
- Anything else is rejected, and every later indexed access in that thread is then
  UNRESOLVED.

The offset is `ext(Rm) << s` over 64 bits. Each access is then classified:

- `VERIFIED_ZERO`: `offset != 0` is UNSAT, so the offset is zero for every execution;
- `DEMONSTRATED_NONZERO`: the offset is a load-independent nonzero constant;
- `UNRESOLVED`: SAT but symbol-dependent, or unsupported syntax before the access.

No sampling is used.

**Result** (`recorded/`): 202 VERIFIED_ZERO, 0 DEMONSTRATED_NONZERO, 0 UNRESOLVED.
- 197 indices are self-XORs (`EOR Wk,Wr,Wr`).
- 5 are initialised to 0 (`herd/tests/instructions/AArch64{,.mixed}/` L015, L016,
  M003–M005).

`Dat3M/litmus/AARCH64/TUTO/LB+addrs.litmus` is checked by the same procedure: both threads
have `STR W3,[X4,W2,SXTW]` with `W2` defined by `EOR W2,W0,W0`, so the offset is 0.
Per-access traces are in `recorded/address-index-traces.txt`.

**Controls.** `make_controls.py` builds 18 synthetic files with known answers, covering:
nonzero init, load-derived index, overwrite, reload, copy, SXTW of a value with nonzero
upper bits, LSL wrap-around to zero, nonzero scaling, UXTW of −1, an address in the index
register, two-load XOR, shifted XOR, the zero register, a never-written register and
unsupported syntax. The checker matches all 18 (`recorded/controls/`). Its exit status is
1 if any DEMONSTRATED_NONZERO is found; it is 1 on the controls by design and 0 on the
corpus.

**Run.** Stage F of `reproduce/07_provenance.py`, or directly:
`python -I address_index_check.py <package> <out>` (needs the `z3-solver` Python module;
recorded with z3 5.0.0).

**Limits.** The executor gives 64-bit register semantics only. It does not model memory
contents: it treats every loaded value as arbitrary, which is sound for a zero verdict.
It certifies nothing about other addressing forms. In the extraction gate (`gate.py`), a
nonzero immediate displacement, pre-index writeback or a base register not bound to a plain
location raises `Unmodelled`, which marks the file UNFAITHFUL and so not eligible.
