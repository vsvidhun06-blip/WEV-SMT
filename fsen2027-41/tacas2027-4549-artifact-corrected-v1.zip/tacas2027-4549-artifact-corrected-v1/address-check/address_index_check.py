#!/usr/bin/env python3
"""Exact zero-offset check for register-indexed accesses in the frozen eligible manifest.

Scope (stated, not inferred): every eligible file whose program body contains a bracketed
memory operand with two or more identifiers -- the syntactic criterion the shipped front
end uses to record an index register (LitmusParser.AsmLexicon.memRef / memIndex). The
enumeration is run over all eligible files of every architecture; non-AArch64 hits are
reported and rejected as unsupported (none are expected).

Method (AArch64 only, works from the original litmus source):
  * own init-block parser: Wn=v zero-extends, Xn=v and typed values sign-extend to 64 bits,
    Rn=identifier binds an address; never-written registers are 0 (herd convention);
  * own straight-line 64-bit symbolic executor per thread (z3 bit-vectors):
      - W-destination writes zero-extend the low 32 bits; X-destination writes are 64-bit;
      - W-named source operands read the low 32 bits; WZR/XZR read 0, writes discarded;
      - loads: W/B/H destinations get a fresh zero-extended 32/8/16-bit symbol,
        X destinations a fresh unconstrained 64-bit symbol (an over-approximation of every
        value any execution could load, so UNSAT below is sound for every execution);
      - supported data ops: MOV (reg/imm), ADD, SUB, EOR, AND, ORR, MVN, NEG with register
        or #immediate operands and optional LSL/LSR/ASR #n or SXTW/UXTW/SXTX/UXTX #n
        operand modifiers; DMB/DSB/ISB/NOP are no-ops; stores change no register;
      - address registers are opaque 64-bit symbols (addr_<loc>), never assumed zero;
      - pre-/post-index writeback makes the base register an opaque symbol;
      - anything else (branches, labels, RMW, unknown mnemonics, unknown modifiers)
        raises Unsupported: every later indexed access in that thread is UNRESOLVED.
  * effective offset of [Xb, Rm{, ext{ #s}}]:
      Wm needs UXTW or SXTW (zero/sign-extend to 64), Xm takes LSL/SXTX/UXTX or nothing;
      the offset is ext(Rm) << s over 64 bits.
  * classification by z3 (exact, no sampling):
      VERIFIED_ZERO          offset != 0 is UNSAT over all load values;
      DEMONSTRATED_NONZERO   offset is a load-independent nonzero constant (any execution);
      UNRESOLVED             SAT but load-dependent (feasibility not established), or
                             unsupported syntax before the access.

Usage: python -I address_index_check.py <artifact_root> <out_dir>
Outputs: <out_dir>/address-index-classification.csv, address-index-traces.txt,
         address-index-summary.json
"""
import csv
import json
import os
import re
import sys

import z3

M64 = (1 << 64) - 1


class Unsupported(Exception):
    pass


BR = re.compile(r'\[([^\]]*)\]')
IDENT = re.compile(r'[A-Za-z_]\w*')
GPR = re.compile(r'^([WwXx])(\d{1,2}|[Zz][Rr])$')


def strip_comments(s):
    s = re.sub(r'\(\*.*?\*\)', '', s, flags=re.S)
    return re.sub(r'//[^\n]*', '', s)


def split_sections(src):
    """Return (init_text, body_text) from a litmus source with comments removed."""
    s = strip_comments(src)
    i = s.find('{')
    if i < 0:
        raise Unsupported('no init block')
    depth, j = 0, i
    while j < len(s):
        if s[j] == '{':
            depth += 1
        elif s[j] == '}':
            depth -= 1
            if depth == 0:
                break
        j += 1
    init, body = s[i + 1:j], s[j + 1:]
    k = re.search(r'^\s*(exists|~exists|forall|locations|filter)\b', body, re.M | re.I)
    if k:
        body = body[:k.start()]
    return init, body


def thread_columns(body):
    rows = [l for l in body.splitlines() if ';' in l]
    if not rows:
        raise Unsupported('no thread rows')
    header = [c.strip() for c in rows[0].rstrip().rstrip(';').split('|')]
    if not all(re.fullmatch(r'P\d+', h) for h in header):
        raise Unsupported('unexpected thread header: ' + rows[0])
    cols = {int(h[1:]): [] for h in header}
    order = [int(h[1:]) for h in header]
    for line in rows[1:]:
        cells = line.rstrip().rstrip(';').split('|')
        if len(cells) != len(order):
            raise Unsupported('ragged row: ' + line)
        for t, c in zip(order, cells):
            c = c.strip()
            if c:
                cols[t].append(c)
    return cols


def lit(tok):
    t = tok.strip().lstrip('#').strip()
    neg = t.startswith('-')
    t = t.lstrip('+-').strip()
    v = int(t, 16) if t.lower().startswith('0x') else int(t)
    return (-v if neg else v) & M64


def parse_init(init):
    """Per-thread register init: {thread: {regno: ('val', int64) | ('addr', name)}}."""
    regs = {}
    for stmt in re.split(r'[;\n]', init):
        stmt = stmt.strip()
        if not stmt:
            continue
        m = re.fullmatch(r'(?:([A-Za-z_][\w ]*?)\s+)?(\d+)\s*:\s*([WwXx])(\d{1,2})\s*=\s*(\S+)', stmt)
        if not m:
            continue                          # location declarations / values: not registers
        typ, t, w, n, v = m.groups()
        t, n = int(t), int(n)
        if re.fullmatch(r'-?(0[xX][0-9a-fA-F]+|\d+)', v):
            raw = lit(v)
            if w in 'Ww' and not typ:
                val = raw & 0xFFFFFFFF                     # Wn=v zero-extends
            elif typ and re.fullmatch(r'(u?int32_t|int|unsigned)', typ.strip()):
                x = raw & 0xFFFFFFFF
                val = (x - (1 << 32)) & M64 if (x >> 31) and not typ.strip().startswith(('u', 'unsigned')) else x
            else:
                val = raw                                  # Xn=v / 64-bit types sign-extend
            regs.setdefault(t, {})[n] = ('val', val)
        elif re.fullmatch(r'[A-Za-z_]\w*', v):
            regs.setdefault(t, {})[n] = ('addr', v)
        else:
            raise Unsupported('init value: ' + stmt)
    return regs


class Thread:
    def __init__(self, tid, init, tag):
        self.tid, self.tag = tid, tag
        self.r = {}            # regno -> BitVec64
        self.desc = {}         # regno -> human-readable definition chain
        self.nload = 0
        for n, (k, v) in init.items():
            if k == 'val':
                self.r[n] = z3.BitVecVal(v, 64)
                self.desc[n] = 'init %#x' % v
            else:
                self.r[n] = z3.BitVec('addr_%s' % v, 64)
                self.desc[n] = 'init address of %s' % v

    def reg(self, tok):
        m = GPR.match(tok.strip())
        if not m:
            raise Unsupported('register operand: ' + tok)
        w, n = m.group(1).upper(), m.group(2).upper()
        return w, (None if n == 'ZR' else int(n))

    def read(self, tok):
        w, n = self.reg(tok)
        v = z3.BitVecVal(0, 64) if n is None else self.r.get(n, z3.BitVecVal(0, 64))
        return z3.ZeroExt(32, z3.Extract(31, 0, v)) if w == 'W' else v

    def write(self, tok, val, why):
        w, n = self.reg(tok)
        if n is None:
            return
        self.r[n] = z3.ZeroExt(32, z3.Extract(31, 0, val)) if w == 'W' else val
        self.desc[n] = why

    def operand(self, toks):
        """toks: [reg|#imm] + optional modifier tokens; returns BV64."""
        base = toks[0].strip()
        if base.startswith('#') or re.fullmatch(r'-?(0[xX][0-9a-fA-F]+|\d+)', base):
            v = z3.BitVecVal(lit(base), 64)
            if len(toks) > 1:
                m = re.fullmatch(r'(?i)LSL\s*#?\s*(\d+)', toks[1].strip())
                if not m or len(toks) > 2:
                    raise Unsupported('immediate modifier: ' + ','.join(toks))
                v = v << int(m.group(1))
            return v
        v = self.read(base)
        if len(toks) == 1:
            return v
        if len(toks) > 2:
            raise Unsupported('operand: ' + ','.join(toks))
        return modify(v, base, toks[1])


def modify(v, regtok, mod):
    m = re.fullmatch(r'(?i)(LSL|LSR|ASR|SXTW|UXTW|SXTX|UXTX)\s*(?:#?\s*(\d+))?', mod.strip())
    if not m:
        raise Unsupported('modifier: ' + mod)
    op, amt = m.group(1).upper(), int(m.group(2) or 0)
    if op == 'SXTW':
        v = z3.SignExt(32, z3.Extract(31, 0, v))
        return v << amt
    if op == 'UXTW':
        v = z3.ZeroExt(32, z3.Extract(31, 0, v))
        return v << amt
    if op in ('SXTX', 'UXTX'):
        return v << amt
    if amt == 0 and op != 'LSL':
        return v
    if regtok.strip()[0] in 'Ww':
        lo = z3.Extract(31, 0, v)
        r = {'LSL': lo << amt, 'LSR': z3.LShR(lo, amt), 'ASR': lo >> amt}[op]
        return z3.ZeroExt(32, r)
    return {'LSL': v << amt, 'LSR': z3.LShR(v, amt), 'ASR': v >> amt}[op]


def split_ops(rest):
    out, depth, cur = [], 0, ''
    for ch in rest:
        if ch == '[':
            depth += 1
        elif ch == ']':
            depth -= 1
        if ch == ',' and depth == 0:
            out.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


LOADS = {'LDR': 64, 'LDAR': 64, 'LDAPR': 64, 'LDRB': 8, 'LDRH': 16, 'LDARB': 8, 'LDARH': 16,
         'LDAPRB': 8, 'LDAPRH': 16}
STORES = {'STR', 'STLR', 'STRB', 'STRH', 'STLRB', 'STLRH'}
NOPS = {'DMB', 'DSB', 'ISB', 'NOP'}
BIN = {'ADD': lambda a, b: a + b, 'SUB': lambda a, b: a - b, 'EOR': lambda a, b: a ^ b,
       'AND': lambda a, b: a & b, 'ORR': lambda a, b: a | b}


def mem_operand(th, ops, i):
    """Parse ops[i] as a memory operand; return (index_info or None, writeback)."""
    o = ops[i].strip()
    m = re.fullmatch(r'\[([^\]]*)\]\s*(!?)', o)
    if not m:
        raise Unsupported('memory operand: ' + o)
    parts = [p.strip() for p in m.group(1).split(',')]
    post = i + 1 < len(ops)
    wb = bool(m.group(2)) or post
    base = parts[0]
    th.reg(base)
    if len(parts) == 1:
        return None, wb, base
    if parts[1].startswith('#'):
        return None, wb, base                   # immediate displacement: not indexed
    idx = parts[1]
    w, n = th.reg(idx)
    raw = th.read(idx)
    if len(parts) == 2:
        if w == 'W':
            raise Unsupported('W index without extend: ' + o)
        off = raw
        ext = 'none'
    elif len(parts) == 3:
        mm = re.fullmatch(r'(?i)(LSL|SXTW|UXTW|SXTX|UXTX)\s*(?:#?\s*(\d+))?', parts[2])
        if not mm:
            raise Unsupported('index modifier: ' + o)
        kind = mm.group(1).upper()
        if (w == 'W') != (kind in ('SXTW', 'UXTW')):
            raise Unsupported('index width/extend mismatch: ' + o)
        off = modify(raw, idx, parts[2])
        ext = parts[2]
    else:
        raise Unsupported('memory operand: ' + o)
    return {'index': idx, 'ext': ext, 'offset': off, 'regno': n}, wb, base


def run_thread(th, instrs, sink):
    for k, text in enumerate(instrs):
        t = text.strip()
        if re.match(r'^[A-Za-z_]\w*:', t):
            raise Unsupported('label: ' + t)
        head = t.split(None, 1)
        op = head[0].upper()
        ops = split_ops(head[1]) if len(head) > 1 else []
        if op in NOPS:
            continue
        if op in LOADS or op in STORES:
            if len(ops) < 2:
                raise Unsupported('access: ' + t)
            info, wb, base = mem_operand(th, ops, 1)
            if info is not None:
                sink(k, t, info, th)
            if op in LOADS:
                bits = LOADS[op]
                if bits == 64 and ops[0].strip()[0] in 'Ww':
                    bits = 32
                th.nload += 1
                sym = z3.BitVec('load_T%d_i%d' % (th.tid, k), bits)
                val = z3.ZeroExt(64 - bits, sym) if bits < 64 else sym
                th.write(ops[0], val, 'load #%d: %s' % (k, t))
            if wb:
                th.write(base, z3.BitVec('wb_T%d_i%d' % (th.tid, k), 64), 'writeback: ' + t)
            continue
        if op == 'MOV':
            if len(ops) != 2:
                raise Unsupported(t)
            th.write(ops[0], th.operand([ops[1]]), '#%d %s' % (k, t))
            continue
        if op in ('MVN', 'NEG'):
            if len(ops) not in (2, 3):
                raise Unsupported(t)
            v = th.operand(ops[1:])
            th.write(ops[0], ~v if op == 'MVN' else -v, '#%d %s' % (k, t))
            continue
        if op in BIN:
            if len(ops) not in (3, 4):
                raise Unsupported(t)
            th.write(ops[0], BIN[op](th.read(ops[1]), th.operand(ops[2:])), '#%d %s' % (k, t))
            continue
        raise Unsupported('mnemonic %s: %s' % (op, t))


def classify(off):
    s = z3.Solver()
    s.add(off != 0)
    r = s.check()
    if r == z3.unsat:
        return 'VERIFIED_ZERO', ''
    if r != z3.sat:
        return 'UNRESOLVED', 'solver: ' + str(r)
    simp = z3.simplify(off)
    if z3.is_bv_value(simp) and simp.as_long() != 0:
        return 'DEMONSTRATED_NONZERO', 'constant offset %#x' % simp.as_long()
    return 'UNRESOLVED', 'symbol-dependent (load or address) nonzero model: %s' % s.model()


def main():
    root, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    pop = {r['path']: r for r in csv.DictReader(open(os.path.join(root, 'corpus/manifests/frozen-population-12324.csv'), encoding='utf-8'))}
    elig = [l.strip() for l in open(os.path.join(root, 'corpus/manifests/frozen-eligible-manifest.csv'), encoding='utf-8') if l.strip()]
    rows, traces, files = [], [], set()
    for p in elig:
        src = open(os.path.join(root, 'corpus/litmus', p), encoding='utf-8', errors='replace').read()
        arch = pop[p]['arch']
        try:
            init, body = split_sections(src)
        except Unsupported as e:
            raise SystemExit('cannot split %s: %s' % (p, e))
        hits = [m for m in BR.finditer(body) if len(IDENT.findall(m.group(1))) >= 2]
        if not hits:
            continue
        files.add(p)
        if arch != 'ARM':
            for m in hits:
                rows.append(dict(file=p, arch=arch, thread='', instr='', text=m.group(0), index='', ext='',
                                 status='UNRESOLVED', detail='unsupported architecture', offset=''))
            continue
        cols = thread_columns(body)
        regs = parse_init(init)
        n_hits_seen = 0
        for tid, instrs in sorted(cols.items()):
            th = Thread(tid, regs.get(tid, {}), p)

            def sink(k, t, info, th=th):
                status, detail = classify(info['offset'])
                rows.append(dict(file=p, arch=arch, thread=tid, instr=k, text=t, index=info['index'],
                                 ext=info['ext'], status=status, detail=detail,
                                 offset=str(z3.simplify(info['offset']))))
                traces.append('%s  P%d #%d  %s\n    index %s defined by: %s\n    offset = %s\n    -> %s %s'
                              % (p, tid, k, t, info['index'],
                                 th.desc.get(info['regno'], 'never written (0)') if info['regno'] is not None else 'zero register',
                                 z3.simplify(info['offset']), status, detail))
            try:
                run_thread(th, instrs, sink)
            except Unsupported as e:
                # every remaining indexed access in this thread is unresolved
                done = {(r['thread'], r['instr']) for r in rows if r['file'] == p}
                for k, text in enumerate(instrs):
                    if (tid, k) in done:
                        continue
                    if any(len(IDENT.findall(m.group(1))) >= 2 for m in BR.finditer(text)):
                        rows.append(dict(file=p, arch=arch, thread=tid, instr=k, text=text, index='', ext='',
                                         status='UNRESOLVED', detail='unsupported before access: %s' % e, offset=''))
        n_hits_seen = sum(1 for r in rows if r['file'] == p)
        if n_hits_seen != len(hits):
            raise SystemExit('access count mismatch in %s: %d enumerated vs %d classified' % (p, len(hits), n_hits_seen))
    fields = ['file', 'arch', 'thread', 'instr', 'text', 'index', 'ext', 'offset', 'status', 'detail']
    with open(os.path.join(out, 'address-index-classification.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    open(os.path.join(out, 'address-index-traces.txt'), 'w', encoding='utf-8').write('\n'.join(traces) + '\n')
    summ = {'eligible_files': len(elig), 'files_with_indexed_access': len(files), 'indexed_accesses': len(rows),
            'by_status': {s: sum(r['status'] == s for r in rows) for s in ('VERIFIED_ZERO', 'DEMONSTRATED_NONZERO', 'UNRESOLVED')},
            'by_arch': {a: sum(r['arch'] == a for r in rows) for a in sorted({r['arch'] for r in rows})},
            'z3': z3.get_version_string()}
    json.dump(summ, open(os.path.join(out, 'address-index-summary.json'), 'w'), indent=2)
    print(json.dumps(summ))
    return 1 if summ['by_status']['DEMONSTRATED_NONZERO'] else 0


if __name__ == '__main__':
    sys.exit(main())
