from pathlib import Path
import csv,json,hashlib
import z3
R=Path(__file__).resolve().parent
funcs={
'cancel_add':lambda x:(x+1)-x,
'cancel_xor':lambda x:(x^7)^x,
'cancel_copy':lambda x:x-x,
'mask_chain':lambda x:(x&1)&2,
'zero_register':lambda x:x*0,
'inject_add':lambda x:x+1,
'inject_mix':lambda x:(x*3^7)+5,
'retained_mask':lambda x:x&1}
a,b=z3.BitVecs('a b',32);ref={}
for n,f in funcs.items():
 s=z3.Solver();s.set(timeout=5000);s.add(f(a)!=f(b));v=s.check()
 assert v!=z3.unknown
 ref[n]=str(v);assert (v==z3.unsat)==(n in list(funcs)[:5])
for level in ['O0','O2']:
 rows=list(csv.DictReader((R/f'dfsan-{level}.csv').open(newline='')))
 assert len(rows)==32
 for r in rows:
  n=r['name'];x=int(r['input']);actual=int(r['output'])
  expect=z3.simplify(funcs[n](z3.BitVecVal(x,32))).as_long()
  assert actual==expect,(n,x,actual,expect)
  expected_label=1 if level=='O0' or ref[n]=='sat' else 0
  assert int(r['label'])==expected_label,(level,r)
(R/'dfsan-validation.json').write_text(json.dumps({'reference':ref,'rows_per_level':32,'all_values_and_labels_checked':True},indent=2))
print('DFSan validation PASS: 8 universal BV32 reference checks, 64 observed value/tag checks')
