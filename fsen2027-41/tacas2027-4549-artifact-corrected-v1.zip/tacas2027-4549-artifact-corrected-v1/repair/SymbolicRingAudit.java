import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import org.sosy_lab.common.ShutdownNotifier;
import org.sosy_lab.common.configuration.Configuration;
import org.sosy_lab.common.log.*;
import org.sosy_lab.java_smt.SolverContextFactory;
import org.sosy_lab.java_smt.SolverContextFactory.Solvers;
import org.sosy_lab.java_smt.api.*;
import wev.smt.*;
import wev.smt.parse.*;
public class SymbolicRingAudit {
 static String src(String expr,int n) {
  StringBuilder b=new StringBuilder("C AUDIT\n{ }\n");
  for(int i=0;i<n;i++) b.append(i==0?" P":" | P").append(i);
  b.append(" ;\n");
  for(int i=0;i<n;i++) b.append(i==0?" ":" | ").append("r").append(i).append(" = READ_ONCE(*x").append(i).append(")");
  b.append(" ;\n");
  for(int i=0;i<n;i++) b.append(i==0?" ":" | ").append("WRITE_ONCE(*x").append((i+1)%n).append(", ").append(expr.replace("r","r"+i)).append(")");
  b.append(" ;\nexists (");
  for(int i=0;i<n;i++) b.append(i==0?"":" /\\ ").append(i).append(":r").append(i).append("=1");
  return b.append(")\n").toString();
 }
 static DependencyInfo all(DependencyInfo d) {
  DependencyInfo x=new DependencyInfo();
  for(var k:d.allEdges()) switch(k.kind()){
   case DATA -> x.addDataDep(k.edge().consumer(),k.edge().producer(),true);
   case ADDR -> x.addAddrDep(k.edge().consumer(),k.edge().producer(),true);
   case CTRL -> x.addCtrlDep(k.edge().consumer(),k.edge().producer(),true);
  }
  return x;
 }
 static String[] solve(SolverContext ctx,LitmusCase c,DependencyInfo d) throws Exception {
  var enc=new EventStructureEncoder(ctx,c.es(),d);
  enc.enableSymbolic(c.writeValueExprs(),c.existsReadValues(),c.existsMemFinal());
  var wf=enc.encodeWellFormedness();
  var ax=new AxiomaticConsistency(enc);
  boolean base,full;
  try(var p=ctx.newProverEnvironment()){p.addConstraint(wf);base=!p.isUnsat();}
  try(var p=ctx.newProverEnvironment()){p.addConstraint(ctx.getFormulaManager().getBooleanFormulaManager().and(wf,ax.consistencyWEAKEST()));full=!p.isUnsat();}
  return new String[]{base?"SAT":"UNSAT",full?"ALLOWED":"FORBIDDEN"};
 }
 public static void main(String[] args)throws Exception{
  var m=Pattern.compile("\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(Files.readString(Path.of(args[0])));
  List<String> es=new ArrayList<>();while(m.find())es.add(m.group(1));
  var cfg=Configuration.defaultConfiguration();var log=BasicLogManager.create(cfg);
  try(var ctx=SolverContextFactory.createSolverContext(cfg,log,ShutdownNotifier.createDummy(),Solvers.Z3);
      var oracle=new QfbvConstancyOracle();
      var w=Files.newBufferedWriter(Path.of(args[1]))){
   w.write("expr,threads,oracle_constant,value_consistency,weakest,folding,syntactic\n");
   int i=0;
   for(String e:es){
    Boolean constant=oracle.isConstant(e.replace("r","r0"),"r0");
    if(constant==null)throw new IllegalStateException("unsupported:"+e);
    for(int n=2;n<=3;n++){
     String s=src(e,n); LitmusCase o,f;
     LitmusParser.CONSTANCY_ORACLE=oracle;
     try{o=LitmusParser.parse(s,"audit.litmus");}finally{LitmusParser.CONSTANCY_ORACLE=null;}
     f=LitmusParser.parse(s,"audit.litmus");
     if(o.existsReadValues().size()!=n)throw new IllegalStateException("missing outcome pins");
     var a=solve(ctx,o,o.deps());var b=solve(ctx,f,f.deps());var c=solve(ctx,o,all(o.deps()));
     if(!a[0].equals(b[0])||!a[0].equals(c[0]))throw new IllegalStateException("WF mismatch");
     w.write("\""+e+"\","+n+","+constant+","+a[0]+","+a[1]+","+b[1]+","+c[1]+"\n");
    }
    if(++i%200==0){w.flush();System.out.println("expressions "+i+"/"+es.size());}
   }
  }
 }
}