; ModuleID = 'dfsan_cases.c'
source_filename = "dfsan_cases.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@__const.main.fs = private unnamed_addr constant [8 x ptr] [ptr @cancel_add.dfsan, ptr @cancel_xor.dfsan, ptr @cancel_copy.dfsan, ptr @mask_chain.dfsan, ptr @zero_register.dfsan, ptr @inject_add.dfsan, ptr @inject_mix.dfsan, ptr @retained_mask.dfsan], align 16
@.str = private unnamed_addr constant [11 x i8] c"cancel_add\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"cancel_xor\00", align 1
@.str.2 = private unnamed_addr constant [12 x i8] c"cancel_copy\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"mask_chain\00", align 1
@.str.4 = private unnamed_addr constant [14 x i8] c"zero_register\00", align 1
@.str.5 = private unnamed_addr constant [11 x i8] c"inject_add\00", align 1
@.str.6 = private unnamed_addr constant [11 x i8] c"inject_mix\00", align 1
@.str.7 = private unnamed_addr constant [14 x i8] c"retained_mask\00", align 1
@__const.main.ns = private unnamed_addr constant [8 x ptr] [ptr @.str, ptr @.str.1, ptr @.str.2, ptr @.str.3, ptr @.str.4, ptr @.str.5, ptr @.str.6, ptr @.str.7], align 16
@__const.main.inputs = private unnamed_addr constant [4 x i32] [i32 0, i32 1, i32 2, i32 -1], align 16
@.str.8 = private unnamed_addr constant [24 x i8] c"name,input,output,label\00", align 1
@.str.9 = private unnamed_addr constant [13 x i8] c"%s,%u,%u,%u\0A\00", align 1
@__dfsan_arg_tls = external thread_local(initialexec) global [100 x i64]
@__dfsan_retval_tls = external thread_local(initialexec) global [100 x i64]
@__dfsan_arg_origin_tls = external thread_local(initialexec) global [200 x i32]
@__dfsan_retval_origin_tls = external thread_local(initialexec) global i32
@__dfsan_track_origins = weak_odr constant i32 0
@0 = private unnamed_addr constant [7 x i8] c"printf\00", align 1

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @cancel_add.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  %5 = alloca i8, align 1
  %6 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  %7 = load i8, ptr %3, align 1
  %8 = load i32, ptr %4, align 4
  %9 = add i32 %8, 1
  store i8 %7, ptr %5, align 1
  store i32 %9, ptr %6, align 4
  %10 = load i8, ptr %5, align 1
  %11 = load i32, ptr %6, align 4
  %12 = load i8, ptr %3, align 1
  %13 = load i32, ptr %4, align 4
  %14 = or i8 %10, %12
  %15 = sub i32 %11, %13
  store i8 %14, ptr @__dfsan_retval_tls, align 2
  ret i32 %15
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @cancel_xor.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  %5 = alloca i8, align 1
  %6 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  %7 = load i8, ptr %3, align 1
  %8 = load i32, ptr %4, align 4
  %9 = xor i32 %8, 7
  store i8 %7, ptr %5, align 1
  store i32 %9, ptr %6, align 4
  %10 = load i8, ptr %5, align 1
  %11 = load i32, ptr %6, align 4
  %12 = load i8, ptr %3, align 1
  %13 = load i32, ptr %4, align 4
  %14 = or i8 %10, %12
  %15 = xor i32 %11, %13
  store i8 %14, ptr @__dfsan_retval_tls, align 2
  ret i32 %15
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @cancel_copy.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  %5 = alloca i8, align 1
  %6 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  %7 = load i8, ptr %3, align 1
  %8 = load i32, ptr %4, align 4
  store i8 %7, ptr %5, align 1
  store i32 %8, ptr %6, align 4
  %9 = load i8, ptr %5, align 1
  %10 = load i32, ptr %6, align 4
  %11 = load i8, ptr %3, align 1
  %12 = load i32, ptr %4, align 4
  %13 = or i8 %9, %11
  %14 = sub i32 %10, %12
  store i8 %13, ptr @__dfsan_retval_tls, align 2
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @mask_chain.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  %5 = alloca i8, align 1
  %6 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  %7 = load i8, ptr %3, align 1
  %8 = load i32, ptr %4, align 4
  %9 = and i32 %8, 1
  store i8 %7, ptr %5, align 1
  store i32 %9, ptr %6, align 4
  %10 = load i8, ptr %5, align 1
  %11 = load i32, ptr %6, align 4
  %12 = and i32 %11, 2
  store i8 %10, ptr @__dfsan_retval_tls, align 2
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @zero_register.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  %5 = alloca i8, align 1
  %6 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  store i8 0, ptr %5, align 1
  store i32 0, ptr %6, align 4
  %7 = load i8, ptr %3, align 1
  %8 = load i32, ptr %4, align 4
  %9 = load i8, ptr %5, align 1
  %10 = load i32, ptr %6, align 4
  %11 = or i8 %7, %9
  %12 = mul i32 %8, %10
  store i8 %11, ptr @__dfsan_retval_tls, align 2
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @inject_add.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  %5 = load i8, ptr %3, align 1
  %6 = load i32, ptr %4, align 4
  %7 = add i32 %6, 1
  store i8 %5, ptr @__dfsan_retval_tls, align 2
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @inject_mix.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  %5 = alloca i8, align 1
  %6 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  %7 = load i8, ptr %3, align 1
  %8 = load i32, ptr %4, align 4
  %9 = mul i32 %8, 3
  store i8 %7, ptr %5, align 1
  store i32 %9, ptr %6, align 4
  %10 = load i8, ptr %5, align 1
  %11 = load i32, ptr %6, align 4
  %12 = xor i32 %11, 7
  %13 = add i32 %12, 5
  store i8 %10, ptr @__dfsan_retval_tls, align 2
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @retained_mask.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = alloca i8, align 1
  %4 = alloca i32, align 4
  store i8 %2, ptr %3, align 1
  store i32 %0, ptr %4, align 4
  %5 = load i8, ptr %3, align 1
  %6 = load i32, ptr %4, align 4
  %7 = and i32 %6, 1
  store i8 %5, ptr @__dfsan_retval_tls, align 2
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i8, align 1
  %2 = alloca i8, align 1
  %3 = alloca i32, align 4
  %4 = alloca [8 x ptr], align 16
  %5 = alloca [8 x ptr], align 16
  %6 = alloca [4 x i32], align 16
  %7 = alloca i8, align 1
  %8 = alloca i32, align 4
  %9 = alloca i8, align 1
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i8, align 1
  %13 = alloca i32, align 4
  %14 = alloca i8, align 1
  %15 = alloca i8, align 1
  store i8 0, ptr %2, align 1
  store i32 0, ptr %3, align 4
  %16 = ptrtoint ptr %4 to i64
  %17 = xor i64 %16, 87960930222080
  %18 = inttoptr i64 %17 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %18, ptr align 1 inttoptr (i64 xor (i64 ptrtoint (ptr @__const.main.fs to i64), i64 87960930222080) to ptr), i64 64, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %4, ptr align 16 @__const.main.fs, i64 64, i1 false)
  %19 = ptrtoint ptr %5 to i64
  %20 = xor i64 %19, 87960930222080
  %21 = inttoptr i64 %20 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %21, ptr align 1 inttoptr (i64 xor (i64 ptrtoint (ptr @__const.main.ns to i64), i64 87960930222080) to ptr), i64 64, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %5, ptr align 16 @__const.main.ns, i64 64, i1 false)
  %22 = ptrtoint ptr %6 to i64
  %23 = xor i64 %22, 87960930222080
  %24 = inttoptr i64 %23 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %24, ptr align 1 inttoptr (i64 xor (i64 ptrtoint (ptr @__const.main.inputs to i64), i64 87960930222080) to ptr), i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @__const.main.inputs, i64 16, i1 false)
  %25 = call i32 @puts(ptr noundef @.str.8)
  store i8 0, ptr %7, align 1
  store i32 0, ptr %8, align 4
  br label %26

26:                                               ; preds = %130, %0
  %27 = load i8, ptr %7, align 1
  %28 = load i32, ptr %8, align 4
  %29 = icmp ult i32 %28, 8
  br i1 %29, label %30, label %134

30:                                               ; preds = %26
  store i8 0, ptr %9, align 1
  store i32 0, ptr %10, align 4
  br label %31

31:                                               ; preds = %125, %30
  %32 = load i8, ptr %9, align 1
  %33 = load i32, ptr %10, align 4
  %34 = icmp ult i32 %33, 4
  br i1 %34, label %35, label %129

35:                                               ; preds = %31
  %36 = load i8, ptr %9, align 1
  %37 = load i32, ptr %10, align 4
  %38 = zext i32 %37 to i64
  %39 = getelementptr inbounds [4 x i32], ptr %6, i64 0, i64 %38
  %40 = ptrtoint ptr %39 to i64
  %41 = xor i64 %40, 87960930222080
  %42 = inttoptr i64 %41 to ptr
  %43 = load i32, ptr %42, align 1
  %44 = lshr i32 %43, 16
  %45 = or i32 %43, %44
  %46 = lshr i32 %45, 8
  %47 = or i32 %45, %46
  %48 = trunc i32 %47 to i8
  %49 = or i8 %48, %36
  %50 = load i32, ptr %39, align 4
  %51 = ptrtoint ptr %11 to i64
  %52 = xor i64 %51, 87960930222080
  %53 = inttoptr i64 %52 to ptr
  %54 = getelementptr i8, ptr %53, i32 0
  store i8 %49, ptr %54, align 1
  %55 = getelementptr i8, ptr %53, i32 1
  store i8 %49, ptr %55, align 1
  %56 = getelementptr i8, ptr %53, i32 2
  store i8 %49, ptr %56, align 1
  %57 = getelementptr i8, ptr %53, i32 3
  store i8 %49, ptr %57, align 1
  store i32 %50, ptr %11, align 4
  call void @dfsan_set_label(i8 noundef zeroext 1, ptr noundef %11, i64 noundef 4)
  %58 = load i8, ptr %7, align 1
  %59 = load i32, ptr %8, align 4
  %60 = zext i32 %59 to i64
  %61 = getelementptr inbounds [8 x ptr], ptr %4, i64 0, i64 %60
  %62 = ptrtoint ptr %61 to i64
  %63 = xor i64 %62, 87960930222080
  %64 = inttoptr i64 %63 to ptr
  %65 = load i64, ptr %64, align 1
  %66 = lshr i64 %65, 32
  %67 = or i64 %65, %66
  %68 = lshr i64 %67, 16
  %69 = or i64 %67, %68
  %70 = lshr i64 %69, 8
  %71 = or i64 %69, %70
  %72 = trunc i64 %71 to i8
  %73 = or i8 %72, %58
  %74 = load ptr, ptr %61, align 8
  %75 = ptrtoint ptr %11 to i64
  %76 = xor i64 %75, 87960930222080
  %77 = inttoptr i64 %76 to ptr
  %78 = load i32, ptr %77, align 1
  %79 = lshr i32 %78, 16
  %80 = or i32 %78, %79
  %81 = lshr i32 %80, 8
  %82 = or i32 %80, %81
  %83 = trunc i32 %82 to i8
  %84 = load i32, ptr %11, align 4
  store i8 %83, ptr @__dfsan_arg_tls, align 2
  %85 = call i32 %74(i32 noundef %84)
  %86 = load i8, ptr @__dfsan_retval_tls, align 2
  store i8 %86, ptr %12, align 1
  store i32 %85, ptr %13, align 4
  %87 = load i8, ptr %12, align 1
  %88 = load i32, ptr %13, align 4
  %89 = zext i32 %88 to i64
  %90 = call zeroext i8 @__dfsw_dfsan_get_label(i64 noundef %89, i8 zeroext %87, ptr %1)
  %91 = load i8, ptr %1, align 1
  store i8 %91, ptr %14, align 1
  store i8 %90, ptr %15, align 1
  %92 = load i8, ptr %7, align 1
  %93 = load i32, ptr %8, align 4
  %94 = zext i32 %93 to i64
  %95 = getelementptr inbounds [8 x ptr], ptr %5, i64 0, i64 %94
  %96 = ptrtoint ptr %95 to i64
  %97 = xor i64 %96, 87960930222080
  %98 = inttoptr i64 %97 to ptr
  %99 = load i64, ptr %98, align 1
  %100 = lshr i64 %99, 32
  %101 = or i64 %99, %100
  %102 = lshr i64 %101, 16
  %103 = or i64 %101, %102
  %104 = lshr i64 %103, 8
  %105 = or i64 %103, %104
  %106 = trunc i64 %105 to i8
  %107 = or i8 %106, %92
  %108 = load ptr, ptr %95, align 8
  %109 = ptrtoint ptr %11 to i64
  %110 = xor i64 %109, 87960930222080
  %111 = inttoptr i64 %110 to ptr
  %112 = load i32, ptr %111, align 1
  %113 = lshr i32 %112, 16
  %114 = or i32 %112, %113
  %115 = lshr i32 %114, 8
  %116 = or i32 %114, %115
  %117 = trunc i32 %116 to i8
  %118 = load i32, ptr %11, align 4
  %119 = load i8, ptr %12, align 1
  %120 = load i32, ptr %13, align 4
  %121 = load i8, ptr %14, align 1
  %122 = load i8, ptr %15, align 1
  %123 = zext i8 %122 to i32
  %124 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef %108, i32 noundef %118, i32 noundef %120, i32 noundef %123)
  br label %125

125:                                              ; preds = %35
  %126 = load i8, ptr %9, align 1
  %127 = load i32, ptr %10, align 4
  %128 = add i32 %127, 1
  store i8 %126, ptr %9, align 1
  store i32 %128, ptr %10, align 4
  br label %31, !llvm.loop !6

129:                                              ; preds = %31
  br label %130

130:                                              ; preds = %129
  %131 = load i8, ptr %7, align 1
  %132 = load i32, ptr %8, align 4
  %133 = add i32 %132, 1
  store i8 %131, ptr %7, align 1
  store i32 %133, ptr %8, align 4
  br label %26, !llvm.loop !8

134:                                              ; preds = %26
  ret i32 0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #1

declare i32 @puts(ptr noundef) #2

declare void @dfsan_set_label(i8 noundef zeroext, ptr noundef, i64 noundef) #2

declare zeroext i8 @dfsan_get_label(i64 noundef) #2

declare i32 @printf(ptr noundef, ...) #2

declare void @__dfsan_load_callback(i8 zeroext, ptr)

declare void @__dfsan_store_callback(i8 zeroext, ptr)

declare void @__dfsan_mem_transfer_callback(ptr, i64)

declare void @__dfsan_cmp_callback(i8 zeroext)

declare void @__dfsan_conditional_callback(i8 zeroext)

declare void @__dfsan_conditional_callback_origin(i8 zeroext, i32)

declare void @__dfsan_reaches_function_callback(i8 zeroext, ptr, i32, ptr)

declare void @__dfsan_reaches_function_callback_origin(i8 zeroext, i32, ptr, i32, ptr)

; Function Attrs: nounwind memory(read)
declare zeroext i8 @__dfsan_union_load(ptr, i64) #3

; Function Attrs: nounwind memory(read)
declare zeroext i64 @__dfsan_load_label_and_origin(ptr, i64) #3

declare void @__dfsan_unimplemented(ptr)

declare void @__dfsan_wrapper_extern_weak_null(ptr, ptr)

declare void @__dfsan_set_label(i8 zeroext, i32 zeroext, ptr, i64)

declare void @__dfsan_nonzero_label()

declare void @__dfsan_vararg_wrapper(ptr)

declare zeroext i32 @__dfsan_chain_origin(i32 zeroext)

declare zeroext i32 @__dfsan_chain_origin_if_tainted(i8 zeroext, i32 zeroext)

declare void @__dfsan_mem_origin_transfer(ptr, ptr, i64)

declare void @__dfsan_mem_shadow_origin_transfer(ptr, ptr, i64)

declare void @__dfsan_mem_shadow_origin_conditional_exchange(i8, ptr, ptr, ptr, i64)

declare void @__dfsan_maybe_store_origin(i8 zeroext, ptr, i64, i32 zeroext)

; Function Attrs: noinline nounwind optnone uwtable
define linkonce_odr dso_local i32 @"dfsw$main"() #0 {
  %1 = call i32 @main()
  store i8 0, ptr @__dfsan_retval_tls, align 2
  ret i32 %1
}

define linkonce_odr i32 @"dfsw$puts"(ptr noundef %0) #2 {
  %2 = call i32 @puts(ptr %0)
  store i8 0, ptr @__dfsan_retval_tls, align 2
  ret i32 %2
}

define linkonce_odr void @"dfsw$dfsan_set_label"(i8 noundef zeroext %0, ptr noundef %1, i64 noundef %2) #2 {
  call void @dfsan_set_label(i8 %0, ptr %1, i64 %2)
  ret void
}

define linkonce_odr zeroext i8 @"dfsw$dfsan_get_label"(i64 noundef %0) #2 {
  %2 = alloca i8, align 1
  %3 = load i8, ptr @__dfsan_arg_tls, align 2
  %4 = call i8 @__dfsw_dfsan_get_label(i64 %0, i8 zeroext %3, ptr %2)
  %5 = load i8, ptr %2, align 1
  store i8 %5, ptr @__dfsan_retval_tls, align 2
  ret i8 %4
}

define linkonce_odr i32 @"dfsw$printf"(ptr noundef %0, ...) #2 {
  call void @__dfsan_vararg_wrapper(ptr @0)
  unreachable
}

declare zeroext i8 @__dfsw_dfsan_get_label(i64 noundef, i8, ptr) #2

attributes #0 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind memory(read) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
