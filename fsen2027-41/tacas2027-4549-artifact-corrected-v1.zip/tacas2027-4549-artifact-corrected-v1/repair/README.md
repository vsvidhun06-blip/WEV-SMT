# Repair supplement: symbolic benchmark and external label propagation

This supplement accompanies the corrected manuscript. It does not replace the
pinned implementation or the original generated input list.

## Benchmark correction
The 3,656 original wired ring results are historical. The all-ones source outcome
also requires e(1)=1, not merely the recorded e(0)=1 filter.
The symbolic audit checks well-formedness/value consistency independently of the
dependency treatment, then checks all three treatments using the pinned classes.
There are 1,288 value-consistent instances and 2,368 impossible outcomes.
The comparable matrices are:
- exact: TP 220, TN 1068, FP 0, FN 0;
- folding: TP 220, TN 298, FP 770, FN 0;
- all dependencies: TP 220, TN 0, FP 1068, FN 0.

Run reproduce/06_repair.py to rerun the symbolic audit; it needs the already
documented JDK 21 and pinned Maven-layout dependencies. No downloads occur.
The script writes only to WORK (default: a sibling external work directory).
Historical wired reproduction is still a regression check, not the current table.

## External-tool check
The eight constructed unsigned-BV32 functions in dfsan_cases.c are independent
small controls, not mined programs. Five are constant and three depend on input.
Under the installed clang 18.1.3 DFSan runtime:
- O0: input tag retained on all eight functions;
- O2: constants are optimized away and untagged; dependent controls stay tagged.
All 64 observed values and tags were checked. Independent Z3 formulas check
the reference over all BV32 values. This demonstrates a conservative union-label
mechanism and the importance of prior optimization. It is not a DFSan defect,
a proof about DFSan's implementation, or practical-frequency evidence.

To repeat this optional external check, use clang-18 on Linux:
  clang-18 -O0 -fsanitize=dataflow -fno-pie -no-pie dfsan_cases.c -o dfsan-O0
  ./dfsan-O0 > dfsan-O0.csv
  clang-18 -O2 -fsanitize=dataflow -fno-pie -no-pie dfsan_cases.c -o dfsan-O2
  ./dfsan-O2 > dfsan-O2.csv
Then run validate_dfsan.py in the output directory alongside both CSV files.

The reviewed documentation is:
https://clang.llvm.org/docs/DataFlowSanitizerDesign.html
https://etaps.org/2027/cfp/
The TACAS 2027 CFP permits 18 main pages plus an optional appendix, excluding
bibliography. The paper is not a claim to solving general thin air.

## Remaining limitations
The external example and chain population are constructed. No naturally
occurring nonlinear discriminator is added. Control beyond F0, compilation
correctness and the significance/novelty assessment remain unresolved.
The original artifact's setup and carried-result limitations still apply.
