; ModuleID = 'dfsan_cases.c'
source_filename = "dfsan_cases.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@__const.main.fs = private unnamed_addr constant [8 x ptr] [ptr @cancel_add.dfsan, ptr @cancel_xor.dfsan, ptr @cancel_copy.dfsan, ptr @mask_chain.dfsan, ptr @zero_register.dfsan, ptr @inject_add.dfsan, ptr @inject_mix.dfsan, ptr @retained_mask.dfsan], align 16
@.str = private unnamed_addr constant [11 x i8] c"cancel_add\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"cancel_xor\00", align 1
@.str.2 = private unnamed_addr constant [12 x i8] c"cancel_copy\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"mask_chain\00", align 1
@.str.4 = private unnamed_addr constant [14 x i8] c"zero_register\00", align 1
@.str.5 = private unnamed_addr constant [11 x i8] c"inject_add\00", align 1
@.str.6 = private unnamed_addr constant [11 x i8] c"inject_mix\00", align 1
@.str.7 = private unnamed_addr constant [14 x i8] c"retained_mask\00", align 1
@__const.main.ns = private unnamed_addr constant [8 x ptr] [ptr @.str, ptr @.str.1, ptr @.str.2, ptr @.str.3, ptr @.str.4, ptr @.str.5, ptr @.str.6, ptr @.str.7], align 16
@.str.8 = private unnamed_addr constant [24 x i8] c"name,input,output,label\00", align 1
@.str.9 = private unnamed_addr constant [13 x i8] c"%s,%u,%u,%u\0A\00", align 1
@__dfsan_arg_tls = external thread_local(initialexec) global [100 x i64]
@__dfsan_retval_tls = external thread_local(initialexec) global [100 x i64]
@__dfsan_track_origins = weak_odr constant i32 0

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @cancel_add.dfsan(i32 %0) #0 {
  store i8 0, ptr @__dfsan_retval_tls, align 2
  ret i32 1
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @cancel_xor.dfsan(i32 %0) #0 {
  store i8 0, ptr @__dfsan_retval_tls, align 2
  ret i32 7
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @cancel_copy.dfsan(i32 %0) #0 {
  store i8 0, ptr @__dfsan_retval_tls, align 2
  ret i32 0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @mask_chain.dfsan(i32 %0) #0 {
  store i8 0, ptr @__dfsan_retval_tls, align 2
  ret i32 0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @zero_register.dfsan(i32 %0) #0 {
  store i8 0, ptr @__dfsan_retval_tls, align 2
  ret i32 0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @inject_add.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = add i32 %0, 1
  store i8 %2, ptr @__dfsan_retval_tls, align 2
  ret i32 %3
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @inject_mix.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = mul i32 %0, 3
  %4 = xor i32 %3, 7
  %5 = add i32 %4, 5
  store i8 %2, ptr @__dfsan_retval_tls, align 2
  ret i32 %5
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef i32 @retained_mask.dfsan(i32 noundef %0) #0 {
  %2 = load i8, ptr @__dfsan_arg_tls, align 2
  %3 = and i32 %0, 1
  store i8 %2, ptr @__dfsan_retval_tls, align 2
  ret i32 %3
}

; Function Attrs: nounwind uwtable
define dso_local noundef i32 @main() local_unnamed_addr #2 {
  %1 = alloca i8, align 1
  %2 = alloca i32, align 4
  %3 = tail call i32 @puts(ptr noundef nonnull dereferenceable(1) @.str.8)
  br label %4

4:                                                ; preds = %0, %4
  %5 = phi i8 [ 0, %0 ], [ %5, %4 ]
  %6 = phi i64 [ 0, %0 ], [ %131, %4 ]
  %7 = getelementptr inbounds [8 x ptr], ptr @__const.main.fs, i64 0, i64 %6
  %8 = getelementptr inbounds [8 x ptr], ptr @__const.main.ns, i64 0, i64 %6
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #5
  %9 = ptrtoint ptr %2 to i64
  %10 = xor i64 %9, 87960930222080
  %11 = inttoptr i64 %10 to ptr
  store i32 0, ptr %11, align 1
  store i32 0, ptr %2, align 4, !tbaa !5
  call void @dfsan_set_label(i8 noundef zeroext 1, ptr noundef nonnull %2, i64 noundef 4) #5
  %12 = load ptr, ptr %7, align 8, !tbaa !9
  %13 = ptrtoint ptr %2 to i64
  %14 = xor i64 %13, 87960930222080
  %15 = inttoptr i64 %14 to ptr
  %16 = load i32, ptr %15, align 1
  %17 = lshr i32 %16, 16
  %18 = or i32 %16, %17
  %19 = lshr i32 %18, 8
  %20 = or i32 %18, %19
  %21 = trunc i32 %20 to i8
  %22 = load i32, ptr %2, align 4, !tbaa !5
  store i8 %21, ptr @__dfsan_arg_tls, align 2
  %23 = call i32 %12(i32 noundef %22) #5
  %24 = load i8, ptr @__dfsan_retval_tls, align 2
  %25 = zext i32 %23 to i64
  %26 = call zeroext i8 @__dfsw_dfsan_get_label(i64 noundef %25, i8 zeroext %24, ptr %1) #5
  %27 = load i8, ptr %1, align 1
  %28 = load ptr, ptr %8, align 8, !tbaa !9
  %29 = ptrtoint ptr %2 to i64
  %30 = xor i64 %29, 87960930222080
  %31 = inttoptr i64 %30 to ptr
  %32 = load i32, ptr %31, align 1
  %33 = lshr i32 %32, 16
  %34 = or i32 %32, %33
  %35 = lshr i32 %34, 8
  %36 = or i32 %34, %35
  %37 = trunc i32 %36 to i8
  %38 = load i32, ptr %2, align 4, !tbaa !5
  %39 = zext i8 %26 to i32
  %40 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef %28, i32 noundef %38, i32 noundef %23, i32 noundef %39)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #5
  %41 = ptrtoint ptr %2 to i64
  %42 = xor i64 %41, 87960930222080
  %43 = inttoptr i64 %42 to ptr
  store i32 0, ptr %43, align 1
  store i32 1, ptr %2, align 4, !tbaa !5
  call void @dfsan_set_label(i8 noundef zeroext 1, ptr noundef nonnull %2, i64 noundef 4) #5
  %44 = ptrtoint ptr %2 to i64
  %45 = xor i64 %44, 87960930222080
  %46 = inttoptr i64 %45 to ptr
  %47 = load i32, ptr %46, align 1
  %48 = lshr i32 %47, 16
  %49 = or i32 %47, %48
  %50 = lshr i32 %49, 8
  %51 = or i32 %49, %50
  %52 = trunc i32 %51 to i8
  %53 = load i32, ptr %2, align 4, !tbaa !5
  store i8 %52, ptr @__dfsan_arg_tls, align 2
  %54 = call i32 %12(i32 noundef %53) #5
  %55 = load i8, ptr @__dfsan_retval_tls, align 2
  %56 = zext i32 %54 to i64
  %57 = call zeroext i8 @__dfsw_dfsan_get_label(i64 noundef %56, i8 zeroext %55, ptr %1) #5
  %58 = load i8, ptr %1, align 1
  %59 = ptrtoint ptr %2 to i64
  %60 = xor i64 %59, 87960930222080
  %61 = inttoptr i64 %60 to ptr
  %62 = load i32, ptr %61, align 1
  %63 = lshr i32 %62, 16
  %64 = or i32 %62, %63
  %65 = lshr i32 %64, 8
  %66 = or i32 %64, %65
  %67 = trunc i32 %66 to i8
  %68 = load i32, ptr %2, align 4, !tbaa !5
  %69 = zext i8 %57 to i32
  %70 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef %28, i32 noundef %68, i32 noundef %54, i32 noundef %69)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #5
  %71 = ptrtoint ptr %2 to i64
  %72 = xor i64 %71, 87960930222080
  %73 = inttoptr i64 %72 to ptr
  store i32 0, ptr %73, align 1
  store i32 2, ptr %2, align 4, !tbaa !5
  call void @dfsan_set_label(i8 noundef zeroext 1, ptr noundef nonnull %2, i64 noundef 4) #5
  %74 = ptrtoint ptr %2 to i64
  %75 = xor i64 %74, 87960930222080
  %76 = inttoptr i64 %75 to ptr
  %77 = load i32, ptr %76, align 1
  %78 = lshr i32 %77, 16
  %79 = or i32 %77, %78
  %80 = lshr i32 %79, 8
  %81 = or i32 %79, %80
  %82 = trunc i32 %81 to i8
  %83 = load i32, ptr %2, align 4, !tbaa !5
  store i8 %82, ptr @__dfsan_arg_tls, align 2
  %84 = call i32 %12(i32 noundef %83) #5
  %85 = load i8, ptr @__dfsan_retval_tls, align 2
  %86 = zext i32 %84 to i64
  %87 = call zeroext i8 @__dfsw_dfsan_get_label(i64 noundef %86, i8 zeroext %85, ptr %1) #5
  %88 = load i8, ptr %1, align 1
  %89 = ptrtoint ptr %2 to i64
  %90 = xor i64 %89, 87960930222080
  %91 = inttoptr i64 %90 to ptr
  %92 = load i32, ptr %91, align 1
  %93 = lshr i32 %92, 16
  %94 = or i32 %92, %93
  %95 = lshr i32 %94, 8
  %96 = or i32 %94, %95
  %97 = trunc i32 %96 to i8
  %98 = load i32, ptr %2, align 4, !tbaa !5
  %99 = zext i8 %87 to i32
  %100 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef %28, i32 noundef %98, i32 noundef %84, i32 noundef %99)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #5
  %101 = ptrtoint ptr %2 to i64
  %102 = xor i64 %101, 87960930222080
  %103 = inttoptr i64 %102 to ptr
  store i32 0, ptr %103, align 1
  store i32 -1, ptr %2, align 4, !tbaa !5
  call void @dfsan_set_label(i8 noundef zeroext 1, ptr noundef nonnull %2, i64 noundef 4) #5
  %104 = ptrtoint ptr %2 to i64
  %105 = xor i64 %104, 87960930222080
  %106 = inttoptr i64 %105 to ptr
  %107 = load i32, ptr %106, align 1
  %108 = lshr i32 %107, 16
  %109 = or i32 %107, %108
  %110 = lshr i32 %109, 8
  %111 = or i32 %109, %110
  %112 = trunc i32 %111 to i8
  %113 = load i32, ptr %2, align 4, !tbaa !5
  store i8 %112, ptr @__dfsan_arg_tls, align 2
  %114 = call i32 %12(i32 noundef %113) #5
  %115 = load i8, ptr @__dfsan_retval_tls, align 2
  %116 = zext i32 %114 to i64
  %117 = call zeroext i8 @__dfsw_dfsan_get_label(i64 noundef %116, i8 zeroext %115, ptr %1) #5
  %118 = load i8, ptr %1, align 1
  %119 = ptrtoint ptr %2 to i64
  %120 = xor i64 %119, 87960930222080
  %121 = inttoptr i64 %120 to ptr
  %122 = load i32, ptr %121, align 1
  %123 = lshr i32 %122, 16
  %124 = or i32 %122, %123
  %125 = lshr i32 %124, 8
  %126 = or i32 %124, %125
  %127 = trunc i32 %126 to i8
  %128 = load i32, ptr %2, align 4, !tbaa !5
  %129 = zext i8 %117 to i32
  %130 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef %28, i32 noundef %128, i32 noundef %114, i32 noundef %129)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #5
  %131 = add nuw nsw i64 %6, 1
  %132 = icmp eq i64 %131, 8
  br i1 %132, label %133, label %4, !llvm.loop !11

133:                                              ; preds = %4
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @puts(ptr nocapture noundef readonly) local_unnamed_addr #3

declare void @dfsan_set_label(i8 noundef zeroext, ptr noundef, i64 noundef) local_unnamed_addr #4

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #3

declare zeroext i8 @__dfsw_dfsan_get_label(i64 noundef, i8, ptr) local_unnamed_addr #4

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!5 = !{!6, !6, i64 0}
!6 = !{!"int", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C/C++ TBAA"}
!9 = !{!10, !10, i64 0}
!10 = !{!"any pointer", !7, i64 0}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.mustprogress"}
