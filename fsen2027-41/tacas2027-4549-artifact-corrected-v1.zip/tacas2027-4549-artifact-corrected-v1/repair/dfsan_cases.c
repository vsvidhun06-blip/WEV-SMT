#include <stdint.h>
#include <stdio.h>
#include <sanitizer/dfsan_interface.h>
#define NI __attribute__((noinline))
NI uint32_t cancel_add(uint32_t x){uint32_t t=x+1;return t-x;}
NI uint32_t cancel_xor(uint32_t x){uint32_t t=x^7;return t^x;}
NI uint32_t cancel_copy(uint32_t x){uint32_t t=x;return t-x;}
NI uint32_t mask_chain(uint32_t x){uint32_t t=x&1;return t&2;}
NI uint32_t zero_register(uint32_t x){uint32_t k=0;return x*k;}
NI uint32_t inject_add(uint32_t x){return x+1;}
NI uint32_t inject_mix(uint32_t x){uint32_t t=x*3;return (t^7)+5;}
NI uint32_t retained_mask(uint32_t x){return x&1;}
typedef uint32_t (*fn)(uint32_t);
int main(void){
 fn fs[]={cancel_add,cancel_xor,cancel_copy,mask_chain,zero_register,inject_add,inject_mix,retained_mask};
 const char *ns[]={"cancel_add","cancel_xor","cancel_copy","mask_chain","zero_register","inject_add","inject_mix","retained_mask"};
 uint32_t inputs[]={0,1,2,0xffffffffu};
 puts("name,input,output,label");
 for(unsigned i=0;i<8;i++)for(unsigned j=0;j<4;j++){
  uint32_t x=inputs[j];dfsan_set_label(1,&x,sizeof x);
  uint32_t y=fs[i](x);dfsan_label l=dfsan_get_label(y);
  printf("%s,%u,%u,%u\n",ns[i],x,y,(unsigned)l);
 }
 return 0;
}
