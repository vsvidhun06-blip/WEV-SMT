from pathlib import Path
import ast,csv,json,collections,hashlib
R=Path(__file__).parent
rows=list(csv.DictReader((R/'symbolic-ring-audit.csv').open(newline='')))
assert len(rows)==3656
assert len({(r['expr'],r['threads']) for r in rows})==3656
M=2**32-1
def ev(e,x):
 def f(n):
  if isinstance(n,ast.Name): return x
  if isinstance(n,ast.Constant): return n.value&M
  if isinstance(n,ast.UnaryOp): return (~f(n.operand))&M
  a,b=f(n.left),f(n.right)
  return {ast.Add:lambda:a+b,ast.Sub:lambda:a-b,ast.Mult:lambda:a*b,ast.BitAnd:lambda:a&b,ast.BitXor:lambda:a^b}[type(n.op)]()&M
 return f(ast.parse(e,mode='eval').body)
for r in rows:
 assert ev(r['expr'],0)==1
 assert (r['value_consistency']=='SAT')==(ev(r['expr'],1)==1),r
 if r['value_consistency']=='UNSAT': assert all(r[k]=='FORBIDDEN' for k in ['weakest','folding','syntactic'])
keep=[r for r in rows if r['value_consistency']=='SAT']
assert len(keep)==1288
matrix={}
for k in ['weakest','folding','syntactic']:
 c=collections.Counter()
 for r in keep:
  positive=r['oracle_constant']=='false'; predicted=r[k]=='FORBIDDEN'
  c['TP' if positive and predicted else 'FN' if positive else 'FP' if predicted else 'TN']+=1
 matrix[k]=dict(c)
assert matrix['weakest']=={'TP':220,'TN':1068}
assert matrix['folding']=={'TP':220,'TN':298,'FP':770}
assert matrix['syntactic']=={'TP':220,'FP':1068}
d={'generated':3656,'value_consistent':1288,'value_inconsistent':2368,'matrices':matrix}
(R/'benchmark-correction.json').write_text(json.dumps(d,indent=2))
with (R/'symbolic-value-consistent.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(keep)
print(json.dumps(d))
