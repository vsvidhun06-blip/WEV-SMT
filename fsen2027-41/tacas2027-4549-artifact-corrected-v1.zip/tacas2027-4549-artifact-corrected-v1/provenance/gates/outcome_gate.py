"""Independent outcome-binding gate (read-only).

For every manifest test, independently derives what the exists clause requires and
compares it with what the shipped parser generated (OutcomeDump.java: existsReadValues by
event position, existsMemFinal, or the rejection).

AArch64: an independent 64-bit executor. Registers are numbered storage (Wn/Xn share n);
W writes zero-extend; X arithmetic is 64-bit; SXTW/UXTW extends; WZR/XZR read 0 and
discard writes; X loads read (upper half of the location's 64-bit initial value | 32-bit
load value), with the upper half also allowed to be 0 when the location is stored to;
B/H loads are treated as 32-bit loads (sub-word semantics are out of scope and flagged).
Initial values: Wn=v zero-extends, Xn=v and typed 64-bit values sign-extend.

Every atom's truth is evaluated on random valuations of the load values (and on forced
valuations): a register atom is
  PIN(k, v)   iff  atom(nu) <=> nu[load k] == v   on every sample,
  CONST-TRUE / CONST-FALSE  iff it does not depend on any load,
  COMPUTED    otherwise (depends on loads, no single-load pin is equivalent: includes
              width-sensitive 64-bit values).
Non-AArch64 tests use the 32-bit executor of the immediate-repair gate (gate2.py).

Per test, outcome status:
  FULLY-BOUND    shipped parsed; its pins and memory-final constraints are exactly the
                 independently required ones, and every atom is supported
  ERRONEOUS      shipped parsed but generated different constraints
  UNSUPPORTED    shipped rejected; sub-status 'expected' when the independent analysis also
                 finds an unsupported construct, else 'over-rejected'
  UNCHECKED      the independent executor cannot model the test
Usage: python -I -X utf8 outcome_gate.py <outcomes.csv> <corpus_root> <out.csv>
"""
import collections
import csv
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate2 as G  # noqa: E402  (32-bit executor of the immediate-repair gate)

M32, M64 = 0xffffffff, 0xffffffffffffffff
NS = 160
SCALAR64 = ('int64_t', 'uint64_t', 'long')
SCALAR32 = ('int', 'int32_t', 'uint32_t', 'unsigned', 'unsigned int')


class Unsup(Exception):
    """A construct the shipped model is expected to reject."""


class Unchecked(Exception):
    """Outside what this independent executor models."""


def sx(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


def lit(s):
    s = s.strip().lstrip('#').strip()
    neg = s.startswith('-')
    s = s.lstrip('+-')
    v = int(s, 16) if s.lower().startswith('0x') else int(s)
    return -v if neg else v


# ── AArch64 initial state ────────────────────────────────────────────────────

def arm_init(init):
    regs = collections.defaultdict(dict)      # thread -> regno -> ('v', int64) | ('a', loc)
    locs = {}                                 # loc -> int64 initial value
    bad_regs = collections.defaultdict(set)
    bad_locs = set()
    contradictory = []
    for st in init.split(';'):
        s = st.strip()
        if not s:
            continue
        m = re.match(r'(unsigned\s+int|int32_t|uint32_t|int64_t|uint64_t|unsigned|long|int)\s+(.*)$', s)
        typ = None
        if m:
            typ, s = m.group(1), m.group(2).strip()
        m = re.fullmatch(r'(\d+)\s*:\s*([A-Za-z_]\w*)\s*=\s*(.+)', s)
        if m:
            t, name, val = int(m.group(1)), m.group(2), m.group(3).strip()
            rm = re.fullmatch(r'([WwXx])(\d{1,2})', name)
            key = int(rm.group(2)) if rm else name
            if re.fullmatch(r'-?(0x[0-9a-fA-F]+|\d+)', val):
                v = lit(val)
                v64 = (v & M32) if (rm and rm.group(1) in 'Ww') else (v & M64)
                new = ('v', v64)
            elif re.fullmatch(r'[A-Za-z_]\w*', val):
                new = ('a', val)
            else:
                bad_regs[t].add(key)
                continue
            if key in regs[t] and regs[t][key] != new:
                contradictory.append((t, key))
            regs[t][key] = new
            continue
        m = re.fullmatch(r'([A-Za-z_]\w*)\s*=\s*(-?(?:0x[0-9a-fA-F]+|\d+))', s)
        if m and (typ is None or typ in SCALAR64 or typ in SCALAR32):
            locs[m.group(1)] = lit(m.group(2)) & M64
            continue
        if typ and re.fullmatch(r'[A-Za-z_]\w*', s) and (typ in SCALAR64 or typ in SCALAR32):
            continue
        m = re.match(r'(?:[A-Za-z_]\w*\s+)*\*?\s*([A-Za-z_]\w*)', s)
        if m:
            bad_locs.add(m.group(1))
    return regs, locs, bad_regs, bad_locs, contradictory


# ── AArch64 64-bit executor ──────────────────────────────────────────────────

def run_arm(instrs, tid, regs0, locs, bad_regs, bad_locs, stored):
    regs = {}       # regno -> fn(nu)->int64, or ('a', loc)
    for k, v in regs0.items():
        regs[k] = (lambda c: (lambda nu: c))(v[1]) if v[0] == 'v' else v
    events = []

    def rd(tok):
        t = tok.strip()
        if re.fullmatch(r'[WwXx][Zz][Rr]', t):
            return lambda nu: 0
        if re.fullmatch(r'#?[+-]?(0x[0-9a-fA-F]+|\d+)', t):
            c = lit(t) & M64
            return lambda nu: c
        m = re.fullmatch(r'([WwXx])(\d{1,2})', t)
        if not m:
            if re.fullmatch(r'(?i)w?sp', t):
                raise Unsup('SP')
            raise Unchecked('operand ' + t)
        n = int(m.group(2))
        if n in bad_regs:
            raise Unsup('unmodelled initial register value')
        src = regs.get(n, lambda nu: 0)
        if isinstance(src, tuple):
            raise Unchecked('address register used as value')
        if m.group(1) in 'Ww':
            return lambda nu, f=src: f(nu) & M32
        return src

    def wr(tok, fn, wide):
        t = tok.strip()
        if re.fullmatch(r'[WwXx][Zz][Rr]', t):
            return
        m = re.fullmatch(r'([WwXx])(\d{1,2})', t)
        if not m:
            raise Unchecked('dest ' + t)
        n = int(m.group(2))
        regs[n] = (lambda nu, f=fn: f(nu) & M64) if (wide and m.group(1) in 'Xx') else (lambda nu, f=fn: f(nu) & M32)

    def loc_of(o, nxt):
        m = re.fullmatch(r'\[\s*([WwXx]\d{1,2})\s*(?:,(.*))?\]\s*(!?)', o.strip())
        if not m:
            raise Unchecked('address ' + o)
        base = int(m.group(1)[1:])
        rest, bang = m.group(2), m.group(3)
        if rest is not None:
            parts = [p.strip() for p in rest.split(',')]
            if parts[0].startswith('#') and (lit(parts[0]) != 0 or bang):
                raise Unsup('immediate offset')
        elif bang:
            raise Unsup('pre-index')
        b = regs.get(base)
        if not (isinstance(b, tuple) and b[0] == 'a'):
            raise Unsup('base not bound to a location')
        if b[1] is None:
            raise Unsup('post-index reuse')
        if not re.fullmatch(r'[A-Za-z_]\w*', b[1]):
            raise Unsup('tagged location')
        if b[1] in bad_locs:
            raise Unsup('unmodelled initial location value')
        post = nxt is not None and nxt.strip().startswith('#')
        return b[1], base, post

    for ins in instrs:
        s = ins.strip()
        if not s or re.fullmatch(r'[A-Za-z_]\w*:', s):
            continue
        if re.search(r'(?<![\w.#])[Ww]?[Ss][Pp](?!\w)', s):
            raise Unsup('SP')
        op, _, rest = s.partition(' ')
        op = op.lower()
        ops = G.split_ops(rest)
        if op in ('ldr', 'ldar', 'ldapr', 'ldur', 'ldrb', 'ldrh', 'ldaprb'):
            loc, base, post = loc_of(ops[1], ops[2] if len(ops) > 2 else None)
            k = len(events)
            events.append(('R', loc))
            d = ops[0].strip()
            if op in ('ldrb', 'ldrh', 'ldaprb'):
                pass
            if re.fullmatch(r'[Xx]\d{1,2}', d):
                up0 = (locs.get(loc, 0) >> 32) & M32
                ups = [up0] + ([0] if loc in stored and up0 else [])
                wr(d, lambda nu, k=k, ups=ups: (ups[nu[('U', tid, k)] % len(ups)] << 32) | (nu[('L', tid, k)] & M32), True)
            else:
                wr(d, lambda nu, k=k: nu[('L', tid, k)] & M32, False)
            if post:
                regs[base] = ('a', None)
            continue
        if op in ('str', 'stlr', 'stur', 'strb', 'strh'):
            loc, base, post = loc_of(ops[1], ops[2] if len(ops) > 2 else None)
            rd(ops[0])                      # the stored register must hold a modelled value
            events.append(('W', loc))
            if post:
                regs[base] = ('a', None)
            continue
        if op in ('dmb', 'dsb', 'isb'):
            events.append(('F', None))
            continue
        if op in ('mov', 'movz'):
            if len(ops) != 2:
                raise Unchecked('mov with shift: ' + s)
            d = ops[0].strip()
            src = ops[1].strip()
            f = rd(src)
            wr(d, f, True)
            continue
        if op in ('eor', 'add', 'sub', 'and', 'orr') and len(ops) in (3, 4):
            d = ops[0].strip()
            a, b = rd(ops[1]), rd(ops[2])
            if len(ops) == 4:
                ext = ops[3].strip().lower()
                if ext == 'sxtw':
                    b = (lambda nu, f=b: sx(f(nu) & M32, 32) & M64)
                elif ext in ('uxtw', 'sxtx', 'uxtx'):
                    pass
                else:
                    raise Unsup('shifted/extended operand')
            fn = {'eor': lambda x, y: x ^ y, 'add': lambda x, y: x + y, 'sub': lambda x, y: x - y,
                  'and': lambda x, y: x & y, 'orr': lambda x, y: x | y}[op]
            wide = bool(re.fullmatch(r'[Xx]\d{1,2}', d))
            if wide:
                wr(d, lambda nu, a=a, b=b, fn=fn: fn(a(nu), b(nu)) & M64, True)
            else:
                wr(d, lambda nu, a=a, b=b, fn=fn: fn(a(nu) & M32, b(nu) & M32) & M32, False)
            continue
        if op in ('cmp', 'tst', 'nop'):
            continue
        if op in ('b', 'cbz', 'cbnz', 'beq', 'bne') or op.startswith('b.'):
            raise Unchecked('branch: final register values are path-dependent')
        raise Unchecked('instruction ' + s)
    return events, regs


# ── outcome clause ───────────────────────────────────────────────────────────

def atoms_of(clause):
    c = clause.strip()
    q = re.match(r'(~\s*exists|exists|forall)\b', c)
    body = c[q.end():] if q else c
    if not body.strip():
        return []
    if '\\/' in body:
        raise Unsup('disjunction')
    out = []
    for raw in body.replace('(', ' ').replace(')', ' ').split('/\\'):
        a = raw.strip()
        if not a:
            continue
        if a.startswith('~'):
            raise Unsup('negated atom')
        m = re.fullmatch(r'(\d+)\s*:\s*([A-Za-z_]\w*)\s*=\s*(-?(?:0x[0-9a-fA-F]+|\d+))', a)
        if m:
            out.append(('reg', int(m.group(1)), m.group(2), lit(m.group(3))))
            continue
        m = re.fullmatch(r'(\[\s*)?([A-Za-z_]\w*)\s*(\])?\s*=\s*(-?(?:0x[0-9a-fA-F]+|\d+))', a)
        if m and (m.group(1) is None) == (m.group(3) is None):
            out.append(('mem', m.group(2), lit(m.group(4))))
            continue
        raise Unsup('unsupported term ' + a)
    return out


def classify_atom(truth, cands, rng):
    """CONST-TRUE / CONST-FALSE / ('PIN', key, value) / COMPUTED for truth: nu -> bool.
    cands: extra candidate pin values (the atom's constant, as 32-bit)."""
    samples = []
    for _ in range(NS):
        nu = collections.defaultdict(lambda: rng.choice([0, 1, 2, 3, M32, 0x80000000, rng.getrandbits(32), rng.getrandbits(32)]))
        samples.append(nu)
    vals = [truth(nu) for nu in samples]
    used = set()
    for nu in samples:
        used |= {k for k in nu if k[0] == 'L'}
    # candidate pins: for each load, the value that makes the atom true in some sample
    for key in sorted(used):
        for v in sorted({nu[key] for nu, t in zip(samples, vals) if t} | set(range(0, 4)) | {M32} | set(cands)):
            ok = True
            for i in range(NS):
                nu = samples[i]
                if truth(nu) != (nu[key] == v):
                    ok = False
                    break
                forced = collections.defaultdict(lambda: rng.getrandbits(32), {kk: vv for kk, vv in nu.items()})
                forced[key] = v
                if not truth(forced):
                    ok = False
                    break
            if ok:
                return ('PIN', key, v)
    if all(vals):
        return 'CONST-TRUE'          # true on every sample (possibly consulting loads, e.g. (r^r)+1 == 1)
    if not any(vals):
        return 'CONST-FALSE'
    return 'COMPUTED'


def analyse_arm(src):
    init, body = G.split_source(src, 'ARM')
    regs0, locs, bad_regs, bad_locs, contra = arm_init(init)
    if contra:
        raise Unsup('contradictory initial values')
    threads = G.threads_of(body)
    stored = set()
    for ins in threads:
        for s in ins:
            m = re.match(r'(?i)(str|stlr|stur|strb|strh)\s', s.strip())
            if m:
                pass
    # locations stored to (by base register name resolution)
    for t, ins in enumerate(threads):
        for s in ins:
            m = re.match(r'(?i)(?:str|stlr|stur|strb|strh)\s+[^,]+,\s*\[\s*([WwXx])(\d{1,2})', s.strip())
            if m:
                b = regs0.get(t, {}).get(int(m.group(2)))
                if isinstance(b, tuple) and b[0] == 'a':
                    stored.add(b[1])
    runs = [run_arm(ins, t + 1, regs0.get(t, {}), locs, bad_regs.get(t, set()), bad_locs, stored)
            for t, ins in enumerate(threads)]
    accessed = {l for ev, _ in runs for k, l in ev if l}
    return runs, locs, accessed, regs0, bad_regs, bad_locs


def expected_arm(src, clause, rng):
    """Expected (pins {(t,ord):v}, mem {loc:v}) or raise Unsup/Unchecked."""
    runs, locs, accessed, regs0, bad_regs, bad_locs = analyse_arm(src)
    pins, mem = {}, {}
    for a in atoms_of(clause):
        if a[0] == 'mem':
            _, loc, v = a
            if loc in bad_locs:
                raise Unsup('unmodelled location in outcome')
            if loc in accessed:
                mem[loc] = v & M32
            elif (locs.get(loc, 0) & M32) != (v & M32):
                raise Unsup('statically false memory atom')
            continue
        _, t, name, v = a
        if t >= len(runs):
            raise Unsup('no such thread')
        m = re.fullmatch(r'([WwXx])(\d{1,2}|[Zz][Rr])', name)
        if not m:
            raise Unchecked('register name ' + name)
        if m.group(2).upper() == 'ZR':
            if v != 0:
                raise Unsup('zero register outcome false')
            continue
        n = int(m.group(2))
        regs = runs[t][1]
        if n in bad_regs.get(t, set()):
            raise Unsup('unmodelled initial register value')
        if n not in regs:
            raise Unsup('undefined register')
        f = regs[n]
        if isinstance(f, tuple):
            raise Unsup('address register')
        if m.group(1) in 'Xx':
            truth = (lambda nu, f=f, c=v & M64: f(nu) == c)
        else:
            truth = (lambda nu, f=f, c=v & M32: (f(nu) & M32) == c)
        k = classify_atom(truth, {v & M32}, rng)
        if k == 'CONST-TRUE':
            continue
        if isinstance(k, tuple):
            key = (k[1][1], k[1][2])
            if key in pins and pins[key] != k[2]:
                raise Unsup('contradictory pins')
            pins[key] = k[2]
            continue
        raise Unsup('atom ' + str(k))
    return pins, mem


def expected_other(src, arch, clause, rng):
    init, body = G.split_source(src, arch)
    regs0 = G.parse_init(init)
    threads = G.threads_of(body)
    runs = [G.run_thread(arch, ins, t + 1, regs0.get(t, {})) for t, ins in enumerate(threads)]
    pins, mem = {}, {}
    accessed = {l for ev, _, _ in runs for k, l, _ in ev if l}
    for a in atoms_of(clause):
        if a[0] == 'mem':
            if a[1] in accessed:
                mem[a[1]] = a[2] & M32
            continue
        _, t, name, v = a
        if t >= len(runs):
            raise Unsup('no such thread')
        env = runs[t][1]
        r = G.canon(name)
        if r not in env:
            raise Unsup('undefined register')
        term = env[r]
        truth = (lambda nu, term=term, c=v & M32: G.ev_term(term, nu) == c)
        k = classify_atom(truth, {v & M32}, rng)
        if k == 'CONST-TRUE':
            continue
        if isinstance(k, tuple):
            pins[(k[1][1], k[1][2])] = k[2]
            continue
        raise Unsup('atom ' + str(k))
    return pins, mem


def arch_of(src):
    return G.arch_of(src)


def parse_pins(s):
    out = {}
    for p in filter(None, s.split(';')):
        pos, v = p.split('=')
        t, o = pos.split('#')
        out[(int(t), int(o))] = int(v) & M32
    return out


def parse_mem(s):
    return {p.split('=')[0]: int(p.split('=')[1]) & M32 for p in filter(None, s.split(';'))}


def main():
    outcomes, root, out = sys.argv[1:4]
    rng = random.Random(20261009)
    rows = []
    for r in csv.DictReader(open(outcomes, encoding='utf-8')):
        t = r['test']
        src = open(root + t, encoding='utf-8', errors='replace').read()
        arch = arch_of(src)
        clause = ''
        m = re.search(r'^\s*((?:~\s*)?exists|forall)\b(.*)\Z', re.sub(r'\(\*.*?\*\)', ' ', src, flags=re.S), re.S | re.M)
        if m:
            clause = (m.group(1) + m.group(2)).strip()
        rec = {'test': t, 'arch': arch, 'shipped': 'ok' if r['status'] == 'ok' else 'rejected',
               'shipped_reason': '' if r['status'] == 'ok' else r['status'][:200],
               'outcome': '', 'detail': ''}
        try:
            if arch == 'ARM' and re.search(r'^\s*filter\b', src, re.M):
                raise Unsup('filter clause')
            exp = expected_arm(src, clause, rng) if arch == 'ARM' else expected_other(src, arch, clause, rng)
            exp_kind = 'bindable'
        except Unsup as u:
            exp, exp_kind = None, 'unsupported: ' + str(u)
        except (Unchecked, G.Unsupported, G.Unmodelled) as u:
            exp, exp_kind = None, 'unchecked: ' + str(u)
        except Exception as x:  # noqa: BLE001
            exp, exp_kind = None, 'unchecked: error ' + repr(x)[:80]
        if r['status'] != 'ok':
            if exp_kind.startswith('unsupported'):
                rec['outcome'], rec['detail'] = 'UNSUPPORTED-expected', exp_kind
            elif exp_kind.startswith('unchecked'):
                rec['outcome'], rec['detail'] = 'UNSUPPORTED-unchecked', exp_kind
            else:
                rec['outcome'], rec['detail'] = 'UNSUPPORTED-over-rejected', 'independently bindable'
        elif exp is None:
            rec['outcome'] = 'UNCHECKED' if exp_kind.startswith('unchecked') else 'ERRONEOUS'
            rec['detail'] = exp_kind + ' (shipped accepted it)'
        else:
            pins, mem = exp
            sp, sm = parse_pins(r['read_pins']), parse_mem(r['mem_final'])
            if pins == sp and mem == sm:
                rec['outcome'] = 'FULLY-BOUND'
            else:
                rec['outcome'] = 'ERRONEOUS'
                rec['detail'] = 'pins shipped=%s expected=%s; mem shipped=%s expected=%s' % (
                    sorted(sp.items()), sorted(pins.items()), sorted(sm.items()), sorted(mem.items()))
        rows.append(rec)
    with open(out, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    c = collections.Counter((r['arch'], r['outcome']) for r in rows)
    for k, v in sorted(c.items()):
        print('%5d %s' % (v, k))


if __name__ == '__main__':
    main()
