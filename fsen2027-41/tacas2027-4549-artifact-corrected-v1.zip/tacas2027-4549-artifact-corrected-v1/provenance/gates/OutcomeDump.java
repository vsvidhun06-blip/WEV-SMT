import com.weakest.model.Event;
import com.weakest.model.ReadEvent;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;
import wev.smt.parse.ParseException;

import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;

/**
 * Read-only outcome-binding dump (external audit tool). Per test:
 *   test,status,read_pins,mem_final,rf
 * read_pins = "T#ord=value;..." (existsReadValues by event position), mem_final = "loc=v;...",
 * rf = "T#ord<-T#ord;..." wired reads-from for every read.
 * Args: list.txt root out.csv
 */
public final class OutcomeDump {
    public static void main(String[] a) throws Exception {
        Path root = Path.of(a[1]);
        try (PrintWriter w = new PrintWriter(Files.newBufferedWriter(Path.of(a[2])))) {
            w.println("test,status,read_pins,mem_final,rf");
            for (String line : Files.readAllLines(Path.of(a[0]))) {
                String t = line.strip();
                if (t.isEmpty()) continue;
                String rel = t.contains(",") ? t.substring(0, t.indexOf(',')) : t;
                LitmusCase lc;
                try {
                    Event.resetCounter();
                    lc = LitmusParser.parse(Files.readString(root.resolve(rel)), rel);
                } catch (ParseException pe) {
                    w.println(q(rel) + "," + q("PARSE:" + pe.getMessage()) + ",,,");
                    continue;
                } catch (RuntimeException re) {
                    w.println(q(rel) + "," + q("ERROR:" + re) + ",,,");
                    continue;
                }
                Map<Integer, String> pos = new HashMap<>();
                Map<Integer, Integer> per = new HashMap<>();
                for (Event e : lc.es().getEvents()) {
                    int k = per.merge(e.getThreadId(), 1, Integer::sum) - 1;
                    pos.put(e.getId(), e.getThreadId() + "#" + k);
                }
                StringJoiner pins = new StringJoiner(";");
                lc.existsReadValues().forEach((id, v) -> pins.add(pos.get(id) + "=" + v));
                StringJoiner mem = new StringJoiner(";");
                lc.existsMemFinal().forEach((l, v) -> mem.add(l + "=" + v));
                StringJoiner rf = new StringJoiner(";");
                for (Event e : lc.es().getEvents()) {
                    if (e instanceof ReadEvent r) {
                        Integer src = lc.es().getReadsFrom().get(r.getId());
                        rf.add(pos.get(r.getId()) + "<-" + (src == null ? "?" : pos.get(src)));
                    }
                }
                w.println(String.join(",", q(rel), "ok", q(pins.toString()), q(mem.toString()), q(rf.toString())));
            }
        }
    }

    static String q(String s) {
        return '"' + s.replace("\"", "\"\"").replace("\n", " ").replace("\r", " ") + '"';
    }
}
