import com.weakest.model.Event;
import com.weakest.model.RMWEvent;
import com.weakest.model.ReadEvent;
import com.weakest.model.WriteEvent;
import wev.smt.DependencyInfo;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;
import wev.smt.parse.ParseException;

import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Read-only extraction dump (external audit tool). For each listed test, with the shipped
 * default configuration (no constancy oracle):
 *   events.csv : test,status,thread,ord,kind,loc,mo,value,composed
 *   edges.csv  : test,kind,prod_thread,prod_ord,cons_thread,cons_ord,semantic
 * Args: list.txt root outdir
 */
public final class Extract {
    public static void main(String[] a) throws Exception {
        Path root = Path.of(a[1]);
        Path out = Path.of(a[2]);
        Files.createDirectories(out);
        try (PrintWriter ev = new PrintWriter(Files.newBufferedWriter(out.resolve("events.csv")));
             PrintWriter ed = new PrintWriter(Files.newBufferedWriter(out.resolve("edges.csv")))) {
            ev.println("test,status,thread,ord,kind,loc,mo,value,composed,id");
            ed.println("test,kind,prod_thread,prod_ord,cons_thread,cons_ord,semantic");
            for (String line : Files.readAllLines(Path.of(a[0]))) {
                String t = line.strip();
                if (t.isEmpty()) continue;
                String rel = t.contains(",") ? t.substring(0, t.indexOf(',')) : t;
                LitmusParser.CONSTANCY_ORACLE = null;
                Event.resetCounter();
                LitmusCase lc;
                try {
                    lc = LitmusParser.parse(Files.readString(root.resolve(rel)), rel);
                } catch (ParseException pe) {
                    ev.println(q(rel) + "," + q("PARSE:" + pe.kind() + ":" + pe.getMessage()) + ",,,,,,,,");
                    continue;
                } catch (RuntimeException re) {
                    ev.println(q(rel) + "," + q("ERROR:" + re) + ",,,,,,,,");
                    continue;
                }
                Map<Integer, int[]> pos = new HashMap<>();
                Map<Integer, Integer> perThread = new HashMap<>();
                boolean any = false;
                for (Event e : lc.es().getEvents()) {
                    int k = perThread.merge(e.getThreadId(), 1, Integer::sum) - 1;
                    pos.put(e.getId(), new int[]{e.getThreadId(), k});
                    if (e.getThreadId() == 0) continue;
                    any = true;
                    String kind = e instanceof RMWEvent ? "U" : e instanceof ReadEvent ? "R"
                            : e instanceof WriteEvent ? "W" : "F";
                    String composed = lc.writeValueExprs().getOrDefault(e.getId(), "");
                    ev.println(String.join(",", q(rel), "ok", String.valueOf(e.getThreadId()),
                            String.valueOf(k), kind, q(e.getVariable()), String.valueOf(e.getMemoryOrder()),
                            kind.equals("W") ? String.valueOf(e.getValue()) : "", q(composed),
                            String.valueOf(e.getId())));
                }
                if (!any) ev.println(q(rel) + ",ok-EMPTY,,,,,,,,");
                for (DependencyInfo.KindedEdge k : lc.deps().allEdges()) {
                    int[] p = pos.get(k.edge().producer().getId());
                    int[] c = pos.get(k.edge().consumer().getId());
                    ed.println(String.join(",", q(rel), String.valueOf(k.kind()),
                            String.valueOf(p[0]), String.valueOf(p[1]), String.valueOf(c[0]),
                            String.valueOf(c[1]), String.valueOf(k.edge().isSemantic())));
                }
            }
        }
    }

    static String q(String s) {
        return '"' + (s == null ? "" : s.replace("\"", "\"\"").replace("\n", " ").replace("\r", " ")) + '"';
    }
}
