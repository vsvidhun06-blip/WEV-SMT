"""Faithfulness gate: compare shipped extraction (Extract.java dumps) against an
independent source-level reconstruction of each litmus test.

Independent of the shipped front end:
  * own body extraction: (* *) comments removed; '#' is an AArch64 immediate when followed
    by [+-]?digit, otherwise a comment (other dialects: always a comment); '//' comments;
  * own lowering per dialect, AArch64 W/X register aliasing, PPC subf/mr/neg semantics;
  * own address resolution (base register -> init binding), with immediate offsets,
    pre-index writeback, post-index writeback and tagged/unknown bindings treated as
    UNMODELLED;
  * own BV32 evaluation: C source with C operator precedence; shipped composed strings
    with the shipped QF_BV grammar's precedence (relational outermost).

Per test, classification:
  FAITHFUL      shipped ok and every check equal
  UNFAITHFUL    shipped ok, independent ok, some check differs (details listed)
  EXCLUDED      shipped raised a ParseException (explicit)
  UNVALIDATED   shipped ok, independent could not reconstruct (reason listed)
  EMPTY         shipped ok but no program events

Usage: python -I gate.py events.csv edges.csv root out_prefix
"""
import collections
import csv
import random
import re
import sys

MASK = 0xffffffff
NVAL = 40


class Unsupported(Exception):
    pass


class Unmodelled(Exception):
    pass


# ── source extraction ────────────────────────────────────────────────────────

def arch_of(txt):
    for ln in txt.splitlines():
        t = ln.strip()
        if not t or t.startswith('#') or t.startswith('//') or t.startswith('(*'):
            continue
        tok = t.split()[0].upper()
        if tok in ('TST', 'LITMUS', 'TEST') and len(t.split()) > 1:
            tok = t.split()[1].upper()
        return {'AARCH64': 'ARM', 'ARM': 'ARM', 'PPC': 'PPC', 'X86': 'X86', 'X86_64': 'X86',
                'RISCV': 'RISCV', 'C': 'C'}.get(tok, tok)
    return None


def strip_hash_comment(line, arch):
    i = 0
    while True:
        i = line.find('#', i)
        if i < 0:
            break
        if arch == 'ARM' and re.match(r'[+-]?\d', line[i + 1:]):
            i += 1
            continue
        line = line[:i]
        break
    j = line.find('//')
    return line if j < 0 else line[:j]


def split_source(txt, arch):
    # A C dereference such as READ_ONCE(*x) also starts with "(*": protect it before
    # removing OCaml-style (* ... *) comments.
    txt = re.sub(r'\(\*(\s*[A-Za-z_]\w*\s*)\)', lambda m: '(\x00' + m.group(1) + ')', txt)
    txt = re.sub(r'\(\*.*?\*\)', ' ', txt, flags=re.S)
    txt = txt.replace('(\x00', '(*')
    lines = txt.splitlines()
    # header line
    k = 0
    while k < len(lines) and (not lines[k].strip() or lines[k].strip().startswith(('#', '//'))):
        k += 1
    k += 1
    # init block
    while k < len(lines) and '{' not in lines[k]:
        k += 1
    buf = []
    depth = 0
    while k < len(lines):
        ln = lines[k]
        for ch in ln:
            if ch == '{':
                depth += 1
                if depth == 1:
                    continue
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    break
            if depth >= 1:
                buf.append(ch)
        buf.append('\n')
        k += 1
        if depth == 0:
            break
    init = ''.join(buf)
    body = []
    while k < len(lines):
        t = lines[k].strip()
        if re.match(r'(~?exists|forall|locations|filter|final)\b', t):
            break
        if t.startswith('#') or t.startswith('//'):
            k += 1
            continue
        body.append(strip_hash_comment(lines[k], arch))
        k += 1
    return init, '\n'.join(body)


def canon(r):
    r = r.strip()
    m = re.fullmatch(r'[WwXx](\d+)', r)
    return 'X' + m.group(1) if m else r


def parse_init(init):
    regs = collections.defaultdict(dict)
    for part in init.split(';'):
        p = part.strip()
        m = re.match(r'(?:[A-Za-z_][\w\s\*]*\s)?(\d+)\s*:\s*([A-Za-z_]\w*)\s*=\s*(.+)$', p)
        if not m:
            continue
        t, r, v = int(m.group(1)), canon(m.group(2)), m.group(3).strip()
        if re.fullmatch(r'-?(0x[0-9a-fA-F]+|\d+)', v):
            regs[t][r] = int(v, 0) & MASK
        else:
            regs[t][r] = ('addr', v)
    return regs


def threads_of(body):
    fm = list(re.finditer(r'P(\d+)\s*\([^)]*\)\s*\{', body))
    if fm:
        out = []
        for m in fm:
            d = 0
            k = m.end() - 1
            for k in range(m.end() - 1, len(body)):
                if body[k] == '{':
                    d += 1
                elif body[k] == '}':
                    d -= 1
                    if d == 0:
                        break
            out.append([s.strip() for s in body[m.end():k].split(';') if s.strip()])
        return out
    rows = [r.strip() for r in body.split(';')]
    rows = [r for r in rows if r]
    if not rows:
        raise Unsupported('no rows')
    hdr = [c.strip() for c in rows[0].split('|')]
    if not all(re.fullmatch(r'P\d+', c) for c in hdr):
        raise Unsupported('no column header')
    out = [[] for _ in hdr]
    for r in rows[1:]:
        cells = r.split('|')
        for t in range(len(hdr)):
            c = cells[t].strip() if t < len(cells) else ''
            if c:
                out[t].append(c)
    return out


def split_ops(rest):
    out, d, cur = [], 0, ''
    for ch in rest:
        if ch in '[(':
            d += 1
        elif ch in '])':
            d -= 1
        if ch == ',' and d == 0:
            out.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def imm_val(s):
    s = s.strip().lstrip('#$').strip()
    return int(s, 0) & MASK


def is_imm(s):
    return bool(re.fullmatch(r'[#$]?\s*[+-]?(0x[0-9a-fA-F]+|\d+)', s.strip()))


# ── independent symbolic execution ───────────────────────────────────────────
# Value terms: ('c', n) | ('L', t, k) | ('I', t, reg) | (op, a, b) | ('neg', a) | ('not', a)

def ev_term(e, nu):
    tag = e[0]
    if tag == 'c':
        return e[1] & MASK
    if tag in ('L', 'I'):
        return nu[e] & MASK
    if tag == 'neg':
        return (-ev_term(e[1], nu)) & MASK
    if tag == 'not':
        return (~ev_term(e[1], nu)) & MASK
    a, b = ev_term(e[1], nu), ev_term(e[2], nu)
    sa = a - (1 << 32) if a & 0x80000000 else a
    sb = b - (1 << 32) if b & 0x80000000 else b
    return {'+': a + b, '-': a - b, '*': a * b, '^': a ^ b, '&': a & b, '|': a | b,
            '==': int(a == b), '!=': int(a != b), '<': int(sa < sb), '<=': int(sa <= sb),
            '>': int(sa > sb), '>=': int(sa >= sb)}[tag] & MASK


def syms(e, acc):
    if e[0] in ('L', 'I'):
        acc.add(e)
    elif e[0] == 'c':
        pass
    else:
        for x in e[1:]:
            syms(x, acc)
    return acc


class CParser:
    """C expression grammar with C precedence: | ^ & (== !=) (< <= > >=) (+ -) * unary."""
    LEVELS = [['|'], ['^'], ['&'], ['==', '!='], ['<=', '>=', '<', '>'], ['+', '-'], ['*']]

    def __init__(self, s, get):
        self.s = re.sub(r'\s+', '', s)
        self.p = 0
        self.get = get

    def parse(self):
        v = self.level(0)
        if self.p != len(self.s):
            raise Unsupported('C expr: ' + self.s)
        return v

    def level(self, i):
        if i == len(self.LEVELS):
            return self.unary()
        v = self.level(i + 1)
        while True:
            for op in self.LEVELS[i]:
                if self.s.startswith(op, self.p) and not (op in ('&', '|') and self.s.startswith(op * 2, self.p)) \
                        and not (op in ('<', '>') and self.s.startswith(op * 2, self.p)):
                    self.p += len(op)
                    v = (op, v, self.level(i + 1))
                    break
            else:
                return v

    def unary(self):
        if self.s.startswith('~', self.p):
            self.p += 1
            return ('not', self.unary())
        if self.s.startswith('-', self.p):
            self.p += 1
            return ('neg', self.unary())
        if self.s.startswith('(', self.p):
            self.p += 1
            v = self.level(0)
            if not self.s.startswith(')', self.p):
                raise Unsupported('C paren')
            self.p += 1
            return v
        m = re.compile(r'0[xX][0-9a-fA-F]+|\d+|[A-Za-z_]\w*').match(self.s, self.p)
        if not m:
            raise Unsupported('C expr: ' + self.s)
        self.p = m.end()
        t = m.group()
        if t[0].isdigit():
            return ('c', int(t, 0) & MASK)
        return self.get(t)


class ShippedParser(CParser):
    """The shipped QF_BV grammar: one relational operator outermost, then | ^ & +- * unary."""
    LEVELS = [['|'], ['^'], ['&'], ['+', '-'], ['*']]

    def parse(self):
        v = self.level(0)
        for op in ('==', '!=', '<=', '>=', '<', '>'):
            if self.s.startswith(op, self.p):
                self.p += len(op)
                v = (op, v, self.level(0))
                break
        if self.p != len(self.s):
            raise Unsupported('shipped expr: ' + self.s)
        return v


def run_thread(arch, instrs, tid, env0):
    env, addr = {}, {}
    for r, v in env0.items():
        if isinstance(v, tuple):
            addr[r] = v[1]
        else:
            env[r] = ('c', v)
    events = []

    def get(r):
        r = canon(r)
        if r in env:
            return env[r]
        if r in addr:
            raise Unsupported('address register used as value: ' + r)
        return ('I', tid, r)

    def opnd(s):
        return ('c', imm_val(s)) if is_imm(s) else get(s)

    def loc_of_base(b):
        b = canon(b)
        if b not in addr:
            raise Unmodelled('base register not bound to a location: ' + b)
        if addr[b] is None:
            raise Unmodelled('base register written back: ' + b)
        if not re.fullmatch(r'[A-Za-z_]\w*', addr[b]):
            raise Unmodelled('location binding not a plain variable: ' + addr[b])
        return addr[b]

    def arm_mem(ops, i):
        o = ops[i]
        m = re.match(r'\[\s*([A-Za-z_]\w*)\s*(?:,(.*))?\]\s*(!?)$', o)
        if not m:
            raise Unsupported('ARM mem operand: ' + o)
        base, rest, bang = m.group(1), m.group(2), m.group(3)
        if rest is not None:
            parts = [p.strip() for p in rest.split(',')]
            if parts[0].startswith('#'):
                if imm_val(parts[0]) != 0 or bang:
                    raise Unmodelled('immediate offset / pre-index: ' + o)
        elif bang:
            raise Unmodelled('pre-index: ' + o)
        loc = loc_of_base(base)
        post = i + 1 < len(ops) and ops[i + 1].strip().startswith('#')
        return loc, base, post

    def load(dst, loc):
        k = len(events)
        events.append(('R', loc, None))
        env[canon(dst)] = ('L', tid, k)
        addr.pop(canon(dst), None)

    def setreg(r, v):
        env[canon(r)] = v
        addr.pop(canon(r), None)

    for ins in instrs:
        s = ins.strip()
        if not s or re.fullmatch(r'[A-Za-z_]\w*:', s):
            continue
        if arch == 'C':
            s = re.sub(r'^(int|long|unsigned|intptr_t)\s+', '', s)
            s = re.sub(r'^else\b\s*', '', s)
            m = re.match(r'(if|while)\s*\((.*)\)\s*(.*)$', s)
            if m:
                s = m.group(3).strip().strip('{} ')
                if not s:
                    continue
            s = s.strip('{} ')
            if not s:
                continue
            m = re.match(r'(\w+)\s*=\s*(READ_ONCE\w*|smp_load_acquire|atomic_load(?:_explicit)?)\s*\(\s*[&*]?\s*(\w+)', s)
            if m:
                load(m.group(1), m.group(3))
                continue
            m = re.match(r'(WRITE_ONCE\w*|smp_store_release|atomic_store(?:_explicit)?)\s*\(\s*[&*]?\s*(\w+)\s*,\s*(.+?)\s*(,\s*\w+\s*)?\)\s*$', s)
            if m:
                events.append(('W', m.group(2), CParser(m.group(3), get).parse()))
                continue
            m = re.match(r'\*\s*(\w+)\s*=\s*(.+)$', s)
            if m:
                events.append(('W', m.group(1), CParser(m.group(2), get).parse()))
                continue
            m = re.match(r'(\w+)\s*=\s*\*\s*(\w+)$', s)
            if m:
                load(m.group(1), m.group(2))
                continue
            if re.match(r'(smp_(r|w)?mb|smp_mb__\w+)\s*\(|atomic_thread_fence|atomic_fence', s):
                events.append(('F', None, None))
                continue
            if re.search(r'atomic_|xchg|cmpxchg|spin_|rcu_|srcu_|\(', s.split('=', 1)[-1]) and not re.match(r'[A-Za-z_]\w*\s*=\s*[^=]', s):
                raise Unsupported('C: ' + s)
            m = re.match(r'([A-Za-z_]\w*)\s*=\s*(.+)$', s)
            if m and not re.search(r'atomic_|xchg|cmpxchg|spin_|rcu_|srcu_', m.group(2)):
                setreg(m.group(1), CParser(m.group(2), get).parse())
                continue
            raise Unsupported('C: ' + s)
        op, _, rest = s.partition(' ')
        op = op.lower()
        ops = split_ops(rest)
        if arch == 'ARM':
            if op in ('ldr', 'ldar', 'ldapr', 'ldrb', 'ldrh', 'ldaprb', 'ldur'):
                loc, base, post = arm_mem(ops, 1)
                load(ops[0], loc)
                if post:
                    addr[canon(base)] = None
                continue
            if op in ('str', 'stlr', 'strb', 'strh', 'stur'):
                loc, base, post = arm_mem(ops, 1)
                events.append(('W', loc, opnd(ops[0])))
                if post:
                    addr[canon(base)] = None
                continue
            if op in ('dmb', 'dsb', 'isb'):
                events.append(('F', None, None))
                continue
            if op in ('mov', 'movz', 'movw'):
                setreg(ops[0], opnd(ops[1]))
                continue
            if op in ('eor', 'add', 'sub', 'and', 'orr') and len(ops) in (3, 4):
                if len(ops) == 4 and not re.fullmatch(r'(?i)[su]xt[wx]', ops[3]):
                    raise Unsupported('ARM shifted/extended operand: ' + s)
                o = {'eor': '^', 'add': '+', 'sub': '-', 'and': '&', 'orr': '|'}[op]
                setreg(ops[0], (o, opnd(ops[1]), opnd(ops[2])))
                continue
            if op in ('cmp', 'cbz', 'cbnz', 'b', 'tst') or op.startswith('b.'):
                continue
            if op == 'nop':
                continue
            raise Unsupported('ARM: ' + s)
        if arch in ('PPC', 'RISCV'):
            loads = ('lwz', 'ld', 'lbz', 'lhz', 'lwa') if arch == 'PPC' else ('lw', 'ld', 'lb', 'lh')
            stores = ('stw', 'std', 'stb', 'sth') if arch == 'PPC' else ('sw', 'sd', 'sb', 'sh')
            fences = ('sync', 'lwsync', 'hwsync', 'isync', 'eieio') if arch == 'PPC' else ('fence', 'fence.i', 'fence.tso')

            def disp(o):
                m = re.fullmatch(r'(-?\w*)\(\s*(\w+)\s*\)', o.strip())
                if not m:
                    raise Unsupported('mem operand: ' + o)
                d = m.group(1)
                if d not in ('', '0'):
                    raise Unmodelled('displacement: ' + o)
                return loc_of_base(m.group(2))
            if op in loads:
                load(ops[0], disp(ops[1]))
                continue
            if op in stores:
                events.append(('W', disp(ops[1]), get(ops[0])))
                continue
            if op in fences:
                events.append(('F', None, None))
                continue
            if op == 'li':
                setreg(ops[0], opnd(ops[1]))
                continue
            if op in ('mr', 'mv'):
                setreg(ops[0], get(ops[1]))
                continue
            if op == 'neg':
                setreg(ops[0], ('neg', get(ops[1])))
                continue
            if op in ('xor', 'add', 'and', 'or', 'sub'):
                o = {'xor': '^', 'add': '+', 'and': '&', 'or': '|', 'sub': '-'}[op]
                setreg(ops[0], (o, get(ops[1]), get(ops[2])))
                continue
            if op == 'subf':
                setreg(ops[0], ('-', get(ops[2]), get(ops[1])))
                continue
            if op in ('addi', 'xori', 'andi', 'ori'):
                o = {'addi': '+', 'xori': '^', 'andi': '&', 'ori': '|'}[op]
                setreg(ops[0], (o, get(ops[1]), opnd(ops[2])))
                continue
            if op in ('cmpw', 'cmpwi', 'cmpd', 'beq', 'bne', 'blt', 'bgt', 'bge', 'b', 'j', 'jal', 'nop'):
                continue
            raise Unsupported(arch + ': ' + s)
        if arch == 'X86':
            o2 = [x.strip() for x in ops]
            s2 = re.sub(r'(?i)^lock\s+', '', s)
            op = s2.split()[0].lower()

            def xloc(x):
                m = re.fullmatch(r'\[\s*([A-Za-z_]\w*)\s*\]', x)
                if not m:
                    raise Unsupported('x86 mem: ' + x)
                n = m.group(1)
                return loc_of_base(n) if canon(n) in addr else n
            if op in ('mfence', 'lfence', 'sfence'):
                events.append(('F', None, None))
                continue
            if op == 'mov' and len(o2) == 2:
                d, sr = o2
                if '[' in d:
                    events.append(('W', xloc(d), opnd(sr)))
                elif '[' in sr:
                    load(d, xloc(sr))
                else:
                    setreg(d, opnd(sr))
                continue
            if op in ('add', 'sub', 'xor', 'and', 'or') and len(o2) == 2 and '[' not in ''.join(o2):
                o = {'add': '+', 'sub': '-', 'xor': '^', 'and': '&', 'or': '|'}[op]
                setreg(o2[0], (o, get(o2[0]), opnd(o2[1])))
                continue
            if op in ('cmp', 'test') or op.startswith('j'):
                continue
            raise Unsupported('X86: ' + s)
        raise Unsupported('arch ' + str(arch))
    return events


# ── comparison ───────────────────────────────────────────────────────────────

def load_shipped(events_csv, edges_csv):
    ev = collections.defaultdict(list)
    status = {}
    for r in csv.DictReader(open(events_csv, encoding='utf-8')):
        status.setdefault(r['test'], r['status'])
        if r['status'] == 'ok':
            ev[r['test']].append(r)
    ed = collections.defaultdict(list)
    for r in csv.DictReader(open(edges_csv, encoding='utf-8')):
        ed[r['test']].append(r)
    return status, ev, ed


def main():
    events_csv, edges_csv, root, out = sys.argv[1:5]
    status, ev, ed = load_shipped(events_csv, edges_csv)
    rnd = random.Random(20261009)
    rows = []
    for test, st in status.items():
        rec = {'test': test, 'arch': '', 'class': '', 'detail': '', 'shipped_status': st[:160],
               'n_events': len(ev.get(test, [])), 'n_data_pairs': 0, 'free_init_dep': False}
        try:
            src = open(root + test, encoding='utf-8', errors='replace').read()
        except OSError as e:
            rec['class'] = 'ERROR'
            rec['detail'] = repr(e)
            rows.append(rec)
            continue
        arch = arch_of(src)
        rec['arch'] = arch
        if st.startswith('PARSE') or st.startswith('ERROR'):
            rec['class'] = 'EXCLUDED'
            try:
                init, body = split_source(src, arch)
                regs = parse_init(init)
                [run_thread(arch, ins, t + 1, regs.get(t, {})) for t, ins in enumerate(threads_of(body))]
                rec['detail'] = 'independent: reconstructible'
            except (Unsupported, Unmodelled) as u:
                rec['detail'] = 'independent: ' + type(u).__name__ + ': ' + str(u)[:100]
            except Exception as x:
                rec['detail'] = 'independent: error ' + repr(x)[:100]
            rows.append(rec)
            continue
        if st == 'ok-EMPTY':
            try:
                init, body = split_source(src, arch)
                regs = parse_init(init)
                ind = [run_thread(arch, ins, t + 1, regs.get(t, {})) for t, ins in enumerate(threads_of(body))]
                n = sum(len(e) for e in ind)
                rec['class'] = 'EMPTY' if n == 0 else 'UNFAITHFUL'
                rec['detail'] = 'independent: no events' if n == 0 else 'shipped empty, independent has %d events' % n
            except (Unsupported, Unmodelled) as u:
                rec['class'] = 'EMPTY-UNVALIDATED'
                rec['detail'] = 'independent: ' + type(u).__name__ + ': ' + str(u)[:100]
            rows.append(rec)
            continue
        try:
            init, body = split_source(src, arch)
            regs = parse_init(init)
            ind = [run_thread(arch, ins, t + 1, regs.get(t, {})) for t, ins in enumerate(threads_of(body))]
        except Unmodelled as u:
            rec['class'] = 'UNFAITHFUL'
            rec['detail'] = 'shipped accepted addressing the model cannot represent: ' + str(u)[:120]
            rows.append(rec)
            continue
        except Unsupported as u:
            rec['class'] = 'UNVALIDATED'
            rec['detail'] = str(u)[:140]
            rows.append(rec)
            continue
        except Exception as x:
            rec['class'] = 'UNVALIDATED'
            rec['detail'] = 'independent error ' + repr(x)[:120]
            rows.append(rec)
            continue
        problems = []
        # 1. shape: kinds + locations per thread
        sh = collections.defaultdict(list)
        id2pos = {}
        for r in ev[test]:
            sh[int(r['thread'])].append(r)
            id2pos[r['id']] = (int(r['thread']), int(r['ord']))
        ind_shape = {t + 1: [(k, l) for k, l, _ in e] for t, e in enumerate(ind) if e}
        shp_shape = {t: [(r['kind'], r['loc'] if r['kind'] != 'F' else None) for r in rs] for t, rs in sh.items()}
        if ind_shape != shp_shape:
            problems.append('shape: shipped=%s indep=%s' % (fmt(shp_shape), fmt(ind_shape)))
        else:
            # 2. data pairs
            ipairs = set()
            for t, e in enumerate(ind):
                for o, (k, l, v) in enumerate(e):
                    if k == 'W':
                        for sy in syms(v, set()):
                            if sy[0] == 'L':
                                ipairs.add((sy[1], sy[2], t + 1, o))
                            else:
                                rec['free_init_dep'] = True
            spairs = {(int(r['prod_thread']), int(r['prod_ord']), int(r['cons_thread']), int(r['cons_ord']))
                      for r in ed.get(test, []) if r['kind'] == 'DATA'}
            rec['n_data_pairs'] = len(ipairs)
            if ipairs != spairs:
                problems.append('data pairs: shipped-only=%s indep-only=%s' % (sorted(spairs - ipairs), sorted(ipairs - spairs)))
            # 3. values: composed (shipped grammar) vs independent; folded value at zero valuation
            for t, e in enumerate(ind):
                for o, (k, l, v) in enumerate(e):
                    if k != 'W':
                        continue
                    r = sh[t + 1][o]
                    try:
                        comp = ShippedParser(r['composed'], lambda n: ('L',) + id2pos[n[1:]] if re.fullmatch(r'R\d+', n) else ('c', 0)).parse()
                    except (Unsupported, KeyError) as u:
                        problems.append('composed unparseable at T%d#%d: %s' % (t + 1, o, r['composed']))
                        continue
                    for i in range(NVAL):
                        nu = collections.defaultdict(lambda: rnd.choice([0, 1, 2, MASK, 0x80000000, rnd.getrandbits(32)]))
                        for sy in syms(v, set()):
                            if sy[0] == 'I':
                                nu[sy] = 0          # implementation pins unbound registers to 0
                        a, b = ev_term(v, nu), ev_term(comp, nu)
                        if a != b:
                            problems.append('value T%d#%d: indep=%s composed=%s (%d vs %d)' % (t + 1, o, show(v), r['composed'], a, b))
                            break
                    zero = collections.defaultdict(int)
                    if not syms(v, set()) and str(ev_term(v, zero) - (1 << 32) if ev_term(v, zero) & 0x80000000 else ev_term(v, zero)) != r['value']:
                        problems.append('folded constant T%d#%d: indep=%d shipped=%s' % (t + 1, o, ev_term(v, zero), r['value']))
        rec['class'] = 'UNFAITHFUL' if problems else 'FAITHFUL'
        rec['detail'] = ' | '.join(problems)[:600]
        rows.append(rec)
    with open(out + '-gate.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    c = collections.Counter(r['class'] for r in rows)
    print(out, dict(c))


def fmt(d):
    return ' '.join('%d:%s' % (t, ''.join(k + (('(' + l + ')') if l else '') for k, l in v)) for t, v in sorted(d.items()))


def show(e):
    if e[0] == 'c':
        return str(e[1])
    if e[0] in ('L', 'I'):
        return '%s%s_%s' % e
    if e[0] in ('neg', 'not'):
        return ('-' if e[0] == 'neg' else '~') + show(e[1])
    return '(%s%s%s)' % (show(e[1]), e[0], show(e[2]))


if __name__ == '__main__':
    main()
