"""Eligibility contract and per-test statuses for the reconstructed 12,324-file source
population (read-only; inputs are the audit's own dumps and gates plus the source files).

Evaluated semantics (what the shipped commands actually compute):
  FIXED-OUTCOME QUERY: "is there an execution of the parsed straight-line event structure,
  with every event active, that satisfies the conjunction of pinned read values
  (existsReadValues) and — in symbolic mode only — memory-final values (existsMemFinal),
  and is consistent under model M?"  The litmus quantifier is not read.
  SOURCE-LITMUS VERDICT: the herd question for the test's own quantifier. exists P and
  ~exists P both ask whether P is reachable, so they coincide with the fixed-outcome query
  on P; forall P asks whether ¬P is unreachable, a different query.

Mutually exclusive status (source-litmus verdict claims), by priority:
  EXPLICITLY-UNSUPPORTED  the parser rejects the test (ParseException)
  KNOWN-INCORRECT         parsed, but the query provably differs from the source semantics:
                          extraction UNFAITHFUL; outcome ERRONEOUS; control flattened
                          (guards ignored, every event active); RMW present (RMW read is fixed
                          to the initial value, written value is a placeholder); sub-word
                          access; non-conjunctive outcome accepted; non-zero typed initial
                          value dropped (non-AArch64); forall quantifier; no outcome clause
  UNCHECKED               parsed, no known defect, but some gate could not confirm it:
                          extraction UNVALIDATED / EMPTY-UNVALIDATED; outcome UNCHECKED;
                          64-bit accesses outside AArch64 (no width tracking); a memory atom
                          on a location the program never accesses (non-AArch64: dropped)
  ELIGIBLE                extraction FAITHFUL or independently confirmed EMPTY, outcome
                          FULLY-BOUND, and none of the above
Flags are also kept in separate columns.

Usage: python -I -X utf8 eligibility.py <prov_dir> <corpus_root>
"""
import collections
import csv
import os
import re
import sys

P, ROOT = sys.argv[1:3]


def rd(path, key):
    with open(path, encoding='utf-8') as f:
        return {r[key]: r for r in csv.DictReader(f)}


man = rd(os.path.join(P, 'manifests', 'manifest-paper-12324.csv'), 'path')
ext = rd(os.path.join(P, 'src12324', 'corpus-gate.csv'), 'test')
out = rd(os.path.join(P, 'src12324', 'outcome-gate.csv'), 'test')
ctrl_tests, locs_accessed = set(), collections.defaultdict(set)
with open(os.path.join(P, 'src12324', 'corpus', 'edges.csv'), encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['kind'] == 'CTRL':
            ctrl_tests.add(r['test'])
with open(os.path.join(P, 'src12324', 'corpus', 'events.csv'), encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['loc']:
            locs_accessed[r['test']].add(r['loc'])

BRANCH = {
    'ARM': r'(?im)(^|[|;\s])(b|bl|br|cbz|cbnz|tbz|tbnz|b\.\w+|beq|bne)\s|^\s*\w+:|\|\s*\w+:',
    'PPC': r'(?im)(^|[|;\s])(b|beq|bne|blt|bgt|ble|bge|bl|bc)\s|^\s*\w+:|\|\s*\w+:',
    'RISCV': r'(?im)(^|[|;\s])(beq|bne|blt|bge|bltu|bgeu|j|jal|jalr|beqz|bnez)\s|^\s*\w+:|\|\s*\w+:',
    'X86': r'(?im)(^|[|;\s])(j\w+|loop)\s|^\s*\w+:|\|\s*\w+:',
    'C': r'(?<![\w])(if|while|for|else|goto)\b|\?',
}
RMW = {
    'ARM': r'(?i)\b(swp\w*|ldadd\w*|ldclr\w*|ldeor\w*|ldset\w*|ldsmax\w*|ldumax\w*|cas\w*|ldxr\w*|stxr\w*|ldaxr\w*|stlxr\w*|ldxp|stxp)\b',
    'PPC': r'(?i)\b(lwarx|stwcx\.|ldarx|stdcx\.|lbarx|stbcx\.)',
    'RISCV': r'(?i)\b(amo\w+(\.\w+)*|lr\.[wd]\w*|sc\.[wd]\w*)\b',
    'X86': r'(?i)\b(xchg|cmpxchg|xadd|lock)\b',
    'C': r'(?i)\b(xchg\w*|cmpxchg\w*|atomic_(exchange|fetch_\w+|compare_exchange\w*|add_return\w*|inc_return\w*|dec_return\w*|sub_return\w*|xchg\w*|cmpxchg\w*|add|sub|inc|dec)|spin_\w+|__atomic\w*|fetch_\w+)\b',
}
SUBWORD = {
    'ARM': r'(?i)\b(ld\w*r[bh]|st\w*r[bh]|ldrs[bhw]|ldurs?[bh]|sturs?[bh]|ldapr[bh]|stlr[bh]|ldar[bh])\b|\b[bh]\d+\b',
    'PPC': r'(?i)\b(lbz\w*|lhz\w*|lha\w*|stb\w*|sth\w*)\b',
    'RISCV': r'(?i)\b(lbu?|lhu?|sb|sh)\b',
    'X86': r'(?i)\b(al|ah|bl|bh|cl|ch|dl|dh|ax|bx|cx|dx|si|di|byte|word)\b',
    'C': r'(?i)\b(char|short|u?int8_t|u?int16_t|__u8|__u16|__s8|__s16)\b',
}
WIDE = {
    'PPC': r'(?i)\b(ld|ldx|std|stdx|ldu|stdu)\b',
    'RISCV': r'(?i)\b(ld|sd|lwu)\b',
    'X86': r'(?i)\b(r[a-ds]x|r[sd]i|r\d+|qword)\b',
}
TYPED_INIT_NONZERO = r'(?:^|;|\{)\s*(?:unsigned\s+)?[A-Za-z_]\w*\s+\*?\s*(?:\d+\s*:\s*)?[A-Za-z_]\w*\s*=\s*(-?(?:0x[0-9a-fA-F]+|\d+))'


def split(src):
    txt = re.sub(r'\(\*.*?\*\)', ' ', src, flags=re.S)
    i, j = txt.find('{'), txt.find('}')
    init = txt[i + 1:j] if 0 <= i < j else ''
    m = re.search(r'^\s*((?:~\s*)?exists|forall)\b(.*)\Z', txt[j + 1:], re.S | re.M)
    body = txt[j + 1:j + 1 + (m.start() if m else len(txt) - j - 1)]
    return init, body, ((m.group(1).replace(' ', ''), m.group(2)) if m else (None, ''))


rows = []
for path, mrow in man.items():
    src = open(os.path.join(ROOT, path), encoding='utf-8', errors='replace').read()
    e, o = ext[path], out[path]
    arch = e['arch'] or o['arch']
    init, body, (quant, clause) = split(src)
    a = arch if arch in BRANCH else None
    f = {
        'quantifier': quant or 'none',
        'nonconj_outcome': bool(re.search(r'\\/|(?<![/])~(?!\s*exists)', clause)),
        'control': path in ctrl_tests or bool(a and re.search(BRANCH[a], body)),
        'rmw': bool(a and re.search(RMW[a], body)),
        'subword': bool(a and (re.search(SUBWORD[a], body) or (a == 'C' and re.search(SUBWORD['C'], init)))),
        'wide_nonarm': bool(a in WIDE and re.search(WIDE[a], body)),
        'typed_init_dropped': bool(arch != 'ARM' and any(int(v, 0) != 0 for v in re.findall(TYPED_INIT_NONZERO, init))),
        'mem_atom_unaccessed': False,
    }
    if arch != 'ARM' and quant:
        for loc in re.findall(r'(?<![\w:\[])\[?\s*([A-Za-z_]\w*)\s*\]?\s*=\s*-?\d', re.sub(r'\d+\s*:\s*\w+\s*=', '', clause)):
            if loc not in locs_accessed.get(path, set()) and e['class'] not in ('EXCLUDED',):
                f['mem_atom_unaccessed'] = True
    reasons = []
    if e['class'] == 'EXCLUDED':
        status = 'EXPLICITLY-UNSUPPORTED'
        reasons.append('parser: ' + (o['shipped_reason'] or e['shipped_status'])[-120:])
    else:
        ki = []
        if e['class'] == 'UNFAITHFUL':
            ki.append('extraction UNFAITHFUL')
        if o['outcome'] == 'ERRONEOUS':
            ki.append('outcome ERRONEOUS')
        for k, why in (('control', 'control flattened'), ('rmw', 'RMW values not modelled'),
                       ('subword', 'sub-word access'), ('nonconj_outcome', 'non-conjunctive outcome'),
                       ('typed_init_dropped', 'non-zero typed initial value dropped')):
            if f[k]:
                ki.append(why)
        if f['quantifier'] == 'forall':
            ki.append('forall quantifier (fixed-outcome query is not the litmus question)')
        if f['quantifier'] == 'none':
            ki.append('no outcome clause')
        un = []
        if e['class'] in ('UNVALIDATED', 'EMPTY-UNVALIDATED'):
            un.append('extraction ' + e['class'])
        if o['outcome'] == 'UNCHECKED':
            un.append('outcome UNCHECKED')
        if f['wide_nonarm']:
            un.append('64-bit access without width tracking')
        if f['mem_atom_unaccessed']:
            un.append('memory atom on an unaccessed location')
        if ki:
            status, reasons = 'KNOWN-INCORRECT', ki + un
        elif un:
            status, reasons = 'UNCHECKED', un
        elif e['class'] in ('FAITHFUL', 'EMPTY') and o['outcome'] == 'FULLY-BOUND':
            status = 'ELIGIBLE'
        else:
            status, reasons = 'UNCHECKED', ['extraction %s / outcome %s' % (e['class'], o['outcome'])]
    fixed_ok = status == 'ELIGIBLE' or (status == 'KNOWN-INCORRECT' and reasons and all(
        r.startswith('forall') for r in reasons))
    rows.append({'path': path, 'sha256': mrow['sha256'], 'norm_sha256': mrow['norm_sha256'], 'arch': arch,
                 'in_manifest_v2': mrow['in_manifest_v2'], 'status': status,
                 'fixed_outcome_query_eligible': fixed_ok,
                 'extraction': e['class'], 'outcome': o['outcome'], **f, 'reasons': ' ; '.join(reasons)})

with open(os.path.join(P, 'per-test-status.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)

n = lambda pred: sum(1 for r in rows if pred(r))
print('source population:', len(rows))
for lab, pred in (('all 12,324', lambda r: True), ('manifest-v2', lambda r: r['in_manifest_v2'] == 'True')):
    sub = [r for r in rows if pred(r)]
    print('\n== %s (%d)' % (lab, len(sub)))
    for k, v in collections.Counter(r['status'] for r in sub).most_common():
        print('   %-24s %5d' % (k, v))
    el = [r for r in sub if r['status'] == 'ELIGIBLE']
    print('   eligible distinct programs (normalised content): %d;  by arch %s' % (
        len({r['norm_sha256'] for r in el}), dict(collections.Counter(r['arch'] for r in el))))
    print('   fixed-outcome-query eligible: %d' % sum(1 for r in sub if r['fixed_outcome_query_eligible']))
    ki = collections.Counter()
    for r in sub:
        if r['status'] == 'KNOWN-INCORRECT':
            for x in r['reasons'].split(' ; '):
                ki[re.sub(r' \(.*', '', x)] += 1
    print('   known-incorrect reasons (a test may have several):', dict(ki.most_common()))
    uc = collections.Counter()
    for r in sub:
        if r['status'] == 'UNCHECKED':
            for x in r['reasons'].split(' ; '):
                uc[x] += 1
    print('   unchecked reasons:', dict(uc.most_common()))
    print('   flags among parsed tests:', {k: sum(1 for r in sub if r['extraction'] != 'EXCLUDED' and r[k] not in (False, 'False', 'exists', '~exists'))
                                         for k in ('quantifier', 'control', 'rmw', 'subword', 'wide_nonarm', 'nonconj_outcome',
                                                   'typed_init_dropped', 'mem_atom_unaccessed')})
