"""Freeze the final-evaluation population (read-only inputs; writes under the audit dir).

Layers: source (12,324 reconstructed) → parser-supported → independently validated
(extraction FAITHFUL/confirmed-EMPTY ∧ outcome FULLY-BOUND) → verdict-eligible (contract).
Adds per-test mode flags: wired_fallback (wired mode wires a pinned read to the initial
write because no write has the value) and mem_atoms (memory-final atoms; encoded only in
symbolic mode).

Usage: python -I -X utf8 freeze.py <prov_dir> <corpus_root> <imm_repair_dir>
"""
import collections
import csv
import hashlib
import os
import re
import sys

P, ROOT, I = sys.argv[1:4]
with open(os.path.join(P, 'per-test-status.csv'), encoding='utf-8') as f:
    rows = list(csv.DictReader(f))
with open(os.path.join(P, 'manifests', 'manifest-paper-12324.csv'), encoding='utf-8') as f:
    man = {r['path']: r for r in csv.DictReader(f)}
with open(os.path.join(P, 'src12324', 'outcomes.csv'), encoding='utf-8') as f:
    oc = {r['test']: r for r in csv.DictReader(f)}
fallback = set(re.findall(r'^\[([^\]]+?\.litmus)\] no write of value', open(os.path.join(P, 'wiring', 'stderr.txt'), encoding='utf-8', errors='replace').read(), re.M))
new258 = {l.strip() for l in open(os.path.join(I, 'impact', 'newly-parsing-not-gated.txt'), encoding='utf-8') if l.strip()}

real_addr, n_events = set(), collections.Counter()
with open(os.path.join(P, 'src12324', 'corpus', 'edges.csv'), encoding='utf-8') as f:
    for e in csv.DictReader(f):
        if e['kind'] == 'ADDR' and e['semantic'] == 'true':
            real_addr.add(e['test'])
with open(os.path.join(P, 'src12324', 'corpus', 'events.csv'), encoding='utf-8') as f:
    for e in csv.DictReader(f):
        if e['status'] == 'ok':
            n_events[e['test']] += 1

for r in rows:
    # Post-pass refinements of the contract (see report §2):
    #  * a parser crash is a tool defect, not an explicit rejection;
    #  * the stated configuration bounds programs at 64 events;
    #  * register-index addressing resolves to the base location, exact only for a zero
    #    index — a real (value-carrying) address dependency is unchecked.
    r['parser_crash'] = oc[r['path']]['status'].startswith('ERROR')
    r['over_event_bound'] = n_events[r['path']] > 64
    r['real_addr_index'] = r['path'] in real_addr
    if r['parser_crash']:
        r['status'], r['reasons'] = 'KNOWN-INCORRECT', 'parser crash: ' + oc[r['path']]['status'][:90]
    elif r['status'] == 'ELIGIBLE' and r['over_event_bound']:
        r['status'], r['reasons'] = 'EXPLICITLY-UNSUPPORTED', 'exceeds the stated 64-event bound (%d events)' % n_events[r['path']]
    elif r['status'] == 'ELIGIBLE' and r['real_addr_index']:
        r['status'], r['reasons'] = 'UNCHECKED', 'real address dependency: index value assumed 0 by the location model'
    if r['status'] != 'ELIGIBLE':
        r['fixed_outcome_query_eligible'] = r['fixed_outcome_query_eligible'] == 'True' and not (
            r['parser_crash'] or r['over_event_bound'] or r['real_addr_index'])
    r['git_blob'] = man[r['path']]['git_blob']
    r['wired_fallback'] = r['path'] in fallback
    r['mem_atoms'] = bool(oc[r['path']]['mem_final'])
    r['new258'] = r['path'] in new258
    r['validated'] = r['extraction'] in ('FAITHFUL', 'EMPTY') and r['outcome'] == 'FULLY-BOUND'

cols = ['path', 'sha256', 'git_blob', 'norm_sha256', 'arch', 'in_manifest_v2', 'new258', 'status',
        'fixed_outcome_query_eligible', 'validated', 'extraction', 'outcome', 'quantifier', 'nonconj_outcome',
        'control', 'rmw', 'subword', 'wide_nonarm', 'typed_init_dropped', 'mem_atom_unaccessed',
        'mem_atoms', 'wired_fallback', 'parser_crash', 'over_event_bound', 'real_addr_index', 'reasons']
with open(os.path.join(P, 'frozen-population-12324.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
    w.writeheader()
    w.writerows(rows)
elig = sorted((r for r in rows if r['status'] == 'ELIGIBLE'), key=lambda r: r['path'])
with open(os.path.join(P, 'frozen-eligible-manifest.csv'), 'w', newline='', encoding='utf-8') as f:
    for r in elig:
        f.write(r['path'] + '\n')
with open(os.path.join(P, 'frozen-eligible-hashes.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['path', 'sha256', 'git_blob', 'norm_sha256', 'arch', 'mem_atoms', 'wired_fallback'])
    for r in elig:
        w.writerow([r['path'], r['sha256'], r['git_blob'], r['norm_sha256'], r['arch'], r['mem_atoms'], r['wired_fallback']])
digest = hashlib.sha256(open(os.path.join(P, 'frozen-eligible-manifest.csv'), 'rb').read()).hexdigest()
open(os.path.join(P, 'frozen-eligible-manifest.sha256'), 'w').write(digest + '  frozen-eligible-manifest.csv\n')

n = lambda S, pred: sum(1 for r in S if pred(r))
print('frozen eligible manifest sha256:', digest)
for lab, S in (('source 12,324', rows), ('manifest-v2 2,972', [r for r in rows if r['in_manifest_v2'] == 'True']),
               ('newly parsing 258', [r for r in rows if r['new258']])):
    sup = [r for r in S if r['extraction'] != 'EXCLUDED']
    val = [r for r in S if r['validated']]
    el = [r for r in S if r['status'] == 'ELIGIBLE']
    print('== %s: denominator %d | parser-supported %d | independently validated %d | verdict-eligible %d '
          '(distinct programs %d; exact-byte distinct %d) | known-incorrect %d | unchecked %d | unsupported %d' % (
              lab, len(S), len(sup), len(val), len(el), len({r['norm_sha256'] for r in el}), len({r['sha256'] for r in el}),
              n(S, lambda r: r['status'] == 'KNOWN-INCORRECT'), n(S, lambda r: r['status'] == 'UNCHECKED'),
              n(S, lambda r: r['status'] == 'EXPLICITLY-UNSUPPORTED')))
    print('     eligible by arch %s; with memory atoms %d; wired-mode fallback %d' % (
        dict(collections.Counter(r['arch'] for r in el)), n(el, lambda r: r['mem_atoms']), n(el, lambda r: r['wired_fallback'])))

# parser rejection reasons (source population)
cat = collections.Counter()
for r in rows:
    if r['status'] != 'EXPLICITLY-UNSUPPORTED':
        continue
    s = oc[r['path']]['status']
    if 'UNSUPPORTED_ARCH' in s:
        k = 'unsupported architecture'
    elif 'EMPTY' in s.split(':')[1:2] or 'EMPTY:' in s:
        k = 'empty file'
    elif 'MALFORMED' in s:
        k = 'malformed'
    elif 'AArch64 outcome' in s:
        k = 'AArch64 unsupported outcome form'
    elif 'initial value' in s:
        k = 'unmodelled initial value'
    elif 'AArch64' in s:
        k = 'AArch64 width/SP/addressing'
    elif 'post-index' in s or 'not bound' in s:
        k = 'unbound / written-back base register'
    elif 'UNSUPPORTED_INSTRUCTION' in s:
        k = 'unsupported instruction (incl. labels/branches)'
    else:
        k = 'other: ' + s[:60]
    cat[k] += 1
print('parser rejection reasons (source population):')
for k, v in cat.most_common():
    print('   %5d %s' % (v, k))
