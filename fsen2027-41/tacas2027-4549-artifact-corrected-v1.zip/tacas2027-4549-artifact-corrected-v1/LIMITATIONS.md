# Limitations of this artifact

(Items 1-8 and the sections up to "Eligibility gates" are from the 2026-10-12 package; the
corrected-v1 additions are at the end. The 2026-10-12 file is preserved under `history/`.)

## Reproducibility gaps (why the status is PARTIAL)

1. **Hard-benchmark generator.** The original enumerate/filter script is lost. The packaged
   script is a labelled reconstruction. It reproduces the recorded candidate file
   byte-for-byte and the 13,880 intermediate count, but it cannot prove what the original
   code was.
2. **Carried results** are packaged but not re-run by the checks:
   - n-thread admission;
   - scalability sweep;
   - Dat3M timings and comparison;
   - Dat3M/LKMM over Table 2's instances;
   - matched-pair sweep;
   - bitwidth synthesis.

   They come from earlier runs on inputs the repairs did not change.
3. **Recorded experiment.** The pre-fix classifier-defect measurement (218/8448 unsound; 293
   unsound across 55 shapes when the fix is reverted) cannot be re-derived from the fixed
   snapshot. Its records are in `results/carried/classifier-defect-records/`.
4. **Full corpus reruns** (about 10 minutes per mode) are documented but not part of the
   checks. The checks re-run Table 2 in full, a 30-file six-model subset and the whole
   chain experiment.
5. **External tools are not shipped:**
   - herd7 7.58 and its cat files;
   - Dat3M v4.4.1;
   - the third-party Maven jars, pinned by SHA-256 in `impl/DEPENDENCIES.txt`;
   - the Z3 native libraries, the `javasmt-solver-z3:4.13.0` Windows-x64 classifier artifacts.

   On Linux, the pom's Linux profile stages the corresponding `.so` files, whose hashes are
   not pinned here.

   *corrected-v1 (2026-10-19):* the Maven jars and the Z3 natives for Windows x64 **and Linux
   x64** are now bundled in `deps/` with pinned SHA-256s (`deps/NATIVES.txt`); herd7 and Dat3M
   are still not shipped.
6. **No revision identifies the evaluated tree.** It was an uncommitted working tree,
   identified only by the snapshot, class, jar and native hashes in `impl/PIN.txt`.
7. **Timing-dependent columns** (`solve_ms`, `C_ms`, `*_time_ms`, `query_ms`, `dat3m_secs`)
   are not expected to reproduce. Verdict, classification and count columns are.
8. **Solver-dependent values.** The chain experiment's witness values (`pairs-final.csv`
   `witness`, and the witness lines of `traces.md`) are z3-chosen counterexamples, and z3
   may return different models on different runs. The verdicts are unaffected. The check
   therefore requires an execution-confirmed witness for every real pair rather than
   identical values. One clean run showed 23 differing witness values.

## Scientific limitations (from the paper, restated)

**Formal results.**
- They cover data dependencies in branch-free straight-line code. Address dependencies are
  implemented and audited, but carry no theorem.
- Control is covered only on the fragment F0. The front end retains every control edge.
- No claim is made about prevalence, compilation correctness, DRF, or IMM/CAT encodings.

**Corpus verdicts.**
- They are fixed-outcome queries on branch-free inputs, with all events active and BV32
  values.
- Only 19.4% of the sample is eligible.
- Known front-end defects are excluded, not fixed.

**Fidelity audits.** Classifier and closure fidelity are audited, not proved. The
374-pair comparison uses the front end's own composed expressions, and 368 of the pairs are
one idiom.

**Chain experiment.**
- The population is constructed: counts reflect the templates, not any frequency.
- Only the C front end is exercised.
- No candidate verdicts are computed.
- Its reference and its exact local oracle share Z3.

## Omitted material

These are deliberately not packaged:
- **Development history and working notes:** session transcripts, audit reports, research
  notes, git metadata.
- **Superseded repository tables:** `corpus-validation-*.csv`, from a build that encoded
  neither fences nor RMW atomicity; and earlier herd7 runs on a different input list.
- **Litmus files outside the 12,324 sample**, and the generated Dat3M inputs
  (`eval/generated-dat3m/`). The latter are derivable from the candidate list by
  `drivers/dat3m-lkmm/dat3m_lkmm_hardbench.py`.
- **Third-party binaries** (see item 5 above).

## Eligibility gates and provenance tools (added 2026-10-11)

- **Sampled, not proved.**
  - The extraction gate (`provenance/gates/gate.py`) compares write values on 40
    valuations per write.
  - The outcome gate (`outcome_gate.py`) classifies outcome atoms on 160 random plus
    forced valuations. Its confirmation of AArch64 width handling (X-named observations
    need zero upper bits) is therefore sampling-based.
  - Both gates use fixed seeds, so they are deterministic and reproduce byte-identically,
    but they are evidence, not proofs.
- **Shared abstraction.** Both gates resolve accesses to base locations, as the encoder
  does. For register-indexed accesses this abstraction is checked exactly and
  population-wide by `address-check/`: 202/202 offsets proved zero. No other addressing
  form is certified beyond the gates' rejection rules.
- **Inputs not regenerated by stage 7:**
  - the population manifest `manifest-paper-12324.csv` (from the provenance replay);
  - the wired-run `stderr.txt` (sets the `wired_fallback` flag for 3 files);
  - the `newly-parsing-not-gated.txt` list.

  They are packaged as recorded inputs.
- **No original command logs.** None survive for the original gate runs. The documented
  usage lines are what stage 7 runs, and they reproduce every recorded output exactly.
- **`gate2.py`** is packaged as `outcome_gate.py`'s import. Its own `main` does not run,
  and it is not the extraction gate.

## Added in corrected-v1 (2026-10-19)

1. **Known implementation defect in the submitted build** (E4 / `CORRECTION-NOTICE.md` C-1).
   The submitted build's results are kept unchanged as the record behind the manuscript; 12
   of their 14,376 verdicts are wrong. Use `results/corrected-v1/` for correct values.
2. **Separate reference checker is not independent.** It shares the parser, Z3 (BV32 value
   reasoning) and model rules transcribed from the paper/Javadoc with the implementation; it
   is not an external semantics. Its agreement (14,376/14,376) supports, but does not prove,
   the corrected verdicts.
3. **External tools not re-run for the correction:** herd7 7.58, Dat3M v4.4.1 and DFSan were
   not executed; their comparisons are recomputed against recorded rows (only SC/TSO cells are
   involved for herd7, and those are unchanged). Source-paper verdict transcriptions
   (`evidence/transcriptions/`) were not re-derived from the cited papers.
4. **Well-formedness argument is paper-level.** The proposed Lemma "Well-formedness adequacy"
   covers the corrected `EventStructureEncoder` (all events active); it is not mechanised, and
   the gated `MinimalWitnessExtractor` variant is checked by regression tests only.
5. **Parser value-model limitations** (audit F-20; gated out of the eligible population, no
   effect on eligible verdicts found): `opSym` defaults to `+` for `mr`, `neg`, `mvn`; the
   `subf` operand order is swapped; `CMP W1,#0` reaches the oracle as `X1,#0` (one Layer-2 row,
   MP01, conservative); non-ARM outcome binding uses the last load.
6. **Platforms.** Results were produced on Windows 11 x64. The Linux x64 route was tested on
   Ubuntu 24.04 under WSL2 with user-space toolchains (`VERIFICATION-SUMMARY.md`), not on the
   (unpublished) TACAS 2027 VM. The Dockerfile's test status is stated in `INSTALL-LINUX.md`.
   macOS and ARM are not supported (no natives bundled).
7. **Model library licence** is to be confirmed by the author (`impl/deps/MODEL-JAR-PROVENANCE.md`).
8. **Runtimes** are measured on one machine with other jobs running; treat them as guidance.

