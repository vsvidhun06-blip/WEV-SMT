# Third-party material

(corrected-v1 package, 2026-10-19. The 2026-10-12 version, which stated that no Maven dependency was redistributed, is preserved in `history/package-20261012/THIRD-PARTY-NOTICES.md`.)

**Original material.** `LICENSE` covers the original code and data of this artifact; see its scope list.

## Redistributed under the upstream terms, with notices kept verbatim

- `corpus/litmus/Dat3M/**`: Dat3M / Dartagnan litmus tests. MIT-style licence; see `corpus/litmus/Dat3M/LICENCE`.
- `corpus/litmus/herdtools7/**`: herdtools7 litmus tests. CeCILL-B; some catalogue subdirectories carry joint copyright with Arm Ltd. See `corpus/litmus/herdtools7/LICENSE.txt`.
- `inputs/examples/**`: example programs transcribed from the cited publications (Weakestmo, PwT / "The Leaky Semicolon", the Java Memory Model causality tests), used for comparison as in the paper.

## Bundled dependencies (`deps/`), new in corrected-v1

**Contents.** `deps/m2/` holds, in Maven layout and unmodified:
- every runtime jar pinned in `impl/DEPENDENCIES.txt`;
- the Z3 natives for Windows x64 and Linux x64 (`deps/NATIVES.txt`);
- the JUnit console launcher used by stage 9;
- the POMs that declare each licence;
- the corresponding source jars of the two LGPL components.

**Source and integrity.** Every file was downloaded from Maven Central (`https://repo1.maven.org/maven2/`) on 2026-10-19 and verified against the Maven `.sha1`. The pinned jars and the Windows natives equal the SHA-256 pins recorded for the submitted build.

**Per-file details.** `deps/DEPENDENCIES.csv` gives, for every file: coordinates, SHA-256, origin URL, declared licence and licence-text file.

| Component | Licence (as declared in its POM) | Licence text in package |
|---|---|---|
| JavaSMT 5.0.1, sosy-lab common | Apache-2.0 | `deps/licenses/Apache-2.0.txt` |
| javasmt-solver-z3 4.13.0 (Z3 4.13.0 jar and natives) | MIT (Z3: Copyright Microsoft Corporation) | `deps/licenses/Z3-MIT-LICENSE.txt` |
| Guava 33.2.1, failureaccess, listenablefuture, error_prone_annotations, j2objc-annotations, jsr305 | Apache-2.0 | `deps/licenses/Apache-2.0.txt` |
| checker-qual 3.44.0 | MIT | `deps/licenses/checker-framework-LICENSE.txt` |
| animal-sniffer-annotations 1.18 | MIT | `deps/licenses/animal-sniffer-MIT-LICENSE.txt` |
| Scala library 2.13.10, scala-parser-combinators 1.1.2 | Apache-2.0 (Scala NOTICE included) | `deps/licenses/Apache-2.0.txt`, `deps/licenses/scala-library-NOTICE.txt` |
| Princess 2024-01-12 (core, parser, smt-parser) | BSD-3-Clause | `deps/licenses/princess-BSD-3-Clause-LICENSE.txt` |
| java-cup 0.11a | CUP Parser Generator Copyright Notice, License, and Disclaimer (permissive). The POM's URL points at the SML/NJ licence page; the text included is the CUP notice from the CUP home page | `deps/licenses/CUP-NOTICE.txt` |
| SMTInterpol 2.5-1242-g5c50fb6d | **LGPL-3.0**; the corresponding source jar is bundled | `deps/licenses/LGPL-3.0.txt`, `GPL-3.0.txt`, `smtinterpol-LICENSE.txt` |
| spotbugs-annotations 4.8.6 | **LGPL-2.1**; the corresponding source jar is bundled | `deps/licenses/LGPL-2.1.txt` |
| junit-platform-console-standalone 1.11.3 (stage 9 only) | EPL-2.0 (bundled sub-licences are inside the jar) | `deps/licenses/EPL-2.0.txt` |

All components are redistributed unmodified. The two LGPL libraries are shipped with their corresponding source jars from Maven Central. Upstream copyright notices inside the jars are untouched.

## The project's model library

`impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar` and its shipped `com.weakest.model` sources (`impl/deps/model-source/`) are described in `impl/deps/MODEL-JAR-PROVENANCE.md`. Their licence is **to be confirmed by the author**.

## Not redistributed

| Item | How to obtain |
|---|---|
| JDK 21 | Eclipse Temurin 21.0.10+7 (GPLv2 with Classpath Exception) |
| Isabelle2024 | isabelle.in.tum.de, under its own distribution terms |
| Python `z3-solver` 5.0.0.0 | PyPI, MIT |
| herd7 7.58 | herdtools7, CeCILL-B |
| Dat3M v4.4.1 | upstream |

Exact versions, URLs and SHA-256s are in `INSTALL-LINUX.md`.
