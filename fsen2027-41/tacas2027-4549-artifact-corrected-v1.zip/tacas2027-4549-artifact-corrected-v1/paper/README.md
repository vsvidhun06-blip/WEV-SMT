# Paper files

## `submitted/`: the manuscript under review (unchanged)

| File | SHA-256 | Provenance |
|---|---|---|
| `TACAS27_paper__4549.pdf` | `1241dc829cfa1ccc352442ae0216fdf1b25c89cbd2f2edc832cc961f3aefc792` | the exact PDF submitted to TACAS 2027 as paper #4549, copied byte-for-byte. 37 pages, no Info dictionary |
| `wev-smt.tex` | `0e9609976ff5257029053fb5e144b098e936eae18a61962ca044b86b63072404` | the manuscript source matching that PDF; it contains the "Use of Generative AI" section (tex L1890–1894) |
| `refs.bib` | `f25ce89898ddb32890b3cd6f136133eaea3a42f4b83d7525f6f3ed1d40f7b447` | the bibliography (byte-identical to the 2026-10-12 package's copy) |

**Correspondence.**
- The source was rebuilt with `llncs`/`splncs04`, MiKTeX pdfTeX, and pdflatex, bibtex, pdflatex ×2. It gives 37 pages.
- The rebuilt PDF's `pdftotext -layout` output is **identical** to the submitted PDF's (`correction-record/audit-2026-10-17/`, `correction-record/investigation-2026-10-18/baseline/hashes.txt`).
- The PDF **bytes differ** in build metadata (dates, producer). The correspondence is text equivalence, not byte identity.

**Layout of the submitted PDF:**
- main body pp. 1–18 (18-page limit);
- Appendix A pp. 19–33:
  - A.6 traceability;
  - A.7 DFSan;
  - A.8 chain;
  - A.9 synthesis;
  - A.10 evidence;
- Use of Generative AI and the Data Availability Statement on p. 33;
- references.

The submitted manuscript prints the submitted-build figures. That includes the four totals of §6.4 that `CORRECTION-NOTICE.md` (C-1) corrects. **It has not been modified.**

## `proposed-correction-NOT-SUBMITTED/`: a proposed correction, not approved and not submitted

| File | SHA-256 | What it is |
|---|---|---|
| `PROPOSED-PAPER-PATCH.diff` | `93013741c8caed08a56d4890c4dc6116f59f576f58ebd44e24ef7615039e45e7` | patch against `submitted/wev-smt.tex`; `patch --binary wev-smt.tex < PROPOSED-PAPER-PATCH.diff` reproduces the next file byte-for-byte (checked 2026-10-19) |
| `wev-smt.PROPOSED-NOT-SUBMITTED.tex` | `537e56eeda7eb015145f7297684a2500baa1338fdb627e6b374c42221dbf0a3a` | the patched source |
| `wev-smt.PROPOSED-NOT-SUBMITTED.pdf` | see `SHA256SUMS` | the build of the patched source (38 pp.). Every page is stamped "PROPOSED CORRECTION - NOT SUBMITTED" in the margins. The unstamped build had SHA-256 `a5eb398a56d3cc1ef864c4daf4653a44e492a5e8142518492d202b202d4bfed3` (`correction-record/investigation-2026-10-18/CORRECTIONS.md`) |

**What the patch changes:**
- the §6.4 totals, marked "corrected";
- the wired-mode description;
- the Prop. 1 scope sentence and caveat (iv);
- a new Lemma "Well-formedness adequacy";
- the (A3) evidence citation (copy program);
- the published-example interpretation;
- the earlier-sweep value-consistency subset;
- the scalability n-set;
- "byte-identical" → "deterministic outputs";
- the claim-checker wording (26/3/2).

**Length.**
- The main text is length-neutral: pages 1–19 end on the same lines as the submitted PDF.
- One compensating trim in §6.4 (M10) needs author approval.
- The appendix grows from 37 to 38 pages.

**Unchanged by the patch.** The "Use of Generative AI" section is identical to the submitted one (checked).

**Status.**
- This is **not** the paper under review, and it must not be presented as the official paper.
- Whether a correction may be made during review, and in what form, is for the TACAS 2027 chairs. That procedure is unresolved.

## Earlier copies

The 2026-10-12 package shipped a 36-page **pre-submission** manuscript (`wev-smt.pdf` `b8c8fb34…`, `wev-smt.tex` `b0584599…`). It lacked the AI-use section. Those files, and that package's `paper/README.md`, are preserved verbatim under `history/package-20261012/paper/`.
