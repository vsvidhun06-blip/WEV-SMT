#!/usr/bin/env bash
# Install the external toolchain for this artifact into ONE user-chosen directory (Linux x86_64).
# Nothing is installed system-wide, no sudo is used, and every download is SHA-256-checked.
#
#   bash tools/setup-linux-toolchain.sh <TOOLS_DIR>        # e.g. ~/wev-tools (must be writable)
#
# Downloads (official sources, pinned):
#   - Eclipse Temurin JDK 21.0.10+7 (Linux x64)                       ~207 MB
#   - Isabelle2024 (Linux bundle; needed only for stage 1)            ~691 MB  (SKIP_ISABELLE=1 to skip)
#   - z3-solver 5.0.0.0 wheel (manylinux_2_27_x86_64, from PyPI)        ~33 MB
# and creates a pip-less Python virtual environment holding exactly that wheel, using the
# system python3 (>= 3.8, with the venv module; on Debian/Ubuntu: package python3-venv).
# At the end it prints the environment variables for reproduce/run_all.sh.
set -euo pipefail
T="${1:?usage: setup-linux-toolchain.sh <TOOLS_DIR>}"
case "$(uname -s)-$(uname -m)" in Linux-x86_64) ;; *) echo "Linux x86_64 only (got $(uname -s)-$(uname -m))" >&2; exit 2 ;; esac
mkdir -p "$T/dl"; T="$(cd "$T" && pwd -P)"
fetch() {  # $1 file  $2 url  $3 sha256
  if [ ! -f "$T/dl/$1" ]; then echo "downloading $1"; curl -fSL --retry 3 -o "$T/dl/$1.part" "$2"; mv "$T/dl/$1.part" "$T/dl/$1"; fi
  echo "$3  $T/dl/$1" | sha256sum -c --quiet - || { echo "SHA-256 MISMATCH for $1 -- refusing to continue" >&2; exit 3; }
  echo "verified $1"
}
fetch OpenJDK21U-jdk_x64_linux_hotspot_21.0.10_7.tar.gz \
  'https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.10%2B7/OpenJDK21U-jdk_x64_linux_hotspot_21.0.10_7.tar.gz' \
  ea3b9bd464d6dd253e9a7accf59f7ccd2a36e4aa69640b7251e3370caef896a4
fetch z3_solver-5.0.0.0-py3-none-manylinux_2_27_x86_64.whl \
  'https://files.pythonhosted.org/packages/py3/z/z3-solver/z3_solver-5.0.0.0-py3-none-manylinux_2_27_x86_64.whl' \
  5571949b47abee67935aeb05db9e48af14ed96ceda18f6ff8b75eb3901bb9c54
if [ "${SKIP_ISABELLE:-0}" != 1 ]; then
  fetch Isabelle2024_linux.tar.gz 'https://isabelle.in.tum.de/website-Isabelle2024/dist/Isabelle2024_linux.tar.gz' \
    603aaaf8abea36597af3b0651d2c162a86c0a0dd4420766f47e5724039639267
fi

[ -x "$T/jdk-21.0.10+7/bin/java" ] || tar -xzf "$T/dl/OpenJDK21U-jdk_x64_linux_hotspot_21.0.10_7.tar.gz" -C "$T"
if [ "${SKIP_ISABELLE:-0}" != 1 ]; then
  [ -x "$T/Isabelle2024/bin/isabelle" ] || tar -xzf "$T/dl/Isabelle2024_linux.tar.gz" -C "$T"
fi
if [ ! -x "$T/pyenv/bin/python" ]; then
  python3 -m venv --without-pip "$T/pyenv"
  SP="$("$T/pyenv/bin/python" -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')"
  "$T/pyenv/bin/python" -c 'import sys, zipfile; zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])' \
    "$T/dl/z3_solver-5.0.0.0-py3-none-manylinux_2_27_x86_64.whl" "$SP"
fi
"$T/jdk-21.0.10+7/bin/java" -version 2>&1 | head -1
"$T/pyenv/bin/python" -I -c 'import z3; print("z3-solver", z3.get_version_string())'
cat <<EOF

Toolchain ready in $T. For reproduce/run_all.sh export:
  export PATH="$T/jdk-21.0.10+7/bin:\$PATH"
  export PYTHON="$T/pyenv/bin/python"
EOF
[ "${SKIP_ISABELLE:-0}" = 1 ] || echo "  export ISABELLE_HOME=\"$T/Isabelle2024\""
