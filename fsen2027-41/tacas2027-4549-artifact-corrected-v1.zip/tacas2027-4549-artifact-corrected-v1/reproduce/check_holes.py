"""Report proof holes ('sorry', 'oops') in Isabelle theories, ignoring comments (* ... *)
and cartouche text blocks (text/txt/section/... \\<open> ... \\<close> or ‹ ... ›).
Exit status 0 iff there are none. Usage: python check_holes.py <theory files...>"""
import re
import sys


def strip(src):
    out, i, n = [], 0, len(src)
    depth = 0          # (* *) nesting
    cart = 0           # cartouche nesting
    while i < n:
        if src.startswith('(*', i):
            depth += 1; i += 2; continue
        if depth and src.startswith('*)', i):
            depth -= 1; i += 2; continue
        if not depth:
            if src.startswith('\\<open>', i) or src[i] == '‹':
                cart += 1; i += 7 if src[i] == '\\' else 1; continue
            if cart and (src.startswith('\\<close>', i) or src[i] == '›'):
                cart -= 1; i += 8 if src[i] == '\\' else 1; continue
        if not depth and not cart:
            out.append(src[i])
        elif src[i] == '\n':
            out.append('\n')
        i += 1
    return ''.join(out)


holes = []
for f in sys.argv[1:]:
    code = strip(open(f, encoding='utf-8').read())
    for ln, line in enumerate(code.splitlines(), 1):
        if re.search(r'(?<![\w.])(sorry|oops)(?![\w.])', line):
            holes.append(f"{f}:{ln}: {line.strip()}")
print('\n'.join(holes) if holes else f"no sorry/oops outside comments in {len(sys.argv) - 1} theories")
sys.exit(1 if holes else 0)
