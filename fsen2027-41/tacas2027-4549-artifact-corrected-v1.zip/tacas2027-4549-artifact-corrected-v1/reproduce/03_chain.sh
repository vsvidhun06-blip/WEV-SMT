#!/usr/bin/env bash
# 3. Chain-composition experiment.
#   (a) validate.py + summarize.py on a copy of the recorded raw outputs;
#   (b) re-classification with a PINNED implementation (WEV_IMPL=submitted: impl/classes, the default;
#       WEV_IMPL=corrected: impl-corrected-v1/classes) and the shipped adapter,
#       then validate.py + summarize.py on the new raw outputs.
# What is compared:
#   * deterministic outputs must be byte-identical: threads-validation.csv,
#     hand-validation.csv, validation-summary.txt, tables.md, raw trace.csv / events.csv;
#   * raw pairs-raw.csv must match except C_ms (per-query solver time: timing-dependent);
#   * pairs-final.csv and traces.md must match except the WITNESS VALUES: each real pair's
#     witness is a z3-chosen counterexample (a model), which can differ between solver runs.
#     Instead of comparing the values, every real pair must carry a witness confirmed by
#     two concrete executions ("exec ..."), and no witness may fail.
# Requires Python 3 + z3-solver; (b) also requires JDK 21 and the pinned jars (M2_REPO).
source "$(dirname "$0")/common.sh"
C="$PKG/chain-composition"
BYTE="threads-validation.csv hand-validation.csv validation-summary.txt tables.md"

nowit() {  # pairs-final.csv without the witness column, or traces.md without witness lines
  case "$1" in
    *.csv) $PY -c "import csv,sys
r=csv.reader(open(sys.argv[1],newline='',encoding='utf-8')); h=next(r); i=h.index('witness')
w=csv.writer(sys.stdout,lineterminator='\n'); w.writerow(h[:i]+h[i+1:]); [w.writerow(x[:i]+x[i+1:]) for x in r]" "$1" ;;
    *) grep -v '^  - witness: ' "$1" ;;
  esac
}
witnesses_ok() { $PY -c "import csv,sys
r=list(csv.DictReader(open(sys.argv[1],newline='',encoding='utf-8')))
real=[x for x in r if x['z3']=='REAL']
assert real and all(x['witness'].startswith('exec ') for x in real), 'unconfirmed witness'
assert not any(x['witness']=='WITNESS-FAILED' for x in r)
print(len(real))" "$1"; }

check_derived() {  # $1 = label, $2 = directory with re-derived outputs
  for f in $BYTE; do
    same_text "$2/$f" "$C/results/$f" "chain $1: $f"
  done
  for f in pairs-final.csv traces.md; do
    diff -q <(nowit "$2/$f") <(nowit "$C/results/$f") >/dev/null \
      && pass "chain $1: $f identical apart from z3-chosen witness values" || fail "chain $1: $f differs"
  done
  n=$(witnesses_ok "$2/pairs-final.csv") && pass "chain $1: all $n real pairs carry an execution-confirmed witness" \
    || fail "chain $1: witness confirmation"
  grep -q 'STOP condition: none' "$2/validation-summary.txt" && pass "chain $1: no closure-FAKE/composed-REAL pair" \
    || fail "chain $1: stop condition"
}

R1="$WORK/chain-a"; rm -rf "$R1"; mkdir -p "$R1"
cp -r "$C/results/generated" "$C/results/raw" "$C/results/validation" "$R1/"
$PY "$C/validate.py" "$R1" > "$WORK/chain-a-validate.log"
$PY "$C/summarize.py" "$R1" > /dev/null
check_derived "(a)" "$R1"

if [ "${SKIP_JAVA:-0}" = 1 ]; then echo "SKIP  chain (b): SKIP_JAVA=1"; finish; fi
setup_java_env
select_impl "${WEV_IMPL:-submitted}"
B="$WORK/chain-b-${WEV_IMPL:-submitted}"; rm -rf "$B"; mkdir -p "$B/adapter-classes"
[ "$(classes_hash "$IMPL_CLASSES")" = "$IMPL_PIN_CLASSES" ] && pass "pinned classes hash ${IMPL_PIN_CLASSES:0:8}... ($IMPL_LABEL)" || fail "classes hash of $IMPL_CLASSES"
"$JAVAC" -encoding UTF-8 -d "$(w "$B/adapter-classes")" -cp "$(w "$IMPL_CLASSES")$SEP$DEPS_CP" "$(w "$C/adapter/ChainCompositionRun.java")" 2> "$B/javac.log"
cp -r "$C/results/generated" "$B/generated"; mkdir -p "$B/validation"
cp -r "$C/results/validation/inputs" "$C/results/validation/queries.tsv" "$C/results/validation/hand.json" "$B/validation/"
RUN=("$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$(w "$B/adapter-classes")$SEP$(w "$IMPL_CLASSES")$SEP$DEPS_CP" ChainCompositionRun)
"${RUN[@]}" "$(w "$B/generated")" "$(w "$B/raw")" 60 2> "$B/classify.log"
"${RUN[@]}" "$(w "$B/validation")" "$(w "$B/validation/raw")" 60 2>> "$B/classify.log"
dropms() { $PY -c "import csv,sys
r=csv.reader(open(sys.argv[1],newline='',encoding='utf-8')); h=next(r); i=h.index('C_ms')
w=csv.writer(sys.stdout,lineterminator='\n'); w.writerow(h[:i]+h[i+1:]); [w.writerow(x[:i]+x[i+1:]) for x in r]" "$1"; }
for d in raw validation/raw; do
  diff -q <(dropms "$B/$d/pairs-raw.csv") <(dropms "$C/results/$d/pairs-raw.csv") >/dev/null \
    && pass "chain (b): $d/pairs-raw.csv identical apart from timing column C_ms" || fail "chain (b): $d/pairs-raw.csv differs"
  for f in trace.csv events.csv; do
    same_text "$B/$d/$f" "$C/results/$d/$f" "chain (b): $d/$f"
  done
done
$PY "$C/validate.py" "$B" > /dev/null; $PY "$C/summarize.py" "$B" > /dev/null
check_derived "(b)" "$B"
finish
