#!/usr/bin/env bash
# 1. Build both Isabelle sessions from a copy of isabelle/ and check for proof holes.
# Requires ISABELLE_HOME = an Isabelle2024 installation. On Windows the POSIX launcher is
# run through Isabelle's bundled Cygwin bash (contrib/cygwin/bin/bash.exe).
# Isabelle's per-user directory (heaps, logs) is isolated in $WORK/isabelle-user via
# USER_HOME, so the build writes nothing to the evaluator's home directory.
# The theories are identical for the submitted and the corrected implementation.
source "$(dirname "$0")/common.sh"
: "${ISABELLE_HOME:?set ISABELLE_HOME to an Isabelle2024 installation}"
D="$WORK/isabelle"; rm -rf "$D"; cp -r "$PKG/isabelle" "$D"
U="$WORK/isabelle-user"; mkdir -p "$U"

$PY "$PKG/reproduce/check_holes.py" "$D"/*.thy "$D"/pwt/*.thy \
  && pass "no 'sorry' or 'oops' outside comments in any theory" || fail "proof holes (listed above)"
# Isabelle's default quick_and_dirty=false additionally makes any 'sorry' a build error.

CYG="$ISABELLE_HOME/contrib/cygwin/bin/bash.exe"
if [ -x "$CYG" ] && command -v cygpath >/dev/null 2>&1; then
  IH="$(cygpath -m "$ISABELLE_HOME")"; DD="$(cygpath -m "$D")"; UU="$(cygpath -m "$U")"
  # USER_HOME is converted inside Isabelle's Cygwin (an MSYS-side value would be mangled).
  "$CYG" --login -c "export USER_HOME=\"\$(cygpath -u '$UU')\"; cd \"\$(cygpath -u '$DD')\" && \"\$(cygpath -u '$IH')/bin/isabelle\" build -c -v -o timeout=600 -d . WEV_SMT WEV_SMT_PwT" \
    > "$WORK/isabelle-build.log" 2>&1 && rc=0 || rc=$?
else
  ( cd "$D" && USER_HOME="$U" "$ISABELLE_HOME/bin/isabelle" build -c -v -o timeout=600 -d . WEV_SMT WEV_SMT_PwT ) \
    > "$WORK/isabelle-build.log" 2>&1 && rc=0 || rc=$?
fi
tail -5 "$WORK/isabelle-build.log"
[ "$rc" = 0 ] && pass "isabelle build WEV_SMT WEV_SMT_PwT (exit 0)" || fail "isabelle build exit $rc (see $WORK/isabelle-build.log)"
grep -q 'Finished WEV_SMT_PwT' "$WORK/isabelle-build.log" && grep -q 'Finished WEV_SMT ' "$WORK/isabelle-build.log" \
  && pass "both sessions report Finished" || fail "session completion lines missing (see $WORK/isabelle-build.log)"
finish
