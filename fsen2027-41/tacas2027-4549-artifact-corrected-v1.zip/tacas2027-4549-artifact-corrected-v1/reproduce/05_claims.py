"""5. Empirical claims of the paper, resolved against packaged files (corrected-v1 package).

Part 1 checks the 31 claims of the SUBMITTED manuscript against the rows produced by the
SUBMITTED build (results/authoritative/, results/carried/, ...). Their logic is unchanged from
the 2026-10-12 checker (history/package-20261012/reproduce/05_claims.py); only appendix labels
were corrected (chain App. A.8, synthesis App. A.9) and each check is now labelled with:
  kind  RECOMPUTE = the figure is computed from packaged rows/manifests/hashes (26 checks);
        SUMMARY   = matched against a recorded summary text or pre-aggregated field (3: A2, X1, A5);
        PRESENCE  = only that the files exist / parse (2: S1, I1).
  build SUBMITTED = rows produced by the submitted build; FIXED-INPUT = corpus/manifests, chain,
        generator or carried data that do not depend on the F-01 encoder change.
A PASS means "the packaged rows agree with the printed figure", NOT that the figure is
correct: E1 passes on submitted rows that contain the F-01 error (12 cells), see part 2.
No check re-runs a solver; stages 3-4, 6 and 8-11 do.

Part 2 (ids ending in "c") RECOMPUTES the corrected-v1 figures from the corrected build's rows
(results/corrected-v1/). They are NOT figures of the submitted manuscript.

Categories (unchanged): AUTH = authoritative repaired run; CARRIED = earlier run on unchanged
inputs, cited as such by the paper; RECORD = recorded experiment the paper says is not
re-derivable; RECON = reconstructed generator; CHAIN = chain-composition experiment;
CORR = corrected-v1 rerun (2026-10-19).
Usage: python 05_claims.py [<package-dir>]   (writes CLAIMS-CHECK.txt to $WORK if set)
"""
import collections
import csv
import json
import os
import re
import statistics
import sys
from pathlib import Path

P = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
AU = P / 'results/authoritative/rerun-2026-10-09'
PR = P / 'results/authoritative/ppo-repair'
CA = P / 'results/carried'
C = collections.Counter
rows_out, fails = [], 0


def rd(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


KIND = {'A2': 'SUMMARY', 'X1': 'SUMMARY', 'A5': 'SUMMARY', 'S1': 'PRESENCE', 'I1': 'PRESENCE'}
SUBMITTED_ROWS = {'E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'D1', 'D2', 'D3', 'A1', 'A2', 'A3', 'A4', 'H1', 'H2', 'X1', 'X4'}
NOTE = {'E1': 'SUBMITTED figure; 12 cells are wrong (F-01); corrected figure: E1c',
        'E4': 'unchanged under the corrected build (E4c)', 'E2': 'unchanged under the corrected build (E2c)',
        'E3': 'unchanged under the corrected build (E3c)', 'E5': 'unchanged under the corrected build (E5c)',
        'E6': 'unchanged under the corrected build (E6c)', 'D1': 'unchanged under the corrected build (D1c)',
        'H1': 'unchanged under the corrected build (H1c)'}


def claim(cid, where, cat, path, statement, expected, compute):
    global fails
    files = [path] if isinstance(path, (str, Path)) else path
    missing = [str(f) for f in files if not (P / f).exists()]
    try:
        got = None if missing else compute()
        ok = not missing and got == expected
    except Exception as ex:  # noqa: BLE001
        got, ok = f'ERROR {ex!r}', False
    fails += not ok
    kind = KIND.get(cid, 'RECOMPUTE')
    build = 'CORRECTED' if cid.endswith('c') else ('SUBMITTED' if cid in SUBMITTED_ROWS else 'FIXED-INPUT')
    if cid in NOTE:
        statement = statement + '  [' + NOTE[cid] + ']'
    rows_out.append((('PASS' if ok else 'FAIL'), cid, where, f'{cat}/{kind}/{build}', statement,
                     ' + '.join(str(f) for f in files), repr(expected) if ok else f'expected {expected!r} got {got!r}'))


pop = rd(P / 'corpus/manifests/frozen-population-12324.csv')
el = [r for r in pop if r['status'] == 'ELIGIBLE']
sym = rd(PR / 'six-model/repaired-symbolic.csv')
V = {(r['file'], r['model']): r['verdict'] for r in sym}
files = sorted({r['file'] for r in sym})
MODELS = ['SC', 'TSO', 'PSO', 'RA', 'WEAKEST', 'RC11']

claim('P1', '§6.1', 'AUTH', 'corpus/manifests/frozen-population-12324.csv',
      'sample 12,324 = herd7 4,324 + Dat3M 8,000', (12324, 4324, 8000),
      lambda: (len(pop), sum(r['path'].startswith('herdtools7/') for r in pop), sum(r['path'].startswith('Dat3M/') for r in pop)))
claim('P2', '§6.1', 'AUTH', 'corpus/manifests/frozen-population-12324.csv',
      'eligible 2,396; excluded 9,744 unsupported / 173 known mis-encoded / 11 unchecked',
      {'ELIGIBLE': 2396, 'EXPLICITLY-UNSUPPORTED': 9744, 'KNOWN-INCORRECT': 173, 'UNCHECKED': 11},
      lambda: dict(C(r['status'] for r in pop)))
claim('P3', '§6.1', 'AUTH', 'corpus/manifests/frozen-population-12324.csv',
      'eligible: 2,312 distinct programs; AArch64 1,058, C 633, PPC 603, x86 102',
      (2312, {'ARM': 1058, 'C': 633, 'PPC': 603, 'X86': 102}),
      lambda: (len({r['norm_sha256'] for r in el}), dict(C(r['arch'] for r in el))))
claim('P4', 'App. A.6', 'AUTH', ['corpus/manifests/frozen-eligible-manifest.csv', 'corpus/manifests/frozen-eligible-manifest.sha256'],
      'eligible manifest SHA-256 ae011be3...', 'ae011be3',
      lambda: __import__('hashlib').sha256((P / 'corpus/manifests/frozen-eligible-manifest.csv').read_bytes()).hexdigest()[:8])
claim('E1', '§6.4', 'AUTH', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv',
      'symbolic ALLOWED/FORBIDDEN: SC 36/2360, TSO 563/1833, PSO 1170/1226, RA 2089/307, WEAKEST 2356/40, RC11 2169/227',
      {'SC': (36, 2360), 'TSO': (563, 1833), 'PSO': (1170, 1226), 'RA': (2089, 307), 'WEAKEST': (2356, 40), 'RC11': (2169, 227)},
      lambda: {m: (sum(V[(f, m)] == 'ALLOWED' for f in files), sum(V[(f, m)] == 'FORBIDDEN' for f in files)) for m in MODELS})
claim('E2', '§6.4', 'AUTH', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv',
      'seven derivable implications: 0 violations on 2,396 files', 0,
      lambda: sum(V[(f, a)] == 'ALLOWED' and V[(f, b)] == 'FORBIDDEN' for f in files for a, b in
                  [('SC', 'TSO'), ('SC', 'PSO'), ('SC', 'RA'), ('SC', 'WEAKEST'), ('SC', 'RC11'), ('RC11', 'WEAKEST'), ('PSO', 'RA')]))
claim('E3', '§6.4', 'AUTH', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv',
      '187 files WEAKEST-ALLOWED but RC11-FORBIDDEN, none in reverse', (187, 0),
      lambda: (sum(V[(f, 'WEAKEST')] == 'ALLOWED' and V[(f, 'RC11')] == 'FORBIDDEN' for f in files),
               sum(V[(f, 'RC11')] == 'ALLOWED' and V[(f, 'WEAKEST')] == 'FORBIDDEN' for f in files)))


def wired_diff():
    W = {(r['file'], r['model']): r['verdict'] for r in rd(PR / 'six-model/repaired-wired-847.csv')}
    wf = sorted({k[0] for k in W})
    return len(wf), {m: sum(W[(f, m)] != V[(f, m)] for f in wf) for m in MODELS}, \
        {(W[k], V[k]) for k in W if W[k] != V[k]}


claim('E4', 'App. A.6', 'AUTH', ['results/authoritative/ppo-repair/six-model/repaired-wired-847.csv', 'corpus/manifests/wired-847-hashes.csv'],
      'wired mode on 847 files differs: SC 0, TSO 1, PSO 16, RA 44, WEAKEST 44, RC11 31; always wired FORBIDDEN vs symbolic ALLOWED',
      (847, {'SC': 0, 'TSO': 1, 'PSO': 16, 'RA': 44, 'WEAKEST': 44, 'RC11': 31}, {('FORBIDDEN', 'ALLOWED')}), wired_diff)


def herd_sc():
    h = {r['relpath']: r for r in rd(AU / 'herd7-frozen-results.csv')}
    comp = [f for f in files if h[f]['herd_sc'] in ('ALLOWED', 'FORBIDDEN')]
    arch = {r['file']: r['arch'] for r in sym}
    return len(comp), sum(h[f]['herd_sc'] == V[(f, 'SC')] for f in comp), dict(C(arch[f] for f in comp))


claim('E5', '§6.4', 'AUTH', ['results/authoritative/rerun-2026-10-09/herd7-frozen-results.csv', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv'],
      'herd7 7.58 sc.cat agrees on all 1,772 compared files (AArch64 1,050, PPC 603, x86 101, C 18)',
      (1772, 1772, {'ARM': 1050, 'PPC': 603, 'X86': 101, 'C': 18}), herd_sc)
claim('E6', '§6.4', 'AUTH', ['results/authoritative/ppo-repair/herd7-x86-results.csv', 'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv'],
      'x86tso.cat agrees on 101/101 x86 files (one herd7 error)', (101, 101, 1),
      lambda: (lambda h: (len([r for r in h if r['herd_tso'] in ('ALLOWED', 'FORBIDDEN')]),
                          sum(r['herd_tso'] == V[(r['relpath'], 'TSO')] for r in h if r['herd_tso'] in ('ALLOWED', 'FORBIDDEN')),
                          sum(r['herd_tso'] not in ('ALLOWED', 'FORBIDDEN') for r in h)))(rd(PR / 'herd7-x86-results.csv')))
sd = rd(AU / 'sdep/sdep-discriminating-all-fake-tests.csv') if (AU / 'sdep/sdep-discriminating-all-fake-tests.csv').exists() else []
claim('D1', '§6.1', 'AUTH', 'results/authoritative/rerun-2026-10-09/sdep/sdep-discriminating-all-fake-tests.csv',
      '6 of 370 fake-carrying eligible files discriminate', (370, 6),
      lambda: (len(sd), sum(r['discriminating'] == 'true' for r in sd)))
claim('D2', 'App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/sdep/sdep-discriminating-all-fake-tests.csv',
      'fake edges: address 197 in 128 files, data 368 in 285, control 0', (197, 128, 368, 285, 0),
      lambda: (sum(int(r['addr_fake']) for r in sd), sum(int(r['addr_fake']) > 0 for r in sd),
               sum(int(r['data_fake']) for r in sd), sum(int(r['data_fake']) > 0 for r in sd), sum(int(r['ctrl_fake']) for r in sd)))
claim('D3', 'App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/mutation-corpus-results.csv',
      'historical wired mutation diagnostic: 370 pairs, 5 ALLOWED/FORBIDDEN changes', (370, 5),
      lambda: (lambda m: (len(m), sum(r['discriminating'] == 'yes' for r in m)))(rd(AU / 'mutation-corpus-results.csv')))


def pairs374():
    pr = [r for r in rd(AU / 'pairs-corpus.csv') if r['cat_S']]
    shapes = {re.sub(r'R\d+', 'R', re.sub(r'\s+', '', r['composed_expr'])) for r in pr}
    return len(pr), len({r['test'] for r in pr}), dict(C(r['cat_S'] for r in pr)), dict(C(r['cat_O'] for r in pr)), len(shapes)


claim('A1', '§5.1, App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/pairs-corpus.csv',
      'closure vs composed: 374 data pairs in 290 files, 368 agree FAKE, 6 agree REAL (both configurations), 4 shapes',
      (374, 290, {'agree-FAKE': 368, 'agree-REAL': 6}, {'agree-FAKE': 368, 'agree-REAL': 6}, 4), pairs374)
claim('A2', '§5.2', 'AUTH', 'results/authoritative/rerun-2026-10-09/final-analysis.txt',
      'oracle-consistency audit: 12,067 pairs, 990 conservative, 0 unsound', ('12067', '990', '0'),
      lambda: re.search(r'total audited\s*:\s*(\d+).*?CONSERVATIVE \(sound\)\s*:\s*(\d+).*?UNSOUND \(defect\)\s*:\s*(\d+)',
                        (AU / 'final-analysis.txt').read_text(encoding='utf-8'), re.S).groups())
claim('A3', '§4.4', 'AUTH', 'results/authoritative/rerun-2026-10-09/pwt-equivalence-sweep.csv',
      'PwT per-site correspondence: 58/58 on the branch-free corpus sweep', (58, 58),
      lambda: (lambda p: (len(p), sum(r['agree'] == 'true' for r in p)))(rd(AU / 'pwt-equivalence-sweep.csv')))
claim('A4', 'App. A.6', 'AUTH', 'results/authoritative/rerun-2026-10-09/qfbv-detector-results.csv',
      'QF_BV detector: 0 verdict changes over 2,396 files', (2396, 0),
      lambda: (lambda q: (len(q), sum(r['changed'] == 'true' for r in q)))(rd(AU / 'qfbv-detector-results.csv')))
claim('A5', 'App. A.6', 'RECORD', ['results/carried/classifier-defect-records/ENGINEERING-SUMMARY.md', 'results/carried/classifier-defect-records/FIX.patch.md'],
      'classifier defect: 218/8448 unsound before the fix (recorded experiment; not re-derivable from the fixed tree)', True,
      lambda: '218 / 8448' in (CA / 'classifier-defect-records/ENGINEERING-SUMMARY.md').read_text(encoding='utf-8'))
hb = rd(AU / 'generated-hard-pairs.csv')


def hard():
    current = rd(P / 'repair/symbolic-ring-audit.csv')
    comparable = [r for r in current if r['value_consistency'] == 'SAT']
    def cnt(col):
        tp = sum(r[col] == 'FORBIDDEN' and r['oracle_constant'] == 'false' for r in comparable)
        tn = sum(r[col] == 'ALLOWED' and r['oracle_constant'] == 'true' for r in comparable)
        fp = sum(r[col] == 'FORBIDDEN' and r['oracle_constant'] == 'true' for r in comparable)
        fn = sum(r[col] == 'ALLOWED' and r['oracle_constant'] == 'false' for r in comparable)
        return tp, tn, fp, fn
    return len(comparable), len({r['expr'] for r in comparable}), cnt('weakest'), cnt('folding'), cnt('syntactic')

claim('H1', 'Table 2', 'AUTH', 'repair/symbolic-ring-audit.csv',
      '1,288 value-consistent rings of 644 expressions; exact 220/1068/0/0, folding 220/298/770/0, all-deps 220/0/1068/0 (TP/TN/FP/FN)',
      (1288, 644, (220,1068,0,0), (220,298,770,0), (220,0,1068,0)), hard)
claim('H2', '§6.3', 'AUTH', 'results/authoritative/rerun-2026-10-09/generated-hard-pairs.csv',
      'folding errors: 385 distinct expressions over 158 operator shapes; 149 right; 534 grounded classes; 383 shapes overall',
      (385, 158, 149, 534, 383),
      lambda: (lambda fp, gr: (len(fp), len({r['shape'] for r in hb if r['expr'] in fp}), len(gr - fp), len(gr),
                               len({r['shape'] for r in hb})))(
          {r['expr'] for r in hb if r['required'] == 'ALLOWED' and r['folding'] == 'FORBIDDEN'},
          {r['expr'] for r in hb if r['required'] == 'ALLOWED'}))
claim('H3', 'App. A.6', 'RECON', ['hardbench/reconstructed/enumerate_candidates_RECONSTRUCTED.py', 'hardbench/generated-hard-candidates.json'],
      'candidate list: 1,828 expressions (13,880 intermediate forms: run reproduce/02_generators.sh)', 1828,
      lambda: len(json.loads((P / 'hardbench/generated-hard-candidates.json').read_text())))
lk = rd(CA / 'dat3m-lkmm-hardbench.csv')
gr = rd(CA / 'dat3m-lkmm-grounded-rings.csv')
claim('H4', '§6.3, App. A.6', 'CARRIED', ['results/carried/dat3m-lkmm-hardbench.csv', 'results/carried/dat3m-lkmm-grounded-rings.csv'],
      'Dat3M v4.4.1 LKMM: 1,350 instances, matches all-dependencies on 1,350/1,350; forbids all 390 grounded rings (195 expressions)',
      (1350, 1350, 390, 390, 195),
      lambda: (len(lk), sum(r['agreement'] == 'true' for r in lk), len(gr),
               sum(r['dat3m_verdict'] == 'FORBIDDEN' for r in gr), len({r['expression_id'] for r in gr})))
ex = json.loads((AU / 'examples-results.json').read_text(encoding='utf-8'))
claim('X1', '§6.4', 'AUTH', 'results/authoritative/rerun-2026-10-09/examples-results.json',
      'published examples 31/34 symbolic (Weakestmo 8/8, PwT 5/6, JMM 18/20); Dat3M 35/41 symbolic, 31/41 wired',
      (31, 34, 18, 20, 35, 31, 41),
      lambda: (ex['published34']['symbolic_agreement'], ex['published34']['total'], ex['jmm20']['symbolic_agreement'],
               ex['jmm20']['total'], ex['dat3m41']['symbolic_agreement'], ex['dat3m41']['wired_agreement'], ex['dat3m41']['total']))
dc = rd(CA / 'dat3m-comparison-v2.csv')
claim('X2', '§6.4', 'CARRIED', 'results/carried/dat3m-comparison-v2.csv',
      'Dat3M timing: median 10 ms (WEAKEST) against 516 ms (BMC) on 41 tests', (41, 10, 516),
      lambda: (len(dc), round(statistics.median(float(r['wev_time_ms']) for r in dc)),
               round(statistics.median(float(r['dat3m_time_ms']) for r in dc))))
gp = rd(CA / 'generated-pairs-folding.csv')
claim('X3', 'App. A.6', 'CARRIED', ['results/carried/generated-pairs.csv', 'results/carried/generated-pairs-folding.csv'],
      'matched-pair sweep: 1,600 rings, 1,440 valid, 1,015 discriminating; folding agrees with WEAKEST on all 1,440 valid',
      (1600, 1440, 1015, 1440),
      lambda: (len(gp), sum(r['valid'] == 'true' for r in gp), sum(r['discriminating'] == 'true' for r in gp),
               sum(r['valid'] == 'true' and r['folding_baseline'] == r['weakest'] for r in gp)))
nt = rd(CA / 'nthread-grounded-admission.csv')
claim('X4', '§4.4', 'CARRIED', 'results/carried/nthread-grounded-admission.csv',
      'grounded-LB admission (Prop. 3(b)) SMT-verified up to eight threads', (8, {'ALLOWED'}),
      lambda: (max(int(r['n']) for r in nt), {r['verdict'] for r in nt}))


def scal():
    s = rd(CA / 'scalability-consistency.csv')
    t = {(r['family'], int(r['n'])): float(r['fullexec_ms']) for r in s if r['model'] == 'WEAKEST'}
    # ratio LBChain / LBFakeChain (real over fake) of the WEAKEST full-execution time
    rs = [t[('LBChain', n)] / t[('LBFakeChain', n)] for n in range(2, 13) if ('LBChain', n) in t and ('LBFakeChain', n) in t]
    return round(min(rs), 2), round(max(rs), 2)


claim('X5', 'App. A.6', 'CARRIED', 'results/carried/scalability-consistency.csv',
      'LBChain vs LBFakeChain WEAKEST time ratios between 0.80 and 1.70 through n=12', (0.80, 1.70), scal)
cf = rd(P / 'chain-composition/results/pairs-final.csv')


def chain():
    fake = [r for r in cf if r['C'] == 'FAKE']
    by = lambda v: [r for r in fake if r['variant'] == v]
    miss = lambda rs, c: sum(r['cat_' + c] == 'closureREAL/composedFAKE' for r in rs)
    return (len({r['id'] for r in cf}), len(cf), sum(r['C'] == 'REAL' for r in cf), len(fake),
            len(by('direct')), len(by('chain')), len(by('control')),
            miss(by('direct'), 'A'), miss(by('direct'), 'B'), miss(by('chain'), 'A'), miss(by('chain'), 'B'),
            miss(by('control'), 'A'), miss(by('control'), 'B'),
            sum(r['cat_A'] == 'closureFAKE/composedREAL' or r['cat_B'] == 'closureFAKE/composedREAL' for r in cf),
            len({(r['norm_shape'], r['k']) for r in cf}))


claim('C1', '§6.2 Table 1, App. A.8', 'CHAIN', 'chain-composition/results/pairs-final.csv',
      'chain: 256 threads, 317 pairs (171 real; fake 66 single-instruction, 72 chain, 8 control); fakes missed '
      'A/B: single 36/0, chain 72/72, control 1/1; 0 fake-where-real; 213 distinct shape/load pairs',
      (256, 317, 171, 146, 66, 72, 8, 36, 0, 72, 72, 1, 1, 0, 213), chain)
claim('C2', 'App. A.8', 'CHAIN', 'chain-composition/results/generated/manifest.json',
      'chain accounting: 236 distinct programs, 168 distinct shapes, 291 distinct program/load pairs', (236, 168, 291),
      lambda: (lambda m: (len({i['norm_program'] for i in m}), len({i['norm_shape'] for i in m}),
                          len({(r['norm_program'], r['k']) for r in cf})))(
          json.loads((P / 'chain-composition/results/generated/manifest.json').read_text())))
claim('S1', 'App. A.9', 'CARRIED', ['synthesis/claimD/claimD-synthesis.json', 'synthesis/claimD/claimD_synth.py'],
      'unrestricted-abstraction synthesis outputs present', True,
      lambda: bool(json.loads((P / 'synthesis/claimD/claimD-synthesis.json').read_text())))
THY = ['Detector', 'Soundness', 'pwt/PwT_Model', 'pwt/PwT_R4b', 'pwt/PwT_Program', 'pwt/PwT_Granularity',
       'pwt/PwT_ReadRestricted', 'pwt/PwT_Capacity', 'pwt/PwT_EventBridge', 'pwt/PwT_Control']
claim('I1', '§5.3, App. A.1', 'AUTH', ['isabelle/ROOT'] + [f'isabelle/{t}.thy' for t in THY],
      'every theory of the mechanization map is packaged; build checked by 01_isabelle.sh', True, lambda: True)

n_sub = len(rows_out)

# ── Part 2: corrected-v1 figures (NOT figures of the submitted manuscript) ──────────────
CV = P / 'results/corrected-v1'
if (CV / 'six-model/corrected-symbolic.csv').exists():
    csym = rd(CV / 'six-model/corrected-symbolic.csv')
    VC = {(r['file'], r['model']): r['verdict'] for r in csym}
    cfiles = sorted({r['file'] for r in csym})
else:
    VC, cfiles = {}, []
F01 = ['Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009.litmus', 'Dat3M/litmus/PPC/2+2W+rfi-datas.litmus',
       'Dat3M/litmus/X86/m55ii.litmus']
claim('E1c', '§6.4 (corrected)', 'CORR', 'results/corrected-v1/six-model/corrected-symbolic.csv',
      'CORRECTED symbolic ALLOWED/FORBIDDEN: SC 36/2360, TSO 563/1833, PSO 1173/1223, RA 2092/304, WEAKEST 2359/37, RC11 2172/224',
      {'SC': (36, 2360), 'TSO': (563, 1833), 'PSO': (1173, 1223), 'RA': (2092, 304), 'WEAKEST': (2359, 37), 'RC11': (2172, 224)},
      lambda: {m: (sum(VC[(f, m)] == 'ALLOWED' for f in cfiles), sum(VC[(f, m)] == 'FORBIDDEN' for f in cfiles)) for m in MODELS})
claim('DIFFc', '§6.4 (corrected)', 'CORR', ['results/corrected-v1/six-model/corrected-symbolic.csv',
                                            'results/authoritative/ppo-repair/six-model/repaired-symbolic.csv'],
      'submitted vs corrected: exactly 12 cells differ (3 files x PSO/RA/WEAKEST/RC11), all FORBIDDEN->ALLOWED',
      sorted((f, m, 'FORBIDDEN', 'ALLOWED') for f in F01 for m in ('PSO', 'RA', 'WEAKEST', 'RC11')),
      lambda: sorted((f, m, V[(f, m)], VC[(f, m)]) for f in files for m in MODELS if V[(f, m)] != VC[(f, m)]))
claim('E2c', '§6.4 (corrected)', 'CORR', 'results/corrected-v1/six-model/corrected-symbolic.csv',
      'seven derivable implications: 0 violations on 2,396 files (corrected)', 0,
      lambda: sum(VC[(f, a)] == 'ALLOWED' and VC[(f, b)] == 'FORBIDDEN' for f in cfiles for a, b in
                  [('SC', 'TSO'), ('SC', 'PSO'), ('SC', 'RA'), ('SC', 'WEAKEST'), ('SC', 'RC11'), ('RC11', 'WEAKEST'), ('PSO', 'RA')]))
claim('E3c', '§6.4 (corrected)', 'CORR', 'results/corrected-v1/six-model/corrected-symbolic.csv',
      '187 files WEAKEST-ALLOWED but RC11-FORBIDDEN, none in reverse (corrected)', (187, 0),
      lambda: (sum(VC[(f, 'WEAKEST')] == 'ALLOWED' and VC[(f, 'RC11')] == 'FORBIDDEN' for f in cfiles),
               sum(VC[(f, 'RC11')] == 'ALLOWED' and VC[(f, 'WEAKEST')] == 'FORBIDDEN' for f in cfiles)))
claim('E4c', 'App. A.6 (corrected)', 'CORR', ['results/corrected-v1/six-model/corrected-wired-847.csv',
                                              'results/corrected-v1/six-model/corrected-symbolic.csv'],
      'wired 847-file differences vs corrected symbolic: SC 0, TSO 1, PSO 16, RA 44, WEAKEST 44, RC11 31',
      {'SC': 0, 'TSO': 1, 'PSO': 16, 'RA': 44, 'WEAKEST': 44, 'RC11': 31},
      lambda: (lambda W: {m: sum(W[(f, m)] != VC[(f, m)] for f in sorted({k[0] for k in W})) for m in MODELS})(
          {(r['file'], r['model']): r['verdict'] for r in rd(CV / 'six-model/corrected-wired-847.csv')}))
claim('E5c', '§6.4 (corrected)', 'CORR', ['results/authoritative/rerun-2026-10-09/herd7-frozen-results.csv',
                                          'results/corrected-v1/six-model/corrected-symbolic.csv'],
      'recorded herd7 7.58 sc.cat rows (herd7 not re-run) agree with corrected SC on 1,772/1,772',
      (1772, 1772),
      lambda: (lambda h: (lambda comp: (len(comp), sum(h[f]['herd_sc'] == VC[(f, 'SC')] for f in comp)))(
          [f for f in cfiles if h[f]['herd_sc'] in ('ALLOWED', 'FORBIDDEN')]))(
          {r['relpath']: r for r in rd(AU / 'herd7-frozen-results.csv')}))
claim('E6c', '§6.4 (corrected)', 'CORR', ['results/authoritative/ppo-repair/herd7-x86-results.csv',
                                          'results/corrected-v1/six-model/corrected-symbolic.csv'],
      'recorded herd7 x86tso.cat rows agree with corrected TSO on 101/101', (101, 101),
      lambda: (lambda h: (len(h), sum(r['herd_tso'] == VC[(r['relpath'], 'TSO')] for r in h)))(
          [r for r in rd(PR / 'herd7-x86-results.csv') if r['herd_tso'] in ('ALLOWED', 'FORBIDDEN')]))
claim('D1c', '§6.1 (corrected)', 'CORR', 'results/corrected-v1/ablation/sdep-discriminating-all-fake-tests.csv',
      '6 of 370 fake-carrying eligible files discriminate (wired ablation re-run with the corrected build)', (370, 6),
      lambda: (lambda s: (len(s), sum(r['discriminating'] == 'true' for r in s)))(
          rd(CV / 'ablation/sdep-discriminating-all-fake-tests.csv')))
claim('H1c', 'Table 2 (corrected)', 'CORR', 'results/corrected-v1/ring-audit/symbolic-ring-audit-corrected.csv',
      'Table 2 ring audit with the corrected build: byte-identical to repair/symbolic-ring-audit.csv', True,
      lambda: (CV / 'ring-audit/symbolic-ring-audit-corrected.csv').read_bytes() == (P / 'repair/symbolic-ring-audit.csv').read_bytes())
claim('REFc', '§6.4 (corrected)', 'CORR', ['results/corrected-v1/reference/reference-verdicts.csv',
                                           'results/corrected-v1/six-model/corrected-symbolic.csv'],
      'separate relational checker (shares parser, Z3 values, transcribed rules) = corrected verdicts on 14,376/14,376 cells',
      (14376, 14376),
      lambda: (lambda R: (len(R), sum(R[k] == VC.get(k) for k in R)))(
          {(r['file'], r['model']): r['ref_verdict'] for r in rd(CV / 'reference/reference-verdicts.csv') if r['model'] in MODELS}))

kinds = collections.Counter(KIND.get(r[1], 'RECOMPUTE') for r in rows_out[:n_sub])
out = ['status  id     where                    cat/kind/build                      statement  |  artifact  |  value']
out += ['  '.join(r[:4]) + f"  {r[4]}\n        -> {r[5]}\n        -> {r[6]}" for r in rows_out]
f_sub = sum(r[0] == 'FAIL' for r in rows_out[:n_sub])
f_cor = sum(r[0] == 'FAIL' for r in rows_out[n_sub:])
out.append(f"\nPart 1, submitted manuscript: {n_sub - f_sub}/{n_sub} claims agree with the packaged rows "
           f"({kinds['RECOMPUTE']} recomputed from rows, {kinds['SUMMARY']} matched against recorded summaries, "
           f"{kinds['PRESENCE']} presence-only); {f_sub} failed. E1 agrees with submitted rows that contain the F-01 error.")
out.append(f"Part 2, corrected v1 (not in the submitted manuscript): {len(rows_out) - n_sub - f_cor}/{len(rows_out) - n_sub} "
           f"figures recomputed from corrected rows; {f_cor} failed")
text = '\n'.join(out)
print(text)
if os.environ.get('WORK'):
    Path(os.environ['WORK'], 'CLAIMS-CHECK.txt').write_text(text + '\n', encoding='utf-8')
sys.exit(1 if fails else 0)
