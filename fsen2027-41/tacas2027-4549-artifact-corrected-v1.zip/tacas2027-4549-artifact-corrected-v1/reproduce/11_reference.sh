#!/usr/bin/env bash
# 11. Separate relational reference checker vs the six-model verdicts of BOTH builds.
#
# The checker (correction-record/investigation-2026-10-18/ref/refcheck.py, written by the
# 2026-10-18 correctness investigation) enumerates rf and co explicitly and evaluates each
# model's relational predicate with plain graph algorithms; it uses no pos variables and no
# integer layers. It is NOT fully independent and NOT an external semantics. It SHARES with
# the implementation:
#   * the parser: its input is LitmusParser's output, exported by ExportCases.java;
#   * Z3 (Python z3-solver) for BV32 value reasoning;
#   * model rules transcribed from the paper/Javadoc (TSO/PSO fence and RMW restore rules,
#     RA's release/acquire-like rules), not from the SMT code.
# Checks:
#   - the exported parse covers all 2,396 frozen eligible files without error;
#   - reference verdicts (all 2,396 x 6 models, enumeration bound 20,000,000) equal the
#     packaged reference verdicts (correction-record/.../ref/ref-verdicts.csv), ignoring timing;
#   - reference = CORRECTED packaged verdicts on all 14,376 cells;
#   - reference vs SUBMITTED authoritative verdicts: exactly the 12 F-01 cells differ.
# Requires JDK 21 (export only) and Python 3 with z3-solver.
source "$(dirname "$0")/common.sh"
setup_java_env
R="$WORK/reference"; rm -rf "$R"; mkdir -p "$R/bin"
REF="$PKG/correction-record/investigation-2026-10-18/ref"
echo "IMPLEMENTATION (parser for the export): SUBMITTED impl/classes (LitmusParser is byte-identical in both builds)"
"$JAVAC" -proc:none -encoding UTF-8 -d "$(w "$R/bin")" -cp "$(w "$PKG/impl/classes")$SEP$DEPS_CP" "$(w "$REF/ExportCases.java")" 2> "$R/javac.log"
"$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$(w "$R/bin")$SEP$(w "$PKG/impl/classes")$SEP$DEPS_CP" ExportCases \
  "$(w "$PKG/corpus/manifests/frozen-eligible-hashes.csv")" "$(w "$PKG/corpus/litmus")" "$(w "$R/cases.jsonl")" > "$R/export.log" 2>&1
n=$(grep -c '"file"' "$R/cases.jsonl"); e=$(grep -c '"error"' "$R/cases.jsonl" || true)
[ "$n" = 2396 ] && [ "$e" = 0 ] && pass "exported parse of $n eligible files, $e errors" || fail "export: $n files, $e errors"
t0=$SECONDS
$PY "$REF/refcheck.py" "$R/cases.jsonl" "$R/ref-verdicts.csv" 20000000 > "$R/refcheck.log" 2>&1 \
  && pass "reference checker completed ($((SECONDS - t0)) s)" || fail "reference checker exit (see $R/refcheck.log)"
$PY - "$PKG" "$R" <<'EOF' || fail "reference comparisons (see FAIL lines above)"
import csv, sys
P, R = sys.argv[1], sys.argv[2]
M = ['SC', 'TSO', 'PSO', 'RA', 'WEAKEST', 'RC11']
rd = lambda p: list(csv.DictReader(open(p, newline='', encoding='utf-8')))
new = rd(R + '/ref-verdicts.csv')
old = rd(P + '/correction-record/investigation-2026-10-18/ref/ref-verdicts.csv')
strip = lambda rows: sorted((r['file'], r['model'], r['ref_verdict'], r['combos'], r['note']) for r in rows)
bad = []
def out(ok, msg):
    bad.extend([] if ok else [msg])
    print(('PASS  ' if ok else 'FAIL  ') + msg)
out(strip(new) == strip(old), f'reference verdicts equal the packaged reference run ({len(new)} rows; timing column ignored)')
ref = {(r['file'], r['model']): r['ref_verdict'] for r in new if r['model'] in M}
unres = [k for k, v in ref.items() if v not in ('ALLOWED', 'FORBIDDEN')]
out(len(ref) == 14376 and not unres, f'reference resolves all {len(ref)} file/model cells ({len(unres)} unresolved)')
cor = {(r['file'], r['model']): r['verdict'] for r in rd(P + '/results/corrected-v1/six-model/corrected-symbolic.csv')}
sub = {(r['file'], r['model']): r['verdict'] for r in rd(P + '/results/authoritative/ppo-repair/six-model/repaired-symbolic.csv')}
dc = sorted(k for k in ref if ref[k] != cor.get(k))
ds = sorted(k for k in ref if ref[k] != sub.get(k))
out(not dc, f'[corrected] corrected verdicts = reference on {len(ref) - len(dc)}/{len(ref)} cells')
exp = {(f, m) for f in ('Dat3M/litmus/PPC/2+2W+rfi-datas.litmus', 'Dat3M/litmus/X86/m55ii.litmus',
                        'Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009.litmus')
       for m in ('PSO', 'RA', 'WEAKEST', 'RC11')}
out(set(ds) == exp and all(sub[k] == 'FORBIDDEN' and ref[k] == 'ALLOWED' for k in ds),
    f'[submitted] submitted verdicts differ from the reference in exactly the 12 F-01 cells (got {len(ds)}, all FORBIDDEN->ALLOWED)')
sys.exit(1 if bad else 0)
EOF
finish
