#!/usr/bin/env bash
# Run every reproduction check in order, summarise, and exit NONZERO if any stage failed.
# (corrected-v1 package; the 2026-10-12 version, which always exited 0, is kept verbatim
#  under history/package-20261012/reproduce/run_all.sh)
#
#   WORK=<scratch dir outside the package>  ISABELLE_HOME=<Isabelle2024>  bash reproduce/run_all.sh
#
# Optional switches (all default off/0):
#   SKIP_ISABELLE=1   skip stage 1            SKIP_JAVA=1   skip every stage needing the JDK
#   RUN_FULL=1        also run the expensive stages: 06 repair (full, both builds) and the full
#                     2,396-file x six-model reruns of both builds inside stage 10
#   REQUIRE_ALL=1     treat a skipped stage (or a stage reporting SKIP lines) as a failure
#
# Each stage's output is kept in $WORK/logs/<stage>.log. A stage is
#   PASS     exit 0, at least one PASS line, no FAIL line, no SKIP line;
#   PARTIAL  exit 0 and no FAIL line, but some of its checks were skipped (listed) -- NOT a pass;
#   SKIPPED  not run at all (switch given or toolchain absent) -- NOT a pass;
#   FAIL     anything else, including a zero exit status with no PASS line.
# Exit status: 0 only if no stage FAILed (and, with REQUIRE_ALL=1, none was SKIPPED/PARTIAL).
HERE="$(cd "$(dirname "$0")" && pwd)"
source "$HERE/common.sh"
set +e
L="$WORK/logs"; mkdir -p "$L"
ORDER=()
declare -A RC STATUS NOTE

classify() {  # $1 = stage name, $2 = exit code, $3 = log
  local p f s
  p=$(grep -c '^PASS' "$3"); f=$(grep -c '^FAIL' "$3"); s=$(grep -c '^SKIP' "$3")
  if [ "$2" != 0 ] || [ "$f" != 0 ]; then STATUS[$1]=FAIL; NOTE[$1]="exit $2, $f FAIL line(s)"
  elif [ "$p" = 0 ]; then STATUS[$1]=FAIL; NOTE[$1]="exit 0 but no PASS line: nothing was checked"
  elif [ "$s" != 0 ]; then STATUS[$1]=PARTIAL; NOTE[$1]="$p passed, $s skipped: $(grep '^SKIP' "$3" | cut -c7- | tr '\n' ';')"
  else STATUS[$1]=PASS; NOTE[$1]="$p checks passed"; fi
  local n; n=$(grep -c '^NOTE' "$3")
  [ "$n" = 0 ] || NOTE[$1]="${NOTE[$1]}; NOTE: $(grep '^NOTE' "$3" | cut -c7- | tr '\n' ';')"
}
run_stage() {  # $1 = name, rest = command
  local name="$1"; shift; ORDER+=("$name")
  local log="$L/$(echo "$name" | tr ' /' '__').log"
  echo; echo "===== $name"; local t0=$SECONDS
  "$@" 2>&1 | tee "$log"; RC[$name]=${PIPESTATUS[0]}
  classify "$name" "${RC[$name]}" "$log"; NOTE[$name]="${NOTE[$name]} [$((SECONDS - t0)) s]"
}
skip_stage() { ORDER+=("$1"); STATUS[$1]=SKIPPED; NOTE[$1]="$2"; echo; echo "===== $1"; echo "SKIPPED: $2"; }
have_java() { command -v "$JAVA" >/dev/null 2>&1 && command -v "$JAVAC" >/dev/null 2>&1; }
java_stage() {  # name, command...
  if [ "${SKIP_JAVA:-0}" = 1 ]; then skip_stage "$1" "SKIP_JAVA=1"
  elif ! have_java; then skip_stage "$1" "JDK not found ($JAVA/$JAVAC)"
  else run_stage "$@"; fi
}

run_stage "0 manifest" bash "$HERE/00_manifest.sh"
if [ "${SKIP_ISABELLE:-0}" = 1 ]; then skip_stage "1 isabelle" "SKIP_ISABELLE=1"
elif [ -z "${ISABELLE_HOME:-}" ]; then skip_stage "1 isabelle" "ISABELLE_HOME not set"
else run_stage "1 isabelle" bash "$HERE/01_isabelle.sh"; fi
run_stage "2 generators" bash "$HERE/02_generators.sh"
run_stage "3 chain [submitted]" env WEV_IMPL=submitted bash "$HERE/03_chain.sh"
java_stage "3c chain [corrected]" env WEV_IMPL=corrected bash "$HERE/03_chain.sh"
java_stage "4 impl smoke [submitted]" bash "$HERE/04_impl_smoke.sh"
run_stage "5 claims" $PY "$HERE/05_claims.py" "$PKG"
if [ "${RUN_FULL:-0}" = 1 ]; then
  java_stage "6 repair full [submitted]" $PY "$HERE/06_repair.py" "$PKG" --impl submitted
  java_stage "6c repair full [corrected]" $PY "$HERE/06_repair.py" "$PKG" --impl corrected
else
  java_stage "6 repair smoke [submitted]" $PY "$HERE/06_repair.py" "$PKG" --impl submitted --smoke
  java_stage "6c repair smoke [corrected]" $PY "$HERE/06_repair.py" "$PKG" --impl corrected --smoke
fi
if [ "${SKIP_JAVA:-0}" = 1 ] || ! have_java; then
  run_stage "7 provenance (without Java part D)" $PY "$HERE/07_provenance.py" "$PKG"
else
  run_stage "7 provenance" $PY "$HERE/07_provenance.py" "$PKG" --with-java
fi
java_stage "8 corrected build [corrected vs submitted]" bash "$HERE/08_corrected_build.sh"
java_stage "9 unit + regression tests [both builds]" bash "$HERE/09_unit_tests.sh"
if [ "${RUN_FULL:-0}" = 1 ] && [ "${SKIP_JAVA:-0}" != 1 ] && have_java; then
  run_stage "10 six-model results [both builds, full rerun]" $PY "$HERE/10_results.py" "$PKG" --rerun
else
  run_stage "10 six-model results [both builds, from packaged rows]" $PY "$HERE/10_results.py" "$PKG"
fi
java_stage "11 reference checker [corrected vs separate checker]" bash "$HERE/11_reference.sh"

echo; echo "===== SUMMARY  (logs: $L)"
nf=0; ns=0
for k in "${ORDER[@]}"; do
  printf '  %-58s %-8s %s\n' "$k" "${STATUS[$k]}" "${NOTE[$k]}"
  case "${STATUS[$k]}" in FAIL) nf=$((nf + 1)) ;; SKIPPED|PARTIAL) ns=$((ns + 1)) ;; esac
done
if [ "$nf" != 0 ]; then echo "RESULT: FAILED -- $nf stage(s) failed"; exit 1; fi
if [ "$ns" != 0 ]; then
  echo "RESULT: no failures, but $ns stage(s) SKIPPED or PARTIAL -- those checks did NOT run"
  [ "${REQUIRE_ALL:-0}" = 1 ] && { echo "REQUIRE_ALL=1: treating skipped checks as failure"; exit 1; }
  exit 0
fi
echo "RESULT: all ${#ORDER[@]} stages passed"
exit 0
