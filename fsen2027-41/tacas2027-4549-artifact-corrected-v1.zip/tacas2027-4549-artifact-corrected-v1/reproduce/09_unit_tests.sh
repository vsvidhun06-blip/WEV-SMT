#!/usr/bin/env bash
# 9. Unit and regression tests, for BOTH implementations, with identical inputs.
#   (a) SUBMITTED build: impl/snapshot/src/test (13 files) against impl/classes  -> expect 123/123
#   (b) CORRECTED build: impl-corrected-v1/snapshot/src/test (15 files: the 13 above plus
#       WellFormednessAdequacyTest and cli/F01CorpusRegressionTest) against
#       impl-corrected-v1/classes                                                -> expect 140/140
#   (c) the 17 new regression tests compiled against and run on the SUBMITTED build: they must
#       fail in exactly the 7 defect-specific tests (CX-1 well-formedness, CX-1 verdicts, the
#       wired CX-1 query, gated well-formedness, the 3 corpus files) and pass the other 10
#       (preservation checks and LB-real/LB-copy controls). This demonstrates the defect and
#       that the tests detect it.
# The tests read inputs from the package (read-only): eval/examples is staged in $WORK as a
# copy of inputs/examples (the tests hard-code the development path), and the regression
# tests get -Dwev.packageRoot=<package>. JUnit runs through the bundled
# junit-platform-console-standalone 1.11.3 (deps/m2).
source "$(dirname "$0")/common.sh"
setup_java_env
U="$WORK/unit-tests"; rm -rf "$U"; mkdir -p "$U"
CS="$M2_REPO/org/junit/platform/junit-platform-console-standalone/1.11.3/junit-platform-console-standalone-1.11.3.jar"
CS_SHA=$(sed -n 's/^\([0-9a-f]\{64\}\)  .*junit-platform-console-standalone-1.11.3.jar$/\1/p' "$PKG/deps/DEPENDENCY-MANIFEST.txt")
[ -n "$CS_SHA" ] && [ "$(sha "$CS")" = "$CS_SHA" ] && pass "JUnit console launcher hash ${CS_SHA:0:8}..." || fail "JUnit console launcher missing or hash mismatch"

run_suite() {  # $1 label, $2 classes dir, $3 test-source list file, $4 extra launcher selectors...
  local label="$1" classes="$2" list="$3"; shift 3
  local T="$U/$label"; mkdir -p "$T/wd/eval"
  cp -r "$PKG/inputs/examples" "$T/wd/eval/examples"
  "$JAVAC" -nowarn -encoding UTF-8 -d "$(w "$T/classes")" -cp "$(w "$classes")$SEP$(w "$CS")$SEP$DEPS_CP" @"$(w "$list")" 2> "$T/javac.log" \
    || { fail "$label: test compilation (see $T/javac.log)"; return 0; }
  ( cd "$T/wd" && "$JAVA" "-Djava.library.path=$NATIVE_DIR" "-Dwev.packageRoot=$(w "$PKG")" -jar "$(w "$CS")" execute \
      --class-path "$(w "$T/classes")$SEP$(w "$classes")$SEP$DEPS_CP" "$@" \
      --reports-dir "$(w "$T/reports")" --disable-banner --details=summary --details-theme=ascii ) > "$T/junit.log" 2>&1 || true
}
summary() { $PY - "$1" <<'EOF'
import sys, glob, xml.etree.ElementTree as ET
res = {}
for f in glob.glob(sys.argv[1] + '/reports/*.xml'):
    for tc in ET.parse(f).getroot().iter('testcase'):
        st = 'FAIL' if tc.find('failure') is not None or tc.find('error') is not None else \
             'SKIP' if tc.find('skipped') is not None else 'OK'
        res[tc.get('classname') + '#' + tc.get('name')] = st
print('\n'.join(f'{v} {k}' for k, v in sorted(res.items())))
EOF
}
# Known timing-dependent test (identical in both snapshots, NOT related to the correction):
# CorpusValidationManifestTest#exhaustedBudgetYieldsTimeoutRowsForEveryEntryAndModel runs with
# budgetMin=0 and expects TIMEOUT rows, but CorpusValidation checks `elapsed > budget` on a
# millisecond clock, so a file started in the same millisecond is still solved. Observed once
# under heavy machine load (0/15 failures when re-run alone). If it is the ONLY failure, its
# class is re-run once; the outcome is reported on a NOTE line and recorded as OK-RETRY.
KNOWN_TIMING='wev.smt.cli.CorpusValidationManifestTest#exhaustedBudgetYieldsTimeoutRowsForEveryEntryAndModel(Path, Path)'
retry_known() {  # $1 label, $2 classes dir, $3 results file
  local fails; fails=$(grep '^FAIL' "$3" | cut -c6- || true)
  [ -n "$fails" ] && [ "$fails" = "$KNOWN_TIMING" ] || return 0
  local T="$U/$1"
  ( cd "$T/wd" && "$JAVA" "-Djava.library.path=$NATIVE_DIR" -jar "$(w "$CS")" execute \
      --class-path "$(w "$T/classes")$SEP$(w "$2")$SEP$DEPS_CP" --select-class wev.smt.cli.CorpusValidationManifestTest \
      --reports-dir "$(w "$T/reports-retry")" --disable-banner --details=summary ) > "$T/junit-retry.log" 2>&1 || true
  mkdir -p "$T/retry"; mv "$T/reports-retry" "$T/retry/reports"
  if summary "$T/retry" | grep -qxF "OK $KNOWN_TIMING"; then
    sed -i "s|^FAIL $KNOWN_TIMING\$|OK-RETRY $KNOWN_TIMING|" "$3"
    echo "NOTE  ($1) known timing-dependent test failed on the first run and PASSED on one re-run: $KNOWN_TIMING"
  else
    echo "NOTE  ($1) known timing-dependent test failed again on re-run: $KNOWN_TIMING"
  fi
}
# javac @argfile lines: quoted, forward slashes (safe for spaces and for Windows JDKs)
argline() { if command -v cygpath >/dev/null 2>&1; then printf '"%s"\n' "$(cygpath -m "$1")"; else printf '"%s"\n' "$1"; fi; }
src_list() { ( cd "$1/snapshot" && find src/test/java -name '*.java' | LC_ALL=C sort | while read -r f; do argline "$1/snapshot/$f"; done ) > "$2"; }

# (a) submitted
echo "IMPLEMENTATION (a): SUBMITTED build impl/classes"
src_list "$PKG/impl" "$U/src-submitted.txt"
run_suite submitted "$PKG/impl/classes" "$U/src-submitted.txt" --scan-class-path "$(w "$U/submitted/classes")"
summary "$U/submitted" > "$U/submitted.results"
retry_known submitted "$PKG/impl/classes" "$U/submitted.results"
n=$(grep -c . "$U/submitted.results"); ok=$(grep -c '^OK' "$U/submitted.results")
[ "$n" = 123 ] && [ "$ok" = 123 ] && pass "(a) submitted build: $ok/$n unit tests pass" || fail "(a) submitted build: $ok/$n unit tests pass (expected 123/123)"

# (b) corrected
echo "IMPLEMENTATION (b): CORRECTED v1 build impl-corrected-v1/classes"
src_list "$PKG/impl-corrected-v1" "$U/src-corrected.txt"
run_suite corrected "$PKG/impl-corrected-v1/classes" "$U/src-corrected.txt" --scan-class-path "$(w "$U/corrected/classes")"
summary "$U/corrected" > "$U/corrected.results"
retry_known corrected "$PKG/impl-corrected-v1/classes" "$U/corrected.results"
n=$(grep -c . "$U/corrected.results"); ok=$(grep -c '^OK' "$U/corrected.results")
[ "$n" = 140 ] && [ "$ok" = 140 ] && pass "(b) corrected build: $ok/$n unit + regression tests pass" || fail "(b) corrected build: $ok/$n tests pass (expected 140/140)"

# (c) new regression tests on the submitted build
echo "IMPLEMENTATION (c): the 17 regression tests run on the SUBMITTED build"
RT="$PKG/impl-corrected-v1/snapshot/src/test/java/wev/smt"
{ argline "$RT/WellFormednessAdequacyTest.java"; argline "$RT/cli/F01CorpusRegressionTest.java"; } > "$U/src-regression.txt"
run_suite regression-on-submitted "$PKG/impl/classes" "$U/src-regression.txt" \
  --select-class wev.smt.WellFormednessAdequacyTest --select-class wev.smt.cli.F01CorpusRegressionTest
summary "$U/regression-on-submitted" > "$U/regression-on-submitted.results"
cat "$U/regression-on-submitted.results" | sed 's/^/  /'
cat > "$U/expected-failures.txt" <<'EOF'
FAIL wev.smt.WellFormednessAdequacyTest#cx1QueryWithRfAndCoUnfixed()
FAIL wev.smt.WellFormednessAdequacyTest#cx1VerdictsWithWellFormednessMatchTheRelationalAnalysis()
FAIL wev.smt.WellFormednessAdequacyTest#cx1WellFormednessAloneAdmitsTheLegalCandidate()
FAIL wev.smt.WellFormednessAdequacyTest#gatedWellFormednessAdmitsCx1WhenAllEventsAreActive()
FAIL wev.smt.cli.F01CorpusRegressionTest#aarch64Mixed2plus2WPosw0q0()
FAIL wev.smt.cli.F01CorpusRegressionTest#ppc2plus2WRfiDatas()
FAIL wev.smt.cli.F01CorpusRegressionTest#x86M55ii()
EOF
n=$(grep -c . "$U/regression-on-submitted.results")
grep '^FAIL' "$U/regression-on-submitted.results" | LC_ALL=C sort | diff -q - <(LC_ALL=C sort "$U/expected-failures.txt") >/dev/null \
  && [ "$n" = 17 ] && [ "$(grep -c '^OK' "$U/regression-on-submitted.results")" = 10 ] \
  && pass "(c) on the submitted build exactly the 7 defect-specific regression tests fail; the other 10 pass" \
  || fail "(c) regression tests on the submitted build: unexpected outcome (see $U/regression-on-submitted.results)"
finish
