"""Shared Java setup for the Python reproduction stages (corrected-v1 package).

Mirrors setup_java_env / select_impl in common.sh:
  * jars from impl/DEPENDENCIES.txt (the model jar from impl/deps/), each SHA-256-verified;
  * the Z3 natives for this platform from deps/NATIVES.txt, SHA-256-verified, staged in WORK;
  * M2_REPO defaults to the bundled deps/m2;
  * implementation selection: 'submitted' = impl/ (the build behind the submitted
    manuscript), 'corrected' = impl-corrected-v1/ (NOT the submitted build).
"""
import hashlib
import os
import platform
import shutil
import sys
from pathlib import Path

PIN_CLASSES_SUBMITTED = '86f068947142ad3e44a80ca77447744858a29190703d2d8c76f22aafabd6bced'


def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def native_platform():
    m = platform.machine().lower()
    if m not in ('x86_64', 'amd64'):
        return None
    if sys.platform.startswith('linux'):
        return 'linux-x64'
    if os.name == 'nt' or sys.platform in ('cygwin', 'msys'):
        return 'windows-x64'
    return None


def work_dir(P, default_name='_repro-work'):
    """WORK resolved outside the package; refuses in-package, ancestor, '/' and $HOME."""
    P = Path(P).resolve()
    W = Path(os.environ.get('WORK', str(P.parent / default_name))).resolve()
    home = Path.home().resolve()
    if W == P or P in W.parents:
        sys.exit(f'REFUSED: WORK={W} is inside the package {P}')
    if W in P.parents:
        sys.exit(f'REFUSED: WORK={W} is an ancestor of the package {P}')
    if W == Path(W.anchor) or W == home:
        sys.exit(f'REFUSED: WORK={W} is a filesystem root or $HOME')
    W.mkdir(parents=True, exist_ok=True)
    return W


def setup(P, native_dir):
    """Return (classpath list of dependency jars, staged native dir, path separator)."""
    P = Path(P)
    M = Path(os.environ.get('M2_REPO') or (P / 'deps/m2'))
    plat = native_platform()
    if plat is None:
        sys.exit(f'UNSUPPORTED platform for the Z3 natives: {sys.platform}/{platform.machine()}')
    cp = []
    for line in (P / 'impl/DEPENDENCIES.txt').read_text().splitlines():
        if not line or line.startswith('#') or line.startswith('NATIVE'):
            continue
        h, rel = line.split()
        f = M / rel
        if rel.startswith('com/weakest/'):
            f = P / 'impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar'
        assert f.is_file(), f'MISSING jar {rel} (M2_REPO={M})'
        assert sha256(f) == h, f'HASH MISMATCH {rel}'
        cp.append(str(f))
    N = Path(native_dir)
    N.mkdir(parents=True, exist_ok=True)
    n = 0
    for line in (P / 'deps/NATIVES.txt').read_text().splitlines():
        if not line.startswith('NATIVE'):
            continue
        _, pl, h, rel, name = line.split()
        if pl != plat:
            continue
        f = M / rel
        assert f.is_file(), f'MISSING native {rel}'
        assert sha256(f) == h, f'HASH MISMATCH {rel}'
        shutil.copy2(f, N / name)
        n += 1
    assert n == 2, f'expected 2 natives for {plat}, staged {n}'
    return cp, N, (';' if os.name == 'nt' else ':')


def impl(P, name):
    """Return (classes dir, label) for 'submitted' or 'corrected'; prints the label."""
    P = Path(P)
    if name == 'submitted':
        d, label = P / 'impl', 'SUBMITTED build (impl/, classes 86f06894..., the build behind the submitted manuscript)'
    elif name == 'corrected':
        pin = [l.split()[1] for l in (P / 'impl-corrected-v1/PIN.txt').read_text().splitlines()
               if l.startswith('classes_sha256 ')][0]
        d, label = P / 'impl-corrected-v1', f'CORRECTED v1 build (impl-corrected-v1/, classes {pin[:8]}..., NOT the submitted build)'
    else:
        sys.exit(f"--impl must be 'submitted' or 'corrected', got {name!r}")
    print('IMPLEMENTATION:', label, flush=True)
    return d / 'classes', label
