#!/usr/bin/env python3
"""10. Six-model results of the SUBMITTED and the CORRECTED build, compared.

Every figure below is RECOMPUTED from packaged rows (no recorded summary is trusted):
  [submitted] = results/authoritative/ppo-repair/six-model/repaired-symbolic.csv and
                repaired-wired-847.csv: the rows behind the submitted manuscript (unchanged);
  [submitted rerun] = results/corrected-v1/rerun-submitted-2026-10-19/: the same submitted
                build re-run on 2026-10-19 with identical settings;
  [corrected] = results/corrected-v1/six-model/: the corrected v1 build, same settings.
Checks: row structure and result categories; the submitted rerun reproduces the authoritative
verdicts; submitted vs corrected differ in exactly the 12 F-01 cells (3 files x PSO/RA/
WEAKEST/RC11, all FORBIDDEN->ALLOWED); both sets of totals; SC/TSO unchanged; the seven
implications and TSO=>WEAKEST; the 187/0 WEAKEST/RC11 split; herd7 agreement recomputed
against the corrected verdicts (herd7 itself is NOT re-run: recorded herd7 rows); the
wired 847-file table; the six discriminators (wired ablation re-run with both builds); the
Table 2 ring audit with the corrected build.

--rerun additionally re-runs, with both builds and the authoritative settings
(perFileSec=30 budgetMin=600 maxEvents=64): the 2,396-file symbolic and 847-file wired
six-model runs and the wired discriminator ablation, and compares the fresh outputs with the
packaged ones (verdict columns; timing columns ignored). About 15-25 minutes.

Usage: python 10_results.py [<package-dir>] [--rerun]
"""
import csv
import json
import os
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import javaenv  # noqa: E402

args = [a for a in sys.argv[1:] if not a.startswith('--')]
RERUN = '--rerun' in sys.argv
P = Path(args[0]).resolve() if args else Path(__file__).resolve().parent.parent
AU = P / 'results/authoritative/ppo-repair/six-model'
CV = P / 'results/corrected-v1'
M = ['SC', 'TSO', 'PSO', 'RA', 'WEAKEST', 'RC11']
F01 = ['Dat3M/litmus/PPC/2+2W+rfi-datas.litmus', 'Dat3M/litmus/X86/m55ii.litmus',
       'Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009.litmus']
fails = []


def out(ok, msg):
    print(('PASS  ' if ok else 'FAIL  ') + msg, flush=True)
    if not ok:
        fails.append(msg)


def rd(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def verdicts(rows):
    return {(r['file'], r['model']): r['verdict'] for r in rows}


def totals(V):
    files = sorted({k[0] for k in V})
    return {m: (sum(V[(f, m)] == 'ALLOWED' for f in files), sum(V[(f, m)] == 'FORBIDDEN' for f in files)) for m in M}


elig = [r['path'] for r in rd(P / 'corpus/manifests/frozen-eligible-hashes.csv')]
A_rows = rd(AU / 'repaired-symbolic.csv')
C_rows = rd(CV / 'six-model/corrected-symbolic.csv')
S_rows = rd(CV / 'rerun-submitted-2026-10-19/symbolic.csv')
A, C, S = verdicts(A_rows), verdicts(C_rows), verdicts(S_rows)

for label, rows in (('submitted', A_rows), ('submitted rerun', S_rows), ('corrected', C_rows)):
    cats = Counter(r['result'] for r in rows)
    keys = {(r['file'], r['model']) for r in rows}
    ok = (len(rows) == 14376 and len(keys) == 14376 and set(cats) <= {'SAT', 'UNSAT'}
          and {k[0] for k in keys} == set(elig)
          and all((r['result'] == 'SAT') == (r['verdict'] == 'ALLOWED') for r in rows))
    out(ok, f'[{label}] {len(rows)} rows = 2,396 eligible files x 6 models; results {dict(cats)}; '
            f'0 UNKNOWN/TIMEOUT/ERROR/UNSUPPORTED')

dS = sorted(k for k in A if A[k] != S.get(k))
out(not dS, f'[submitted rerun] reproduces the authoritative submitted verdicts on {14376 - len(dS)}/14376 cells')

diff = sorted(k for k in A if A[k] != C[k])
exp = sorted((f, m) for f in F01 for m in ('PSO', 'RA', 'WEAKEST', 'RC11'))
out(diff == exp and all(A[k] == 'FORBIDDEN' and C[k] == 'ALLOWED' for k in diff),
    f'[submitted vs corrected] exactly {len(diff)} cells differ: 3 files x PSO/RA/WEAKEST/RC11, all FORBIDDEN->ALLOWED')
for k in diff:
    print(f'      {k[0]}  {k[1]}: {A[k]} -> {C[k]}')

TA, TC = totals(A), totals(C)
want_A = {'SC': (36, 2360), 'TSO': (563, 1833), 'PSO': (1170, 1226), 'RA': (2089, 307), 'WEAKEST': (2356, 40), 'RC11': (2169, 227)}
want_C = {'SC': (36, 2360), 'TSO': (563, 1833), 'PSO': (1173, 1223), 'RA': (2092, 304), 'WEAKEST': (2359, 37), 'RC11': (2172, 224)}
out(TA == want_A, f'[submitted] ALLOWED/FORBIDDEN totals as printed in the submitted paper: {TA}')
out(TC == want_C, f'[corrected] ALLOWED/FORBIDDEN totals: {TC}')
out(all(A[(f, m)] == C[(f, m)] for f in elig for m in ('SC', 'TSO')), '[both] SC and TSO verdicts identical on all 2,396 files')

IMPL = [('SC', 'TSO'), ('SC', 'PSO'), ('SC', 'RA'), ('SC', 'WEAKEST'), ('SC', 'RC11'), ('RC11', 'WEAKEST'), ('PSO', 'RA')]
for label, V in (('submitted', A), ('corrected', C)):
    viol = {f'{a}=>{b}': sum(V[(f, a)] == 'ALLOWED' and V[(f, b)] == 'FORBIDDEN' for f in elig) for a, b in IMPL}
    tso_w = sum(V[(f, 'TSO')] == 'ALLOWED' and V[(f, 'WEAKEST')] == 'FORBIDDEN' for f in elig)
    out(not any(viol.values()) and tso_w == 0, f'[{label}] seven derivable implications: 0 violations; measured TSO=>WEAKEST: {tso_w}')
    split = (sum(V[(f, 'WEAKEST')] == 'ALLOWED' and V[(f, 'RC11')] == 'FORBIDDEN' for f in elig),
             sum(V[(f, 'RC11')] == 'ALLOWED' and V[(f, 'WEAKEST')] == 'FORBIDDEN' for f in elig))
    out(split == (187, 0), f'[{label}] WEAKEST-ALLOWED/RC11-FORBIDDEN split {split[0]}/{split[1]} (expected 187/0)')

herd = {r['relpath']: r for r in rd(P / 'results/authoritative/rerun-2026-10-09/herd7-frozen-results.csv')}
x86 = rd(P / 'results/authoritative/ppo-repair/herd7-x86-results.csv')
for label, V in (('submitted', A), ('corrected', C)):
    comp = [f for f in elig if herd[f]['herd_sc'] in ('ALLOWED', 'FORBIDDEN')]
    agree = sum(herd[f]['herd_sc'] == V[(f, 'SC')] for f in comp)
    xs = [r for r in x86 if r['herd_tso'] in ('ALLOWED', 'FORBIDDEN')]
    xa = sum(r['herd_tso'] == V[(r['relpath'], 'TSO')] for r in xs)
    out((len(comp), agree, len(xs), xa) == (1772, 1772, 101, 101),
        f'[{label}] recorded herd7 7.58 rows (herd7 NOT re-run): sc.cat {agree}/{len(comp)}, x86tso.cat {xa}/{len(xs)}')

AW = verdicts(rd(AU / 'repaired-wired-847.csv'))
CW = verdicts(rd(CV / 'six-model/corrected-wired-847.csv'))
out(AW == CW and len(CW) == 847 * 6, f'[both] wired 847-file six-model table identical under both builds ({len(CW)} cells)')
wf = sorted({k[0] for k in CW})
wd = {m: sum(CW[(f, m)] != C[(f, m)] for f in wf) for m in M}
out(wd == {'SC': 0, 'TSO': 1, 'PSO': 16, 'RA': 44, 'WEAKEST': 44, 'RC11': 31},
    f'[corrected] wired-vs-symbolic differences on the 847 files unchanged: {wd}')

sd_a = P / 'results/authoritative/rerun-2026-10-09/sdep/sdep-discriminating-all-fake-tests.csv'
sd_c = CV / 'ablation/sdep-discriminating-all-fake-tests.csv'
disc = lambda p: sorted(r['file'] for r in rd(p) if r['discriminating'] == 'true')
out(sd_a.read_bytes() == sd_c.read_bytes() and len(disc(sd_c)) == 6 and len(rd(sd_c)) == 370,
    f'[both] wired discriminator ablation: corrected-build output byte-identical to the submitted one; 6/370: {disc(sd_c)}')

ring = CV / 'ring-audit/symbolic-ring-audit-corrected.csv'
out(ring.read_bytes() == (P / 'repair/symbolic-ring-audit.csv').read_bytes(),
    '[corrected] Table 2 ring audit (3,656 rows) with the corrected build is byte-identical to repair/symbolic-ring-audit.csv')

if RERUN:
    W = javaenv.work_dir(P) / 'results-rerun'
    W.mkdir(parents=True, exist_ok=True)
    for b in ('submitted', 'corrected'):
        classes, label = javaenv.impl(P, b)
        deps, N, sep = javaenv.setup(P, W / 'native')
        cp = sep.join([str(classes)] + deps)
        jv = [os.environ.get('JAVA', 'java'), '-Djava.library.path=' + str(N), '-cp', cp]
        for mode, man, extra in (('symbolic', 'frozen-eligible-hashes.csv', ['mode=symbolic']),
                                 ('wired', 'wired-847-hashes.csv', [])):
            o = W / f'{b}-{mode}'
            t0 = time.time()
            r = subprocess.run(jv + ['wev.smt.cli.CorpusValidation', str(P / 'corpus/litmus'), str(o),
                                     'manifest=' + str(P / 'corpus/manifests' / man), 'csv=r.csv'] + extra
                               + ['perFileSec=30', 'budgetMin=600', 'maxEvents=64'],
                               capture_output=True, text=True)
            new = verdicts(rd(o / 'r.csv'))
            ref = {('submitted', 'symbolic'): A, ('submitted', 'wired'): AW,
                   ('corrected', 'symbolic'): C, ('corrected', 'wired'): CW}[(b, mode)]
            out(r.returncode == 0 and new == ref,
                f'[{b} rerun] {mode} six-model run reproduces the packaged {b} verdicts '
                f'({len(new)} cells, {time.time() - t0:.0f} s)')
        o = W / f'{b}-ablation'
        r = subprocess.run(jv + ['wev.smt.ablation.SdepFakeDiscriminatingRun',
                                 'manifest=' + str(P / 'corpus/manifests/frozen-eligible-manifest.csv'),
                                 'corpusRoot=' + str(P / 'corpus/litmus'), 'out=' + str(o),
                                 'timeoutSec=30', 'maxEvents=64'], capture_output=True, text=True)
        out(r.returncode == 0 and (o / 'sdep-discriminating-all-fake-tests.csv').read_bytes() == sd_a.read_bytes(),
            f'[{b} rerun] wired discriminator ablation byte-identical to the authoritative CSV')
else:
    print('NOTE  --rerun not given (rows mode): the full 2,396 x 6 symbolic, 847 x 6 wired and ablation re-runs of both builds were not executed (rows checked only)')

print(f'SUMMARY: {len(fails)} failed check(s)')
sys.exit(1 if fails else 0)
