#!/usr/bin/env bash
# Shared environment for the reproduction scripts. Source it; do not run it.
# (corrected-v1 package, 2026-10-19; the 2026-10-12 version is kept verbatim under
#  history/package-20261012/reproduce/common.sh)
#
# Inputs (environment variables):
#   WORK      scratch directory for all outputs. Default: ../_repro-work next to the package.
#             It must resolve OUTSIDE the package and must not be "/", $HOME or an ancestor
#             of the package; anything else is refused. Nothing under the package is modified.
#   M2_REPO   Maven-layout directory holding the pinned jars of impl/DEPENDENCIES.txt and the
#             natives of deps/NATIVES.txt. Default: the bundled deps/m2 (every file is still
#             verified against its pinned SHA-256 before use).
#   PYTHON    Python 3 with the z3-solver module (default: python3, else python).
#   JAVA, JAVAC  JDK 21 tools (default: java, javac on PATH).
#   WEV_IMPL  which implementation a Java stage runs: "submitted" (impl/, the build behind the
#             submitted manuscript) or "corrected" (impl-corrected-v1/). Stages that support
#             both print the one they use; see VERSION-MAP.md.
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
if [ -z "${M2_REPO:-}" ]; then M2_REPO="$PKG/deps/m2"; fi
WORK="${WORK:-$PKG/../_repro-work}"

# ── WORK safety guard ───────────────────────────────────────────────────────────
if [ -e "$WORK" ] && [ ! -d "$WORK" ]; then echo "REFUSED: WORK=$WORK exists and is not a directory" >&2; exit 2; fi
# Resolve WITHOUT creating anything (realpath -m), so a refused WORK leaves no directory behind.
WORK="$(realpath -m -- "$WORK")"
case "$WORK/" in
  "$PKG"/*) echo "REFUSED: WORK=$WORK is inside the package $PKG" >&2; exit 2 ;;
esac
case "$PKG/" in
  "$WORK"/*) echo "REFUSED: WORK=$WORK is an ancestor of the package $PKG" >&2; exit 2 ;;
esac
if [ "$WORK" = "/" ] || [ "$WORK" = "$(cd "$HOME" 2>/dev/null && pwd -P || echo /nonexistent)" ]; then
  echo "REFUSED: WORK=$WORK is / or \$HOME" >&2; exit 2
fi
mkdir -p "$WORK"
export WORK

JAVA="${JAVA:-java}"; JAVAC="${JAVAC:-javac}"
if [ -z "${PYTHON:-}" ]; then
  if command -v python3 >/dev/null 2>&1 && python3 -c 'import sys' >/dev/null 2>&1; then PYTHON=python3; else PYTHON=python; fi
fi
PY="$PYTHON -I -B -X utf8"   # -X utf8: UTF-8 stdout on every platform (-I ignores PYTHONIOENCODING)

# Path conversion for native Windows JVMs under Git Bash / Cygwin.
if command -v cygpath >/dev/null 2>&1; then
  w() { cygpath -w "$1"; }; SEP=';'
else
  w() { printf '%s' "$1"; }; SEP=':'
fi

# Platform of the Z3 natives (deps/NATIVES.txt).
case "$(uname -s)-$(uname -m)" in
  Linux-x86_64) NATIVE_PLATFORM=linux-x64 ;;
  MINGW*-x86_64|MSYS*-x86_64|CYGWIN*-x86_64) NATIVE_PLATFORM=windows-x64 ;;
  *) NATIVE_PLATFORM="unsupported:$(uname -s)-$(uname -m)" ;;
esac

sha() { sha256sum "$1" | cut -c1-64; }

# Build the runtime classpath from impl/DEPENDENCIES.txt (identical for both implementations),
# verifying every jar's SHA-256, and stage this platform's Z3 natives from deps/NATIVES.txt
# into $WORK/native (hash-verified). The NATIVE rows of impl/DEPENDENCIES.txt are the
# windows-x64 rows of deps/NATIVES.txt.
setup_java_env() {
  local cp="" line h rel name plat n=0
  case "$NATIVE_PLATFORM" in unsupported:*) echo "UNSUPPORTED platform for the Z3 natives: $NATIVE_PLATFORM" >&2; return 1 ;; esac
  mkdir -p "$WORK/native"
  while IFS= read -r line; do
    case "$line" in
      '#'*|''|NATIVE*) continue ;;
    esac
    read -r h rel <<<"$line"
    local f="$M2_REPO/$rel"
    case "$rel" in com/weakest/visualising-weakest-executions/*)
      f="$PKG/impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar" ;; esac
    [ -f "$f" ] || { echo "MISSING jar: $rel (M2_REPO=$M2_REPO)" >&2; return 1; }
    [ "$(sha "$f")" = "$h" ] || { echo "HASH MISMATCH: $rel" >&2; return 1; }
    cp="${cp:+$cp$SEP}$(w "$f")"
  done < "$PKG/impl/DEPENDENCIES.txt"
  while IFS= read -r line; do
    case "$line" in NATIVE*) ;; *) continue ;; esac
    read -r _ plat h rel name <<<"$line"
    [ "$plat" = "$NATIVE_PLATFORM" ] || continue
    [ -f "$M2_REPO/$rel" ] || { echo "MISSING native: \$M2_REPO/$rel" >&2; return 1; }
    [ "$(sha "$M2_REPO/$rel")" = "$h" ] || { echo "HASH MISMATCH: $rel" >&2; return 1; }
    cp "$M2_REPO/$rel" "$WORK/native/$name"; n=$((n + 1))
  done < "$PKG/deps/NATIVES.txt"
  [ "$n" = 2 ] || { echo "expected 2 natives for $NATIVE_PLATFORM, staged $n" >&2; return 1; }
  DEPS_CP="$cp"
  NATIVE_DIR="$(w "$WORK/native")"
  export DEPS_CP NATIVE_DIR
}

# -b: binary-mode lines ('hash *path') on every platform; Git Bash's default, which the pins assume
classes_hash() { ( cd "$1" && find . -name '*.class' | LC_ALL=C sort | xargs sha256sum -b | sha256sum | cut -c1-64 ); }
PIN_CLASSES=86f068947142ad3e44a80ca77447744858a29190703d2d8c76f22aafabd6bced
PIN_SNAPSHOT=04d5604b133bc7d7a3b329843a7be9c6070e44f2d7e917b3b0075340f7f827e2
PIN_MANIFEST=ae011be3422cacff9d08a742650906c846f4a22590bffc06885d86ff59fa4036
# corrected-v1 pins (impl-corrected-v1/PIN.txt); these never replace the submitted pins above
PIN_CLASSES_CORRECTED=$(sed -n 's/^classes_sha256 //p' "$PKG/impl-corrected-v1/PIN.txt" 2>/dev/null || true)
PIN_SNAPSHOT_CORRECTED=$(sed -n 's/^snapshot_sha256 //p' "$PKG/impl-corrected-v1/PIN.txt" 2>/dev/null || true)

# Implementation selection: sets IMPL_DIR, IMPL_CLASSES, IMPL_PIN_CLASSES, IMPL_LABEL.
select_impl() {
  case "${1:-}" in
    submitted) IMPL_DIR="$PKG/impl"; IMPL_PIN_CLASSES=$PIN_CLASSES
               IMPL_LABEL="SUBMITTED build (impl/, classes ${PIN_CLASSES:0:8}..., the build behind the submitted manuscript)" ;;
    corrected) IMPL_DIR="$PKG/impl-corrected-v1"; IMPL_PIN_CLASSES=$PIN_CLASSES_CORRECTED
               IMPL_LABEL="CORRECTED v1 build (impl-corrected-v1/, classes ${PIN_CLASSES_CORRECTED:0:8}..., NOT the submitted build)" ;;
    *) echo "select_impl: expected 'submitted' or 'corrected', got '${1:-}'" >&2; return 2 ;;
  esac
  IMPL_CLASSES="$IMPL_DIR/classes"
  echo "IMPLEMENTATION: $IMPL_LABEL"
}

# same_text NEW RECORDED LABEL: PASS if byte-identical; PASS (stated explicitly) if identical
# after CRLF->LF normalisation -- the recorded outputs were produced on Windows, where Java
# println writes CRLF; FAIL otherwise. Never hides a content difference.
same_text() {
  if cmp -s "$1" "$2"; then pass "$3 identical"
  elif cmp -s <(tr -d '\r' < "$1") <(tr -d '\r' < "$2"); then pass "$3 identical modulo line endings (CRLF vs LF only)"
  else fail "$3 differs"; fi
}
pass() { echo "PASS  $*"; }
fail() { echo "FAIL  $*"; FAILS=$(( ${FAILS:-0} + 1 )); }
skip() { echo "SKIP  $*"; }
# Exit with the number of failed checks, capped so that it can never wrap to 0.
finish() { local n=${FAILS:-0}; [ "$n" -gt 125 ] && n=125; exit "$n"; }
