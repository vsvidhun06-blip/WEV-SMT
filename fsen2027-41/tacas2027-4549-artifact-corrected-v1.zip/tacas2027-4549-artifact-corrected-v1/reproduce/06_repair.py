#!/usr/bin/env python3
"""6. Regenerate the symbolic ring audit behind Table 2 (repair/symbolic-ring-audit.csv).

Usage: python 06_repair.py [<package-dir>] --impl submitted|corrected [--smoke]
  --impl     REQUIRED. 'submitted' = impl/ (the build behind the submitted manuscript);
             'corrected' = impl-corrected-v1/ (NOT the submitted build). Both are compared
             against the same recorded audit: the correction does not change Table 2.
  --smoke    three expressions at both ring sizes (6 rows) instead of all 1,828 (3,656 rows).
Environment: WORK (outside the package), M2_REPO (default: bundled deps/m2), JAVA, JAVAC,
REPAIR_TIMEOUT_SEC (default 14400 for the full run).
(corrected-v1 package; the 2026-10-12 version is in history/package-20261012/reproduce/.)
"""
import argparse
import csv
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import javaenv  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument('package', nargs='?', default=str(Path(__file__).resolve().parent.parent))
ap.add_argument('--impl', required=True, choices=['submitted', 'corrected'])
ap.add_argument('--smoke', action='store_true')
args = ap.parse_args()
P = Path(args.package).resolve()
W = javaenv.work_dir(P) / f'repair-{args.impl}{"-smoke" if args.smoke else ""}'
W.mkdir(parents=True, exist_ok=True)
classes, label = javaenv.impl(P, args.impl)
deps, N, sep = javaenv.setup(P, W / 'native')
cp = [str(classes)] + deps
C = W / 'classes'
C.mkdir(exist_ok=True)
subprocess.run([os.environ.get('JAVAC', 'javac'), '-proc:none', '-encoding', 'UTF-8', '-cp', sep.join(cp),
                '-d', str(C), str(P / 'repair/SymbolicRingAudit.java')], check=True)
output = W / ('symbolic-ring-smoke.csv' if args.smoke else 'symbolic-ring-audit.csv')
candidate = P / 'hardbench/generated-hard-candidates.json'
expect = list(csv.DictReader((P / 'repair/symbolic-ring-audit.csv').open(newline='', encoding='utf-8')))
if args.smoke:
    chosen = []
    for const, base in [('true', 'SAT'), ('false', 'SAT'), ('false', 'UNSAT')]:
        chosen.append(next(r['expr'] for r in expect if r['oracle_constant'] == const and r['value_consistency'] == base))
    candidate = W / 'smoke-candidates.json'
    candidate.write_text(json.dumps(chosen), encoding='utf-8')
    expect = [r for e in chosen for r in expect if r['expr'] == e]

t0 = time.time()
timeout = None if args.smoke else int(os.environ.get('REPAIR_TIMEOUT_SEC', '14400'))
subprocess.run([os.environ.get('JAVA', 'java'), '-Djava.library.path=' + str(N), '-cp', sep.join([str(C)] + cp),
                'SymbolicRingAudit', str(candidate), str(output)], check=True, timeout=timeout)
secs = time.time() - t0
got = list(csv.DictReader(output.open(newline='', encoding='utf-8')))
if got == expect:
    print(f'PASS  {len(got)} symbolic ring rows match repair/symbolic-ring-audit.csv exactly '
          f'[{args.impl}; solver run {secs:.0f} s]')
    sys.exit(0)
diff = sum(a != b for a, b in zip(got, expect)) + abs(len(got) - len(expect))
print(f'FAIL  symbolic verdicts differ from the recorded audit: {diff} row(s) [{args.impl}]')
sys.exit(1)
