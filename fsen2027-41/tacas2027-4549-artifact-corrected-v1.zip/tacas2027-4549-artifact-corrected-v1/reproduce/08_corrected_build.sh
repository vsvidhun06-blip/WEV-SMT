#!/usr/bin/env bash
# 8. The CORRECTED v1 implementation (impl-corrected-v1/), checked against the SUBMITTED one.
#   - corrected snapshot sources match impl-corrected-v1/PIN.txt; a fresh javac build reproduces
#     the corrected pinned classes;
#   - the corrected snapshot differs from the submitted snapshot ONLY in EventStructureEncoder,
#     MinimalWitnessExtractor and two added test files, and its classes differ from the
#     submitted pinned classes in exactly three class files;
#   - the audit's F-01 probes (correction-record/audit-2026-10-17/probes/litmus) under BOTH
#     builds, symbolic mode: 2+2W+rfis must be all-FORBIDDEN under the submitted build and
#     SC/TSO F, PSO/RA/WEAKEST/RC11 A under the corrected one; 2+2W and S+rfi must agree;
#   - the 30-file six-model subset of stage 4, run with the CORRECTED build, reproduces the
#     packaged corrected verdicts (results/corrected-v1/six-model/corrected-symbolic.csv).
# Requires JDK 21 and the pinned jars (bundled in deps/).
source "$(dirname "$0")/common.sh"
setup_java_env
S="$WORK/corrected-build"; rm -rf "$S"; mkdir -p "$S"
CI="$PKG/impl-corrected-v1"
echo "IMPLEMENTATIONS: CORRECTED v1 (impl-corrected-v1/) compared with SUBMITTED (impl/)"

# corrected pins
grep -E '^[0-9a-f]{64} \*' "$CI/PIN.txt" > "$S/pin-lines.txt"
( cd "$CI/snapshot" && sha256sum -c --quiet "$S/pin-lines.txt" ) \
  && pass "corrected snapshot files match impl-corrected-v1/PIN.txt ($(wc -l < "$S/pin-lines.txt") files)" \
  || fail "corrected snapshot files vs impl-corrected-v1/PIN.txt"
[ "$(sha256sum < "$S/pin-lines.txt" | cut -c1-64)" = "$PIN_SNAPSHOT_CORRECTED" ] \
  && pass "corrected snapshot aggregate ${PIN_SNAPSHOT_CORRECTED:0:8}..." || fail "corrected snapshot aggregate"
( cd "$CI/snapshot" && { echo pom.xml; find src -type f | LC_ALL=C sort; } ) > "$S/listed.txt"
sed 's/^[0-9a-f]* \*//' "$S/pin-lines.txt" | diff -q - "$S/listed.txt" >/dev/null \
  && pass "PIN lists exactly the corrected snapshot's files" || fail "corrected snapshot has unpinned or missing files"
( cd "$CI/snapshot" && find src/main/java -name '*.java' | LC_ALL=C sort ) > "$S/sources.txt"
( cd "$CI/snapshot" && "$JAVAC" -nowarn -encoding UTF-8 -d "$(w "$S/classes")" -cp "$DEPS_CP" @"$(w "$S/sources.txt")" ) 2> "$S/javac.log"
[ "$(classes_hash "$S/classes")" = "$PIN_CLASSES_CORRECTED" ] \
  && pass "fresh build of corrected snapshot reproduces corrected pinned classes ${PIN_CLASSES_CORRECTED:0:8}..." \
  || fail "fresh corrected build classes hash $(classes_hash "$S/classes")"
[ "$(classes_hash "$CI/classes")" = "$PIN_CLASSES_CORRECTED" ] \
  && pass "packaged impl-corrected-v1/classes hash ${PIN_CLASSES_CORRECTED:0:8}..." || fail "impl-corrected-v1/classes hash"
[ "$(classes_hash "$PKG/impl/classes")" = "$PIN_CLASSES" ] \
  && pass "submitted impl/classes still hash to 86f06894... (unchanged)" || fail "impl/classes hash"

# scope of the change
diff -rq "$PKG/impl/snapshot" "$CI/snapshot" 2>&1 | LC_ALL=C sort > "$S/src-diff.txt" || true
cat > "$S/src-diff-expected.txt" <<'EOF'
FILES_DIFFER src/main/java/wev/smt/EventStructureEncoder.java
FILES_DIFFER src/main/java/wev/smt/MinimalWitnessExtractor.java
ONLY_CORRECTED src/test/java/wev/smt/WellFormednessAdequacyTest.java
ONLY_CORRECTED src/test/java/wev/smt/cli/F01CorpusRegressionTest.java
EOF
$PY - "$PKG" "$S" <<'EOF' && pass "snapshots differ only in the encoder, the witness extractor and 2 added tests" || fail "unexpected source differences (see $S/src-diff-norm.txt)"
import filecmp, os, sys
from pathlib import Path
P, S = Path(sys.argv[1]), Path(sys.argv[2])
a, b = P / 'impl/snapshot', P / 'impl-corrected-v1/snapshot'
rel = lambda root: {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
ra, rb = rel(a), rel(b)
out = sorted(['FILES_DIFFER ' + f for f in ra & rb if not filecmp.cmp(a / f, b / f, shallow=False)]
             + ['ONLY_SUBMITTED ' + f for f in ra - rb] + ['ONLY_CORRECTED ' + f for f in rb - ra])
(S / 'src-diff-norm.txt').write_text('\n'.join(out) + '\n')
assert out == (S / 'src-diff-expected.txt').read_text().split('\n')[:-1], out
EOF
$PY - "$PKG" <<'EOF' && pass "classes differ in exactly EventStructureEncoder, MinimalWitnessExtractor, MinimalWitnessExtractor\$1" || fail "unexpected class differences"
import filecmp, sys
from pathlib import Path
P = Path(sys.argv[1]); a, b = P / 'impl/classes', P / 'impl-corrected-v1/classes'
fa = {p.relative_to(a).as_posix() for p in a.rglob('*.class')}
fb = {p.relative_to(b).as_posix() for p in b.rglob('*.class')}
assert fa == fb, fa ^ fb
d = sorted(f for f in fa if not filecmp.cmp(a / f, b / f, shallow=False))
print('  differing:', d)
assert d == ['wev/smt/EventStructureEncoder.class', 'wev/smt/MinimalWitnessExtractor$1.class',
             'wev/smt/MinimalWitnessExtractor.class'], d
EOF

# F-01 probes under both builds
PR="$PKG/correction-record/audit-2026-10-17/probes"
for v in submitted corrected; do
  c="$PKG/impl/classes"; [ $v = corrected ] && c="$CI/classes"
  "$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$(w "$c")$SEP$DEPS_CP" wev.smt.cli.CorpusValidation \
    "$(w "$PR/litmus")" "$(w "$S/probe-$v")" manifest="$(w "$PR/manifest.csv")" mode=symbolic csv=probe.csv \
    perFileSec=30 budgetMin=10 maxEvents=64 > "$S/probe-$v.log" 2>&1
done
$PY - "$S" <<'EOF' && pass "F-01 probes: submitted forbids 2+2W+rfis under all six; corrected allows it under PSO/RA/WEAKEST/RC11; 2+2W, S+rfi unchanged" || fail "F-01 probe verdicts"
import csv, sys
S = sys.argv[1]
def v(b):
    return {(r['file'], r['model']): r['verdict'][0] for r in csv.DictReader(open(f'{S}/probe-{b}/probe.csv', encoding='utf-8'))}
s, c = v('submitted'), v('corrected')
M = ['SC', 'TSO', 'PSO', 'RA', 'WEAKEST', 'RC11']
row = lambda d, f: ''.join(d[(f, m)] for m in M)
for f in sorted({k[0] for k in s}):
    print(f'  {f:28s} submitted {row(s, f)}  corrected {row(c, f)}   (SC TSO PSO RA WEAKEST RC11)')
for f in ('2+2W+rfis.litmus', '2+2W+rfis-pinned.litmus'):
    assert row(s, f) == 'FFFFFF' and row(c, f) == 'FFAAAA', f
for f in ('2+2W.litmus', 'S+rfi.litmus'):
    assert row(s, f) == row(c, f) == 'FFAAAA', f
EOF

# 30-file subset with the corrected build (same selection as stage 4)
$PY - "$PKG" "$S" <<'EOF'
import csv, sys
P, S = sys.argv[1], sys.argv[2]
rows = list(csv.DictReader(open(P + '/corpus/manifests/frozen-eligible-hashes.csv', newline='', encoding='utf-8')))
disc = {'Dat3M/litmus/AARCH64/SYS/LB+data+dataap.litmus', 'Dat3M/litmus/AARCH64/SYS/LB+dataaps.litmus',
        'Dat3M/litmus/AARCH64/TUTO/LB+addrs.litmus', 'Dat3M/litmus/AARCH64/TUTO/LB+datas.litmus',
        'Dat3M/litmus/PPC/DETOUR0236.litmus',
        'herdtools7/catalogue/herding-cats/ppc/tests/illustrative/LB+datas.litmus',
        # the three files whose verdicts the correction changes
        'Dat3M/litmus/PPC/2+2W+rfi-datas.litmus', 'Dat3M/litmus/X86/m55ii.litmus',
        'Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009.litmus'}
pick = [r for i, r in enumerate(rows) if r['path'] in disc or i % 100 == 0]
w = csv.DictWriter(open(S + '/subset-hashes.csv', 'w', newline='', encoding='utf-8'), fieldnames=list(rows[0]))
w.writeheader(); w.writerows(pick)
print(' ', len(pick), 'subset files (stage-4 selection plus the 3 F-01 files)')
EOF
"$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$(w "$CI/classes")$SEP$DEPS_CP" wev.smt.cli.CorpusValidation "$(w "$PKG/corpus/litmus")" "$(w "$S/six")" \
  manifest="$(w "$S/subset-hashes.csv")" mode=symbolic csv=subset-symbolic.csv perFileSec=30 budgetMin=60 maxEvents=64 > "$S/six.log" 2>&1
# (build-independent) the model jar's com.weakest.model classes vs the shipped model sources
MS="$PKG/impl/deps/model-source"
mkdir -p "$S/model-jar" "$S/model-classes"
( cd "$S/model-jar" && "$PYTHON" -I -c 'import sys, zipfile; zipfile.ZipFile(sys.argv[1]).extractall(".")' \
    "$(w "$PKG/impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar")" )
"$JAVAC" -g -source 21 -target 21 -nowarn -encoding UTF-8 -d "$(w "$S/model-classes")" \
  $(for f in "$MS"/src/main/java/com/weakest/model/*.java; do w "$f"; echo; done) 2> "$S/model-javac.log"
( cd "$S/model-jar" && ls com/weakest/model/*.class ) > "$S/model-list.txt"
nm=0; nd=0
while read -r f; do nm=$((nm + 1)); cmp -s "$S/model-jar/$f" "$S/model-classes/$f" || nd=$((nd + 1)); done < "$S/model-list.txt"
[ "$nm" = 19 ] && [ "$nd" = 0 ] \
  && pass "model jar: all $nm com.weakest.model classes recompile byte-identically from impl/deps/model-source" \
  || fail "model jar vs model-source: $nd of $nm classes differ"
$PY - "$PKG" "$S" <<'EOF' && pass "corrected six-model subset reproduces results/corrected-v1 verdicts" || fail "corrected six-model subset"
import csv, sys
P, S = sys.argv[1], sys.argv[2]
key = lambda r: (r['file'], r['model'])
auth = {key(r): (r['result'], r['verdict']) for r in csv.DictReader(open(
    P + '/results/corrected-v1/six-model/corrected-symbolic.csv', newline='', encoding='utf-8'))}
new = list(csv.DictReader(open(S + '/six/subset-symbolic.csv', newline='', encoding='utf-8')))
diff = [(key(r), (r['result'], r['verdict']), auth.get(key(r))) for r in new if auth.get(key(r)) != (r['result'], r['verdict'])]
print(' ', len(new), 'rows,', len({r['file'] for r in new}), 'files,', len(diff), 'differences')
for d in diff[:10]: print('  ', d)
assert new and not diff
EOF
finish
