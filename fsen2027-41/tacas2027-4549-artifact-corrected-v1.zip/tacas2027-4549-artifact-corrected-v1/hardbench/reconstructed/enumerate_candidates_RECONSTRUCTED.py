"""RECONSTRUCTED enumerate-and-filter step for the hard-expression benchmark.

THIS IS NOT THE ORIGINAL SCRIPT. The original generator that produced
hardbench/generated-hard-candidates.json was run outside the development tree and
could not be found. This reconstruction was written afterwards, from the
rules stated in the paper (App. A.6, "Enumeration") and the structure of the
recorded file. It is accepted only because it reproduces that file byte-for-byte
(order included) and reproduces the recorded intermediate count of 13,880 forms;
`check_reconstruction.py` verifies both.

Rules (all deterministic, no randomness, no solver):
  * Expressions are parenthesis-free infix strings "a op b op c [op d]" with
    single spaces, evaluated with C operator precedence over 32-bit wrap-around
    arithmetic: * binds tightest, then + and -, then &, then ^ (all left-assoc).
  * Two binary operators (three leaves):
        leaves    r, ~r, 0, 1, 2, 3, 7, 255   (this order)
        operators +, -, *, &, ^               (this order)
  * Three binary operators (four leaves):
        leaves    r, ~r, 0, 1                 (this order)
        operators &, *, ^                     (this order; differs from the
                                              two-operator order, as recorded)
  * Enumeration order: all two-operator forms, then all three-operator forms;
    within each, leaves vary in lexicographic product order (first leaf slowest),
    and for each leaf tuple the operators vary in product order (first slowest).
  * Intermediate population: forms that mention the register (some leaf is r or
    ~r): 7,400 two-operator + 6,480 three-operator = 13,880.
  * Retention (a wiring requirement, consults no classifier): keep a form iff its
    value at r = 0 is exactly 1.  Result: 1,828 expressions.

Usage: python enumerate_candidates_RECONSTRUCTED.py <out.json>
"""
import itertools
import json
import sys

M32 = 0xFFFFFFFF
PREC = {'*': 3, '+': 2, '-': 2, '&': 1, '^': 0}


def leaf_value(tok, r):
    if tok == 'r':
        return r & M32
    if tok == '~r':
        return ~r & M32
    return int(tok) & M32


def evaluate(leaves, ops, r):
    """Shunting-yard evaluation with C precedence, left associativity, BV32 wrap."""
    vals, stack = [leaf_value(leaves[0], r)], []

    def apply(op):
        b, a = vals.pop(), vals.pop()
        vals.append({'*': a * b, '+': a + b, '-': a - b, '&': a & b, '^': a ^ b}[op] & M32)
    for op, leaf in zip(ops, leaves[1:]):
        while stack and PREC[stack[-1]] >= PREC[op]:
            apply(stack.pop())
        stack.append(op)
        vals.append(leaf_value(leaf, r))
    while stack:
        apply(stack.pop())
    return vals[0]


FAMILIES = [
    (['r', '~r', '0', '1', '2', '3', '7', '255'], ['+', '-', '*', '&', '^'], 2),
    (['r', '~r', '0', '1'], ['&', '*', '^'], 3),
]


def enumerate_forms():
    for leaves_pool, ops_pool, nops in FAMILIES:
        for leaves in itertools.product(leaves_pool, repeat=nops + 1):
            if not any(l in ('r', '~r') for l in leaves):
                continue
            for ops in itertools.product(ops_pool, repeat=nops):
                yield leaves, ops


def main():
    forms = list(enumerate_forms())
    kept = []
    for leaves, ops in forms:
        if evaluate(leaves, ops, 0) == 1:
            parts = [leaves[0]]
            for op, leaf in zip(ops, leaves[1:]):
                parts += [op, leaf]
            kept.append(' '.join(parts))
    print(f"intermediate forms: {len(forms)}  retained: {len(kept)}", file=sys.stderr)
    # The recorded file uses CRLF line endings and has no newline after the final ']'.
    with open(sys.argv[1], 'w', newline='') as f:
        f.write('[\r\n' + ',\r\n'.join(json.dumps(e) for e in kept) + '\r\n]')


if __name__ == '__main__':
    main()
