# Evidence files cited by App. A.10

App. A.10 ("Evidence traceability notes") of the paper names four files that the
2026-10-11 package did not contain. This directory adds them. No experiment was re-run to
produce them: they are copies of the recorded files.

| Packaged file | Cited in A.10 as | Origin |
|---|---|---|
| `logs/pwt.log` | run log of the free-range sweep (58 decisions) | run log of the frozen re-run, `<AUDIT_ROOT>/2026-10-09-final-rerun/mirror/logs/pwt.log` |
| `logs/oracle-audit.log` | run log of the oracle audit (59 decisions) | run log of the frozen re-run, `<AUDIT_ROOT>/2026-10-09-final-rerun/mirror/logs/oracle-audit.log` |
| `transcriptions/source-paper-results.csv` | required verdicts, Weakestmo and PwT examples | `<AUDIT_ROOT>/2026-10-09-final-rerun/mirror/eval/source-paper-results.csv` |
| `transcriptions/jmm-results.csv` | required verdicts, JMM causality tests | `<AUDIT_ROOT>/2026-10-09-final-rerun/mirror/eval/jmm-results.csv` |

## Hashes (SHA-256)

| File | Original | Packaged |
|---|---|---|
| `pwt.log` | `6efc10bbe45dd8a146287d74704815393e6685a14f7c8b5d49c0c390d722bc1f` | `00b5a89b5ef42503529cc90cb52bfd59a1e2fd4b4914cc73c33612f6cca80431` |
| `oracle-audit.log` | `7837f462aaf5c686d1e3a91aa7df0bcd3d76f9b50aa9c387bb172d22e50f0fec` | `b5f2b26c3557c62c58e8aaa59341a20748a2a79f752ab25bedfd674853d5f13b` |
| `source-paper-results.csv` | `0bbd0451b3a63375004cd171af6434bdf59cf71e44fe117d41ea96f4cace8d1c` | same (unmodified) |
| `jmm-results.csv` | `70e7a4524f9aab81aea744c2281f81c7a15f4d5253fb727054874854b0bb34de` | same (unmodified) |

**The two logs were anonymized.** Each contained the absolute path of the measurement work
area. That prefix was replaced by `<AUDIT_ROOT>`, the placeholder `ANONYMIZATION.md`
already uses: two replacements in `pwt.log` and one in `oracle-audit.log`. Nothing else
changed. Line endings (CRLF) are preserved, and substituting the prefix back reproduces the
original bytes and the "Original" hash. The two CSVs contain no identifying text and are
byte-identical to the originals.

## How the logs tie to packaged results

- `pwt.log` ends at 2026-10-09T21:43:53 and names its output CSV, `pwt-equivalence-sweep.csv`.
  That output (SHA-256 `8073696c…ef2a`) is byte-identical to
  `results/authoritative/rerun-2026-10-09/pwt-equivalence-sweep.csv`.
- `oracle-audit.log` ends at 2026-10-09T21:47:00 and names its output CSV,
  `detector-oracle-audit.csv`. That output (SHA-256 `54ff7740…f2c9`) is byte-identical to
  `results/authoritative/rerun-2026-10-09/detector-oracle-audit.csv`.

## What A.10 reads from each file

- **`pwt.log`** reports 60 distinct (expression, register) decisions, 58 arithmetic, and
  `AGREE=58 DISAGREE=0`. It names the two exclusions, `(r0 != 0)` and `X1,#0`.
- **`oracle-audit.log`** reports 60 distinct pairs parsed and 59 corpus pairs checked, with
  1 outside the oracle grammar, which is not named. It also reports 990 mismatches, all
  conservative, and 0 unsound.
- **The two CSVs** supply the required verdicts. Only the `source_verdict` and
  `jmm_verdict` columns are cited, as the project's transcriptions of the published
  verdicts.

  Their `wev_verdict`, `verdict_*` and `match` columns are **historical wired-mode
  results** from July 2026. They are **not** the measured verdicts of Table 4, which are
  the symbolic verdicts in `results/authoritative/rerun-2026-10-09/examples-results.json`.
  The two differ for JMM TC06, TC13 and TC18.

Agreement was checked when this package was assembled: all 34 required verdicts in Table 4
equal the transcription columns, and all 34 measured verdicts equal the symbolic verdicts in
`examples-results.json`.
