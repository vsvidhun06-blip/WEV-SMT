"""F-06: recount the earlier 1,600-ring matched-pair sweep from its packaged rows.
Value consistency of a ring (every read pinned to 1; thread i reads x_i, writes
x_{i+1} := E_i(r_i)): each read must take its value from the unique program write to its
location (the init holds 0), so the ring is value-consistent iff E_i(1) == 1 (BV32) for every
thread. Evaluated with an independent BV32 evaluator (paper grammar / C precedence).
Cross-checked against the reference checker's ANY verdict on the generated .litmus files."""
import csv, sys, collections, re
rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8")))
M = 0xffffffff

def ev(expr, r):
    toks = re.findall(r"<<|>>|0x[0-9a-fA-F]+|\d+|[A-Za-z_]\w*|[()|^&+\-*~]", expr)
    pos = [0]
    def pk(): return toks[pos[0]] if pos[0] < len(toks) else None
    def bin_(nxt, ops, f):
        def g():
            v = nxt()
            while pk() in ops:
                op = toks[pos[0]]; pos[0] += 1; v = f(op, v, nxt()) & M
            return v
        return g
    def un():
        t = pk()
        if t == "~": pos[0] += 1; return (~un()) & M
        if t == "-": pos[0] += 1; return (-un()) & M
        if t == "(":
            pos[0] += 1; v = p_or(); assert toks[pos[0]] == ")"; pos[0] += 1; return v
        pos[0] += 1
        if t == "r": return r & M
        return int(t, 0) & M
    p_mul = bin_(un, ("*",), lambda o, a, b: a * b)
    p_add = bin_(p_mul, ("+", "-"), lambda o, a, b: a + b if o == "+" else a - b)
    p_sh = bin_(p_add, ("<<", ">>"), lambda o, a, b: (a << b) if o == "<<" else (a >> b))
    p_and = bin_(p_sh, ("&",), lambda o, a, b: a & b)
    p_xor = bin_(p_and, ("^",), lambda o, a, b: a ^ b)
    p_or = bin_(p_xor, ("|",), lambda o, a, b: a | b)
    v = p_or(); assert pos[0] == len(toks), expr
    return v

c = collections.Counter()
detail = []
for x in rows:
    n, k = int(x["threads"]), int(x["n_fake_sites"])
    ok_f = ev(x["fake_expr"], 1) == 1
    ok_r = ev(x["real_expr"], 1) == 1
    vc = (k == 0 or ok_f) and (k == n or ok_r)
    valid = x["valid"] == "true"; disc = x["discriminating"] == "true"
    c["total"] += 1; c["valid"] += valid; c["discriminating"] += disc
    c["value_consistent_all"] += vc
    c["value_consistent_valid"] += vc and valid
    c["value_consistent_discriminating"] += vc and disc
    c["weakest_eq_required_valid"] += valid and x["weakest"] == x["required"]
    if valid and vc: c["vc_required_" + x["required"]] += 1
    detail.append([x["name"], n, k, x["fake_expr"], x["real_expr"], valid, disc, vc, x["required"], x["weakest"]])
consts = {e: ev(e, 0) == ev(e, 1) == ev(e, 2) == ev(e, 7) for e in sorted({x["fake_expr"] for x in rows})}
print(dict(c))
print("fake-shape values at r=0,1,2,7:", {e: [ev(e, v) for v in (0, 1, 2, 7)] for e in consts})
print("real-shape e(1):", {e: ev(e, 1) for e in sorted({x["real_expr"] for x in rows})})
with open(sys.argv[2], "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh); w.writerow(["name", "threads", "k", "fake_expr", "real_expr", "valid", "discriminating", "value_consistent", "required", "weakest_wired"]); w.writerows(detail)
