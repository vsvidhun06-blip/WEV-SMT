"""Apply the scratch-only encoder variants. Each replacement must match exactly once.
corrected (F2): global pos order keeps only same-location po edges (encoder + MWE gated wf).
nopo     (F1): global pos order carries no po edges (encoder only) -- cross-check variant."""
import pathlib, sys
D = pathlib.Path(sys.argv[1])

def patch(path, old, new):
    t = path.read_bytes().decode("utf-8")
    assert t.count(old) == 1, (path, t.count(old), old[:60])
    path.write_bytes(t.replace(old, new).encode("utf-8"))
    print("patched", path.relative_to(D))

ESE = "wev/smt/EventStructureEncoder.java"
MWE = "wev/smt/MinimalWitnessExtractor.java"
c = D / "src" / "corrected"
patch(c / ESE,
      "                if (droppedCrossLocation(a, b)) continue;\n                cs.add(imgr.lessThan(posA, eventVars.get(b)));",
      "                if (droppedCrossLocation(a, b)) continue;\n"
      "                // CORRECTNESS-INVESTIGATION 2026-10-18 (scratch only): keep a po edge in the\n"
      "                // global witness order only when both endpoints access the SAME location.\n"
      "                // pos is shared across locations, so a kept cross-location R->W / R->R hop\n"
      "                // composes with a same-location W->R hop into an unrelaxed cross-location\n"
      "                // W->W order (W x; R x; W y) that no PSO/RA/WEAKEST/RC11 axiom requires.\n"
      "                // Same-location po edges are implied by CoherencePerLocation.\n"
      "                if (!sameLocation(a, b)) continue;\n"
      "                cs.add(imgr.lessThan(posA, eventVars.get(b)));")
patch(c / ESE,
      "    /** Whether {@code a→b} is a cross-location store→store or store→load po edge. */",
      "    /** CORRECTNESS-INVESTIGATION: both events access the same (non-null) location. */\n"
      "    static boolean sameLocation(Event a, Event b) {\n"
      "        return a.getVariable() != null && a.getVariable().equals(b.getVariable());\n"
      "    }\n\n"
      "    /** Whether {@code a→b} is a cross-location store→store or store→load po edge. */")
patch(c / MWE,
      "                if (droppedCrossLocation(a, b)) continue;\n                cs.add(bmgr.implication(bothActive(a, b),",
      "                if (droppedCrossLocation(a, b)) continue;\n"
      "                // CORRECTNESS-INVESTIGATION 2026-10-18 (scratch only): same-location edges\n"
      "                // only, mirroring the corrected encoder (a fence never matches).\n"
      "                if (!EventStructureEncoder.sameLocation(a, b)) continue;\n"
      "                cs.add(bmgr.implication(bothActive(a, b),")
n = D / "src" / "nopo"
patch(n / ESE,
      "        cs.addAll(relaxedPoConstraints());\n",
      "        // CORRECTNESS-INVESTIGATION 2026-10-18 (scratch only, cross-check variant F1):\n"
      "        // no program-order constraints in the global witness order at all.\n"
      "        // cs.addAll(relaxedPoConstraints());\n")
