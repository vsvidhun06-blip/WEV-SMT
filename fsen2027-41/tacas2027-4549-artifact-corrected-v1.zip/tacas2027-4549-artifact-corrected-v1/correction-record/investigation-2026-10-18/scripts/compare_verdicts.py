"""Per-file/per-model comparison: authoritative CSV, original re-run, corrected (F2), nopo (F1, if
present) and the independent reference. Writes VERDICT-DIFF.csv (only rows where any source
differs) and runs/verdict-summary.txt with totals, result categories, implication checks and the
WEAKEST/RC11 split."""
import csv, collections, os, sys, json
D, A = sys.argv[1], sys.argv[2]
M6 = ["SC", "TSO", "PSO", "RA", "WEAKEST", "RC11"]

def load(p):
    d = {}
    for r in csv.DictReader(open(p, encoding="utf-8")):
        d[(r["file"], r["model"])] = (r["result"], r["verdict"])
    return d

src = {
    "authoritative": load(os.path.join(A, "results/authoritative/ppo-repair/six-model/repaired-symbolic.csv")),
    "original": load(os.path.join(D, "runs/corpus-original-symbolic/r.csv")),
    "corrected": load(os.path.join(D, "runs/corpus-corrected-symbolic/r.csv")),
}
nopo = os.path.join(D, "runs/corpus-nopo-symbolic/r.csv")
if os.path.exists(nopo) and os.path.getsize(nopo) > 0:
    try: src["nopo"] = load(nopo)
    except Exception: pass
ref = {}
for r in csv.DictReader(open(os.path.join(D, "ref/ref-verdicts.csv"), encoding="utf-8")):
    if r["model"] in M6: ref[(r["file"], r["model"])] = r["ref_verdict"]
wired = {k: load(os.path.join(D, f"runs/corpus-{k}-wired/r.csv")) for k in ("original", "corrected")}
wired["authoritative"] = load(os.path.join(A, "results/authoritative/ppo-repair/six-model/repaired-wired-847.csv"))

out = []
lines = []
keys = sorted(src["authoritative"])
for name, s in src.items():
    assert set(s) == set(keys), (name, len(s), len(keys))
lines.append(f"cells per source: {len(keys)} (files {len({k[0] for k in keys})})")
for name, s in src.items():
    rc = collections.Counter(v[0] for v in s.values())
    lines.append(f"{name:14s} result categories {dict(rc)}")
for name, s in list(src.items()) + [("reference", None)]:
    cnt = {}
    for m in M6:
        vs = [ (s[(f, mm)][1] if s else ref[(f, mm)]) for (f, mm) in keys if mm == m]
        cnt[m] = (vs.count("ALLOWED"), vs.count("FORBIDDEN"), len(vs) - vs.count("ALLOWED") - vs.count("FORBIDDEN"))
    lines.append(f"{name:14s} ALLOWED/FORBIDDEN/other " + " ".join(f"{m}={a}/{f}/{o}" for m, (a, f, o) in cnt.items()))

def V(name, f, m):
    return ref[(f, m)] if name == "reference" else src[name][(f, m)][1]

for k in keys:
    f, m = k
    vals = {n: V(n, f, m) for n in list(src) + ["reference"]}
    if len(set(vals.values())) > 1:
        out.append([f, m] + [vals[n] for n in list(src) + ["reference"]])
lines.append(f"cells where any source differs: {len(out)}")
pairs = [("authoritative", "original"), ("original", "corrected"), ("corrected", "reference"),
         ("original", "reference")] + ([("corrected", "nopo")] if "nopo" in src else [])
for a, b in pairs:
    diff = [k for k in keys if V(a, *k) != V(b, *k)]
    lines.append(f"{a} vs {b}: {len(diff)} differing cells, files {len({k[0] for k in diff})}, by model {dict(collections.Counter(k[1] for k in diff))}, directions {dict(collections.Counter(V(a,*k)+'->'+V(b,*k) for k in diff))}")
files = sorted({k[0] for k in keys})
impl = [("SC","TSO"),("SC","PSO"),("SC","RA"),("SC","WEAKEST"),("SC","RC11"),("RC11","WEAKEST"),("PSO","RA")]
for n in list(src) + ["reference"]:
    viol = {f"{a}=>{b}": sum(V(n,f,a)=="ALLOWED" and V(n,f,b)=="FORBIDDEN" for f in files) for a, b in impl}
    split = (sum(V(n,f,"WEAKEST")=="ALLOWED" and V(n,f,"RC11")=="FORBIDDEN" for f in files),
             sum(V(n,f,"RC11")=="ALLOWED" and V(n,f,"WEAKEST")=="FORBIDDEN" for f in files))
    tw = sum(V(n,f,"TSO")=="ALLOWED" and V(n,f,"WEAKEST")=="FORBIDDEN" for f in files)
    lines.append(f"{n:14s} implication violations {viol}; WEAKEST-A/RC11-F split {split}; TSO=>WEAKEST violations {tw}")
# wired
wk = sorted(wired["authoritative"])
for a, b in [("authoritative", "original"), ("original", "corrected")]:
    diff = [k for k in wk if wired[a][k][1] != wired[b][k][1]]
    lines.append(f"WIRED {a} vs {b}: {len(diff)} cells {sorted(set(k[0] for k in diff))} {dict(collections.Counter(k[1] for k in diff))}")
    out += [[k[0], k[1] + "(wired)", wired["authoritative"][k][1], wired["original"][k][1], wired["corrected"][k][1]] for k in diff if b == "corrected"]
for n in ("original", "corrected"):
    rc = collections.Counter(v[0] for v in wired[n].values())
    cnt = {m: (sum(1 for k in wk if k[1]==m and wired[n][k][1]=="ALLOWED"), sum(1 for k in wk if k[1]==m and wired[n][k][1]=="FORBIDDEN")) for m in M6}
    lines.append(f"WIRED {n} result categories {dict(rc)} counts {cnt}")
hdr = ["file", "model"] + list(src) + ["reference"]
with open(os.path.join(D, "VERDICT-DIFF.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh); w.writerow(hdr); w.writerows(out)
open(os.path.join(D, "runs/verdict-summary.txt"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("\n".join(lines))
