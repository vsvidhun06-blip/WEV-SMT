"""Classify every example input by the mechanism behind its WEAKEST verdict.
Inputs: probes/examples/{cases.jsonl, ref.csv, out-*-*/r.csv}; transcriptions from the artifact.
Output: probes/examples/example-classification.csv + console table."""
import csv, json, collections, hashlib, sys, os
D = sys.argv[1]; A = sys.argv[2]
X = os.path.join(D, "probes", "examples")
M6 = ["SC", "TSO", "PSO", "RA", "WEAKEST", "RC11"]

def table(p, key="verdict"):
    d = collections.defaultdict(dict)
    for r in csv.DictReader(open(p, encoding="utf-8")):
        d[r["file"]][r["model"]] = r.get(key) or r.get("ref_verdict") or r.get("result")
    return d

ref = table(os.path.join(X, "ref.csv"), "ref_verdict")
enc = {f"{v}-{m}": table(os.path.join(X, f"out-{v}-{m}", "r.csv")) for v in ("original", "corrected") for m in ("symbolic", "wired")}

cases = {}
for line in open(os.path.join(X, "cases.jsonl"), encoding="utf-8"):
    j = json.loads(line); cases[j["file"]] = j

def canon(j):
    idx = {e["id"]: i for i, e in enumerate(j["events"])}
    ev = [(e["t"], e["k"], e["loc"], e["mo"], e.get("fk"), e.get("rv"), e.get("full")) for e in j["events"]]
    import re
    def ne(s): return re.sub(r"R(\d+)", lambda m: "R%d" % idx[int(m.group(1))], s)
    po = sorted((idx[a], idx[b]) for a, b in j["po"])
    deps = sorted((k, idx[p], idx[c], s) for k, p, c, s in j["deps"])
    wx = sorted((idx[int(k)], ne(v)) for k, v in j["wexpr"].items())
    pins = sorted((idx[int(k)], v) for k, v in j["pins"].items())
    mf = sorted(j["memfinal"].items())
    return hashlib.sha1(json.dumps([ev, po, deps, wx, pins, mf]).encode()).hexdigest()[:12]

src = {}
for r in csv.DictReader(open(os.path.join(A, "evidence/transcriptions/source-paper-results.csv"), encoding="utf-8")):
    src[f"{r['source']}/{r['test']}.litmus"] = r["source_verdict"]
for r in csv.DictReader(open(os.path.join(A, "evidence/transcriptions/jmm-results.csv"), encoding="utf-8")):
    src[f"jmm/{r['test']}.litmus"] = r["jmm_verdict"]

groups = collections.defaultdict(list)
for f, j in cases.items(): groups[canon(j)].append(f)

rows = []
for f in sorted(cases):
    j = cases[f]
    has_ctrl = any(k == "CTRL" for k, *_ in j["deps"])
    has_sem = any(s for *_, s in j["deps"])
    has_fake = any(not s for *_, s in j["deps"])
    R = ref[f]; S = enc["corrected-symbolic"][f]; O = enc["original-symbolic"][f]; Wd = enc["original-wired"][f]
    if R["ANY"] == "FORBIDDEN":
        mech = "VALUE-UNREACHABLE (forbidden by every model; no axiom involved)"
    elif R["COH"] == "FORBIDDEN":
        mech = "SHARED-BASE (CoherencePerLocation/RMWAtomicity forbid under every model)"
    elif has_ctrl and S["WEAKEST"] != S["RA"]:
        mech = "CONTROL (conservatively retained ctrl edge decides; outside formal fragment)"
    elif S["WEAKEST"] == "FORBIDDEN" and S["RA"] == "ALLOWED":
        mech = "DEPENDENCY-DISCRIMINATING (sdep closes a cycle RA/axiom-free base allows)"
    elif S["WEAKEST"] == "ALLOWED" and S["RC11"] == "FORBIDDEN":
        mech = "GROUNDED-ADMITTED (WEAKEST allows what acyclic(po u rf) forbids)" + (" [fake deps]" if has_fake else " [no deps]")
    elif S["WEAKEST"] == "ALLOWED":
        mech = "ALLOWED-BY-ALL-WEAK (no thin-air question)"
    else:
        mech = "OTHER"
    g = groups[canon(j)]
    rows.append({
        "file": f, "source_verdict": src.get(f, "-"),
        "weakest_symbolic": S["WEAKEST"], "agree_source": ("yes" if src.get(f) == S["WEAKEST"] else ("no" if f in src else "-")),
        "mechanism": mech, "has_ctrl": has_ctrl, "has_semantic_dep": has_sem, "has_fake_dep": has_fake,
        "ref_ANY": R["ANY"], "ref_COH": R["COH"],
        "sym_corrected": " ".join(f"{m}={S[m][0]}" for m in M6),
        "ref_models": " ".join(f"{m}={R[m][0]}" for m in M6),
        "sym_original_eq_corrected": all(O[m] == S[m] for m in M6),
        "ref_eq_corrected": all(R[m] == S[m] for m in M6),
        "wired_original": " ".join(f"{m}={Wd[m][0]}" for m in M6),
        "wired_differs_from_symbolic": any(Wd[m] != S[m] for m in M6),
        "collision_group": (",".join(sorted(x for x in g if x != f)) if len(g) > 1 else ""),
    })
out = os.path.join(X, "example-classification.csv")
with open(out, "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
for r in rows:
    print(f"{r['file']:<42} src={r['source_verdict'][:4]:<4} W={r['weakest_symbolic'][:4]} {r['mechanism'][:40]:<40} ref==enc:{r['ref_eq_corrected']} orig==corr:{r['sym_original_eq_corrected']} wiredDiff:{r['wired_differs_from_symbolic']} {('COLL:'+r['collision_group']) if r['collision_group'] else ''}")
pub = [r for r in rows if r["source_verdict"] != "-"]
print("published:", len(pub), "agree:", sum(r["agree_source"] == "yes" for r in pub))
print(collections.Counter(r["mechanism"].split(" (")[0] for r in pub))
print("published FORBIDDEN-agreements by mechanism:",
      collections.Counter(r["mechanism"].split(" (")[0] for r in pub if r["agree_source"] == "yes" and r["source_verdict"] == "FORBIDDEN"))
