# Independent (no project code) reconstruction of the pos-order constraints the original
# encodeWellFormedness emits for the 2+2W+rfis candidate; unsat core + drop-one minimality.
from z3 import *
ev = ['ix','iy','a','b','c','d','e','f']
P = {e: Int('pos_'+e) for e in ev}
kept_po = [('a','b','po W->R same-loc x'), ('b','c','po R->W cross-loc (kept)'),
           ('d','e','po W->R same-loc y'), ('e','f','po R->W cross-loc (kept)')]
co = [('ix','f','co'),('f','a','co'),('ix','a','co'),('iy','c','co'),('c','d','co'),('iy','d','co')]
C = [(x,y,w) for x,y,w in kept_po] + co
def solver(cons):
    s = Solver()
    for e in ev: s.add(P[e] >= 0, P[e] < len(ev))
    s.add(Distinct(*P.values()))
    for x,y,_ in cons: s.add(P[x] < P[y])
    return s
s = Solver(); s.set(unsat_core=True)
for e in ev: s.add(P[e] >= 0, P[e] < len(ev))
s.add(Distinct(*P.values()))
lab = {}
for i,(x,y,w) in enumerate(C):
    t = Bool(f'c{i}'); lab[str(t)] = (x,y,w); s.assert_and_track(P[x] < P[y], t)
print('all constraints:', s.check())
core = [lab[str(t)] for t in s.unsat_core()]
print('unsat core:'); [print(f'   pos({x}) < pos({y})   [{w}]') for x,y,w in core]
for i in range(len(core)):
    r = solver(core[:i]+core[i+1:]).check()
    print(f'   drop pos({core[i][0]})<pos({core[i][1]}) -> {r}')
print('same constraints minus the two R->W cross-location edges (corrected encoder):',
      solver([c for c in C if 'cross-loc' not in c[2]]).check())
