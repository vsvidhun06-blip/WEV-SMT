# Correctness verification — TACAS 2027 submission #4549
*"The Limits of Instruction-Local Dependency Summaries, with an Application to Thin-Air Reads"*

- **Investigation directory:** `<HOME>\wev-correctness-20261018`, created fresh on 2026-10-18 and refused if it already existed.
- **Inputs left untouched:** the repository, the submitted PDF, the original artifact, recorded results and the previous audit. Every artifact of this investigation lives in the investigation directory.
- **No external actions:** no git operations, and no contact with chairs or external systems.
- **Input to verify:** the previous audit (`<HOME>\wev-artifact-audit-20261017`) was treated as claims to check, not as established findings.

---

## 0. Summary of outcomes

| Previous finding | Outcome here |
|---|---|
| **F-01** global-order over-constraint, "12 cells, 3 files, 4 models" | **Confirmed independently.** I give the mechanism, an explicit minimal unsat core, and an independent relational reference over all 14,376 cells. Exactly 12 cells change (FORBIDDEN→ALLOWED). No timeouts, errors or unresolved cases |
| **F-01** "patch the encoder later, disclose now" | **Not inherited.** A principled correction (same-location-only po edges in the global witness order) was designed, justified by a lemma, and run in full. It agrees with the reference on every cell |
| **F-05** LB-real ≠ figure; published data thin-air agreements value-unreachable | **Confirmed and extended.** 15 of 34 published tests are value-unreachable as transcribed. They include all 14 FORBIDDEN agreements on tests with data dependencies, and TC04, whose divergence the paper attributes only to control flattening |
| **F-06** 425/1,440 and 385/1,015 value-consistent | **Confirmed by recount**, both analytically and with the reference on 1,400 generated programs. New detail: one "fake" shape, `r ^ r - 0 + 1`, is not constant (the oracle labelled it correctly) |
| **F-07** wired ablation; symbolic re-solve gives the same six | **Confirmed** three ways: symbolic encoder (original and corrected), and the independent reference over all 2,396 files |
| "recomputes 31 claim figures" overstated | **Confirmed.** 26 checks compute, 3 match recorded summaries, 2 test presence only. E1 passes despite F-01 |
| (new) wired mode misdescribed (tex L465–466) | **Established.** The paper says "rf fixed, co free"; the code fixes co and lets rf vary over value-matching writes |
| (new) wired-mode drivers behind some "verdict" claims | **Established** (disclosure gap). The RC11 matched-pair comparison, the A.4 witnesses, the n-thread controls and the ablation all run in wired mode |
| (new) jfCoherence decides no corpus verdict | **Established** (a significance point, not an error). After correction, WEAKEST-FORBIDDEN equals forbidden-by-shared-base-alone (37 = 37) |

**Proposition 1** (Relational encoding adequacy): **class A, implementation defect only**, for the statement as printed. Its scope sentence (L1513–1514) and caveat (iv) (L490–492) overstate coverage. Under the reading the paper relies on for verdict claims ("the emitted formula"), CX-3 is an explicit counterexample. Repair: Lemma *Well-formedness adequacy*, which is provable for the corrected encoder. Details in §3.

**Changes to published results:**
- Four model totals in §6.4 (tex L960–962): PSO 1,170/1,226 → **1,173/1,223**; RA 2,089/307 → **2,092/304**; WEAKEST 2,356/40 → **2,359/37**; RC11 2,169/227 → **2,172/224**.
- No other published number changes. One textual figure is fixed: the scalability n-set (L970).
- Several interpretations need correcting (§4–§5).

**Central mathematical contribution:**
- **Supported and unaffected:** Theorems 1–3 and the one-thread lifting (C1, C3), Props. 2–4 and the detector lemma. The two Isabelle sessions rebuild clean.
- **Unchanged:** the chain experiment (C2) and Table 2 (C4 benchmark). Table 2 was re-run with the corrected encoder and is byte-identical.
- **Weakened in its supporting evidence, not in its statements:** the application's corpus and published-example corroboration (§4–§5).

---

## 1. Baseline (`baseline/hashes.txt`)

**Manuscript and manifests:**

| Object | SHA-256 |
|---|---|
| Submitted PDF `D:\TACAS27_paper__4549.pdf` (37 pp) | `1241dc829cfa1ccc352442ae0216fdf1b25c89cbd2f2edc832cc961f3aefc792` |
| Manuscript `paper\wev-smt.tex` | `0e9609976ff5257029053fb5e144b098e936eae18a61962ca044b86b63072404` |
| `paper\refs.bib` | `f25ce89898ddb32890b3cd6f136133eaea3a42f4b83d7525f6f3ed1d40f7b447` |
| Artifact `SHA256SUMS` | `89f41d1f5a26325d7d0e34a0e381634a767d90f8d37295741e21b806170644a1` |
| Artifact `impl/PIN.txt` | `00a04e81…7b08` |
| Frozen eligible manifest | `ae011be3422cacff…4036` |

**Encoder sources:**

| Source | SHA-256 |
|---|---|
| `EventStructureEncoder.java` | `1facd9d8466fcb6b…11bf` |
| `AxiomaticConsistency.java` | `7f4e1c3c…2ec9` |
| `MinimalWitnessExtractor.java` | `77dbae63…629b` |
| `CorpusValidation.java` | `17f7d370…25ba` |
| `LitmusParser.java` | `c9dd2daf…4621` |

Each of these files is identical in the repository working tree and the packaged snapshot.

**Manuscript ↔ submitted PDF.** I rebuilt the repo tex into `paper/build` with MiKTeX pdfTeX (pdflatex, bibtex, pdflatex ×2). It gives 37 pages.
- `pdftotext -layout` output is **identical** to the submitted PDF's.
- The PDF bytes **differ** (`cb7eb4b2…` vs `1241dc82…`, timestamps and producer data).
- So the correspondence is **text equivalence, not byte identity.**

**Classes used by every rerun** (never mixed):

| Label | Classes | Built from |
|---|---|---|
| ORIGINAL | `classes/original` | Packaged snapshot; **166/166 class files byte-identical** to the artifact's `impl/classes` |
| CORRECTED | `classes/corrected` | ORIGINAL + `src/corrected.diff` (41 lines; encoder and witness extractor) |
| NOPO | `classes/nopo` | ORIGINAL + `src/nopo.diff`, a cross-check variant |

**Shared runtime:**
- jars: the artifact's model jar plus pinned Maven jars, listed in `scripts/deps-cp.txt`;
- Z3 natives `libz3.dll` `1a0efef3…` and `libz3java.dll` `70408c86…` (= `impl/DEPENDENCIES.txt`);
- JDK 21.0.10; Isabelle2024;
- Python 3.11 with z3-solver 5.0.0, used only by the reference checker and the core script.

## 2. F-01 — verified

### 2.1 Mechanism
From a full read of `EventStructureEncoder.java` (551 lines), `AxiomaticConsistency.java` (929) and `MinimalWitnessExtractor` (gated well-formedness, L262–345):

**The `pos` order in well-formedness.**
- `encodeWellFormedness` gives every event a distinct position in `[0,n)`, i.e. one strict total order over *all* events (L218–230).
- It adds `relaxedPoConstraints` (L232).
- It ties `co(a,b) ⇔ pos(a) < pos(b)` for same-location writes (L274–279).
- In symbolic mode it adds init-minimality and final-memory co-max constraints (L332–365). In wired mode it pins co to the loader's order instead (`coConstraints`, L287).

**`relaxedPoConstraints` (L426–447).**
- It walks **immediate** po edges, skips fences, and drops cross-location W→W and W→R edges.
- It **keeps** every R→R and R→W edge, across locations, and same-location W→W and W→R.
- Because `pos` is shared, `W x → R x → W y` re-imposes `W x < W y`. The relaxation is not closed under composition.

**The model axioms do not use `pos`.**
- Each model has its own layer families (`freshLayer`/`freshLocLayer`) with fresh variables per call.
- PSO and TSO relax over all po-ordered pairs (`addPo` with `laterAccessHops`), and RA uses explicit reachability.
- The only link between `pos` and the axioms is the shared `co` variables. That is how the extra order reaches every model.

**The witness extractor** (`MinimalWitnessExtractor.gatedWellFormedness`, L285–298) has the same leak, and additionally keeps edges into and out of fences. No paper claim relies on it.

### 2.2 Minimal counterexample (COUNTEREXAMPLES.md CX-1)
**Probe.** A hand-built, parser-free `2+2W+rfis` candidate (`probes/F01Probe.java`):
- In ORIGINAL, **the well-formedness formula alone is UNSAT** on a legal candidate.
- The consistency formulas alone are SAT for PSO, RA, WEAKEST and RC11, and UNSAT for SC and TSO, matching the hand analysis of each relational predicate.

**Independent core.** `scripts/f01_core.py`, a pure z3 model of only the emitted `pos` constraints, yields a minimal 6-constraint core. Every constraint is necessary (drop-one → SAT): two same-location W→R edges, two kept cross-location R→W edges, and two co orientations required by the outcome `x=1 ∧ y=2`.

**Why no legitimate axiom requires that order.**
- `pos` has only two legitimate jobs: a per-location strict total co, and co-max for final-memory atoms. Neither relates events of different locations.
- Per-location orders on disjoint sets always extend to a global order.
- Same-location po edges in `pos` are implied by CoherencePerLocation, which every model conjoins.

This argument is constructive, from the core. It is not "deleting constraints changed UNSAT to SAT".

### 2.3 Independent reference check
`ref/refcheck.py`, fed by `ref/ExportCases.java`:

**What it does.**
- Enumerates every rf (each read: any same-location write but itself) and every co (per-location permutations, init first).
- For each candidate, evaluates the relational predicates directly: DFS acyclicity, plus bitset transitive closure for RA's `hb`/`eco`.
- Uses Z3 only for BV32 value feasibility (write-value expressions, rf coupling, pins, co-max final-memory atoms).
- Defines ALLOWED iff some candidate satisfies both, which is the semantics stated at tex L697–699.

**What it shares with the implementation (stated assumptions):**
- the parser output;
- Z3 for BV32 arithmetic;
- the encoded-variant TSO/PSO fence and RMW restore rules and RA's release/acquire-like rules, transcribed from the paper (L452–453, App. A.4) and the documented semantics, not from the SMT code.

**Coverage.** All 2,396 files; two needed a larger enumeration bound (589,824 combinations each). No file was skipped or left unresolved.

**Bug found and fixed.** An initialisation-order bug crashed the first run on files with fences. It was fixed and the full run repeated; results above are from the fixed version.

### 2.4 Correction (scratch only)
**F2, CORRECTED.** In `relaxedPoConstraints` and in the extractor's gated copy, keep a po edge only when both endpoints access the **same** location (`src/corrected.diff`).

**Why it is principled.**
- With it, every `pos` constraint relates two events of one location. The constraints split per location, and per location they are satisfiable iff po_loc-immediate ∪ co is acyclic, which CoherencePerLocation implies.
- Well-formedness therefore admits exactly the legal candidates (proposed Lemma *Well-formedness adequacy*).
- It preserves:
  - each read's single same-location rf source with value coupling;
  - co as a strict total order per location;
  - init co-minimality (symbolic) or the pinned textual co (wired);
  - final-memory co-max;
  - all value and outcome constraints.

**F1, NOPO** (no po edges in `pos` at all) was run as a cross-check. It gives identical results to F2 on all 14,376 symbolic cells and 5,082 wired cells.

### 2.5 Full-population reruns: identical settings, frozen eligible population
Settings for every run, matching the authoritative `config.txt`:
- CorpusValidation in manifest mode, `perFileSec=30 budgetMin=600 maxEvents=64`;
- manifest `corpus/manifests/frozen-eligible-hashes.csv` (2,396 entries, hash-verified) for symbolic runs, and `wired-847-hashes.csv` for wired runs.

| Source | SC | TSO | PSO | RA | WEAKEST | RC11 |
|---|---|---|---|---|---|---|
| authoritative CSV (packaged) | 36/2360 | 563/1833 | 1170/1226 | 2089/307 | 2356/40 | 2169/227 |
| ORIGINAL re-run | 36/2360 | 563/1833 | 1170/1226 | 2089/307 | 2356/40 | 2169/227 |
| CORRECTED (F2) | 36/2360 | 563/1833 | **1173/1223** | **2092/304** | **2359/37** | **2172/224** |
| NOPO (F1) | = CORRECTED | | | | | |
| independent reference | = CORRECTED | | | | | |

Cells are ALLOWED/FORBIDDEN.

- **Result categories:** SAT/UNSAT only in every run. There are 0 UNKNOWN, 0 TIMEOUT, 0 ERROR, 0 UNSUPPORTED, and the reference left none unresolved.
- **Authoritative vs ORIGINAL re-run:** 0 cells differ. The baseline reproduces.
- **ORIGINAL vs CORRECTED, and ORIGINAL vs reference:** exactly **12 cells, 3 files × {PSO, RA, WEAKEST, RC11}, all FORBIDDEN→ALLOWED** (`VERDICT-DIFF.csv`). The three files are `Dat3M/litmus/PPC/2+2W+rfi-datas`, `Dat3M/litmus/X86/m55ii` and `Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009`.
- **CORRECTED vs reference:** 0 of 14,376 cells differ. **The previous audit's "12 cells, three files, four models" scope is verified, not assumed.**
- **Exposure:** 173 eligible files contain the exposed W→…→W path, recomputed independently. Only these 3 also need the conflicting co orientation.
- **Implications:** the seven derivable implications have 0 violations in every source, and TSO⇒WEAKEST also has 0.
- **187/0 WEAKEST-A / RC11-F split:** unchanged everywhere.
- **Wired 847-file table:** identical across ORIGINAL, CORRECTED and the packaged CSV (none of the three files is in it). The wired-vs-symbolic difference counts (tex L1643–1646) are unchanged.

### 2.6 Effects on other results

| Result | Effect | Evidence |
|---|---|---|
| Discriminators | Unchanged: 6 files, wired (packaged driver, both class sets, byte-identical to the packaged CSV) and symbolic (both class sets, and the reference over all 2,396 files) | `runs/ablation/` |
| External comparisons | herd7 SC 1,772/1,772 and x86tso 101/101 are unchanged (SC/TSO cells identical); Dat3M-41 inputs don't include the 3 files | — |
| Witnesses and drivers | RaFormalAtlasRun, PsoCanonicalComparison, Rc11DirectionCheck, Rc11ComparisonRun and NThreadGroundedAdmission give identical CSVs (timing excluded) under both class sets | `runs/witness-*` |
| Table 2 ring audit | Re-run with CORRECTED: 3,656 rows **byte-identical** to `repair/symbolic-ring-audit.csv`. The 644 e(1)=1 expressions were recounted independently | `runs/ring/` |
| Published examples | Symbolic and wired verdicts identical under both class sets for all 43 inputs | — |

**Significance (not an error).** After correction, the 37 WEAKEST-FORBIDDEN eligible files are exactly the 37 forbidden by the shared base alone (reference COH). jfCoherence decides no eligible verdict as parsed. In the submitted build, the only 3 files WEAKEST forbade beyond the base were the F-01 errors.

## 3. Proposition 1 (Relational encoding adequacy; tex L473–481, PDF p. 8; proof L1518–1531, p. 25)

**Statement.** Fix a finite value-consistent candidate, its rf and co, a well-formed activity assignment a (WF1–WF2), and C. The *relational consistency formula* is satisfiable iff the induced sub-execution satisfies CoherencePerLocation, RMWAtomicity and `acyclic(C ∪ rf)`.

**Definitions the statement relies on.**
- L459–462: "each consistency predicate is a quantifier-free formula … acyclicity as a topological order".
- The proof enumerates jfCoherence, CoherencePerLocation and RMWAtomicity. A legacy conjunct is argued neutral (L1505–1516).

**Answers to the questions posed.**

1. **Are the emitted global-order constraints included in the stated predicate?**
   No. They live in `encodeWellFormedness`, a separate conjunct. Neither the statement nor the proof mentions it.
2. **Are they redundant under its assumptions?**
   No. With rf and co fixed to a legal candidate, they can still be unsatisfiable (CX-1: WF alone UNSAT).
3. **Does F-01 supply a counterexample to either implication?**
   - For the printed object (the consistency conjunct): **no**. CX-1 satisfies the right-hand side, and the emitted consistency formula is SAT.
   - For the formula the tool solves (well-formedness ∧ consistency), which L1514 ("holds of the emitted formula as it stands") and caveat (iv) treat as covered: **yes, the "if" direction fails** (CX-3).
   - The "only-if" direction is unaffected, because well-formedness only removes models.
4. **Does wired/symbolic or full/sub-execution matter?**
   - Both modes emit the same `relaxedPoConstraints`.
   - In wired mode co is pinned, so the defect bites only when the pinned co conflicts. No eligible wired file is affected.
   - The sub-execution path (`MinimalWitnessExtractor`) has the same leak gated by activity, plus fence edges. Prop. 1's activity-gated statement concerns the consistency conjunct, so it is unaffected; the extractor's well-formedness is not covered by it either.
5. **Does the neutral-legacy-conjunct argument address this?**
   No. It concerns the `ℓ_w` family in `consistencyWEAKEST` (non-strict inequalities), a different conjunct. That argument is correct.

**Classification: A — implementation defect only.** The proposition and its proof are correct as stated. What is incorrect is the surrounding scope text:
- L1513–1514 says it holds of "the emitted formula";
- caveat (iv) lists only extraction and value-encoding fidelity as remaining obligations.

Together these leave an unstated obligation that the submitted build violates.

**Smallest defensible repair** (non-circular; `PROPOSED-PAPER-PATCH.diff`):
- **(i)** State and prove **Lemma (Well-formedness adequacy).** For a finite all-active candidate in symbolic mode with rf and co fixed, the corrected well-formedness conjunct is satisfiable iff:
  - each read has one same-location rf source;
  - co is a per-location total order with init first;
  - the value and outcome atoms and the co-max final-memory atoms hold;
  - per location, immediate same-location po ∪ co is acyclic (implied by CoherencePerLocation).

  Proof: the constraints split per location, and orders on disjoint sets extend. With Prop. 1, this makes the verdict query exact for every model that conjoins CoherencePerLocation. This lemma is false for the submitted build (CX-1), so the paper must say that the submitted counts are corrected.
- **(ii)** Narrow L1514 to "the emitted consistency formula".
- **(iii)** Add well-formedness fidelity to caveat (iv).

No assumption of the form "the encoding is adequate" is introduced.

## 4. F-05 — LB-real and published examples (`probes/examples/`)

**Program sources compared:**

| Source | Program | Notes |
|---|---|---|
| Figure 1 (L511–551) | **copy** (`W x = r0`) | — |
| App. (A3) (L1170–1172) | cites `eval/examples/paper/LB-real.litmus` | That file (= packaged `inputs/examples/paper/LB-real.litmus`, `1c0772e8…`) stores **`r0+1`** |
| `LitmusCorpus.LBdep-real` (App. A.4) | hand-built wired, constant write 1 + real dep | Consistent with a copy at value 1 |
| `Rc11DirectionCheck`, `Rc11ComparisonRun` | read the r+1 file | — |

**Value consistency, derived by hand.**
- r+1 variant: `r0=1` needs a write of 1 to y, but the only program write stores `r1+1`, which is 2 at `r1=1`. **Unreachable.**
- Copy variant: `r0=r1=v` is consistent for every v.

**Runs** (symbolic; ORIGINAL = CORRECTED = reference):

| Input | SC | TSO | PSO | RA | WEAKEST | RC11 | ANY |
|---|---|---|---|---|---|---|---|
| LB-real (r+1) | F | F | F | **F** | F | F | **F** |
| `LB-copy` (new, labelled diagnostic input) | F | F | F | **A** | **F** | F | — |

Wired mode gives RA A and WEAKEST F for LB-real, only because wired ignores computed values.

**Classification of all 43 example inputs** (34 published + paper/ + diag + diagnostic), in `example-classification.csv`:

| Mechanism | Published tests | Of which FORBIDDEN agreements |
|---|---|---|
| Value-unreachable, F under every model and with no axiom | **15**: LBd ×2, OOTA, TC02, TC03, TC04, TC05, TC06, TC08, TC09, TC10, TC14, TC17, TC18, TC20 | 14; TC04 is a divergence |
| Shared-base (coherence) | 3: CoRR, CoRW, CoWR | 3 |
| Control (retained ctrl edges decide) | 4: LB+ctrl, LBcd, LBfc, TC07 | 3; LBfc is a divergence |
| Grounded-admitted (WEAKEST A, RC11 F) | 7: LB ×2, LBfd, LBxor, TC01, TC12, TC16 | — |
| Allowed by all weak models | 5: MP, TC11, TC13, TC15, TC19 | — |

**Genuine data-dependency discrimination among published tests: none in the FORBIDDEN direction.** In the ALLOWED direction: LBfd and LBxor (as the paper says), plus the dependency-free LB tests.

**Further observations.**
- **Parser collisions** (parsed representation, up to register names): {TC03, TC04}, {LB+ctrl, LBcd, LBfc, **TC07**}, {LBd, LBd, OOTA}, {LB, LB}, {ctrl-single, ctrl-double}, {TC02, paper/LB-real}. The paper's text-level groups omit TC07 and TC02/LB-real.
- **Wired-only artifacts:** wired differs from symbolic on 18 of 43 inputs (column `wired_differs_from_symbolic`), including LB-real and the r+1 thin-air tests.
- **Claims accurate in number but not in interpretation:**
  - 31/34;
  - JMM 18/20;
  - "WEAKEST forbids only LB-real" (RC11 baseline);
  - "(A3) … FORBIDDEN verdict (LB-real.litmus)" — the citation is wrong evidence;
  - the TC04 explanation.

## 5. F-06, F-07, claims checker

**F-06** (`runs/sweep/`). Recount from `results/carried/generated-pairs.csv`:

| Population | Count |
|---|---|
| Total | 1,600 |
| Valid | 1,440 |
| Value-consistent | 425 (all valid) |
| Discriminating | 1,015 |
| Discriminating and value-consistent | **385** |

- **Rule:** value consistency holds iff every thread's expression satisfies e(1)=1 under BV32, evaluated with an independent evaluator.
- **Cross-check:** the reference "ANY" verdict on the 1,400 generated files agrees with the analytic classification on all 1,400 (390 consistent). The other 200 rows have no generated file (`<<` shape).
- **Where the consistent rows come from:** 40 are required FORBIDDEN and 385 required ALLOWED.
- **Shape detail:** `r ^ r - 0 + 1` = `r ^ (r+1)` is non-constant.

**F-07** (`runs/ablation/`).
- The packaged `SdepFakeDiscriminatingRun` (wired) re-run with ORIGINAL and with CORRECTED is byte-identical to the packaged CSV, and lists 6 discriminators.
- My symbolic driver `probes/AblationSym.java` gives 6/370 with both class sets. The only between-class difference is `PPC/2+2W+rfi-datas` (F→A under both configurations, so not a discriminator).
- The reference (WEAKEST vs WEAKEST_ALL) over 2,396 files gives the same 6.

**Claims checker** (`reproduce/05_claims.py`, read in full).
- **Computed from packaged data** (rows, manifests, hashes or counts): 26 — P1–P4, E1–E6, D1–D3, A1, A3, A4, H1–H4, X2–X5, C1, C2.
- **Matched against recorded summaries or text:** 3 — A2 (regex over `final-analysis.txt`), X1 (pre-aggregated `examples-results.json` fields), A5 (string presence).
- **Presence only:** 2 — S1 (`bool(json)`), I1 (`lambda: True` after a file-existence check).
- **None re-runs a solver.** E1 passes on rows that contain the F-01 error: the checker certifies consistency with rows, not correctness.

**Effect on abstract, introduction and conclusion.**
- **None** in numbers: 66/72/171 (chain), 770/385 (Table 2) and the matched-pair claim (copy program) are unchanged.
- The **evaluation** (§6.1, §6.4), **limitations**, **App. A.2 (A3)**, **A.5**, **A.6**, **A.8**, **A.10** and the **DAS** change. No table changes; Table `tab:published` keeps its entries, and the notes under it change.

## 6. Formal core: dependency on these defects

| Result | Formal object | Assumptions | Affected? |
|---|---|---|---|
| Thm 1 (granularity) | Straight-line assignment programs, Boolean site abstraction α | none (Isabelle, assumption-free) | No: statement, proof and mechanisation are independent of the encoder, parser and corpus |
| Thm 2 (read-restricted insufficiency) | Same, over β ∈ A_read | none | No |
| Thm 3 (capacity) | Same; per-site codes | none; (c) mechanized family; full count is a hand argument (disclosed) | No |
| One-thread lifting (PwT_EventBridge) | Load/assignment/store thread events | none | No |
| Lem. detector-properties | Relations sdep_impl, sdep_true, dep | Isabelle counterpart uses oracle axioms (disclosed) | No: algebra; encoder fidelity was never claimed |
| Prop. 1 | Consistency formula at a fixed candidate | per candidate; caveats (i)–(iv) | Statement no; **scope text and caveat (iv) yes**; repair: Lemma wf-adequacy (§3) |
| Prop. 2 (uniqueness of sdep) | Site-uniform relations on dep_data | A1–A3 | No for the statement; **(A3) evidence citation is wrong** (cites the r+1 file); the argument is about the copy program and holds |
| Prop. 3 (basic properties) | jfCoherence relational facts | branch-free fragment | No; the (b) n-thread SMT controls are wired, rerun identical under both class sets |
| Prop. 4 (control on F0) | Mechanized, assumption-free | — | No |
| Lem. pwt-site, Lem. LB embedding | Mechanized and paper-level | A_R4b assumption only for PwT reading | No |

**Isabelle.** The artifact `isabelle/` is identical to the repo. `check_holes` finds no `sorry` or `oops` in 13 theories. Axiomatizations exist only in `WEV_SMT_Defs.thy` (L67, L104), as disclosed. A clean build of WEV_SMT and WEV_SMT_PwT exits 0 in 21 s (`logs/isabelle-build.log`, isolated `USER_HOME`).

As stated in the brief, this proves the checked statements and nothing about parser or Java-encoder fidelity. Accordingly, the encoder and parser claims were checked empirically above.

## 7. Separation of finding types

**Established errors:**
1. F-01, the encoder defect with its four wrong totals.
2. Wrong evidence citation for (A3).
3. Wired-mode description inverted (L465–466).
4. Prop. 1 scope sentence L1514.
5. Scalability n-set.
6. "Byte-identical" at L1765.
7. DAS "recomputes 31".

**Evidence gaps** (numbers correct, support weaker than the wording):
- published-example agreements are value-driven;
- TC04 explanation;
- RC11 matched-pair comparison, A.4 witnesses and ablation are wired;
- the earlier sweep's required verdicts;
- caveat (iv)'s missing obligation.

**Disclosed limitations, not new defects:** control flattening and collisions (disclosed; groups slightly understated), wired mode being diagnostic, last-load binding, simplified RC11, sampled gates.

**Significance judgments:**
- jfCoherence decides no corpus verdict after correction.
- The corpus and published-example evidence for the criterion reduces to the six-file ablation, LBfd/LBxor, and Table 2's constructed benchmark. The paper already frames it this way, but the corrected wording makes it explicit.

## 8. Residual uncertainty

- **Reference independence is partial.** It shares the parser, Z3 (values), and the transcribed TSO/PSO fence and RA sw rules. The F-01 conclusion itself does not depend on those rules: the counterexample core (CX-1) is a pure `pos` argument, and the affected verdicts involve no fences.
- **Herd7 and Dat3M** were not re-run (not installed). Their comparisons involve only SC and TSO cells, which do not change.
- **Unpinned co in the TC13 transcription** and other transcription choices were not re-derived from the source papers.
- **The patch is length-neutral in the main text** (pages 1–19 end identically to the submitted PDF), but the appendix grows by one page (37 → 38). Chairs may have rules about appendix length or post-submission changes.
