# Commands and results (chronological, failures included)

- **Directory:** `D = <HOME>\wev-correctness-20261018`, written via Git Bash at `<HOME>/wev-correctness-20261018`.
- **Other paths:**
  - `A` = `<HOME>\wev-submission-refresh-20261012`, the artifact (read-only);
  - `R` = repository (read-only).
- **Classpath:** `scripts/deps-cp.txt`, holding the artifact model jar plus pinned Maven jars; no class directories.
- **Natives:** `native/libz3*.dll`, hashes equal to `impl/DEPENDENCIES.txt`.
- Every command was inspected before it ran. **No git commands** were run in this investigation, and no network, install or external action was taken.

| # | Step | Command (abridged) | Result |
|---|---|---|---|
| 1 | Fresh dir | `[ -e $D ] && refuse; mkdir -p $D/{baseline,…}` | Created |
| 2 | Baseline hashes | `sha256sum PDF tex bib SHA256SUMS PIN manifest encoder sources (repo+snapshot)` → `baseline/hashes.txt` | Repo sources equal the snapshot for all five files |
| 3 | Rebuild manuscript | `pdflatex; bibtex; pdflatex ×2` in `paper/build`; `pdftotext -layout` both PDFs; `cmp` | 37 pp; **text identical**; PDF bytes differ |
| 4 | ORIGINAL classes | `javac -proc:none … -d classes/original` from snapshot; compare to `A/impl/classes` | **166/166 identical** |
| 5 | Variants | `python scripts/make_variants.py D` → `src/corrected`, `src/nopo`; javac each | First attempt rewrote whole files with CRLF (unreviewable diffs). **Redone byte-preserving**; `src/corrected.diff` is 41 lines, `src/nopo.diff` 14 |
| 6 | Hand-built probe | `javac probes/F01Probe.java` against each class set; `java … F01Probe <variant>` → `runs/f01-probe.txt` | ORIGINAL: WF alone UNSAT; CORRECTED/NOPO: WF SAT; verdicts SC/TSO F, others A |
| 7 | Unsat core | `python scripts/f01_core.py` → `runs/f01-core.txt` | 6-constraint minimal core; every drop-one → sat. The first version had a broken minimisation loop, which was replaced before use |
| 8 | Export parse | `javac ref/ExportCases.java; java ExportCases frozen-eligible-manifest.csv corpus/litmus ref/cases.jsonl` | 2,396 exported, 0 errors |
| 9 | Probe programs | 4 C probes → `probes/probe-cases.jsonl` → `refcheck.py` | Expected relational verdicts |
| 10 | Corpus runs | `bash scripts/run_corpus.sh` ({original, corrected, nopo} × {symbolic 2,396, wired 847}; `perFileSec=30 budgetMin=600 maxEvents=64`) | All exit 0; symbolic 198–202 s, wired 64–67 s; rows 14,376 and 5,082; SAT/UNSAT only |
| 11 | Reference (1st) | `python ref/refcheck.py cases.jsonl ref-verdicts.csv 200000` | **FAILED:** AttributeError (`po_closure_all` used before assignment; first hit on fenced files). Fixed by moving the assignment |
| 12 | Reference (2nd) | same | 2,394 files done, 2 over the bound (fig6, fig6_translated) |
| 13 | Reference, skipped | `refcheck.py … 20000000 skipped.txt` | Both resolved (589,824 combos each) |
| 14 | Reference + pseudo-models | Added ANY, COH, WEAKEST_ALL; full re-run, bound 20M | 2,396/2,396; ANY F = 2 files; COH F = 37 |
| 15 | Compare | `python scripts/compare_verdicts.py D A` → `VERDICT-DIFF.csv`, `runs/verdict-summary.txt` | First call **asserted** on the partially written nopo CSV (run still going); re-run after completion: authoritative = original; original vs corrected/reference **12 cells**; corrected = nopo = reference (0 diffs); implications 0; 187/0 |
| 16 | Examples | Copy `A/inputs/examples` + diagnostic `LB-copy.litmus` → export → refcheck; CorpusValidation ×{orig, corr}×{sym, wired} | All exit 0; 43 inputs; orig = corr in both modes |
| 17 | Classify examples | `python scripts/classify_examples.py D A` → `example-classification.csv` | 15 value-unreachable, 3 coherence, 4 control, 7 grounded-admitted, 5 allowed-by-all |
| 18 | Sweep recount | `python scripts/sweep_recount.py generated-pairs.csv …` | 1,600/1,440/1,015/425/385 |
| 19 | Sweep cross-check | Export the 1,400 generated litmus files → refcheck | Analytic = reference ANY on 1,400/1,400 |
| 20 | Symbolic ablation | `javac probes/AblationSym.java`; run on `fake-carrying.txt` | **First run failed** (quoted paths in the list file); quotes stripped, re-run: 6/370 with both class sets |
| 21 | Wired ablation | `java … SdepFakeDiscriminatingRun manifest=… corpusRoot=… out=… timeoutSec=30 maxEvents=64` ×2 | Both byte-identical to the packaged CSV |
| 22 | Isabelle (1st) | Cygwin bash, `USER_HOME` passed as a Windows path | **FAILED** exit 2 (`No such file: "C"`) |
| 23 | Isabelle (2nd) | `export USER_HOME=$(cygpath -u …)`; `isabelle build -c -v -o timeout=600 -d . WEV_SMT WEV_SMT_PwT` on a copy | **exit 0**, 21 s; `check_holes`: none |
| 24 | Witness drivers | `RaFormalAtlasRun`, `PsoCanonicalComparison`, `Rc11DirectionCheck`, `NThreadGroundedAdmission`, `Rc11ComparisonRun` with each class set in `runs/witness-*` | All exit 0; CSVs identical excluding timing |
| 25 | Ring audit | `javac SymbolicRingAudit.java` against CORRECTED; `bash scripts/run_ring.sh` | exit 0, 8 min; **3,656 rows byte-identical** to `repair/symbolic-ring-audit.csv` |
| 26 | Ring recount | Independent BV32 e(1) over 1,828 candidates | 644 = audit SAT set |
| 27 | Exposure recount | Kept-edge path search on `cases.jsonl` → `ref/exposed-files.txt` | 173 (3 flipped files included) |
| 28 | Page map | `pdftotext -f i -l i` per page; grep phrases | `PAPER-IMPACT-MATRIX.csv` pages |
| 29 | Paper patch | `python scripts/make_paper_patch.py R/paper/wev-smt.tex paper/proposed/wev-smt.tex`; build; compare per-page last lines | Several iterations; failures below |
| 30 | Patch test | `patch --binary wev-smt.tex < PROPOSED-PAPER-PATCH.diff` on a copy; `cmp` | **byte-identical** to the proposed source (text-mode patch fails only on CRLF) |

**Failures during step 29, all fixed before the final build:**
- an escaping error, which broke string literals twice;
- a line-break mismatch, solved by whitespace-tolerant matching;
- main-text overflow onto page 19 in the first three builds, solved by shortening and making edits length-neutral, plus flagged trim M10;
- a CRLF/LF mix, normalised to CRLF.

**Final build:** 38 pp; pages 1–19 end identically to the submitted PDF; no undefined references.

**Final hashes:**

| File | SHA-256 |
|---|---|
| `paper/proposed/wev-smt.tex` | `537e56eeda7eb015145f7297684a2500baa1338fdb627e6b374c42221dbf0a3a` |
| `paper/proposed/wev-smt.pdf` | `a5eb398a56d3cc1ef864c4daf4653a44e492a5e8142518492d202b202d4bfed3` |
| `PROPOSED-PAPER-PATCH.diff` | `93013741c8caed08a56d4890c4dc6116f59f576f58ebd44e24ef7615039e45e7` |

**Missing dependencies and blocked checks (not run):**
- **herd7 and Dat3M are not installed.** Their comparisons are SC/TSO-only, and those cells do not change.
- **No Linux or TACAS-VM run.**
- **Source papers not checked.** Verdict transcriptions were not compared against the cited papers.
