import com.weakest.model.Event;
import org.sosy_lab.common.ShutdownNotifier;
import org.sosy_lab.common.configuration.Configuration;
import org.sosy_lab.common.log.BasicLogManager;
import org.sosy_lab.java_smt.SolverContextFactory;
import org.sosy_lab.java_smt.SolverContextFactory.Solvers;
import org.sosy_lab.java_smt.api.*;
import wev.smt.*;
import wev.smt.parse.*;
import java.nio.file.*;
import java.util.*;

/** Edge-relabelling ablation in SYMBOLIC mode: WEAKEST with the parsed deps ("current")
 *  versus every syntactic edge marked semantic ("all"). Usage: list.txt corpusRoot out.csv */
public class AblationSym {
    public static void main(String[] a) throws Exception {
        StringBuilder out = new StringBuilder("file,current,all,discriminating\n");
        for (String rel : Files.readAllLines(Path.of(a[0]))) {
            if (rel.isBlank()) continue;
            String cur = solve(rel, a[1], false), all = solve(rel, a[1], true);
            out.append(rel).append(',').append(cur).append(',').append(all).append(',')
               .append(!cur.equals(all)).append('\n');
        }
        Files.writeString(Path.of(a[2]), out.toString());
    }

    static String solve(String rel, String root, boolean allSem) throws Exception {
        Event.resetCounter();
        LitmusCase lc = LitmusParser.parse(Files.readString(Path.of(root).resolve(rel)), rel);
        DependencyInfo deps = lc.deps();
        if (allSem) {
            DependencyInfo o = new DependencyInfo();
            for (DependencyInfo.KindedEdge k : deps.allEdges()) switch (k.kind()) {
                case DATA -> o.addDataDep(k.edge().consumer(), k.edge().producer(), true);
                case ADDR -> o.addAddrDep(k.edge().consumer(), k.edge().producer(), true);
                case CTRL -> o.addCtrlDep(k.edge().consumer(), k.edge().producer(), true);
            }
            deps = o;
        }
        Configuration cfg = Configuration.defaultConfiguration();
        try (SolverContext ctx = SolverContextFactory.createSolverContext(cfg,
                BasicLogManager.create(cfg), ShutdownNotifier.createDummy(), Solvers.Z3)) {
            EventStructureEncoder enc = new EventStructureEncoder(ctx, lc.es(), deps);
            enc.enableSymbolic(lc.writeValueExprs(), lc.existsReadValues(), lc.existsMemFinal());
            AxiomaticConsistency ax = new AxiomaticConsistency(enc);
            try (ProverEnvironment p = ctx.newProverEnvironment()) {
                p.addConstraint(enc.getBmgr().and(enc.encodeWellFormedness(), ax.consistencyWEAKEST()));
                return p.isUnsat() ? "FORBIDDEN" : "ALLOWED";
            }
        }
    }
}
