import com.weakest.model.*;
import org.sosy_lab.common.ShutdownNotifier;
import org.sosy_lab.common.configuration.Configuration;
import org.sosy_lab.common.log.BasicLogManager;
import org.sosy_lab.java_smt.SolverContextFactory;
import org.sosy_lab.java_smt.SolverContextFactory.Solvers;
import org.sosy_lab.java_smt.api.*;
import wev.smt.*;
import java.util.*;

/**
 * Hand-built (parser-free) minimal F-01 candidate 2+2W+rfis.
 *   init: ix=W(x,0) iy=W(y,0)
 *   T1:   a=W(x,1) ; b=R(x)<-a ; c=W(y,1)
 *   T2:   d=W(y,2) ; e=R(y)<-d ; f=W(x,2)
 *   co:   ix < f < a   (final x=1);   iy < c < d   (final y=2)
 * Checks, per model, with the candidate's rf and co asserted as fixed Boolean values:
 *   CONS   = consistency formula alone (what Prop. 1's proof enumerates)
 *   WF     = encodeWellFormedness alone (wired mode; co pinned by the textual order)
 *   WF+CONS
 * plus WF+CONS with rf/co free (the verdict query).
 */
public class F01Probe {
    static final MemoryOrder RLX = MemoryOrder.RELAXED;

    public static void main(String[] args) throws Exception {
        String variant = args.length > 0 ? args[0] : "?";
        System.out.println("variant=" + variant);
        System.out.printf("%-8s %-6s %-6s %-8s %-10s%n", "model", "CONS", "WF", "WF+CONS", "free:WF+CONS");
        for (MemoryModel m : MemoryModel.values()) {
            String cons = run(m, true, false, true);
            String wf = run(m, false, true, true);
            String both = run(m, true, true, true);
            String free = run(m, true, true, false);
            System.out.printf("%-8s %-6s %-6s %-8s %-10s%n", m, cons, wf, both, free);
        }
    }

    record Cand(EventStructure es, List<Event[]> rf, List<Event[]> co) { }

    static Cand build() {
        Event.resetCounter();
        EventStructure es = new EventStructure();
        WriteEvent ix = new WriteEvent(0, "x", RLX, 0, "0");
        WriteEvent iy = new WriteEvent(0, "y", RLX, 0, "0");
        WriteEvent a = new WriteEvent(1, "x", RLX, 1, "1");
        ReadEvent b = new ReadEvent(1, "x", RLX, "r0");
        WriteEvent c = new WriteEvent(1, "y", RLX, 1, "1");
        WriteEvent d = new WriteEvent(2, "y", RLX, 2, "2");
        ReadEvent e = new ReadEvent(2, "y", RLX, "r1");
        WriteEvent f = new WriteEvent(2, "x", RLX, 2, "2");
        for (Event ev : new Event[]{ix, iy, a, b, c, d, e, f}) es.addEvent(ev);
        es.addProgramOrder(a, b); es.addProgramOrder(b, c);
        es.addProgramOrder(d, e); es.addProgramOrder(e, f);
        es.addCoherenceOrder("x", ix); es.addCoherenceOrder("x", f); es.addCoherenceOrder("x", a);
        es.addCoherenceOrder("y", iy); es.addCoherenceOrder("y", c); es.addCoherenceOrder("y", d);
        es.addReadsFrom(b, a);
        es.addReadsFrom(e, d);
        List<Event[]> rf = List.of(new Event[]{a, b}, new Event[]{d, e});
        List<Event[]> co = List.of(new Event[]{ix, f}, new Event[]{f, a}, new Event[]{ix, a},
                new Event[]{iy, c}, new Event[]{c, d}, new Event[]{iy, d});
        return new Cand(es, rf, co);
    }

    static String run(MemoryModel m, boolean withCons, boolean withWf, boolean fix) throws Exception {
        Cand cand = build();
        Configuration cfg = Configuration.defaultConfiguration();
        try (SolverContext ctx = SolverContextFactory.createSolverContext(cfg,
                BasicLogManager.create(cfg), ShutdownNotifier.createDummy(), Solvers.Z3)) {
            EventStructureEncoder enc = new EventStructureEncoder(ctx, cand.es());
            AxiomaticConsistency ax = new AxiomaticConsistency(enc);
            BooleanFormulaManager b = enc.getBmgr();
            List<BooleanFormula> cs = new ArrayList<>();
            if (withWf) cs.add(enc.encodeWellFormedness());
            if (withCons) cs.add(switch (m) {
                case SC -> ax.consistencySC(); case TSO -> ax.consistencyTSO();
                case PSO -> ax.consistencyPSO(); case RA -> ax.consistencyRA();
                case WEAKEST -> ax.consistencyWEAKEST(); case RC11 -> ax.consistencyRC11(); });
            if (fix) {
                for (Map.Entry<EventPair, BooleanFormula> en : enc.getRfVars().entrySet()) {
                    boolean on = cand.rf().stream().anyMatch(p -> p[0] == en.getKey().from() && p[1] == en.getKey().to());
                    cs.add(on ? en.getValue() : b.not(en.getValue()));
                }
                for (Map.Entry<EventPair, BooleanFormula> en : enc.getCoVars().entrySet()) {
                    boolean on = cand.co().stream().anyMatch(p -> p[0] == en.getKey().from() && p[1] == en.getKey().to());
                    cs.add(on ? en.getValue() : b.not(en.getValue()));
                }
            }
            try (ProverEnvironment p = ctx.newProverEnvironment()) {
                p.addConstraint(b.and(cs));
                return p.isUnsat() ? "UNSAT" : "SAT";
            }
        }
    }
}
