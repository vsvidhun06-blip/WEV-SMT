# Counterexamples — TACAS 2027 submission #4549

All runs are in `<HOME>\wev-correctness-20261018` and use only that directory.

| Label | Classes | Source |
|---|---|---|
| ORIGINAL | `classes/original` | Compiled from the packaged snapshot; byte-identical to the packaged `impl/classes` (166/166 files) |
| CORRECTED | `classes/corrected` | Scratch patch F2, `src/corrected.diff` |
| NOPO | `classes/nopo` | Cross-check patch F1, `src/nopo.diff` |

The **reference** is `ref/refcheck.py`.
- It enumerates rf and co explicitly and evaluates each model's relational predicate with plain graph algorithms. It uses no `pos` variables and no integer layers.
- It shares the parser output with the implementation, and uses Z3 for BV32 value feasibility.

---

## CX-1 (F-01). Minimal hand-built candidate `2+2W+rfis`, no parser involved

### Candidate

Program:
```
P0: W(x,1) ; r0 = R(x) ; W(y,1)        P1: W(y,2) ; r1 = R(y) ; W(x,2)       exists (x=1 /\ y=2)
```

| Element | Content |
|---|---|
| Events | Init `ix = W(x,0)` and `iy = W(y,0)` (thread 0). T1: `a = W(x,1)`, `b = R(x)`, `c = W(y,1)`. T2: `d = W(y,2)`, `e = R(y)`, `f = W(x,2)` |
| po | `a→b→c`, `d→e→f`; init writes are po-isolated |
| rf | `a→b` (b reads 1), `d→e` (e reads 2); both internal |
| co | x: `ix < f < a` (final x = 1). y: `iy < c < d` (final y = 2) |
| fr | Empty. b reads the co-maximal write of x and e the co-maximal write of y, so no write follows either source. Init sources are not read |
| Dependencies | None. sdep = ∅ |

### Model predicates
Paper L446–454 and App. A.4; all models also conjoin CoherencePerLocation and RMWAtomicity.

- **Shared base.**
  - Per location x, po-loc ∪ rf ∪ co ∪ fr = {a→b, a→b, ix→f, f→a, ix→a} is acyclic.
  - Location y is symmetric.
  - There is no RMW. The base holds.
- **SC.** `a →po c →co d →po f →co a` is a cycle. **FORBIDDEN.**
- **TSO** (po minus W×R, rfe, co, fr). a→c and d→f are W→W, so they are preserved and the same cycle exists. **FORBIDDEN.**
- **PSO** (encoded: po minus (W×R ∪ W×W), rfe, co, fr, plus `irreflexive(hb;eco?)`).
  - ppo = {b→c, e→f}. rfe = ∅.
  - Edges b→c, e→f, ix→f, f→a, ix→a, iy→c, c→d, iy→d are acyclic, because a and d have no ppo out-edge.
  - hb = po⁺ = {a→b, a→c, b→c, d→e, d→f, e→f}. eco⁺ ⊇ {a→b, d→e, f→a, f→b, c→d, c→e, …}. No x has hb(x,z) together with eco?(z,x).
  - **ALLOWED.**
- **RA** (`irreflexive(hb;eco?)` alone, as computed above). **ALLOWED.**
- **WEAKEST** (`acyclic(sdep ∪ jf)` = `acyclic(rf)`). **ALLOWED.**
- **RC11** (simplified, `acyclic(po ∪ rf)`). rf runs along po. **ALLOWED.**

### The encoder's verdicts
From `probes/F01Probe.java` → `runs/f01-probe.txt`, with rf and co asserted to the candidate:

| model | CONS alone | WF alone | WF ∧ CONS | free query (verdict) |
|---|---|---|---|---|
| SC | UNSAT | **UNSAT** | UNSAT | UNSAT |
| TSO | UNSAT | **UNSAT** | UNSAT | UNSAT |
| PSO | SAT | **UNSAT** | UNSAT | **UNSAT (FORBIDDEN, wrong)** |
| RA | SAT | **UNSAT** | UNSAT | **UNSAT (wrong)** |
| WEAKEST | SAT | **UNSAT** | UNSAT | **UNSAT (wrong)** |
| RC11 | SAT | **UNSAT** | UNSAT | **UNSAT (wrong)** |

- In ORIGINAL the **well-formedness formula alone** is UNSAT for this candidate, before any model axiom is conjoined.
- With CORRECTED and with NOPO, WF alone is SAT, and the six verdicts are SC/TSO FORBIDDEN and PSO/RA/WEAKEST/RC11 ALLOWED. They match the relational analysis above.

### Exact conflicting constraints
`scripts/f01_core.py` → `runs/f01-core.txt` is an independent z3 model of only the emitted `pos` constraints. Its minimal unsat core has six constraints, and dropping any one of them makes the set SAT:

| Constraint | Emitted by |
|---|---|
| `pos(a) < pos(b)` | `relaxedPoConstraints`: kept same-location W→R |
| `pos(b) < pos(c)` | `relaxedPoConstraints`: kept R→W, cross-location |
| `pos(d) < pos(e)` | `relaxedPoConstraints`: kept same-location W→R |
| `pos(e) < pos(f)` | `relaxedPoConstraints`: kept R→W, cross-location |
| `pos(f) < pos(a)` | `co(f,a) ⇔ pos(f) < pos(a)` (EventStructureEncoder L274–279) |
| `pos(c) < pos(d)` | `co(c,d) ⇔ pos(c) < pos(d)` |

`pos` is **one** strict total order over **all** events (L222–230), and co is read off it.
- `relaxedPoConstraints` (L426–447) drops cross-location W→W and W→R edges *only as immediate po edges*. It keeps R→W and R→R across locations, and same-location W→R.
- Composed through the intermediate read, the dropped order `W x → W y` comes back as `pos(a) < pos(b) < pos(c)`. The two co edges then close a cycle.

### Why no legitimate axiom needs that order
1. Every relaxation in each model is applied in that model's **own** layer.
   - `AxiomaticConsistency.addPo` filters *every* po-ordered access pair, not just consecutive ones (L586–591).
   - Same-location order is imposed by CoherencePerLocation over a **separate** per-location layer family (L491–501). Its Javadoc states that coupling distinct locations "would collapse the model back to SC".
2. The well-formedness `pos` order has exactly two legitimate roles:
   - to make co a strict total order per location, with the init write co-minimal in symbolic mode (L332–347);
   - to identify the co-maximal write for final-memory atoms (L349–365).

   Neither role needs any order between events of different locations. Given any per-location total orders, a single global total order extending them always exists, because the locations' event sets are disjoint.
3. The po edges that `relaxedPoConstraints` keeps for the same location are implied by CoherencePerLocation, which every model conjoins.
   - If `w →po-loc w'`, coherence forces `co(w,w')`.
   - Reads take no part in co, and chains of reads within one location force only co orders that coherence already forces.
   - So the cross-location kept edges are the *only* constraints the well-formedness formula adds beyond the candidate space, and they are not part of any model.

The relational verdicts above are therefore the intended ones. The encoder rejects the candidate because of a constraint that belongs to no axiom. This is shown directly from the constraint core, not inferred from deleting constraints.

---

## CX-2 (F-01). The three eligible corpus files

The original encoder forbids each of these wrongly, under PSO, RA, WEAKEST and RC11 (SC and TSO forbid them correctly):

| file | shape | ORIGINAL | CORRECTED = NOPO = reference |
|---|---|---|---|
| `Dat3M/litmus/PPC/2+2W+rfi-datas.litmus` | `stw x; lwz x (rfi); xor; addi; stw y` with a fake data dependency, twice | F F | A A A A |
| `Dat3M/litmus/X86/m55ii.litmus` | `MOV [x],2; MOV EAX,[x] (rfi); MOV [y],1`, twice | F F | A A A A |
| `Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009.litmus` | `STR x; LDR x (rfi); LDR y; STR y`, twice | F F | A A A A |

The two columns give the PSO/RA/WEAKEST/RC11 verdicts.

Each file has the CX-1 shape: a write, a same-location read, and a later write to the other location, with the co edges closing through the other thread.
- **Scope.** 173 eligible files contain a write → … → write path through kept edges (independently recomputed here from the exported parse: `ref/exposed-files.txt`; this matches the previous audit's figure). Only these 3 also need the conflicting co orientation for their outcome.
- **Full-population check.**
  - Outputs: `runs/corpus-*`, `ref/ref-verdicts.csv`, `VERDICT-DIFF.csv`.
  - ORIGINAL differs from the reference in exactly these **12 cells**.
  - CORRECTED and NOPO agree with the reference on **all 14,376 cells**.

---

## CX-3 (Proposition 1). Reading under which the stated equivalence fails

**Proposition 1 as printed** (tex L473–481; PDF p. 8) quantifies over "the relational consistency formula" at a fixed candidate rf, co, activity a and C.
- With that formula taken as the consistency conjunct (`consistencyWEAKEST`, which the proof at L1518–1531 enumerates), the statement **holds**.
  - For CX-1 with C = ∅, the induced execution satisfies CoherencePerLocation, RMWAtomicity and `acyclic(C ∪ rf)`.
  - The emitted `consistencyWEAKEST` with rf and co fixed is SAT (CONS column above).

**The bridge in the text.**
- L1513–1514 states that "Prop. 1 holds of the emitted formula as it stands".
- Caveat (iv) (L490–492) lists only "extraction and value-encoding fidelity" as further obligations for symbolic verdicts.

**Counterexample to the reading the paper relies on.** Read "the emitted formula" as the formula the tool actually solves, `encodeWellFormedness ∧ consistencyWEAKEST`.
- CX-1 satisfies every premise: a finite, value-consistent candidate; legal rf and co; every event active, which is WF1–WF2-well-formed with no guards; C = ∅.
- It satisfies the right-hand side.
- Yet the emitted formula with rf and co fixed is **UNSAT** (WF ∧ CONS column).
- So the *if* direction fails for the emitted query.
- The *only-if* direction is unaffected, because well-formedness only removes models.

**Classification and repair.** See CORRECTNESS-VERIFICATION.md §3.

---

## CX-4 (F-05). LB-real: the cited file is not the figure's program

| Program | Store | Outcome `r0=r1=1` | Symbolic verdicts (ORIGINAL = CORRECTED = reference) |
|---|---|---|---|
| `inputs/examples/paper/LB-real.litmus`, the file A3 cites at L1172 | `x := r0+1`, `y := r1+1` | Unreachable: r0 = 1 needs a write of 1 to y, but the only program write to y stores r1+1 = 2 | SC F, TSO F, PSO F, **RA F**, WEAKEST F, RC11 F. Also F with no axiom at all (reference "ANY") |
| `probes/examples/inputs/diagnostic/LB-copy.litmus` (**new diagnostic input**, labelled), the program of the figure (L511–551: `W x = r0`, `W y = r1`) | `x := r0`, `y := r1` | Value-consistent for every v; r0 = r1 = 1 is self-justifying | SC F, TSO F, PSO F, **RA A**, **WEAKEST F**, RC11 F |

- The copy program shows the separation the paper claims: the shared base and RA allow it, and jfCoherence forbids it through two semantic data edges.
- The packaged file shows no such separation in symbolic mode, because no model can produce its outcome.
- In wired mode the packaged file does separate RA from WEAKEST. That is only because wired mode ignores the computed store values.
- Wired verdicts for LB-real: SC F, TSO F, PSO F, RA A, WEAKEST F, RC11 F.

---

## CX-5 (F-05). Published FORBIDDEN agreements decided by value unreachability

Source: `probes/examples/example-classification.csv`.

For each published test, the reference was run with the pseudo-models:
- **ANY**: outcome and values only, no axiom;
- **COH**: shared base only.

Every test below is FORBIDDEN under ANY. As transcribed, its exists-outcome cannot occur in any rf/co candidate, whatever the model:

`weakestmo/LBd`, `weakestmo/OOTA`, `leaky-semicolon/LBd`, `jmm/TC02`, `TC03`, `TC04`, `TC05`, `TC06`, `TC08`, `TC09`, `TC10`, `TC14`, `TC17`, `TC18`, `TC20`.

That is 15 tests: 14 FORBIDDEN agreements, plus the divergence TC04. They also include `paper/LB-real` and `paper/LB-fake-xor`, which are not among the 34.

The mechanism is the same throughout: each transcription writes `r+1` where the source program copies, or otherwise makes the pinned read value unwritable.
- **Example, TC04.** P1 stores `y := r0+1`. The outcome needs `0:r0=1`, i.e. a read of y = 1, but y is only ever 0 or 2.
- So TC04 is FORBIDDEN under every model **independently of** its control collision with TC03.
- The paper attributes the TC04 divergence to control flattening (L951–952, L1058–1063). That explanation is incomplete: correct control handling would not change this verdict.

---

## CX-6 (F-06). Earlier matched-pair sweep: value-inconsistent "required" verdicts

- **Representative case.** `GEN-n2-k1-rxrx1-rp1`: thread 0 stores `r^r^1`, thread 1 stores `r+1`, with `exists r0=r1=1`.
  - The CSV records required = ALLOWED, WEAKEST (wired) = ALLOWED.
  - Thread 1 writes x0 := r1+1 = 2, so `0:r0=1` cannot read 1. The ring is value-inconsistent: reference ANY = FORBIDDEN.
- **Recount from the packaged rows.** `runs/sweep/sweep-value-consistency.csv`, cross-checked by the reference on the 1,400 generated files:

| Population | Count |
|---|---|
| Generated | 1,600 |
| Valid | 1,440 |
| Discriminating | 1,015 |
| Value-consistent and valid | **425** |
| Value-consistent and discriminating | **385** |

- The only real shape with e(1) = 1 is `r & 2 ^ 1`.
- The "fake" shape `r ^ r - 0 + 1` parses as `r ^ ((r-0)+1)`. It is **non-constant** (values 1, 3, 1, 15 at r = 0, 1, 2, 7). The oracle labels those 145 cases correctly; only the summary's shape list (`generated-pairs-summary.md`) is wrong.
