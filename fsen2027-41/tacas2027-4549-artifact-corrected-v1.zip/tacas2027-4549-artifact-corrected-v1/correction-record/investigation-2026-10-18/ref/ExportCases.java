import com.weakest.model.*;
import wev.smt.DependencyInfo;
import wev.smt.parse.LitmusCase;
import wev.smt.parse.LitmusParser;
import java.nio.file.*;
import java.util.*;

/**
 * Exports the parsed representation the encoder consumes (events, immediate po, dependency
 * sidecar, symbolic write-value expressions, exists pins, memory-final atoms) as JSON lines,
 * so an independent checker can evaluate the model predicates without the SMT encoder.
 * Shared dependency (stated): LitmusParser front end.
 * Usage: ExportCases manifest.csv corpusRoot out.jsonl
 */
public class ExportCases {
    public static void main(String[] a) throws Exception {
        List<String> rels = new ArrayList<>();
        for (String l : Files.readAllLines(Path.of(a[0]))) {
            String t = l.strip();
            if (t.isEmpty() || t.startsWith("path,")) continue;
            rels.add(t.split(",")[0]);
        }
        StringBuilder out = new StringBuilder();
        for (String rel : rels) {
            Event.resetCounter();
            LitmusCase lc;
            try {
                lc = LitmusParser.parse(Files.readString(Path.of(a[1]).resolve(rel)), rel);
            } catch (Exception ex) {
                out.append("{\"file\":").append(q(rel)).append(",\"error\":").append(q(ex.toString())).append("}\n");
                continue;
            }
            StringBuilder s = new StringBuilder("{\"file\":").append(q(rel)).append(",\"events\":[");
            boolean first = true;
            for (Event e : lc.es().getEvents()) {
                if (!first) s.append(','); first = false;
                String kind = e instanceof RMWEvent ? "U" : e instanceof FenceEvent ? "F"
                        : e instanceof ReadEvent ? "R" : (e instanceof WriteEvent || e.getType() == EventType.INIT) ? "W" : "?";
                s.append("{\"id\":").append(e.getId()).append(",\"t\":").append(e.getThreadId())
                 .append(",\"k\":").append(q(kind)).append(",\"loc\":").append(q(e.getVariable()))
                 .append(",\"mo\":").append(q(String.valueOf(e.getMemoryOrder())))
                 .append(",\"val\":").append(e.getValue());
                if (e instanceof RMWEvent u) s.append(",\"rv\":").append(u.getReadValue()).append(",\"full\":").append(u.isFullFence());
                if (e instanceof FenceEvent f) s.append(",\"fk\":").append(q(f.getKind().name()));
                s.append('}');
            }
            s.append("],\"po\":[");
            first = true;
            for (var en : lc.es().getProgramOrder().entrySet()) for (Integer to : en.getValue()) {
                if (!first) s.append(','); first = false;
                s.append('[').append(en.getKey()).append(',').append(to).append(']');
            }
            s.append("],\"deps\":[");
            first = true;
            for (DependencyInfo.KindedEdge k : lc.deps().allEdges()) {
                if (!first) s.append(','); first = false;
                s.append("[").append(q(k.kind().name())).append(',').append(k.edge().producer().getId()).append(',')
                 .append(k.edge().consumer().getId()).append(',').append(k.edge().isSemantic()).append(']');
            }
            s.append("],\"wexpr\":{");
            first = true;
            for (var en : lc.writeValueExprs().entrySet()) {
                if (!first) s.append(','); first = false;
                s.append(q(String.valueOf(en.getKey()))).append(':').append(q(en.getValue()));
            }
            s.append("},\"pins\":{");
            first = true;
            for (var en : lc.existsReadValues().entrySet()) {
                if (!first) s.append(','); first = false;
                s.append(q(String.valueOf(en.getKey()))).append(':').append(en.getValue());
            }
            s.append("},\"memfinal\":{");
            first = true;
            for (var en : lc.existsMemFinal().entrySet()) {
                if (!first) s.append(','); first = false;
                s.append(q(en.getKey())).append(':').append(en.getValue());
            }
            s.append("}}\n");
            out.append(s);
        }
        Files.writeString(Path.of(a[2]), out.toString());
        System.out.println("exported " + rels.size());
    }

    static String q(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
            else b.append(c);
        }
        return b.append('"').toString();
    }
}
