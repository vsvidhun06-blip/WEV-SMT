"""Independent reference checker for the six encoded models (symbolic-mode semantics, tex L697-699):
a test is ALLOWED under M iff some (rf, co) -- every event active, init co-minimal -- satisfies
M's relational predicate and the BV32 value constraints (rf value coupling, write-value
expressions, exists pins, final-memory atoms on the co-maximal write).

Independence: no SMT encoder, no pos variables, no integer layers. rf and co are enumerated
explicitly; relational predicates are evaluated with explicit graphs (DFS acyclicity, bitset
transitive closure). Shared with the implementation (stated assumptions):
  * the parsed representation (LitmusParser output, exported by ExportCases.java);
  * Z3 (python 4.x/5.0.0) for BV32 value feasibility only;
  * the encoded-variant fence/RMW restore rules for TSO/PSO and the release/acquire-like rules
    for RA's sw, transcribed from the documented semantics (paper L452-453, App. A.4,
    AxiomaticConsistency Javadoc), not from its SMT code.
Usage: refcheck.py cases.jsonl out.csv [maxCombos] [files.txt]"""
import json, sys, csv, itertools, time
from z3 import BitVec, BitVecVal, Solver, sat, unsat

MODELS = ["SC", "TSO", "PSO", "RA", "WEAKEST", "RC11", "ANY", "COH", "WEAKEST_ALL"]
# WEAKEST_ALL = WEAKEST with every syntactic dependency edge treated as semantic (ablation "all")
# ANY = values/outcome only (no axiom at all); COH = shared base only (CoherencePerLocation + RMWAtomicity)
W = 32

# ---------------- BV expression parser (grammar of the paper: | < ^ < & < +- < * < unary) -------
class Unparsable(Exception): pass

def tokenize(s):
    s = s.replace(" ", "")
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if c in "()|^&+-*~":
            out.append(c); i += 1
        elif s.startswith("0x", i) or s.startswith("0X", i):
            j = i + 2
            while j < len(s) and s[j] in "0123456789abcdefABCDEF": j += 1
            out.append(("num", int(s[i+2:j], 16))); i = j
        elif c.isdigit():
            j = i
            while j < len(s) and s[j].isdigit(): j += 1
            out.append(("num", int(s[i:j]))); i = j
        elif c.isalpha() or c == "_":
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == "_"): j += 1
            out.append(("id", s[i:j])); i = j
        else:
            raise Unparsable(s)
    return out

def parse_expr(s, env):
    toks = tokenize(s); pos = [0]
    def peek(): return toks[pos[0]] if pos[0] < len(toks) else None
    def eat(c):
        if peek() == c: pos[0] += 1; return True
        return False
    def binop(nxt, ops):
        def f():
            v = nxt()
            while peek() in ops:
                op = toks[pos[0]]; pos[0] += 1
                r = nxt()
                v = {"|": lambda a, b: a | b, "^": lambda a, b: a ^ b, "&": lambda a, b: a & b,
                     "+": lambda a, b: a + b, "-": lambda a, b: a - b, "*": lambda a, b: a * b}[op](v, r)
            return v
        return f
    def unary():
        if eat("~"): return ~unary()
        if eat("-"): return -unary()
        return primary()
    def primary():
        t = peek()
        if t == "(":
            pos[0] += 1; v = p_or()
            if not eat(")"): raise Unparsable(s)
            return v
        if isinstance(t, tuple):
            pos[0] += 1
            if t[0] == "num": return BitVecVal(t[1] & 0xffffffff, W)
            if t[1] in env: return env[t[1]]
            raise Unparsable(s)
        raise Unparsable(s)
    p_mul = binop(unary, ("*",)); p_add = binop(p_mul, ("+", "-")); p_and = binop(p_add, ("&",))
    p_xor = binop(p_and, ("^",)); p_or = binop(p_xor, ("|",))
    v = p_or()
    if pos[0] != len(toks): raise Unparsable(s)
    return v

# ---------------- graph helpers ----------------
def acyclic(n, edges):
    adj = [[] for _ in range(n)]
    for a, b in edges: adj[a].append(b)
    color = [0] * n
    for s0 in range(n):
        if color[s0]: continue
        stack = [(s0, 0)]; color[s0] = 1
        while stack:
            u, i = stack[-1]
            if i < len(adj[u]):
                stack[-1] = (u, i + 1); v = adj[u][i]
                if color[v] == 1: return False
                if color[v] == 0: color[v] = 1; stack.append((v, 0))
            else:
                color[u] = 2; stack.pop()
    return True

def closure(n, edges):
    reach = [0] * n
    for a, b in edges: reach[a] |= 1 << b
    for k in range(n):
        bk = 1 << k; rk = reach[k]
        for i in range(n):
            if reach[i] & bk: reach[i] |= rk
    return reach

# ---------------- per-case static structure ----------------
class Case:
    def __init__(self, j):
        self.file = j["file"]
        ev = j["events"]; self.ev = ev
        self.idx = {e["id"]: i for i, e in enumerate(ev)}
        self.n = len(ev)
        K = [e["k"] for e in ev]; self.K = K
        self.is_w = [k in ("W", "U") for k in K]
        self.is_r = [k in ("R", "U") for k in K]
        self.is_acc = [k in ("W", "R", "U") for k in K]
        self.loc = [e["loc"] for e in ev]
        self.init = [e["t"] == 0 and K[i] == "W" for i, e in enumerate(ev)]
        n = self.n
        imm = [(self.idx[a], self.idx[b]) for a, b in j["po"]]
        self.po_succ = [[] for _ in range(n)]
        for a, b in imm: self.po_succ[a].append(b)
        # po between accesses, fence-transparent, with the fences crossed on the way
        self.po_pairs = {}   # (a,b) -> set of crossed fence indices (union over paths)
        for a in range(n):
            if not self.is_acc[a]: continue
            stack = [(s, frozenset()) for s in self.po_succ[a]]; seen = set()
            while stack:
                v, cr = stack.pop()
                if (v, cr) in seen: continue
                seen.add((v, cr))
                if K[v] == "F":
                    for s in self.po_succ[v]: stack.append((s, cr | {v}))
                else:
                    self.po_pairs.setdefault((a, v), set()).update(cr)
                    for s in self.po_succ[v]: stack.append((s, cr))
        self.po = list(self.po_pairs)
        self.thread = [e["t"] for e in ev]
        self.locs = sorted({l for i, l in enumerate(self.loc) if self.is_acc[i] and l is not None})
        self.writes = {l: [i for i in range(n) if self.is_w[i] and self.loc[i] == l] for l in self.locs}
        self.reads = [i for i in range(n) if self.is_r[i]]
        self.rf_cands = {r: [w for w in self.writes.get(self.loc[r], []) if w != r] for r in self.reads}
        self.sdep = [(self.idx[p], self.idx[c]) for kind, p, c, sem in j["deps"] if sem]
        self.alldep = [(self.idx[p], self.idx[c]) for kind, p, c, sem in j["deps"]]
        self.wexpr = {self.idx[int(k)]: v for k, v in j["wexpr"].items()}
        self.pins = {self.idx[int(k)]: v for k, v in j["pins"].items()}
        self.memfinal = j["memfinal"]
        self.mo = [e["mo"] for e in ev]
        self.full_rmw = [K[i] == "U" and ev[i].get("full", False) for i in range(n)]
        self.fk = [ev[i].get("fk") for i in range(n)]
        self.ppo_tso = self._ppo(True, False)
        self.ppo_pso = self._ppo(True, True)
        self.po_closure_all = closure(n, imm)
        self.rel_like = [self._rel_like(i) for i in range(n)]
        self.acq_like = [self._acq_like(i) for i in range(n)]

    def _fence_orders(self, f, a, b):
        k = self.fk[f]
        if k == "FULL": return True
        if k == "ACQ": return self.is_r[a]
        if k == "REL": return self.is_w[b]
        if k == "ACQ_REL": return self.is_r[a] or self.is_w[b]
        return False

    def _ppo(self, skip_wr, skip_ww):
        out = []
        for (a, b), crossed in self.po_pairs.items():
            relaxed = (skip_wr and self.is_w[a] and self.K[b] == "R") or (skip_ww and self.is_w[a] and self.is_w[b])
            if relaxed:
                restored = self.full_rmw[a] or self.full_rmw[b] or any(self._fence_orders(f, a, b) for f in crossed)
                if not restored: continue
            out.append((a, b))
        return out

    def _fence_po(self, f, e):  # fence f po-before e (same thread, any distance)
        return self.K[f] == "F" and self.thread[f] == self.thread[e] and (self.po_closure_all[f] >> e) & 1

    def _rel_like(self, i):
        if self.mo[i] in ("RELEASE", "SC"): return True
        if not self.is_w[i]: return False
        return any(self._fence_po(f, i) and self.fk[f] in ("REL", "ACQ_REL", "FULL") for f in range(self.n))

    def _acq_like(self, i):
        if self.mo[i] in ("ACQUIRE", "SC"): return True
        if not self.is_r[i]: return False
        return any(self.K[f] == "F" and self.thread[f] == self.thread[i] and (self.po_closure_all[i] >> f) & 1
                   and self.fk[f] in ("ACQ", "ACQ_REL", "FULL") for f in range(self.n))

    # ------------- model predicates for one (rf, co) -------------
    def predicates(self, rf, co_orders):
        n = self.n
        co = []
        for l, order in co_orders.items():
            for i in range(len(order)):
                for k in range(i + 1, len(order)): co.append((order[i], order[k]))
        coset = set(co)
        rfl = [(w, r) for r, w in rf.items()]
        fr = [(r, w2) for r, w in rf.items() for (a, w2) in co if a == w and w2 != r]
        # shared base: CoherencePerLocation + RMWAtomicity
        coh = True
        for l in self.locs:
            E = [(a, b) for (a, b) in self.po if self.loc[a] == l and self.loc[b] == l]
            E += [(w, r) for (w, r) in rfl if self.loc[r] == l]
            E += [(a, b) for (a, b) in co if self.loc[a] == l]
            E += [(r, w) for (r, w) in fr if self.loc[r] == l]
            if not acyclic(n, E): coh = False; break
        rmw = True
        for u in range(n):
            if self.K[u] != "U" or u not in rf: continue
            w = rf[u]
            for w2 in self.writes[self.loc[u]]:
                if w2 in (w, u): continue
                if (w, w2) in coset and (w2, u) in coset: rmw = False
        base = coh and rmw
        res = {}
        rfe = [(w, r) for (w, r) in rfl if self.thread[w] != self.thread[r]]
        res["SC"] = base and acyclic(n, self.po + rfl + co + fr)
        res["TSO"] = base and acyclic(n, self.ppo_tso + rfe + co + fr)
        hbe = self.po + [(w, r) for (w, r) in rfl if self.rel_like[w] and self.acq_like[r]]
        hb = closure(n, hbe); eco = closure(n, rfl + co + fr)
        hbeco_ok = True
        for x in range(n):
            if (hb[x] >> x) & 1: hbeco_ok = False; break
            z = hb[x]
            while z:
                lb = z & -z; zi = lb.bit_length() - 1; z ^= lb
                if (eco[zi] >> x) & 1: hbeco_ok = False; break
            if not hbeco_ok: break
        res["RA"] = base and hbeco_ok
        res["PSO"] = base and hbeco_ok and acyclic(n, self.ppo_pso + rfe + co + fr)
        res["WEAKEST"] = base and acyclic(n, self.sdep + rfl)
        res["RC11"] = base and acyclic(n, self.po + rfl)
        res["ANY"] = True
        res["COH"] = base
        res["WEAKEST_ALL"] = base and acyclic(n, self.alldep + rfl)
        return res

    # ------------- value feasibility for (rf, co-max per location) -------------
    def values_ok(self, rf, comax, cache):
        key = (tuple(sorted(rf.items())), tuple(sorted(comax.items())))
        if key in cache: return cache[key]
        s = Solver()
        vr = {r: BitVec(f"vr{r}", W) for r in self.reads}
        vw = {w: BitVec(f"vw{w}", W) for l in self.locs for w in self.writes[l]}
        env = {f"R{self.ev[r]['id']}": vr[r] for r in self.reads}
        for w, v in vw.items():
            ex = self.wexpr.get(w)
            if ex is None:
                s.add(v == BitVecVal(self.ev[w]["val"] & 0xffffffff, W))
            else:
                try: s.add(v == parse_expr(ex, env))
                except Unparsable: self.unparsable.add(ex)   # left free, as the encoder does
        for r, w in rf.items(): s.add(vr[r] == vw[w])
        for r, v in self.pins.items(): s.add(vr[r] == BitVecVal(v & 0xffffffff, W))
        for l, v in self.memfinal.items():
            if l in comax: s.add(vw[comax[l]] == BitVecVal(v & 0xffffffff, W))
            else: cache[key] = False; return False
        ok = s.check() == sat
        cache[key] = ok
        return ok

def check(case, max_combos):
    case.unparsable = set()
    rf_space = [case.rf_cands[r] for r in case.reads]
    if any(len(c) == 0 for c in rf_space):
        return {m: "FORBIDDEN" for m in MODELS}, 0, "read-without-write"
    co_space = []
    for l in case.locs:
        ws = case.writes[l]; inits = [w for w in ws if case.init[w]]; prog = [w for w in ws if not case.init[w]]
        co_space.append([tuple(inits) + p for p in itertools.permutations(prog)])
    total = 1
    for c in rf_space: total *= len(c)
    for c in co_space: total *= len(c)
    if total > max_combos:
        return {m: "SKIPPED" for m in MODELS}, total, "combinatorial-bound"
    found = {m: False for m in MODELS}
    cache = {}
    for co_choice in itertools.product(*co_space):
        co_orders = dict(zip(case.locs, co_choice))
        comax = {l: o[-1] for l, o in co_orders.items() if o}
        for rf_choice in itertools.product(*rf_space):
            rf = dict(zip(case.reads, rf_choice))
            need = [m for m in MODELS if not found[m]]
            if not need: break
            pr = case.predicates(rf, co_orders)
            if not any(pr[m] for m in need): continue
            if not case.values_ok(rf, comax, cache): continue
            for m in need:
                if pr[m]: found[m] = True
        if all(found.values()): break
    note = "unparsable:" + "|".join(sorted(case.unparsable)) if case.unparsable else ""
    return {m: ("ALLOWED" if found[m] else "FORBIDDEN") for m in MODELS}, total, note

def main():
    cases_path, out_path = sys.argv[1], sys.argv[2]
    max_combos = int(sys.argv[3]) if len(sys.argv) > 3 else 200000
    only = None
    if len(sys.argv) > 4:
        only = set(l.strip() for l in open(sys.argv[4], encoding="utf-8") if l.strip())
    rows = []
    t0 = time.time()
    with open(cases_path, encoding="utf-8") as f:
        for line in f:
            j = json.loads(line)
            if only is not None and j["file"] not in only: continue
            t = time.time()
            res, combos, note = check(Case(j), max_combos)
            for m in MODELS:
                rows.append([j["file"], m, res[m], combos, round(time.time() - t, 3), note])
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["file", "model", "ref_verdict", "combos", "secs", "note"]); w.writerows(rows)
    print(f"{len(rows)//len(MODELS)} files, {time.time()-t0:.1f}s")

if __name__ == "__main__":
    main()
