# Proposed corrections — TACAS 2027 submission #4549

**Status: proposed only.** Nothing has been applied to the submitted paper, the repository, the artifact or any external system.

| Item | Path | SHA-256 |
|---|---|---|
| Patch | `PROPOSED-PAPER-PATCH.diff` | `93013741…45e7` |
| Patched source | `paper/proposed/wev-smt.tex` | `537e56ee…0a3a` |
| Build | `paper/proposed/wev-smt.pdf` | `a5eb398a…ed3` |

- **How the patch applies.** It is against the submitted source `paper/wev-smt.tex` (`0e960997…`). `patch --binary wev-smt.tex < PROPOSED-PAPER-PATCH.diff` reproduces the proposed source byte-for-byte (tested on a copy).
- **Length.** The main text is length-neutral: pages 1–19 of the proposed build end on exactly the same lines as the submitted PDF. The appendix grows from 37 to 38 pages in total. The appendix is outside the page limit per the source comment at L1100–1104, but the chairs' rules on post-submission changes apply.

## 1. Corrections to results and statements

Each entry gives the submitted page/line, the original wording, what is wrong, the evidence, the correction, and whether the headline contribution changes. PAPER-IMPACT-MATRIX.csv has the same data, with 27 rows in total.

| # | PDF p. / tex L | Original | Verified defect | Evidence | Correction (patch edit) | Headline changes? |
|---|---|---|---|---|---|---|
| 1 | p.16 / L960–962 | "PSO 1,170/1,226, RA 2,089/307, WEAKEST 2,356/40, RC11 2,169/227" | Well-formedness over-constraint forbids 3 legal files under these models (12 cells) | `VERDICT-DIFF.csv`, CX-1/CX-2, reference = corrected on 14,376/14,376 | "PSO 1,173/1,223, RA 2,092/304, WEAKEST 2,359/37, RC11 2,172/224 (corrected, App. A.6)" (**M7**); explanatory paragraph in App. A.6 (**A5**) | No |
| 2 | p.8 / L465–466 | "Wired: rf fixed by one loader wiring, co free" | Inverted: the code pins co and lets rf range over folded-value matches | Encoder L258, L286–288, L458–469 | "Wired: co fixed by the loader, rf limited to folded-value matches" (**M1**) | No |
| 3 | p.8 / L467 | "Symbolic (…; all verdict claims)" | The RC11 matched pair, A.4 witnesses, n-thread controls and ablation are wired drivers | Driver sources (no `enableSymbolic`) | "all **corpus** verdict claims" (**M2**); wired checks named in App. A.6 (**A5**) | No |
| 4 | p.9 / L490–492 | caveat (iv): "extraction and value-encoding fidelity remain separate obligations" | Omits well-formedness (candidate-space) fidelity, the obligation F-01 violates | CX-3 | adds "well-formedness (Lem. wf-adequacy)" (**M3**) | No |
| 5 | p.25 / L1513–1514 | "Prop. 1 holds of the emitted formula as it stands" | True only of the emitted *consistency* formula; the solved query also contains well-formedness | CX-3; `runs/f01-probe.txt` | "…of the emitted consistency formula… does not cover the separately emitted well-formedness conjunct; Lem. wf-adequacy does, for the corrected encoder" (**A2**) | No |
| 6 | p.25 / after L1531 | (absent) | No lemma covered the well-formedness conjunct | §3 of CORRECTNESS-VERIFICATION.md | New **Lemma (Well-formedness adequacy)** with proof, plus a note that the submitted build failed its "if" direction (**A3**) | No |
| 7 | p.20 / L1170–1172 | "(A3) … FORBIDDEN verdict (eval/examples/paper/LB-real.litmus)" | The file stores r+1; its outcome is value-unreachable and forbidden by every model incl. RA in symbolic mode | CX-4 | cites the copy program of Fig. 1 and states why the file does not witness (A3) (**A1**) | No |
| 8 | p.16 / L952–954 | "Qualitative corroboration, not validation: 32 of the 34 place no fake dependency…" | The FORBIDDEN data-dependency agreements (14) and TC04 are value-unreachable as transcribed | CX-5; `example-classification.csv` | "Not validation: the FORBIDDEN data-dependency agreements are value-unreachable as transcribed (App. A.10); fake dependencies decide only pwt/LBfd and pwt/LBxor." (**M5**) plus the App. A.10 note (**A7**) | No (31/34 unchanged) |
| 9 | p.16 / L956–959 | "…where WEAKEST forbids only LB-real" | Wired check; in symbolic mode LB-real is forbidden by every model | `runs/witness-*`, `probes/examples` | "(wired)" (**M6**); detail in App. A.6 (**A5**) | No |
| 10 | p.13 / L798–800 | "6 of the 370 … discriminate" | Mode not stated (wired); a symbolic re-solve gives the same six | `runs/ablation/`, reference | "whose (wired) WEAKEST verdict…" (**M4**); detail in App. A.6 (**A5**) | No |
| 11 | p.16 / L970 | n ∈ {2,3,4,6,8,12,16} | The CSV has {2,3,4,5,6,8,10,12,16} | `results/carried/scalability-consistency.csv` | corrected set (**M8**) | No |
| 12 | p.27 / L1582–1586 | "A sweep of 1,600 … 1,015/1,015 against 0/1,015" | Only 425 valid and 385 discriminating rings are value-consistent | `runs/sweep/` | adds "wired" and the value-consistent subset (**A4**) | No |
| 13 | p.30 / L1765 | "reruns were byte-identical" | Deterministic outputs only; z3 witness values may differ | stage-3 comparison rule | qualified (**A6**) | No |
| 14 | p.32 / L1862–1866 | Published-example notes | Missing value-unreachability (15 tests) and parse-level collisions (TC07 in group c; TC02 ≡ LB-real) | CX-5 | added (**A7**) | No |
| 15 | p.33 / L1910–1912 | "recomputes 31 claim figures from packaged rows" | 26 compute, 3 match recorded summaries, 2 presence-only | `05_claims.py` read in full | precise wording (**A8**) | No |

**Compensating trim, flagged for author approval.** M10 rewords one sentence in the same §6.4 paragraph to keep the main text length-neutral. It does not change the meaning.
- Before: "Encoded TSO⇒WEAKEST also has no corpus counterexample; this is a measured implication, not one established by the conjunct checks."
- After: "Encoded TSO⇒WEAKEST has no corpus counterexample (measured, not derived from the conjuncts)."

## 2. Verified unaffected (no edit)

- Abstract and introduction numbers (66/72/171; 770/385) and the matched-pair claim (copy program).
- Theorems 1–3, the one-thread lifting, Props. 2–4, Lem. detector-properties, Lem. LB embedding and Lem. pwt-site.
- Table 2, which is byte-identical under the corrected encoder.
- The chain experiment.
- E2 (seven implications, 0 violations) and E3 (187/0).
- herd7 SC 1,772 and x86tso 101/101.
- The wired 847-file differences.
- The App. A.4 witnesses.
- The n-thread controls.
- Dat3M 35/41 and the 438/390 subset.
- The PwT 58/58 and oracle audit 12,067/990/0.
- The 2,396/2,312 population figures.

## 3. Code correction (for the artifact and camera-ready; not part of the paper patch)

**Scratch patch** `src/corrected.diff`: keep a po edge in the global witness order only when both endpoints access the same location, in both `EventStructureEncoder.relaxedPoConstraints` and `MinimalWitnessExtractor.gatedWellFormedness`.

**Validation performed:**
- full symbolic six-model run, 2,396 files;
- wired run, 847 files;
- independent reference agreement on all 14,376 cells;
- cross-check variant NOPO identical to CORRECTED;
- Table 2 ring audit byte-identical;
- witness, RC11 and n-thread drivers identical;
- wired and symbolic ablation unchanged.

**Steps before shipping the correction in an artifact:**
1. Apply it to a new snapshot, rebuild the classes and regenerate the pins.
2. Regenerate `repaired-symbolic.csv` and its config, and update `05_claims.py` E1.
3. Add a regression test containing CX-1 (`2+2W+rfis`).
4. Disclose it in ERRATA.

Do not overwrite the recorded submitted-build results; keep them as superseded.

## 4. Assessment

**The corrections preserve the central contribution.**
- C1–C3 (Theorems 1–3, the lifting and the Isabelle development) are independent of the defects. The Isabelle build was re-verified.
- C2 (the chain experiment) is unaffected.
- C4's formal statements are unaffected, and its benchmark (Table 2) is unaffected.
- C5 is unaffected.

**What changes:**
- four model totals in one sentence;
- the interpretation of the published-example agreements, which are mostly value-driven or control-driven;
- the disclosure that several comparison verdicts are wired-mode;
- the scope text around Prop. 1, plus a short lemma.

**Recommendation.** Withdrawal is **not** indicated by these findings. Report the confirmed errors to the chairs factually, through whatever channel they prefer (draft in `CHAIR-CORRECTION-NOTE-DRAFT.txt`, not sent), and offer the patch.

**Remaining uncertainty:**
- The reference shares the parser and the transcribed fence and sw rules (§8 of CORRECTNESS-VERIFICATION.md).
- Source-paper verdict transcriptions were not re-derived from the cited papers.
- Herd7 and Dat3M were not re-run (no SC/TSO cell changed).
- The chairs' policy on appendix growth and mid-review corrections is unknown.
