# Progress / coverage log — correctness investigation (started 2026-10-18)

Directory created fresh: <HOME>\wev-correctness-20261018 (refused-if-exists check passed).
Nothing outside this directory is written. No git commands.

## Done
- baseline/hashes.txt: PDF, tex, bib, artifact SHA256SUMS, PIN, frozen manifest, encoder sources
  (repo working tree == packaged snapshot for ESE/AC/MWE/CorpusValidation/LitmusParser).
- paper/build: repo tex rebuilt -> 37 pp; pdftotext -layout identical to submitted PDF; PDF bytes differ
  (cb7eb4b2... vs 1241dc82...) => text equivalence, not byte identity.
- classes/original: compiled from packaged snapshot; 166/166 class files byte-identical to impl/classes.
- classes/corrected (F2: same-location-only pos po edges, ESE + MWE), classes/nopo (F1: no pos po edges).
  src/corrected.diff, src/nopo.diff.
- probes/F01Probe.java (hand-built, parser-free) -> runs/f01-probe.txt.
- scripts/f01_core.py (independent z3) -> runs/f01-core.txt: minimal 6-constraint core.
- ref/ExportCases.java + ref/refcheck.py: independent relational reference (no pos, no layers).
  Probe sanity: runs ok (probes/probe-ref.csv).
- Read in full: EventStructureEncoder (551), AxiomaticConsistency (929), MWE gated wf (L262-345),
  paper L170-216, L440-494, L570-689, L1318-1360, L1495-1531.

## Running
- scripts/run_corpus.sh: {original,corrected,nopo} x {symbolic 2396, wired 847}, CorpusValidation manifest
  mode, perFileSec=30 budgetMin=600 maxEvents=64 -> runs/corpus-*/r.csv
- ref/refcheck.py over 2396 files (combo cap 200000) -> ref/ref-verdicts.csv

## Pending
- F-05 LB-real / published examples; F-06 sweep recount; F-07 ablation; claims checker; formal chain;
  Isabelle build; deliverables.

## Checkpoint 2 (2026-10-18, end)
All steps complete; deliverables written: CORRECTNESS-VERIFICATION.md, COUNTEREXAMPLES.md, VERDICT-DIFF.csv,
PAPER-IMPACT-MATRIX.csv, CORRECTIONS.md, PROPOSED-PAPER-PATCH.diff, CHAIR-CORRECTION-NOTE-DRAFT.txt (not sent),
COMMANDS-AND-RESULTS.md. Protected inputs re-hashed at end (see final check).
