# Correction record (audit 2026-10-17/18, correctness investigation 2026-10-18)

These are curated copies of the two reviews that led to corrected-v1. The originals are kept outside the package, unchanged.

**What changed in the copies.** Text files had local absolute paths replaced, as listed in `PATH-SUBSTITUTIONS.csv`. Nothing else was edited. These files are **records**: statements in them about "the package" refer to the 2026-10-12 package.

## `audit-2026-10-17/`: artifact audit of the 2026-10-12 package

| File | Content |
|---|---|
| `AUDIT-REPORT.md` | findings F-01 to F-25, with verdict NOT READY |
| `VERIFICATION-RESULTS.md` | the runs performed |
| `SUBMISSION-PACKAGING-PLAN.md` | the plan this package implements, with deviations documented in `VERIFICATION-SUMMARY.md` |
| `CLAIM-TO-EVIDENCE.csv` | traceability ledger |
| `FILE-INVENTORY.csv` | traceability ledger |
| `SOURCE-REVIEW-COVERAGE.csv` | traceability ledger |
| `KEEP-REMOVE-REVIEW.csv` | traceability ledger; 0 REMOVE CANDIDATES |
| `probes/litmus/` | the F-01 probes `2+2W+rfis`, `2+2W+rfis-pinned`, `2+2W` and `S+rfi` (stage 8 runs them under both builds) |
| `probes/out/` | the probes' recorded outputs |
| `probes/lbreal/`, `probes/examples-all/` | LB-real/LB-copy and all-example runs (symbolic and wired) |
| `experiments/pos-patch/changed-verdicts.csv` | the 12 cells found with a gated scratch patch |
| `experiments/ablation-symbolic/ablation-both.csv` | symbolic re-solve of the ablation: same 6 files |
| `work/pos-pattern-files.csv` | the 173 files exposed to the pattern |
| `scripts/pos_pattern.py` | the script that found them |

## `investigation-2026-10-18/`: independent correctness verification

| File | Content |
|---|---|
| `CORRECTNESS-VERIFICATION.md` | the full report |
| `COUNTEREXAMPLES.md` | CX-1 to CX-5 |
| `CORRECTIONS.md` | table of corrections and their effects |
| `PAPER-IMPACT-MATRIX.csv` | 27 rows, mapped to page and line |
| `VERDICT-DIFF.csv` | the 12 cells, compared across builds and the reference |
| `PROPOSED-PAPER-PATCH.diff` | the patch also shipped in `paper/proposed-correction-NOT-SUBMITTED/` |
| `COMMANDS-AND-RESULTS.md` | commands and results, failures included |
| `PROGRESS-LOG.md` | progress log |
| `src/corrected.diff`, `src/nopo.diff` | the scratch corrections that were verified. `corrected.diff` is semantically the change in `impl-corrected-v1/` |
| `probes/F01Probe.java`, `runs/f01-probe.txt` | hand-built CX-1 probe and its results |
| `scripts/f01_core.py`, `runs/f01-core.txt` | the minimal 6-constraint unsat core |
| `ref/refcheck.py`, `ref/ExportCases.java`, `ref/ref-verdicts.csv` | the **separate reference checker** and its 2026-10-18 output. It shares the parser, Z3 value reasoning and transcribed model rules with the implementation. Stage 11 re-runs it |
| `ref/exposed-files.txt` | the 173 exposed files, recomputed |
| `probes/examples/example-classification.csv` | the mechanism behind each published example's verdict |
| `probes/examples/ref.csv` | reference verdicts for the examples |
| `runs/sweep/sweep-value-consistency.csv`, `scripts/sweep_recount.py` | the 425/385 recount, re-run byte-identically on 2026-10-19 |
| `runs/ablation/ablation-symbolic-*.csv`, `probes/AblationSym.java` | symbolic ablation: 6/370 under both builds |
| `baseline/hashes.txt` | protected-input hashes at the start of the investigation |
