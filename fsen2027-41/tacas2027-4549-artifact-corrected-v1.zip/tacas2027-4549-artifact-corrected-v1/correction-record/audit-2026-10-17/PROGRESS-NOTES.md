# Audit progress checkpoint (2026-10-17)

Scratch: <HOME>\wev-artifact-audit-20261017 (created fresh). Clean ZIP extraction in extract/.

## Runs done
- runs/full1: run_all.sh from clean extraction. Stages 0,2,3,4,5,7 PASS; stage 1 FAIL caused by my USER_HOME env mangling (audit harness). run_all exit=0 despite stage 1 failing => exit-masking CONFIRMED.
- runs/isabelle1: 01_isabelle.sh standalone with MSYS2_ENV_CONV_EXCL=USER_HOME, USER_HOME in scratch: PASS, exit 0, ~23s.
- probes/: 2+2W+rfis probes, pinned classes: PSO/RA/WEAKEST/RC11 FORBIDDEN (should be ALLOWED).
- experiments/pos-patch: scratch-only patched EventStructureEncoder (-Daudit.noPosPo) => 3 eligible files change FORBIDDEN->ALLOWED for PSO,RA,WEAKEST,RC11 (changed-verdicts.csv). SC/TSO unchanged; implications/E3 unchanged.
- runs/synth: synthesis JSONs regenerate byte-identically (needs non -I python).
- runs/dfsan: validate_dfsan.py PASS, identical json.
- runs/repair-smoke: PASS. runs/repair-full: in progress.

## Key findings so far
1. pos over-constraint (EventStructureEncoder.relaxedPoConstraints) — executable defect, 3 files x 4 models.
2. run_all.sh always exits 0.
3. Linux/TACAS VM: DEPENDENCIES pins only Windows DLLs; third-party jars not shipped; JDK21/Isabelle/z3 install steps missing.
4. Package paper (36pp, tex b0584599) != submitted PDF (37pp). Repo tex 0e960997 rebuilds text-identical to submitted.
5. Identity: <LINUX_HOME> in drivers/final-rerun/run_herd7_frozen.sh and results/.../herd7-model-closure.txt (contradicts ANONYMIZATION.md).
6. Stale docs: LICENSE paths; ROOT/PwT_R4b "equivalence" wording; SYMBOLIC_RF_DESIGN.md "not implemented"; results/README & hardbench/README "Table 2 = generated-hard-pairs"; qfbv-summary/sdep-fake-summary stale headers/overclaims; examples-results.json carried 2026-08 blocks; claims-check location labels C1/C2/S1 vs submitted numbering; REPORT.md byte-identical claim vs witness nondeterminism.
7. Model jar binary-only (no source for com.weakest.model).
8. z3-solver python version unpinned while address-check summary JSON embeds z3 version (5.0.0).
9. Claims checker: S1/I1 presence-only, A2 text-summary, A5 string match => "recomputed" overstated.

## Checkpoint 2 (2026-10-18)
- All main Java (52) + 13 test files read. Unit tests: 123/123 PASS in runs/unittests (needs eval/examples mapping; no stage runs them).
- Re-run audits (runs/rerun-audits): pwt, qfbv-detector-results, layer2, detector-quality(2), oracle-audit, sdep(2), mutation-corpus-results, generated-pairs-folding + 1,400 generated litmus: byte-identical. pairs-corpus identical modulo query_ms; *-summary.md differ only in paths/wall-clock.
- 06_repair full: PASS 3656 rows (2026-10-17T15:14 -> 2026-10-18T14:12; machine may have slept).
- Dataset scan (work/datasets): all CSV/JSON parse; SHA256SUMS 14475/14475; six-model counts == paper L960-962; herd7 SC 1772/0, TSO 101/0.
  per-test-status (2403 ELIGIBLE) is pre-freeze stage; freeze.py -> 2396 (3 over bound, 4 real addr). Intentional.
- NEW F: packaged LB-real.litmus writes r0+1 (paper fig. L511-551 / A3 L1170-1172 describe copy W x=r0 and cite this file).
  Symbolic: LB-real FORBIDDEN under all 6 incl. RA (value-unreachable). LB-copy (probe) RA=ALLOWED WEAKEST=FORBIDDEN.
  21/42 example inputs FORBIDDEN under all six symbolically; all data thin-air published examples are value-unreachable;
  only RA/WEAKEST separations are 6 control examples. probes/lbreal, probes/examples-all.
- Ledgers built: FILE-INVENTORY.csv, SOURCE-REVIEW-COVERAGE.csv, KEEP-REMOVE-REVIEW.csv (scripts/build_ledgers.py).
- Remaining: CLAIM-TO-EVIDENCE.csv, AUDIT-REPORT.md, VERIFICATION-RESULTS.md, SUBMISSION-PACKAGING-PLAN.md.
