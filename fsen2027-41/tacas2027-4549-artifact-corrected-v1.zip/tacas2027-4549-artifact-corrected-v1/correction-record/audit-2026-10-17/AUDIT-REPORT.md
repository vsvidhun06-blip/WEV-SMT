# Artifact audit — WEV-SMT, TACAS 2027 paper #4549

Audited package `<HOME>\wev-submission-refresh-20261012`, its ZIP, the submitted PDF `D:\TACAS27_paper__4549.pdf` (37 pp), and the repository manuscript source and bibliography.
Audit period 2026-10-17/18. All outputs are in `<HOME>\wev-artifact-audit-20261017`, created fresh for this audit.

## 0. Readiness verdict

**Not ready to upload as-is.** The research artifact itself is in good shape:
- integrity is complete;
- all 31 claim checks pass;
- every regenerated audit is byte-identical;
- both Isabelle sessions build with no holes;
- 123/123 unit tests pass;
- the full repair stage reproduces 3,656/3,656 rows.

**Blockers before submission**, all fixable without changing any scientific result:

1. **F-02 — wrong manuscript copy.** `paper/` holds the 36-page pre-submission version, not the submitted 37-page PDF.
2. **F-03 — `run_all.sh` always exits 0.** A failed stage cannot be detected by its exit status.
3. **F-04 — not runnable on the evaluation platform.** On Linux or the TACAS VM the package cannot run as shipped: the jars are not included, the natives are pinned only as Windows DLLs, there are no JDK 21, Isabelle or z3-solver install steps, and the README defaults to a Windows setup.
4. **F-01 — implementation defect needing disclosure.** The encoder adds a global `pos` linearisation that wrongly forbids 3 eligible files under PSO, RA, WEAKEST and RC11. The paper's E1 counts are therefore off by 3 for those four models.
   - It must be **disclosed** (ERRATA/LIMITATIONS, and the paper on revision).
   - It must not be silently fixed in the pinned snapshot.

**Material issues:**
- F-05: the LB-real file differs from the paper's figure, and the published-example data thin-air agreements rest on value-unreachability.
- F-06: the "Earlier sweeps" value-consistency caveat is missing.
- F-07: the ablation run is wired-mode but presented under the symbolic convention.
- F-08: the claims checker's "recomputes" wording is too strong.
- F-09: identity paths remain in two files.
- F-11: Table-2 file references are stale.
- F-14: the model jar's licence and provenance are unstated.

**Protected inputs are unchanged.**
- The submitted PDF `1241dc82…`, repo tex `0e960997…`, bib `f25ce898…` and ZIP `c75d2991…` re-hash identically at the end of the audit.
- The package tree re-hashes to the opening inventory: 14,476 files, 0 added, 0 removed, 0 changed.

**Constraint deviation (self-reported).** During the final integrity check I ran one read-only `git status --porcelain` on the repository. It contradicts the "No Git commands" rule. It changed nothing, and no other git command was run.

## 1. Totals and coverage

| Quantity | Value |
|---|---|
| Files inventoried (dir = ZIP) | 14,476, including 14,032 `.litmus`, 166 `.class`, 1 jar, 71 `.java`, 26 `.py`, 13 `.thy`, 69 `.csv` |
| `SHA256SUMS` entries verified | 14,475 / 14,475 |
| Coverage: read fully | 213 text files, 38,545 lines: all docs, scripts, Java (52 main + 13 test), theories, ROOT, pom, configs and published example inputs. The submitted tex (1,930 lines) was also read fully |
| Coverage: programmatic | 14,089 files: corpus litmus (hash vs frozen population), generated litmus (regenerated, compared), every CSV/JSON (parsed, structural checks) |
| Coverage: partial, documented | 4 files: `gate2.py` (diffed against `gate.py`), two archived `.postfix` historical sources, `traces.md` (generated dump) |
| Binary | 170 files, hashed and type-checked; classes rebuilt identically; jar unzipped and scanned; PDFs text-extracted |
| Claims traced | 44 (`CLAIM-TO-EVIDENCE.csv`) |
| Claim status | VERIFIED family 34: 22 plain, 3 with caveat, 9 with a scoped qualifier (rows-only, wev-side-only, labelled diagnostic or reconstruction, validation-only, output not packaged, timing carried). Also CARRIED 2, CONTRADICTED 3, PARTIALLY CONTRADICTED 3, NOT VERIFIABLE on target platform 1, NOTED 1 |
| Claim categories (primary) | A regenerated 28; B recomputed from rows 11; C carried 3; D external 1; not applicable 1. External tool runs (herd7, Dat3M, DFSan, transcription sources) inside A/B rows are checked on recorded rows only |
| Verification runs | PASS 31, PASS\* 2 (timing or witness column excluded: stage 3, pairs-corpus), FAIL 1 (run_all exit masking), harness-caused FAIL 1 (stage 1; re-run PASS). NOT RUN 6, with reasons: herd7, Dat3M, DFSan compile, unpatched full corpus, scalability/BMC timing, Linux/VM (`VERIFICATION-RESULTS.md` §9) |
| Dispositions | KEEP 14,437 · REQUIRES REVIEW 22 · REPLACE DOCUMENT COPY 3 · OPTIONAL 14 · REMOVE CANDIDATE 0 |

## 2. Findings

Severity: **HIGH** blocks submission or misstates a result; **MEDIUM** is a material accuracy or reproducibility issue; **LOW** is a documentation or hygiene issue; **INFO** is recorded only.
Status is `OPEN` unless noted. "Disclosed" means the issue is already acknowledged in LIMITATIONS, ERRATA or the paper, so it is not a new defect.

### F-01 HIGH — Encoder well-formedness imposes a global po/co linearisation that no model contains
- **Files:** `impl/snapshot/src/main/java/wev/smt/EventStructureEncoder.java`.
  - L232: `encodeWellFormedness` adds `relaxedPoConstraints()`.
  - L426–445: kept po edges (consecutive R→\*, same-location W→W, same-location W→R; fences skipped) become `pos(a) < pos(b)`.
  - `coConstraints` / symbolic co ⇔ pos ties co to the same order.
- **Evidence:** In `probes/` the C program `2+2W+rfis` is FORBIDDEN under PSO, RA, WEAKEST and RC11. Its shape is `Wx1; Rx; Wy1 ∥ Wy2; Ry; Wx2` with `exists x=1 ∧ y=2`.
  - None of those model axioms forbids it, since its po edges create no ppo/hb/po∪rf cycle.
  - The plain 2+2W gives ALLOWED.
  - The same-location W→R edge plus R→W chains `Wx1 <pos Wy1`; with co (`Wy1 <co Wy2`, `Wx2 <co Wx1`) that closes a `pos` cycle.
  - A scratch copy gated by `-Daudit.noPosPo` (`experiments/pos-patch`) flips the probe to ALLOWED.
  - Over all 2,396 files × 6 models it changes exactly **12 cells, 3 files × {PSO, RA, WEAKEST, RC11}**, FORBIDDEN→ALLOWED: `Dat3M/litmus/PPC/2+2W+rfi-datas`, `Dat3M/litmus/X86/m55ii`, `Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009`.
  - 173 eligible files have the exposed shape (`work/pos-pattern-files.csv`).
- **Impact:** These cells contradict the stated semantics at tex L697–699 ("ALLOWED iff some rf and co … is model-consistent").
  - E1 (tex L960–962) would read PSO 1,173/1,223, RA 2,092/304, WEAKEST 2,359/37, RC11 2,172/224.
  - E2, E3 (187/0), SC/TSO and herd7 agreement are unchanged.
  - Table 2 rings are unaffected (no same-location W→R).
  - The defect was invisible to `RelCheck` (model layers only) and to herd7 (SC/TSO only).
- **Repair:** Do **not** patch the pinned snapshot for this submission; it would invalidate the pins and every regeneration.
  - Add an ERRATA entry and a LIMITATIONS entry naming the three files, the four models and the corrected counts.
  - Ship the probe and the patched-run diff as evidence.
  - For the camera-ready, fix `relaxedPoConstraints` (drop the global order; keep only per-model layers and coherence) and re-run.
- **Confidence:** high, by mechanism, minimal probe and corpus differential.

### F-02 HIGH — Package manuscript is older than the submitted PDF
- **Files:**
  - `paper/wev-smt.tex` (`b0584599…`), `paper/wev-smt.pdf` (`b8c8fb34…`, 36 pp);
  - `paper/README.md` L5, L11, L22 ("36 pages");
  - `README.md` L16, L53 ("36-page manuscript").
- **Evidence:**
  - The submitted PDF is 37 pp (`1241dc82…`, no Info dictionary).
  - The repo tex `0e960997…` rebuilt in `work/texbuild` gives 37 pp, with text identical to the submitted PDF (`work/pdf-word-diff.txt`).
  - Package tex versus repo tex (`work/tex-pkg-vs-repo.diff`): the repo adds the **"Use of Generative AI"** section (tex L1890–1894), rewrites the Data Availability "Supported workflow" paragraph, and has three wording changes.
  - `refs.bib` is identical.
- **Impact:** Reviewers would read a manuscript that is not the submitted one, and it lacks the AI-use disclosure.
- **Repair:**
  - Replace `paper/wev-smt.pdf` with the submitted PDF byte-for-byte and `paper/wev-smt.tex` with the repo tex `0e960997…`.
  - Keep `refs.bib`.
  - Update the 36→37 references in `paper/README.md`, the page-range notes and the README; regenerate `SHA256SUMS`.
  - Do not edit or remove the AI disclosure (plan P-1).
- **Confidence:** high.

### F-03 HIGH — `reproduce/run_all.sh` cannot signal failure
- **File:** `reproduce/run_all.sh` L19. The script ends with a `for … do echo …; done` loop and no `exit`, so the status is the loop's (0).
- **Evidence:** The real run in `runs/full1` printed `1 isabelle: 1` and `run_all exit=0` (`runs/full1/exit.txt`).
- **Impact:** Evaluators and CI cannot detect failures from the exit status. The README's "0 = all checks passed" relies on reading the summary text.
- **Repair:** After the summary, `fail=0; for k in …; do [ "${RC[$k]}" = 0 ] || [ "${RC[$k]}" = skipped ] || fail=1; done; exit $fail` (plan P-3).
- **Confidence:** high.

### F-04 HIGH — Not runnable as shipped on Linux or the TACAS VM; dependency bundle missing
- **Files:** `impl/DEPENDENCIES.txt` L23–25 (natives only as `libz3.dll`, `libz3java.dll`); `README.md` L26, L46–47 (Git Bash and Cygwin instructions); `reproduce/common.sh`; `impl/PIN.txt`.
- **Evidence:**
  - The Maven jars are not in the package; `M2_REPO` must hold them.
  - No Linux `.so` natives are pinned, and none exist in the local Maven cache, so they must be downloaded: a missing dependency.
  - The classes are Java 21 (class major version 65).
  - The toolchain pinned in PIN.txt is OpenJDK 21.0.10, while the latest TACAS AE guidance (TACAS'25 page; the 2027 AE call is not yet published) gives an Ubuntu 22.04 VM with OpenJDK 8, or Docker.
  - Isabelle2024 and `z3-solver` have no install instructions, and `z3-solver` is unpinned although `address-index-summary.json` embeds `"z3": "5.0.0"`.
  - TACAS 2027: artifacts are mandatory for tool papers and voluntary for regular papers; submission 11 Jan 2027, after acceptance; LICENSE required; DOI for the Available badge; reasonable network access permitted.
- **Impact:** An evaluator on Linux cannot run stages 4, 6 or 7 (Java), or stage 1 without installing Isabelle; badges are at risk.
- **Repair (plan P-4):**
  - Ship a `deps/` bundle: all pinned jars plus `javasmt-solver-z3` Linux natives (`libz3.so`, `libz3java.so`), each hash-pinned.
  - Add a Linux path in `common.sh` that stages `.so` natives.
  - Add an `INSTALL-LINUX.md` with exact commands: Temurin 21 tarball, Isabelle2024 Linux bundle, `pip install z3-solver==<pin>`.
  - Preferably add a Dockerfile.
  - State the smoke-test runtime.
- **Confidence:** high. Linux execution was not attempted, because doing so would require downloads.

### F-05 MEDIUM — LB-real input differs from the paper's figure; published-example data thin-air "agreements" are value-unreachable
- **Files:** `inputs/examples/paper/LB-real.litmus` (writes `r0 + 1`); tex L546–551 (figure: "In LB-real the copy r₀"), L1170–1172 (A3 cites `eval/examples/paper/LB-real.litmus`), L948–954 (31/34).
- **Evidence (`probes/lbreal`, `probes/examples-all`):**
  - In symbolic mode the packaged LB-real is FORBIDDEN under **all six models, RA included**: `exists r0=r1=1` needs a write of 1, but the program writes 2.
  - The copy program in the figure gives RA ALLOWED and WEAKEST FORBIDDEN, as intended.
  - 21 of 42 example inputs are FORBIDDEN under all six symbolically. They include every data-dependency thin-air example (TC02, 05, 06, 09, 10, 14, 17, 18, 20; LBd ×2; OOTA; LB-real), all of which write `r+1`.
  - The only RA-ALLOWED/WEAKEST-FORBIDDEN inputs are the 6 control examples.
  - In wired mode LB-real separates RA and WEAKEST, because values are ignored.
- **Impact:** The theoretical claims are unaffected; the copy program behaves as the paper says. But the cited file does not witness them in the primary mode. The FORBIDDEN agreements on data thin-air examples hold for every model, so they do not exercise jfCoherence.
  - Partly disclosed: tex L952–953 says "qualitative corroboration, not validation".
  - Not disclosed: the value-unreachability mechanism.
- **Repair:**
  - Add a note in README and LIMITATIONS, and ship `LB-copy.litmus` as the figure's program.
  - Do not edit transcribed inputs.
  - For the camera-ready, cite the copy program or state the wired-mode scope.
- **Confidence:** high.

### F-06 MEDIUM — "Earlier sweeps" 1,440/1,015 lack the value-consistency caveat applied to Table 2
- **Files:** tex L1582–1586; `results/carried/generated-pairs-summary.md` L14 and L23–28; `impl/.../cli/GeneratedPairsRun.java` Javadoc.
- **Evidence:**
  - The ring exists-clause pins every read to 1, but the real shapes (except `r & 2 ^ 1`) have e(1) ≠ 1.
  - Only 425/1,440 "valid" and 385/1,015 "discriminating" instances are value-consistent.
  - The summary's "all store expressions evaluate to 1 at r=0, so every variant wires the same candidate" concerns r=0, not the pinned r=1.
  - The regeneration is byte-identical, so the counts reproduce; it is their interpretation that is wired-mode only.
  - Table 2 was corrected for this (tex L881–890) and the mutation diagnostic carries a caveat (L1590–1593); this paragraph does not.
- **Impact:** "Required verdicts" are not program-level ground truth on 1,055 of 1,440 instances.
- **Repair:**
  - Add a caveat to ERRATA and to the summary file.
  - Camera-ready: one sentence stating the 425/385 value-consistent subset.
- **Confidence:** high.

### F-07 MEDIUM — Discriminator ablation (D1) is wired-mode; the paper's verdict convention is symbolic
- **Files:** `impl/.../ablation/SdepFakeDiscriminatingRun.java` (no `enableSymbolic`); tex L793–805.
- **Evidence:** I re-solved the 370 files under none/all/current in both modes (`experiments/ablation-symbolic/ablation-both.csv`). Symbolic gives the **same 6 discriminators**; the wired reproduction has 0/370 mismatches.
- **Impact:** The result stands, but the mode should be disclosed.
- **Repair:** Add a sentence in LIMITATIONS and the README; ship `ablation-both.csv` as corroboration.
- **Confidence:** high.

### F-08 MEDIUM — Claims checker and "recomputes 31 claim figures" wording overstate what is recomputed
- **Files:** `reproduce/05_claims.py`:
  - L234 (S1: JSON non-empty);
  - L239 (I1: theory files present);
  - L130 (A2: parses `final-analysis.txt` summary text instead of `detector-oracle-audit.csv` and the log);
  - L140 (A5: string match in a record);
  - L178 (X1: reads `examples-results.json` blocks, some carried from 2026-08).
- The wording appears at tex L1911–1912 and in README L35–37.
- **Evidence:** Read in full. The underlying figures do hold (S1 regenerated; I1 by build; A2 from the regenerated CSV and log).
- **Impact:** "Recomputed from packaged rows" is true for about 24/31 checks; the rest are presence or text checks.
- **Repair:**
  - Label each check as RECOMPUTE, PRESENCE or RECORD in the checker output.
  - Point A2 at the CSV and log.
  - Point S1 at the specific numbers in the JSON.
  - Change the README wording to "checks 31 claims (24 recomputed from rows)".
  - Camera-ready: the same wording.
- **Confidence:** high.

### F-09 MEDIUM — Local identity paths contradict ANONYMIZATION.md
- **Files:**
  - `drivers/final-rerun/run_herd7_frozen.sh` L7–8;
  - `results/authoritative/rerun-2026-10-09/herd7-model-closure.txt` L1–4 and more (`/home/<user>/.opam/4.14.2/...`);
  - `ANONYMIZATION.md` claims all such paths were replaced.
- **Evidence:** grep. No e-mails, keys or tokens were found anywhere (classes, jar and PDFs included).
- **Impact:** A local username leaks. The artifact is submitted after acceptance and need not be anonymous (TACAS AE), but the statement is inaccurate.
- **Repair:**
  - Replace the paths with `<OPAM_ROOT>` and note the substitution.
  - For the closure file, the hashes stay valid because they hash file contents, not paths.
  - Update ANONYMIZATION.md, or retire it once anonymity is no longer required.
- **Confidence:** high.

### F-10 LOW — Scalability n-set misstated
- **Evidence:** tex L970 says n ∈ {2,3,4,6,8,12,16}. `results/carried/scalability-consistency.csv` has {2,3,4,5,6,8,10,12,16}.
- **Repair:** ERRATA entry; camera-ready fix.
- **Confidence:** high.

### F-11 MEDIUM — Table 2 file references stale
- **Files:**
  - `README.md` L100 and L112 context ("Table 2 re-run byte-identically");
  - `results/README.md` L24 ("Table 2 (`generated-hard-pairs.csv`…)");
  - `results/README.md` L40;
  - `hardbench/README.md` L1, L45.
- **Evidence:** Table 2 is now `repair/symbolic-ring-audit.csv` (tex L1576–1581: `generated-hard-pairs.csv` is "historical wired evidence"). `hardbench/reconstructed/…RECONSTRUCTED.py` references the absent `check_reconstruction.py`.
- **Repair:** Edit the docs (plan P-5).
- **Confidence:** high.

### F-12 LOW — Stale appendix labels
- **Files:** `reproduce/05_claims.py` L225/L229 (C1/C2 "App. A.6"; submitted numbering is A.8), L234 (S1 "App. A.7" → A.9); `ERRATA.md` E1 L30 ("App. A.6" chain accounting → A.8).
- **Submitted numbering:** A.6 traceability, A.7 DFSan, A.8 chain, A.9 synthesis, A.10 evidence.
- **Repair:** Relabel. The labels are display strings only, so the checker logic is unchanged.

### F-13 MEDIUM — LICENSE scope names paths absent from the package
- **File:** `LICENSE` L2–4, L9–14 (`src/`, `eval/`, `research/claimD/`, `reproduce.sh`, `eval/corpus/...`).
- **Impact:** It is ambiguous which files the licence covers. A LICENSE is required by TACAS AE.
- **Repair:** Rewrite the scope with the package paths (`impl/`, `isabelle/`, `drivers/`, `reproduce/`, `synthesis/`, `results/`, `corpus/litmus/...`).

### F-14 MEDIUM — Binary model jar without source, licence or provenance statement
- **Files:** `impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar` (classes `com.weakest.model.*`, including UI classes); `THIRD-PARTY-NOTICES.md` does not mention it.
- **Repair:** State its origin and licence in THIRD-PARTY-NOTICES. If it is the author's own earlier project, say so and cover it under LICENSE; ideally add the model sources.
- **Confidence:** medium. Its origin cannot be established from the package.

### F-15 — merged into F-08.

### F-16 LOW — Stale or over-strong internal documentation and comments
These are documentation only; the scientific text in the paper is already hedged. Items in pinned sources should be annotated in README rather than edited.
- **Isabelle headers:** `isabelle/ROOT` L33–34 and `isabelle/pwt/PwT_R4b.thy` L8–10, L32–36 say "per-site equivalence" / "the universal-v check the paper attributes to R4b". The paper uses the observation-anchored transcription, and the theories cite absent files.
- **Javadoc and design notes:**
  - `LitmusParser.java` L136 ("`sdep_impl = sdep_true` exactly");
  - `SYMBOLIC_RF_DESIGN.md` L3 ("design only, not implemented");
  - `SmtBackend.java` (an empty class with a Javadoc claiming lifecycle ownership);
  - `PwtEquivalenceSweep` ("exactly PwT's criterion");
  - `RaFormalAtlasRun` ("chain closes", where the RA⇒WEAKEST rung fails by design);
  - `MinimalWitnessExtractor` ("relax identically", but it does not skip fences);
  - `LitmusCorpus.loadFrom`;
  - `DetectorOracleAuditTest` ("2972-test corpus", `eval/run_all.py`).
- **Results summaries:**
  - `qfbv-summary.md` L3, L11, L31 ("exact", "ground truth"; `ENGINEERING-SUMMARY` §5 notes that QfbvDetectorRun is structurally blind via the `!mentionsReg` short-circuit);
  - `sdep-fake-summary.md` L3 ("2 998 tests");
  - `final-analysis.txt` L75 ("fake 0, semantic 0"; the true values are 565 and 6, because `final_analysis.py` L138–140 reads the wrong columns `is_semantic`/`semantic` instead of `classification`);
  - `examples-results.json` (carried 2026-08-06 blocks: 2,972-file corpus);
  - `results/carried/dat3m-lkmm-README.md` L5–7 (1,350/1,350 headline, superseded by the 438 subset in the paper).
- **Chain report and inputs:**
  - `chain-composition/REPORT.md` L227 and tex L1765 "byte-identical" (witness values vary; stage 3 compares modulo witnesses);
  - `inputs/examples/jmm/TC18.litmus` comment (absent `eval/*.md`).
- **Repair:** One "Known documentation discrepancies" section in README (plan P-6). Edit only unpinned docs.

### F-17 LOW — Scripts write next to themselves or into the package
- **Files:**
  - `repair/validate_dfsan.py`;
  - `provenance/correction/summarize_correction.py` (stage 7 copies it first);
  - `synthesis/claimD/*.py`;
  - drivers with `eval/` defaults;
  - `chain-composition/run.sh`;
  - `reproduce/common.sh` L15 (`WORK` defaults to `$PKG/../_repro-work`, outside the package; but a user-supplied `WORK` inside the package is not refused);
  - Isabelle heaps written to the user's `~/.isabelle`.
- **Impact:** Running these in place modifies the package and breaks `SHA256SUMS`.
- **Repair:**
  - Refuse `WORK` under `$PKG`.
  - Document `USER_HOME`/`ISABELLE_HOME_USER` isolation.
  - Add output-dir arguments to the synthesis and DFSan scripts, or document running them on a copy.

### F-18 LOW — Unit tests are not part of reproduction and depend on the development layout
- **Evidence:** 123/123 pass in scratch only with `eval/examples` → `inputs/examples` mapped (`runs/unittests`).
- **Repair:** Add an optional `08_unit_tests.sh` that stages the mapping in `WORK`, and ship the JUnit jars in the dependency bundle.

### F-19 — merged into F-04 (`z3-solver` unpinned).

### F-20 LOW — Parser value-model defects (gated out, disclosed)
- **Findings:**
  - `opSym` defaults to `+` for `mr`, `neg`, `mvn`;
  - `subf` operand order is swapped;
  - `CMP W1,#0` reaches the oracle as `X1,#0` (Layer-2 row in `layer2-audit.csv`, MP01, conservative);
  - non-ARM outcome binding uses the last load.
- **Impact:** The independent gates exclude the affected files, and MP01's site is conservative and has no store downstream. No effect on eligible-file verdicts was found.
- **Repair:** List these in LIMITATIONS as known front-end limitations.

### F-21 INFO — The QF_BV oracle's relational operator binds at the outermost level, not with C precedence
The gate uses C precedence for source text and catches mismatches. No action.

### F-22 INFO — Generative-AI disclosure
The submitted PDF (tex L1890–1894) says the ideas "originated with the author" (singular). Recorded only. Preserve it verbatim when the copy is replaced (F-02); do not edit it.

### F-23 LOW — Full repair runtime guidance unverified
README L151–152 says "allow up to 30 minutes". The scratch run took about 23 h wall clock on a shared host that may have slept. Re-time on a quiet machine and state the measured figure.

### F-24 LOW — The ZIP has no top-level directory
Unzipping into a working directory spills about 25 entries. Re-zip with a single root (`wev-smt-artifact/`).

### F-25 INFO — Eligibility column semantics need a data dictionary
`fixed_outcome_query_eligible` is True for 17 `forall` KNOWN-INCORRECT rows, by design. `per-test-status.csv` (2,403 ELIGIBLE) is the pre-freeze stage. Add a short column dictionary to `provenance/README.md`.

## 3. Implementation trace — specific checks requested

| Check | Result |
|---|---|
| QF_BV width/grammar | BV32. Binary `\| ^ & + - *`; unary `~ -`; one relational operator at the outermost level (signed). No shifts or division, so these are UNPARSEABLE → conservative (F-21) |
| Oracle undecided | Parse or solver failure returns `null`; the detector keeps the edge semantic (conservative); symbolic manifest mode refuses a verdict on encoding gaps (tested) |
| jf = rf | `jfImplications` ties jf ⇔ rf; consistent with the paper's single-candidate reading |
| Acyclicity, fresh ranking variables | Integer layers; a fresh layer family per call via `layerTag`; no sharing across conjuncts |
| Legacy conjunct | `irreflexiveHbEco` is RA's coherence axiom (`irreflexive(hb;eco?)`), used as documented |
| Outcome binding / final memory | AArch64 W/X canonicalisation, width tracking, `armBindOutcome` (rejects computed, unbound and wide atoms). Symbolic memory-final uses a co-max constraint; init is co-minimal. Non-ARM last-load binding is a known limitation and gated (F-20) |
| Address handling | Register-indexed offsets resolve to the base; 202/202 proved zero (stage 7 F). Nonzero `#imm` offsets are rejected explicitly |
| Control flattening / collisions | `splitGuardedStatement` keeps guards; both arms are straight-lined. 34 example inputs form 28 distinct programs (groups a–d), as disclosed |
| Theoretical exactness vs prototype fidelity | The paper keeps them apart (tex L705–719). Internal docs overstate it (F-16). The encoder `pos` defect (F-01) is a fidelity gap outside the theory |
| Model names | SC, TSO, PSO (encoded PSO′; PSOcan separate), RA, WEAKEST, RC11 ("simplified", `acyclic(po∪rf)`). Consistent with the paper |
| Unsupported strong words | The paper hedges throughout. Over-strong uses are in internal docs only: "exact", "ground truth", "provably exact", "equivalence", "byte-identical", "recomputes" (F-08, F-16). "Byte-identical" at tex L1765 needs qualifying (F-16) |

## 4. Proof and claim correspondence

- **Build:** both sessions build clean. No `sorry`/`oops`.
- **Assumptions:** the only `axiomatization`s are `oracle_soundness`, `oracle_completeness_branch_free` and `control_conservative`, all in `WEV_SMT_Defs`. The PwT theories, including Capacity and EventBridge, import only the Expr chain and are assumption-free.
- **Mapping:** claims map to theorems as listed in the paper's mechanisation table.
- **R4b:** the paper uses the observation-anchored transcription. The theory header and ROOT text describe the older universal-v two-point check and "per-site equivalence". The program-level PwT correspondence is an inclusion, not an equality (as the paper states).
- **Repair:** a README note (F-16); do not edit pinned theories.

## 5. Evidence categories

| Category | Items |
|---|---|
| **A** regenerated | Manifests and population; gates; six-model 30-subset and the patched full run; all rerun-2026-10-09 audits; Table 2 (full repair); chain; synthesis; address check; examples; n-thread; A.4 witnesses; Isabelle; unit tests |
| **B** recomputed from rows | E1–E6, P3, H2, the Dat3M 438/390 subset |
| **C** carried | Scalability, Dat3M BMC timing, classifier-defect record, Dat3M LKMM rows |
| **D** external | herd7 runs, Dat3M runs, DFSan compilation, source-paper verdict transcriptions |

**The four named evidence files:**
- `evidence/logs/pwt.log` links the CSV by hash `8073696c`, which matches the packaged and regenerated CSV.
- `evidence/logs/oracle-audit.log` links hash `54ff7740`, which matches; the CSV holds only the 990 CONSERVATIVE rows, and 12,067 appears only in the log.
- `source-paper-results.csv` (14 rows) and `jmm-results.csv` (20 rows): the WEV-side verdicts reproduce. The source verdicts are transcriptions and were not re-checked against the cited papers (D).

## 6. Packaging hygiene

- **Secrets:** none found.
- **Personal information:** one username path (F-09).
- **Licences:**
  - upstream Dat3M (MIT-style) and herdtools7 (CeCILL-B, with Arm notices) are kept verbatim;
  - LICENSE scope is stale (F-13);
  - the model jar's licence is unknown (F-14).
- **Dependencies and platform:** F-04.
- **Writes outside their own directory:** F-17.
- **TACAS rules:**
  - checked 2026-10-17 at etaps.org/2027 (CFP) and the TACAS 2025 AE page, the latest AE guidance available;
  - the TACAS 2027 AE call must be re-checked when published (plan P-0).

## 7. Exclusion analysis

**No file qualifies as a REMOVE CANDIDATE.** Every candidate considered is either read by a stage or is documentary.
- `gate2.py`: used by `outcome_gate.py`.
- `provenance/recorded/frozen/*`: stage 7 compares against them.
- `results/carried/generated-pairs-folding.csv`: read by 05_claims.
- `results/superseded/`: disclosed as superseded.

Marked OPTIONAL: the header-only disagreement CSVs (3), `repair/dfsan-O*.ll` (2), the classifier-defect `.postfix` archives (2) and `results/superseded/**` (7). Keeping them costs about 4.5 MB. Removing any requires regenerating `SHA256SUMS` and updating README and LICENSE references. Recommendation: keep them.

## 8. Prioritised repairs

See `SUBMISSION-PACKAGING-PLAN.md`. In order:
1. P-1 synchronise the paper copy (F-02);
2. P-3 fix the run_all exit status (F-03);
3. P-4 Linux dependency bundle and install guide (F-04);
4. P-2 ERRATA/LIMITATIONS disclosures (F-01, F-05, F-06, F-07, F-10);
5. P-5 doc fixes (F-11, F-12, F-13, F-14, F-09);
6. P-6 documentation-discrepancy note (F-16);
7. P-7 hygiene (F-17, F-18, F-24);
8. P-8 regenerate SHA256SUMS, re-verify from a clean extraction, re-zip.
