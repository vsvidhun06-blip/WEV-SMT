"""Count eligible files whose per-thread consecutive (fence-free) kept pos edges chain a
write to a write of another location (the 2+2W+rfis over-constraint pattern)."""
import csv, sys, collections
P = sys.argv[1]
el = {r['path'] for r in csv.DictReader(open(P + '/corpus/manifests/frozen-population-12324.csv', encoding='utf-8')) if r['status'] == 'ELIGIBLE'}
ev = collections.defaultdict(lambda: collections.defaultdict(list))
kinds = collections.Counter()
for r in csv.DictReader(open(P + '/provenance/recorded/src12324/corpus/events.csv', encoding='utf-8')):
    if r['test'] not in el or not r['thread']: continue
    kinds[r['kind']] += 1
    ev[r['test']][int(r['thread'])].append((int(r['ord']), r['kind'], r['loc']))
print('kinds', dict(kinds), 'eligible files with events', len(ev))
hits = {}
for t, threads in ev.items():
    for th, es in threads.items():
        es.sort()
        n = len(es)
        for i in range(n):
            k, loc = es[i][1], es[i][2]
            if k not in ('W', 'WRITE', 'RMW', 'U'): continue
            # walk kept consecutive edges; a fence breaks the chain (fence edges are skipped)
            j = i; prev = es[i]
            while j + 1 < n:
                nxt = es[j + 1]
                if nxt[1] in ('F', 'FENCE'): break
                pk, pl = prev[1], prev[2]
                pwrite = pk in ('W', 'WRITE', 'RMW', 'U')
                if pwrite and pl != nxt[2]: break      # dropped cross-loc W->W / W->R
                j += 1; prev = nxt
                if nxt[1] in ('W', 'WRITE', 'RMW', 'U') and nxt[2] != loc:
                    hits.setdefault(t, []).append((th, es[i], nxt)); break
print('eligible files with write->...->write(other loc) kept chain:', len(hits))
csv.writer(open(sys.argv[2], 'w', newline='')).writerows([[t, len(v), v[0]] for t, v in sorted(hits.items())])
