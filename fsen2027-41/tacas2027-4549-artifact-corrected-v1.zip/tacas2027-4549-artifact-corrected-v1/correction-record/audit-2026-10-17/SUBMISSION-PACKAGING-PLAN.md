# Submission packaging plan (proposed — nothing below has been executed)

**Scope.** This plan turns the audited package into an upload-ready artifact. Per the audit instructions, **I stopped before modifying the package or uploading anything.**
- Every step builds a **new** copy. The existing directory, the existing ZIP, the repository, the submitted PDF, recorded results, pinned code and theories stay untouched.
- AI-use disclosures, attribution and development records are preserved verbatim.
- No scientific claim is strengthened. The F-01 defect is *disclosed*, not silently fixed.

Target: TACAS 2027 artifact evaluation. Regular papers submit after acceptance, deadline 11 Jan 2027. Aim for the Available, Functional and Reusable badges.

## P-0 Preconditions
1. Re-read the TACAS 2027 AE call once published. Confirm the VM image or Docker policy, the README and smoke-test requirements, the size limits and the DOI host (Zenodo).
2. Decide whether the artifact is still anonymised. After acceptance the AE need not be anonymous; if so, retire `ANONYMIZATION.md` rather than maintain it (F-09).
3. Choose a new build directory, e.g. `<HOME>\wev-artifact-tacas27-v4\wev-smt-artifact\`. Refuse to proceed if it exists.

## P-1 Synchronise the manuscript copy (F-02, REPLACE DOCUMENT COPY)
| Package path | Replace with | Expected SHA-256 |
|---|---|---|
| `paper/wev-smt.pdf` | `D:\TACAS27_paper__4549.pdf`, byte-for-byte | `1241dc829cfa1ccc352442ae0216fdf1b25c89cbd2f2edc832cc961f3aefc792` |
| `paper/wev-smt.tex` | repo `paper/wev-smt.tex` | `0e9609976ff5257029053fb5e144b098e936eae18a61962ca044b86b63072404` |
| `paper/refs.bib` | unchanged | `f25ce89898ddb32890b3cd6f136133eaea3a42f4b83d7525f6f3ed1d40f7b447` |
| `paper/README.md` | edit: 37 pp; new hashes; build note (MiKTeX/pdfTeX); the repo tex rebuilds to text identical to the submitted PDF (audit `work/texbuild`) | — |

- **Keep the "Use of Generative AI" section exactly as submitted**, including its wording.
- Update `README.md` L16 and L53 ("36-page" → "37-page").
- Optional: keep the old 36-page copy as `paper/superseded/wev-smt.pre-submission.{tex,pdf}`, labelled. It is not required.

## P-2 Disclosures (ERRATA.md / LIMITATIONS.md; no code change)
- **E4 (new, F-01): encoder linearisation over-constraint.** Name the 3 files and the 4 models. Give the counts as reported (E1) and as they would be without the global `pos` order: PSO 1,173/1,223, RA 2,092/304, WEAKEST 2,359/37, RC11 2,172/224. State that SC/TSO, the seven implications, E3 (187/0), herd7 agreement and Table 2 are unchanged. Ship evidence under `evidence/audit-2026-10/`:
  - the 4 probe litmus files and their results;
  - `changed-verdicts.csv` (12 rows);
  - `pos-pattern-files.csv`;
  - the patched encoder as a *separate, clearly labelled* diff, not replacing the snapshot.
- **E5 (F-05):**
  - `LB-real.litmus` writes `r0+1`; the figure's program is the copy variant.
  - Symbolic LB-real is FORBIDDEN under all six models.
  - Ship `inputs/examples/paper/LB-copy.litmus` (new file, labelled as added by the audit) and its six-model results.
  - Note that the data thin-air published-example agreements are value-unreachable; only the control examples separate RA and WEAKEST.
- **E6 (F-06):** the earlier 1,600-ring sweep is wired-mode; only 425/1,440 valid and 385/1,015 discriminating instances are value-consistent.
- **E7 (F-07):** the discriminator ablation runs in wired mode; a symbolic re-solve gives the same six files. Ship `ablation-both.csv`.
- **E8 (F-10):** the scalability n-set is {2,3,4,5,6,8,10,12,16}.
- **E9 (F-16 subset):**
  - tex L1765 "byte-identical": witness values vary; deterministic outputs are identical.
  - `final-analysis.txt` §8 should read fake 565 / semantic 6 (a reader bug in `final_analysis.py`).
- **ERRATA E1 label:** "App. A.6" → "App. A.8" (F-12).
- **LIMITATIONS:** add the F-20 parser limitations list.

## P-3 Fix `run_all.sh` exit status (F-03)
Append to `reproduce/run_all.sh` after the summary loop:
```bash
fail=0
for k in "0 manifest" "1 isabelle" "2 generators" "3 chain" "4 impl smoke" "5 claims" "7 provenance"; do
  case "${RC[$k]}" in 0|skipped) ;; *) fail=1 ;; esac
done
exit $fail
```
Verify by forcing a stage failure in a scratch copy: the exit must be non-zero.

## P-4 Linux / TACAS-VM runnability (F-04)
1. Add `deps/` with every jar listed in `impl/PIN.txt` and `DEPENDENCIES.txt`. That covers JavaSMT 5.0.1, `javasmt-solver-z3` 4.13.0 (jar plus **Linux** natives `libz3.so` and `libz3java.so` from the same Maven artifact, and the Windows DLLs already pinned), Guava etc., plus JUnit 5.11.3 / platform 1.11.3 for P-7.
   - **Missing dependency:** the local Maven cache holds only the Windows DLLs for `javasmt-solver-z3` 4.13.0. The Linux natives (`javasmt-solver-z3-4.13.0-libz3-x64.so`, `...-libz3java-x64.so`) must be fetched from Maven Central by the author, a network step the audit did not perform. Pin them by SHA-256 on arrival.
   - Check the redistribution terms of each jar; these are Apache-2.0, MIT and EPL-style licences.
   - Add their notices to `THIRD-PARTY-NOTICES.md`.
2. `impl/DEPENDENCIES.txt`: add `NATIVE-LINUX` rows with SHA-256s.
3. `reproduce/common.sh`:
   - default `M2_REPO` to `$PKG/deps` when set up in the Maven layout;
   - stage `.so` natives on Linux and `.dll` on Windows;
   - keep the Git Bash path.
4. Add `INSTALL-LINUX.md` with tested commands for Ubuntu 22.04:
   - Temurin JDK 21 tarball (the VM's OpenJDK 8 cannot run the classes, which target 21);
   - Isabelle2024 Linux bundle and `ISABELLE_HOME`;
   - `python3 -m pip install z3-solver==<version that reports 5.0.0, i.e. the recorded one>`;
   - the expected runtime of each stage.
5. Preferred: a `Dockerfile` (Ubuntu 22.04 + Temurin 21 + Isabelle2024 + pinned z3-solver) that runs `SKIP_ISABELLE=0 bash reproduce/run_all.sh`. Document the image size.
6. README: add a ≤30-minute **smoke test** (stages 0, 2, 4, 5, 7 and `06_repair.py --smoke`) and a "full" path with measured times. Re-time `06_repair.py` full on a quiet machine (F-23).
7. **Test it:** run the whole sequence on a clean Ubuntu 22.04 VM or container before upload. The audit could not, because that would require downloads.

## P-5 Documentation corrections (REQUIRES REVIEW files)
| File | Change |
|---|---|
| `LICENSE` | Rewrite the scope with the real package paths (F-13) |
| `THIRD-PARTY-NOTICES.md` | Add `impl/deps/visualising-weakest-executions-1.0-SNAPSHOT.jar`: origin, licence and an "own earlier work" statement if true; add the `deps/` jars (F-14) |
| `README.md` | 37 pp; Table 2 = `repair/symbolic-ring-audit.csv`; "checks 31 claims (24 recomputed from rows, 7 presence/record)"; smoke test; Linux pointer |
| `results/README.md`, `hardbench/README.md` | Table 2 references (F-11); remove the `check_reconstruction.py` mention or ship it |
| `results/carried/dat3m-lkmm-README.md`, `generated-pairs-summary.md` | Prepend a "superseded headline" note pointing to the paper's 438 subset and the value-consistency caveat (no rewrite of the carried body) |
| `drivers/final-rerun/run_herd7_frozen.sh`, `results/.../herd7-model-closure.txt` | Replace `/home/<user>/.opam` with `<OPAM_ROOT>` and record the substitution (F-09). The content hashes in the closure file remain valid |
| `ANONYMIZATION.md` | Update or retire (P-0.2) |
| `reproduce/05_claims.py` | Relabel C1/C2 → App. A.8 and S1 → App. A.9; add a RECOMPUTE/PRESENCE/RECORD tag per claim; point A2 at `detector-oracle-audit.csv` plus the log (F-08, F-12). Re-run and expect 31/31 |
| `provenance/README.md` | Data dictionary for `status`, `fixed_outcome_query_eligible`, and pre-freeze versus frozen (F-25) |

Do **not** edit:
- pinned sources (`impl/snapshot/**`, `impl/classes/**`) or theories (`isabelle/**`);
- recorded results (`results/authoritative/**` CSVs, `repair/*.csv`, `chain-composition/results/**`);
- transcribed inputs (`inputs/examples/**`, except adding the labelled `LB-copy.litmus`).

For stale comments inside pinned files, use P-6.

## P-6 "Known documentation discrepancies" section in README (F-16)
List each stale statement inside pinned or recorded files, with its file:line and the correct reading. That covers the ROOT and PwT_R4b headers, the LitmusParser `CONSTANCY_ORACLE` Javadoc, `SYMBOLIC_RF_DESIGN.md`, `SmtBackend`, the `PwtEquivalenceSweep`, `RaFormalAtlasRun` and `MinimalWitnessExtractor` Javadocs, `qfbv-summary.md`, `sdep-fake-summary.md`, `examples-results.json` carried blocks, `final-analysis.txt` §8, chain `REPORT.md` L227, and the TC18 comment. This keeps the pins valid and still corrects the record.

## P-7 Hygiene (F-17, F-18, F-24)
- `common.sh`: refuse a `WORK` that resolves inside `$PKG`. Document `USER_HOME` isolation for Isabelle (`ISABELLE_HOME_USER`) and the `MSYS2_ENV_CONV_EXCL=USER_HOME` gotcha on Git Bash.
- README: "run `synthesis/claimD/*.py`, `repair/validate_dfsan.py` and the `drivers/**` scripts on a copy". Or add output-dir arguments in non-pinned scripts only.
- Optional `reproduce/08_unit_tests.sh`: copies `inputs/examples` to `$WORK/eval/examples`, compiles the tests against `impl/classes` and the JUnit jars from `deps/`, runs them from `$WORK`, and expects 123/123.
- ZIP with a single top-level folder `wev-smt-artifact/`.

## P-8 Seal and verify
1. Regenerate `SHA256SUMS` over the new tree (LF, sorted, excluding itself).
2. From a **fresh extraction of the new ZIP**, in a new scratch directory:
   - `bash reproduce/run_all.sh` (expect exit 0 and every stage 0);
   - a negative test (expect non-zero);
   - `06_repair.py --smoke`;
   - the unit tests;
   - on Linux, the same via the Dockerfile.
3. Compare the new tree against the audited tree. The only differences should be the files listed in P-1 to P-7. Produce `CHANGES-<date>.md` from this diff.
4. Deposit on Zenodo for the DOI (Available badge) only after the above passes. Uploading is a separate step for the author; it was not performed.

## Proposed upload contents (new artifact v4)
```
wev-smt-artifact/
  README.md  INSTALL-LINUX.md  Dockerfile  LICENSE  THIRD-PARTY-NOTICES.md
  CHANGES-<date>.md  ERRATA.md (E1–E9)  LIMITATIONS.md  [ANONYMIZATION.md only if still required]
  SHA256SUMS
  paper/          wev-smt.pdf (= submitted 37 pp)  wev-smt.tex (0e960997…)  refs.bib  README.md
  reproduce/      00–07 (+ optional 08_unit_tests.sh), run_all.sh (exit fixed), common.sh (WORK guard, Linux natives)
  impl/           snapshot/ classes/ deps/(model jar) PIN.txt DEPENDENCIES.txt (+Linux natives)
  deps/           pinned Maven jars + z3 natives (Linux + Windows) + JUnit
  isabelle/       unchanged
  corpus/         unchanged (litmus + licences + manifests)
  inputs/         unchanged + examples/paper/LB-copy.litmus (labelled addition)
  provenance/ address-check/ chain-composition/ hardbench/ repair/ synthesis/ drivers/   unchanged
                  except the path redaction in drivers/final-rerun/run_herd7_frozen.sh
  results/        unchanged recorded data; README fixes; redacted herd7-model-closure.txt
  evidence/       unchanged + audit-2026-10/ (F-01 probes, changed-verdicts.csv, pos-pattern-files.csv,
                  labelled encoder diff, LB-copy results, ablation-both.csv, unit-test log)
```
**Excluded:** nothing from the audited package. All 14 OPTIONAL files stay; there are 0 REMOVE CANDIDATEs. Audit scratch outputs are not shipped, except the curated `evidence/audit-2026-10/`.

**Estimated size:** the current ZIP is 17.4 MB. Adding the pinned jars and z3 natives for both platforms (the Windows z3 artifact alone is about 17 MB unpacked) should give roughly 60–90 MB. Measure after P-4.
