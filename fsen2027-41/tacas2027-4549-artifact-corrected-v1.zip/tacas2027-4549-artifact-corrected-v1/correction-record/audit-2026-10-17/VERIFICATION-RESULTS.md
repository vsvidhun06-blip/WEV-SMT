# Verification results — WEV-SMT artifact, TACAS 2027 paper #4549

Audit scratch directory: `<HOME>\wev-artifact-audit-20261017`. It was created fresh on 2026-10-17, and every run below wrote only into it.
Package under audit: `<HOME>\wev-submission-refresh-20261012`, with ZIP `...20261012.zip` (SHA-256 `c75d2991...a5fa`).
Nothing in the package, the ZIP, the repository or the submitted PDF was modified. Re-hashing at the end of the audit is listed in §9.

Legend for results: **PASS** (identical to recorded output), **PASS\*** (identical modulo a documented timing or witness column), **FAIL**, **SKIP**, **NOT RUN** (with reason).

## 1. Integrity and packaging

| Check | Result | Evidence |
|---|---|---|
| Freeze hashes (PDF, tex, bib, ZIP, package tex/pdf) recorded before work | PASS | `work/freeze-hashes*` |
| ZIP ↔ directory: same 14,476 files, no extras in either, all hashes equal | PASS | `work/inventory-raw.json` (`only_in_dir=[]`, `only_in_zip=[]`, `dir_zip_hash_mismatch=[]`) |
| `SHA256SUMS` (14,475 entries, LF) verifies, twice, by independent code | PASS | stage 0, and `scripts/dataset_scan.py` → 14,475/14,475 |
| Path traversal, absolute paths, symlinks in the ZIP | PASS (none) | inventory |
| Case-insensitive collisions | PASS (none) | inventory |
| Longest path | 140 chars, or 172 with the `wev-submission-refresh-20261012/` prefix | inventory; fine for Linux, but close to Windows MAX_PATH once nested deeper |
| ZIP top-level folder | **Note:** the ZIP has no top-level directory, so it extracts into the current directory | F-24 |
| Duplicates | 61 groups / 127 files, all intentional: upstream litmus duplicates, frozen manifests copied under `provenance/recorded/frozen` (read by stage 7), header-only disagreement CSVs | `work/inventory-raw.json` |
| Clean extraction into `extract/` | PASS | used for every run below |

## 2. Stage runs from the clean extraction (`runs/full1`, 2026-10-17 14:56–15:04)

| Stage | Result | Notes |
|---|---|---|
| 0 manifest | PASS | 14,475/14,475 |
| 1 isabelle | FAIL in the first run (my harness error) → **PASS** on rerun | First run: MSYS rewrote my `USER_HOME=/cygdrive/...` value, an audit-harness error. Rerun with `MSYS2_ENV_CONV_EXCL=USER_HOME` and an isolated `USER_HOME` (`runs/isabelle1`): both sessions WEV_SMT and WEV_SMT_PwT build, 23 s, exit 0; `check_holes.py` finds no `sorry`/`oops` |
| 2 generators | PASS | hardbench candidate list and chain inputs regenerate byte-identically |
| 3 chain | PASS\* | deterministic outputs identical; `pairs-final.csv`/`traces.md` compared modulo z3 witness values (23 lines differ in chain-a), every real witness re-confirmed |
| 4 impl smoke | PASS | snapshot hashes = PIN; fresh `javac` gives class hash `86f06894...`; wired hardbench byte-identical; 30-file six-model subset 0 differences |
| 5 claims | PASS 31/31 | presence- and text-type checks noted in F-08 |
| 7 provenance (`--with-java`) | PASS, 0 failures | gates A–D, eligibility/freeze C, address check F (corpus 202/202 VERIFIED_ZERO; controls 18/18 as expected) |
| **run_all.sh exit status** | **FAIL (defect)** | Exited **0** while stage 1 reported **1**: the trailing `for … echo` loop sets the status (F-03) |

## 3. Repair stage (06)

| Run | Result | Notes |
|---|---|---|
| `06_repair.py --smoke` (`runs/repair-smoke`) | PASS | 6 rows |
| `06_repair.py` full (`runs/repair-full`) | **PASS: 3,656 symbolic ring rows match exactly** | Wall clock 2026-10-17T15:14 → 2026-10-18T14:12. The host was shared with other jobs and may have slept, so the runtime is not a measurement; README's "allow up to 30 minutes" is **unverified** (F-23) |

## 4. Regeneration of authoritative re-run outputs (`runs/rerun-audits`, pinned classes, frozen manifest)

| Output | Result |
|---|---|
| `pwt-equivalence-sweep.csv` (58/58) | PASS (byte-identical) |
| `qfbv-detector-results.csv` | PASS; `qfbv-summary.md` differs only in absolute paths and wall-clock (3.1 s → 1.7 s) |
| `layer2-audit.csv` | PASS |
| `detector-quality/detector-quality-report.csv`, `pattern-frequency.csv` | PASS |
| `detector-oracle-audit.csv` (`--limit 12000`, RESULT PASS) | PASS |
| `sdep/sdep-discriminating-all-fake-tests.csv`, `sdep-fake-summary.md` | PASS |
| `mutation-corpus-results.csv` | PASS; summary differs only in source path line |
| `pairs-corpus.csv` (CoherencePairs adapter, compiled in scratch) | PASS\* (identical after dropping the `query_ms` timing column) |
| `generated-pairs-folding.csv` + 1,400 generated `.litmus` | PASS (identical to both the authoritative and the carried copy; `diff -r` clean) |

## 5. Other regenerations (category A)

| Item | Result |
|---|---|
| Published examples / JMM / Dat3M-41 (SymbolicRfRun over `inputs/examples`) | 31/34, JMM 18/20, Dat3M 35/41 symbolic / 31/41 wired; 0 mismatches against `examples-results.json` |
| Collision groups of example inputs | 34 files form 28 distinct parsed programs, as stated |
| n-thread grounded admission | verdicts identical to the carried CSV |
| Synthesis (`synthesis/claimD/*.py`, run without `-I` because of a sibling import) | JSONs byte-identical; w=2 → m=4, w=3 → m=8/12, 305 > 256 hold |
| App. A.4 witnesses (PsoCanonicalComparison, RaFormalAtlasRun) | CO-MP: PSOcan ALLOWED / RA FORBIDDEN; LBdep-real: RA ALLOWED / WEAKEST FORBIDDEN. Their CSVs are **not packaged** |
| DFSan validation (`validate_dfsan.py`) | PASS, JSON identical; DFSan itself not re-run (needs Linux clang-18) |
| Ablation independence | Re-solve of the 370 fake-carrying files in symbolic mode (`experiments/ablation-symbolic`) gives the same 6 discriminators; wired reproduction 0/370 mismatches |

## 6. Unit tests (`runs/unittests`)

No reproduction stage runs the packaged JUnit suite. I compiled `impl/snapshot/src/test/java` against the pinned classes and JUnit 5.11.3 / platform 1.11.3 from the local Maven cache, with a scratch launcher. I ran it from a scratch working directory where `eval/examples` is a copy of `inputs/examples`; the tests hard-code the development path.
**Result: 123 tests found, 123 successful, 0 failed, 0 skipped.** Without that path mapping, `PaperExampleTest` and `LitmusParserTest.representativeAddrFileRecordsFakeAddrDependency` cannot find their inputs (F-18).

## 7. Dataset structure (`work/datasets/dataset-checks.csv`, `dataset-scan.csv`)

- All 83 CSV/JSON files parse; no ragged rows. Two CSVs are deliberately header-less: the eligible manifest and its frozen copy.
- Population: 12,324 files on disk = 12,324 rows; 0 missing; 0 hash mismatches. The 2,396 eligible files match their pinned hashes.
- Six-model symbolic table: 14,376 rows = 2,396 × 6, one per (file, model), result ∈ {SAT, UNSAT}, verdict consistent. The counts equal the paper text at tex lines 960–962. Wired table: 5,082 = 847 × 6.
- `symbolic-ring-audit.csv`: 3,656 unique rows; the 1,288 SAT rows equal `symbolic-value-consistent.csv`; WEAKEST equals the oracle label on all 1,288.
- herd7 versus repaired symbolic: SC 1,772 compared / 0 disagreements; TSO 101 / 0.
- **Two intentional "FAIL"s explained.**
  - `fixed_outcome_query_eligible` is True for 2,413 population rows: 2,396 ELIGIBLE plus 17 `forall` KNOWN-INCORRECT rows, by design in `eligibility.py` L153–154.
  - `per-test-status.csv` is the pre-freeze stage (2,403 ELIGIBLE); `freeze.py` removes 3 files over the event bound and 4 real-address-index files. Neither is a defect; only a data dictionary is missing (F-25).

## 8. Probes and experiments (scratch only)

| Probe | Result |
|---|---|
| `probes/litmus/2+2W*.litmus`, `S+rfi` | 2+2W ALLOWED (PSO/RA/WEAKEST/RC11); **2+2W+rfis FORBIDDEN** under PSO/RA/WEAKEST/RC11, although no model axiom forbids it |
| `experiments/pos-patch` (copy of `EventStructureEncoder` gated by `-Daudit.noPosPo`) | Probe becomes ALLOWED. On the 2,396 corpus files, **3 files × 4 models flip FORBIDDEN→ALLOWED** (`PPC/2+2W+rfi-datas`, `X86/m55ii`, `AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009`); SC/TSO, E2 and E3 are unchanged (F-01) |
| `scripts/pos_pattern.py` | 173 eligible files contain a W→…→W (other location) chain through kept po edges, i.e. are exposed to the pattern; 3 actually flip |
| `probes/lbreal` | Packaged `LB-real` (r0+1) symbolic: FORBIDDEN under all six models, RA included. Copy variant: RA ALLOWED, WEAKEST FORBIDDEN (F-05) |
| `probes/examples-all` | 21/42 example inputs FORBIDDEN under all six models symbolically; RA-ALLOWED/WEAKEST-FORBIDDEN only for the 6 control examples (F-05) |

## 9. Not run / skipped, with reasons

- **herd7 7.58 and Dat3M v4.4.1 runs:** not installed; I was told to avoid installations. Their outputs are checked as recorded rows only (category D for the tool runs).
- **DFSan compilation:** needs Linux clang-18. Only validation was run.
- **Full unpatched six-model corpus re-run:** not run as such. What was run instead:
  - the 30-file subset (stage 4);
  - one full symbolic six-model run of all 2,396 files with the `pos`-patched encoder (14,376 cells, 243 s). It matches the authoritative CSV in **14,364/14,376 cells**, and the only 12 differences are the F-01 cells. It is a near-complete regeneration, but with one deliberate change;
  - recomputation from rows.

  The unpatched wired 847-file table was not re-run.
- **Scalability sweep, Dat3M BMC timing:** carried (C); not re-measured.
- **TACAS VM / Linux run:** not possible here. The jars are not shipped, and the natives are pinned only as Windows DLLs (F-04).
- **Final re-hash of protected inputs.** Required before closing the audit: compare `work/freeze-hashes*` against the current SHA-256 of the submitted PDF, repo tex/bib, ZIP and package. Result: see AUDIT-REPORT.md §0.
