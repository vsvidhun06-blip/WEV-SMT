# `impl/`: the SUBMITTED build (unchanged)

This directory is the implementation that produced every figure of the submitted manuscript. Its contents are byte-identical to the 2026-10-12 package: `snapshot/`, `classes/`, `PIN.txt`, `DEPENDENCIES.txt` and `deps/visualising-weakest-executions-1.0-SNAPSHOT.jar`.

**Pins (not re-defined):**
- snapshot aggregate `04d5604b133bc7d7a3b329843a7be9c6070e44f2d7e917b3b0075340f7f827e2`;
- classes aggregate `86f068947142ad3e44a80ca77447744858a29190703d2d8c76f22aafabd6bced`.

Stage 4 recompiles the snapshot and checks both.

**Known defect.** `snapshot/src/main/java/wev/smt/EventStructureEncoder.java` `relaxedPoConstraints`, and its gated copy in `MinimalWitnessExtractor.java`, over-constrain well-formedness (`CORRECTION-NOTICE.md`, C-1). The Javadoc there claims that the relaxation "does not weaken any model below its textbook strength". That comment is accurate about weakening, but it misses the over-constraint introduced by the kept cross-location R→W/R→R edges.

The source is **not edited** here. The corrected build is in `../impl-corrected-v1/`.

**Added in corrected-v1** (outside the pins):
- this file;
- `deps/model-source/` and `deps/MODEL-JAR-PROVENANCE.md`, the source and provenance of the model jar.

Other stale comments in the snapshot are listed in the top-level `README.md`, section "Known documentation discrepancies".
