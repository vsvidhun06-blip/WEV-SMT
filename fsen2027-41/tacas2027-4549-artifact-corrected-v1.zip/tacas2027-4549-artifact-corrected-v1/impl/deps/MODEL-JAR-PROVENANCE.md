# Model jar: `visualising-weakest-executions-1.0-SNAPSHOT.jar`

Audit finding F-14 (2026-10-17): "binary model jar without source, licence or provenance statement". This file records what was established on 2026-10-19. Nothing is inferred beyond it.

| Item | Fact | Evidence |
|---|---|---|
| Jar | SHA-256 `4c88524b28a9a341bfaa56c5e271230bc59a52e5c156be0273a2967d3e245469`; pinned for the submitted build in `impl/DEPENDENCIES.txt` and `impl/PIN.txt`; unchanged | `SHA256SUMS` |
| Maven coordinates | `com.weakest:visualising-weakest-executions:1.0-SNAPSHOT`; manifest "Created-By: Maven JAR Plugin 3.4.1, Build-Jdk-Spec: 21"; class timestamps 2026-05-25 | jar `META-INF/` |
| Source project | the author's development workspace project "Visualising WEAKest Executions" (`pom.xml` name). Its embedded `META-INF/maven/.../pom.xml` is byte-identical to that project's `pom.xml` | compared 2026-10-19 |
| Classes used by WEV-SMT | only package `com.weakest.model`: 19 class files from 13 sources (`Event`, `EventStructure`, `EventType`, `ExecutionSnapshot`, `ExecutionState`, `FenceEvent`, `Instruction`, `MemoryOrder`, `Program`, `ProgramThread`, `ReadEvent`, `RMWEvent`, `WriteEvent`) | grep of every packaged Java source |
| Source shipped | `model-source/src/main/java/com/weakest/model/*.java` and `model-source/pom.xml`, copied unmodified from the source project on 2026-10-19 | `SHA256SUMS` |
| Source ↔ jar | `javac -g -source 21 -target 21` (JDK 21.0.10) on the 13 sources reproduces **all 19** `com.weakest.model` class files of the jar **byte-for-byte** | `reproduce/08_corrected_build.sh` (check "model jar") |
| Other jar content | `com.weakest.ui`, `.checker`, `.parser` and `com.weakest.Main`, the project's JavaFX visualiser. WEV-SMT does not load them. Their sources are not shipped; they need JavaFX and GraphStream | jar listing |
| Licence | **Not established.** The source project has no LICENSE file and no licence headers. The 2026-10-12 package called the jar "the project's own model jar", which is consistent with it being the authors' own earlier work. That ownership claim has **not** been independently verified here | — |

**Author action required before publication.** Confirm that the model library is the authors' own work, and state its licence: for example, extend `LICENSE` (MIT, "The WEV-SMT Authors") to `impl/deps/`. Until then, `LICENSE` lists it as "to be confirmed". Do not publish the artifact under an open licence for this component without that confirmation.
