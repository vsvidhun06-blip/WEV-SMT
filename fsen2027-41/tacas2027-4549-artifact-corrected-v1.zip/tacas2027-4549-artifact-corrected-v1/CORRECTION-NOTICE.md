# CORRECTION NOTICE: TACAS 2027 submission #4549, artifact corrected-v1

> **Read this first.**
> - This package contains the implementation and results behind the **submitted** manuscript, **unchanged**.
> - Beside them it contains a **corrected** implementation (`impl-corrected-v1/`) and its results (`results/corrected-v1/`).
> - The submitted manuscript (`paper/submitted/`) is **unchanged**. It still prints the submitted-build figures, including four erroneous model totals (C-1).
> - The corrected figures are **not** figures of the submitted manuscript.
> - A proposed manuscript correction is in `paper/proposed-correction-NOT-SUBMITTED/`. It has **not** been submitted, accepted or approved.
> - Whether, and how, a correction may be made during review is for the TACAS 2027 chairs to decide. That procedure is **unresolved**.

Dates:
- audit 2026-10-17/18 (`correction-record/audit-2026-10-17/`);
- correctness investigation 2026-10-18 (`correction-record/investigation-2026-10-18/`);
- corrected package 2026-10-19.

The version map is in `VERSION-MAP.md`. The verification of this package is in `VERIFICATION-SUMMARY.md`.

---

## C-1. Implementation defect: well-formedness over-constraint (finding F-01). Four totals change.

**What was wrong.**
- `EventStructureEncoder.encodeWellFormedness` orders all events by one global witness order `pos`, and reads co off it.
- `relaxedPoConstraints` dropped cross-location W→W and W→R program-order edges, but kept cross-location R→W and R→R edges.
- Through an intermediate read, `W x; R x; W y` therefore re-imposed `W x < W y`. In 2+2W-shaped programs with internal reads, the co edges then closed a `pos` cycle.
- The query became unsatisfiable although **no** PSO, RA, WEAKEST or RC11 axiom forbids the execution.
- The minimal counterexample is CX-1 `2+2W+rfis` (hand-built, no parser). Its **well-formedness formula alone** is UNSAT on a legal candidate. The minimal unsat core has 6 constraints (`correction-record/investigation-2026-10-18/COUNTEREXAMPLES.md`).
- `MinimalWitnessExtractor`'s gated copy had the same leak, and additionally kept edges into and out of fences.

**Effect on the 2,396-file frozen eligible population** (symbolic mode, six models, 14,376 cells):
- Exactly **12 verdicts change, all FORBIDDEN→ALLOWED**: 3 files × {PSO, RA, WEAKEST, RC11}.
  - `Dat3M/litmus/PPC/2+2W+rfi-datas.litmus`
  - `Dat3M/litmus/X86/m55ii.litmus`
  - `Dat3M/litmus/AARCH64/mixed/2+2W+posw0q0-poq0q0-posq0w0s009.litmus`
- There are no UNKNOWN, TIMEOUT, ERROR or UNSUPPORTED results in either build.

| Model | **Submitted manuscript** (§6.4, p. 16, tex L960–962), ALLOWED/FORBIDDEN | **Corrected v1**, ALLOWED/FORBIDDEN |
|---|---|---|
| SC | 36 / 2,360 | 36 / 2,360 (unchanged) |
| TSO | 563 / 1,833 | 563 / 1,833 (unchanged) |
| PSO | 1,170 / 1,226 | **1,173 / 1,223** |
| RA | 2,089 / 307 | **2,092 / 304** |
| WEAKEST | 2,356 / 40 | **2,359 / 37** |
| RC11 | 2,169 / 227 | **2,172 / 224** |

**Verified unchanged** by recomputation from the corrected rows and by re-runs with the corrected build (stages 3c, 6c, 8–11):
- SC and TSO verdicts, on all 2,396 files;
- the seven derivable implications (0 violations), and the measured TSO⇒WEAKEST (0);
- the 187/0 WEAKEST-ALLOWED/RC11-FORBIDDEN split;
- the six discriminators (the wired ablation re-run with the corrected build is byte-identical);
- the wired 847-file table and its differences from symbolic mode;
- the chain experiment (Table 1);
- Table 2: the 3,656-row ring audit with the corrected build is byte-identical;
- agreement with the **recorded** herd7 7.58 rows (sc.cat 1,772/1,772; x86tso.cat 101/101).

**Not re-run:** herd7, Dat3M and DFSan were **not** re-executed for this correction. The herd7 and Dat3M comparisons are recomputed against recorded rows only. The herd7 comparisons involve only SC and TSO cells, which do not change.

**Significance, not an error.** After correction, the 37 WEAKEST-FORBIDDEN eligible files are exactly the files forbidden by the shared base alone (CoherencePerLocation + RMWAtomicity). jfCoherence decides no eligible corpus verdict as parsed. In the submitted build, the only 3 files that WEAKEST forbade beyond that base were the F-01 errors.

**The repair** (`impl-corrected-v1/CORRECTION.diff`, applied only to the corrected snapshot):
- In both well-formedness encoders, keep a program-order edge in `pos` **only when both endpoints access the same location**.
- Fences have no location and are therefore excluded.
- 166 class files compile. Exactly 3 differ from the submitted build: `EventStructureEncoder`, `MinimalWitnessExtractor` and `MinimalWitnessExtractor$1`.
- The parser and every other class are byte-identical.

**The well-formedness argument, and what it covers.**
- *Statement.* For a finite, all-active candidate with rf and co fixed, the **corrected** `EventStructureEncoder.encodeWellFormedness` (symbolic or wired) is satisfiable iff all of the following hold:
  - each read has exactly one same-location rf source with matching value;
  - co is a strict total order per location, with the initial write first in symbolic mode, or the loader's order in wired mode;
  - the value, outcome and co-maximal final-memory atoms hold;
  - per location, same-location program order ∪ co is acyclic.
- *Why the last condition costs nothing.* CoherencePerLocation implies it, and every model conjoins CoherencePerLocation (`AxiomaticConsistency`).
- *Proof idea.* Every remaining `pos` constraint relates two events of one location. Per-location strict orders on disjoint event sets always extend to one global order of `n` distinct positions.
- *Scope.* This argument is the proposed Lemma "Well-formedness adequacy" (proposed patch, App. A). It is **false for the submitted build** (CX-1).
  - It covers the corrected `EventStructureEncoder`.
  - The corrected `MinimalWitnessExtractor` mirrors it under activity gating. That is checked by regression tests, but the lemma does not state it.
  - It is a paper-level argument, **not** mechanised in Isabelle. The Isabelle development proves nothing about the Java encoder.

**How the correction was checked** (`VERIFICATION-SUMMARY.md`):
- the CX-1 probe;
- 17 new regression tests (`WellFormednessAdequacyTest`, `F01CorpusRegressionTest`):
  - on the corrected build all 17 pass, and the full suite passes 140/140;
  - on the submitted build exactly the 7 defect-specific tests fail and the 10 preservation and control tests pass;
- full-population re-runs of both builds with identical settings;
- a separate relational reference checker.

**What the reference checker shares with the implementation.** It enumerates rf and co explicitly and evaluates each relational model predicate with plain graph algorithms, with no `pos` variables and no integer layers. It is **not fully independent and not an external semantics**. It shares:
- the parser: it reads LitmusParser's output;
- Z3, for BV32 value reasoning;
- model rules transcribed from the paper and Javadoc: the TSO/PSO fence and RMW rules, and RA's release/acquire-like rules.

It agrees with the corrected build on 14,376/14,376 cells, and differs from the submitted build in exactly the 12 cells above.

## C-2. Proposition 1: the scope of its consistency conjunct versus the complete query

- **Proposition 1** (p. 8, tex L473–481; proof p. 25, L1518–1531) is correct as stated. It concerns the **consistency** formula at a fixed candidate.
- The surrounding text overstates its coverage:
  - L1513–1514 says it "holds of the emitted formula as it stands";
  - caveat (iv) (L490–492) lists only extraction and value-encoding fidelity as remaining obligations.
- The solved query also contains the separately emitted **well-formedness** conjunct, which Prop. 1 does not cover. For the submitted build the "if" direction fails for the complete query (CX-3).
- The "only if" direction is unaffected, because well-formedness only removes models.
- Classification: an implementation defect plus overbroad scope text. No theorem is false.
- The proposed patch narrows the sentence and adds the well-formedness lemma (C-1) and a missing obligation to caveat (iv).

## C-3. LB-real: the packaged transcription versus the figure's copy program

- The paper's Fig. 1 (p. 9, L511–551) draws LB-real with **copy** stores, `W x = r0`.
- Appendix condition (A3) (p. 20, L1170–1172) cites `eval/examples/paper/LB-real.litmus`, shipped here as `inputs/examples/paper/LB-real.litmus`. That file stores **`r0 + 1`**.
- With `r+1` stores the outcome `r0 = r1 = 1` is **value-unreachable**: no thread writes 1. In symbolic mode the file is FORBIDDEN under all six models, RA included, and with no axiom at all.
- The original file is **unchanged**. A **labelled diagnostic input** `inputs/diagnostic-added-2026-10/LB-copy.litmus` (added 2026-10-18, *not* original evidence) encodes the figure's copy program.

| Input | SC | TSO | PSO | RA | WEAKEST | RC11 |
|---|---|---|---|---|---|---|
| `LB-real.litmus` as packaged (r+1), symbolic | F | F | F | **F** | F | F |
| `LB-copy.litmus` (diagnostic), symbolic | F | F | F | **A** | **F** | F |
| `LB-real.litmus` as packaged, wired (values ignored) | F | F | F | A | F | F |

The same results hold in both builds; stage 9 asserts the two symbolic rows. The figure's claim holds for the copy program. The cited file does not witness it in the paper's primary (symbolic) mode.

## C-4. Published-example agreements are largely value-driven

The 31/34 agreement (Weakestmo 8/8, PwT 5/6, JMM 18/20) reproduces exactly in both builds. Its **interpretation is reduced**:
- 15 of the 34 published tests are value-unreachable as transcribed:
  - all 14 FORBIDDEN agreements on data-dependency tests (LBd ×2, OOTA, TC02, TC03, TC05, TC06, TC08, TC09, TC10, TC14, TC17, TC18, TC20);
  - TC04, a divergence the paper attributes only to control flattening.
- These FORBIDDEN verdicts hold under every model, so they do not exercise the dependency criterion.
- Fake dependencies decide only `pwt/LBfd` and `pwt/LBxor` (ALLOWED direction).
- Among the original example inputs, the only RA-ALLOWED/WEAKEST-FORBIDDEN separations (symbolic) are the 6 control examples: TC07, LBcd, LBfc, LB+ctrl, and the two `paper/LB+ctrldata+ctrl` files. The added LB-copy diagnostic also separates them.
- Parse-level collisions are wider than the paper's text-level groups: TC07 joins the control group, and TC02 parses identically to `paper/LB-real`.

The classification is in `correction-record/investigation-2026-10-18/probes/examples/example-classification.csv`.

## C-5. Earlier matched-pair sweep: value-consistency accounting

The "earlier sweep" of 1,600 rings (p. 27, L1582–1586: 1,440 valid, 1,015 discriminating) runs in **wired** mode. Its exists-clause pins every read to 1, but most ring expressions do not satisfy e(1) = 1. Only these subsets are value-consistent:
- **425 / 1,440** valid instances;
- **385 / 1,015** discriminating instances.

For the remaining instances the "required verdicts" are not program-level ground truth. The counts themselves reproduce. Table 2 (the 1,288-instance symbolic benchmark) already applies this correction and is unaffected.

## C-6. Wired versus symbolic modes

- The paper's description of wired mode (p. 8, L465–466: "rf fixed by one loader wiring, co free") is **inverted**. The code pins co to the loader's textual order and lets rf range over writes whose folded constant matches.
- Several verdict claims come from **wired** drivers, not the symbolic convention of L467:
  - the discriminator ablation (6/370);
  - the RC11 matched-pair comparison ("WEAKEST forbids only LB-real");
  - the App. A.4 witnesses;
  - the n-thread controls.
- A symbolic re-solve of the ablation gives the **same six** discriminators: `correction-record/audit-2026-10-17/experiments/ablation-symbolic/ablation-both.csv` and the investigation's `runs/ablation/`.

## C-7. Scalability n-values

The paper (p. 16, L970) states n ∈ {2,3,4,6,8,12,16}. The saved sweep (`results/carried/scalability-consistency.csv`) has **n ∈ {2,3,4,5,6,8,10,12,16}**.

## C-8. Witness- and timing-dependent outputs

- "Reruns were byte-identical" (p. 30, L1765) holds only for **deterministic** outputs.
- The chain experiment's z3-chosen witness values (`pairs-final.csv` column `witness`, and the witness lines of `traces.md`) may differ between runs. Stage 3 compares them modulo witness values and requires every real pair to carry an execution-confirmed witness.
- Timing columns (`solve_ms`, `C_ms`, `query_ms`, `*_time_ms`) never reproduce.

## C-9. What the claim checker actually covers

The Data Availability Statement (p. 33, L1910–1912) says the artifact "recomputes 31 claim figures from packaged rows". Reconfirmed by reading `reproduce/05_claims.py`:
- **26 compute** from packaged data (rows, manifests, hashes, counts): P1–P4, E1–E6, D1–D3, A1, A3, A4, H1–H4, X2–X5, C1, C2.
- **3 match recorded summaries**: A2 (regex over `final-analysis.txt`), X1 (pre-aggregated `examples-results.json` fields), A5 (string match).
- **2 check presence only**: S1 (the JSON parses and is non-empty) and I1 (the theory files exist).

No check re-runs a solver. **E1 passed on rows that contain the C-1 error.** The checker certifies agreement between the paper and the rows, not the correctness of the rows.

The corrected-v1 checker labels every check RECOMPUTE, SUMMARY or PRESENCE and SUBMITTED, FIXED-INPUT or CORRECTED. It keeps E1 (the submitted figure, flagged), and adds E1c and the other corrected-v1 checks.

## C-10. Other recorded corrections and limitations

Carried over from `ERRATA.md` and `LIMITATIONS.md`, and listed in `README.md` "Known documentation discrepancies":
- stale appendix labels;
- Table 2 file references;
- LICENSE scope;
- pinned-source comments;
- parser value-model limitations (gated out).

---

## Manuscript status

| Item | Status |
|---|---|
| `paper/submitted/TACAS27_paper__4549.pdf` | the exact submitted PDF (SHA-256 `1241dc82…c792`), unchanged |
| `paper/submitted/wev-smt.tex`, `refs.bib` | matching submitted source (`0e960997…`, `f25ce898…`). It rebuilds to a PDF with identical extracted text; the bytes differ in build metadata |
| `paper/proposed-correction-NOT-SUBMITTED/` | proposed patch, patched source, and a build stamped "PROPOSED CORRECTION — NOT SUBMITTED". The main text is length-neutral (pages 1–19 end identically); the appendix grows by one page |
| Chair notification | drafted, **not sent**; the chairs' correction procedure is **unresolved** |

Packaging this correction is **not** permission to replace the submitted paper.
