# Version map

This package (`tacas2027-4549-artifact-corrected-v1`, 2026-10-19) holds two implementations and two result sets **side by side**. Nothing of the submitted version was overwritten or re-pinned.

## Implementations

| | **SUBMITTED** build | **CORRECTED v1** build |
|---|---|---|
| Used for | every figure of the submitted manuscript (`paper/submitted/`) | the corrected figures of `CORRECTION-NOTICE.md` and `results/corrected-v1/` only |
| Source snapshot | `impl/snapshot/` (pin file `impl/PIN.txt`) | `impl-corrected-v1/snapshot/` (pin file `impl-corrected-v1/PIN.txt`) |
| Snapshot aggregate | `04d5604b133bc7d7a3b329843a7be9c6070e44f2d7e917b3b0075340f7f827e2` | `1f5d7d56f9bcb15b3c19e5c6ef080dc5d1a4785a699df27f47a97e5aa8b3a3e4` |
| Compiled classes | `impl/classes/` | `impl-corrected-v1/classes/` |
| Classes aggregate | `86f068947142ad3e44a80ca77447744858a29190703d2d8c76f22aafabd6bced` | `abf33814a8eda51107b99f05150ba3048e7cd51d82d2cd7fba5a62222f481992` |
| Relation | the evaluated, uncommitted working tree (no repository revision identifies it) | SUBMITTED + `impl-corrected-v1/CORRECTION.diff`: 2 main sources (`EventStructureEncoder`, `MinimalWitnessExtractor`) and 2 added tests. 3 of 166 class files differ |
| Unit tests | 13 files, 123 tests | 15 files, 140 tests (123 + 17 regression tests) |
| Runtime | `impl/DEPENDENCIES.txt` (jars) + `deps/NATIVES.txt` (Z3 natives); **identical for both** | same |

Toolchain for both builds: JDK 21 (javac 21.0.10, Temurin), JavaSMT 5.0.1, Z3 4.13.0 (`javasmt-solver-z3`).

## Results

| Result | SUBMITTED (as printed) | CORRECTED v1 | Where |
|---|---|---|---|
| Six-model symbolic verdicts, 2,396 files | `results/authoritative/ppo-repair/six-model/repaired-symbolic.csv` | `results/corrected-v1/six-model/corrected-symbolic.csv` | 12 cells differ (C-1) |
| Same, re-run 2026-10-19 with the submitted build | `results/corrected-v1/rerun-submitted-2026-10-19/symbolic.csv` (0 cells differ from authoritative) | — | reproduction evidence |
| Wired 847-file table | `.../repaired-wired-847.csv` | `results/corrected-v1/six-model/corrected-wired-847.csv` | identical |
| PSO / RA / WEAKEST / RC11 totals (A/F) | 1,170/1,226 · 2,089/307 · 2,356/40 · 2,169/227 | 1,173/1,223 · 2,092/304 · 2,359/37 · 2,172/224 | `CORRECTION-NOTICE.md` C-1 |
| SC / TSO totals | 36/2,360 · 563/1,833 | identical | |
| Discriminator ablation (wired) | `results/authoritative/rerun-2026-10-09/sdep/` | `results/corrected-v1/ablation/` | byte-identical CSV, 6/370 |
| Table 2 ring audit | `repair/symbolic-ring-audit.csv` | `results/corrected-v1/ring-audit/symbolic-ring-audit-corrected.csv` | byte-identical |
| Chain experiment | `chain-composition/results/` | re-classified by stage 3c | identical (modulo z3 witness values, as for the submitted build) |
| Reference-checker verdicts | — | `results/corrected-v1/reference/reference-verdicts.csv` | = corrected on 14,376/14,376 cells |
| Everything else (population, gates, address check, carried results, Isabelle) | as packaged | not affected by the encoder change | |

## Which command runs which version

Every Java stage prints an `IMPLEMENTATION:` line.

| Command | Version |
|---|---|
| `reproduce/04_impl_smoke.sh` | SUBMITTED only |
| `WEV_IMPL=submitted bash reproduce/03_chain.sh` / `WEV_IMPL=corrected …` | as named (default: submitted) |
| `python reproduce/06_repair.py <pkg> --impl submitted\|corrected [--smoke]` | as named (`--impl` is required) |
| `python reproduce/07_provenance.py <pkg> --with-java` | SUBMITTED classes; the parser is byte-identical in both builds |
| `reproduce/08_corrected_build.sh` | CORRECTED, compared with SUBMITTED |
| `reproduce/09_unit_tests.sh` | both: (a) submitted, (b) corrected, (c) the new regression tests on the submitted build |
| `python reproduce/10_results.py <pkg> [--rerun]` | both: compares the packaged result sets; `--rerun` re-runs both builds |
| `reproduce/11_reference.sh` | the reference checker vs both result sets |
| `python reproduce/05_claims.py` | part 1: SUBMITTED rows (the manuscript's 31 claims); part 2: CORRECTED rows (ids ending in `c`) |
| `reproduce/run_all.sh` | all of the above, each stage labelled |

## Earlier packages

| Package | Identifier | Status |
|---|---|---|
| 2026-10-11 | ZIP `b130b958…ec8c` | superseded by 2026-10-12 |
| 2026-10-12 (`wev-submission-refresh-20261012`) | ZIP `c75d2991315ed6f62bf6789e148fde8bc91314bd3cd59a467e6d221240f6fa5a`; `SHA256SUMS` `89f41d1f5a26325d7d0e34a0e381634a767d90f8d37295741e21b806170644a1` | this package's starting point. Every file kept here verbatim is still listed, with its hash, in `history/package-20261012/SHA256SUMS`. Modified files are preserved under `history/package-20261012/`. `CHANGES-v1.md` lists every difference |
