"""Assert the numbers the paper reports for the composed-label mode, the reference, expression
equality, mode L, the corpus, the rings and the Isabelle check, from the outputs of this run of
run_all.sh. Prints PASS/FAIL lines and exits non-zero on any failure (an uncaught error is a FAIL).
Archived data read here, each compared with fresh results: the generator's labels and metadata
(pairs-final.csv), the base artifact's recorded corpus verdicts, and the archived ring audit
(reproduced row for row by the RINGS=1 re-execution). See README "What the run establishes".

Usage: python -I check_numbers.py <OUT dir of run_all.sh> <BASE extracted artifact> [--require-rings]
"""
import csv, hashlib, os, random, re, sys, collections

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'refcheck'))
import refcheck as REF  # noqa: E402  (the reference's own expression parser, used to validate edges.csv)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import semcheck as SEM  # noqa: E402  (solver-free evaluator, shares no code with the prototype or the reference)

OUT, BASE = sys.argv[1], sys.argv[2]
REQUIRE_RINGS = len(sys.argv) > 3 and sys.argv[3] == '--require-rings'
fails = 0
RSYM_ALL = re.compile(r'(?<![A-Za-z0-9_])R[0-9]+(?![A-Za-z0-9_])')


def check(cond, msg):
    global fails
    print(('PASS  ' if cond else 'FAIL  ') + msg)
    if not cond:
        fails += 1


def _abort(et, ev, tb):
    # a missing or unreadable output must fail the run with a FAIL line, never pass silently
    import traceback
    traceback.print_exception(et, ev, tb)
    print(f'FAIL  aborted: {et.__name__}: {ev}')
    print(f'\n{fails + 1} failure(s)')
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(1)


sys.excepthook = _abort


def rows(p):
    return list(csv.DictReader(open(p, encoding='utf-8')))


def refsummary(d):
    s = {}
    for line in open(os.path.join(d, 'summary.txt'), encoding='utf-8'):
        k, v = line.rstrip('\n').split('\t'); s[k] = int(v)
    return s


# ---------------------------------------------------------------- input identity
# The base archive is identified by the hash of its own manifest; run_all.sh records that hash and the hash of
# this add-on's manifest in OUT/inputs-identity.txt before any step runs. A different base, or outputs produced
# by a different add-on version (stale OUT), fail here. This check runs FIRST, before anything reads BASE, so a
# wrong or incomplete base is reported by this check even if a later check then aborts on a missing base file
# (repair pass 2026-11-08: the fresh run fr41 showed the case "wrong base archive" aborting before this check).
PIN_BASE_MANIFEST = 'e8f43105d1ee417511466907929bfbb2667a0179fcf54adc9e2a3c7e4a77cb9d'
_sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.isfile(p) else 'missing'
_base_m = _sha(os.path.join(BASE, 'SHA256SUMS'))
_addon_m = _sha(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'SHA256SUMS'))
_idp = os.path.join(OUT, 'inputs-identity.txt')
_ident = dict(l.split(': ', 1) for l in open(_idp, encoding='utf-8').read().splitlines() if ': ' in l) if os.path.isfile(_idp) else {}
check(_base_m == PIN_BASE_MANIFEST and _ident.get('base manifest sha256') == _base_m and
      _ident.get('add-on manifest sha256') == _addon_m,
      f'input identity: base manifest {_base_m[:12]} (pinned {PIN_BASE_MANIFEST[:12]}), OUT produced from this base '
      f'and from this add-on (manifest {_addon_m[:12]})')
sys.stdout.flush()


# ---------------------------------------------------------------- strict record audits
# Every audit reads the per-record CSV files (not only the summary), and fails on a missing
# file, a wrong header, a malformed or duplicate record, a status outside the allowed set,
# an internally inconsistent record, incomplete coverage, or a count that differs from the
# expected one. The summary files are recounted from the records and must match them.
REF_PAIR_COLS = ['file', 'thread', 'load_ord', 'store_ord', 'store_loc', 'ref32', 'ref64', 'evidence32',
                 'const_corroboration', 'java_edge', 'java_composed', 'agree']
REF_FILE_COLS = ['file', 'ref_status', 'ref_reason', 'java_support', 'java_reason']
EDGE_COLS = ['file', 'read_id', 'write_id', 'write_loc', 'local_A_semantic', 'local_B_semantic', 'composed',
             'symbol_occurs', 'composed_expr']
AFF_COLS = ['file', 'thread', 'load_ord', 'store_ord', 'form', 'modeL', 'ref32', 'agree']
FILE_COLS = ['file', 'support', 'reason', 'data_edges', 'coverage_violations', 'wf', 'weakest_A', 'weakest_B',
             'weakest_C', 'weakest_ALL', 'weakest_NODEP', 'edges_fake_A', 'edges_fake_B', 'edges_fake_C']
EVENT_COLS = ['file', 'id', 'class', 'thread', 'var']


def read_table(p, cols, errs, tag):
    """Rows of a CSV whose header must equal cols; malformed rows are reported."""
    if not os.path.isfile(p):
        errs.append(f'{tag}: missing {os.path.basename(p)}'); return []
    rd = list(csv.reader(open(p, encoding='utf-8', newline='')))
    if not rd or rd[0] != cols:
        errs.append(f'{tag}: wrong header in {os.path.basename(p)}'); return []
    out = []
    for n, r in enumerate(rd[1:], 2):
        if len(r) != len(cols):
            errs.append(f'{tag}: malformed record at line {n} of {os.path.basename(p)}'); continue
        out.append(dict(zip(cols, r)))
    return out


def read_summary(p, errs, tag):
    s = {}
    if not os.path.isfile(p):
        errs.append(f'{tag}: missing {os.path.basename(p)}'); return s
    for line in open(p, encoding='utf-8'):
        parts = line.rstrip('\n').split('\t')
        if len(parts) != 2 or not parts[1].isdigit() or parts[0] in s:
            errs.append(f'{tag}: malformed summary line {line.strip()!r}'); continue
        s[parts[0]] = int(parts[1])
    return s


def modec_audit(name):
    """Strict audit of mode C's own manifest (files.csv) and data edges (edges.csv) for one input set.
    Fails on a missing file, wrong header, malformed record, duplicate file or edge record, a files.csv
    that does not cover the input list exactly once, a status/verdict outside the allowed set, an edge in
    a file mode C did not support, or a per-file edge count (data_edges, edges_fake_A/B/C) that does
    not equal the edge records. Returns (files by name, edge records, errors); later checks use only
    these validated tables, so a duplicate can never silently overwrite a record."""
    errs, tag = [], f'{name}/modeC'
    lp = f'{OUT}/lists/{name}.txt'
    lst = [l.strip() for l in open(lp, encoding='utf-8') if l.strip()] if os.path.isfile(lp) else []
    if not lst: errs.append(f'{tag}: missing or empty input list')
    if len(set(lst)) != len(lst): errs.append(f'{tag}: duplicate entry in the input list')
    fr = read_table(f'{OUT}/{name}/files.csv', FILE_COLS, errs, tag)
    files = {}
    for r in fr:
        fn = r['file']
        if fn in files: errs.append(f'{tag}: duplicate file record {fn}')
        files.setdefault(fn, r)
        if r['support'] == 'SUPPORTED':
            ok = (r['reason'] == '' and r['wf'] in ('R', 'U') and r['coverage_violations'] == '0' and
                  all(r[k] in ('A', 'F') for k in ('weakest_A', 'weakest_B', 'weakest_C', 'weakest_ALL', 'weakest_NODEP')) and
                  all(r[k].isdigit() for k in ('data_edges', 'edges_fake_A', 'edges_fake_B', 'edges_fake_C')))
        elif r['support'] == 'REJECTED':
            ok = (r['reason'] != '' and r['weakest_C'] == '' and r['edges_fake_C'] == '' and
                  r['wf'] in ('R', 'U', '') and r['coverage_violations'] in ('0', '') and
                  all(r[k] in ('A', 'F', '') for k in ('weakest_A', 'weakest_B', 'weakest_ALL', 'weakest_NODEP')))
        else:
            ok = False
        if not ok: errs.append(f'{tag}: malformed or inconsistent file record {fn} ({r["support"]})')
    if set(files) != set(lst) or len(fr) != len(lst):
        errs.append(f'{tag}: {len(fr)} file records ({len(files)} distinct) do not cover the {len(lst)} listed inputs exactly once')
    ev = read_table(f'{OUT}/{name}/events.csv', EVENT_COLS, errs, tag)
    evk, evcls = set(), {}
    for r in ev:
        k = (r['file'], r['id'])
        if k in evk: errs.append(f'{tag}: duplicate event record {k}')
        evk.add(k); evcls[k] = r['class']
    evfiles = {r['file'] for r in ev}
    for fn, r in files.items():
        if r['support'] == 'SUPPORTED' and fn not in evfiles:
            errs.append(f'{tag}: supported file {fn} has no event records')
    er = read_table(f'{OUT}/{name}/edges.csv', EDGE_COLS, errs, tag)
    keys, per = set(), collections.defaultdict(list)
    for r in er:
        k = (r['file'], r['read_id'], r['write_id'])
        if k in keys: errs.append(f'{tag}: duplicate edge record {k}')
        keys.add(k); per[r['file']].append(r)
        if files.get(r['file'], {}).get('support') != 'SUPPORTED':
            errs.append(f'{tag}: edge in a file mode C did not support {k}')
        if not (r['read_id'].isdigit() and r['write_id'].isdigit() and r['local_A_semantic'] in ('true', 'false')
                and r['local_B_semantic'] in ('true', 'false') and r['composed'] in ('CONST', 'VARIES')
                and r['symbol_occurs'] in ('true', 'false')):
            errs.append(f'{tag}: malformed edge record {k}'); continue
        if evcls.get((r['file'], r['read_id'])) != 'ReadEvent' or evcls.get((r['file'], r['write_id'])) != 'WriteEvent':
            errs.append(f'{tag}: edge endpoints are not a read and a write event of the file {k}')
        # composed_expr must parse with the reference's parser, mention only this file's load symbols R<read id>,
        # and symbol_occurs must say whether the edge's own load symbol occurs in it
        try:
            vs = set(); stack = [REF.parse_expr(r['composed_expr'])]
            while stack:
                e = stack.pop()
                if e[0] == 'var': vs.add(e[1])
                stack.extend(x for x in e[1:] if isinstance(x, tuple))
            okv = all(v[:1] == 'R' and evcls.get((r['file'], v[1:])) == 'ReadEvent' for v in vs)
            if not okv or (('R' + r['read_id']) in vs) != (r['symbol_occurs'] == 'true'):
                errs.append(f'{tag}: composed_expr/symbol_occurs inconsistent with the event table at {k}')
        except Exception:
            errs.append(f'{tag}: composed_expr does not parse at {k}')
    for fn, r in files.items():
        if r['support'] != 'SUPPORTED': continue
        es = per.get(fn, [])
        want = (str(len(es)), str(sum(e['local_A_semantic'] == 'false' for e in es)),
                str(sum(e['local_B_semantic'] == 'false' for e in es)), str(sum(e['composed'] == 'CONST' for e in es)))
        if (r['data_edges'], r['edges_fake_A'], r['edges_fake_B'], r['edges_fake_C']) != want:
            errs.append(f'{tag}: per-file edge counts of {fn} do not match its edge records')
    return files, er, errs


def edge_pair_keys(name, errs, tag):
    """Map each mode C edge (file, read_id, write_id) to the reference's (file, thread, load_ord, store_ord),
    exactly as refcheck.py joins them: per-thread ordinal of the access among that thread's events."""
    ev = read_table(f'{OUT}/{name}/events.csv', EVENT_COLS, errs, tag)
    by, pos = collections.defaultdict(list), {}
    for r in ev:
        if r['thread'] == '0' or r['class'] not in ('ReadEvent', 'WriteEvent'): continue
        if not (r['id'].isdigit() and r['thread'].isdigit()):
            errs.append(f'{tag}: malformed event record {r["file"]} {r["id"]}'); continue
        by[(r['file'], int(r['thread']))].append(int(r['id']))
    for (f_, t), ids in by.items():
        if len(set(ids)) != len(ids): errs.append(f'{tag}: duplicate event id in {f_}')
        for k, i in enumerate(sorted(set(ids))): pos[(f_, i)] = (t, k)
    return pos


def ref_audit(name, exp_files, exp_pairs, exp_width):
    """Reference vs mode C on one input set. exp_files: {(ref_status, java_support): n};
    exp_pairs: {ref32: n}, every pair AGREE; exp_width: number of 32/64-bit width-sensitive pairs."""
    errs, tag = [], f'{name}/ref'
    lp = f'{OUT}/lists/{name}.txt'
    lst = [l.strip() for l in open(lp, encoding='utf-8') if l.strip()] if os.path.isfile(lp) else []
    if not lst: errs.append(f'{tag}: missing or empty input list')
    fr = read_table(f'{OUT}/{name}/ref/ref-files.csv', REF_FILE_COLS, errs, tag)
    pr = read_table(f'{OUT}/{name}/ref/ref-pairs.csv', REF_PAIR_COLS, errs, tag)
    files = {}
    for r in fr:
        if r['file'] in files: errs.append(f'{tag}: duplicate file record {r["file"]}')
        if r['ref_status'] not in ('SUPPORTED', 'REJECTED') or r['java_support'] not in ('SUPPORTED', 'REJECTED'):
            errs.append(f'{tag}: unexpected file status {r["file"]} {r["ref_status"]}/{r["java_support"]}')
        files[r['file']] = r
    if set(files) != set(lst) or len(fr) != len(lst):
        errs.append(f'{tag}: {len(fr)} file records do not cover the {len(lst)} listed inputs exactly once')
    fc = collections.Counter((r['ref_status'], r['java_support']) for r in fr)
    if fc != collections.Counter(exp_files): errs.append(f'{tag}: file statuses {dict(fc)}, expected {exp_files}')
    both = {f for f, r in files.items() if r['ref_status'] == 'SUPPORTED' and r['java_support'] == 'SUPPORTED'}
    keys, agree, width = set(), collections.Counter(), 0
    for r in pr:
        k = (r['file'], r['thread'], r['load_ord'], r['store_ord'])
        if k in keys: errs.append(f'{tag}: duplicate pair record {k}')
        keys.add(k)
        if r['agree'] != 'AGREE':
            errs.append(f'{tag}: pair status {r["agree"]} at {k}'); continue
        if r['file'] not in both: errs.append(f'{tag}: pair in a file not supported by both tools {k}')
        if r['ref32'] not in ('CONST', 'VARIES') or r['ref64'] not in ('CONST', 'VARIES') \
                or r['java_edge'] != 'yes' or r['java_composed'] != r['ref32']:
            errs.append(f'{tag}: inconsistent AGREE record {k}'); continue
        # the evidence each verdict claims: CONST = Z3 unsat + 8-bit exhaustive + 32-bit random corroboration;
        # VARIES = a concrete witness (two load values), re-evaluated without the solver by refcheck.py
        if (r['ref32'] == 'CONST' and (r['evidence32'] != 'z3-unsat' or
                                       r['const_corroboration'] != 'w8-exhaustive-const;w32-random-20k-const')) or \
           (r['ref32'] == 'VARIES' and (not r['evidence32'].startswith('witness ') or r['const_corroboration'] != '')):
            errs.append(f'{tag}: evidence columns do not support the verdict at {k}')
        agree[r['ref32']] += 1
        width += r['ref32'] != r['ref64']
    if agree != collections.Counter(exp_pairs): errs.append(f'{tag}: AGREE pairs {dict(agree)}, expected {exp_pairs}')
    if width != exp_width: errs.append(f'{tag}: {width} width-sensitive pairs, expected {exp_width}')
    # the reference's copy of mode C's support status must equal mode C's own manifest
    mfiles, je, _ = MC[name]
    for fn, r in files.items():
        if fn in mfiles and r['java_support'] != mfiles[fn]['support']:
            errs.append(f'{tag}: java_support of {fn} differs from mode C files.csv')
    # every mode C data edge in a file that both tools support must be one of the agreeing pairs, and
    # its composed verdict, re-read from mode C's own edges.csv (not the reference's copy), must equal
    # the reference's verdict; joined independently of refcheck.py's own join
    nje = sum(1 for r in je if r['file'] in both)
    if nje != len(pr):
        errs.append(f'{tag}: {nje} mode C edges in jointly supported files vs {len(pr)} pair records (unmatched edges)')
    pos = edge_pair_keys(name, errs, tag)
    pmap = {(r['file'], r['thread'], r['load_ord'], r['store_ord']): r for r in pr}
    joined = set()
    for r in je:
        if r['file'] not in both: continue
        rt = pos.get((r['file'], int(r['read_id']))) if r['read_id'].isdigit() else None
        wt = pos.get((r['file'], int(r['write_id']))) if r['write_id'].isdigit() else None
        if not rt or not wt or rt[0] != wt[0]:
            errs.append(f'{tag}: mode C edge {r["file"]} {r["read_id"]}->{r["write_id"]} has no thread-local position'); continue
        k = (r['file'], str(rt[0]), str(rt[1]), str(wt[1]))
        p = pmap.get(k)
        if p is None:
            errs.append(f'{tag}: mode C edge {k} has no reference pair (unmatched edge)'); continue
        if k in joined: errs.append(f'{tag}: two mode C edges join the same reference pair {k}')
        joined.add(k)
        if r['composed'] != p['ref32'] or r['composed'] != p['java_composed']:
            errs.append(f'{tag}: mode C edges.csv says {r["composed"]}, reference {p["ref32"]} at {k} (disagreement)')
    if joined != set(pmap): errs.append(f'{tag}: {len(set(pmap) - joined)} reference pairs not joined to a mode C edge')
    # the summary is recounted from the records and must equal them
    s = read_summary(f'{OUT}/{name}/ref/summary.txt', errs, tag)
    rc = collections.Counter()
    for (a, b), n in fc.items(): rc[str(('file', 'REF_' + a, b))] = n
    for r in pr:
        rc[str(('pair', r['agree'], r['java_composed'] if r['agree'] == 'JAVA_ONLY' else r['ref32']))] += 1
        if r['agree'] != 'JAVA_ONLY' and r['ref32'] != r['ref64']: rc[str(('width-sensitive', r['ref32'], r['ref64']))] += 1
    if s != dict(rc): errs.append(f'{tag}: summary.txt does not match the records')
    return errs


def affine_audit(name, exp, exp_rejected):
    """Mode L vs the reference. exp: {(form, ref32, agree): n} with agree in {AGREE, ABSTAIN};
    exp_rejected: the exact set of files mode L rejects."""
    errs, tag = [], f'{name}/affine'
    ar = read_table(f'{OUT}/{name}/affine/affine-pairs.csv', AFF_COLS, errs, tag)
    refk = {(r['file'], r['thread'], r['load_ord'], r['store_ord']): r['ref32']
            for r in read_table(f'{OUT}/{name}/ref/ref-pairs.csv', REF_PAIR_COLS, errs, tag) if r['ref32']}
    keys, cnt, rej = set(), collections.Counter(), set()
    for r in ar:
        if r['modeL'].startswith('REJECTED:'):
            if r['file'] in rej: errs.append(f'{tag}: duplicate rejection {r["file"]}')
            rej.add(r['file']); continue
        k = (r['file'], r['thread'], r['load_ord'], r['store_ord'])
        if k in keys: errs.append(f'{tag}: duplicate pair record {k}')
        keys.add(k)
        form = 'chain' if '-chain' in r['file'] else ('direct' if '-direct' in r['file'] else 'check')
        ok = (r['form'] == form and refk.get(k) == r['ref32'] and
              ((r['agree'] == 'AGREE' and r['modeL'] == r['ref32']) or (r['agree'] == 'ABSTAIN' and r['modeL'] == 'ABSTAIN')))
        if not ok:
            errs.append(f'{tag}: pair status {r["agree"]} or inconsistent record at {k}'); continue
        cnt[(r['form'], r['ref32'], r['agree'])] += 1
    if keys != set(refk):
        errs.append(f'{tag}: covers {len(keys & set(refk))} of the {len(refk)} reference pairs, {len(keys - set(refk))} extra')
    if cnt != collections.Counter(exp): errs.append(f'{tag}: counts {dict(cnt)}, expected {exp}')
    if rej != set(exp_rejected): errs.append(f'{tag}: rejected files {sorted(rej)}, expected {sorted(exp_rejected)}')
    s = read_summary(f'{OUT}/{name}/affine/affine-summary.txt', errs, tag)
    rc = collections.Counter()
    for r in ar:
        rc[str(('file', 'REJECTED')) if r['modeL'].startswith('REJECTED:') else str(('pair', r['form'], r['ref32'], r['agree']))] += 1
    lp = f'{OUT}/lists/{name}.txt'
    nlist = sum(1 for l in open(lp, encoding='utf-8') if l.strip()) if os.path.isfile(lp) else -1
    rc[str(('file', 'READ'))] = nlist - len(rej)
    if s != dict(rc): errs.append(f'{tag}: affine-summary.txt does not match the records and the input list')
    return errs, cnt


def audit_check(errs, msg):
    for e in errs[:8]: print('      ' + e)
    check(not errs, msg)


# ---------------------------------------------------------------- mode C manifests (all input sets)
MC = {}
for _n, _N in (('diag', 21), ('regress', 3), ('chain', 256), ('corpus', 2396)):
    MC[_n] = modec_audit(_n)
    audit_check(MC[_n][2], f'mode C manifest, {_n}: one well-formed files.csv record for each of the {_N} listed inputs, '
                           f'no duplicate or malformed file/edge record, edges only in supported files, per-file edge counts match')

# ---------------------------------------------------------------- corpus accounting (raw and de-duplicated)
# corpus_accounting.py writes the raw, byte-distinct and normalised counts; they are asserted here and the key
# ones are recomputed independently from the validated files.csv and the base's litmus files.
_ap = f'{OUT}/corpus/accounting/accounting.txt'
ACC = dict(l.rsplit(': ', 1) for l in open(_ap, encoding='utf-8').read().splitlines() if ': ' in l) if os.path.isfile(_ap) else {}
ACC_WANT = {
    'analysed files (raw)': '2380', 'analysed files (byte-distinct)': '2340', 'analysed files (normalised-distinct)': '2338',
    'mode C supported (raw)': '2250', 'mode C supported (byte-distinct)': '2210', 'mode C supported (normalised-distinct)': '2208',
    'supported files with >=1 data edge (raw)': '245', 'supported files with >=1 data edge (byte-distinct)': '245',
    'supported files without data edges (raw)': '2005', 'data edges in supported files': '326',
    'data edges: composed CONST (fake)': '322', 'data edges: composed VARIES (real)': '4',
    'distinct shapes of fake composed expressions': '1', 'fake shape (((R)^(R))+1)': '322', 'edges where A, B and C disagree': '0',
    'weakest_B on analysed files: A/F/none': '2345/33/2', 'weakest_B on byte-distinct analysed files: A/F': '2307/31',
    'weakest_ALL on analysed files: A/F/none': '2339/39/2',
    'changed verdicts: A vs B (folding vs exact oracle) (raw files)': '0',
    'changed verdicts: B vs C (closure vs composed labels; C-supported only) (raw files)': '0',
    'changed verdicts: B vs ALL (semantic vs every syntactic dependency) (raw files)': '6',
    'changed verdicts: B vs ALL (semantic vs every syntactic dependency) (byte-distinct)': '6',
    'changed verdicts: NODEP vs B (no dependency axiom vs SDEP) (raw files)': '0',
    'byte-identical duplicate groups': '38', 'byte-identical extra copies': '40',
    'byte-identical groups spanning herd7 and Dat3M': '15', 'normalised-identical extra copies': '42'}
_cf = {k: v for k, v in MC['corpus'][0].items() if v['reason'] != 'VMSA_PAGE_TABLE'}
_cs = [v for v in _cf.values() if v['support'] == 'SUPPORTED']
_hh = {f: hashlib.sha256(open(os.path.join(BASE, 'corpus', 'litmus', f), 'rb').read()).hexdigest() for f in _cf}
_chg = sorted(f for f, v in _cf.items() if v['weakest_B'] and v['weakest_ALL'] and v['weakest_B'] != v['weakest_ALL'])
_recomp = (str(len(_cf)), str(len(set(_hh.values()))), str(len({_hh[v['file']] for v in _cs})),
           str(sum(int(v['data_edges']) > 0 for v in _cs)), str(len(_chg)), str(sum(1 for f in _chg if _cf[f]['support'] == 'SUPPORTED')))
_bad = [k for k, v in ACC_WANT.items() if ACC.get(k) != v]
for k in _bad[:6]: print(f'      accounting {k}: {ACC.get(k)!r}, expected {ACC_WANT[k]!r}')
check(not _bad and _recomp == ('2380', '2340', '2210', '245', '6', '5'),
      f'corpus accounting: raw/byte-distinct analysed {_recomp[0]}/{_recomp[1]}, supported distinct {_recomp[2]}, '
      f'{_recomp[3]} supported files with data edges, 1 fake shape on all 322 fakes, {_recomp[4]} files change under '
      f'all-syntactic dependencies ({_recomp[5]} of them mode-C supported), 40 byte-identical extra copies')

# ---------------------------------------------------------------- semantic re-decision of every recorded verdict
# Hash and record-format checks cannot show that a recorded verdict fits its recorded expression. Each edge's
# composed verdict is therefore re-decided twice from its composed_expr: (1) by the reference's decision procedure
# (refcheck.decide: witness search, then Z3 over the reference's own encoding; the solver is shared with the
# prototype), and (2) by semcheck.py, which uses no solver: a VARIES verdict needs a concrete 32-bit witness, and a
# CONST verdict fails on any 32-bit or lifted width-8 variation and is proved only where exact rewriting removes the
# load symbol. Both must agree with the record.
def _to_ref(e):
    if e[0] == 'var': return ('sym', e[1])
    if e[0] == 'un': return ('un', e[1], _to_ref(e[2]))
    if e[0] == 'bin': return ('bin', e[1], _to_ref(e[2]), _to_ref(e[3]))
    return e


SEMSTAT = {}
for _n in ('diag', 'regress', 'chain', 'corpus'):
    _errs, _st = [], collections.Counter()
    for r in MC[_n][1]:
        k = (r['file'], r['read_id'], r['write_id'])
        try:
            ok, evd = SEM.check_edge(r['composed_expr'], 'R' + r['read_id'], r['composed'])
            rv, _ = REF.decide(_to_ref(REF.parse_expr(r['composed_expr'])), 'R' + r['read_id'], 32, random.Random(7))
        except Exception as ex:  # unparsable or unexpected: a failure, never a skip
            _errs.append(f'{_n}: semantic re-decision raised {type(ex).__name__} at {k}'); continue
        if not ok: _errs.append(f'{_n}: solver-free validator rejects {r["composed"]} for {r["composed_expr"]} at {k}: {evd}')
        if rv != r['composed']: _errs.append(f'{_n}: reference decision {rv} differs from recorded {r["composed"]} at {k}')
        _st[(r['composed'], 'proved' if evd == 'proved-by-normalisation' else 'corroborated' if evd.startswith('corroborated') else 'witness')] += 1
    SEMSTAT[_n] = _st
    audit_check(_errs, f'semantic re-decision, {_n}: all {len(MC[_n][1])} recorded composed verdicts re-decided from their '
                       f'expressions (reference decision procedure and solver-free validator agree with the record; '
                       f'CONST proved without a solver {_st[("CONST", "proved")]}, corroborated only {_st[("CONST", "corroborated")]}; '
                       f'VARIES with a concrete witness {_st[("VARIES", "witness")]})')

# ---------------------------------------------------------------- diagnostics
f = MC['diag'][0]
check(f['LB-chain-cancel.litmus']['weakest_B'] == 'F' and f['LB-chain-cancel.litmus']['weakest_C'] == 'A',
      'LB-chain-cancel: closure (B) forbids, composed labels (C) admit')
for n in ('LB-copy', 'LB-chain-double'):
    r = f[n + '.litmus']
    check((r['weakest_A'], r['weakest_B'], r['weakest_C'], r['weakest_NODEP']) == ('F', 'F', 'F', 'A'),
          f'{n}: F/F/F with no-dependency base allowing -> source (D)')
for n in ('LB-fake-xor-cycle', 'LBfd', 'LB-direct-cancel'):
    r = f[n + '.litmus']
    check((r['weakest_A'], r['weakest_B'], r['weakest_C']) == ('A', 'A', 'A'), f'{n}: A/A/A')
check(f['LB-real.litmus']['wf'] == 'U', 'LB-real: well-formedness alone unsatisfiable (W)')
rej = {k: r['reason'] for k, r in f.items() if r['support'] == 'REJECTED'}
check(rej == {'U-reject-branch.litmus': 'CTRL_DEP', 'U-reject-rmw.litmus': 'RMW', 'U-reject-shift.litmus': 'ENCODING_GAP'},
      f'diagnostics: exactly 3 rejections with stated reasons {rej}')
audit_check(ref_audit('diag', {('SUPPORTED', 'SUPPORTED'): 18, ('REJECTED', 'REJECTED'): 3},
                      {'CONST': 15, 'VARIES': 23}, 1),
            'diagnostics: reference agrees with mode C on all 38 pairs (15 constant, 23 varying), every mode C edge matched, '
            'no other status; it rejects the same 3 files; exactly one width-sensitive pair (r*65536*65536)')
check(all(r['coverage_violations'] in ('0', '') for r in f.values()), 'diagnostics: no coverage violation')

# ---------------------------------------------------------------- chain population
cf = list(MC['chain'][0].values())
check(len(cf) == 256 and all(r['support'] == 'SUPPORTED' for r in cf), 'chain: 256/256 files supported by mode C')
check(all(r['coverage_violations'] == '0' for r in cf), 'chain: no coverage violation')
audit_check(ref_audit('chain', {('SUPPORTED', 'SUPPORTED'): 256}, {'CONST': 143, 'VARIES': 171}, 0),
            'chain: reference agrees with mode C on 314 pairs (143 constant, 171 varying), every mode C edge matched, '
            'no other status, none width-sensitive')
pf = rows(os.path.join(BASE, 'chain-composition/results/pairs-final.csv'))
arch = collections.defaultdict(list)
for r in pf: arch[r['id'] + '.litmus'].append(r)
fe = collections.defaultdict(list)
for r in MC['chain'][1]: fe[r['file']].append(r)
table = collections.Counter(); joined = 0; noedge = 0
for fn, ar in arch.items():
    ar = sorted(ar, key=lambda r: int(r['k']))
    fr = sorted(fe.get(fn, []), key=lambda r: (int(r['write_id']), int(r['read_id'])))
    if len(fr) != len(ar):
        # pairs without a syntactic edge (overwritten / reloaded load): fake in every mode
        kept = {(r['read_loc'] if 'read_loc' in r else None) for r in fr}
        noedge += len(ar) - len(fr)
        # Table 2 lists pairs without a syntactic edge in their own row ("no syntactic edge, check cases"):
        # no mode classifies them, so they are counted only there (n), never as a mode's fake verdict.
        for a in ar:
            if a['expected'] == 'FAKE' and not fr:
                table[('noedge', 'n')] += 1; table[('noedge', 'variant-' + a['variant'])] += 1
        if fr:  # CTRL-RELOAD: first load killed (no edge), second has the edge
            assert len(fr) == 1 and len(ar) == 2
            for a in ar:
                if a['expected'] == 'FAKE':
                    table[('noedge', 'n')] += 1; table[('noedge', 'variant-' + a['variant'])] += 1
                else:
                    cat = 'real'
                    table[(cat, 'n')] += 1
                    b = fr[0]
                    table[(cat, 'A')] += b['local_A_semantic'] == 'false'
                    table[(cat, 'B')] += b['local_B_semantic'] == 'false'
                    table[(cat, 'C')] += b['composed'] == 'CONST'
        continue
    for a, b in zip(ar, fr):
        joined += 1
        cat = 'real' if a['expected'] == 'REAL' else 'fake-' + a['variant']
        table[(cat, 'n')] += 1
        table[(cat, 'A')] += b['local_A_semantic'] == 'false'
        table[(cat, 'B')] += b['local_B_semantic'] == 'false'
        table[(cat, 'C')] += b['composed'] == 'CONST'
        check_ok = (b['composed'] == 'CONST') == (a['expected'] == 'FAKE')
        if not check_ok: print('  mismatch', fn, a['k'])
        table['C_vs_expected_ok'] += check_ok
exp = {'real': (171, 0, 0, 0), 'fake-direct': (66, 30, 66, 66), 'fake-chain': (72, 0, 0, 72), 'fake-control': (5, 4, 4, 5)}
for cat, v in exp.items():
    got = tuple(table[(cat, k)] for k in ('n', 'A', 'B', 'C'))
    check(got == v, f'Table 2 row {cat}: (edges,A,B,C) = {got}, paper {v}')
check(table['C_vs_expected_ok'] == joined == 313, f'chain: fresh mode C equals generator classification on {joined} joined pairs')
check(noedge == 3 and table[('noedge', 'n')] == 3 and table[('noedge', 'variant-control')] == 3,
      f'chain: {noedge} archived pairs carry no syntactic edge, all generator-fake check cases '
      f'(Table 2 row "no syntactic edge, check cases": 3, no mode verdict)')
# Structure recomputed from the .litmus text (recount_chain.py) and labels from the fresh reference
# verdicts: a pair is fake iff the reference finds the store's value constant in the load (CONST),
# real iff VARIES; a pair with no reference record has no occurrence of the load's symbol in the
# stored expression (no syntactic dependency), hence is fake.
rcn = rows(f'{OUT}/chain/recount.csv')
refl = {(r['file'][:-len('.litmus')], r['load_ord'], r['store_ord']): r['ref32']
        for r in rows(f'{OUT}/chain/ref/ref-pairs.csv') if r['agree'] == 'AGREE'}
fresh = {}
for r in rcn:
    v = refl.get((r['id'], r['load_ord'], r['store_ord']))
    fresh[(r['id'], r['k'])] = 'FAKE' if v in (None, 'CONST') else 'REAL'
used = {(r['id'], r['load_ord'], r['store_ord']) for r in rcn}
check(len(rcn) == 317 and len(fresh) == 317 and set(refl) <= used and sum(v is None for v in
      (refl.get((r['id'], r['load_ord'], r['store_ord'])) for r in rcn)) == 3,
      'chain (recomputed from inputs): 317 load-store pairs; every reference pair maps to one; 3 have no reference record')
ff = [r for r in rcn if fresh[(r['id'], r['k'])] == 'FAKE']
check(len({r['shape'] for r in ff if r['variant'] == 'direct'}) == 41 and
      len({r['shape'] for r in ff if r['variant'] == 'chain'}) == 52 and
      max(int(r['assignments']) for r in ff if r['variant'] == 'chain') == 9,
      'chain (recomputed from inputs + fresh reference labels): 41/52 distinct fake shapes, chains up to 9 assignments')
inj = collections.Counter(r['template'][:7] for r in rcn if fresh[(r['id'], r['k'])] == 'REAL' and r['template'].startswith('INJ'))
check(inj == {'INJ-MIX': 48, 'INJ-2IN': 32},
      f'chain (recomputed from inputs + fresh reference labels): injective real pairs {dict(inj)} (48 single-register + 32 two-input)')
pfk = {(r['id'], r['k']): r for r in pf}
meta_ok = set(pfk) == set(fresh) and all(
    (pfk[(r['id'], r['k'])]['variant'] if pfk[(r['id'], r['k'])]['variant'] != 'control' else 'control',
     pfk[(r['id'], r['k'])]['template'], pfk[(r['id'], r['k'])]['assignments'], pfk[(r['id'], r['k'])]['norm_shape'],
     pfk[(r['id'], r['k'])]['expected']) ==
    (r['variant'], r['template'], r['assignments'], r['shape'], fresh[(r['id'], r['k'])]) for r in rcn)
check(meta_ok, 'chain: archived generator metadata (pairs-final.csv: variant, template, assignments, norm_shape, expected) '
               'equals the values recomputed above on all 317 pairs')

# ---------------------------------------------------------------- corpus
co = list(MC['corpus'][0].values())
vm = {r['file'] for r in co if 'aarch64-VMSA' in r['file']}
c2 = [r for r in co if r['file'] not in vm]
check(len(co) == 2396 and len(vm) == 16 and len(c2) == 2380, 'corpus: 2,396 eligible, 16 VMSA excluded, 2,380 remain')
reasons = collections.Counter((r['support'], r['reason']) for r in c2)
check(reasons == {('SUPPORTED', ''): 2250, ('REJECTED', 'ADDR_DEP'): 128, ('REJECTED', 'NO_EVENTS'): 2},
      f'corpus: mode C support manifest {dict(reasons)}')
sup = [r for r in c2 if r['support'] == 'SUPPORTED']
check(all(r['weakest_B'] == r['weakest_C'] for r in sup), 'corpus: composed labels change no verdict')
ce = [r for r in MC['corpus'][1] if r['file'] not in vm]
kinds = collections.Counter((r['local_A_semantic'], r['local_B_semantic'], r['composed']) for r in ce)
check(len(ce) == 326 and kinds == {('false', 'false', 'CONST'): 322, ('true', 'true', 'VARIES'): 4},
      f'corpus: 326 data edges, 322 fake / 4 real, A=B=C on every edge {dict(kinds)}')
check(all(r['coverage_violations'] in ('0', '') for r in co), 'corpus: no coverage violation')
wk = collections.Counter(r['weakest_B'] for r in c2 if r['weakest_B'])
src = collections.Counter()
for r in c2:
    if r['weakest_B'] != 'F': continue
    src['W' if r['wf'] == 'U' else ('B' if r['weakest_NODEP'] == 'F' else 'D')] += 1
w_files = sorted(os.path.basename(r['file']) for r in c2 if r['weakest_B'] == 'F' and r['wf'] == 'U')
noev = [r['file'] for r in c2 if r['reason'] == 'NO_EVENTS']
symv = {}
for r in rows(os.path.join(BASE, 'results/corrected-v1/six-model/corrected-symbolic.csv')):
    if r['model'] == 'WEAKEST': symv[r['file']] = r['verdict']
check(wk['A'] == 2345 and len(noev) == 2 and all(symv[x] == 'ALLOWED' for x in noev),
      f'corpus: SDEP allows 2,345 encodable files; 2 files produce no events (recorded ALLOWED)')
mism = [r['file'] for r in co if r['weakest_B'] and {'A': 'ALLOWED', 'F': 'FORBIDDEN'}[r['weakest_B']] != symv[r['file']]]
nenc = sum(1 for r in co if r['weakest_B'])
check(not mism and nenc == 2394, f'corpus: fresh SDEP verdicts equal the recorded symbolic verdicts on all {nenc} encodable files (paper: 2,394)')
check(wk['F'] == 33 and src == {'B': 31, 'W': 2}, f'corpus: SDEP forbids 33 = {dict(src)}; (W) files {w_files}')
disc = [r['file'] for r in c2 if r['weakest_ALL'] == 'F' and r['weakest_B'] == 'A']
check(len(disc) == 6, f'corpus: 6 discriminators {[os.path.basename(d) for d in disc]}')

# ---------------------------------------------------------------- rings
rc = rows(f'{OUT}/rings/ring-classes.csv')
cls = collections.Counter((r['e0'], r['e1'] == '1', r['nonconst']) for r in rc)
check(len(rc) == 1828 and cls == {('1', False, 'True'): 1184, ('1', True, 'False'): 534, ('1', True, 'True'): 110},
      f'rings: 1,828 expressions = 1,184 (W) / 534 constant / 110 non-constant with e(1)=1')
au = rows(os.path.join(BASE, 'repair/symbolic-ring-audit.csv'))
by = collections.defaultdict(dict)
for r in au: by[r['expr']][r['threads']] = r
# per expression, not only per count: the reference's classes (ring-classes.csv, recomputed by
# classify_rings.py with the reference evaluator) must cover every archived expression exactly once
# and agree with the archived audit on that expression (constancy and value-consistency)
rexp = [r['expr'] for r in rc]
ring_err = []
if len(rexp) != len(set(rexp)): ring_err.append('duplicate expression in ring-classes.csv')
if set(rexp) != set(by) or any(set(d) != {'2', '3'} for d in by.values()):
    ring_err.append('ring-classes.csv does not cover the archived audit expressions (n=2,3) exactly')
for r in rc:
    d = by.get(r['expr'], {}).get('2')
    if d is None or r['e0'] != '1' or r['nonconst'] not in ('True', 'False') or \
            (r['nonconst'] == 'True') != (d['oracle_constant'] == 'false') or \
            (r['e1'] == '1') != (d['value_consistency'] == 'SAT'):
        ring_err.append(f'reference class of {r["expr"]!r} disagrees with the archived audit')
audit_check(ring_err, 'rings: one reference classification per archived expression (1,828), each agreeing with the archived '
                      'audit on constancy and value-consistency')
check(all(by[e]['2'][k] == by[e]['3'][k] for e in by for k in ('value_consistency', 'weakest', 'folding', 'syntactic')),
      'rings: verdicts identical at n=2 and n=3 for every expression')
fold_fp = sum(1 for e, d in by.items() if d['2']['oracle_constant'] == 'true' and d['2']['value_consistency'] == 'SAT' and d['2']['folding'] == 'FORBIDDEN')
check(fold_fp == 385, f'rings: folding forbids {fold_fp} of the 534 constant expressions')
r110 = [e for e, d in by.items() if d['2']['oracle_constant'] == 'false' and d['2']['value_consistency'] == 'SAT']
check(len(r110) == 110 and all(by[e]['2']['weakest'] == 'FORBIDDEN' for e in r110), 'rings: SDEP forbids all 110 reachable non-constant expressions')
rl = os.path.join(OUT, 'rings', 'run-06-corrected.log')
if REQUIRE_RINGS or os.path.exists(rl):
    check(os.path.exists(rl) and 'PASS  3656 symbolic ring rows match' in open(rl, encoding='utf-8').read(),
          'rings: full 3,656-ring audit re-executed and matches (required with RINGS=1; missing log = FAIL)')
else:
    print('SKIP  full ring audit not run (set RINGS=1)')
w1184 = [r['expr'] for r in rc if r['e1'] != '1']
check(all(by[e]['2']['value_consistency'] == 'UNSAT' for e in w1184) and len(rc) - len(w1184) == 644,
      'rings: the 1,184 are value-inconsistent (W); 644 value-consistent = 534 + 110')

# ---------------------------------------------------------------- remaining printed numbers
# populations and inputs
check(len(rcn) == 317 and len({r['id'] for r in rcn}) == 256 and len({r['id'] for r in rcn if r['variant'] == 'control'}) == 14,
      'chain (recomputed from inputs): 256 files, 317 load-store pairs, 14 check-case files')
dnames = list(f)
check(len(dnames) == 21 and sum(n.startswith('LB') for n in dnames) == 7 and sum(n.startswith('U-') for n in dnames) == 14,
      'diagnostics: 21 inputs = 7 LB programs + 14 unit cases')
# Table 3 columns from the six-model probe (exact-oracle line B; folding line A must agree)
probe, probe_err = {}, []
cur = None
for line in open(f'{OUT}/probe-six-models.txt', encoding='utf-8'):
    if line.endswith('.litmus\n'):
        cur = line.strip()
        if cur in probe: probe_err.append(f'duplicate probe block {cur}')
        probe.setdefault(cur, {})
    elif cur and line.strip().startswith(('A (', 'B (')):
        kv = dict(t.split('=') for t in line.split('|')[0].split()[2:] if '=' in t)
        if line.strip()[0] in probe[cur]: probe_err.append(f'duplicate {line.strip()[0]} line in probe block {cur}')
        probe[cur][line.strip()[0]] = kv
want_blocks = {n + '.litmus' for n in ('LB-copy', 'LB-chain-double', 'LB-fake-xor-cycle', 'LBfd', 'LB-direct-cancel',
                                       'LB-chain-cancel', 'LB-real')}
if set(probe) != want_blocks or any(set(v) != {'A', 'B'} for v in probe.values()):
    probe_err.append(f'probe blocks {sorted(probe)} are not exactly the 7 LB programs with one A and one B line each')
audit_check(probe_err, 'six-model probe: exactly one block per LB program, one A and one B line each')
t4 = {'LB-copy': ('reachable', 'A', 'F', 'F'), 'LB-chain-double': ('reachable', 'A', 'F', 'F'),
      'LB-fake-xor-cycle': ('reachable', 'A', 'F', 'A'), 'LBfd': ('reachable', 'A', 'F', 'A'),
      'LB-chain-cancel': ('reachable', 'A', 'F', 'F'), 'LB-real': ('UNREACHABLE', 'F', 'F', 'F')}
# Table 3 also lists, per mode A/B/C, the data edges kept in sdep (of 2) and the cause of each F verdict:
# (W) well-formedness alone unsatisfiable; (D) the same model without the dependency axiom (NODEP) admits;
# (B) otherwise. Both are read from mode C's fresh diag/files.csv, and the A/B verdicts must equal the probe's.
t3x = {'LB-copy': ('222', 'FFF', 'DDD'), 'LB-chain-double': ('222', 'FFF', 'DDD'),
       'LB-fake-xor-cycle': ('000', 'AAA', '---'), 'LBfd': ('000', 'AAA', '---'),
       'LB-chain-cancel': ('220', 'FFA', 'DD-'), 'LB-real': ('222', 'FFF', 'WWW')}
def _cause(r, m):
    if r['weakest_' + m] != 'F': return '-'
    return 'W' if r['wf'] == 'U' else ('D' if r['weakest_NODEP'] == 'A' else 'B')
for n, (reach, coh, rc11, wk) in t4.items():
    p = probe.get(n + '.litmus', {})
    ok = all(p.get(m, {}).get('WF-only') == reach and p[m].get('RA') == coh and p[m].get('RC11') == rc11
             and p[m].get('WEAKEST') == wk for m in 'AB')
    r = MC['diag'][0].get(n + '.litmus', {})
    try:
        kept = ''.join(str(int(r['data_edges']) - int(r['edges_fake_' + m])) for m in 'ABC')
        verd = ''.join(r['weakest_' + m] for m in 'ABC'); cause = ''.join(_cause(r, m) for m in 'ABC')
    except (KeyError, ValueError):
        kept = verd = cause = 'missing'
    ok = ok and (kept, verd, cause) == t3x[n] and verd[:2] == wk * 2
    check(ok, f'Table 3 row {n}: reach={reach} Coh(RA)={coh} RC11={rc11} SDEP A/B={wk}; per mode A/B/C: '
              f'sdep edges kept {"/".join(t3x[n][0])}, verdict {"/".join(t3x[n][1])}, cause of F {"/".join(t3x[n][2])}')
# ---------------------------------------------------------------- memory-hop contrast (memhop repair pass, 2026-11-08)
# Kept apart from the corpus, population and ring counts (own input set inputs/memhop, own output OUT/memhop).
# T+-LB cancels in registers; LB-mem-cancel cancels through a write of z and a coherence-forced reload of z.
# NODEP is the same encoder and WEAKEST formula with sdep = {} (ComposedLabelRun.verdicts with DependencyInfo.empty());
# in the corrected build the dependency set enters only acyclic(sdep U rf), so C and NODEP differ only in sdep.
MC['memhop'] = modec_audit('memhop')
audit_check(MC['memhop'][2], 'mode C manifest, memhop: one well-formed files.csv record for each of the 2 listed inputs, '
                             'no duplicate or malformed file/edge record, edges only in supported files, per-file edge counts match')
_mf = MC['memhop'][0]
_mt, _mm = _mf.get('LB-chain-cancel.litmus', {}), _mf.get('LB-mem-cancel.litmus', {})
_vcols = ('support', 'wf', 'weakest_A', 'weakest_B', 'weakest_C', 'weakest_ALL', 'weakest_NODEP', 'data_edges', 'edges_fake_C')
_want_t = ('SUPPORTED', 'R', 'F', 'F', 'A', 'F', 'A', '2', '2')
_want_m = ('SUPPORTED', 'R', 'F', 'F', 'F', 'F', 'A', '4', '0')
_got_t = tuple(_mt.get(k) for k in _vcols); _got_m = tuple(_mm.get(k) for k in _vcols)
_diag_t = tuple(MC['diag'][0].get('LB-chain-cancel.litmus', {}).get(k) for k in _vcols)
# the edge that closes the cycle: load of y -> store of x, whose composed label mentions the reload symbol too
_me = [r for r in MC['memhop'][1] if r['file'] == 'LB-mem-cancel.litmus']
_ev = {(r['file'], r['id']): r for r in rows(f'{OUT}/memhop/events.csv')} if os.path.isfile(f'{OUT}/memhop/events.csv') else {}
_yx = [r for r in _me if _ev.get((r['file'], r['read_id']), {}).get('var') == 'y' and r['write_loc'] == 'x']
_yx_ok = (len(_yx) == 1 and _yx[0]['composed'] == 'VARIES' and
          len(set(RSYM_ALL.findall(_yx[0]['composed_expr']))) == 2)
_mp = {}
_mpp = f'{OUT}/memhop/probe-six-models.txt'
for _l in (open(_mpp, encoding='utf-8').read().splitlines() if os.path.isfile(_mpp) else []):
    if _l.strip().startswith(('A (', 'B (')):
        _mp.setdefault(_l.strip()[0], []).append(dict(t.split('=') for t in _l.split('|')[0].split()[2:] if '=' in t))
_probe_ok = (set(_mp) == {'A', 'B'} and all(len(v) == 1 and v[0].get('WF-only') == 'reachable' and v[0].get('RA') == 'A'
             and v[0].get('RC11') == 'F' and v[0].get('WEAKEST') == 'F' for v in _mp.values()))
_ab_ok = (_mm.get('edges_fake_A'), _mm.get('edges_fake_B')) == ('0', '0')
if not _probe_ok: print(f'      LB-mem-cancel probe: {_mp}')
if not _ab_ok: print(f'      LB-mem-cancel edges_fake_A/B: {_mm.get("edges_fake_A")}/{_mm.get("edges_fake_B")}, expected 0/0')
for k, a, b in (('T+ (memhop)', _got_t, _want_t), ('LB-mem-cancel', _got_m, _want_m), ('T+ (diag)', _diag_t, _want_t)):
    if a != b: print(f'      {k}: {dict(zip(_vcols, a))}, expected {dict(zip(_vcols, b))}')
if not _yx_ok: print(f'      LB-mem-cancel y->x edge: {_yx}')
check(_got_t == _want_t and _diag_t == _want_t and _got_m == _want_m and _yx_ok and _probe_ok and _ab_ok,
      'memory-hop contrast (separate from corpus and ring counts): T+-LB admitted by composed labels (C=A, both edges fake); '
      'LB-mem-cancel forbidden by composed labels (C=F, all 4 data edges kept) and admitted by the same model with sdep empty '
      '(NODEP=A), so the cause is D; its load-of-y -> store-of-x label is VARIES and mentions the reload symbol; '
      'Table 3 row LB-mem-cancel: reachable, Coh(RA)=A, RC11=F, A/B keep all 4 edges and forbid')
# the reference on the same two files (parses them from source) and the re-decision of their 6 recorded expressions
_rp = rows(f'{OUT}/memhop/ref/ref-pairs.csv') if os.path.isfile(f'{OUT}/memhop/ref/ref-pairs.csv') else []
_rerr = []
if len(_rp) != 6 or any(r['agree'] != 'AGREE' for r in _rp):
    _rerr.append(f'memhop: reference pairs {len(_rp)}, statuses {sorted({r["agree"] for r in _rp})}; expected 6 AGREE')
for r in MC['memhop'][1]:
    k = (r['file'], r['read_id'], r['write_id'])
    try:
        ok, evd = SEM.check_edge(r['composed_expr'], 'R' + r['read_id'], r['composed'])
        rv, _ = REF.decide(_to_ref(REF.parse_expr(r['composed_expr'])), 'R' + r['read_id'], 32, random.Random(7))
    except Exception as ex:
        _rerr.append(f'memhop: re-check raised {type(ex).__name__} at {k}'); continue
    if not ok or rv != r['composed']: _rerr.append(f'memhop: recorded {r["composed"]} not confirmed at {k} ({evd}; reference {rv})')
audit_check(_rerr, 'memory-hop reference: the reference rebuilds both files from source and agrees on all 6 load-store pairs; '
                   'each recorded expression re-checked by the reference decision procedure and the solver-free validator')
# witnesses: one block per file; counts of rf assignments; Z3 model of the admitted candidate; driver DFS cycle
_wp = f'{OUT}/memhop/witness.txt'
_wt = open(_wp, encoding='utf-8').read() if os.path.isfile(_wp) else ''
_wb = {}
for _blk in _wt.split('=== ')[1:]:
    _nm = _blk.split('\n', 1)[0].strip()
    _wb[_nm] = _blk if _nm not in _wb else None   # a duplicate block is invalid
_wm, _wtp = _wb.get('LB-mem-cancel.litmus') or '', _wb.get('LB-chain-cancel.litmus') or ''
_wit_ok = (len(_wb) == 3 and None not in _wb.values() and
           '  rf assignments: 8; wf-satisfiable: 1; NODEP-consistent: 1; C-consistent: 0\n' in _wm and
           _wm.count('NODEP=SAT C=UNSAT') == 1 and
           'W T1 x) value=1\n' in _wm and
           any(l.strip().startswith('cycle in sdep U rf (driver DFS):') and l.count('-sdep->') == 2 and l.count('-rf->') == 2
               for l in _wm.splitlines()) and
           '  rf assignments: 4; wf-satisfiable: 1; NODEP-consistent: 1; C-consistent: 1\n' in _wtp)
check(_wit_ok, 'memory-hop witness: LB-mem-cancel has exactly one well-formed rf assignment for r0=r1=1; NODEP admits it '
               '(Z3 model stores 1 to x) and C forbids it; the cycle found is sdep-rf-sdep-rf; T+-LB: the one well-formed '
               'candidate is consistent under C')
_wc = _wb.get('LB-mem-cancel-cohcheck.litmus') or ''
check('  rf assignments: 8; wf-satisfiable: 4; NODEP-consistent: 0; C-consistent: 0\n' in _wc and _wc.count('wf=SAT NODEP=UNSAT') == 4,
      'memory-hop coherence probe: the 4 candidates in which the reload of z reads the initial 0 after the thread\'s own store '
      'are well-formed but violate the coherence base (NODEP), so coherence forces the reload to see the store')

# reference coverage of the corpus
audit_check(ref_audit('corpus', {('SUPPORTED', 'SUPPORTED'): 611, ('REJECTED', 'SUPPORTED'): 1639,
                                  ('REJECTED', 'REJECTED'): 146}, {'VARIES': 1}, 0),
            'corpus: reference parses 611 files that mode C also supports; their only data pair (1, varying) agrees with '
            'mode C, every mode C edge in them is matched, no other status')
ref_both = {r['file'] for r in rows(f'{OUT}/corpus/ref/ref-files.csv')
            if r['ref_status'] == 'SUPPORTED' and r['java_support'] == 'SUPPORTED'}
# Identity pins (regression pins recorded from the validated run of 2026-11-06, not independent evidence):
# which files the reference parses, which corpus edges are real, and each diagnostic pair's verdict.
# They make a coordinated relabelling that preserves every count fail.
def _digest(items): return hashlib.sha256('\n'.join(sorted(items)).encode('utf-8')).hexdigest()
PIN_REF_BOTH = '7474ac7de18d4fe65620ff9a940c5f91109320200741c240f437ffc249622ce8'
PIN_DIAG_PAIRS = 'a1d61d88e1f2e04e2a64baca19c4df03a50b9df2149e2edfbb048db162042509'
PIN_CORPUS_REAL = collections.Counter({('Dat3M/litmus/LKMM/manual/demo/C-wmb-is-not-A-cumulative.litmus', 'z'): 1,
                                       ('Dat3M/litmus/PPC/Dart-idd-two-regs.litmus', 'z'): 2,
                                       ('herdtools7/catalogue/aarch64/tests/LB+rel+data-post.litmus', 'x'): 1})
check(_digest(ref_both) == PIN_REF_BOTH and
      collections.Counter((r['file'], r['write_loc']) for r in ce if r['composed'] == 'VARIES') == PIN_CORPUS_REAL and
      _digest('|'.join((r['file'], r['thread'], r['load_ord'], r['store_ord'], r['ref32']))
              for r in rows(f'{OUT}/diag/ref/ref-pairs.csv')) == PIN_DIAG_PAIRS,
      'identity pins: the 611 files the reference parses, the 4 real corpus edges, and the 38 diagnostic pair verdicts '
      'are the recorded ones')
unchecked = [r for r in ce if r['file'] not in ref_both]
check(len(ce) == 326 and len(unchecked) == 325,
      f'corpus: {len(unchecked)} of the {len(ce)} mode C data edges lie in files the reference does not parse (unchecked by it)')
# which mode produced the corpus verdicts
check(all(r['weakest_A'] == r['weakest_B'] for r in c2 if r['weakest_B']), 'corpus: modes A and B give the same verdict on every file')
addrF = [r for r in c2 if r['weakest_B'] == 'F' and r['reason'] == 'ADDR_DEP']
check(len(addrF) == 5, f'corpus: {len(addrF)} of the 33 forbidden files contain address edges (not decided by mode C)')
vm_lines = open(f'{OUT}/vmsa-recount.txt', encoding='utf-8').read().splitlines()
vm_sum = [l for l in vm_lines if l.startswith('in aarch64-VMSA directory')]
vm_dir = [l.split()[1] for l in vm_lines if l.startswith('   DIR ')]
vm_tok = [l for l in vm_lines if l.startswith('   DIR ') and not l.rstrip().endswith('[]')]
check(vm_sum == ['in aarch64-VMSA directory 16 ; with page-table tokens 11 ; both 11'] and
      [l for l in vm_lines if l.startswith('eligible files')] == ['eligible files 2396'] and
      len(vm_dir) == len(set(vm_dir)) == 16 and set(vm_dir) == vm and len(vm_tok) == 11,
      'corpus: 16 VMSA files excluded (exactly the aarch64-VMSA files of files.csv), 11 with page-table tokens + 5 without')

# ---------------------------------------------------------------- expression equality (bridge assumption)
def equiv_audit(name, exp):
    errs, tag = [], f'{name}/equiv'
    er = read_table(f'{OUT}/{name}/equiv/expr-equiv.csv', ['file', 'read_id', 'write_id', 'status', 'evidence'], errs, tag)
    keys = set()
    for r in er:
        k = (r['file'], r['read_id'], r['write_id'])
        if k in keys: errs.append(f'{tag}: duplicate record {k}')
        keys.add(k)
        if r['status'] != 'EQUAL': errs.append(f'{tag}: status {r["status"]} at {k}')
        elif r['evidence'] != 'z3-unsat; 2000 random evaluations equal':
            errs.append(f'{tag}: EQUAL record without the Z3 + random-evaluation evidence at {k}')
    both = {r['file'] for r in rows(f'{OUT}/{name}/ref/ref-files.csv')
            if r['ref_status'] == 'SUPPORTED' and r['java_support'] == 'SUPPORTED'}
    want = {(r['file'], r['read_id'], r['write_id']) for r in MC[name][1] if r['file'] in both}
    if keys != want: errs.append(f'{tag}: {len(keys & want)} of the {len(want)} jointly supported edges compared, {len(keys - want)} extra')
    if len(er) != exp: errs.append(f'{tag}: {len(er)} records, expected {exp}')
    s = read_summary(f'{OUT}/{name}/equiv/expr-equiv-summary.txt', errs, tag)
    if s != dict(collections.Counter(r['status'] for r in er)): errs.append(f'{tag}: summary does not match the records')
    return errs
# Thm. 7(d) regression: load r0; s := r0 * k; store s, with k's INITIAL value fixed. Dependent for
# some initial k (esdep), but with k fixed to 0 (declared or undeclared, default 0) constant, and
# with k fixed to 1 varying. Both executables must implement the fixed-initial-state relation.
rgl = [((r['file'], r['write_loc']), r['composed']) for r in MC['regress'][1]]
rg = dict(rgl)
check(len(rgl) == len(rg) == 6 and rg == {('R-init-k0.litmus', 'x'): 'CONST', ('R-init-k0.litmus', 'y'): 'VARIES',
             ('R-init-k1.litmus', 'x'): 'VARIES', ('R-init-k1.litmus', 'y'): 'VARIES',
             ('R-init-undecl.litmus', 'x'): 'CONST', ('R-init-undecl.litmus', 'y'): 'VARIES'},
      f'initial registers fixed (Thm 7(d)): mode C gives r0*k CONST for k=0 and undeclared k, VARIES for k=1 {rg}')
audit_check(ref_audit('regress', {('SUPPORTED', 'SUPPORTED'): 3}, {'CONST': 2, 'VARIES': 4}, 0),
            'initial registers fixed: the reference agrees with mode C on all 6 regression pairs')
for name, n in (('regress', 6), ('diag', 38), ('chain', 314), ('corpus', 1)):
    audit_check(equiv_audit(name, n), f'expression equality, {name}: the composed expression of the prototype equals that of the reference '
                                      f'on all {n} jointly supported edges (Z3 unsat + 2,000 random evaluations each)')

neq = sum(len(rows(f'{OUT}/{n}/equiv/expr-equiv.csv')) for n in ('regress', 'diag', 'chain', 'corpus'))
check(neq == 359, f'expression equality: {neq} edges compared in total (paper: 359)')

# ---------------------------------------------------------------- mode L (weighted closure, Thm. 6)
def affsummary(d):
    out = {}
    for line in open(os.path.join(d, 'affine-summary.txt'), encoding='utf-8'):
        k, v = line.rstrip('\n').split('\t'); out[k] = int(v)
    return out
DIAG_L = {('chain', 'CONST', 'ABSTAIN'): 2, ('chain', 'CONST', 'AGREE'): 2, ('chain', 'VARIES', 'AGREE'): 6,
          ('check', 'CONST', 'ABSTAIN'): 4, ('check', 'CONST', 'AGREE'): 5, ('check', 'VARIES', 'AGREE'): 17,
          ('direct', 'CONST', 'AGREE'): 2}
CHAIN_L = {('chain', 'CONST', 'ABSTAIN'): 46, ('chain', 'CONST', 'AGREE'): 26, ('chain', 'VARIES', 'ABSTAIN'): 49,
           ('chain', 'VARIES', 'AGREE'): 45, ('check', 'CONST', 'ABSTAIN'): 4, ('check', 'CONST', 'AGREE'): 1,
           ('check', 'VARIES', 'ABSTAIN'): 1, ('check', 'VARIES', 'AGREE'): 8, ('direct', 'CONST', 'ABSTAIN'): 40,
           ('direct', 'CONST', 'AGREE'): 26, ('direct', 'VARIES', 'ABSTAIN'): 43, ('direct', 'VARIES', 'AGREE'): 25}
DIAG_L_REJ = {'U-reject-branch.litmus', 'U-reject-rmw.litmus', 'U-reject-shift.litmus'}
for name, exp, rjs, npair in (('diag', DIAG_L, DIAG_L_REJ, 38), ('chain', CHAIN_L, set(), 314)):
    e, _ = affine_audit(name, exp, rjs)
    audit_check(e, f'mode L, {name}: one record for each of the {npair} reference pairs, every record AGREE or ABSTAIN '
                   f'(no disagreement), {len(rjs)} files rejected {sorted(rjs)}')
a = affsummary(f'{OUT}/chain/affine')
def g(form, ref, ag):
    return a.get(f"('pair', '{form}', '{ref}', '{ag}')", 0)
check(g('chain', 'CONST', 'AGREE') == 26 and g('chain', 'CONST', 'ABSTAIN') == 46,
      'mode L, chain: decides 26 of the 72 chain-form fakes (all correctly) and abstains on 46')
check(g('direct', 'CONST', 'AGREE') == 26 and g('direct', 'CONST', 'ABSTAIN') == 40,
      'mode L, chain: decides 26 of the 66 single-instruction fakes and abstains on 40')
check(g('check', 'CONST', 'AGREE') == 1 and g('check', 'CONST', 'ABSTAIN') == 4,
      'mode L, chain: check cases with an edge: 1 of 5 fakes decided (Table 2 column L: 1), 4 abstained; '
      'the 3 no-edge pairs are not classified')
dec = sum(v for k, v in a.items() if k.endswith("'AGREE')"))
abst = sum(v for k, v in a.items() if k.endswith("'ABSTAIN')"))
check(dec == 131 and abst == 183 and dec + abst == 314,
      f'mode L, chain: {dec} of 314 pairs decided (affine), {abst} abstained (non-affine)')
real = sum(g(f, 'VARIES', ag) for f in ('chain', 'direct', 'check') for ag in ('AGREE', 'ABSTAIN'))
check(real == 171, f'mode L, chain: the {real} real pairs are decided real or abstained, never reported fake')
ip = f'{OUT}/isabelle/CHECK-RESULT.txt'
isa = [l for l in open(ip, encoding='utf-8').read().splitlines() if l.strip()] if os.path.exists(ip) else []
ISA_THY = {'WEV_SMT_PwT.' + t for t in ('PwT_Control', 'PwT_Capacity', 'PwT_EventBridge', 'PwT_ReadRestricted',
                                        'PwT_Granularity', 'PwT_Program', 'PwT_R4b', 'PwT_Constancy', 'PwT_Expr')} | \
          {'WEV_SMT_Rev.' + t for t in ('PwT_Correspondence', 'PwT_Block', 'PwT_Affine', 'PwT_Versioned', 'PwT_Remarks')}
isa_ok = (len(isa) == 76 and isa[0].startswith('theories checked (14): ') and
          set(isa[0][len('theories checked (14): '):].split(', ')) == ISA_THY and
          isa[1].startswith('ancestry: OK') and isa[2] == 'oracles over 73 theorems: none')
# This reads the result file that this run's Isabelle step wrote (run_all.sh deletes any old copy first and
# fails the step unless the build succeeds); it cannot itself re-check proofs.
check(isa_ok, 'isabelle: 73 cited facts (one statement line each) over exactly the 14 named theories, no oracle, '
              'ancestry OK (missing or malformed result file = FAIL)')

print(f'\n{fails} failure(s)')
sys.exit(1 if fails else 0)
