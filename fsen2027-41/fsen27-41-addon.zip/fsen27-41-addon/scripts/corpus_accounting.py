"""Corpus accounting for the FSEN 2027 #41 paper (raw and de-duplicated counts).

Usage: python -I corpus_accounting.py OUT BASE OUTDIR

Reads OUT/corpus/files.csv and OUT/corpus/edges.csv (produced by run_all.sh) and the
litmus files under BASE/corpus/litmus. Writes to OUTDIR:
  accounting.txt     raw and distinct counts, one "key: value" per line
  changed-tests.csv  every file whose SDEP verdict differs between two configurations
  duplicates.csv     every group of byte-identical / normalised-identical files

Units are kept apart: files (raw), distinct files (byte-identical content counted once),
normalised tests (comments, whitespace and the test-name token in the header ignored),
edges, and expression shapes. Nothing is removed from the raw counts; the distinct counts
are reported next to them.
"""
import csv, hashlib, os, re, sys, collections

OUT, BASE, DST = sys.argv[1:4]
os.makedirs(DST, exist_ok=True)
F = list(csv.DictReader(open(os.path.join(OUT, 'corpus', 'files.csv'), encoding='utf-8')))
E = list(csv.DictReader(open(os.path.join(OUT, 'corpus', 'edges.csv'), encoding='utf-8')))
LIT = os.path.join(BASE, 'corpus', 'litmus')


def raw(f):
    return open(os.path.join(LIT, f), 'rb').read()


def normalised(b):
    s = b.decode('utf-8', 'replace')
    s = re.sub(r'\(\*.*?\*\)', ' ', s, flags=re.S)
    s = re.sub(r'/\*.*?\*/', ' ', s, flags=re.S)
    s = re.sub(r'//[^\n]*', ' ', s)
    lines = s.split('\n')
    head = lines[0].split()
    lines[0] = head[0] if head else ''          # keep the architecture, drop the test name
    return ' '.join(' '.join(lines).split()).encode()


def sha(b):
    return hashlib.sha256(b).hexdigest()


vmsa = [r for r in F if r['reason'] == 'VMSA_PAGE_TABLE']
elig = [r for r in F if r['reason'] != 'VMSA_PAGE_TABLE']
sup = [r for r in elig if r['support'] == 'SUPPORTED']
h_raw = {r['file']: sha(raw(r['file'])) for r in F}
h_norm = {r['file']: sha(normalised(raw(r['file']))) for r in F}


def distinct(rows, h):
    return len({h[r['file']] for r in rows})


edges_by_file = collections.defaultdict(list)
for e in E:
    edges_by_file[e['file']].append(e)
shape = lambda x: re.sub(r'R\d+', 'R', x)
fake = [e for e in E if e['composed'] == 'CONST']
real = [e for e in E if e['composed'] == 'VARIES']
supf = {r['file'] for r in sup}

acc = collections.OrderedDict()
acc['eligible files (raw)'] = len(F)
acc['excluded aarch64-VMSA files'] = len(vmsa)
acc['analysed files (raw)'] = len(elig)
acc['analysed files (byte-distinct)'] = distinct(elig, h_raw)
acc['analysed files (normalised-distinct)'] = distinct(elig, h_norm)
acc['mode C supported (raw)'] = len(sup)
acc['mode C supported (byte-distinct)'] = distinct(sup, h_raw)
acc['mode C supported (normalised-distinct)'] = distinct(sup, h_norm)
for k, v in sorted(collections.Counter(r['reason'] for r in elig if r['support'] != 'SUPPORTED').items()):
    acc['mode C rejected: ' + k] = v
withe = [r for r in sup if int(r['data_edges'] or 0) > 0]
acc['supported files with >=1 data edge (raw)'] = len(withe)
acc['supported files with >=1 data edge (byte-distinct)'] = distinct(withe, h_raw)
acc['supported files without data edges (raw)'] = len(sup) - len(withe)
acc['data edges in supported files'] = sum(len(edges_by_file[f]) for f in supf)
acc['data edges: composed CONST (fake)'] = len(fake)
acc['data edges: composed VARIES (real)'] = len(real)
acc['distinct shapes of fake composed expressions'] = len({shape(e['composed_expr']) for e in fake})
for s, n in collections.Counter(shape(e['composed_expr']) for e in fake).most_common():
    acc['fake shape ' + s] = n
acc['distinct shapes of real composed expressions'] = len({shape(e['composed_expr']) for e in real})
acc['edges where A, B and C disagree'] = sum(1 for e in E if not (
    e['local_A_semantic'] == e['local_B_semantic'] == ('true' if e['composed'] == 'VARIES' else 'false')))
for col in ('weakest_A', 'weakest_B', 'weakest_ALL', 'weakest_NODEP'):
    c = collections.Counter(r[col] for r in elig)
    acc[f'{col} on analysed files: A/F/none'] = f"{c['A']}/{c['F']}/{c['']}"
    d = {}
    for r in elig:
        if r[col]:
            d.setdefault(h_raw[r['file']], r[col])
    cd = collections.Counter(d.values())
    acc[f'{col} on byte-distinct analysed files: A/F'] = f"{cd['A']}/{cd['F']}"
c = collections.Counter(r['weakest_C'] for r in sup)
acc['weakest_C on supported files: A/F'] = f"{c['A']}/{c['F']}"
forb = [r for r in elig if r['weakest_B'] == 'F']
acc['forbidden (B closure): from well-formedness (W)'] = sum(1 for r in forb if r['wf'] == 'U')
acc['forbidden (B closure): from coherence base (B)'] = sum(1 for r in forb if r['wf'] == 'R' and r['weakest_NODEP'] == 'F')
acc['forbidden (B closure): by the dependency axiom alone (D)'] = sum(1 for r in forb if r['wf'] == 'R' and r['weakest_NODEP'] == 'A')

COMPARISONS = [
    ('A vs B (folding vs exact oracle)', 'weakest_A', 'weakest_B', elig),
    ('B vs C (closure vs composed labels; C-supported only)', 'weakest_B', 'weakest_C', sup),
    ('B vs ALL (semantic vs every syntactic dependency)', 'weakest_B', 'weakest_ALL', elig),
    ('NODEP vs B (no dependency axiom vs SDEP)', 'weakest_NODEP', 'weakest_B', elig),
]
rows = []
for name, a, b, pop in COMPARISONS:
    ch = [r for r in pop if r[a] and r[b] and r[a] != r[b]]
    acc['changed verdicts: ' + name + ' (raw files)'] = len(ch)
    acc['changed verdicts: ' + name + ' (byte-distinct)'] = len({h_raw[r['file']] for r in ch})
    for r in ch:
        rows.append({'comparison': name, 'file': r['file'], 'sha256': h_raw[r['file']],
                     'normalised_sha256': h_norm[r['file']], 'support': r['support'], 'reason': r['reason'],
                     'data_edges': r['data_edges'], 'fake_edges_C': r['edges_fake_C'],
                     a: r[a], b: r[b], 'weakest_NODEP': r['weakest_NODEP'], 'wf': r['wf']})

dups = []
for label, h in (('byte', h_raw), ('normalised', h_norm)):
    g = collections.defaultdict(list)
    for r in elig:
        g[h[r['file']]].append(r['file'])
    groups = [v for v in g.values() if len(v) > 1]
    acc[f'{label}-identical duplicate groups'] = len(groups)
    acc[f'{label}-identical extra copies'] = sum(len(v) - 1 for v in groups)
    acc[f'{label}-identical groups spanning herd7 and Dat3M'] = sum(
        1 for v in groups if len({x.split('/')[0] for x in v}) > 1)
    for i, v in enumerate(sorted(groups)):
        for f in v:
            dups.append({'kind': label, 'group': i, 'file': f, 'sha256': h[f]})

with open(os.path.join(DST, 'accounting.txt'), 'w', encoding='utf-8', newline='\n') as fh:
    for k, v in acc.items():
        fh.write(f'{k}: {v}\n')
keys = sorted({k for r in rows for k in r}, key=lambda k: (k not in ('comparison', 'file'), k))
with open(os.path.join(DST, 'changed-tests.csv'), 'w', encoding='utf-8', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
with open(os.path.join(DST, 'duplicates.csv'), 'w', encoding='utf-8', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=['kind', 'group', 'file', 'sha256']); w.writeheader(); w.writerows(dups)
for k, v in acc.items():
    print(f'{k}: {v}')
