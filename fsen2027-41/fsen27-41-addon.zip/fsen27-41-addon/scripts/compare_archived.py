"""Fresh mode-C run vs the archived chain-composition experiment (pairs-final.csv).
Usage: python -I compare_archived.py <pairs-final.csv> <fresh edges.csv> <fresh files.csv>"""
import csv, sys, collections
arch = collections.defaultdict(list)
for r in csv.DictReader(open(sys.argv[1], encoding='utf-8')):
    arch[r['id'] + '.litmus'].append(r)
fresh = collections.defaultdict(list)
for r in csv.DictReader(open(sys.argv[2], encoding='utf-8')):
    fresh[r['file']].append(r)
files = {r['file']: r for r in csv.DictReader(open(sys.argv[3], encoding='utf-8'))}
c = collections.Counter()
for f, rows in arch.items():
    fr = sorted(fresh.get(f, []), key=lambda r: (int(r['write_id']), int(r['read_id'])))
    ar = sorted(rows, key=lambda r: int(r['k']))
    if len(fr) != len(ar):
        c['pair-count-mismatch'] += 1; print('COUNT', f, len(fr), len(ar)); continue
    for a, b in zip(ar, fr):
        exp = a['expected']                       # FAKE/REAL ground truth from the generator
        cfresh = 'FAKE' if b['composed'] == 'CONST' else 'REAL'
        c[('C_fresh_vs_expected', cfresh == exp)] += 1
        c[('C_fresh_vs_archived_C', cfresh == a['C'])] += 1
        c[('A_fresh_vs_archived_A', ('REAL' if b['local_A_semantic'] == 'true' else 'FAKE') == a['A'])] += 1
        c[('B_fresh_vs_archived_B', ('REAL' if b['local_B_semantic'] == 'true' else 'FAKE') == a['B'])] += 1
        c[('category', a['variant'], 'B', 'REAL' if b['local_B_semantic'] == 'true' else 'FAKE', 'C', cfresh)] += 1
for k in sorted(c, key=str): print(k, c[k])
v = collections.Counter((r['weakest_B'], r['weakest_C']) for r in files.values() if r['support'] == 'SUPPORTED')
print('single-thread WEAKEST verdicts (B,C):', dict(v))
