"""Positive and negative tests for check_numbers.py.

Usage: python -I test_check_numbers.py <OUT of run_all.sh> <BASE> <scratch dir> [--require-rings]

1. The genuine OUT must pass: check_numbers.py exits 0.
2. Each mutation is applied to a disposable copy of OUT (the genuine OUT is never written).
   check_numbers.py must then exit non-zero AND print FAIL on the check that the mutation
   targets. A mutation that leaves the targeted check passing is a test failure.
Prints one PASS/FAIL line per case and exits non-zero if any case fails.
"""
import csv, os, shutil, subprocess, sys

OUT, BASE, SCR = sys.argv[1], sys.argv[2], sys.argv[3]
EXTRA = sys.argv[4:]
HERE = os.path.dirname(os.path.abspath(__file__))
CN = os.path.join(HERE, 'check_numbers.py')
fails = 0


def run(out, base=None):
    p = subprocess.run([sys.executable, '-I', CN, out, base or BASE] + EXTRA, capture_output=True, text=True, encoding='utf-8')
    return p.returncode, p.stdout


def report(ok, msg):
    global fails
    print(('PASS  ' if ok else 'FAIL  ') + msg)
    fails += not ok


def table(p):
    rd = list(csv.reader(open(p, encoding='utf-8', newline='')))
    return rd[0], rd[1:]


def write_table(p, head, body):
    with open(p, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f); w.writerow(head); w.writerows(body)


def edit_text(p, fn):
    s = open(p, encoding='utf-8').read(); s2 = fn(s)
    assert s2 != s, f'mutation did not change {p}'
    open(p, 'w', encoding='utf-8', newline='').write(s2)


# ---------------------------------------------------------------- mutations
def set_col(rel, col, old, new, nth=0, summary=None):
    """Change column col from old to new in the nth matching record; optionally rewrite the summary consistently."""
    def m(o):
        p = os.path.join(o, rel); h, b = table(p); i = h.index(col)
        hits = [r for r in b if r[i] == old]
        assert len(hits) > nth, f'no record with {col}={old} in {rel}'
        hits[nth][i] = new; write_table(p, h, b)
        if summary:
            edit_text(os.path.join(o, summary[0]), lambda s: s.replace(summary[1], summary[2]))
    return m


def drop_row(rel, nth=0, summary=None):
    def m(o):
        p = os.path.join(o, rel); h, b = table(p)
        assert len(b) > nth; del b[nth]; write_table(p, h, b)
        if summary:
            edit_text(os.path.join(o, summary[0]), summary[1])
    return m


def dup_row(rel, nth=0):
    def m(o):
        p = os.path.join(o, rel); h, b = table(p); b.insert(nth, list(b[nth])); write_table(p, h, b)
    return m


def truncate_row(rel, nth=0):
    def m(o):
        p = os.path.join(o, rel); h, b = table(p); b[nth] = b[nth][:-2]; write_table(p, h, b)
    return m


def header_only(rel, summary=None):
    def m(o):
        p = os.path.join(o, rel); h, _ = table(p); write_table(p, h, [])
        if summary is not None:
            open(os.path.join(o, summary), 'w', encoding='utf-8').write('')
    return m


def remove(rel):
    def m(o):
        os.remove(os.path.join(o, rel))
    return m


def extra_corpus_edge(o):
    """An unmatched mode C data edge in a file that both tools support."""
    both = {r['file'] for r in csv.DictReader(open(os.path.join(o, 'corpus/ref/ref-files.csv'), encoding='utf-8'))
            if r['ref_status'] == 'SUPPORTED' and r['java_support'] == 'SUPPORTED'}
    p = os.path.join(o, 'corpus/edges.csv'); h, b = table(p)
    src = [r for r in b if r[0] in both]
    assert src, 'no edge in a jointly supported file'
    e = list(src[0]); e[1] = str(int(e[1]) + 100000); e[2] = str(int(e[2]) + 100000); b.append(e)
    write_table(p, h, b)


def corpus_java_only(o):
    p = os.path.join(o, 'corpus/ref/ref-pairs.csv'); h, b = table(p)
    r = list(b[0]); r[2] = '7'; r[5] = r[6] = r[7] = r[8] = ''; r[11] = 'JAVA_ONLY'; b.append(r); write_table(p, h, b)


def drop_summary_pair_line(o):
    edit_text(os.path.join(o, 'corpus/ref/summary.txt'),
              lambda s: ''.join(l for l in s.splitlines(True) if not l.startswith("('pair'")))


def set_file_col(rel, fn, col, val):
    """Change one column of fn's genuine record in place (scope pass 2026-11-08: Table 3 per-mode columns)."""
    def m(o):
        p = os.path.join(o, rel); h, b = table(p)
        g = next(r for r in b if r[0] == fn); i = h.index(col)
        assert g[i] != val, f'{fn} already has {col}={val}'
        g[i] = val; write_table(p, h, b)
    return m


def contradictory_dup_file(rel, fn, col, val):
    """Insert, BEFORE the genuine record, a copy of fn's record with col changed (a duplicate that
    contradicts the genuine one; a last-wins dict would silently keep the genuine record)."""
    def m(o):
        p = os.path.join(o, rel); h, b = table(p)
        g = next(r for r in b if r[0] == fn); bad = list(g); bad[h.index(col)] = val
        assert bad != g; b.insert(0, bad); write_table(p, h, b)
    return m


def edge_verdict_consistent(name, fn):
    """Flip one CONST edge of fn to VARIES in edges.csv and decrement edges_fake_C in files.csv, so that
    mode C's own manifest stays internally consistent and only the edge-to-reference join can catch it."""
    def m(o):
        p = os.path.join(o, name, 'edges.csv'); h, b = table(p); i = h.index('composed')
        hit = next(r for r in b if r[0] == fn and r[i] == 'CONST'); hit[i] = 'VARIES'; write_table(p, h, b)
        p = os.path.join(o, name, 'files.csv'); h, b = table(p); j = h.index('edges_fake_C')
        r = next(r for r in b if r[0] == fn); r[j] = str(int(r[j]) - 1); write_table(p, h, b)
    return m


def swap_file_record(o):
    """Replace one corpus file record by a duplicate of another (row count unchanged)."""
    p = os.path.join(o, 'corpus/files.csv'); h, b = table(p)
    c = [k for k, r in enumerate(b) if r[h.index('support')] == 'SUPPORTED' and r[h.index('data_edges')] == '0'
         and 'VMSA' not in r[0]]
    b[c[0]] = list(b[c[1]]); write_table(p, h, b)


def set_all(rel, col, new):
    def m(o):
        p = os.path.join(o, rel); h, b = table(p); i = h.index(col)
        for r in b: r[i] = new
        write_table(p, h, b)
    return m


def rename_file_cell(rel, old, new):
    def m(o):
        p = os.path.join(o, rel); h, b = table(p); hit = [r for r in b if r[0] == old]
        assert hit; hit[0][0] = new; write_table(p, h, b)
    return m


def probe_dup_block(o):
    p = os.path.join(o, 'probe-six-models.txt'); L = open(p, encoding='utf-8').read().splitlines(True)
    i = next(k for k, l in enumerate(L) if l.strip() == 'LB-chain-cancel.litmus')
    blk = [l.replace('WEAKEST=F', 'WEAKEST=A').replace('RC11=F', 'RC11=A') for l in L[i:i + 3]]
    assert blk != L[i:i + 3]
    open(p, 'w', encoding='utf-8', newline='').write(''.join(L[:1] + blk + L[1:]))


def vmsa_append(o):
    edit_text(os.path.join(o, 'vmsa-recount.txt'), lambda s: s.replace(
        'in aarch64-VMSA directory 16 ; with page-table tokens 11 ; both 11', 'in aarch64-VMSA directory 99 ; with page-table tokens 0 ; both 0')
        + '# in aarch64-VMSA directory 16 ; with page-table tokens 11 ; both 11\n')


def corpus_real_fake_swap(o):
    """Relabel one real corpus edge fake and one fake edge (outside the reference's files) real, adjusting the
    per-file counts so every count and the manifest stay consistent."""
    both = {r['file'] for r in csv.DictReader(open(os.path.join(o, 'corpus/ref/ref-files.csv'), encoding='utf-8'))
            if r['ref_status'] == 'SUPPORTED' and r['java_support'] == 'SUPPORTED'}
    p = os.path.join(o, 'corpus/edges.csv'); h, b = table(p); c, A, B = h.index('composed'), h.index('local_A_semantic'), h.index('local_B_semantic')
    real = next(r for r in b if r[c] == 'VARIES' and r[0] not in both)
    fake = next(r for r in b if r[c] == 'CONST' and r[0] not in both and r[0] != real[0] and 'VMSA' not in r[0])
    real[c], real[A], real[B] = 'CONST', 'false', 'false'; fake[c], fake[A], fake[B] = 'VARIES', 'true', 'true'
    write_table(p, h, b)
    p = os.path.join(o, 'corpus/files.csv'); h2, b2 = table(p)
    for r in b2:
        d = 1 if r[0] == real[0] else (-1 if r[0] == fake[0] else 0)
        for col in ('edges_fake_A', 'edges_fake_B', 'edges_fake_C'):
            if d: r[h2.index(col)] = str(int(r[h2.index(col)]) + d)
    write_table(p, h2, b2)


def ref_status_swap(o):
    p = os.path.join(o, 'corpus/ref/ref-files.csv'); h, b = table(p); s = h.index('ref_status')
    x = next(r for r in b if r[s] == 'SUPPORTED' and r[h.index('java_support')] == 'SUPPORTED')
    y = next(r for r in b if r[s] == 'REJECTED' and r[h.index('java_support')] == 'SUPPORTED')
    for col in ('ref_status', 'ref_reason'):
        i = h.index(col); x[i], y[i] = y[i], x[i]
    write_table(p, h, b)


def diag_coordinated_swap(o):
    """Swap the CONST/VARIES labels of two pairs of U-reload-cancel consistently in mode C, the reference and mode L."""
    fn = 'U-reload-cancel.litmus'
    p = os.path.join(o, 'diag/edges.csv'); h, b = table(p); c = h.index('composed')
    es = [r for r in b if r[0] == fn]; assert {r[c] for r in es} == {'CONST', 'VARIES'}
    for r in es: r[c] = 'VARIES' if r[c] == 'CONST' else 'CONST'
    write_table(p, h, b)
    for rel, cols in (('diag/ref/ref-pairs.csv', ('ref32', 'ref64', 'java_composed')), ('diag/affine/affine-pairs.csv', ('ref32', 'modeL'))):
        p = os.path.join(o, rel); h, b = table(p)
        for r in b:
            if r[0] != fn: continue
            for col in cols:
                i = h.index(col); r[i] = {'CONST': 'VARIES', 'VARIES': 'CONST'}.get(r[i], r[i])
        write_table(p, h, b)


def ring_class_swap(o):
    p = os.path.join(o, 'rings/ring-classes.csv'); h, b = table(p); n, e1 = h.index('nonconst'), h.index('e1')
    x = next(r for r in b if r[e1] == '1' and r[n] == 'True'); y = next(r for r in b if r[e1] == '1' and r[n] == 'False')
    x[n], y[n] = 'False', 'True'; write_table(p, h, b)


def ring_dup(o):
    p = os.path.join(o, 'rings/ring-classes.csv'); h, b = table(p)
    same = next(k for k in range(1, len(b)) if (b[k][1], b[k][2], b[k][3]) == (b[0][1], b[0][2], b[0][3]))
    b[same] = list(b[0]); write_table(p, h, b)


def drop_events_outside_ref(o):
    both = {r['file'] for r in csv.DictReader(open(os.path.join(o, 'corpus/ref/ref-files.csv'), encoding='utf-8'))
            if r['ref_status'] == 'SUPPORTED' and r['java_support'] == 'SUPPORTED'}
    p = os.path.join(o, 'corpus/events.csv'); h, b = table(p); write_table(p, h, [r for r in b if r[0] in both])


def forge_isa(o):
    open(os.path.join(o, 'isabelle/CHECK-RESULT.txt'), 'w', encoding='utf-8').write(
        'theories checked (13): X\nancestry: OK\noracles over 62 theorems: none\n')


# ---------------------------------------------------------------- repair-pass cases (2026-11-06)
def expr_verdict_mismatch(name, verdict, outside_ref=False):
    """Change one edge's composed_expr so that it no longer fits its recorded verdict, keeping every other
    column (verdict, symbol_occurs, per-file counts) unchanged: the bypass reported by the cold review."""
    def m(o):
        p = os.path.join(o, name, 'edges.csv'); h, b = table(p)
        c, x, rid = h.index('composed'), h.index('composed_expr'), h.index('read_id')
        skip = set()
        if outside_ref:
            rf = os.path.join(o, name, 'ref', 'ref-files.csv'); rh, rb = table(rf)
            skip = {r[rh.index('file')] for r in rb if r[rh.index('ref_status')] == 'SUPPORTED'}
        r = next(r for r in b if r[c] == verdict and r[0] not in skip and ('R' + r[rid]) in r[x])
        sym = 'R' + r[rid]
        r[x] = f'((({sym})+({sym}))+1)' if verdict == 'CONST' else f'((({sym})^({sym}))+1)'
        write_table(p, h, b)
    return m


def stale_identity(o):
    edit_text(os.path.join(o, 'inputs-identity.txt'), lambda s: s.replace('add-on manifest sha256: ', 'add-on manifest sha256: 0'))


def wrong_base(o):
    fb = os.path.join(o, '_wrong_base'); os.makedirs(fb, exist_ok=True)
    open(os.path.join(fb, 'SHA256SUMS'), 'wb').write(open(os.path.join(BASE, 'SHA256SUMS'), 'rb').read() + b'# altered\n')
    return fb


def unexpected_file_record(o):
    p = os.path.join(o, 'corpus', 'files.csv'); h, b = table(p)
    r = list(b[0]); r[h.index('file')] = 'NO-SUCH-DIR/NO-SUCH.litmus'; b.append(r); write_table(p, h, b)


def truncated_file(rel):
    def m(o):
        p = os.path.join(o, rel); data = open(p, 'rb').read()
        open(p, 'wb').write(data[:len(data) * 2 // 3])
    return m


def stale_accounting(o):
    edit_text(os.path.join(o, 'corpus', 'accounting', 'accounting.txt'),
              lambda s: s.replace('supported files with >=1 data edge (raw): 245', 'supported files with >=1 data edge (raw): 246'))


CASES = [
    ('corpus: fake edge expression made non-constant, CONST kept (outside the reference files)',
     expr_verdict_mismatch('corpus', 'CONST', outside_ref=True), 'semantic re-decision, corpus'),
    ('chain: fake edge expression made non-constant, CONST kept', expr_verdict_mismatch('chain', 'CONST'), 'semantic re-decision, chain'),
    ('chain: real edge expression made constant, VARIES kept', expr_verdict_mismatch('chain', 'VARIES'), 'semantic re-decision, chain'),
    ('diag: fake edge expression made non-constant, CONST kept', expr_verdict_mismatch('diag', 'CONST'), 'semantic re-decision, diag'),
    ('stale outputs: produced by another add-on version (identity record)', stale_identity, 'input identity'),
    ('wrong base archive (manifest differs)', wrong_base, 'input identity'),
    ('corpus: unexpected files.csv record for a file not in the input list', unexpected_file_record, 'mode C manifest, corpus'),
    ('corpus: edges.csv truncated mid-file', truncated_file('corpus/edges.csv'), 'mode C manifest, corpus'),
    ('corpus: accounting summary stale (245 -> 246)', stale_accounting, 'corpus accounting'),
    # AI-reviewer bypasses of the first hardened checker (review/ai-reviewer-2/bypass2.out, bypass3.out)
    ('expr equality: evidence of every record replaced', set_all('chain/equiv/expr-equiv.csv', 'evidence', 'NOT CHECKED'), 'expression equality, chain'),
    ('reference: CONST evidence removed', set_col('chain/ref/ref-pairs.csv', 'evidence32', 'z3-unsat', 'none'), 'chain: reference agrees'),
    ('mode L diag: rejection record renamed to a nonexistent file', rename_file_cell('diag/affine/affine-pairs.csv', 'U-reject-shift.litmus', 'NO-SUCH-FILE.litmus'), 'mode L, diag'),
    ('probe: contradictory LB-chain-cancel block inserted first', probe_dup_block, 'six-model probe'),
    ('VMSA recount falsified, expected text appended', vmsa_append, 'corpus: 16 VMSA'),
    ('corpus: a real and a fake edge relabelled, counts adjusted', corpus_real_fake_swap, 'identity pins'),
    ('corpus: reference status of two files swapped', ref_status_swap, 'identity pins'),
    ('diag: labels swapped coherently in mode C, reference and mode L', diag_coordinated_swap, 'identity pins'),
    ('rings: reference classification of two expressions swapped', ring_class_swap, 'rings: one reference classification'),
    ('rings: a row replaced by a duplicate of another', ring_dup, 'rings: one reference classification'),
    ('corpus: event records outside the reference files deleted', drop_events_outside_ref, 'mode C manifest, corpus'),
    ('isabelle: CHECK-RESULT.txt forged (three lines)', forge_isa, 'isabelle:'),
    ('diag: composed_expr made unparsable', set_col('diag/edges.csv', 'composed_expr', '(((R6) + 1) - (R6))', '((('), 'mode C manifest, diag'),
    ('diag: symbol_occurs garbage', set_all('diag/edges.csv', 'symbol_occurs', 'GARBAGE'), 'mode C manifest, diag'),

    # AI-reviewer bypasses of the pre-hardening checker (review/ai-reviewer/bypass_*.out), now required to fail
    ('diag: contradictory duplicate files.csv record (LB-chain-cancel weakest_C=F) before the genuine one',
     contradictory_dup_file('diag/files.csv', 'LB-chain-cancel.litmus', 'weakest_C', 'F'), 'mode C manifest, diag'),
    ('corpus: one files.csv record replaced by a duplicate of another', swap_file_record, 'mode C manifest, corpus'),
    ('diag: mode C composed verdict corrupted in edges.csv, files.csv edge counts rewritten consistently',
     edge_verdict_consistent('diag', 'U-signed-cmp.litmus'), 'diagnostics: reference agrees'),
    ('corpus: files.csv record removed', drop_row('corpus/files.csv', 5), 'mode C manifest, corpus'),
    ('chain: edges.csv record duplicated', dup_row('chain/edges.csv', 3), 'mode C manifest, chain'),
    ('regress: malformed files.csv record', truncate_row('regress/files.csv'), 'mode C manifest, regress'),
    ('corpus: unexpected support status', set_col('corpus/files.csv', 'support', 'SUPPORTED', 'MAYBE'), 'mode C manifest, corpus'),

    # (name, mutation, substring of the check line that must FAIL)
    ('corpus: AGREE -> DISAGREE (records only)', set_col('corpus/ref/ref-pairs.csv', 'agree', 'AGREE', 'DISAGREE'), 'corpus: reference parses 611'),
    ('corpus: AGREE -> DISAGREE (records and summary rewritten consistently)',
     set_col('corpus/ref/ref-pairs.csv', 'agree', 'AGREE', 'DISAGREE',
             summary=('corpus/ref/summary.txt', "('pair', 'AGREE', 'VARIES')", "('pair', 'DISAGREE', 'VARIES')")),
     'corpus: reference parses 611'),
    ('corpus: comparison record removed (records and summary)', drop_row('corpus/ref/ref-pairs.csv', 0,
     summary=('corpus/ref/summary.txt', lambda s: ''.join(l for l in s.splitlines(True) if not l.startswith("('pair'")))),
     'corpus: reference parses 611'),
    ('corpus: comparison record duplicated', dup_row('corpus/ref/ref-pairs.csv'), 'corpus: reference parses 611'),
    ('corpus: unmatched mode C edge added', extra_corpus_edge, 'corpus: reference parses 611'),
    ('corpus: AGREE -> NO_JAVA_EDGE', set_col('corpus/ref/ref-pairs.csv', 'agree', 'AGREE', 'NO_JAVA_EDGE'), 'corpus: reference parses 611'),
    ('corpus: JAVA_ONLY record added', corpus_java_only, 'corpus: reference parses 611'),
    ('corpus: unexpected status UNKNOWN', set_col('corpus/ref/ref-pairs.csv', 'agree', 'AGREE', 'UNKNOWN'), 'corpus: reference parses 611'),
    ('corpus: AGREE record inconsistent (java_composed differs)', set_col('corpus/ref/ref-pairs.csv', 'java_composed', 'VARIES', 'CONST'), 'corpus: reference parses 611'),
    ('corpus: malformed record', truncate_row('corpus/ref/ref-pairs.csv'), 'corpus: reference parses 611'),
    ('corpus: ref-pairs.csv missing', remove('corpus/ref/ref-pairs.csv'), 'corpus: reference parses 611'),
    ('corpus: summary inconsistent with records', drop_summary_pair_line, 'corpus: reference parses 611'),
    ('corpus: duplicate file record', dup_row('corpus/ref/ref-files.csv'), 'corpus: reference parses 611'),
    ('diag: AGREE -> DISAGREE', set_col('diag/ref/ref-pairs.csv', 'agree', 'AGREE', 'DISAGREE'), 'diagnostics: reference agrees'),
    ('diag: comparison record removed', drop_row('diag/ref/ref-pairs.csv', 3), 'diagnostics: reference agrees'),
    ('chain: AGREE -> DISAGREE', set_col('chain/ref/ref-pairs.csv', 'agree', 'AGREE', 'DISAGREE', nth=5), 'chain: reference agrees'),
    ('chain: comparison record duplicated', dup_row('chain/ref/ref-pairs.csv', 9), 'chain: reference agrees'),
    ('mode L diag: no records at all (header only, empty summary)', header_only('diag/affine/affine-pairs.csv', 'diag/affine/affine-summary.txt'), 'mode L, diag'),
    ('mode L chain: AGREE -> DISAGREE', set_col('chain/affine/affine-pairs.csv', 'agree', 'AGREE', 'DISAGREE'), 'mode L, chain: one record'),
    ('mode L chain: record removed (coverage)', drop_row('chain/affine/affine-pairs.csv', 0), 'mode L, chain: one record'),
    ('mode L chain: record duplicated', dup_row('chain/affine/affine-pairs.csv', 0), 'mode L, chain: one record'),
    ('mode L chain: ABSTAIN record claims a decision', set_col('chain/affine/affine-pairs.csv', 'modeL', 'ABSTAIN', 'CONST'), 'mode L, chain: one record'),
    ('chain: recomputed shape tampered', set_col('chain/recount.csv', 'variant', 'chain', 'direct'), 'archived generator metadata'),
    ('chain: recount.csv missing', remove('chain/recount.csv'), 'aborted'),
    ('corpus: files.csv missing', remove('corpus/files.csv'), 'mode C manifest, corpus'),
    ('expression equality chain: EQUAL -> DIFFERENT', set_col('chain/equiv/expr-equiv.csv', 'status', 'EQUAL', 'DIFFERENT'), 'expression equality, chain'),
    ('expression equality corpus: record removed', drop_row('corpus/equiv/expr-equiv.csv', 0), 'expression equality, corpus'),
    ('regression: k=0 pair reported VARIES (arbitrary-initial-state semantics)', set_col('regress/edges.csv', 'composed', 'CONST', 'VARIES'), 'initial registers fixed (Thm 7(d))'),
    ('isabelle: CHECK-RESULT.txt missing', remove('isabelle/CHECK-RESULT.txt'), 'isabelle:'),
    # scope pass 2026-11-08: the per-mode columns of Table 3 (sdep edges kept, cause of F)
    ('Table 3: T+-LB composed mode keeps both edges (edges_fake_C 2 -> 0)',
     set_file_col('diag/files.csv', 'LB-chain-cancel.litmus', 'edges_fake_C', '0'), 'Table 3 row LB-chain-cancel'),
    ('Table 3: LB-copy no-dependency model forbids (cause would be B, not D)',
     set_file_col('diag/files.csv', 'LB-copy.litmus', 'weakest_NODEP', 'F'), 'Table 3 row LB-copy'),
    # memhop repair pass 2026-11-08: each side of the memory-hop contrast, the reference, and the witnesses
    ('memhop: LB-mem-cancel composed labels admit (C F -> A)',
     set_file_col('memhop/files.csv', 'LB-mem-cancel.litmus', 'weakest_C', 'A'), 'memory-hop contrast'),
    ('memhop: LB-mem-cancel no-dependency model forbids (NODEP A -> F)',
     set_file_col('memhop/files.csv', 'LB-mem-cancel.litmus', 'weakest_NODEP', 'F'), 'memory-hop contrast'),
    ('memhop: T+-LB composed labels forbid (C A -> F)',
     set_file_col('memhop/files.csv', 'LB-chain-cancel.litmus', 'weakest_C', 'F'), 'memory-hop contrast'),
    ('memhop: reference pair AGREE -> DISAGREE', set_col('memhop/ref/ref-pairs.csv', 'agree', 'AGREE', 'DISAGREE'),
     'memory-hop reference'),
    ('memhop: witness says C admits the memory-hop candidate',
     lambda o: edit_text(os.path.join(o, 'memhop/witness.txt'),
                         lambda s: s.replace('wf-satisfiable: 1; NODEP-consistent: 1; C-consistent: 0',
                                             'wf-satisfiable: 1; NODEP-consistent: 1; C-consistent: 1')), 'memory-hop witness'),
    ('memhop: witness file missing', remove('memhop/witness.txt'), 'memory-hop witness'),
    ('memhop: coherence probe admits a reload of the initial z',
     lambda o: edit_text(os.path.join(o, 'memhop/witness.txt'),
                         lambda s: s.replace('wf-satisfiable: 4; NODEP-consistent: 0', 'wf-satisfiable: 4; NODEP-consistent: 1')),
     'memory-hop coherence probe'),
    ('memhop: six-model probe says Coh forbids LB-mem-cancel',
     lambda o: edit_text(os.path.join(o, 'memhop/probe-six-models.txt'), lambda s: s.replace(' RA=A ', ' RA=F ')),
     'memory-hop contrast'),
]
if '--require-rings' in EXTRA:
    CASES.append(('rings: full-audit log missing', remove('rings/run-06-corrected.log'), 'rings: full 3,656-ring audit'))

# the documented RINGS=1 workflow defines 70 corruption cases (69 without RINGS=1)
report(len(CASES) == (70 if '--require-rings' in EXTRA else 69), f'{len(CASES)} corruption cases defined')

# ---------------------------------------------------------------- run
rc, so = run(OUT)
report(rc == 0 and '\nFAIL' not in '\n' + so, f'genuine outputs pass (exit {rc})')
os.makedirs(SCR, exist_ok=True)
for i, (name, mut, target) in enumerate(CASES):
    d = os.path.join(SCR, f'neg{i:02d}')
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(OUT, d)
    try:
        alt_base = mut(d)
    except (AssertionError, StopIteration) as ex:
        report(False, f'{name}: mutation could not be applied ({ex})'); continue
    rc, so = run(d, alt_base)
    hit = any(l.startswith('FAIL') and target in l for l in so.splitlines())
    report(rc != 0 and hit, f'{name}: exit {rc}, targeted check {"FAILS" if hit else "still passes"}')
    shutil.rmtree(d, ignore_errors=True)
print(f'\n{fails} failure(s) in {len(CASES) + 1} cases')
sys.exit(1 if fails else 0)
