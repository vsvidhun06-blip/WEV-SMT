"""Recompute the chain population's structural metadata from the generated .litmus inputs.

Usage: python -I recount_chain.py <generated inputs dir> <out csv>

For every input file this parses the single thread from the C text (its own expression
parser, C precedence, left-associative binary operators), and writes one row per
(load, store) pair with:
  id, variant (from the file name), template (file-name prefix), load index k, the
  memory-event ordinals of the load and of the thread's single store,
  assignments (number of register assignments in the thread),
  shape (alpha-renamed, constant-abstracted program hash; the same definition as the
  generator's norm_shape, recomputed here from the text, not read from the archive).
It reads no archived classification. check_numbers.py derives the printed counts from this
file plus the reference's fresh CONST/VARIES verdicts, and separately reports whether the
recomputed shapes equal the archived generator metadata.
"""
import csv, hashlib, json, os, re, sys

TOK = re.compile(r'\s*(0x[0-9a-fA-F]+|\d+|[A-Za-z_]\w*|[-+*^&|~()])')
PREC = {'|': 1, '^': 2, '&': 3, '+': 4, '-': 4, '*': 5}


def tokens(s):
    out, i = [], 0
    s = s.strip()
    while i < len(s):
        m = TOK.match(s, i)
        if not m:
            raise ValueError(f'bad token at {s[i:]!r}')
        out.append(m.group(1)); i = m.end()
    return out


def parse(s):
    ts = tokens(s); pos = [0]

    def peek():
        return ts[pos[0]] if pos[0] < len(ts) else None

    def eat():
        pos[0] += 1; return ts[pos[0] - 1]

    def atom():
        t = eat()
        if t == '(':
            e = expr(0)
            if eat() != ')':
                raise ValueError('missing )')
            return e
        if t in ('-', '~'):
            return ('u', t, atom())
        if re.fullmatch(r'0x[0-9a-fA-F]+|\d+', t):
            return ('c', int(t, 0))
        return ('v', t)

    def expr(minp):
        lhs = atom()
        while peek() in PREC and PREC[peek()] >= minp:
            op = eat(); p = PREC[op]
            rhs = expr(p + 1)
            lhs = ('b', op, lhs, rhs)
        return lhs

    e = expr(0)
    if pos[0] != len(ts):
        raise ValueError(f'trailing tokens in {s!r}')
    return e


def normalize(instrs):
    """Alpha-rename registers by first appearance and abstract constants (generator's definition)."""
    names = {}

    def nm(r):
        names.setdefault(r, f"q{len(names)}"); return names[r]

    def ne(e):
        t = e[0]
        if t == 'c':
            return ('c', 'K')
        if t == 'v':
            return ('v', nm(e[1]))
        if t == 'u':
            return ('u', e[1], ne(e[2]))
        return ('b', e[1], ne(e[2]), ne(e[3]))
    out = []
    for i in instrs:
        if i[0] == 'load':
            out.append(('load', nm(i[1]), i[2]))
        elif i[0] == 'assign':
            out.append(('assign', nm(i[1]), ne(i[2])))
        else:
            out.append(('store', i[1], nm(i[2])))
    return hashlib.sha256(json.dumps(out).encode()).hexdigest()[:16]


LOAD = re.compile(r'^\s*(\w+)\s*=\s*READ_ONCE\(\*(\w+)\);\s*$')
STORE = re.compile(r'^\s*WRITE_ONCE\(\*(\w+),\s*(\w+)\);\s*$')
ASGN = re.compile(r'^\s*(\w+)\s*=\s*(.+);\s*$')


def thread(path):
    instrs, inbody = [], False
    for line in open(path, encoding='utf-8'):
        if line.startswith('P0('):
            inbody = True; continue
        if not inbody:
            continue
        if line.startswith('}'):
            break
        if not line.strip():
            continue
        m = LOAD.match(line)
        if m:
            instrs.append(('load', m.group(1), m.group(2))); continue
        m = STORE.match(line)
        if m:
            instrs.append(('store', m.group(1), m.group(2))); continue
        m = ASGN.match(line)
        if m:
            instrs.append(('assign', m.group(1), parse(m.group(2)))); continue
        raise ValueError(f'{path}: unparsed line {line!r}')
    return instrs


def main():
    ind, outp = sys.argv[1], sys.argv[2]
    with open(outp, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['id', 'variant', 'template', 'k', 'load_ord', 'store_ord', 'assignments', 'shape'])
        for fn in sorted(os.listdir(ind)):
            if not fn.endswith('.litmus'):
                continue
            iid = fn[:-len('.litmus')]
            ins = thread(os.path.join(ind, fn))
            variant = 'chain' if iid.endswith('-chain') else ('direct' if iid.endswith('-direct') else 'control')
            m = re.match(r'^(.*)-L\d+-d\d+-(chain|direct)$', iid)
            template = m.group(1) if m else iid
            nas = sum(1 for i in ins if i[0] == 'assign')
            shape = normalize(ins)
            # memory-event ordinals (loads and stores in program order), as the reference numbers them
            mem = [i[0] for i in ins if i[0] in ('load', 'store')]
            lords = [n for n, t in enumerate(mem) if t == 'load']
            sords = [n for n, t in enumerate(mem) if t == 'store']
            if len(sords) != 1:
                raise ValueError(f'{fn}: expected exactly one store, found {len(sords)}')
            for k, lo in enumerate(lords):
                w.writerow([iid, variant, template, k, lo, sords[0], nas, shape])


if __name__ == '__main__':
    main()
