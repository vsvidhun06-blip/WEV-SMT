"""Sensitivity test for refcheck/expr_equiv.py.

Usage: python -I test_expr_equiv.py <OUT/diag> <inputs/diag> <OUT/lists/diag.txt> <scratch dir>

Copies the prototype's diagnostic outputs, perturbs the printed composed expression of single
edges in ways that change the 32-bit value on every input (+1, bitwise complement, + 2^31, xor 1), reruns expr_equiv.py on the copy, and requires exactly the perturbed edges to
be reported DIFFERENT and every other edge EQUAL. One perturbation that does NOT change the
function (adding 0) must stay EQUAL. The genuine outputs are never written.
"""
import csv, os, shutil, subprocess, sys

JOUT, INP, LST, SCR = sys.argv[1:5]
HERE = os.path.dirname(os.path.abspath(__file__))
EQ = os.path.join(os.path.dirname(HERE), 'refcheck', 'expr_equiv.py')
fails = 0


def report(ok, msg):
    global fails
    print(('PASS  ' if ok else 'FAIL  ') + msg)
    fails += not ok


rd = list(csv.reader(open(os.path.join(JOUT, 'edges.csv'), encoding='utf-8', newline='')))
head, body = rd[0], rd[1:]
ci = head.index('composed_expr')
shutil.rmtree(SCR, ignore_errors=True)
g = subprocess.run([sys.executable, '-I', EQ, JOUT, INP, LST, os.path.join(SCR, 'genuine')], capture_output=True, text=True)
gen = {(r['file'], r['read_id'], r['write_id']): r['status']
       for r in csv.DictReader(open(os.path.join(SCR, 'genuine', 'expr-equiv.csv'), encoding='utf-8'))}
report(g.returncode == 0 and gen and all(v == 'EQUAL' for v in gen.values()), f'genuine copy: all {len(gen)} edges EQUAL')
fi, ri, wi = head.index('file'), head.index('read_id'), head.index('write_id')
seen_store, picked = set(), []
for i, r in enumerate(body):  # one edge per store, so each perturbation affects only its own record
    if (r[fi], r[ri], r[wi]) in gen and (r[fi], r[wi]) not in seen_store and sum(
            1 for x in body if (x[fi], x[wi]) == (r[fi], r[wi])) == 1:
        seen_store.add((r[fi], r[wi])); picked.append(i)
assert len(picked) >= 5, 'not enough edges to perturb'
# (row index, new expression, should differ)
cases = [(picked[0], lambda e: f'({e}) + 1', True),
         (picked[1], lambda e: f'~({e})', True),
         (picked[2], lambda e: f'({e}) + 0x80000000', True),
         (picked[3], lambda e: f'({e}) ^ 1', True),
         (picked[4], lambda e: f'({e}) + 0', False)]
d = os.path.join(SCR, 'jout')
shutil.copytree(JOUT, d)
mut = [list(r) for r in body]
for i, f, _ in cases:
    mut[i][ci] = f(mut[i][ci])
with open(os.path.join(d, 'edges.csv'), 'w', encoding='utf-8', newline='') as fh:
    w = csv.writer(fh); w.writerow(head); w.writerows(mut)
# a perturbation applies to every edge that shares the same store: compare per (file, write_id)
p = subprocess.run([sys.executable, '-I', EQ, d, INP, LST, os.path.join(SCR, 'res')], capture_output=True, text=True)
report(p.returncode == 0, f'expr_equiv.py ran on the perturbed copy (exit {p.returncode})')
res = {(r['file'], r['read_id'], r['write_id']): r['status']
       for r in csv.DictReader(open(os.path.join(SCR, 'res', 'expr-equiv.csv'), encoding='utf-8'))}
hi = head.index
for i, f, differ in cases:
    r = mut[i]; k = (r[hi('file')], r[hi('read_id')], r[hi('write_id')])
    want = 'DIFFERENT' if differ else 'EQUAL'
    report(res.get(k) == want, f'perturbed edge {k}: {body[i][ci]!r} -> {r[ci]!r}: {res.get(k)} (expected {want})')
touched = {(mut[i][hi('file')], mut[i][hi('read_id')], mut[i][hi('write_id')]) for i, _, d_ in cases if d_}
others = [s for k, s in res.items() if k not in touched]
report(all(s == 'EQUAL' for s in others) and len(others) == len(res) - len(touched),
       f'all {len(others)} unperturbed edges stay EQUAL')
print(f'\n{fails} failure(s)')
sys.exit(1 if fails else 0)
