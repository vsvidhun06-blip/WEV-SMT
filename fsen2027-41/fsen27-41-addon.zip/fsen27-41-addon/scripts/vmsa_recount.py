"""Verify the VMSA exclusion from file contents and recompute corpus totals.
Usage: python -I vmsa_recount.py <corpus_litmus_dir> <eligible list> <corrected-symbolic.csv> [<fresh files.csv>]"""
import csv, re, sys, collections, os
base, listf, symf = sys.argv[1:4]
fresh = {r['file']: r for r in csv.DictReader(open(sys.argv[4], encoding='utf-8'))} if len(sys.argv) > 4 else {}
elig = [l.strip() for l in open(listf, encoding='utf-8') if l.strip()]
PT = re.compile(r'\bpte_\w+|\bPTE\s*\(|\bTLBI\b|\bPA\s*\(|\bAF\s*:|\bDB\s*:|\bvalid\s*:')
rows = []
for f in elig:
    src = open(os.path.join(base, f), encoding='utf-8', errors='replace').read()
    hits = sorted(set(m.group(0) for m in PT.finditer(src)))
    rows.append((f, 'aarch64-VMSA' in f, hits))
indir = [r for r in rows if r[1]]; content = [r for r in rows if r[2]]
print('eligible files', len(elig))
print('in aarch64-VMSA directory', len(indir), '; with page-table tokens', len(content),
      '; both', sum(1 for r in rows if r[1] and r[2]))
for f, d, h in rows:
    if d or h: print('  ', 'DIR' if d else '   ', f, h)
sym = collections.defaultdict(dict)
for r in csv.DictReader(open(symf, encoding='utf-8')):
    sym[r['file']][r['model']] = r['verdict']
vm_dir = {r[0] for r in rows if r[1]}; vm_tok = {r[0] for r in rows if r[2]}
for label, files in (('all eligible', elig), ('excluding 11 page-table-token files', [f for f in elig if f not in vm_tok]),
                     ('excluding 16 aarch64-VMSA directory files', [f for f in elig if f not in vm_dir])):
    t = collections.Counter()
    for f in files:
        for m, v in sym[f].items(): t[(m, v)] += 1
    print(label, len(files), {m: f"{t[(m,'ALLOWED')]}/{t[(m,'FORBIDDEN')]}" for m in ('SC','TSO','PSO','RA','WEAKEST','RC11')})
    if fresh:
        src = collections.Counter()
        for f in files:
            r = fresh.get(f)
            if not r or not r['weakest_B']: src['no-fresh-verdict'] += 1; continue
            if r['weakest_B'] == 'A': src['WEAKEST allowed'] += 1
            elif r['wf'] == 'U': src['(W) well-formedness unsatisfiable'] += 1
            elif r['weakest_NODEP'] == 'F': src['(B) base forbids'] += 1
            else: src['(D) dependency only'] += 1
        print('   fresh source split:', dict(src))
        mism = [f for f in files if fresh.get(f, {}).get('weakest_B') and
                {'A': 'ALLOWED', 'F': 'FORBIDDEN'}[fresh[f]['weakest_B']] != sym[f]['WEAKEST']]
        print('   fresh WEAKEST vs archived symbolic mismatches:', len(mism), mism[:5])
    print('   (W) files:', [f for f in files if fresh.get(f, {}).get('wf') == 'U'] if fresh else 'n/a')
