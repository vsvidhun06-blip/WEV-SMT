"""Recompute the ring-expression classes from the candidate JSON with refcheck's own evaluator.
Usage: python -I classify_rings.py <refcheck_dir> <generated-hard-candidates.json> <symbolic-ring-audit.csv>"""
import sys, json, csv, random, collections
sys.path.insert(0, sys.argv[1]); import refcheck as R
exprs = json.load(open(sys.argv[2], encoding='utf-8'))
audit = collections.defaultdict(dict)
for r in csv.DictReader(open(sys.argv[3], encoding='utf-8')):
    audit[r['expr']][r['threads']] = r
rng = random.Random(1); c = collections.Counter(); rows = []
def subst(e):
    if e[0] == 'var': return ('sym', e[1])
    if e[0] == 'un': return ('un', e[1], subst(e[2]))
    if e[0] == 'bin': return ('bin', e[1], subst(e[2]), subst(e[3]))
    return e
for s in exprs:
    e = subst(R.parse_expr(s)); v = sorted(R.syms(e, set()))
    assert v in (['r'], []), (s, v)
    e0 = R.ev(e, {'r': 0}, 32); e1 = R.ev(e, {'r': 1}, 32)
    nc = R.decide(e, 'r', 32, rng)[0] == 'VARIES' if v else False
    cls = ('e0=1' if e0 == 1 else 'e0!=1', 'e1=1' if e1 == 1 else 'e1!=1', 'nonconst' if nc else 'const')
    c[cls] += 1
    a = audit.get(s, {})
    rows.append([s, e0, e1, nc, a.get('2', {}).get('value_consistency'), a.get('2', {}).get('weakest'), a.get('2', {}).get('oracle_constant')])
    if cls == ('e0=1', 'e1=1', 'nonconst'):
        c[('110-class audit2', a.get('2', {}).get('value_consistency'), a.get('2', {}).get('weakest'))] += 1
print('total', len(exprs))
for k in sorted(c, key=str): print(k, c[k])
csv.writer(open('ring-classes.csv', 'w', newline='', encoding='utf-8')).writerows([['expr', 'e0', 'e1', 'nonconst', 'audit2_value', 'audit2_weakest', 'audit2_oracle_constant']] + rows)
