# Add-on artifact: composed-label mode, version-aware closure theorem, re-executed checks

This add-on extends the base artifact `tacas2027-4549-artifact-corrected-v1.zip` (SHA-256 `45e434df4825e2e7f47178d97109583b7300bea6b1562612c5562983359429af`). It modifies no file of the base artifact. It compiles its two drivers against the base artifact's pinned corrected classes, and checks the classes hash first.

## Contents
- `impl/src/wev/smt/cli/ComposedLabelRun.java`: runs the three dependency modes on a list of litmus files:
  - A: folding closure;
  - B: exact per-instruction closure;
  - C: composed labels, with every initial register bound to its declared value (0 if undeclared).

  It also computes well-formedness-only, all-semantic and no-dependency verdicts. It writes `files.csv` (a support/exclusion manifest with reasons), `edges.csv` (per data edge: the A/B/C decisions and the composed expression) and `events.csv`.
- `impl/src/wev/smt/cli/LbProbe.java`: the six encoded models plus the well-formedness-only query on the LB programs.
- `impl/src/wev/smt/cli/MemhopWitness.java`, `impl/run_witness.sh` (memhop pass 2026-11-08): for each litmus file, every assignment of one rf source per read, checked for well-formedness, for WEAKEST with sdep = {} (NODEP) and for WEAKEST with mode C's sdep (C); the Z3 model of each NODEP-consistent candidate; and, where NODEP admits and C forbids, a cycle in sdep ∪ rf. The cycle search is this driver's own DFS over the tool's edge sets. NODEP and C use the same encoder and formula; in the corrected build the dependency set enters only acyclic(sdep ∪ rf), so they differ only in sdep.
- `refcheck/refcheck.py`: the independent reference. It has its own parser, symbolic executor and evaluator, and fixes initial registers the same way.
  - "varies" verdicts are witnessed and re-evaluated without a solver;
  - "constant" verdicts come from Z3 over the reference's own encoding, plus 8-bit exhaustive and 32-bit random corroboration.

  It parses C-syntax litmus only.
- `refcheck/expr_equiv.py`: for every data edge in a file both tools parse, checks that the prototype's composed expression and the reference's are the same 32-bit function. Z3 must prove their difference unsatisfiable (shared solver), and 2,000 random evaluations must agree. This tests the two implementations against each other; it does not prove either equal to the Isabelle label.
- `refcheck/affine_mode.py`: mode L, the ring-weighted closure, run on the diagnostics and the chain population and compared with the reference.
- `formal/`: `PwT_Versioned.thy`, `PwT_Affine.thy`, `PwT_Block.thy`, `PwT_Correspondence.thy` and `Rev_Check.thy`.
  - They cover the version-aware closure theorem, the ring-weighted closure and its capacity theorem, and the block-summary theorem.
  - `PwT_Correspondence.thy` proves that Cousot's ordered composition (SAS 2019, rules 10 and 16.b) equals `vdep`, with the overwrite regression `y:=x; y:=w`. It also proves the fixed-initial-state bridge `esdep_at`/`label_at` and the regression `load r; t:=r*k; store t`.
  - `Rev_Check.thy` checks all 73 Isabelle facts the paper cites, across 14 theories (`PwT_Remarks.thy` adds the 2^64 / 2^32 cardinalities of Thms 3(c) and 6(c), single-instruction exactness of the closure, SRI-not-necessary and closure masking), for oracles and ancestry. It writes `CHECK-RESULT.txt`.
  - They build on the base session `WEV_SMT_PwT`.
- `inputs/diag/`: 7 LB programs and 14 unit cases.
- `inputs/regress/`: three initial-register regressions (`k` declared 0, declared 1, undeclared).
- `inputs/memhop/`: the memory-hop contrast, kept out of every corpus, population and ring count. `LB-mem-cancel.litmus` (the referee's program, SHA-256 `d53c2ef2…0c1d`: P0 loads y, stores r+1 to z, reloads z and stores u−r to x; P1 copies x to y; outcome r0=r1=1) and `LB-chain-cancel.litmus` (T+-LB, the same file as in `inputs/diag/`). `inputs/memhop-probe/LB-mem-cancel-cohcheck.litmus` asks whether the reload of z can read the initial 0.
  - Expected: T+-LB C = A, NODEP = A, both edges CONST. LB-mem-cancel wf = R, A/B/C = F/F/F, NODEP = A (cause D), 4 data edges all VARIES (load y → store x is `((R25)-(R21))`); reference agrees on all 6 pairs; one of 8 rf assignments is well-formed, NODEP admits it (Z3 model: load y 1, store z 2, reload 2, store x 1) and C forbids it with the cycle `ld y –sdep→ st x –rf→ ld x –sdep→ st y –rf→ ld y`; six-model probe: reachable, RA (Coh) = A, RC11 = F, WEAKEST = F. Coherence probe: the 4 candidates in which the reload reads the initial z are well-formed but NODEP-inconsistent.
  - Reproduce just this: `PKGROOT=<base> WORK=<scratch> bash impl/run_witness.sh inputs/memhop/*.litmus inputs/memhop-probe/*.litmus`.
- `extcompare/`: the bounded LLVM known-bits comparison (inputs, script, raw output; see its README). Not run by `run_all.sh`.
- `scripts/`:
  - `check_numbers.py`: asserts the paper's experimental numbers from the outputs of this run (84 checks with `RINGS=1`). It reads per-record CSV files, not only summaries, and fails on any disagreement, missing, duplicate or malformed record, unexpected status, unmatched edge, or summary that does not match its records. Mode C's own manifests (`files.csv`, `edges.csv`) are audited strictly for every input set: one record per listed input, no duplicate, and per-file edge counts equal to the edge records. Every mode C edge is re-joined to its reference pair independently of `refcheck.py`, and its composed verdict, re-read from `edges.csv`, must equal the reference's. Each edge's `composed_expr` must parse with the reference's parser and mention only that file's load symbols, and its recorded verdict is **re-decided from the recorded expression** twice: by the reference's decision procedure (`refcheck.decide`, which uses Z3 for constant verdicts) and by `semcheck.py`, which uses no solver. Both start from the expression mode C wrote, so they check the verdict, not the front end that built it; the expression is rebuilt from source by a separate front end only where the reference parses the input (C syntax: 6 regression, 38 diagnostic, 314 population and 1 corpus edge), and `expr_equiv.py` then proves the two expressions equal. Evidence per verdict: all 202 VARIES have a concrete 32-bit witness; 462 of the 482 CONST are proved by exact normalisation; the other 20 (population masking expressions) are only tested; the reference's Z3 proof covers all 482 CONST. A record whose expression no longer fits its verdict fails. The input identity (hash of the base manifest, pinned, and of this add-on's manifest) is recorded by `run_all.sh` in `OUT/inputs-identity.txt` and checked, so outputs from a different base or add-on version fail. The corpus accounting numbers (raw, byte-distinct and normalised counts, changed tests) are asserted and the key ones recomputed independently. Each verdict's evidence columns must name the evidence the paper claims (Z3 + 8-bit exhaustive + 32-bit random for constant, a witness for varying, Z3 + 2,000 random evaluations for expression equality). The rings are checked per expression against the archived audit, not only as counts. Identity pins (recorded from the validated run) fix which 611 files the reference parses, which 4 corpus edges are real, and each diagnostic pair's verdict. A missing output fails the run, and so does a missing ring log when `RINGS=1`; without `RINGS=1` the ring re-execution check is skipped, which is why `run_all.sh` passes `--require-rings` whenever `RINGS=1`.
  - **What the checks do not guarantee.** They detect inconsistent, incomplete, duplicated or relabelled outputs. They are not a defence against a deliberately forged, fully consistent set of outputs, and `check_numbers.py` cannot re-check Isabelle proofs (it reads the `CHECK-RESULT.txt` written by this run's Isabelle step, which deletes any old copy first). The assurance comes from `run_all.sh` regenerating every output from the hashed archives in the same run.
  - `test_check_numbers.py`: requires the genuine outputs to pass and 70 corrupted copies to fail on the targeted check (69 without `--require-rings`). These include the bypasses that two AI-reviewer passes found in earlier versions of the checker: contradictory duplicate records, substituted records, corrupted or coherently relabelled verdicts, removed evidence, duplicated probe blocks, falsified recount and proof-result files, and swapped ring classes. The 2026-11-06 repair pass added: an edge expression changed so it no longer fits its kept verdict (corpus edge outside the reference's files, which the previous checker accepted; chain CONST and VARIES; diagnostic), a stale identity record, a wrong base archive, an unexpected file record, a truncated edge file and a stale accounting summary. The 2026-11-08 scope pass added two cases for the per-mode columns of the paper's Table 3 (data edges kept in sdep, cause of each F), which `check_numbers.py` now asserts together with the split of Table 2 into edges and pairs without a syntactic edge. The 2026-11-08 memhop pass added eight cases: LB-mem-cancel C F→A, NODEP A→F, T+-LB C A→F, a reference disagreement, a witness file claiming C admits, a missing witness file, a coherence probe that admits the initial-z reload, and a six-model probe claiming Coh forbids. The checks print the paper's table numbers (Table 2: constructed population; Table 3: load buffering).
  - `semcheck.py`: solver-free validator. Own tokenizer, parser and 32-bit evaluator; no code shared with the prototype, the reference or Z3. VARIES needs a concrete 32-bit witness; CONST fails on any variation found by a deterministic 32-bit search or by exhaustive width-8 enumeration (lifted to 32 bits and re-evaluated; used only for comparison-free expressions with at most one other symbol), and counts as *proved* only where exact rewriting (ring normal form modulo 2^32, a^a=0, idempotence, constant masks) removes the load symbol. Otherwise CONST is only corroborated. On the validated run: corpus 322/322 fakes proved, chain 123 proved and 20 corroborated only, diagnostics 15 proved, regression 2 proved.
  - `test_semcheck.py`: fixed cases, a randomised soundness test of the rewriting proof (seed 20261106), mutation sensitivity, and acceptance of every recorded verdict.
  - `corpus_accounting.py`: writes `OUT/corpus/accounting/{accounting.txt,changed-tests.csv,duplicates.csv}`: raw, byte-distinct and normalised-distinct counts, edges and shapes, and every file whose verdict changes between two configurations (A vs B, B vs C, B vs ALL, NODEP vs B).
  - `test_expr_equiv.py`: perturbs composed expressions and requires the equality check to detect each perturbation.
  - `recount_chain.py`: recomputes the chain population's structure (shapes, assignment counts, templates, event ordinals) from the `.litmus` text.
  - `vmsa_recount.py`, `compare_archived.py`, `classify_rings.py`.
- `run_all.sh`: the driver.
- `SHA256SUMS`: hashes of every other file in this add-on. Before running anything, the driver checks it and the base artifact's own manifest.

## What the run establishes, and what it does not
- **Re-executed by this run:**
  - Isabelle build and oracle/ancestry check;
  - modes A, B and C, the reference and expression equality on all input sets; mode L on the diagnostics and the chain population only;
  - the six-model probe;
  - the memory-hop contrast (modes A/B/C, reference, witnesses, six-model probe), separate from all counts;
  - the ring expression classes;
  - with `RINGS=1`, the full 3,656-ring audit;
  - the checks of the checks.
- **Recomputed from archived inputs:**
  - the chain population's structure, from the archived `.litmus` files;
  - the corpus verdicts, from the archived corpus files.
- **Compared with archived metadata, not independent of it:**
  - the generator's labels (`pairs-final.csv`), checked against the fresh reference verdicts and the recomputed structure;
  - the corpus SDEP verdicts, checked against the base artifact's recorded symbolic verdicts;
  - the ring counts 385 and 110, computed from the archived ring audit, which the `RINGS=1` re-execution reproduces row for row.
- **Corpus exclusion:** the 16 excluded files are selected by directory (`aarch64-VMSA`). A token scan finds page-table constructs in 11 of them. Mode C rejects a file for `VMSA_PAGE_TABLE` if its path contains `aarch64-VMSA` or its text contains `pte_`.
- **Not checked by this artifact:** the Promising comparison (including the derivation that Promising admits LB-mem-cancel's outcome), the multi-thread criterion and the encoder's adequacy (hand derivations), literature claims, and the external LLVM comparison (archived in `extcompare/`, not re-run).

## Run
```
unzip tacas2027-4549-artifact-corrected-v1.zip -d base
unzip fsen27-41-addon.zip
BASE=$PWD/base/tacas2027-4549-artifact-corrected-v1 WORK=$PWD/work OUT=$PWD/out \
  ISABELLE_HOME=<Isabelle2024> RINGS=1 bash fsen27-41-addon/run_all.sh
```
The driver exits non-zero if any step or check fails. `OUT/run_all.log` records versions, steps and timings. After the last log line, `OUT/SHA256SUMS` hashes every output. Without `ISABELLE_HOME`, the Isabelle step is skipped and the Isabelle check in `check_numbers.py` fails, so a passing run needs Isabelle.

Tested on Windows 11 (Git Bash, JDK 21.0.10, Python 3.11, z3-solver 5.0.0, Isabelle2024). The Isabelle step calls Isabelle's bundled Cygwin bash, so on Linux adapt `isa_build` to call `isabelle build` directly. **The driver has not been run on Linux or macOS.**

On Windows, extract to a short directory. The base artifact's deepest file sits about 180 characters below `BASE`, and Python fails on paths of 260 characters or more; `run_all.sh` refuses up front if any path is too long.

On a machine with little free memory, set `ISABELLE_EXTRA_OPTS="-o threads=1"` to run Isabelle single-threaded. The driver already runs every step sequentially.

Runtime: about 10 min for the corpus, 10 min for `RINGS=1`, 1 min for Isabelle, and a few minutes for the negative tests.

## Known limitations
- Mode C rejects address, control, RMW and page-table inputs. It does not decide them.
- The reference shares Z3 with the prototype for "constant" verdicts and for the equality proofs. The random evaluations are solver-free.
- The reference parses only C-syntax tests. The corpus assembly tests are cross-checked only by folding vs oracle, and those two share the prototype's parser and front end.
