#!/usr/bin/env bash
# Compile MemhopWitness (with the unchanged ComposedLabelRun) against the pinned CORRECTED v1 classes and run it.
# For each litmus file: every assignment of one rf source per read, checked for well-formedness, for WEAKEST with
# sdep = {} (NODEP) and for WEAKEST with mode C's sdep (C); Z3 models of the NODEP-consistent candidates; and, where
# NODEP admits and C forbids, a cycle in sdep U rf found by the driver's own DFS over the tool's edge sets.
# Usage: PKGROOT=<extracted artifact> WORK=<scratch> bash run_witness.sh <litmus>...
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKGROOT:?}"; : "${WORK:?}"
source "$PKGROOT/reproduce/common.sh"
setup_java_env
select_impl corrected
[ "$(classes_hash "$IMPL_CLASSES")" = "$IMPL_PIN_CLASSES" ] || { echo "FAIL classes hash != pin" >&2; exit 2; }
echo "impl: $IMPL_LABEL  classes ${IMPL_PIN_CLASSES:0:12}"
"$JAVA" -version 2>&1 | head -1
OUT="$WORK/witness-classes"; rm -rf "$OUT"; mkdir -p "$OUT"
"$JAVAC" -proc:none -encoding UTF-8 -d "$(w "$OUT")" -cp "$(w "$IMPL_CLASSES")$SEP$DEPS_CP" \
  "$(w "$HERE/src/wev/smt/cli/ComposedLabelRun.java")" "$(w "$HERE/src/wev/smt/cli/MemhopWitness.java")"
args=(); for f in "$@"; do args+=("$(w "$f")"); done
"$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$(w "$OUT")$SEP$(w "$IMPL_CLASSES")$SEP$DEPS_CP" wev.smt.cli.MemhopWitness "${args[@]}"
