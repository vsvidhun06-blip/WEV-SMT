#!/usr/bin/env bash
# Run LbProbe (all six encoded models + well-formedness-only) on litmus files, corrected build.
# Usage: PKGROOT=<extracted artifact> WORK=<scratch> bash run_probe.sh <litmus>...
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKGROOT:?}"; : "${WORK:?}"
source "$PKGROOT/reproduce/common.sh"
setup_java_env
select_impl corrected
[ "$(classes_hash "$IMPL_CLASSES")" = "$IMPL_PIN_CLASSES" ] || { echo "FAIL classes hash != pin" >&2; exit 2; }
OUT="$WORK/probe-classes"; rm -rf "$OUT"; mkdir -p "$OUT"
"$JAVAC" -proc:none -encoding UTF-8 -d "$(w "$OUT")" -cp "$(w "$IMPL_CLASSES")$SEP$DEPS_CP" "$(w "$HERE/src/wev/smt/cli/LbProbe.java")"
args=(); for f in "$@"; do args+=("$(w "$f")"); done
"$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$(w "$OUT")$SEP$(w "$IMPL_CLASSES")$SEP$DEPS_CP" wev.smt.cli.LbProbe "${args[@]}" 2> "$WORK/probe.stderr"
