#!/usr/bin/env bash
# Compile ComposedLabelRun against the pinned CORRECTED v1 classes (unmodified) and run it.
# Usage: PKGROOT=<extracted artifact> WORK=<scratch> bash run_composed.sh <outDir> <listFile> <baseDir>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKGROOT:?set PKGROOT to the extracted artifact root}"
: "${WORK:?set WORK to a scratch dir}"
source "$PKGROOT/reproduce/common.sh"
setup_java_env
select_impl corrected
[ "$(classes_hash "$IMPL_CLASSES")" = "$IMPL_PIN_CLASSES" ] || { echo "FAIL corrected classes hash != pin" >&2; exit 2; }
echo "impl: $IMPL_LABEL  classes ${IMPL_PIN_CLASSES:0:12}"
OUTC="$WORK/composed-classes"; rm -rf "$OUTC"; mkdir -p "$OUTC"
"$JAVAC" -proc:none -encoding UTF-8 -d "$(w "$OUTC")" -cp "$(w "$IMPL_CLASSES")$SEP$DEPS_CP" \
  "$(w "$HERE/src/wev/smt/cli/ComposedLabelRun.java")"
"$JAVA" -version 2>&1 | head -1
"$JAVA" "-Djava.library.path=$NATIVE_DIR" -cp "$(w "$OUTC")$SEP$(w "$IMPL_CLASSES")$SEP$DEPS_CP" \
  wev.smt.cli.ComposedLabelRun "$(w "$1")" "$(w "$2")" "$(w "$3")"
