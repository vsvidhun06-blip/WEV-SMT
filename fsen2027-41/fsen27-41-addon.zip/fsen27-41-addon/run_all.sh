#!/usr/bin/env bash
# Re-execute the checks reported for the composed-label mode, the formal development, expression
# equality, mode L, the corpus recount and the rings, assert the reported numbers
# (check_numbers.py), and test that those assertions fail on corrupted outputs. Every output under
# $OUT is produced by this run; which archived data is compared is listed in README.md.
#
# Usage:
#   BASE=<extracted base artifact (tacas2027-4549-artifact-corrected-v1)>
#   WORK=<scratch dir>   OUT=<results dir>
#   [ISABELLE_HOME=<Isabelle2024>]  (Isabelle step skipped if unset)
#   [ISABELLE_EXTRA_OPTS="-o threads=1"]  (optional extra build options, e.g. to limit memory)
#   [RINGS=1]                       (full 3,656-ring audit, ~10 min; otherwise skipped)
#   bash run_all.sh
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${BASE:?}"; : "${WORK:?}"; : "${OUT:?}"
mkdir -p "$WORK" "$OUT"
LOG="$OUT/run_all.log"; : > "$LOG"
say() { echo "$*" | tee -a "$LOG"; }
FAILS=0; step() { local name="$1"; shift; local t0=$(date +%s); say "== $name"; if "$@" >>"$LOG" 2>&1; then say "   ok ($(( $(date +%s)-t0 ))s)"; else say "   FAILED ($(( $(date +%s)-t0 ))s)"; FAILS=$((FAILS+1)); fi; }

say "date: $(date -u +%FT%TZ)"; say "host: $(uname -a)"
say "java: $(java -version 2>&1 | head -1)"; say "python: $(python -V 2>&1)"
say "isabelle extra options: ${ISABELLE_EXTRA_OPTS:-(none)}"
say "z3 (python): $(python -I -c 'import z3;print(z3.get_version_string())' 2>&1)"

# Windows: Python's file APIs fail on paths of 260+ characters (MAX_PATH); the deepest base
# file is ~180 characters below BASE, so refuse a deep BASE instead of failing mid-run.
LONGEST=$(python -I -c "import os,sys;b=os.path.abspath(sys.argv[1]);print(max(len(os.path.join(r,f)) for r,_,fs in os.walk(b) for f in fs))" "$BASE")
if [ "$LONGEST" -ge 260 ] && [ "$(uname -s | cut -c1-5)" != Linux ]; then
  say "REFUSED: longest path under BASE is $LONGEST characters (Windows limit 259); extract to a shorter directory"; exit 1
fi
say "longest path under BASE: $LONGEST"

# 0. base artifact integrity (its own manifest) and identity
step "base manifest" bash -c "cd '$BASE' && sha256sum -c --quiet SHA256SUMS"
step "add-on manifest" bash -c "cd '$HERE' && sha256sum -c --quiet SHA256SUMS"
# identity of the inputs this OUT is produced from (check_numbers.py compares it with BASE and this add-on)
{ echo "base manifest sha256: $(sha256sum "$BASE/SHA256SUMS" | cut -d' ' -f1)"
  echo "add-on manifest sha256: $(sha256sum "$HERE/SHA256SUMS" | cut -d' ' -f1)"; } > "$OUT/inputs-identity.txt"

# 1. Isabelle: Thm (version-aware closure) + oracle/ancestry check
if [ -n "${ISABELLE_HOME:-}" ]; then
  conv() { printf '%s' "$1" | sed -E 's#^/([a-zA-Z])/#/cygdrive/\1/#'; }
  isa_build() {
    rm -f "$HERE/formal/CHECK-RESULT.txt"
    MSYS2_ENV_CONV_EXCL=USER_HOME "$ISABELLE_HOME/contrib/cygwin/bin/bash.exe" --login -c \
      "cd $(conv "$HERE/formal") && $(conv "$ISABELLE_HOME")/bin/isabelle build -c -o timeout=900 ${ISABELLE_EXTRA_OPTS:-} -d $(conv "$BASE/isabelle") -d . WEV_SMT_Rev" &&
    grep -q 'oracles over 73 theorems: none' "$HERE/formal/CHECK-RESULT.txt" &&
    grep -q '^ancestry: OK' "$HERE/formal/CHECK-RESULT.txt" &&
    ! grep -n -E '^[[:space:]]*(sorry|oops|axiomatization)\b|by[[:space:]]+sorry' "$HERE"/formal/*.thy &&
    mkdir -p "$OUT/isabelle" && cp "$HERE/formal/CHECK-RESULT.txt" "$OUT/isabelle/"
  }
  step "isabelle WEV_SMT_Rev (+Rev_Check)" isa_build
else
  say "SKIP isabelle (ISABELLE_HOME unset)"
fi

# 2. lists
mkdir -p "$OUT/lists"
ls "$HERE/inputs/diag" > "$OUT/lists/diag.txt"
ls "$HERE/inputs/regress" > "$OUT/lists/regress.txt"
ls "$HERE/inputs/memhop" > "$OUT/lists/memhop.txt"
( cd "$BASE/chain-composition/results/generated/inputs" && ls *.litmus ) > "$OUT/lists/chain.txt"
awk -F, 'NR>1 && $2=="SC"{print $1}' "$BASE/results/corrected-v1/reference/reference-verdicts.csv" > "$OUT/lists/corpus.txt"

# 3. mode C (+A, B, all-semantic, no-dependency, well-formedness) and the independent reference
run_set() {  # name inputs_dir
  PKGROOT="$BASE" WORK="$WORK/$1" bash "$HERE/impl/run_composed.sh" "$OUT/$1" "$OUT/lists/$1.txt" "$2" &&
  python -I "$HERE/refcheck/refcheck.py" "$OUT/$1" "$2" "$OUT/lists/$1.txt" "$OUT/$1/ref"
}
step "mode C + reference: diagnostics" run_set diag "$HERE/inputs/diag"
step "mode C + reference: initial-register regressions" run_set regress "$HERE/inputs/regress"
step "mode C + reference: chain population" run_set chain "$BASE/chain-composition/results/generated/inputs"
step "mode C + reference: corpus (2,396 files, ~10 min)" run_set corpus "$BASE/corpus/litmus"
# 3a. memory-hop contrast (memhop repair pass 2026-11-08): T+-LB (register-only cancellation) against LB-mem-cancel
# (the same cancellation through a write and a coherence-forced reload). Kept apart from the corpus and ring counts.
step "memory-hop contrast: mode C + reference" run_set memhop "$HERE/inputs/memhop"
step "memory-hop witnesses (rf enumeration, models, cycle)" bash -c "PKGROOT='$BASE' WORK='$WORK/witness' bash '$HERE/impl/run_witness.sh' \
  '$HERE/inputs/memhop/LB-chain-cancel.litmus' '$HERE/inputs/memhop/LB-mem-cancel.litmus' \
  '$HERE/inputs/memhop-probe/LB-mem-cancel-cohcheck.litmus' > '$OUT/memhop/witness.txt'"
step "memory-hop six-model probe" bash -c "PKGROOT='$BASE' WORK='$WORK/probe-memhop' bash '$HERE/impl/run_probe.sh' '$HERE/inputs/memhop/LB-mem-cancel.litmus' > '$OUT/memhop/probe-six-models.txt'"
# 3b. mode L: the ring-weighted closure (PwT_Affine.wdep), compared with the reference
step "mode L (weighted closure): diagnostics" python -I "$HERE/refcheck/affine_mode.py" "$HERE/inputs/diag"   "$OUT/lists/diag.txt" "$OUT/diag/ref/ref-pairs.csv" "$OUT/diag/affine"
step "mode L (weighted closure): chain population" python -I "$HERE/refcheck/affine_mode.py"   "$BASE/chain-composition/results/generated/inputs" "$OUT/lists/chain.txt" "$OUT/chain/ref/ref-pairs.csv" "$OUT/chain/affine"

# 3c. expression level: the prototype's composed expression equals the reference's (Z3 + random evaluation)
step "expression equality: diagnostics" python -I "$HERE/refcheck/expr_equiv.py" "$OUT/diag" "$HERE/inputs/diag" "$OUT/lists/diag.txt" "$OUT/diag/equiv"
step "expression equality: initial-register regressions" python -I "$HERE/refcheck/expr_equiv.py" "$OUT/regress" "$HERE/inputs/regress" "$OUT/lists/regress.txt" "$OUT/regress/equiv"
step "expression equality: chain population" python -I "$HERE/refcheck/expr_equiv.py" "$OUT/chain" "$BASE/chain-composition/results/generated/inputs" "$OUT/lists/chain.txt" "$OUT/chain/equiv"
step "expression equality: corpus" python -I "$HERE/refcheck/expr_equiv.py" "$OUT/corpus" "$BASE/corpus/litmus" "$OUT/lists/corpus.txt" "$OUT/corpus/equiv"

# 4. six encoded models on the LB programs of Table 3
D="$HERE/inputs/diag"
step "six-model probe (Table 3)" bash -c "PKGROOT='$BASE' WORK='$WORK/probe' bash '$HERE/impl/run_probe.sh' \
  '$D/LB-copy.litmus' '$D/LB-chain-double.litmus' '$D/LB-fake-xor-cycle.litmus' '$D/LBfd.litmus' \
  '$D/LB-direct-cancel.litmus' '$D/LB-chain-cancel.litmus' '$D/LB-real.litmus' > '$OUT/probe-six-models.txt'"

# 5. corpus recount (VMSA exclusion from file contents) and chain comparison
step "VMSA recount" bash -c "python -I '$HERE/scripts/vmsa_recount.py' '$BASE/corpus/litmus' '$OUT/lists/corpus.txt' \
  '$BASE/results/corrected-v1/six-model/corrected-symbolic.csv' '$OUT/corpus/files.csv' > '$OUT/vmsa-recount.txt'"
step "chain structure recount from the .litmus text" python -I "$HERE/scripts/recount_chain.py"   "$BASE/chain-composition/results/generated/inputs" "$OUT/chain/recount.csv"
step "chain vs generator classification" bash -c "python -I '$HERE/scripts/compare_archived.py' \
  '$BASE/chain-composition/results/pairs-final.csv' '$OUT/chain/edges.csv' '$OUT/chain/files.csv' > '$OUT/chain-compare.txt'"

# 6. rings: expression classes (reference evaluator) and, optionally, the full audit
mkdir -p "$OUT/rings"
step "ring expression classes" bash -c "cd '$OUT/rings' && python -I '$HERE/scripts/classify_rings.py' '$HERE/refcheck' \
  '$BASE/hardbench/generated-hard-candidates.json' '$BASE/repair/symbolic-ring-audit.csv' > classes-summary.txt"
if [ "${RINGS:-0}" = 1 ]; then
  step "full ring audit, corrected build (3,656 rings)" bash -c "WORK='$WORK/rings' python -I '$BASE/reproduce/06_repair.py' '$BASE' --impl corrected > '$OUT/rings/run-06-corrected.log' 2>&1"
fi

# 6b. corpus accounting: raw, byte-distinct and normalised counts; every test whose verdict changes, per comparison
step "corpus accounting" bash -c "python -I '$HERE/scripts/corpus_accounting.py' '$OUT' '$BASE' '$OUT/corpus/accounting' > /dev/null"
# 6c. the solver-free validator itself (fixed cases, normaliser soundness, mutation sensitivity, all recorded verdicts)
step "solver-free validator tests" bash -c "set -o pipefail; python -I '$HERE/scripts/test_semcheck.py' '$OUT' | tee '$OUT/test_semcheck.txt'"

# 7. assert the reported numbers
REQ=""; [ "${RINGS:-0}" = 1 ] && REQ="--require-rings"
step "check_numbers.py" bash -c "set -o pipefail; python -I '$HERE/scripts/check_numbers.py' '$OUT' '$BASE' $REQ | tee '$OUT/check_numbers.txt'"

# 8. the checks themselves: each must fail on corrupted copies of these outputs (copies live under WORK)
step "negative tests of check_numbers.py" bash -c "set -o pipefail; python -I '$HERE/scripts/test_check_numbers.py' '$OUT' '$BASE' '$WORK/negative' $REQ | tee '$OUT/test_check_numbers.txt'"
step "sensitivity of the expression check" bash -c "set -o pipefail; python -I '$HERE/scripts/test_expr_equiv.py' '$OUT/diag' '$HERE/inputs/diag' '$OUT/lists/diag.txt' '$WORK/equiv-test' | tee '$OUT/test_expr_equiv.txt'"

say "failures: $FAILS"
# hash the outputs last, after the final log line, so OUT/SHA256SUMS verifies
( cd "$OUT" && find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum ) > "$OUT/SHA256SUMS"
# exit status: 0 only if every step succeeded (a count of 256 must not wrap to 0)
[ "$FAILS" -eq 0 ]
