# Bounded external comparison: LLVM known bits (not run by `run_all.sh`)

One example, run once on 2026-11-08; it establishes only that example.

- Tool: LLVM 22.1.0 as bundled in llvmlite 0.50.0 (Python 3.11.9, isolated venv, `pip install llvmlite==0.50.0`).
  No C front end: the IR is hand-written, so nothing is simplified before the passes.
- Inputs: `i32 %x, %u`, unconstrained function arguments; plain `mul`/`add` (wrap-around, no `nsw`/`nuw`).
- Pipelines: P1 = InstCombine; P2 = NewGVN then InstCombine (new pass manager, one function at a time).
- Queries, for E in {2x, 2x+1} and, as an extra, 2x+2:
  - Q1 low bit: `E & 1`. Is it folded to a constant (bit 0 known)?
  - Q2 the paper's separating context (Thm 3(a), Sec. 3): `zext(E != 2*x) * (u+1)`. Is the result the constant 0,
    or does it still reference `%u`?
- Run: `python -I llvm_knownbits.py > llvm_knownbits.out` (inside the venv). Output: `llvm_knownbits.out`
  (input IR, per-query results, optimised IR for both pipelines).

| E | Q1 (P1, P2) | Q2, P1 | Q2, P2 |
|---|---|---|---|
| 2x | `ret 0` | `ret 0` (no `%u`) | `ret 0` |
| 2x+1 | `ret 1` | `ret u+1` (`%u` kept) | `ret u+1` |
| 2x+2 | `ret 0` | not folded (select on two `shl` copies; `%u` kept) | `ret u+1` |

Attribution. The 2x fold in Q2 comes from InstCombine recognising the same expression (`2*x != 2*x`), not from
known bits. The 2x+1 result is consistent with known bits (bit 0 is 1 on one side and 0 on the other); the
individual rule was not instrumented. 2x+2 has the same known bits as 2x (bit 0 = 0, the rest unknown), so a
known-bits value alone does not separate them; P2 needs NewGVN for that.

Answers. (1) The analysis distinguishes the intermediate values 2x and 2x+1 (Q1). (2) In the context it resolves
the dependence on `u` for both (absent after 2x, present after 2x+1). (3) KnownBits (Zero/One masks per value)
and InstCombine's expression rewriting are not read sets, so this lies outside the class of Thm 2 and does not
test it. A bit-level taint tool inside the class (DataFlowSanitizer, label union) was not run: it needs Linux, and
this machine has no Linux or WSL distribution.
