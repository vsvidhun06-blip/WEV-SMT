"""Bounded external comparison (memory-hop repair pass, 2026-11-08): LLVM's InstCombine, whose integer
reasoning uses the KnownBits transfer functions of llvm/Support/KnownBits.h via ValueTracking's
computeKnownBits, on hand-written 32-bit IR (no C front end, so nothing is simplified before the pass).

Inputs: x, u : i32, unconstrained (function arguments).  Wrap-around: plain `mul`/`add` without nsw/nuw.
Pipelines: (P1) InstCombine alone; (P2) NewGVN then InstCombine.  Driver: llvmlite (bundled LLVM).

Queries
  Q1  low bit:   f(x) = (E(x)) & 1          does the pass reduce it to a constant (bit 0 known)?
  Q2  context:   g(x,u) = zext(E(x) != 2*x) * (u+1)   (the paper's separating context, Thm 3(a) / Sec. 3)
                 does the optimised return value still reference %u (dependence on u not resolved
                 away), and is it the constant 0?
  for E in {2x, 2x+1} (required) and 2x+2 (extra: known bits of 2x+2 and 2x agree on every bit).
Usage: python -I llvm_knownbits.py   (inside the venv that has llvmlite)"""
import llvmlite, llvmlite.binding as llvm

E = {'2x': ['%t = mul i32 %x, 2'],
     '2x+1': ['%m = mul i32 %x, 2', '%t = add i32 %m, 1'],
     '2x+2': ['%m = mul i32 %x, 2', '%t = add i32 %m, 2']}

def fn_low(name, body):
    return (f'define i32 @low_{name}(i32 %x) {{\n  ' + '\n  '.join(body) +
            '\n  %r = and i32 %t, 1\n  ret i32 %r\n}\n')

def fn_ctx(name, body):
    return (f'define i32 @ctx_{name}(i32 %x, i32 %u) {{\n  ' + '\n  '.join(body) +
            '\n  %k = mul i32 %x, 2\n  %c = icmp ne i32 %t, %k\n  %z = zext i1 %c to i32\n'
            '  %v = add i32 %u, 1\n  %r = mul i32 %z, %v\n  ret i32 %r\n}\n')

def safe(n): return n.replace('+', 'p')

ir = ''.join(fn_low(safe(n), b) + fn_ctx(safe(n), b) for n, b in E.items())

def run(pipeline):
    llvm.initialize_native_target(); llvm.initialize_native_asmprinter()
    mod = llvm.parse_assembly(ir); mod.verify()
    tm = llvm.Target.from_default_triple().create_target_machine()
    pto = llvm.create_pipeline_tuning_options()
    pb = llvm.create_pass_builder(tm, pto)
    fpm = llvm.create_new_function_pass_manager()
    if pipeline == 'P2': fpm.add_new_gvn_pass()
    fpm.add_instruction_combine_pass()
    for f in mod.functions: fpm.run(f, pb)
    return mod

def body_of(mod, name):
    s = str(mod.get_function(name))
    return '\n'.join(l for l in s.splitlines() if l.strip() and not l.startswith(';'))

print('llvmlite', llvmlite.__version__, 'LLVM', '.'.join(map(str, llvm.llvm_version_info)))
print('==== input IR ====\n' + ir)
for P in ('P1', 'P2'):
    mod = run(P)
    print(f'==== pipeline {P}: ' + ('InstCombine' if P == 'P1' else 'NewGVN; InstCombine') + ' ====')
    for n in E:
        lo, cx = body_of(mod, f'low_{safe(n)}'), body_of(mod, f'ctx_{safe(n)}')
        ret_lo = [l for l in lo.splitlines() if 'ret ' in l][0].strip()
        ret_cx = [l for l in cx.splitlines() if 'ret ' in l][0].strip()
        uses_u = '%u' in cx.split('{', 1)[1]
        print(f'  E={n:5s} Q1 low bit -> {ret_lo:16s} | Q2 context -> {ret_cx:18s} references %u: {uses_u}')
    print('---- optimised IR ----\n' + str(mod))
